#target illustrator
app.preferences.setBooleanPreference('ShowExternalJSXWarning', false);

/*

### 概要

ドキュメント内のオブジェクトをアートボードとの重なり条件で判定し、外側のオブジェクトを削除または保管用レイヤーへ移動します。
対象は「現在のアートボードのみ」または「すべてのアートボード」から選べます。

詳細は README を参照してください。

### Overview

Tests the objects in the document against the artboards and either deletes the ones outside or moves them to a holding layer.
The scope can be the current artboard only, or every artboard.

See the README for details.

*/

// =========================================
// 基本情報 / Basic info
// =========================================
var SCRIPT_NAME     = "DeleteOutsideArtboard";        /* スクリプト名 / script name */
var SCRIPT_VERSION  = "v1.4.1";                         /* バージョン / version */
var SCRIPT_AUTHOR   = "Masahiro Takano (@swwwitch)";  /* 作者 / author */
var SCRIPT_RELEASED = "2025-07-08";                   /* 最初のリリース日 / first release date */
var SCRIPT_UPDATED  = "2026-09-19";                   /* 更新日 / last updated */

var SCRIPT_README_JA = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/DeleteOutsideArtboard.md"; /* README（日本語） */
var SCRIPT_README_EN = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/DeleteOutsideArtboard.md"; /* README (English) */

// Released under the MIT license
// http://opensource.org/licenses/mit-license.php

(function () {

    /**
     * ラジオボタンを1つ追加し、ツールチップを設定する
     * @param {Group|Panel} parentContainer - 追加先のコンテナ
     * @param {object} labelEntry - ja / en を持つラベル定義
     * @param {object} [tooltipEntry] - ja / en を持つツールチップ定義
     * @returns {RadioButton} 追加したラジオボタン
     */
    function addRadio(parentContainer, labelEntry, tooltipEntry) {
        var radioButton = parentContainer.add("radiobutton", undefined, labelEntry[uiLang]);
        if (tooltipEntry) radioButton.helpTip = tooltipEntry[uiLang];
        return radioButton;
    }

    function getCurrentLang() {
      return ($.locale.indexOf("ja") === 0) ? "ja" : "en";
    }
    var uiLang = getCurrentLang();

    /* 日英ラベル定義 / Japanese-English label definitions */

    var LABELS = {
        dialog: {
            title: { ja: "オブジェクトを削除", en: "Delete Objects" }
        },
        panel: {
            scope: { ja: "アートボード内", en: "Inside Artboard" },
            outside: { ja: "アートボード外", en: "Outside Artboard" }
        },
        radio: {
            excludeSelected: { ja: "選択オブジェクトを残す", en: "Exclude Selected Objects" },
            allObjects: { ja: "すべて残す", en: "Keep All Objects" },
            remove: { ja: "削除", en: "Delete" },
            ignore: { ja: "無視（残す）", en: "Ignore (Keep)" }
        },
        checkbox: {
            includeLocked: { ja: "ロックされたオブジェクトを含む", en: "Include Locked Objects" },
            moveToBackup: { ja: "保管用レイヤーに移す", en: "Move to Backup Layer" }
        },
        tooltip: {
            excludeSelected: {
                ja: "アートボード内にあるオブジェクトのうち、選択しているものだけを残して他を削除します。",
                en: "Inside the artboard, keeps only the selected objects and deletes the rest."
            },
            allObjects: {
                ja: "アートボード内のオブジェクトはすべて残します。",
                en: "Keeps every object inside the artboard."
            },
            remove: { ja: "アートボードの外にはみ出したオブジェクトを削除します。", en: "Deletes the objects that sit outside the artboard." },
            ignore: { ja: "アートボードの外のオブジェクトはそのまま残します。", en: "Leaves the objects outside the artboard untouched." },
            includeLocked: {
                ja: "ロックされたオブジェクトも処理の対象にします。オフのときは触りません。",
                en: "Includes locked objects. They are left alone when this is off."
            },
            moveToBackup: {
                ja: "削除せずに保管用のレイヤーへ移します。あとから戻せます。",
                en: "Moves the objects to a backup layer instead of deleting them, so they can be brought back."
            }
        },
        button: {
            cancel: { ja: "キャンセル", en: "Cancel" },
            ok: { ja: "削除", en: "Delete" }
        },
        alert: {
            noSelection: { ja: "選択オブジェクトがありません。", en: "No objects selected." },
            noTargets: { ja: "削除対象のオブジェクトはありません。", en: "No objects to delete." }
        }
    };

    /* ダイアログを表示し、ユーザーの選択を取得 / Show dialog and get user selection */
    function showDialog() {
        /* ダイアログタイトル（日本語固定） / Dialog title (fixed Japanese) */
        var dialog = new Window("dialog", LABELS.dialog.title[uiLang]);
        dialog.orientation = "column";
        dialog.alignChildren = "fill";

        /* 対象範囲パネル / Target scope panel */
        var scopeGroup = dialog.add("panel", undefined, LABELS.panel.scope[uiLang]);
        scopeGroup.orientation = "column";
        scopeGroup.alignChildren = "left";
        scopeGroup.margins = [15, 20, 15, 10];

        var scopeRadios = {
            excludeSelected: addRadio(scopeGroup, LABELS.radio.excludeSelected, LABELS.tooltip.excludeSelected),
            allObjects: addRadio(scopeGroup, LABELS.radio.allObjects, LABELS.tooltip.allObjects)
        };

        /* Set radio default based on selection */
        var hasSelection = false;
        try {
            hasSelection = app.documents.length > 0 && app.activeDocument.selection && app.activeDocument.selection.length > 0;
        } catch (e) {
            hasSelection = false;
        }
        if (hasSelection) {
            scopeRadios.excludeSelected.value = true;
        } else {
            scopeRadios.allObjects.value = true;
        }

        /* アートボード外処理パネル / Outside artboard action panel */
        var abGroup = dialog.add("panel", undefined, LABELS.panel.outside[uiLang]);
        abGroup.orientation = "column";
        abGroup.alignChildren = "left";
        abGroup.margins = [15, 20, 15, 10];

        var deleteRadio = addRadio(abGroup, LABELS.radio.remove, LABELS.tooltip.remove);
        var ignoreRadio = addRadio(abGroup, LABELS.radio.ignore, LABELS.tooltip.ignore);
        ignoreRadio.value = true;

        /* オプション（保管用レイヤー、ロック含む） / Option (backup layer, include locked) */
        var optionGroup = dialog.add("group");
        optionGroup.orientation = "column";
        optionGroup.alignChildren = "left";
        optionGroup.margins = [15, 0, 15, 10];

        var ignoreLockedCheckbox = optionGroup.add("checkbox", undefined, LABELS.checkbox.includeLocked[uiLang]);
        ignoreLockedCheckbox.helpTip = LABELS.tooltip.includeLocked[uiLang];
        ignoreLockedCheckbox.value = true;

        var backupCheckbox = optionGroup.add("checkbox", undefined, LABELS.checkbox.moveToBackup[uiLang]);
        backupCheckbox.helpTip = LABELS.tooltip.moveToBackup[uiLang];
        backupCheckbox.value = false;

        /* ボタン / Buttons */
        var buttonGroup = dialog.add("group");
        buttonGroup.orientation = "row";
        buttonGroup.alignment = "center";
        var cancelBtn = buttonGroup.add("button", undefined, LABELS.button.cancel[uiLang]);
        var okBtn = buttonGroup.add("button", undefined, LABELS.button.ok[uiLang], {
            name: "ok"
        });

        cancelBtn.onClick = function() {
            dialog.close();
        };
        okBtn.onClick = function() {
            var resultCode = 0;
            if (scopeRadios.excludeSelected.value) {
                resultCode += 100;
            }
            /* Only two options: 削除 (deleteRadio) or 無視 (ignoreRadio) */
            if (deleteRadio.value) {
                resultCode += 1;
            } else if (ignoreRadio.value) {
                resultCode += 3;
            }
            if (backupCheckbox.value) resultCode += 10;
            if (!ignoreLockedCheckbox.value) resultCode += 1000;
            dialog.close(resultCode);
        };

        var result = dialog.show();
        return result;
    }

    /* バウンディングボックスの重なり率（大きい方の面積に対する割合）を返す / Return overlap ratio of bounding boxes (relative to larger area) */
    function getOverlapRatio(a, b) {
        var ax = Math.max(0, Math.min(a[2], b[2]) - Math.max(a[0], b[0]));
        var ay = Math.max(0, Math.min(a[1], b[1]) - Math.max(a[3], b[3]));
        var overlapArea = ax * ay;
        if (overlapArea <= 0) return 0;
        var areaA = (a[2] - a[0]) * (a[1] - a[3]);
        var areaB = (b[2] - b[0]) * (b[1] - b[3]);
        var maxArea = Math.max(areaA, areaB);
        return overlapArea / maxArea;
    }

    /* オブジェクトがアートボードと重なっているか判定 / Check if object overlaps artboard */
    function isOverlappingArtboard(item, artboard) {
        var itemBounds = item.visibleBounds;
        var abBounds = artboard.artboardRect;
        var overlapRatio = getOverlapRatio(itemBounds, abBounds);
        return overlapRatio > 0;
    }

    /* 指定したオブジェクトが対象のアートボード群のいずれかと重なっているか判定 / Check if item overlaps any of the artboards */
    function checkOverlapWithArtboards(item, artboards) {
        for (var i = 0; i < artboards.length; i++) {
            if (isOverlappingArtboard(item, artboards[i])) {
                return true;
            }
        }
        return false;
    }

    /* アートボード外オブジェクトを収集 / Collect objects outside artboards */
    function collectOutsideItems(items, artboards, currentOnly, ab, result, includeLocked) {
        for (var i = items.length - 1; i >= 0; i--) {
            var item = items[i];

            if (item.layer && item.layer.name === "// backup") {
                continue;
            }

            if (!includeLocked && item.locked) continue;

            if (item.locked) item.locked = false;
            if (!item.visible) item.visible = true;

            if (item.typename === "GroupItem") {
                var groupTarget = item;
                /* If clipped group, use the clipping path for bounds */
                if (item.clipped) {
                    for (var k = 0; k < item.pageItems.length; k++) {
                        if (item.pageItems[k].clipping) {
                            groupTarget = item.pageItems[k];
                            break;
                        }
                    }
                }

                var overlapsGroup = false;
                if (currentOnly) {
                    overlapsGroup = isOverlappingArtboard(groupTarget, ab);
                } else {
                    overlapsGroup = checkOverlapWithArtboards(groupTarget, artboards);
                }

                if (!overlapsGroup) {
                    result.push(item);
                    continue; /* Skip inside items if group added */
                }

                /* If group overlaps, check inside */
                collectOutsideItems(item.pageItems, artboards, currentOnly, ab, result, includeLocked);
                continue;
            }

            var overlaps = false;
            if (currentOnly) {
                overlaps = isOverlappingArtboard(item, ab);
            } else {
                overlaps = checkOverlapWithArtboards(item, artboards);
            }

            if (!overlaps) {
                result.push(item);
            }
        }
    }

    /* アートボード外オブジェクトを削除または保管用レイヤーに移動 / Remove or move objects outside artboards */
    /* mode: 0=All Objects, 1=Exclude Selected (Current Artboard) */
    function removeOutsideObjects(currentOnly, moveToBackup, mode, includeLocked) {
        if (!app.documents.length) return;
        var doc = app.activeDocument;
        var artboards = doc.artboards;
        var ab = doc.artboards[doc.artboards.getActiveArtboardIndex()];

        if (currentOnly === null) {
            /* "無視" 選択時は何もしないで終了 / Do nothing and exit when ignore mode selected */
            return;
        }

        var outsideItems = [];
        collectOutsideItems(doc.pageItems, artboards, currentOnly, ab, outsideItems, includeLocked);

        if (mode === 1) {
            /* 「選択オブジェクトを残す」: Delete/move all objects inside current artboard except selected */
            var currentSelection = doc.selection;
            if (!currentSelection || currentSelection.length === 0) {
                alert(LABELS.alert.noSelection[uiLang]);
                return;
            }
            /* Collect all objects inside current artboard (including locked/hidden as per includeLocked) */
            var insideItems = [];

            function collectInsideItems(items) {
                for (var i = items.length - 1; i >= 0; i--) {
                    var item = items[i];
                    if (item.layer && item.layer.name === "// backup") continue;
                    if (!includeLocked && item.locked) continue;
                    if (item.locked) item.locked = false;
                    if (!item.visible) item.visible = true;
                    if (item.typename === "GroupItem") {
                        var groupTarget = item;
                        if (item.clipped) {
                            for (var k = 0; k < item.pageItems.length; k++) {
                                if (item.pageItems[k].clipping) {
                                    groupTarget = item.pageItems[k];
                                    break;
                                }
                            }
                        }
                        if (isOverlappingArtboard(groupTarget, ab)) {
                            insideItems.push(item);
                            /* Also check inside group for further items */
                            collectInsideItems(item.pageItems);
                        }
                        continue;
                    }
                    if (isOverlappingArtboard(item, ab)) {
                        insideItems.push(item);
                    }
                }
            }
            collectInsideItems(doc.pageItems);
            /* Exclude selected objects */
            var selectedSet = {};
            for (var si = 0; si < currentSelection.length; si++) {
                selectedSet[currentSelection[si]] = true;
            }
            /* For ExtendScript, compare by reference */
            var filteredItems = [];
            for (var ii = 0; ii < insideItems.length; ii++) {
                var isSelected = false;
                for (var sj = 0; sj < currentSelection.length; sj++) {
                    if (insideItems[ii] === currentSelection[sj]) {
                        isSelected = true;
                        break;
                    }
                }
                if (!isSelected) {
                    filteredItems.push(insideItems[ii]);
                }
            }
            outsideItems = filteredItems;
        }

        if (outsideItems.length === 0) {
            alert(LABELS.alert.noTargets[uiLang]);
            return;
        }

        for (var i = 0; i < outsideItems.length; i++) {
            var item = outsideItems[i];

            try {
                if (item.locked) item.locked = false;
                if (!item.visible) item.visible = true;
                if (item.layer && item.layer.locked) item.layer.locked = false;

                if (moveToBackup) {
                    moveItemToBackupLayer(item, doc);
                } else {
                    item.remove();
                }
            } catch (e) {
                $.writeln("Skipped invalid object: " + e);
            }
        }
    }

    /* オブジェクトを保管用レイヤーに移動（ロック・非表示解除を含む、グループも対応） / Move object to backup layer (unlock/show, supports group) */
    function moveItemToBackupLayer(item, doc) {
        var backupLayerName = "// backup";
        var backupLayer = null;
        try {
            backupLayer = doc.layers.getByName(backupLayerName);
        } catch (e) {
            backupLayer = doc.layers.add();
            backupLayer.name = backupLayerName;
        }

        if (backupLayer.locked) backupLayer.locked = false;
        if (!backupLayer.visible) backupLayer.visible = true;

        function unlockAndShowAll(target) {
            if (target.locked) target.locked = false;
            if (!target.visible) target.visible = true;
            if (typeof target.pageItems !== "undefined" && target.pageItems.length > 0) {
                for (var i = 0; i < target.pageItems.length; i++) {
                    unlockAndShowAll(target.pageItems[i]);
                }
            }
        }
        unlockAndShowAll(item);

        item.move(backupLayer, ElementPlacement.PLACEATBEGINNING);

        backupLayer.visible = false;
    }

    /* メイン処理 / Main process */
    function main() {
        var dialogResult = showDialog();
        if (dialogResult === 0 || dialogResult === undefined) return;

        var mode = 0;
        var includeLocked = true;
        if (dialogResult >= 1000) {
            includeLocked = false;
            dialogResult -= 1000;
        }
        if (dialogResult >= 100) {
            mode = 1;
            dialogResult -= 100;
        }

        var currentOnly = null;
        if (mode === 1) {
            /* 「選択オブジェクトを残す」モードの場合は必ず現在のアートボードのみを対象とする / In 'Exclude Selected' mode, always target current artboard only */
            currentOnly = true;
        } else {
            if (dialogResult === 1) {
                currentOnly = true;
            } else if (dialogResult === 3) {
                currentOnly = null; /* 無視モード / Ignore mode */
            }
        }

        var moveToBackup = false;
        if (dialogResult >= 10) {
            moveToBackup = true;
            dialogResult -= 10;
        }

        if (currentOnly !== null) {
            removeOutsideObjects(currentOnly, moveToBackup, mode, includeLocked);
        }
    }

    main();

})();
