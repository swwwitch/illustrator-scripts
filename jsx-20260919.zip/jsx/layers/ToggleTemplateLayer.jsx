#target illustrator
app.preferences.setBooleanPreference('ShowExternalJSXWarning', false);

/*

### 概要

アクティブレイヤーの「テンプレート」属性（ロック・印刷不可・画像を薄く表示）をON/OFFします。
小さなダイアログで切り替えを選び、ダイナミックアクションで実行します。

詳細は README を参照してください。

### Overview

Toggles the template attribute — locked, non-printing and dimmed images — on the active layer.
A small dialog picks the direction, and the change is applied through a dynamic action.

See the README for details.

*/

// =========================================
// 基本情報 / Basic info
// =========================================
var SCRIPT_NAME     = "ToggleTemplateLayer";          /* スクリプト名 / script name */
var SCRIPT_VERSION  = "v1.3.1";                         /* バージョン / version */
var SCRIPT_AUTHOR   = "Masahiro Takano (@swwwitch)";  /* 作者 / author */
var SCRIPT_RELEASED = "2024-07-21";                   /* 最初のリリース日 / first release date */
var SCRIPT_UPDATED  = "2026-09-19";                   /* 更新日 / last updated */

var SCRIPT_README_JA = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/ToggleTemplateLayer.md"; /* README（日本語） */
var SCRIPT_README_EN = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/ToggleTemplateLayer.md"; /* README (English) */

// Released under the MIT license
// http://opensource.org/licenses/mit-license.php

(function () {

  // 一時アクション設定 / Temporary action settings
  // =========================================

  var ACTION_SET_NAME = "DynamicActionLayerTemplate";
  var ACTION_NAME_ON = "TemplateON";
  var ACTION_NAME_OFF = "TemplateOFF";
  var ACTION_FILE_NAME = "~/ToggleTemplateLayerAction.aia";

  /*
    レイヤーオプションのプリセット（チェックボックスの ON/OFF）
    Layer-option presets (dialog checkbox states)
  */
  var TEMPLATE_ON_OPTIONS = {
    template: true,   /* tmpl テンプレート */
    show: true,       /* show 表示 */
    lock: true,       /* lock ロック */
    preview: true,    /* prvw プレビュー */
    print: false,     /* prnt プリント */
    dim: true,        /* dim. 画像を薄く表示 */
    dimPercent: 50    /* 薄く表示の％（dim が true のときだけ書き出す） */
  };

  var TEMPLATE_OFF_OPTIONS = {
    template: false,
    show: true,
    lock: false,
    preview: true,
    print: true,
    dim: false,
    dimPercent: 50
  };

  // =========================================
  // 一時アクション生成 / Temporary action generation
  // =========================================

  /*
    記録済みの .aia から採取した internalName / key を使い、オプションから組み立てる
    Build the action from recorded internalName / keys, driven by the options preset
  */
  // =========================================
  // ローカライズ / Localization
  // =========================================

  /**
   * 現在のUI言語を判定する
   * @returns {string} "ja" または "en"
   */
  function getCurrentLang() {
    return ($.locale.indexOf("ja") === 0) ? "ja" : "en";
  }
  var uiLang = getCurrentLang();

  /* 日英ラベル定義 / Japanese-English label definitions */
  var LABELS = {
    dialogTitle: { ja: "レイヤーテンプレート", en: "Layer Template" },
    description: {
      ja: "アクティブレイヤーのテンプレート属性を切り替えます。",
      en: "Toggles the template attribute of the active layer."
    },
    buttonOn:  { ja: "ON（テンプレート化）", en: "ON (make template)" },
    buttonOff: { ja: "OFF（解除）", en: "OFF (release)" },
    cancel:    { ja: "キャンセル", en: "Cancel" },
    tipOn: {
      ja: "アクティブレイヤーをテンプレートレイヤーにします。印刷・書き出しの対象から外れ、ロックされます。",
      en: "Makes the active layer a template layer: it is locked and left out of printing and export."
    },
    tipOff: {
      ja: "テンプレート属性を外して、通常のレイヤーに戻します。",
      en: "Clears the template attribute and returns the layer to a normal one."
    }
  };

  /**
   * ラベルを取得する
   * @param {string} key - LABELS のキー
   * @returns {string} 現在のUI言語のラベル
   */
  function getLabel(key) {
    return LABELS[key] ? LABELS[key][uiLang] : key;
  }

  function buildActionSource(setName, actionName, layerName, options) {
    var parameterLines = buildLayerParameterLines(layerName, options);

    var parameterBlock = '';
    for (var i = 0; i < parameterLines.length; i++) {
      parameterBlock += ' /parameter-' + (i + 1) + ' { ' + parameterLines[i] + ' }\n';
    }

    return ''
      + '/version 3\n'
      + buildActionNameLine(setName)
      + '/isOpen 1\n'
      + '/actionCount 1\n'
      + '/action-1 {\n'
      + ' ' + buildActionNameLine(actionName)
      + ' /keyIndex 0\n'
      + ' /colorIndex 0\n'
      + ' /isOpen 1\n'
      + ' /eventCount 1\n'
      + ' /event-1 {\n'
      + ' /useRulersIn1stQuadrant 0\n'
      + ' /internalName (ai_plugin_Layer)\n'
      + ' /localizedName [ 9 e8a1a8e7a4ba203a20 ]\n'
      + ' /isOpen 1\n'
      + ' /isOn 1\n'
      + ' /hasDialog 1\n'
      + ' /showDialog 0\n'
      + ' /parameterCount ' + parameterLines.length + '\n'
      + parameterBlock
      + ' }\n'
      + '}\n';
  }

  /*
    parameter-* を1行ずつ生成。key は記録済み .aia の FourCC（tmpl/show/lock/prvw/prnt/dim.）
    Build each parameter line; keys are FourCC from the recorded .aia
    dim が true のときだけ末尾に「薄く表示の％」行を追加する（OFF では出さない）
  */
  function buildLayerParameterLines(layerName, options) {
    var lines = [];
    lines.push('/key 1836411236 /showInPalette 4294967295 /type (integer) /value 4');                                   /* カラー（ラベル色） */
    lines.push('/key 1851878757 /showInPalette 4294967295 /type (ustring) /value [ 36 e383ace382a4e383a4e383bce38391e3838de383abe382aae38397e382b7e383a7e383b3 ]'); /* 名前ラベル */
    lines.push('/key 1953068140 /showInPalette 4294967295 /type (ustring) /value ' + buildUstringValue(layerName));     /* レイヤー名（動的注入） */
    lines.push('/key 1953329260 /showInPalette 4294967295 /type (boolean) /value ' + boolBit(options.template));        /* tmpl テンプレート */
    lines.push('/key 1936224119 /showInPalette 4294967295 /type (boolean) /value ' + boolBit(options.show));            /* show 表示 */
    lines.push('/key 1819239275 /showInPalette 4294967295 /type (boolean) /value ' + boolBit(options.lock));            /* lock ロック */
    lines.push('/key 1886549623 /showInPalette 4294967295 /type (boolean) /value ' + boolBit(options.preview));         /* prvw プレビュー */
    lines.push('/key 1886547572 /showInPalette 4294967295 /type (boolean) /value ' + boolBit(options.print));           /* prnt プリント */
    lines.push('/key 1684630830 /showInPalette 4294967295 /type (boolean) /value ' + boolBit(options.dim));             /* dim. 画像を薄く表示 */
    if (options.dim) {
      lines.push('/key 1885564532 /showInPalette 4294967295 /type (unit real) /value ' + formatDimPercent(options.dimPercent) + ' /unit 592474723'); /* 薄く表示の％ */
    }
    return lines;
  }

  function boolBit(flag) {
    return flag ? 1 : 0;
  }

  function formatDimPercent(percent) {
    return percent.toFixed(1);
  }

  function buildActionNameLine(actionName) {
    return '/name [ ' + actionName.length + ' ' + stringToHex(actionName) + ' ]\n';
  }

  function stringToHex(sourceText) {
    var hexText = "";
    for (var i = 0; i < sourceText.length; i++) {
      var hexValue = sourceText.charCodeAt(i).toString(16);
      if (hexValue.length < 2) hexValue = "0" + hexValue;
      hexText += hexValue;
    }
    return hexText;
  }

  /*
    ustring 値（[ バイト数 UTF-8のhex ]）を生成する
    Build a ustring value ([ byteCount UTF-8 hex ]); handles multi-byte names
  */
  function buildUstringValue(sourceText) {
    var byteString = unescape(encodeURIComponent(sourceText));
    var hexText = "";
    for (var i = 0; i < byteString.length; i++) {
      var hexValue = byteString.charCodeAt(i).toString(16);
      if (hexValue.length < 2) hexValue = "0" + hexValue;
      hexText += hexValue;
    }
    return '[ ' + byteString.length + ' ' + hexText + ' ]';
  }

  // =========================================
  // 一時アクション実行 / Temporary action playback
  // =========================================

  function playTemporaryAction(actionSource, setName, actionName, actionFilePath) {
    var actionFile = new File(actionFilePath);
    var isActionLoaded = false;
    var isActionFileOpen = false;

    try { app.unloadAction(setName, ""); } catch (e) { }

    try {
      if (!actionFile.open("w")) {
        throw new Error("Failed to open temporary action file.");
      }
      isActionFileOpen = true;

      actionFile.write(actionSource);
      actionFile.close();
      isActionFileOpen = false;

      app.loadAction(actionFile);
      isActionLoaded = true;

      app.doScript(actionName, setName, false);

    } catch (e) {
      alert("テンプレート属性の適用に失敗しました。\nFailed to apply the template attribute.\n\n" + e);

    } finally {
      if (isActionFileOpen) {
        try { actionFile.close(); } catch (e) { }
      }

      if (actionFile.exists) {
        try { actionFile.remove(); } catch (e) { }
      }

      if (isActionLoaded) {
        try { app.unloadAction(setName, ""); } catch (e) { }
      }
    }
  }

  // =========================================
  // ダイアログ / Dialog
  // =========================================

  /*
    ON / OFF を選ぶ小ダイアログ。戻り値は "on" / "off" / null（キャンセル）
    Small dialog to choose ON / OFF; returns "on" / "off" / null (cancel)
  */
  function chooseTemplateMode() {
    var dialog = new Window("dialog", getLabel("dialogTitle") + " " + SCRIPT_VERSION);
    dialog.orientation = "column";
    dialog.alignChildren = "fill";
    dialog.margins = 16;
    dialog.spacing = 12;

    dialog.add("statictext", undefined, getLabel("description"));

    var buttonGroup = dialog.add("group");
    buttonGroup.alignment = "right";

    var cancelButton = buttonGroup.add("button", undefined, getLabel("cancel"), { name: "cancel" });
    var offButton = buttonGroup.add("button", undefined, getLabel("buttonOff"));
    offButton.helpTip = getLabel("tipOff");
    var onButton = buttonGroup.add("button", undefined, getLabel("buttonOn"), { name: "ok" });
    onButton.helpTip = getLabel("tipOn");

    var chosenMode = null;
    onButton.onClick = function () { chosenMode = "on"; dialog.close(); };
    offButton.onClick = function () { chosenMode = "off"; dialog.close(); };
    cancelButton.onClick = function () { chosenMode = null; dialog.close(); };

    dialog.show();
    return chosenMode;
  }

  // =========================================
  // メイン処理 / Main
  // =========================================

  function applyLayerTemplate() {
    if (app.documents.length === 0) {
      alert("ドキュメントが開かれていません。\nNo document is open.");
      return;
    }

    var mode = chooseTemplateMode();
    if (!mode) return; /* キャンセル / Cancelled */

    var activeLayer = app.activeDocument.activeLayer;

    /*
      ロック確認はテンプレート化（ON）のときのみ。
      OFF はテンプレート（＝ロック済み）を解除する用途なので、ロックは許容する。
      Lock check applies only to ON; OFF intentionally allows locked layers (templates are locked).
    */
    if (mode === "on" && activeLayer.locked) {
      alert("アクティブレイヤーがロックされているため、実行できません。\nThe active layer is locked.");
      return;
    }

    /* 非表示レイヤーは ON/OFF とも対象外 / Hidden layers are skipped in both modes */
    if (!activeLayer.visible) {
      alert("アクティブレイヤーが非表示のため、実行できません。\nThe active layer is hidden.");
      return;
    }

    /* 実行前にアクティブレイヤー名を取得して parameter-3 に注入（リネーム防止） */
    /* Capture the active layer name and inject it into parameter-3 (avoid renaming) */
    var layerName = activeLayer.name;

    var options = (mode === "on") ? TEMPLATE_ON_OPTIONS : TEMPLATE_OFF_OPTIONS;
    var actionName = (mode === "on") ? ACTION_NAME_ON : ACTION_NAME_OFF;

    var actionSource = buildActionSource(ACTION_SET_NAME, actionName, layerName, options);
    playTemporaryAction(actionSource, ACTION_SET_NAME, actionName, ACTION_FILE_NAME);
  }

  applyLayerTemplate();

})();
