#target illustrator
app.preferences.setBooleanPreference('ShowExternalJSXWarning', false);

/*

### 概要

「bg-template」レイヤーをテンプレート化します。

詳細は README を参照してください。

### Overview

Marks the "bg-template" layer as a template layer.

See the README for details.

*/

// =========================================
// 基本情報 / Basic info
// =========================================
var SCRIPT_NAME     = "bg-template-only";             /* スクリプト名 / script name */
var SCRIPT_VERSION  = "v1.0";                         /* バージョン / version */
var SCRIPT_AUTHOR   = "Masahiro Takano (@swwwitch)";  /* 作者 / author */
var SCRIPT_RELEASED = "";                             /* 最初のリリース日 / first release date */
var SCRIPT_UPDATED  = "";                             /* 更新日 / last updated */

var SCRIPT_README_JA = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/bg-template-only.md"; /* README（日本語） */
var SCRIPT_README_EN = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/bg-template-only.md"; /* README (English) */

// Released under the MIT license
// http://opensource.org/licenses/mit-license.php

(function () {

    function act_setLayTmplAttr() {
        var actionSetName = "layer";
        var actionName = "template";

        // アクション定義テキスト / Action definition text
        var actionCode = [
            " /version 3",
            "/name [ 5",
            "	6c61796572",
            "]",
            "/isOpen 1",
            "/actionCount 1",
            "/action-1 {",
            "	/name [ 8",
            "		74656d706c617465",
            "	]",
            "	/keyIndex 0",
            "	/colorIndex 0",
            "	/isOpen 1",
            "	/eventCount 1",
            "	/event-1 {",
            "		/useRulersIn1stQuadrant 0",
            "		/internalName (ai_plugin_Layer)",
            "		/localizedName [ 9",
            "			e8a1a8e7a4ba203a20",
            "		]",
            "		/isOpen 1",
            "		/isOn 1",
            "		/hasDialog 1",
            "		/showDialog 0",
            "		/parameterCount 9",
            "		/parameter-1 {",
            "			/key 1836411236",
            "			/showInPalette 4294967295",
            "			/type (integer)",
            "			/value 4",
            "		}",
            "		/parameter-2 {",
            "			/key 1851878757",
            "			/showInPalette 4294967295",
            "			/type (ustring)",
            "			/value [ 36",
            "				e383ace382a4e383a4e383bce38391e3838de383abe382aae38397e382b7e383",
            "				a7e383b3",
            "			]",
            "		}",
            "		/parameter-3 {",
            "			/key 1953329260",
            "			/showInPalette 4294967295",
            "			/type (boolean)",
            "			/value 1",
            "		}",
            "		/parameter-4 {",
            "			/key 1936224119",
            "			/showInPalette 4294967295",
            "			/type (boolean)",
            "			/value 1",
            "		}",
            "		/parameter-5 {",
            "			/key 1819239275",
            "			/showInPalette 4294967295",
            "			/type (boolean)",
            "			/value 1",
            "		}",
            "		/parameter-6 {",
            "			/key 1886549623",
            "			/showInPalette 4294967295",
            "			/type (boolean)",
            "			/value 1",
            "		}",
            "		/parameter-7 {",
            "			/key 1886547572",
            "			/showInPalette 4294967295",
            "			/type (boolean)",
            "			/value 0",
            "		}",
            "		/parameter-8 {",
            "			/key 1684630830",
            "			/showInPalette 4294967295",
            "			/type (boolean)",
            "			/value 1",
            "		}",
            "		/parameter-9 {",
            "			/key 1885564532",
            "			/showInPalette 4294967295",
            "			/type (unit real)",
            "			/value 50.0",
            "			/unit 592474723",
            "		}",
            "	}",
            "}"
        ].join("\n");
        var tempFile = new File(Folder.temp + "/temp_action.aia");
        tempFile.open("w");
        tempFile.write(actionCode);
        tempFile.close();

        /* 読み込み時点でパース済みなので、ここで一時ファイルを消しておく / The action is parsed on load, so remove the temp file now */
        app.loadAction(tempFile);
        tempFile.remove();

        try {
            app.doScript(actionName, actionSetName);
        } catch (e) {
            alert("エラーが発生しました: " + e);
        } finally {
            app.unloadAction(actionSetName, "");
        }
    }

    act_setLayTmplAttr();

})();
