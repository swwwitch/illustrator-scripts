#target illustrator
app.preferences.setBooleanPreference('ShowExternalJSXWarning', false);

/*

### 概要

現在のアートボードと同じ大きさの長方形を作成し、「bg-template」レイヤーに置いてテンプレート化したうえで最背面へ移動します。

詳細は README を参照してください。

### Overview

Creates a rectangle the size of the current artboard, places it on a "bg-template" layer, marks that layer as a template and sends it to the back.

See the README for details.

*/

// =========================================
// 基本情報 / Basic info
// =========================================
var SCRIPT_NAME     = "bg-template";                  /* スクリプト名 / script name */
var SCRIPT_VERSION  = "v1.0.1";                         /* バージョン / version */
var SCRIPT_AUTHOR   = "Masahiro Takano (@swwwitch)";  /* 作者 / author */
var SCRIPT_RELEASED = "2025-07-29";                   /* 最初のリリース日 / first release date */
var SCRIPT_UPDATED  = "2026-09-19";                   /* 更新日 / last updated */

var SCRIPT_README_JA = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/bg-template.md"; /* README（日本語） */
var SCRIPT_README_EN = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/bg-template.md"; /* README (English) */

// Released under the MIT license
// http://opensource.org/licenses/mit-license.php

(function () {

    function getCurrentLang() {
      return ($.locale.indexOf("ja") === 0) ? "ja" : "en";
    }
    var uiLang = getCurrentLang();

    // UIラベル定義 / UI Label Definitions
    var LABELS = {
        dialogTitle: {
            ja: "背景色レイヤーを作成 " + SCRIPT_VERSION,
            en: "Create Background Color Layer " + SCRIPT_VERSION
        },
        colorPanel: {
            ja: "カラー設定",
            en: "Color Settings"
        },
        marginLabel: {
            ja: "マージン",
            en: "Margin"
        },
        templateCheckbox: {
            ja: "「テンプレート」レイヤーに",
            en: "Set as Template Layer"
        },
        tipHex: {
            ja: "背景色を16進数で指定します（例: 999999）。RGB欄と連動します。",
            en: "Background color as a hex value, for example 999999. It is linked to the RGB fields."
        },
        tipMargin: {
            ja: "アートボードの外側へ背景を広げる量です。",
            en: "How far the background extends past the artboard."
        },
        tipTemplate: {
            ja: "作った背景をテンプレートレイヤーに置きます。印刷・書き出しの対象から外れ、ロックされます。",
            en: "Puts the background on a template layer: it is locked and left out of printing and export."
        },
        okButton: {
            ja: "OK",
            en: "OK"
        },
        cancelButton: {
            ja: "キャンセル",
            en: "Cancel"
        }
    };

    /**
     * コロン付きの項目名を返す（日本語は全角、英語は半角）
     * @param {string} key - LABELS のキー
     * @returns {string} コロンを添えたラベル
     */
    function labelText(key) {
        return LABELS[key][uiLang] + (uiLang === "ja" ? "：" : ": ");
    }

    // RGB → HEX 更新 / Update HEX from RGB
    function updateHexFromRGB(rInput, gInput, bInput, hexInput) {
        var r = Math.min(255, Math.max(0, parseInt(rInput.text) || 0));
        var g = Math.min(255, Math.max(0, parseInt(gInput.text) || 0));
        var b = Math.min(255, Math.max(0, parseInt(bInput.text) || 0));
        var hex = "#" +
            ("0" + r.toString(16)).slice(-2) +
            ("0" + g.toString(16)).slice(-2) +
            ("0" + b.toString(16)).slice(-2);
        hexInput.text = hex.toUpperCase();
    }

    // HEX → RGB 更新 / Update RGB from HEX
    function updateRGBFromHex(hexInput, rInput, gInput, bInput) {
        var hexValue = hexInput.text;
        var cleanHex = hexValue.replace(/^#/, ""); // 先頭の#を削除
        if (/^[0-9A-Fa-f]{6}$/.test(cleanHex)) {
            rInput.text = parseInt(cleanHex.substr(0, 2), 16);
            gInput.text = parseInt(cleanHex.substr(2, 2), 16);
            bInput.text = parseInt(cleanHex.substr(4, 2), 16);
        }
    }

    // 値を矢印キーで増減する関数 / Function to change value by arrow keys
    function changeValueByArrowKey(editText) {
        editText.addEventListener("keydown", function(event) {
            var value = Number(editText.text);
            if (isNaN(value)) return;

            var keyboard = ScriptUI.environment.keyboardState;
            var delta = 1;

            if (keyboard.shiftKey) {
                delta = 10;
                if (event.keyName == "Up") {
                    value = Math.ceil((value + 1) / delta) * delta;
                    event.preventDefault();
                } else if (event.keyName == "Down") {
                    value = Math.floor((value - 1) / delta) * delta;
                    event.preventDefault();
                }
            } else if (keyboard.altKey) {
                delta = 0.1;
                if (event.keyName == "Up") {
                    value += delta;
                    event.preventDefault();
                } else if (event.keyName == "Down") {
                    value -= delta;
                    event.preventDefault();
                }
            } else {
                delta = 1;
                if (event.keyName == "Up") {
                    value += delta;
                    event.preventDefault();
                } else if (event.keyName == "Down") {
                    value -= delta;
                    event.preventDefault();
                }
            }

            if (keyboard.altKey) {
                value = Math.round(value * 10) / 10; // 小数第1位まで
            } else {
                value = Math.round(value); // 整数
            }

            editText.text = value;
        });
    }

    function act_setLayTmplAttr() {
        var actionSetName = "layer";
        var actionName = "template";

        // アクション定義テキスト / Action definition text
        var actionCode = [
            " /version 3",
            "/name [ 5",
            "	6c61796572",
            "]",
            "/isOpen 1",
            "/actionCount 1",
            "/action-1 {",
            "	/name [ 8",
            "		74656d706c617465",
            "	]",
            "	/keyIndex 0",
            "	/colorIndex 0",
            "	/isOpen 1",
            "	/eventCount 1",
            "	/event-1 {",
            "		/useRulersIn1stQuadrant 0",
            "		/internalName (ai_plugin_Layer)",
            "		/localizedName [ 9",
            "			e8a1a8e7a4ba203a20",
            "		]",
            "		/isOpen 1",
            "		/isOn 1",
            "		/hasDialog 1",
            "		/showDialog 0",
            "		/parameterCount 9",
            "		/parameter-1 {",
            "			/key 1836411236",
            "			/showInPalette 4294967295",
            "			/type (integer)",
            "			/value 4",
            "		}",
            "		/parameter-2 {",
            "			/key 1851878757",
            "			/showInPalette 4294967295",
            "			/type (ustring)",
            "			/value [ 36",
            "				e383ace382a4e383a4e383bce38391e3838de383abe382aae38397e382b7e383",
            "				a7e383b3",
            "			]",
            "		}",
            "		/parameter-3 {",
            "			/key 1953329260",
            "			/showInPalette 4294967295",
            "			/type (boolean)",
            "			/value 1",
            "		}",
            "		/parameter-4 {",
            "			/key 1936224119",
            "			/showInPalette 4294967295",
            "			/type (boolean)",
            "			/value 1",
            "		}",
            "		/parameter-5 {",
            "			/key 1819239275",
            "			/showInPalette 4294967295",
            "			/type (boolean)",
            "			/value 1",
            "		}",
            "		/parameter-6 {",
            "			/key 1886549623",
            "			/showInPalette 4294967295",
            "			/type (boolean)",
            "			/value 1",
            "		}",
            "		/parameter-7 {",
            "			/key 1886547572",
            "			/showInPalette 4294967295",
            "			/type (boolean)",
            "			/value 0",
            "		}",
            "		/parameter-8 {",
            "			/key 1684630830",
            "			/showInPalette 4294967295",
            "			/type (boolean)",
            "			/value 1",
            "		}",
            "		/parameter-9 {",
            "			/key 1885564532",
            "			/showInPalette 4294967295",
            "			/type (unit real)",
            "			/value 50.0",
            "			/unit 592474723",
            "		}",
            "	}",
            "}"
        ].join("\n");
        var tempFile = new File(Folder.temp + "/temp_action.aia");
        tempFile.open("w");
        tempFile.write(actionCode);
        tempFile.close();

        /* 読み込み時点でパース済みなので、ここで一時ファイルを消しておく / The action is parsed on load, so remove the temp file now */
        app.loadAction(tempFile);
        tempFile.remove();

        try {
            app.doScript(actionName, actionSetName);
        } catch (e) {
            alert("エラーが発生しました: " + e);
        } finally {
            app.unloadAction(actionSetName, "");
        }
    }

    // =========================================
    // 単位 / Units
    // =========================================

    /* 単位コードに対応する表示ラベルと、1単位あたりのポイント数
       Unit code -> display label and points per unit */
    var UNITS = [
        { label: "in",    pointsPerUnit: 72 },                /* 0 */
        { label: "mm",    pointsPerUnit: 72 / 25.4 },         /* 1 */
        { label: "pt",    pointsPerUnit: 1 },                 /* 2 */
        { label: "pica",  pointsPerUnit: 12 },                /* 3 */
        { label: "cm",    pointsPerUnit: 72 / 2.54 },         /* 4 */
        { label: "Q",     pointsPerUnit: 72 / 25.4 * 0.25 },  /* 5 */
        { label: "px",    pointsPerUnit: 1 },                 /* 6 */
        { label: "ft/in", pointsPerUnit: 72 * 12 },           /* 7 */
        { label: "m",     pointsPerUnit: 72 / 25.4 * 1000 },  /* 8 */
        { label: "yd",    pointsPerUnit: 72 * 36 },           /* 9 */
        { label: "ft",    pointsPerUnit: 72 * 12 }            /* 10 */
    ];

    /**
     * 環境設定キーの単位を返す
     * @param {string} [prefKey] - "rulerType"（既定）/ "strokeUnits" / "text/units" / "text/asianunits"
     * @returns {{code: number, label: string, pointsPerUnit: number}} 単位の情報
     */
    function getUnitInfo(prefKey) {
        var unitCode = app.preferences.getIntegerPreference(prefKey || "rulerType");
        /* 未知のコードは pt に寄せる / unknown codes fall back to points */
        var unit = UNITS[unitCode] || UNITS[2];
        return { code: unitCode, label: unit.label, pointsPerUnit: unit.pointsPerUnit };
    }

    // CMYK入力欄を作成する共通関数 / Common function to create CMYK input
    function createCMYKInput(parent, label, defaultValue) {
        var group = parent.add("group");
        var lbl = group.add("statictext", undefined, label);
        lbl.preferredSize.width = 20;
        var input = group.add("edittext", undefined, defaultValue);
        input.characters = 4;
        input.preferredSize.width = 40;
        changeValueByArrowKey(input);
        return input;
    }

    // RGB入力欄を作成する共通関数 / Common function to create RGB input
    function createRGBInput(parent, label, defaultValue) {
        var group = parent.add("group");
        var lbl = group.add("statictext", undefined, label);
        lbl.preferredSize.width = 20;
        var input = group.add("edittext", undefined, defaultValue);
        input.characters = 4;
        input.preferredSize.width = 40;
        changeValueByArrowKey(input);
        return input;
    }

    function main() {
        try {
            if (app.documents.length === 0) {
                alert("ドキュメントが開かれていません。");
                return;
            }

            var doc = app.activeDocument;

            /* ダイアログボックスを表示 / Show dialog box */
            var dlg = new Window("dialog", LABELS.dialogTitle[uiLang]);
            dlg.orientation = "column";
            dlg.alignChildren = "left";

            /* --- Two-column color panel (CMYK left, RGB right) --- */
            var colorPanel = dlg.add("panel", undefined, LABELS.colorPanel[uiLang]);
            colorPanel.orientation = "row";
            colorPanel.alignChildren = ["fill", "top"];
            colorPanel.margins = [15, 20, 15, 10];
            colorPanel.spacing = 20;

            var leftCol = colorPanel.add("group");
            leftCol.orientation = "column";
            leftCol.alignChildren = ["left", "top"];

            var rightCol = colorPanel.add("group");
            rightCol.orientation = "column";
            rightCol.alignChildren = ["left", "top"];

            // CMYK inputs
            var cInput = createCMYKInput(leftCol, "C:", "0");
            var mInput = createCMYKInput(leftCol, "M:", "0");
            var yInput = createCMYKInput(leftCol, "Y:", "0");
            var kInput = createCMYKInput(leftCol, "K:", "45");

            // RGB inputs
            var rInput = createRGBInput(rightCol, "R:", "153");
            var gInput = createRGBInput(rightCol, "G:", "153");
            var bInput = createRGBInput(rightCol, "B:", "153");

            // HEX input under RGB
            var hexGroup = rightCol.add("group");
            hexGroup.orientation = "row";
            var hexLabel = hexGroup.add("statictext", undefined, "#");
            hexLabel.preferredSize.width = 20;
            var hexInput = hexGroup.add("edittext", undefined, "999999");
            hexInput.helpTip = LABELS.tipHex[uiLang];
            hexInput.characters = 7;

            // RGBとHEXの連動 / Link RGB and HEX
            rInput.onChanging = function() { updateHexFromRGB(rInput, gInput, bInput, hexInput); };
            gInput.onChanging = function() { updateHexFromRGB(rInput, gInput, bInput, hexInput); };
            bInput.onChanging = function() { updateHexFromRGB(rInput, gInput, bInput, hexInput); };
            hexInput.onChanging = function() { updateRGBFromHex(hexInput, rInput, gInput, bInput); };

            /* カラーモードに応じて項目をディム表示 / Dim inputs depending on document color mode */
            if (doc.documentColorSpace === DocumentColorSpace.CMYK) {
                // Disable RGB inputs
                rInput.enabled = false;
                gInput.enabled = false;
                bInput.enabled = false;
                hexInput.enabled = false;
                // Keep CMYK inputs active
                if (cInput) cInput.enabled = true;
                if (mInput) mInput.enabled = true;
                if (yInput) yInput.enabled = true;
                if (kInput) kInput.enabled = true;
            } else {
                // Disable CMYK inputs (dim but still visible)
                if (cInput) cInput.enabled = false;
                if (mInput) mInput.enabled = false;
                if (yInput) yInput.enabled = false;
                if (kInput) kInput.enabled = false;
                // Keep RGB inputs active
                rInput.enabled = true;
                gInput.enabled = true;
                bInput.enabled = true;
                hexInput.enabled = true;
            }

            var marginGroup = dlg.add("group");
            marginGroup.orientation = "row";

            marginGroup.add("statictext", undefined, labelText("marginLabel"));
            var marginInput = marginGroup.add("edittext", undefined, "0");
            marginInput.helpTip = LABELS.tipMargin[uiLang];
            marginInput.characters = 4;
            var unitLabel = marginGroup.add("statictext", undefined, getUnitInfo().label);

            changeValueByArrowKey(marginInput);

            var templateCheckbox = dlg.add("checkbox", undefined, LABELS.templateCheckbox[uiLang]);
            templateCheckbox.helpTip = LABELS.tipTemplate[uiLang];
            templateCheckbox.value = true; // デフォルトでON

            var btnGroup = dlg.add("group");
            btnGroup.orientation = "row";
            btnGroup.alignment = "center"; // 中央揃え / Center alignment

            var cancelBtn = btnGroup.add("button", undefined, LABELS.cancelButton[uiLang], {name:"cancel"});
            var okBtn = btnGroup.add("button", undefined, LABELS.okButton[uiLang], {name:"ok"});

            if (dlg.show() != 1) {
                return; // キャンセル時は終了
            }

            var margin = parseFloat(marginInput.text) || 0;
            var setAsTemplate = templateCheckbox.value;

            var abIndex = doc.artboards.getActiveArtboardIndex();
            var ab = doc.artboards[abIndex];
            var rect = ab.artboardRect; // [left, top, right, bottom]

            /* 「bg-template」レイヤーを再作成 / Recreate "bg-template" layer */
            var bgLayer;
            var existingLayer = null;
            try {
                existingLayer = doc.layers.getByName("bg-template");
            } catch (e) {}

            if (existingLayer) {
                existingLayer.locked = false; // 既存レイヤーをロック解除
                existingLayer.remove();       // 既存レイヤーを削除
            }

            bgLayer = doc.layers.add();
            bgLayer.name = "bg-template";

            /* 長方形を作成 / Create rectangle */
            var newRect = bgLayer.pathItems.rectangle(
                rect[1] + margin, // top expands with positive margin
                rect[0] - margin, // left expands with positive margin
                (rect[2] - rect[0]) + (margin * 2), // width expands with positive margin
                (rect[1] - rect[3]) + (margin * 2)  // height expands with positive margin
            );

            /* 塗り色を設定 / Set fill color */
            if (doc.documentColorSpace === DocumentColorSpace.CMYK) {
                var c = parseFloat(cInput.text) || 0;
                var m = parseFloat(mInput.text) || 0;
                var y = parseFloat(yInput.text) || 0;
                var k = parseFloat(kInput.text) || 0;
                var fillColor = new CMYKColor();
                fillColor.cyan = c;
                fillColor.magenta = m;
                fillColor.yellow = y;
                fillColor.black = k;
                newRect.fillColor = fillColor;
            } else {
                var rgbColor = new RGBColor();
                var hexValue = hexInput.text;
                var cleanHex = hexValue.replace(/^#/, ""); // 先頭の#を削除
                if (/^[0-9A-Fa-f]{6}$/.test(cleanHex)) {
                    rgbColor.red = parseInt(cleanHex.substr(0, 2), 16);
                    rgbColor.green = parseInt(cleanHex.substr(2, 2), 16);
                    rgbColor.blue = parseInt(cleanHex.substr(4, 2), 16);
                } else {
                    var r = parseFloat(rInput.text) || 0;
                    var g = parseFloat(gInput.text) || 0;
                    var b = parseFloat(bInput.text) || 0;
                    rgbColor.red = r;
                    rgbColor.green = g;
                    rgbColor.blue = b;
                }
                newRect.fillColor = rgbColor;
            }
            newRect.filled = true;
            newRect.stroked = false;

            if (setAsTemplate) {
                /* テンプレートレイヤーに設定（アクションを使用）/ Set as template layer (using action) */
                act_setLayTmplAttr();
            }

            /* 一時的にロック解除 / Temporarily unlock */
            bgLayer.locked = false;
            /* 最背面に移動 / Send to back */
            bgLayer.zOrder(ZOrderMethod.SENDTOBACK);

    bgLayer.name = "bg-template";

            bgLayer.locked = true;

        } catch (e) {
            alert("エラーが発生しました: " + e);
        }
    }

    main();

})();
