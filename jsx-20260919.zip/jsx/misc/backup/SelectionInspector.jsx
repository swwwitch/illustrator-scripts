#target illustrator
app.preferences.setBooleanPreference('ShowExternalJSXWarning', false);
#targetengine "SelectionInspectorSession"

/*

### スクリプト名：

SelectionInspector.jsx

### GitHub：

https://github.com/swwwitch/illustrator-scripts/blob/master/jsx/misc/SelectionInspector.jsx

### 概要：

- 選択中／全体のオブジェクト数をカウントし、2カラムのダイアログで表示
- テキスト・配置画像・透明・グループ・パス・ガイドの統計を表示
- 「書き出し」でレポート（テキスト）を書き出し可能
- UIと書き出しテキストの文言をローカライズ辞書で一元管理

### 主な機能：

- オブジェクト数（選択／全体）・アートボード数を表示
- テキスト（ポイント／エリア／パス上）・文字数・段落数・強制改行数を表示
- 配置画像（リンク／埋め込み／リンク切れ）を表示
- 透明（不透明度<100、描画モード≠通常）を表示
- グループ／クリップグループを表示
- パス（オープン／クローズ／アンカー／ハンドル／複合パス／複合シェイプ）を表示
  ※ ガイド（guides=true）はパス統計から除外
- ガイド（ルーラー／アートボード／その他）を表示
- 「書き出し」ボタンで集計結果をテキストファイルとして保存

### 処理の流れ：

- ドキュメントと選択オブジェクトを解析し、各種情報を取得
- ダイアログに2カラムで情報を整然と表示
- 書き出し機能でデスクトップにテキスト保存


### note：

https://note.com/dtp_tranist/n/nefcb1ce828ce

### 更新履歴：

- v1.0 (20250806) : 初期バージョン
- v1.1 (20250806) : 書き出し機能を追加
- v1.2 (20250807) : UI調整
- v1.3 (20260301) : パスのハンドル数を追加
- v1.4 (20260301) : 強制改行（ソフトリターン）数を追加
- v1.4.1 (20260302) : UI調整（OK→閉じる、キャンセル削除、書き出しを左へ移動）
- v1.5 (20260302) : ガイド集計（ルーラー/アートボード/その他）、ガイド除外のパス統計、パネル配置と書き出しレイアウト更新
- v1.5.1 (20260312) : グループ内のパス統計を再帰的にカウント
- v1.5.2 (20260312) : グループ内のテキスト統計を再帰的にカウント
- v1.5.3 (20260314) : ダイアログ位置をセッション中に記憶・復元
- v1.6 (20260316) : 配置画像の下にメモパネルを追加（属性パネルのメモ欄を表示）
- v1.6.1 (20260316) : ローカライズ整理（書き出し文言・セクション見出しをLABELSへ集約）

---

### Script Name:

SelectionInspector.jsx

### GitHub:

https://github.com/swwwitch/illustrator-scripts/blob/master/jsx/misc/SelectionInspector.jsx

### Overview:

- Count selection / document totals and show them in a two-column dialog
- Show stats for text, images, transparency, groups, paths, and guides
- Export the stats as a plain text report
- Centralize UI and export strings in the localization dictionary

### Main Features:

- Show object counts (Selection / All) and artboard count
- Text stats: point/area/path text, characters, paragraphs, forced line breaks
- Image stats: linked/embedded/broken links
- Transparency stats: opacity < 100, blend mode ≠ Normal
- Group stats: groups and clipping groups
- Path stats: open/closed, anchor points, handles, compound paths, compound shapes
  * Guide paths (guides=true) are excluded from path stats
- Guide breakdown: ruler / artboard / other
- Export button writes a plain text report to the desktop

### Process Flow:

- Analyze document and selected objects
- Display data in a two-column dialog UI
- Export stats to desktop text file

### Changelog:

- v1.0 (20250806): Initial version
- v1.1 (20250806): Added export feature
- v1.2 (20250807): UI adjustments
- v1.3 (20260301): Added handle count for paths
- v1.4 (20260301): Added forced line break (soft return) count
- v1.4.1 (20260302): UI tweaks (OK→Close, removed Cancel, moved Export to left)
- v1.5 (20260302): Added guide breakdown (ruler/artboard/other), excluded guides from path stats, updated panel arrangement and export layout
- v1.5.1 (20260312): Recursively count path stats inside groups
- v1.5.2 (20260312): Recursively count text stats inside groups
- v1.5.3 (20260314): Remember and restore dialog position during the current session
- v1.6 (20260316): Added Notes panel below Images (shows Attributes panel note field)
- v1.6.1 (20260316): Localization cleanup (moved export strings and section headers into LABELS)

*/

var SCRIPT_VERSION = "v1.6.2";

function getCurrentLang() {
    return ($.locale.indexOf("ja") === 0) ? "ja" : "en";
}
var lang = getCurrentLang();

/* 日英ラベル定義 / Japanese-English label definitions */
var LABELS = {
    dialogTitle: {
        ja: "選択／全体オブジェクトのカウント " + SCRIPT_VERSION,
        en: "Selection / All Objects Count " + SCRIPT_VERSION
    },
    reportTitle: {
        ja: "Selection Inspector Report",
        en: "Selection Inspector Report"
    },
    reportDocument: {
        ja: "ドキュメント:",
        en: "Document:"
    },
    reportDate: {
        ja: "日付:",
        en: "Date:"
    },
    reportValueNote: {
        ja: "※ 値は『選択 / 全体』の形式です（アートボードのみ全体）",
        en: "Note: values are formatted as 'Selection / All' (Artboards is All only)"
    },
    sectionBasics: {
        ja: "基本",
        en: "Basics"
    },
    sectionTextFrames: {
        ja: "テキスト",
        en: "Text Frames"
    },
    sectionCharPara: {
        ja: "文字・段落",
        en: "Characters & Paragraphs"
    },
    sectionImages: {
        ja: "配置画像",
        en: "Images"
    },
    sectionNotes: {
        ja: "メモ",
        en: "Notes"
    },
    sectionTransparency: {
        ja: "透明",
        en: "Transparency"
    },
    sectionGroups: {
        ja: "グループ",
        en: "Groups"
    },
    sectionPaths: {
        ja: "パス",
        en: "Paths"
    },
    sectionGuides: {
        ja: "ガイド",
        en: "Guides"
    },
    other: {
        ja: "基本",
        en: "Basics"
    },
    artboards: {
        ja: "アートボード：",
        en: "Artboards:"
    },
    objects: {
        ja: "オブジェクト：",
        en: "Objects:"
    },
    charPara: {
        ja: "文字・段落",
        en: "Characters & Paragraphs"
    },
    transparency: {
        ja: "透明",
        en: "Transparency"
    },
    chars: {
        ja: "文字数：",
        en: "Characters:"
    },
    paras: {
        ja: "段落数：",
        en: "Paragraphs:"
    },
    forcedBreaks: {
        ja: "強制改行：",
        en: "Line Breaks:"
    },
    opacityLt100: {
        ja: "不透明度<100：",
        en: "Opacity < 100:"
    },
    blendNotNormal: {
        ja: "描画モード≠通常：",
        en: "Blend Mode ≠ Normal:"
    },
    texts: {
        ja: "テキスト：",
        en: "Text Frames:"
    },
    pointText: {
        ja: "ポイント文字：",
        en: "Point Type:"
    },
    areaText: {
        ja: "エリア内文字：",
        en: "Area Type:"
    },
    pathText: {
        ja: "パス上文字：",
        en: "Path Text:"
    },
    link: {
        ja: "配置画像",
        en: "Images"
    },
    images: {
        ja: "配置画像",
        en: "Images"
    },
    linked: {
        ja: "リンク：",
        en: "Linked Images:"
    },
    embed: {
        ja: "埋め込み：",
        en: "Embedded Images:"
    },
    broken: {
        ja: "リンク切れ：",
        en: "Broken Links:"
    },
    group: {
        ja: "グループ：",
        en: "Groups:"
    },
    clipGroup: {
        ja: "クリップグループ：",
        en: "Clipping Groups:"
    },
    path: {
        ja: "パス",
        en: "Paths"
    },
    guide: {
        ja: "ガイド",
        en: "Guides"
    },
    rulerGuides: {
        ja: "ルーラーガイド：",
        en: "Ruler Guides:"
    },
    artboardGuides: {
        ja: "アートボードガイド：",
        en: "Artboard Guides:"
    },
    otherGuides: {
        ja: "その他のガイド：",
        en: "Other Guides:"
    },
    pathCount: {
        ja: "パス：",
        en: "Paths:"
    },
    openPath: {
        ja: "オープンパス：",
        en: "Open Paths:"
    },
    closedPath: {
        ja: "クローズパス：",
        en: "Closed Paths:"
    },
    anchors: {
        ja: "アンカーポイント：",
        en: "Anchor Points:"
    },
    handles: {
        ja: "ハンドル：",
        en: "Handles:"
    },
    compoundPath: {
        ja: "複合パス：",
        en: "Compound Paths:"
    },
    compoundShape: {
        ja: "複合シェイプ：",
        en: "Compound Shapes:"
    },
    ok: {
        ja: "閉じる",
        en: "Close"
    },
    exportPreset: {
        ja: "書き出し",
        en: "Export"
    },
    applyMemo: {
        ja: "適用",
        en: "Apply"
    },
    tabCount: {
        ja: "情報",
        en: "Info"
    },
    tabMemo: {
        ja: "メモ",
        en: "Notes"
    },
    multipleMemosMsg: {
        ja: "複数のメモがあります。\n「メモ」タブで確認",
        en: "Multiple notes found.\nSee the \"Notes\" tab."
    },
    memo: {
        ja: "メモ",
        en: "Notes"
    },
    memoText: {
        ja: "メモ：",
        en: "Note:"
    },
    shortcutHint: {
        ja: "⌥I: 情報  ⌥M: メモ",
        en: "⌥I: Info  ⌥M: Notes"
    }
};

var __selectionInspectorDialogState = {
    location: null
};

function main() {
    try {
        /* 選択オブジェクトを取得 / Get selected objects */
        var sel = app.activeDocument.selection;

        /* 選択がない場合の処理 / Handle case with no selection */
        if (!sel) {
            sel = [];
        }

        /* 選択数をカウント / Count selected objects */
        var count = sel.length;

        /* ドキュメント全体のオブジェクト数をカウント / Count all objects in document */
        var allCount = 0;

        function countAllObjects(items) {
            for (var i = 0; i < items.length; i++) {
                var it = items[i];
                allCount++;
                if (it.typename === "GroupItem") {
                    countAllObjects(it.pageItems);
                } else if (it.typename === "CompoundPathItem") {
                    countAllObjects(it.pathItems);
                }
            }
        }
        countAllObjects(app.activeDocument.pageItems);

        /* 種類ごとのカウント（選択と全体） / Count by type (selected and all) */
        var pathCountSel = 0,
            pathCountAll = 0;
        var anchorCountSel = 0,
            anchorCountAll = 0;
        var handleCountSel = 0,
            handleCountAll = 0;
        var compoundPathSel = 0,
            compoundPathAll = 0;
        var compoundShapeSel = 0,
            compoundShapeAll = 0;

        // ガイド（ルーラーガイド／アートボードガイド／その他のガイド）
        // Guides (ruler / artboard / other)
        var rulerGuideSel = 0,
            rulerGuideAll = 0;
        var artboardGuideSel = 0,
            artboardGuideAll = 0;
        var otherGuideSel = 0,
            otherGuideAll = 0;

        function __getMaxArtboardSpan(doc) {
            // Returns max(width, height) among all artboards (in points)
            var maxSpan = 0;
            try {
                var abs = Math.abs;
                var ab = doc.artboards;
                for (var i = 0; i < ab.length; i++) {
                    var r = ab[i].artboardRect; // [left, top, right, bottom]
                    var w = abs(r[2] - r[0]);
                    var h = abs(r[1] - r[3]);
                    if (w > maxSpan) maxSpan = w;
                    if (h > maxSpan) maxSpan = h;
                }
            } catch (e) { }
            return maxSpan;
        }

        function __isArtboardGuidePathItem(pi, doc) {
            // Artboard guide definition:
            // - guide path (pi.guides)
            // - open path
            // - exactly 2 points
            // - horizontal OR vertical
            // - line length approximately equals width OR height of ANY artboard
            try {
                if (!pi || pi.typename !== "PathItem") return false;
                if (!pi.guides) return false;
                if (pi.closed) return false;
                if (!pi.pathPoints || pi.pathPoints.length !== 2) return false;

                var a0 = pi.pathPoints[0].anchor;
                var a1 = pi.pathPoints[1].anchor;
                var T = 0.01;
                var sameX = Math.abs(a0[0] - a1[0]) <= T;
                var sameY = Math.abs(a0[1] - a1[1]) <= T;
                if (!(sameX || sameY)) return false;

                var dx = a0[0] - a1[0];
                var dy = a0[1] - a1[1];
                var len = Math.sqrt(dx * dx + dy * dy);

                // Compare against every artboard
                var abs = Math.abs;
                var tol = 0.5; // pt tolerance (rounding / pixel alignment)
                var ab = doc.artboards;
                for (var i = 0; i < ab.length; i++) {
                    var r = ab[i].artboardRect; // [left, top, right, bottom]
                    var w = abs(r[2] - r[0]);
                    var h = abs(r[1] - r[3]);
                    if (abs(len - w) <= tol) return true;
                    if (abs(len - h) <= tol) return true;
                }
                return false;
            } catch (e) {
                return false;
            }
        }

        function __isRulerGuidePathItem(pi) {
            // Best-effort heuristic:
            // Ruler guides are typically a long straight horizontal/vertical open line.
            // Here we treat it as:
            // - guide path (pi.guides)
            // - open path
            // - exactly 2 points
            // - horizontal OR vertical
            // - line length is longer than the artboard width or height
            try {
                if (!pi || pi.typename !== "PathItem") return false;
                if (!pi.guides) return false;
                if (pi.closed) return false;
                if (!pi.pathPoints || pi.pathPoints.length !== 2) return false;

                var a0 = pi.pathPoints[0].anchor;
                var a1 = pi.pathPoints[1].anchor;
                var T = 0.01;

                var sameX = Math.abs(a0[0] - a1[0]) <= T;
                var sameY = Math.abs(a0[1] - a1[1]) <= T;
                if (!(sameX || sameY)) return false;

                var dx = a0[0] - a1[0];
                var dy = a0[1] - a1[1];
                var len = Math.sqrt(dx * dx + dy * dy);

                var maxSpan = __getMaxArtboardSpan(app.activeDocument);
                // If artboard span cannot be obtained, fall back to old behavior (treat as ruler guide)
                if (!(maxSpan > 0)) return true;

                return (len > maxSpan);
            } catch (e) {
                return false;
            }
        }

        function __countGuidesForPathItem(pi) {
            // returns { ruler:0/1, artboard:0/1, other:0/1 }
            var r = { ruler: 0, artboard: 0, other: 0 };
            try {
                if (!pi || pi.typename !== "PathItem") return r;
                if (!pi.guides) return r;

                // Priority:
                // 1) Ruler guide (longer than max artboard span)
                // 2) Artboard guide (matches any artboard width/height)
                // 3) Other guide
                if (__isRulerGuidePathItem(pi)) {
                    r.ruler = 1;
                } else if (__isArtboardGuidePathItem(pi, app.activeDocument)) {
                    r.artboard = 1;
                } else {
                    r.other = 1;
                }
            } catch (e) { }
            return r;
        }

        // 透明（不透明度<100／描画モード≠通常）/ Transparency stats
        var opacityLt100Sel = 0,
            opacityLt100All = 0;
        var blendNotNormalSel = 0,
            blendNotNormalAll = 0;

        function countTransparencyForItem(it) {
            var r = { opacityLt100: 0, blendNotNormal: 0 };
            if (!it) return r;

            try {
                if (typeof it.opacity === "number" && it.opacity < 100) r.opacityLt100 = 1;
            } catch (e) { }

            try {
                if (it.blendingMode !== undefined && it.blendingMode !== BlendModes.NORMAL) r.blendNotNormal = 1;
            } catch (e) { }

            return r;
        }

        function __isGuidePathItem(pi) {
            try {
                return (pi && pi.typename === "PathItem" && pi.guides === true);
            } catch (e) {
                return false;
            }
        }

        function countHandlesInPathItem(pi) {
            // Count bezier handles: left/right direction differs from anchor
            // A corner point typically has both directions == anchor => 0
            // A smooth/curve point often has 2 handles
            var c = 0;
            try {
                var pts = pi.pathPoints;
                for (var i = 0; i < pts.length; i++) {
                    var p = pts[i];
                    var a = p.anchor;
                    var l = p.leftDirection;
                    var r = p.rightDirection;
                    if (l[0] !== a[0] || l[1] !== a[1]) c++;
                    if (r[0] !== a[0] || r[1] !== a[1]) c++;
                }
            } catch (e) { }
            return c;
        }

        /* アイテムのパス統計を再帰的にカウント / Recursively count path stats for an item */
        function countPathStatsForItem(it, stats) {
            if (it.typename === "GroupItem") {
                for (var gi = 0; gi < it.pageItems.length; gi++) {
                    countPathStatsForItem(it.pageItems[gi], stats);
                }
            } else if (it.typename === "PathItem") {
                if (!__isGuidePathItem(it)) {
                    stats.pathCount++;
                    stats.anchorCount += it.pathPoints.length;
                    stats.handleCount += countHandlesInPathItem(it);
                    if (it.closed) {
                        stats.closedPath++;
                    } else {
                        stats.openPath++;
                    }
                }
            } else if (it.typename === "CompoundPathItem") {
                for (var ci = 0; ci < it.pathItems.length; ci++) {
                    if (__isGuidePathItem(it.pathItems[ci])) continue;
                    stats.pathCount++;
                    stats.anchorCount += it.pathItems[ci].pathPoints.length;
                    stats.handleCount += countHandlesInPathItem(it.pathItems[ci]);
                    if (it.pathItems[ci].closed) {
                        stats.closedPath++;
                    } else {
                        stats.openPath++;
                    }
                }
            }
        }

        // 強制改行（ソフトリターン）をカウント / Count forced line breaks (soft returns)
        // 段落改行（\r）は除外し、\u0003 / \n / \u2028 を強制改行として数える
        function countForcedBreaksFromContents(s) {
            if (!s || !s.length) return 0;
            var m = s.match(/[\u0003\n\u2028]/g);
            return m ? m.length : 0;
        }

        /* アイテムのテキスト統計を再帰的にカウント / Recursively count text stats for an item */
        function countTextStatsForItem(it, stats) {
            if (it.typename === "GroupItem") {
                for (var gi = 0; gi < it.pageItems.length; gi++) {
                    countTextStatsForItem(it.pageItems[gi], stats);
                }
            } else if (it.typename === "TextFrame") {
                stats.textCount++;
                try { stats.charCount += it.characters.length; } catch (e) { }
                try { stats.paraCount += it.paragraphs.length; } catch (e) { }
                try { stats.forcedBreakCount += countForcedBreaksFromContents(it.contents); } catch (e) { }
                if (it.kind === TextType.POINTTEXT) {
                    stats.pointText++;
                } else if (it.kind === TextType.AREATEXT) {
                    stats.areaText++;
                } else if (it.kind === TextType.PATHTEXT) {
                    stats.pathText++;
                }
            }
        }

        /* 選択分をカウント / Count selected items */
        for (var i = 0; i < sel.length; i++) {
            // CompoundPath/CompoundShape
            if (sel[i].typename === "CompoundPathItem") {
                compoundPathSel++;
            }
            if (sel[i].typename === "PluginItem") {
                // 複合シェイプ（ライブパスファインダー）
                try {
                    if (sel[i].name && sel[i].name.indexOf("Compound Shape") !== -1) {
                        compoundShapeSel++;
                    }
                } catch (e) { }
            }
            // 透明（選択）/ Transparency (selected)
            try {
                var t0 = countTransparencyForItem(sel[i]);
                opacityLt100Sel += t0.opacityLt100;
                blendNotNormalSel += t0.blendNotNormal;
            } catch (e) { }

            // ガイド（選択）/ Guides (selected)
            try {
                if (sel[i].typename === "PathItem") {
                    var g0 = __countGuidesForPathItem(sel[i]);
                    rulerGuideSel += g0.ruler;
                    artboardGuideSel += g0.artboard;
                    otherGuideSel += g0.other;
                } else if (sel[i].typename === "CompoundPathItem") {
                    for (var gg = 0; gg < sel[i].pathItems.length; gg++) {
                        var g1 = __countGuidesForPathItem(sel[i].pathItems[gg]);
                        rulerGuideSel += g1.ruler;
                        artboardGuideSel += g1.artboard;
                        otherGuideSel += g1.other;
                    }
                }
            } catch (e) { }
        }

        // パス統計（選択）- グループ内も再帰的にカウント
        // Path stats (selected) - recursively count inside groups
        var pathStatsSel = { pathCount: 0, anchorCount: 0, handleCount: 0, openPath: 0, closedPath: 0 };
        for (var i = 0; i < sel.length; i++) {
            countPathStatsForItem(sel[i], pathStatsSel);
        }
        pathCountSel = pathStatsSel.pathCount;
        anchorCountSel = pathStatsSel.anchorCount;
        handleCountSel = pathStatsSel.handleCount;

        /* 全体をカウント / Count all items */
        var allItems = app.activeDocument.pageItems;
        for (var k = 0; k < allItems.length; k++) {
            var obj = allItems[k];

            if (obj.typename === "CompoundPathItem") {
                compoundPathAll++;
            }
            if (obj.typename === "PluginItem") {
                try {
                    if (obj.name && obj.name.indexOf("Compound Shape") !== -1) {
                        compoundShapeAll++;
                    }
                } catch (e) { }
            }

            // 透明（全体）/ Transparency (all)
            try {
                var tAll = countTransparencyForItem(obj);
                opacityLt100All += tAll.opacityLt100;
                blendNotNormalAll += tAll.blendNotNormal;
            } catch (e) { }

            // ガイド（全体）/ Guides (all)
            try {
                if (obj.typename === "PathItem") {
                    var gAll0 = __countGuidesForPathItem(obj);
                    rulerGuideAll += gAll0.ruler;
                    artboardGuideAll += gAll0.artboard;
                    otherGuideAll += gAll0.other;
                } else if (obj.typename === "CompoundPathItem") {
                    for (var gg2 = 0; gg2 < obj.pathItems.length; gg2++) {
                        var gAll1 = __countGuidesForPathItem(obj.pathItems[gg2]);
                        rulerGuideAll += gAll1.ruler;
                        artboardGuideAll += gAll1.artboard;
                        otherGuideAll += gAll1.other;
                    }
                }
            } catch (e) { }
        }

        // パス統計（全体）- グループ内も再帰的にカウント
        // Path stats (all) - recursively count inside groups
        var pathStatsAll = { pathCount: 0, anchorCount: 0, handleCount: 0, openPath: 0, closedPath: 0 };
        for (var k = 0; k < allItems.length; k++) {
            countPathStatsForItem(allItems[k], pathStatsAll);
        }
        pathCountAll = pathStatsAll.pathCount;
        anchorCountAll = pathStatsAll.anchorCount;
        handleCountAll = pathStatsAll.handleCount;

        /* 結果を表示（ダイアログボックス） / Display results (dialog box) */
        var dlg = new Window("dialog", LABELS.dialogTitle[lang]);
        dlg.orientation = "column";
        dlg.alignChildren = "center";
        dlg.margins = [15, 0, 15, 20];

        var LABEL_WIDTH = 130; /* 全ラベルの幅を統一 / Set uniform label width */
        var LABEL_WIDTH_LEFT = 100; /* 左カラムのラベル幅 / Label width for left column */
        var LABEL_WIDTH_TOP = 90; // オブジェクト・アートボード数専用ラベル幅
        var LABEL_WIDTH_RIGHT = 140; /* 右カラムのラベル幅 / Label width for right column */

        /* ラベルと値を2カラムで表示 / Display label and value in two columns */
        var group = dlg.add("group");
        group.orientation = "column";
        group.alignChildren = ["fill", "top"];

        // addRow: ラベル、値、カスタム幅（省略可） / label, value, customWidth (optional)
        function addRow(labelText, valueText, customWidth) {
            var g = group.add("group");
            g.orientation = "row";
            var label = g.add("statictext", undefined, labelText);
            label.justify = "right";
            label.preferredSize.width = (customWidth !== undefined) ? customWidth : LABEL_WIDTH;
            g.add("statictext", undefined, valueText);
        }

        var totalObjSel = count;
        var totalObjAll = allCount;
        var artboardCount = app.activeDocument.artboards.length;

        // 表示切り替え（ラジオボタン＋stack） / View switcher (radio buttons + stack)
        var switchRow = dlg.add("group");
        switchRow.orientation = "row";
        switchRow.alignChildren = ["center", "center"];
        switchRow.alignment = ["center", "top"];
        switchRow.helpTip = LABELS.shortcutHint[lang];

        var rbInfo = switchRow.add("radiobutton", undefined, LABELS.tabCount[lang]);
        var rbMemo = switchRow.add("radiobutton", undefined, LABELS.tabMemo[lang]);
        rbInfo.helpTip = LABELS.shortcutHint[lang];
        rbMemo.helpTip = LABELS.shortcutHint[lang];
        rbInfo.value = true;

        var stackWrap = dlg.add("group");
        stackWrap.orientation = "stack";
        stackWrap.alignChildren = ["fill", "fill"];

        var tab1 = stackWrap.add("group");
        tab1.orientation = "column";
        tab1.alignChildren = ["fill", "top"];
        tab1.margins = [10, 15, 10, 10];

        var tab2 = stackWrap.add("group");
        tab2.orientation = "column";
        tab2.alignChildren = ["fill", "top"];
        tab2.margins = [10, 15, 10, 10];
        tab2.visible = false;

        function switchView(mode) {
            var showInfo = (mode === "info");
            rbInfo.value = showInfo;
            rbMemo.value = !showInfo;
            tab1.visible = showInfo;
            tab2.visible = !showInfo;

            try {
                if (stackWrap && stackWrap.layout && stackWrap.layout.layout) {
                    stackWrap.layout.layout(true);
                }
            } catch (e) { }

            try {
                if (dlg && dlg.layout && dlg.layout.layout) {
                    dlg.layout.layout(true);
                }
            } catch (e2) { }
        }

        // 2カラムのグループ / Two-column group
        var twoColGroup = tab1.add("group");
        twoColGroup.orientation = "row";
        twoColGroup.alignChildren = ["fill", "top"];

        // 左カラム
        var leftCol = twoColGroup.add("group");
        leftCol.orientation = "column";
        leftCol.alignChildren = ["fill", "top"];

        /* その他の詳細を表示するパネル / Panel to display other details */
        var panelOther = leftCol.add("panel", undefined, LABELS.other[lang]);
        panelOther.orientation = "column";
        panelOther.alignChildren = ["fill", "top"];
        panelOther.margins = [15, 20, 0, 10];

        function addOtherRow(label, value) {
            var row = panelOther.add("group");
            row.orientation = "row";
            var lbl = row.add("statictext", [0, 0, LABEL_WIDTH_LEFT, 20], label);
            lbl.justify = "right";
            var val = row.add("statictext", undefined, value);
            val.characters = value.length;
        }

        addOtherRow(LABELS.artboards[lang], artboardCount.toString());
        addOtherRow(LABELS.objects[lang], totalObjSel + " / " + totalObjAll);

        /* テキストの詳細を表示するパネル / Panel to display text details */
        var panelText = leftCol.add("panel", undefined, LABELS.texts[lang]);
        panelText.orientation = "column";
        panelText.alignChildren = ["fill", "top"];
        panelText.margins = [15, 20, 0, 10];

        /* 文字・段落の詳細を表示するパネル / Panel to display character and paragraph details */
        var panelCharPara = leftCol.add("panel", undefined, LABELS.charPara[lang]);
        panelCharPara.orientation = "column";
        panelCharPara.alignChildren = ["fill", "top"];
        panelCharPara.margins = [15, 20, 0, 10];


        function addCharParaRow(label, value) {
            var row = panelCharPara.add("group");
            row.orientation = "row";
            var lbl = row.add("statictext", [0, 0, LABEL_WIDTH_LEFT, 20], label);
            lbl.justify = "right";
            var val = row.add("statictext", undefined, value);
            val.characters = value.length;
        }

        // テキスト統計（選択）- グループ内も再帰的にカウント
        // Text stats (selected) - recursively count inside groups
        var textStatsSel = { textCount: 0, charCount: 0, paraCount: 0, forcedBreakCount: 0, pointText: 0, areaText: 0, pathText: 0 };
        for (var i = 0; i < sel.length; i++) {
            countTextStatsForItem(sel[i], textStatsSel);
        }
        var textCountSel = textStatsSel.textCount;
        var totalCharSel = textStatsSel.charCount;
        var paraCountSel = textStatsSel.paraCount;
        var forcedBreakSel = textStatsSel.forcedBreakCount;
        var pointTextSel = textStatsSel.pointText;
        var areaTextSel = textStatsSel.areaText;
        var pathTextSel = textStatsSel.pathText;

        // テキスト統計（全体）- グループ内も再帰的にカウント
        // Text stats (all) - recursively count inside groups
        var textStatsAll = { textCount: 0, charCount: 0, paraCount: 0, forcedBreakCount: 0, pointText: 0, areaText: 0, pathText: 0 };
        for (var k = 0; k < allItems.length; k++) {
            countTextStatsForItem(allItems[k], textStatsAll);
        }
        var textCountAll = textStatsAll.textCount;
        var totalCharAll = textStatsAll.charCount;
        var paraCountAll = textStatsAll.paraCount;
        var forcedBreakAll = textStatsAll.forcedBreakCount;
        var pointTextAll = textStatsAll.pointText;
        var areaTextAll = textStatsAll.areaText;
        var pathTextAll = textStatsAll.pathText;

        function addTextRow(label, value) {
            var row = panelText.add("group");
            row.orientation = "row";
            var lbl = row.add("statictext", [0, 0, LABEL_WIDTH_LEFT, 20], label);
            lbl.justify = "right";
            var val = row.add("statictext", undefined, value);
            val.characters = value.length;
        }

        addCharParaRow(LABELS.chars[lang], totalCharSel + " / " + totalCharAll);
        addCharParaRow(LABELS.paras[lang], paraCountSel + " / " + paraCountAll);
        addCharParaRow(LABELS.forcedBreaks[lang], forcedBreakSel + " / " + forcedBreakAll);
        addTextRow(LABELS.texts[lang], textCountSel + " / " + textCountAll);
        addTextRow(LABELS.pointText[lang], pointTextSel + " / " + pointTextAll);
        addTextRow(LABELS.areaText[lang], areaTextSel + " / " + areaTextAll);
        addTextRow(LABELS.pathText[lang], pathTextSel + " / " + pathTextAll);

        // 右カラム
        var rightCol = twoColGroup.add("group");
        rightCol.orientation = "column";
        rightCol.alignChildren = ["fill", "top"];


        /* 画像の詳細を表示するパネル / Panel to display image details */
        var panelImage = leftCol.add("panel", undefined, LABELS.images[lang]);
        panelImage.orientation = "column";
        panelImage.alignChildren = ["fill", "top"];
        panelImage.margins = [15, 20, 0, 10];

        var linkedSel = 0,
            linkedAll = 0;
        var embeddedSel = 0,
            embeddedAll = 0;
        var brokenLinkSel = 0,
            brokenLinkAll = 0;
        var memoTextsSel = [];

        /* 選択オブジェクト / Selected objects */
        for (var i = 0; i < sel.length; i++) {
            if (sel[i].typename === "PlacedItem") {
                if (sel[i].embedded) {
                    embeddedSel++;
                } else {
                    linkedSel++;
                    try {
                        var f = sel[i].file;
                        if (!f || !f.exists) {
                            brokenLinkSel++;
                        }
                    } catch (err) {
                        brokenLinkSel++;
                    }
                }
            }
            try {
                if (sel[i].note && sel[i].note !== "") {
                    memoTextsSel.push(sel[i].note);
                }
            } catch (e) { }
        }

        /* 全体 / All objects */
        for (var k = 0; k < allItems.length; k++) {
            var obj = allItems[k];
            if (obj.typename === "PlacedItem") {
                if (obj.embedded) {
                    embeddedAll++;
                } else {
                    linkedAll++;
                    try {
                        var fAll = obj.file;
                        if (!fAll || !fAll.exists) {
                            brokenLinkAll++;
                        }
                    } catch (err) {
                        brokenLinkAll++;
                    }
                }
            }
        }

        function addImageRow(label, value) {
            var row = panelImage.add("group");
            row.orientation = "row";
            var lbl = row.add("statictext", [0, 0, LABEL_WIDTH_LEFT, 20], label);
            lbl.justify = "right";
            var val = row.add("statictext", undefined, value);
            val.characters = value.length;
        }

        addImageRow(LABELS.linked[lang], linkedSel + " / " + linkedAll);
        addImageRow(LABELS.embed[lang], embeddedSel + " / " + embeddedAll);
        addImageRow(LABELS.broken[lang], brokenLinkSel + " / " + brokenLinkAll);

        /* メモパネル（表示のみ）/ Memo panel (read-only) */
        var panelMemo = leftCol.add("panel", undefined, LABELS.memo[lang]);
        panelMemo.orientation = "column";
        panelMemo.alignChildren = ["fill", "top"];
        panelMemo.margins = [15, 20, 0, 10];
        var memoTab1Text = memoTextsSel.length === 1 ? memoTextsSel[0] : (memoTextsSel.length > 1 ? LABELS.multipleMemosMsg[lang] : "");
        var memoReadOnly = panelMemo.add("statictext", undefined, memoTab1Text, { multiline: true });
        memoReadOnly.preferredSize = [160, 50];
        var firstMemoField = null;

        /* メモタブ（位置順にソート）/ Notes tab (sorted by position) */
        var sortedSel = [];
        for (var si = 0; si < sel.length; si++) { sortedSel.push(sel[si]); }
        sortedSel.sort(function (a, b) {
            var aTop = 0, bTop = 0, aLeft = 0, bLeft = 0;
            try { aTop = a.geometricBounds[1]; } catch (e) { }
            try { bTop = b.geometricBounds[1]; } catch (e) { }
            try { aLeft = a.geometricBounds[0]; } catch (e) { }
            try { bLeft = b.geometricBounds[0]; } catch (e) { }
            if (aTop !== bTop) return bTop - aTop; // 上から下（Y降順）
            return aLeft - bLeft;                  // 左から右（X昇順）
        });

        for (var mi = 0; mi < sortedSel.length; mi++) {
            (function (obj) {
                var row = tab2.add("group");
                row.orientation = "row";
                row.alignChildren = ["fill", "center"];
                var noteText = "";
                try { noteText = obj.note || ""; } catch (e) { }
                var noteField = row.add("edittext", undefined, noteText, { multiline: true });
                noteField.preferredSize = [340, 44];
                if (!firstMemoField) firstMemoField = noteField;
                var applyBtn = row.add("button", undefined, LABELS.applyMemo[lang]);
                // applyBtn.preferredSize.width = 30;
                applyBtn.onClick = function () {
                    try { obj.note = noteField.text; } catch (e) { }

                    // Update the read‑only memo panel immediately
                    try {
                        if (memoTextsSel.length === 1) {
                            memoReadOnly.text = noteField.text;
                        }
                    } catch (e2) { }

                    // Force Illustrator UI refresh
                    try { app.redraw(); } catch (e3) { }
                };
            })(sortedSel[mi]);
        }

        /* グループの詳細を表示するパネル / Panel to display group details */
        var panelGroup = rightCol.add("panel", undefined, LABELS.group[lang]);
        panelGroup.orientation = "column";
        panelGroup.alignChildren = ["fill", "top"];
        panelGroup.margins = [15, 20, 0, 10];

        var groupSel = 0,
            groupAll = 0;
        var clipGroupSel = 0,
            clipGroupAll = 0;

        /* 選択オブジェクト / Selected objects */
        for (var i = 0; i < sel.length; i++) {
            if (sel[i].typename === "GroupItem") {
                groupSel++;
                if (sel[i].clipped) {
                    clipGroupSel++;
                }
            }
        }

        /* 全体 / All objects */
        for (var k = 0; k < allItems.length; k++) {
            var obj = allItems[k];
            if (obj.typename === "GroupItem") {
                groupAll++;
                if (obj.clipped) {
                    clipGroupAll++;
                }
            }
        }

        function addGroupRow(label, value) {
            var row = panelGroup.add("group");
            row.orientation = "row";
            var lbl = row.add("statictext", [0, 0, LABEL_WIDTH_RIGHT, 20], label);
            lbl.justify = "right";
            var val = row.add("statictext", undefined, value);
            val.characters = value.length;
        }

        addGroupRow(LABELS.group[lang], groupSel + " / " + groupAll);
        addGroupRow(LABELS.clipGroup[lang], clipGroupSel + " / " + clipGroupAll);

        /* 透明の詳細を表示するパネル / Panel to display transparency details */
        var panelTransparency = rightCol.add("panel", undefined, LABELS.transparency[lang]);
        panelTransparency.orientation = "column";
        panelTransparency.alignChildren = ["fill", "top"];
        panelTransparency.margins = [15, 20, 0, 10];

        function addTransparencyRow(label, value) {
            var row = panelTransparency.add("group");
            row.orientation = "row";
            var lbl = row.add("statictext", [0, 0, LABEL_WIDTH_RIGHT, 20], label);
            lbl.justify = "right";
            var val = row.add("statictext", undefined, value);
            val.characters = value.length;
        }

        addTransparencyRow(LABELS.opacityLt100[lang], opacityLt100Sel + " / " + opacityLt100All);
        addTransparencyRow(LABELS.blendNotNormal[lang], blendNotNormalSel + " / " + blendNotNormalAll);

        /* パスの詳細を表示するパネル / Panel to display path details */
        var panelPath = rightCol.add("panel", undefined, LABELS.path[lang]);
        panelPath.orientation = "column";
        panelPath.alignChildren = ["fill", "top"];
        panelPath.margins = [15, 20, 0, 10];

        /* パス総数表示行を最上部に追加 / Add total path count row at top */
        function addPathRow(label, value) {
            var row = panelPath.add("group");
            row.orientation = "row";
            var lbl = row.add("statictext", [0, 0, LABEL_WIDTH_RIGHT, 20], label);
            lbl.justify = "right";
            var val = row.add("statictext", undefined, value);
            val.characters = value.length;
        }
        addPathRow(LABELS.pathCount[lang], pathCountSel + " / " + pathCountAll);

        /* パスの種類（再帰カウント済み） / Path types (already counted recursively) */
        var openPathSel = pathStatsSel.openPath;
        var openPathAll = pathStatsAll.openPath;
        var closedPathSel = pathStatsSel.closedPath;
        var closedPathAll = pathStatsAll.closedPath;

        addPathRow(LABELS.openPath[lang], openPathSel + " / " + openPathAll);
        addPathRow(LABELS.closedPath[lang], closedPathSel + " / " + closedPathAll);
        addPathRow(LABELS.anchors[lang], anchorCountSel + " / " + anchorCountAll);
        addPathRow(LABELS.handles[lang], handleCountSel + " / " + handleCountAll);
        addPathRow(LABELS.compoundPath[lang], compoundPathSel + " / " + compoundPathAll);
        addPathRow(LABELS.compoundShape[lang], compoundShapeSel + " / " + compoundShapeAll);

        /* ガイドの詳細を表示するパネル / Panel to display guide details */
        var panelGuide = rightCol.add("panel", undefined, LABELS.guide[lang]);
        panelGuide.orientation = "column";
        panelGuide.alignChildren = ["fill", "top"];
        panelGuide.margins = [15, 20, 0, 10];

        function addGuideRow(label, value) {
            var row = panelGuide.add("group");
            row.orientation = "row";
            var lbl = row.add("statictext", [0, 0, LABEL_WIDTH_RIGHT, 20], label);
            lbl.justify = "right";
            var val = row.add("statictext", undefined, value);
            val.characters = value.length;
        }

        addGuideRow(LABELS.rulerGuides[lang], rulerGuideSel + " / " + rulerGuideAll);
        addGuideRow(LABELS.artboardGuides[lang], artboardGuideSel + " / " + artboardGuideAll);
        addGuideRow(LABELS.otherGuides[lang], otherGuideSel + " / " + otherGuideAll);

        // メイングループ（横並び） / Main group (horizontal layout)
        var btnRowGroup = dlg.add("group");
        btnRowGroup.orientation = "row";
        btnRowGroup.alignChildren = ["fill", "center"];
        btnRowGroup.margins = [10, 10, 10, 0];
        btnRowGroup.alignment = ["fill", "bottom"];

        // 左側グループ / Left-side button group
        var btnLeftGroup = btnRowGroup.add("group");
        btnLeftGroup.alignChildren = ["left", "center"];
        var btnExport = btnLeftGroup.add("button", undefined, LABELS.exportPreset[lang], {
            name: "preview"
        });

        // スペーサー（伸縮）/ Spacer (stretchable)
        var spacer = btnRowGroup.add("statictext", undefined, "");
        spacer.alignment = ["fill", "fill"];
        spacer.minimumSize.width = 0;

        // 右側グループ / Right-side button group
        var btnRightGroup = btnRowGroup.add("group");
        btnRightGroup.alignChildren = ["right", "center"];
        var btnOK = btnRightGroup.add("button", undefined, LABELS.ok[lang], {
            name: "ok"
        });

        btnExport.onClick = function () {
            try {
                var docName = app.activeDocument.name.replace(/\.[^\.]+$/, ""); // 拡張子を除いたファイル名
                var today = new Date();
                var yyyy = today.getFullYear();
                var mm = ("0" + (today.getMonth() + 1)).slice(-2);
                var dd = ("0" + today.getDate()).slice(-2);
                var dateStr = yyyy + mm + dd;

                var desktopPath = Folder.desktop + "/count-" + docName + "-" + dateStr + ".txt";
                var file = new File(desktopPath);

                // Helper: write a label + "sel / all" (layout aligned with dialog)
                function wPair(labelJa, labelEn, selVal, allVal) {
                    if (lang === "ja") {
                        file.writeln(labelJa + " " + selVal + " / " + allVal);
                    } else {
                        file.writeln(labelEn + " " + selVal + " / " + allVal);
                    }
                }

                // Helper: write a label + single value
                function wSingle(labelJa, labelEn, val) {
                    if (lang === "ja") {
                        file.writeln(labelJa + " " + val);
                    } else {
                        file.writeln(labelEn + " " + val);
                    }
                }

                // Helper: section header
                function wSection(labelObj) {
                    file.writeln("");
                    file.writeln(labelObj[lang]);
                }

                if (file.open("w")) {
                    // Header
                    file.writeln(LABELS.reportTitle[lang]);
                    file.writeln(LABELS.reportDocument[lang] + " " + app.activeDocument.name);
                    file.writeln(LABELS.reportDate[lang] + " " + yyyy + "-" + mm + "-" + dd);
                    file.writeln("");
                    file.writeln(LABELS.reportValueNote[lang]);

                    // Basics / Misc
                    wSection(LABELS.sectionBasics);
                    wSingle(LABELS.artboards.ja.replace(/：$/, ":"), LABELS.artboards.en.replace(/:$/, ":"), artboardCount);
                    wPair(LABELS.objects.ja.replace(/：$/, ":"), LABELS.objects.en.replace(/:$/, ":"), totalObjSel, totalObjAll);

                    // Text Frames
                    wSection(LABELS.sectionTextFrames);
                    wPair(LABELS.texts.ja.replace(/：$/, ":"), LABELS.texts.en.replace(/:$/, ":"), textCountSel, textCountAll);
                    wPair(LABELS.pointText.ja.replace(/：$/, ":"), LABELS.pointText.en.replace(/:$/, ":"), pointTextSel, pointTextAll);
                    wPair(LABELS.areaText.ja.replace(/：$/, ":"), LABELS.areaText.en.replace(/:$/, ":"), areaTextSel, areaTextAll);
                    wPair(LABELS.pathText.ja.replace(/：$/, ":"), LABELS.pathText.en.replace(/:$/, ":"), pathTextSel, pathTextAll);

                    // Characters & Paragraphs
                    wSection(LABELS.sectionCharPara);
                    wPair(LABELS.chars.ja.replace(/：$/, ":"), LABELS.chars.en.replace(/:$/, ":"), totalCharSel, totalCharAll);
                    wPair(LABELS.paras.ja.replace(/：$/, ":"), LABELS.paras.en.replace(/:$/, ":"), paraCountSel, paraCountAll);
                    wPair(LABELS.forcedBreaks.ja.replace(/：$/, ":"), LABELS.forcedBreaks.en.replace(/:$/, ":"), forcedBreakSel, forcedBreakAll);

                    // Images
                    wSection(LABELS.sectionImages);
                    wPair(LABELS.linked.ja.replace(/：$/, ":"), LABELS.linked.en.replace(/:$/, ":"), linkedSel, linkedAll);
                    wPair(LABELS.embed.ja.replace(/：$/, ":"), LABELS.embed.en.replace(/:$/, ":"), embeddedSel, embeddedAll);
                    wPair(LABELS.broken.ja.replace(/：$/, ":"), LABELS.broken.en.replace(/:$/, ":"), brokenLinkSel, brokenLinkAll);

                    // Notes
                    wSection(LABELS.sectionNotes);
                    if (memoTextsSel.length > 0) {
                        file.writeln(memoTextsSel.join("\n"));
                    }

                    // Transparency
                    wSection(LABELS.sectionTransparency);
                    wPair(LABELS.opacityLt100.ja.replace(/：$/, ":"), LABELS.opacityLt100.en.replace(/:$/, ":"), opacityLt100Sel, opacityLt100All);
                    wPair(LABELS.blendNotNormal.ja.replace(/：$/, ":"), LABELS.blendNotNormal.en.replace(/:$/, ":"), blendNotNormalSel, blendNotNormalAll);

                    // Groups
                    wSection(LABELS.sectionGroups);
                    wPair(LABELS.group.ja.replace(/：$/, ":"), LABELS.group.en.replace(/:$/, ":"), groupSel, groupAll);
                    wPair(LABELS.clipGroup.ja.replace(/：$/, ":"), LABELS.clipGroup.en.replace(/:$/, ":"), clipGroupSel, clipGroupAll);

                    // Paths
                    wSection(LABELS.sectionPaths);
                    wPair(LABELS.pathCount.ja.replace(/：$/, ":"), LABELS.pathCount.en.replace(/:$/, ":"), pathCountSel, pathCountAll);
                    wPair(LABELS.openPath.ja.replace(/：$/, ":"), LABELS.openPath.en.replace(/:$/, ":"), openPathSel, openPathAll);
                    wPair(LABELS.closedPath.ja.replace(/：$/, ":"), LABELS.closedPath.en.replace(/:$/, ":"), closedPathSel, closedPathAll);
                    wPair(LABELS.anchors.ja.replace(/：$/, ":"), LABELS.anchors.en.replace(/:$/, ":"), anchorCountSel, anchorCountAll);
                    wPair(LABELS.handles.ja.replace(/：$/, ":"), LABELS.handles.en.replace(/:$/, ":"), handleCountSel, handleCountAll);
                    wPair(LABELS.compoundPath.ja.replace(/：$/, ":"), LABELS.compoundPath.en.replace(/:$/, ":"), compoundPathSel, compoundPathAll);
                    wPair(LABELS.compoundShape.ja.replace(/：$/, ":"), LABELS.compoundShape.en.replace(/:$/, ":"), compoundShapeSel, compoundShapeAll);

                    // Guides
                    wSection(LABELS.sectionGuides);
                    wPair(LABELS.rulerGuides.ja.replace(/：$/, ":"), LABELS.rulerGuides.en.replace(/:$/, ":"), rulerGuideSel, rulerGuideAll);
                    wPair(LABELS.artboardGuides.ja.replace(/：$/, ":"), LABELS.artboardGuides.en.replace(/:$/, ":"), artboardGuideSel, artboardGuideAll);
                    wPair(LABELS.otherGuides.ja.replace(/：$/, ":"), LABELS.otherGuides.en.replace(/:$/, ":"), otherGuideSel, otherGuideAll);

                    file.close();

                    if (lang === "ja") {
                        alert("書き出しました: " + desktopPath);
                    } else {
                        alert("Exported: " + desktopPath);
                    }
                } else {
                    if (lang === "ja") {
                        alert("ファイルを開けませんでした。");
                    } else {
                        alert("Failed to open the file.");
                    }
                }
            } catch (err) {
                if (lang === "ja") {
                    alert("書き出し中にエラー: " + err);
                } else {
                    alert("Export error: " + err);
                }
            }
        };
        btnOK.onClick = function () {
            dlg.close();
        };

        /* ダイアログ透明度と位置を調整 / Adjust dialog opacity and position */
        var dialogOpacity = 0.97;

        function setDialogOpacity(targetDlg, opacityValue) {
            try {
                if (targetDlg && typeof opacityValue === "number") {
                    targetDlg.opacity = opacityValue;
                }
            } catch (e) { }
        }

        function restoreDialogLocation(targetDlg) {
            try {
                if (__selectionInspectorDialogState.location && __selectionInspectorDialogState.location.length === 2) {
                    targetDlg.location = [
                        __selectionInspectorDialogState.location[0],
                        __selectionInspectorDialogState.location[1]
                    ];
                } else {
                    targetDlg.center();
                }
            } catch (e) {
                targetDlg.center();
            }
        }

        function rememberDialogLocation(targetDlg) {
            try {
                if (targetDlg.location && targetDlg.location.length === 2) {
                    __selectionInspectorDialogState.location = [
                        targetDlg.location[0],
                        targetDlg.location[1]
                    ];
                }
            } catch (e) { }
        }

        dlg.onClose = function () {
            rememberDialogLocation(dlg);
            try { app.redraw(); } catch (e) { }
        };

        dlg.addEventListener("keydown", function (event) {
            var key = "";
            try {
                key = event && event.keyName ? String(event.keyName).toUpperCase() : "";
            } catch (e) {
                key = "";
            }

            if (event && event.altKey && key === "I") {
                switchView("info");
                try { btnOK.active = true; } catch (e1) { }
                try { if (event.preventDefault) event.preventDefault(); } catch (e2) { }
            }
            else if (event && event.altKey && key === "M") {
                switchView("memo");
                try {
                    if (firstMemoField) {
                        firstMemoField.active = true;
                    }
                } catch (e3) { }
                try { if (event.preventDefault) event.preventDefault(); } catch (e4) { }
            }
        });

        rbInfo.onClick = function () {
            switchView("info");
        };

        rbMemo.onClick = function () {
            switchView("memo");
            try {
                if (firstMemoField) firstMemoField.active = true;
            } catch (e5) { }
        };

        switchView("info");
        setDialogOpacity(dlg, dialogOpacity);
        restoreDialogLocation(dlg);
        dlg.show();

    } catch (e) {
        alert("エラーが発生しました: " + e);
    }
}

main();