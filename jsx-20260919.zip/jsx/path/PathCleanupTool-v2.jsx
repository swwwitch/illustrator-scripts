#target illustrator
#targetengine "PathCleanupToolEngine"
app.preferences.setBooleanPreference('ShowExternalJSXWarning', false);

/*

### 概要

選択したパス（グループ・複合パスの中も含む）の冗長なアンカー・同座標のアンカー・直線として扱えるベジェハンドルを削除して最適化します。
［その他］タブからスムーズ化／コーナー化／アンカー追加／アンカー分割も実行できます。

詳細は README を参照してください。

### Overview

Optimizes the selected paths — including those inside groups and compound paths — by removing redundant anchors, coincident anchors and Bézier handles that can be treated as straight.
The Other tab adds smoothing, cornering, adding anchors and splitting anchors.

See the README for details.

*/

// =========================================
// 基本情報 / Basic info
// =========================================
var SCRIPT_NAME     = "PathCleanupTool-v2";           /* スクリプト名 / script name */
var SCRIPT_VERSION  = "v1.4.2";                       /* バージョン / version */
var SCRIPT_AUTHOR   = "Masahiro Takano (@swwwitch)";  /* 作者 / author */
var SCRIPT_RELEASED = "2026-03-20";                   /* 最初のリリース日 / first release date */
var SCRIPT_UPDATED  = "2026-09-19";                   /* 更新日 / last updated */

var SCRIPT_README_JA = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/PathCleanupTool-v2.md"; /* README（日本語） */
var SCRIPT_README_EN = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/PathCleanupTool-v2.md"; /* README (English) */

// Released under the MIT license
// http://opensource.org/licenses/mit-license.php

(function () {

    function getCurrentLang() {
        return ($.locale.indexOf("ja") === 0) ? "ja" : "en";
    }
    var uiLang = getCurrentLang();

    /* 日英ラベル定義 / Japanese-English label definitions */
    var LABELS = {
        dialogTitle: {
            ja: "パスの最適化",
            en: "Path Optimization"
        },
        panelProcess: {
            ja: "削除対象",
            en: "Removal Targets"
        },
        panelCurrentInfo: {
            ja: "情報",
            en: "Info"
        },
        labelPathCount: {
            ja: "パスの数：",
            en: "Paths: "
        },
        labelAnchorCount: {
            ja: "アンカーポイント数：",
            en: "Anchor points: "
        },
        labelHandleCount: {
            ja: "ハンドル数：",
            en: "Handles: "
        },
        cbRemoveAnchors: {
            ja: "直線上のアンカーポイント",
            en: "Collinear anchor points"
        },
        cbRemoveSameAnchors: {
            ja: "同じ座標のアンカーポイント",
            en: "Duplicate anchor points"
        },
        cbRemoveHandles: {
            ja: "パスと同じ角度のハンドル",
            en: "Handles on straight segments"
        },
        labelTolAnchor: {
            ja: "許容誤差",
            en: "Tolerance"
        },
        labelTolHandle: {
            ja: "許容誤差",
            en: "Tolerance"
        },
        btnOK: {
            ja: "OK",
            en: "OK"
        },
        btnCancel: {
            ja: "キャンセル",
            en: "Cancel"
        },
        alertNoDocument: {
            ja: "ドキュメントが開かれていません。",
            en: "No document is open."
        },
        alertNeedSelection: {
            ja: "パスを選択してから実行してください。",
            en: "Please select paths before running."
        },
        tabProcess: {
            ja: "削除対象",
            en: "Removal Targets"
        },
        tabOther: {
            ja: "その他",
            en: "Other"
        },
        rbConvertSmooth: {
            ja: "スムーズポイントに変換",
            en: "Convert to smooth points"
        },
        rbConvertCorner: {
            ja: "コーナーポイントに変換",
            en: "Convert to corner points"
        },
        rbAddAnchors: {
            ja: "アンカーポイントを追加",
            en: "Add anchor points"
        },
        rbSplitAtAnchors: {
        tipSameAnchors: { ja: "同じ位置に重なっているアンカーポイントを1つにまとめます。", en: "Merges anchor points that sit on top of each other." },
        tipRemoveAnchors: { ja: "直線上に並んでいて、形に影響しないアンカーポイントを削除します。", en: "Deletes anchor points that lie on a straight run and do not change the shape." },
        tipTolAnchor: { ja: "直線とみなす許容値です。大きいほど多く削除されます。", en: "How far from straight still counts as straight. Larger values delete more." },
        tipRemoveHandles: { ja: "曲線の形に影響していない方向線（ハンドル）を削除します。", en: "Removes direction handles that are not shaping the curve." },
        tipTolHandle: { ja: "方向線を不要とみなす許容値です。大きいほど多く削除されます。", en: "How close to collinear a handle must be before it is removed. Larger values remove more." },
        tipConvertSmooth: { ja: "アンカーポイントをスムーズポイントに変えます。", en: "Converts the anchor points to smooth points." },
        tipConvertCorner: { ja: "アンカーポイントをコーナーポイントに変えます。", en: "Converts the anchor points to corner points." },
        tipAddAnchors: { ja: "各セグメントの中間にアンカーポイントを追加します。", en: "Adds an anchor point in the middle of every segment." },
        tipSplitAtAnchors: { ja: "各アンカーポイントでパスを分割します。", en: "Splits the path at every anchor point." },
            ja: "アンカーポイントで分割",
            en: "Split at anchor points"
        }
    };

    (function () {
        // --- shared settings / helpers ---
        /* 共通設定とヘルパー / Shared settings and helpers */
        // Tolerances (keep same default values to avoid behavior change)
        // - Anchor collinearity tolerance: used for redundant anchor removal
        // - Handle collinearity tolerance: used for straight-segment handle normalization
        // - Same-point tolerance: used for handle/anchor coincidence checks and counts
        var TOL_ANCHOR_COLLINEAR = 0.02;
        var TOL_HANDLE_COLLINEAR = 0.01;
        var TOL_SAMEPOINT = 0.02;

        // 実処理系のみ最小ログ化。UI位置保存や復元系の catch は従来どおり silent のままにする
        function logProcessError(context, e) {
            try {
                $.writeln("[PathCleanupTool] " + context + ": " + e);
            } catch (e) {
                // ignore logging failure
            }
        }

        function hasDocument() {
            return app.documents.length > 0;
        }

        /**
     * 同一座標のアンカーポイント（重複点）を削除（内部：targets 指定）
     * - 連続して同じ座標になっているアンカーのみ対象（離れた位置の同座標は対象外）
     * - オープンパスは端点を削除しない
     * 戻り値：削除したアンカー数
     */
        function removeDuplicateAnchorsOnTargets(targets) {
            if (!targets || !targets.length) return 0;

            var removed = 0;

            for (var s = 0; s < targets.length; s++) {
                var item = targets[s];
                if (!item || isSkippableItem(item)) continue;

                try {
                    var pts = item.pathPoints;
                    var isClosed = item.closed;
                    var n = pts.length;
                    if (n < 2) continue;

                    // Walk backward so index stays valid after removals
                    // Open path: do not remove endpoints => i from n-2 down to 1
                    // Closed path: can remove any point, but keep at least 2 points
                    var start = isClosed ? (n - 1) : (n - 2);
                    var end = isClosed ? 0 : 1;

                    for (var i = start; i >= end; i--) {
                        var curLen = pts.length;
                        if (curLen < 2) break;

                        if (i > curLen - 1) i = curLen - 1;
                        if (!isClosed && (i <= 0 || i >= curLen - 1)) continue;

                        var prevIndex = isClosed ? ((i - 1 + curLen) % curLen) : (i - 1);
                        if (prevIndex < 0 || prevIndex > curLen - 1) continue;

                        var pPrev = pts[prevIndex];
                        var pCur = pts[i];

                        if (samePoint(pPrev.anchor, pCur.anchor, TOL_SAMEPOINT)) {
                            pCur.remove();
                            removed++;
                        }
                    }
                } catch (e) {
                    logProcessError("removeDuplicateAnchorsOnTargets", e);
                }
            }

            return removed;
        }

        function getLabel(key) {
            var v = LABELS[key];
            if (!v) return String(key);
            return v[uiLang] || v.ja || String(key);
        }

        function getSelectionOrAlert() {
            if (!hasDocument()) {
                alert(getLabel('alertNoDocument'));
                return null;
            }
            var doc = app.activeDocument;
            var currentSelection = doc.selection;
            if (!(currentSelection instanceof Array) || currentSelection.length === 0) {
                alert(getLabel('alertNeedSelection'));
                return null;
            }
            return currentSelection;
        }

        // 3点が一直線上にあるか判定（外積を使用）
        function isCollinear(p1, p2, p3, tol) {
            var area = (p2[0] - p1[0]) * (p3[1] - p1[1]) - (p2[1] - p1[1]) * (p3[0] - p1[0]);
            return Math.abs(area) < (tol || TOL_ANCHOR_COLLINEAR);
        }

        function samePoint(a, b, tol) {
            return (Math.abs(a[0] - b[0]) + Math.abs(a[1] - b[1])) < (tol || TOL_SAMEPOINT);
        }

        // 点pが線分a-bの直線上にあるか（点から直線までの距離で判定）
        // tol は「距離（pt）」として扱う。線分が極端に短い場合は samePoint にフォールバック。
        function isPointOnLineByDistance(a, b, p, tol) {
            tol = (tol != null) ? tol : TOL_HANDLE_COLLINEAR;

            var abx = b[0] - a[0];
            var aby = b[1] - a[1];
            var len = Math.sqrt(abx * abx + aby * aby);

            if (len < 1e-9) {
                // a と b がほぼ同一点
                return samePoint(a, p, Math.max(TOL_SAMEPOINT, tol));
            }

            // cross product magnitude / |AB| = perpendicular distance
            var apx = p[0] - a[0];
            var apy = p[1] - a[1];
            var area2 = abx * apy - aby * apx; // signed
            var dist = Math.abs(area2) / len;
            return dist <= tol;
        }

        // --- dialog position persistence (session only) ---
        // Store ONLY window location (x,y). Bounds can include size and may restore too small, making UI appear blank.
        // Stored in the target engine's global object; reset when Illustrator quits.
        var DLG_LOC_KEY = "__PathCleanupTool_DialogLocation__";

        function loadDialogLocation() {
            try {
                var p = $.global[DLG_LOC_KEY];
                if (!p || p.length !== 2) return null;
                return [Number(p[0]), Number(p[1])];
            } catch (e) {
                return null;
            }
        }

        function saveDialogLocation(dlg) {
            if (!dlg) return;
            try {
                var p = dlg.location; // [x,y]
                if (!p || p.length !== 2) return;
                $.global[DLG_LOC_KEY] = [Number(p[0]), Number(p[1])];
            } catch (e) {
                // ignore
            }
        }

        function tryRestoreDialogLocation(dlg) {
            var p = loadDialogLocation();
            if (!p) return;
            try {
                dlg.location = p;
            } catch (e) {
                // ignore
            }
        }

        /* ロック・非表示を判定（親・レイヤーも含む） / Check locked/hidden including parents and layers */
        function isSkippableItem(item) {
            var cur = item;
            while (cur) {
                try {
                    // PageItem / GroupItem / PathItem etc.
                    if (cur.locked === true) return true;
                    if (cur.hidden === true) return true;

                    // Layer
                    if (cur.typename === "Layer") {
                        if (cur.locked === true) return true;
                        if (cur.visible === false) return true;
                    }

                    // If the item has a layer reference, also respect it
                    if (cur.layer) {
                        try {
                            if (cur.layer.locked === true) return true;
                            if (cur.layer.visible === false) return true;
                        } catch (e) { }
                    }
                } catch (e) {
                    // ignore property access errors
                }

                // Walk up
                try {
                    cur = cur.parent;
                } catch (e) {
                    break;
                }

                // Stop when reaching document-like root
                if (!cur || cur.typename === "Document") break;
            }
            return false;
        }

        /* 選択からPathItemを再帰的に収集 / Collect PathItems recursively from selection */
        function collectPathItemsFromAny(item, out) {
            if (!item) return;
            if (isSkippableItem(item)) return;

            try {
                // Direct PathItem
                if (item.typename === "PathItem") {
                    out.push(item);
                    return;
                }

                // CompoundPathItem contains pathItems
                if (item.typename === "CompoundPathItem") {
                    for (var i = 0; i < item.pathItems.length; i++) {
                        if (!isSkippableItem(item.pathItems[i])) out.push(item.pathItems[i]);
                    }
                    return;
                }

                // GroupItem (including clipped groups)
                if (item.typename === "GroupItem") {
                    for (var g = 0; g < item.pageItems.length; g++) {
                        collectPathItemsFromAny(item.pageItems[g], out);
                    }
                    return;
                }

                // Other container types we may want to traverse
                if (item.pageItems && item.pageItems.length) {
                    for (var p = 0; p < item.pageItems.length; p++) {
                        collectPathItemsFromAny(item.pageItems[p], out);
                    }
                }
            } catch (e) {
                logProcessError("collectPathItemsFromAny", e);
            }
        }

        function getTargetPathItemsFromSelection(selection) {
            var out = [];
            for (var i = 0; i < selection.length; i++) {
                collectPathItemsFromAny(selection[i], out);
            }
            return out;
        }

        /* 指定targetsから情報（数）を取得 / Get info counts from given targets */
        function getInfoCountsFromTargets(targets) {
            var info = { paths: 0, anchors: 0, handles: 0 };
            if (!targets || !targets.length) return info;

            for (var i = 0; i < targets.length; i++) {
                var item = targets[i];
                if (!item || isSkippableItem(item)) continue;
                info.paths++;

                var pts = item.pathPoints;
                var n = pts.length;
                info.anchors += n;

                for (var k = 0; k < n; k++) {
                    var pt = pts[k];
                    if (!samePoint(pt.leftDirection, pt.anchor, TOL_SAMEPOINT)) info.handles++;
                    if (!samePoint(pt.rightDirection, pt.anchor, TOL_SAMEPOINT)) info.handles++;
                }
            }

            return info;
        }

        /**
         * 不要なアンカーポイント（直線上の冗長点）を削除（内部：targets 指定）
         */
        function removeRedundantAnchorsOnTargets(targets) {
            if (!targets || !targets.length) return 0;

            var removedCount = 0;

            // アンカーポイントからハンドル（方向線）が引き出されていないか判定
            function isStraightPoint(pt) {
                var d1 = Math.abs(pt.anchor[0] - pt.leftDirection[0]) + Math.abs(pt.anchor[1] - pt.leftDirection[1]);
                var d2 = Math.abs(pt.anchor[0] - pt.rightDirection[0]) + Math.abs(pt.anchor[1] - pt.rightDirection[1]);
                return d1 < TOL_SAMEPOINT && d2 < TOL_SAMEPOINT;
            }

            for (var s = 0; s < targets.length; s++) {
                var item = targets[s];
                if (!item || isSkippableItem(item)) continue;

                try {
                    var pts = item.pathPoints;
                    var isClosed = item.closed;

                    // オープンパスの場合は端点を削除しない、クローズドパスの場合は全てループ
                    // 削除によってインデックスがずれるのを防ぐため、後ろからループする
                    var startIndex = isClosed ? pts.length - 1 : pts.length - 2;
                    var endIndex = isClosed ? 0 : 1;

                    for (var i = startIndex; i >= endIndex; i--) {
                        var currentLen = pts.length;
                        if (currentLen < 3) break;

                        // 削除でインデックスが範囲外になった場合に備えて補正
                        if (i > currentLen - 1) i = currentLen - 1;
                        if (i < endIndex) break;

                        var prevIndex = (i - 1 + currentLen) % currentLen;
                        var nextIndex = (i + 1) % currentLen;

                        var pA = pts[prevIndex];
                        var pB = pts[i];
                        var pC = pts[nextIndex];

                        if (isStraightPoint(pB) && isCollinear(pA.anchor, pB.anchor, pC.anchor, TOL_ANCHOR_COLLINEAR)) {
                            pB.remove();
                            removedCount++;
                        }
                    }
                } catch (e) {
                    logProcessError("removeRedundantAnchorsOnTargets", e);
                }
            }

            return removedCount;
        }

        /**
         * 不要なハンドルを削除（直線になっているベジェ区間のハンドルをアンカーに戻す）（内部：targets 指定）
         * 戻り値：リセットしたハンドル数（左右それぞれ1カウント）
         */
        function removeRedundantHandlesOnTargets(targets) {
            if (!targets || !targets.length) return 0;

            var changed = 0;

            // セグメント(p0 -> p1)が「見た目として直線」か判定
            // 両端アンカーを結ぶ直線に、p0右ハンドル / p1左ハンドルが近ければ直線とみなす
            function isStraightSegment(p0, p1) {
                // 両端アンカーを結ぶ直線に、p0右ハンドル / p1左ハンドルが近ければ直線とみなす
                return isPointOnLineByDistance(p0.anchor, p1.anchor, p0.rightDirection, TOL_HANDLE_COLLINEAR) &&
                    isPointOnLineByDistance(p0.anchor, p1.anchor, p1.leftDirection, TOL_HANDLE_COLLINEAR);
            }

            for (var s = 0; s < targets.length; s++) {
                var item = targets[s];
                if (!item || isSkippableItem(item)) continue;

                try {
                    var pts = item.pathPoints;
                    var len = pts.length;
                    if (len < 2) continue;

                    var isClosed = item.closed;
                    var segCount = isClosed ? len : (len - 1);

                    for (var i = 0; i < segCount; i++) {
                        var p0 = pts[i];
                        var p1 = pts[(i + 1) % len];

                        if (!isStraightSegment(p0, p1)) continue;

                        // オープンパス端点のハンドルは触らない / Do not modify endpoint handles for open paths
                        var isOpen = !item.closed;
                        var isFirstSeg = isOpen && (i === 0);
                        var isLastSeg = isOpen && (i === (segCount - 1));

                        // p0.rightDirection: skip if p0 is the first endpoint of an open path
                        if (!isFirstSeg) {
                            if (!samePoint(p0.rightDirection, p0.anchor, TOL_SAMEPOINT)) {
                                p0.rightDirection = p0.anchor;
                                changed++;
                            }
                        }

                        // p1.leftDirection: skip if p1 is the last endpoint of an open path
                        if (!isLastSeg) {
                            if (!samePoint(p1.leftDirection, p1.anchor, TOL_SAMEPOINT)) {
                                p1.leftDirection = p1.anchor;
                                changed++;
                            }
                        }
                    }
                } catch (e) {
                    logProcessError("removeRedundantHandlesOnTargets", e);
                }
            }

            return changed;
        }

        // 予測情報を取得（処理前後のアンカー数とハンドル数）
        // ※実際に削除はせず、指定targetsをスキャンして「実行順（アンカー→ハンドル→アンカー）」をモデル上でシミュレートする
        function getPredictedInfoCountsForTargets(targets, doSameAnchors, doAnchors, doHandles) {
            var infoNow = getInfoCountsFromTargets(targets);

            // --- model helpers ---
            function clonePoint(pt) {
                return {
                    a: [pt.anchor[0], pt.anchor[1]],
                    l: [pt.leftDirection[0], pt.leftDirection[1]],
                    r: [pt.rightDirection[0], pt.rightDirection[1]]
                };
            }

            function clonePath(item) {
                var pts = item.pathPoints;
                var out = [];
                for (var i = 0; i < pts.length; i++) {
                    out.push(clonePoint(pts[i]));
                }
                return {
                    closed: !!item.closed,
                    pts: out
                };
            }

            function isStraightPointM(p) {
                var d1 = Math.abs(p.a[0] - p.l[0]) + Math.abs(p.a[1] - p.l[1]);
                var d2 = Math.abs(p.a[0] - p.r[0]) + Math.abs(p.a[1] - p.r[1]);
                return d1 < TOL_SAMEPOINT && d2 < TOL_SAMEPOINT;
            }

            function samePointM(a, b) {
                return (Math.abs(a[0] - b[0]) + Math.abs(a[1] - b[1])) < TOL_SAMEPOINT;
            }

            // アンカー削除（モデル上）
            function removeRedundantAnchorsModel(pathM) {
                var removed = 0;
                var pts = pathM.pts;
                var isClosed = pathM.closed;

                if (pts.length < 3) return 0;

                // 実処理と同じ：オープンは端点を除外、後ろから走査
                var startIndex = isClosed ? (pts.length - 1) : (pts.length - 2);
                var endIndex = isClosed ? 0 : 1;

                for (var i = startIndex; i >= endIndex; i--) {
                    var currentLen = pts.length;
                    if (currentLen < 3) break;

                    // 途中で短くなった場合に備えて補正
                    if (i > currentLen - 1) i = currentLen - 1;
                    if (i < endIndex) break;

                    var prevIndex = (i - 1 + currentLen) % currentLen;
                    var nextIndex = (i + 1) % currentLen;

                    var pA = pts[prevIndex];
                    var pB = pts[i];
                    var pC = pts[nextIndex];

                    if (isStraightPointM(pB) && isCollinear(pA.a, pB.a, pC.a, TOL_ANCHOR_COLLINEAR)) {
                        pts.splice(i, 1);
                        removed++;
                    }
                }

                return removed;
            }

            // 重複アンカー削除（モデル上）
            function removeDuplicateAnchorsModel(pathM) {
                var removed = 0;
                var pts = pathM.pts;
                var isClosed = pathM.closed;
                var n = pts.length;
                if (n < 2) return 0;

                var start = isClosed ? (n - 1) : (n - 2);
                var end = isClosed ? 0 : 1;

                for (var i = start; i >= end; i--) {
                    var curLen = pts.length;
                    if (curLen < 2) break;

                    if (i > curLen - 1) i = curLen - 1;
                    if (!isClosed && (i <= 0 || i >= curLen - 1)) continue;

                    var prevIndex = isClosed ? ((i - 1 + curLen) % curLen) : (i - 1);
                    if (prevIndex < 0 || prevIndex > curLen - 1) continue;

                    var pPrev = pts[prevIndex];
                    var pCur = pts[i];

                    if (samePointM(pPrev.a, pCur.a)) {
                        pts.splice(i, 1);
                        removed++;
                    }
                }

                return removed;
            }

            // ハンドル削除（モデル上）
            function removeRedundantHandlesModel(pathM) {
                var changed = 0;
                var pts = pathM.pts;
                var len = pts.length;
                if (len < 2) return 0;

                function isStraightSegmentM(p0, p1) {
                    return isPointOnLineByDistance(p0.a, p1.a, p0.r, TOL_HANDLE_COLLINEAR) &&
                        isPointOnLineByDistance(p0.a, p1.a, p1.l, TOL_HANDLE_COLLINEAR);
                }

                var isClosed = pathM.closed;
                var segCount = isClosed ? len : (len - 1);

                for (var i = 0; i < segCount; i++) {
                    var p0 = pts[i];
                    var p1 = pts[(i + 1) % len];

                    if (!isStraightSegmentM(p0, p1)) continue;

                    var isOpen = !isClosed;
                    var isFirstSeg = isOpen && (i === 0);
                    var isLastSeg = isOpen && (i === (segCount - 1));

                    // p0.rightDirection
                    if (!isFirstSeg) {
                        if (!samePointM(p0.r, p0.a)) {
                            p0.r = [p0.a[0], p0.a[1]];
                            changed++;
                        }
                    }

                    // p1.leftDirection
                    if (!isLastSeg) {
                        if (!samePointM(p1.l, p1.a)) {
                            p1.l = [p1.a[0], p1.a[1]];
                            changed++;
                        }
                    }
                }

                return changed;
            }

            function countHandlesModel(pathM) {
                var c = 0;
                var pts = pathM.pts;
                for (var i = 0; i < pts.length; i++) {
                    var p = pts[i];
                    if (!samePointM(p.l, p.a)) c++;
                    if (!samePointM(p.r, p.a)) c++;
                }
                return c;
            }

            // --- simulate ---
            var pathsCount = 0;
            var anchorsAfterTotal = 0;
            var handlesAfterTotal = 0;

            for (var t = 0; t < (targets ? targets.length : 0); t++) {
                var item = targets[t];
                if (!item || isSkippableItem(item)) continue;

                pathsCount++;

                var m = clonePath(item);

                // 実行順に合わせる（重複アンカー→冗長アンカー→ハンドル→冗長アンカー→重複アンカー）
                if (doSameAnchors) {
                    removeDuplicateAnchorsModel(m);
                }
                if (doAnchors) {
                    removeRedundantAnchorsModel(m);
                }
                if (doHandles) {
                    removeRedundantHandlesModel(m);
                }
                if (doAnchors) {
                    removeRedundantAnchorsModel(m);
                }
                if (doSameAnchors) {
                    removeDuplicateAnchorsModel(m);
                }

                anchorsAfterTotal += m.pts.length;
                handlesAfterTotal += countHandlesModel(m);
            }

            return {
                paths: pathsCount,
                anchorsNow: infoNow.anchors,
                anchorsAfter: anchorsAfterTotal,
                handlesNow: infoNow.handles,
                handlesAfter: handlesAfterTotal
            };
        }

        // 変換・分割の予測情報を取得
        function getPredictedInfoForConvert(targets, mode) {
            var infoNow = getInfoCountsFromTargets(targets);
            var pathsAfter = infoNow.paths;
            var anchorsAfter = infoNow.anchors;
            var handlesAfter = infoNow.handles;

            if (!targets || !targets.length) {
                return { paths: 0, anchorsNow: 0, anchorsAfter: 0, handlesNow: 0, handlesAfter: 0 };
            }

            if (mode === 'corner') {
                // 全ハンドル削除
                handlesAfter = 0;
            } else if (mode === 'smooth') {
                // 全アンカーに左右ハンドル付与
                handlesAfter = infoNow.anchors * 2;
            } else if (mode === 'add') {
                // 各セグメントに1点追加
                var totalSegs = 0;
                for (var i = 0; i < targets.length; i++) {
                    var item = targets[i];
                    if (!item || isSkippableItem(item)) continue;
                    var n = item.pathPoints.length;
                    totalSegs += item.closed ? n : (n - 1);
                }
                anchorsAfter = infoNow.anchors + totalSegs;
                handlesAfter = '-';
            } else if (mode === 'split') {
                // 各セグメントが独立パスに
                var totalSegs2 = 0;
                for (var j = 0; j < targets.length; j++) {
                    var item2 = targets[j];
                    if (!item2 || isSkippableItem(item2)) continue;
                    var n2 = item2.pathPoints.length;
                    totalSegs2 += item2.closed ? n2 : (n2 - 1);
                }
                pathsAfter = totalSegs2;
                anchorsAfter = totalSegs2 * 2;
                handlesAfter = '-';
            }

            return {
                paths: infoNow.paths,
                pathsAfter: pathsAfter,
                anchorsNow: infoNow.anchors,
                anchorsAfter: anchorsAfter,
                handlesNow: infoNow.handles,
                handlesAfter: handlesAfter
            };
        }

        // --- UI ---
        function showDialog(frozenTargets) {
            function getActiveMode() {
                return (tpanel.selection === tabOther) ? 'other' : 'process';
            }
            var dlg = new Window('dialog', getLabel('dialogTitle') + ' ' + SCRIPT_VERSION);
            dlg.orientation = 'column';
            dlg.alignChildren = ['fill', 'top'];
            dlg.margins = 18;

            tryRestoreDialogLocation(dlg);
            dlg.onClose = function () {
                saveDialogLocation(dlg);
            };

            var pnlInfo = dlg.add('panel', undefined, getLabel('panelCurrentInfo'));
            pnlInfo.orientation = 'column';
            pnlInfo.alignChildren = ['left', 'top'];
            pnlInfo.margins = [5, 20, 5, 10];

            function addInfoRow(labelKey) {
                var row = pnlInfo.add('group');
                row.orientation = 'row';
                row.alignChildren = ['left', 'center'];

                var stLabel = row.add('statictext', undefined, getLabel(labelKey));
                stLabel.characters = 16;
                stLabel.justify = 'right';

                var stValue = row.add('statictext', undefined, '0');
                stValue.characters = 8;
                return stValue;
            }

            var stPathCount = addInfoRow('labelPathCount');
            var stAnchorCount = addInfoRow('labelAnchorCount');
            var stHandleCount = addInfoRow('labelHandleCount');

            function fmtArrow(a, b) {
                return String(a) + " → " + String(b);
            }

            function refreshInfoPreview(doSameAnchors, doAnchors, doHandles) {
                var p = getPredictedInfoCountsForTargets(frozenTargets, doSameAnchors, doAnchors, doHandles);
                stPathCount.text = String(p.paths);
                stAnchorCount.text = fmtArrow(p.anchorsNow, p.anchorsAfter);
                stHandleCount.text = fmtArrow(p.handlesNow, p.handlesAfter);
            }

            function refreshInfoForConvert(mode) {
                var p = getPredictedInfoForConvert(frozenTargets, mode);
                stPathCount.text = fmtArrow(p.paths, p.pathsAfter);
                stAnchorCount.text = fmtArrow(p.anchorsNow, p.anchorsAfter);
                stHandleCount.text = fmtArrow(p.handlesNow, p.handlesAfter);
            }

            function getSelectedConvertMode() {
                if (rbSmooth.value) return 'smooth';
                if (rbCorner.value) return 'corner';
                if (rbAdd.value) return 'add';
                return 'split';
            }

            function refreshByActiveTab() {
                if (tpanel.selection === tabOther) {
                    refreshInfoForConvert(getSelectedConvertMode());
                } else {
                    refreshInfoPreview(cbSameAnchors.value, cbAnchors.value, cbHandle.value);
                }
            }

            refreshInfoPreview(false, true, true);

            var tpanel = dlg.add('tabbedpanel');
            tpanel.alignChildren = ['fill', 'top'];

            // --- Tab 1: 削除対象 ---
            var tabProcess = tpanel.add('tab', undefined, getLabel('tabProcess'));
            tabProcess.orientation = 'column';
            tabProcess.alignChildren = ['left', 'top'];
            tabProcess.margins = [15, 15, 15, 10];

            var cbSameAnchors = tabProcess.add('checkbox', undefined, getLabel('cbRemoveSameAnchors'));
            cbSameAnchors.helpTip = getLabel('tipSameAnchors');
            cbSameAnchors.value = false;

            // Tolerance for collinear anchor detection (0.01 - 3.00)

            var grpAnchors = tabProcess.add('group');
            grpAnchors.orientation = 'column';
            grpAnchors.alignChildren = ['left', 'top'];
            grpAnchors.margins = [0, 15, 0, 15];

            var cbAnchors = grpAnchors.add('checkbox', undefined, getLabel('cbRemoveAnchors'));
            cbAnchors.helpTip = getLabel('tipRemoveAnchors');
            cbAnchors.value = true;

            var grpTolAnchor = grpAnchors.add('group');
            grpTolAnchor.orientation = 'row';
            grpTolAnchor.alignChildren = ['left', 'center'];
            grpTolAnchor.margins = [20, 0, 0, 0];

            var stTolAnchor = grpTolAnchor.add('statictext', undefined, getLabel('labelTolAnchor'));
            stTolAnchor.characters = 6;

            var etTolAnchor = grpTolAnchor.add('edittext', undefined, TOL_ANCHOR_COLLINEAR.toFixed(2));
            etTolAnchor.helpTip = getLabel('tipTolAnchor');
            etTolAnchor.characters = 6;

            var slTolAnchor = grpAnchors.add('slider', undefined, Math.round(TOL_ANCHOR_COLLINEAR * 100), 1, 300);
            slTolAnchor.helpTip = getLabel('tipTolAnchor');
            slTolAnchor.preferredSize.width = 160;
            slTolAnchor.indent = 20;

            function clampTolAnchor(v) {
                if (isNaN(v)) return TOL_ANCHOR_COLLINEAR;
                if (v < 0.01) v = 0.01;
                if (v > 3) v = 3;
                v = Math.round(v * 100) / 100;
                return v;
            }

            function syncTolAnchorFromValue(v) {
                v = clampTolAnchor(v);
                TOL_ANCHOR_COLLINEAR = v;
                etTolAnchor.text = v.toFixed(2);
                slTolAnchor.value = Math.round(v * 100);
            }

            slTolAnchor.onChanging = function () {
                var v = slTolAnchor.value / 100;
                syncTolAnchorFromValue(v);
                refreshInfoPreview(cbSameAnchors.value, cbAnchors.value, cbHandle.value);
            };

            etTolAnchor.onChange = function () {
                var v = parseTolText(etTolAnchor.text);
                syncTolAnchorFromValue(v);
                refreshInfoPreview(cbSameAnchors.value, cbAnchors.value, cbHandle.value);
            };

            syncTolAnchorFromValue(TOL_ANCHOR_COLLINEAR);

            var grpHandle = tabProcess.add('group');
            grpHandle.orientation = 'column';
            grpHandle.alignChildren = ['left', 'top'];
            // grpHandle.margins = [0, 0, 0, 8];

            var cbHandle = grpHandle.add('checkbox', undefined, getLabel('cbRemoveHandles'));
            cbHandle.helpTip = getLabel('tipRemoveHandles');
            cbHandle.value = true;

            // Tolerance for straight-segment handle detection (0.01 - 3.00)
            var grpTol = grpHandle.add('group');
            grpTol.orientation = 'row';
            grpTol.alignChildren = ['left', 'center'];
            grpTol.margins = [20, 0, 0, 0];

            var stTol = grpTol.add('statictext', undefined, getLabel('labelTolHandle'));
            stTol.characters = 6;

            var etTol = grpTol.add('edittext', undefined, TOL_HANDLE_COLLINEAR.toFixed(2));
            etTol.helpTip = getLabel('tipTolHandle');
            etTol.characters = 6;

            var slTol = grpHandle.add('slider', undefined, Math.round(TOL_HANDLE_COLLINEAR * 100), 1, 300);
            slTol.helpTip = getLabel('tipTolHandle');
            slTol.preferredSize.width = 160;
            slTol.indent = 20;

            function clampTolHandle(v) {
                if (isNaN(v)) return TOL_HANDLE_COLLINEAR;
                if (v < 0.01) v = 0.01;
                if (v > 3) v = 3;
                // keep 2 decimals
                v = Math.round(v * 100) / 100;
                return v;
            }

            function syncTolHandleFromValue(v) {
                v = clampTolHandle(v);
                TOL_HANDLE_COLLINEAR = v;
                etTol.text = v.toFixed(2);
                slTol.value = Math.round(v * 100);
            }

            function parseTolText(s) {
                if (!s) return NaN;
                // accept formats like "[0.01]", "0.01", and full-width brackets
                s = String(s).replace(/\[/g, '').replace(/\]/g, '').replace(/［/g, '').replace(/］/g, '').replace(/\s/g, '');
                return parseFloat(s);
            }

            slTol.onChanging = function () {
                var v = slTol.value / 100;
                syncTolHandleFromValue(v);
                refreshInfoPreview(cbSameAnchors.value, cbAnchors.value, cbHandle.value);
            };

            etTol.onChange = function () {
                var v = parseTolText(etTol.text);
                syncTolHandleFromValue(v);
                refreshInfoPreview(cbSameAnchors.value, cbAnchors.value, cbHandle.value);
            };

            // init
            syncTolHandleFromValue(TOL_HANDLE_COLLINEAR);

            cbSameAnchors.onClick = function () {
                refreshInfoPreview(cbSameAnchors.value, cbAnchors.value, cbHandle.value);
            };
            cbAnchors.onClick = function () {
                grpTolAnchor.enabled = cbAnchors.value;
                refreshInfoPreview(cbSameAnchors.value, cbAnchors.value, cbHandle.value);
            };
            cbHandle.onClick = function () {
                grpTol.enabled = cbHandle.value;
                refreshInfoPreview(cbSameAnchors.value, cbAnchors.value, cbHandle.value);
            };

            // 初回反映
            refreshInfoPreview(cbSameAnchors.value, cbAnchors.value, cbHandle.value);
            grpTolAnchor.enabled = cbAnchors.value;
            grpTol.enabled = cbHandle.value;

            // --- Tab 2: その他 ---
            var tabOther = tpanel.add('tab', undefined, getLabel('tabOther'));
            tabOther.orientation = 'column';
            tabOther.alignChildren = ['left', 'top'];
            tabOther.margins = [15, 15, 15, 10];

            var rbSmooth = tabOther.add('radiobutton', undefined, getLabel('rbConvertSmooth'));
            rbSmooth.helpTip = getLabel('tipConvertSmooth');
            var rbCorner = tabOther.add('radiobutton', undefined, getLabel('rbConvertCorner'));
            rbCorner.helpTip = getLabel('tipConvertCorner');
            var rbAdd = tabOther.add('radiobutton', undefined, getLabel('rbAddAnchors'));
            rbAdd.helpTip = getLabel('tipAddAnchors');
            var rbSplit = tabOther.add('radiobutton', undefined, getLabel('rbSplitAtAnchors'));
            rbSplit.helpTip = getLabel('tipSplitAtAnchors');
            rbSmooth.value = true;

            rbSmooth.onClick = rbCorner.onClick = rbAdd.onClick = rbSplit.onClick = function () {
                refreshInfoForConvert(getSelectedConvertMode());
            };

            tpanel.onChange = function () {
                refreshByActiveTab();
            };

            tpanel.selection = 0;

            var btns = dlg.add('group');
            btns.orientation = 'row';
            btns.alignChildren = ['center', 'center'];
            btns.alignment = ['center', 'top'];

            var btnCancel = btns.add('button', undefined, getLabel('btnCancel'), { name: 'cancel' });
            var btnOK = btns.add('button', undefined, getLabel('btnOK'), { name: 'ok' });

            var result = {
                ok: false,
                activeMode: 'process',
                doRemoveSameAnchors: false,
                doRemoveAnchors: false,
                doRemoveHandles: false,
                convertMode: 'smooth'
            };

            btnOK.onClick = function () {
                result.ok = true;
                result.activeMode = getActiveMode();
                result.doRemoveSameAnchors = cbSameAnchors.value;
                result.doRemoveAnchors = cbAnchors.value;
                result.doRemoveHandles = cbHandle.value;
                result.convertMode = getSelectedConvertMode();
                saveDialogLocation(dlg);
                dlg.close(1);
            };
            btnCancel.onClick = function () {
                saveDialogLocation(dlg);
                dlg.close(0);
            };

            dlg.show();
            return result;
        }

        // --- 変換・分割ロジック ---
        function convertToCorner(pathItem) {
            var points = pathItem.pathPoints;
            for (var k = 0; k < points.length; k++) {
                var pt = points[k];
                pt.pointType = PointType.CORNER;
                pt.leftDirection = pt.anchor;
                pt.rightDirection = pt.anchor;
            }
        }

        function convertToSmooth(pathItem) {
            var points = pathItem.pathPoints;
            for (var k = 0; k < points.length; k++) {
                var pt = points[k];
                pt.pointType = PointType.SMOOTH;

                // クローズドパスは循環参照、オープンパス端点は片側だけを参照する
                var anchor = pt.anchor;
                var isClosed = !!pathItem.closed;
                var prevPt = null;
                var nextPt = null;

                if (isClosed || k > 0) {
                    prevPt = points[(k - 1 + points.length) % points.length];
                }
                if (isClosed || k < points.length - 1) {
                    nextPt = points[(k + 1) % points.length];
                }

                var dPrev = prevPt ? Math.sqrt(
                    Math.pow(prevPt.anchor[0] - anchor[0], 2) +
                    Math.pow(prevPt.anchor[1] - anchor[1], 2)
                ) : 0;
                var dNext = nextPt ? Math.sqrt(
                    Math.pow(nextPt.anchor[0] - anchor[0], 2) +
                    Math.pow(nextPt.anchor[1] - anchor[1], 2)
                ) : 0;

                var lenLeft = dPrev / 3;
                var lenRight = dNext / 3;

                var angleFactor = 1;
                var balanceFactor = 1;

                var prevVecX = prevPt ? (prevPt.anchor[0] - anchor[0]) : 0;
                var prevVecY = prevPt ? (prevPt.anchor[1] - anchor[1]) : 0;
                var nextVecX = nextPt ? (nextPt.anchor[0] - anchor[0]) : 0;
                var nextVecY = nextPt ? (nextPt.anchor[1] - anchor[1]) : 0;

                // 前後アンカーが同一点または極端に近い場合の 0 除算を防ぐ
                var EPS = 1e-6;
                var hasPrev = dPrev > EPS;
                var hasNext = dNext > EPS;

                var dirX = 1;
                var dirY = 0;

                if (hasPrev && hasNext) {
                    var tVecX = nextVecX / dNext - prevVecX / dPrev;
                    var tVecY = nextVecY / dNext - prevVecY / dPrev;
                    var tLen = Math.sqrt(tVecX * tVecX + tVecY * tVecY);

                    if (tLen < 0.0001) {
                        dirX = nextVecX / dNext;
                        dirY = nextVecY / dNext;
                    } else {
                        dirX = tVecX / tLen;
                        dirY = tVecY / tLen;
                    }
                } else if (hasNext) {
                    dirX = nextVecX / dNext;
                    dirY = nextVecY / dNext;
                } else if (hasPrev) {
                    dirX = -prevVecX / dPrev;
                    dirY = -prevVecY / dPrev;
                }

                // 鋭角や前後距離の偏りが大きい場合は、ハンドル長を少しだけ抑える
                if (hasPrev && hasNext) {
                    var inDirX = -prevVecX / dPrev;
                    var inDirY = -prevVecY / dPrev;
                    var outDirX = nextVecX / dNext;
                    var outDirY = nextVecY / dNext;

                    var dot = inDirX * outDirX + inDirY * outDirY;
                    if (dot < -1) dot = -1;
                    if (dot > 1) dot = 1;

                    var turnAngle = Math.acos(dot);
                    var angleNorm = turnAngle / Math.PI; // 0..1
                    angleFactor = 1 - (0.35 * angleNorm);

                    var minLen = Math.min(dPrev, dNext);
                    var maxLen = Math.max(dPrev, dNext);
                    var imbalance = (maxLen > EPS) ? (1 - (minLen / maxLen)) : 0; // 0..1
                    balanceFactor = 1 - (0.25 * imbalance);
                }

                lenLeft *= angleFactor * balanceFactor;
                lenRight *= angleFactor * balanceFactor;

                // 8方向へ丸めず、計算した接線方向をそのまま使う
                pt.leftDirection = [
                    anchor[0] - dirX * lenLeft,
                    anchor[1] - dirY * lenLeft
                ];
                pt.rightDirection = [
                    anchor[0] + dirX * lenRight,
                    anchor[1] + dirY * lenRight
                ];
            }
        }

        function convertPathItem(item, mode) {
            var func = (mode === 'smooth') ? convertToSmooth : convertToCorner;
            if (item.typename === 'PathItem') {
                func(item);
            } else if (item.typename === 'CompoundPathItem') {
                for (var i = 0; i < item.pathItems.length; i++) {
                    func(item.pathItems[i]);
                }
            } else if (item.typename === 'GroupItem') {
                for (var j = 0; j < item.pageItems.length; j++) {
                    convertPathItem(item.pageItems[j], mode);
                }
            }
        }

        function splitAtAnchors(pathItem) {
            var pts = pathItem.pathPoints;
            if (pts.length < 2) return;

            var parent = pathItem.layer;
            var segCount = pathItem.closed ? pts.length : pts.length - 1;

            for (var s = 0; s < segCount; s++) {
                var idx1 = s;
                var idx2 = (s + 1) % pts.length;
                var p1 = pts[idx1];
                var p2 = pts[idx2];

                var newPath = parent.pathItems.add();
                newPath.closed = false;
                newPath.filled = pathItem.filled;
                newPath.fillColor = pathItem.fillColor;
                newPath.stroked = pathItem.stroked;
                if (pathItem.stroked) {
                    newPath.strokeColor = pathItem.strokeColor;
                    newPath.strokeWidth = pathItem.strokeWidth;
                }

                var np1 = newPath.pathPoints.add();
                np1.anchor = p1.anchor;
                np1.leftDirection = p1.anchor;
                np1.rightDirection = p1.rightDirection;
                np1.pointType = p1.pointType;

                var np2 = newPath.pathPoints.add();
                np2.anchor = p2.anchor;
                np2.leftDirection = p2.leftDirection;
                np2.rightDirection = p2.anchor;
                np2.pointType = p2.pointType;
            }

            pathItem.remove();
        }

        function splitItem(item) {
            if (item.typename === 'PathItem') {
                splitAtAnchors(item);
            } else if (item.typename === 'CompoundPathItem') {
                var paths = [];
                for (var i = 0; i < item.pathItems.length; i++) {
                    paths.push(item.pathItems[i]);
                }
                for (var ii = 0; ii < paths.length; ii++) {
                    splitAtAnchors(paths[ii]);
                }
            } else if (item.typename === 'GroupItem') {
                var items = [];
                for (var j = 0; j < item.pageItems.length; j++) {
                    items.push(item.pageItems[j]);
                }
                for (var jj = 0; jj < items.length; jj++) {
                    splitItem(items[jj]);
                }
            }
        }

        // ダイアログ表示時点の選択を確定（予測と実行を同一対象に揃える）
        var selectionAtOpen = getSelectionOrAlert();
        if (!selectionAtOpen) return;
        var targetsAtOpen = getTargetPathItemsFromSelection(selectionAtOpen);

        var ui = showDialog(targetsAtOpen);
        if (!ui.ok) return;

        // タブindex依存だと ScriptUI 環境差で誤判定しうるため、明示状態で分岐する
        if (ui.activeMode === 'other') {
            // --- その他タブ: 変換・分割処理 ---
            var currentSelection = selectionAtOpen.slice(0);
            if (ui.convertMode === 'add') {
                app.executeMenuCommand('Add Anchor Points2');
            } else if (ui.convertMode === 'split') {
                for (var n = 0; n < currentSelection.length; n++) {
                    splitItem(currentSelection[n]);
                }
            } else {
                for (var n = 0; n < currentSelection.length; n++) {
                    if (!currentSelection[n]) continue;
                    convertPathItem(currentSelection[n], ui.convertMode);
                }
            }
        } else {
            // --- 削除対象タブ: クリーンアップ処理 ---
            var targetsAtOk = targetsAtOpen;

            if (!ui.doRemoveSameAnchors && !ui.doRemoveAnchors && !ui.doRemoveHandles) {
                return;
            }

            // 実行順：重複アンカー → 冗長アンカー → ハンドル → 冗長アンカー → 重複アンカー
            if (ui.doRemoveSameAnchors) {
                removeDuplicateAnchorsOnTargets(targetsAtOk);
            }
            if (ui.doRemoveAnchors) {
                removeRedundantAnchorsOnTargets(targetsAtOk);
            }
            if (ui.doRemoveHandles) {
                removeRedundantHandlesOnTargets(targetsAtOk);
            }
            if (ui.doRemoveAnchors) {
                removeRedundantAnchorsOnTargets(targetsAtOk);
            }
            if (ui.doRemoveSameAnchors) {
                removeDuplicateAnchorsOnTargets(targetsAtOk);
            }
        }
    })();

})();
