#target illustrator
app.preferences.setBooleanPreference('ShowExternalJSXWarning', false);

/*

### 概要

ドキュメントに登録されているシンボルを一覧から選び、選択したオブジェクトをそのシンボルインスタンスへ置き換えます。

詳細は README を参照してください。

### Overview

Picks a symbol from the ones registered in the document and replaces the selected objects with instances of it.

See the README for details.

*/

// =========================================
// 基本情報 / Basic info
// =========================================
var SCRIPT_NAME     = "シンボルに置き換え-sw";        /* スクリプト名 / script name */
var SCRIPT_VERSION  = "v0.5.0";                       /* バージョン / version */
var SCRIPT_AUTHOR   = "Toshiyuki Takahashi";          /* 作者 / author */
var SCRIPT_MODIFIED = "Masahiro Takano (@swwwitch)";  /* 改変 / modified by */
var SCRIPT_RELEASED = "";                             /* 最初のリリース日 / first release date */
var SCRIPT_UPDATED  = "";                             /* 更新日 / last updated */

var SCRIPT_README_JA = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/シンボルに置き換え-sw.md"; /* README（日本語） */
var SCRIPT_README_EN = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/シンボルに置き換え-sw.md"; /* README (English) */

// Released under the MIT license
// http://opensource.org/licenses/mit-license.php

/**
 * @author Toshiyuki Takahashi
 * @discussion http://www.graphicartsunit.com/
 */

(function () {

	var SCRIPT_TITLE = 'シンボルに置き換え';
	var SCRIPT_VERSION = '0.5.0';

	var MAX_VISIBLE_SYMBOLS = 20;
	var RADIO_ROW_HEIGHT = 20;
	var SLOW_SELECTION_THRESHOLD = 20;
	var ERROR_PREFIX = 'エラーが発生して処理を実行できませんでした\nエラー内容：';

	// Settings
	var settings = {
		'symbolIndex': 0
	};

	var activeDoc = app.activeDocument;
	var activeLayer = activeDoc.activeLayer;
	var selectedItems = activeDoc.selection;
	var documentSymbols = activeDoc.symbols;
	var symbolEntries = getSortedSymbolEntries(documentSymbols);
	if (symbolEntries.length > 0) {
		settings.symbolIndex = symbolEntries[0].index;
	}

	if (canRun()) {
		createDialog().show();
	}

	// UI dialog
	// =========================================
	// ローカライズ / Localization
	// =========================================

	/**
	 * 現在のUI言語を判定する
	 * @returns {string} "ja" または "en"
	 */
	function getCurrentLang() {
		return ($.locale.indexOf('ja') === 0) ? 'ja' : 'en';
	}
	var uiLang = getCurrentLang();

	/* カテゴリ分けした日英ラベル定義 / Categorized Japanese-English label definitions */
	var LABELS = {
		panel: {
			symbol: { ja: 'シンボル', en: 'Symbol' }
		},
		button: {
			ok:     { ja: '実行', en: 'Run' },
			cancel: { ja: 'キャンセル', en: 'Cancel' }
		},
		tooltip: {
			symbol: {
				ja: '選択したオブジェクトを、このシンボルのインスタンスに置き換えます。',
				en: 'Replaces the selected objects with an instance of this symbol.'
			}
		}
	};

	/**
	 * ラベルを取得する（ドット区切りキー）
	 * @param {string} labelPath - "panel.symbol" のようなドット区切りキー
	 * @returns {string} 現在のUI言語のラベル（見つからなければキーそのもの）
	 */
	function getLabel(labelPath) {
		var pathKeys = String(labelPath).split('.');
		var labelNode = LABELS;
		for (var i = 0; i < pathKeys.length; i++) {
			labelNode = labelNode[pathKeys[i]];
			if (!labelNode) return labelPath;
		}
		return (labelNode[uiLang] != null) ? labelNode[uiLang] : labelPath;
	}

	/**
	 * 項目名にコロンを付ける（日本語は全角、英語は半角）
	 * @param {string} labelPath - ラベルのドット区切りキー
	 * @returns {string} コロン付きの項目名
	 */
	function labelText(labelPath) {
		return getLabel(labelPath) + (uiLang === 'ja' ? '：' : ': ');
	}

	function createDialog() {
		var window = new Window('dialog', SCRIPT_TITLE + ' - ver.' + SCRIPT_VERSION);

		var symbolPanel = window.add('panel', undefined, labelText('panel.symbol'));
		symbolPanel.alignment = 'left';
		symbolPanel.margins = [15, 20, 15, 10];
		symbolPanel.orientation = 'column';
		symbolPanel.alignChildren = 'left';

		var buttonGroup = window.add('group');
		buttonGroup.alignment = 'center';
		buttonGroup.orientation = 'row';

		var symbolRadios = buildSymbolList(symbolPanel);
		buildButtons(buttonGroup);

		return {
			show: function () { window.show(); }
		};

		function buildSymbolList(parent) {
			var listContainer = parent.add('group');
			listContainer.orientation = 'row';
			listContainer.alignChildren = 'top';
			listContainer.spacing = 4;

			var radioGroup = listContainer.add('group');
			radioGroup.orientation = 'column';
			radioGroup.alignChildren = 'left';
			radioGroup.spacing = 2;

			var visibleCount = Math.min(symbolEntries.length, MAX_VISIBLE_SYMBOLS);
			var radios = [];
			for (var i = 0; i < visibleCount; i++) {
				var entry = symbolEntries[i];
				var radio = radioGroup.add('radiobutton', undefined, entry.name);
				radio.helpTip = getLabel('tooltip.symbol');
				radio.symbolIndex = entry.index;
				radio.value = (entry.index === settings.symbolIndex);
				radio.onClick = onRadioClick;
				radios.push(radio);
			}
			if (radios.length > 0) {
				radios[0].active = true;
			}

			if (symbolEntries.length > MAX_VISIBLE_SYMBOLS) {
				addScrollbar(listContainer, radios);
			}
			return radios;
		}

		function addScrollbar(parent, radios) {
			var maxOffset = symbolEntries.length - MAX_VISIBLE_SYMBOLS;
			var scrollbar = parent.add('scrollbar', undefined, 0, 0, maxOffset);
			scrollbar.preferredSize.width = 16;
			scrollbar.preferredSize.height = RADIO_ROW_HEIGHT * MAX_VISIBLE_SYMBOLS;
			scrollbar.onChanging = function () {
				var offset = Math.round(scrollbar.value);
				for (var idx = 0; idx < radios.length; idx++) {
					var entry = symbolEntries[offset + idx];
					radios[idx].text = entry.name;
					radios[idx].symbolIndex = entry.index;
					radios[idx].value = (entry.index === settings.symbolIndex);
				}
			};
		}

		function buildButtons(parent) {
			var cancelButton = parent.add('button', undefined, getLabel('button.cancel'), { name: 'cancel' });
			var okButton = parent.add('button', undefined, getLabel('button.ok'), { name: 'ok' });

			okButton.onClick = function () {
				try {
					replaceSelectionWithSymbol(false);
					window.close();
				} catch (e) {
					alert(ERROR_PREFIX + e);
				}
			};
			cancelButton.onClick = function () {
				window.close();
			};
		}

		function onRadioClick() {
			try {
				settings.symbolIndex = this.symbolIndex;
				previewReplace();
			} catch (e) {
				alert(ERROR_PREFIX + e);
			}
		}

		function previewReplace() {
			replaceSelectionWithSymbol(true);
			app.redraw();
			app.undo();
		}
	}

	// Pre-flight check before showing the dialog
	function canRun() {
		if (!activeDoc || selectedItems.length < 1) {
			alert('オブジェクトが選択されていません');
			return false;
		}
		if (!activeLayer.visible || activeLayer.locked) {
			alert('選択レイヤーがロックされているか非表示になっています');
			return false;
		}
		if (selectedItems.length > SLOW_SELECTION_THRESHOLD) {
			return confirm(selectedItems.length + '個のオブジェクトが選択されており、処理にとても時間がかかる可能性があります。継続しますか？');
		}
		return true;
	}

	// Main process
	function replaceSelectionWithSymbol(isPreview) {
		var targetItems = toItemArray(selectedItems);
		for (var i = 0; i < targetItems.length; i++) {
			var newSymbolItem = activeLayer.symbolItems.add(documentSymbols[settings.symbolIndex]);
			centerOnTarget(newSymbolItem, targetItems[i]);
			if (isPreview) {
				selectedItems[i].hidden = true;
			} else {
				newSymbolItem.selected = true;
				selectedItems[i].remove();
			}
		}
	}

	// Center the symbol item on the target item's bounding box
	function centerOnTarget(symbolItem, targetItem) {
		var t = targetItem.geometricBounds;
		var s = symbolItem.geometricBounds;
		symbolItem.top = (t[1] + t[3]) / 2 - (s[3] - s[1]) / 2;
		symbolItem.left = (t[0] + t[2]) / 2 - (s[2] - s[0]) / 2;
	}

	// Convert a collection (selection / PageItems) to a plain Array
	function toItemArray(collection) {
		var items = [];
		for (var i = 0; i < collection.length; i++) {
			items.push(collection[i]);
		}
		return items;
	}

	// Build {name, index} entries sorted by name (case-insensitive)
	function getSortedSymbolEntries(symbolCollection) {
		var entries = [];
		for (var i = 0; i < symbolCollection.length; i++) {
			entries.push({ name: symbolCollection[i].name, index: i });
		}
		entries.sort(function (a, b) {
			var an = a.name.toLowerCase();
			var bn = b.name.toLowerCase();
			if (an < bn) return -1;
			if (an > bn) return 1;
			return 0;
		});
		return entries;
	}
}());
