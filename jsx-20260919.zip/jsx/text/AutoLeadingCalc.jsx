#target illustrator
app.preferences.setBooleanPreference('ShowExternalJSXWarning', false);

/*

### 概要

選択したテキストの現在の行送り（絶対値）とフォントサイズから行送り％を逆算し、それを自動行送り量（％）として設定します。
これにより、以後は常に自動行送りとして扱われます。

詳細は README を参照してください。

### Overview

Derives the leading percentage from the current absolute leading and font size of the selected text and stores it as the auto-leading percentage.
From then on the text uses auto leading.

See the README for details.

*/

// =========================================
// 基本情報 / Basic info
// =========================================
var SCRIPT_NAME     = "AutoLeadingCalc";              /* スクリプト名 / script name */
var SCRIPT_VERSION  = "v1.0.1";                       /* バージョン / version */
var SCRIPT_AUTHOR   = "Masahiro Takano (@swwwitch)";  /* 作者 / author */
var SCRIPT_RELEASED = "";                             /* 最初のリリース日 / first release date */
var SCRIPT_UPDATED  = "2026-09-19";                             /* 更新日 / last updated */

var SCRIPT_README_JA = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/AutoLeadingCalc.md"; /* README（日本語） */
var SCRIPT_README_EN = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/AutoLeadingCalc.md"; /* README (English) */

// Released under the MIT license
// http://opensource.org/licenses/mit-license.php

(function () {

    var isJa = ($.locale.indexOf("ja") === 0);
    /* 言語に応じた文字列 / Pick a string for the current UI language */
    function getLabel(ja, en) { return isJa ? ja : en; }

    /* 型名を安全に取得 / Safely resolve a type name */
    function getTypeName(obj) {
        if (obj === null || obj === undefined) return "";
        if (obj.typename) return obj.typename;
        try { return obj.constructor ? obj.constructor.name : ""; } catch (e) { return ""; }
    }

    /* 親をたどって TextFrame を返す / Walk up parents to the enclosing TextFrame */
    function findParentTextFrame(item) {
        for (var i = 0; i < 20 && item; i++) {
            if (getTypeName(item) === "TextFrame") return item;
            try { item = item.parent; } catch (e) { return null; }
        }
        return null;
    }

    /* 選択から処理対象の TextFrame を収集（グループは再帰、テキスト編集中の範囲は親フレームへ）
       Collect processable TextFrames from the selection (recurse groups; range → parent frame) */
    function collectTextFrames(item, frames) {
        if (!item) return;
        var typeName = getTypeName(item);
        if (typeName === "TextFrame") {
            if (item.contents && item.lines && item.lines.length > 0) frames.push(item);
        } else if (typeName === "GroupItem" && item.pageItems) {
            for (var i = 0; i < item.pageItems.length; i++) collectTextFrames(item.pageItems[i], frames);
        } else {
            collectTextFrames(findParentTextFrame(item), frames);
        }
    }

    /* 範囲が触れている段落（段落全体）を対象配列へ追加 / Add the full paragraphs the range touches */
    function collectParagraphs(range, paragraphTargets) {
        try {
            var paragraphs = range.paragraphs;
            for (var i = 0; i < paragraphs.length; i++) paragraphTargets.push(paragraphs[i]);
        } catch (e) { }
    }

    /* 1段落へ、その段落の現在の行送り（絶対値）÷サイズから % を逆算して自動行送りを適用
       Apply auto-leading to one paragraph by back-calculating the % from its absolute leading ÷ size */
    function applyAutoLeadingToParagraph(paragraph) {
        if (!paragraph.characters || paragraph.characters.length === 0) return;
        try {
            var charAttr = paragraph.characters[0].characterAttributes;
            var sizePt = charAttr.size;
            var leadingPt = charAttr.leading;
            if (isNaN(sizePt) || sizePt <= 0 || isNaN(leadingPt)) return;
            var percent = Math.round((leadingPt / sizePt) * 100 * 10) / 10;
            paragraph.paragraphAttributes.autoLeadingAmount = percent;
            paragraph.characterAttributes.autoLeading = true;
        } catch (e) { }
    }

    function main() {
        if (app.documents.length === 0) {
            alert(getLabel("ドキュメントを開いてください。", "Please open a document."));
            return;
        }

        var selection = app.activeDocument.selection;
        var paragraphTargets = []; // 対象の段落範囲 / Target paragraph ranges
        var typeFrames = [];       // leadingType を設定するフレーム / Frames to set leadingType on

        if (getTypeName(selection) === "TextRange") {
            // テキスト編集モード：選択が触れている段落だけを対象（一部の文字選択でも段落全体に適用）
            // Text-edit mode: target only the paragraphs the selection touches (partial char selection → whole paragraph)
            collectParagraphs(selection, paragraphTargets);
            var editFrame = findParentTextFrame(selection);
            if (editFrame) typeFrames.push(editFrame);
        } else {
            // 選択ツール：選択したフレーム（グループ内含む）の全段落を対象
            // Selection tool: target every paragraph of the selected frames (including those inside groups)
            var frames = [];
            var items = selection || [];
            for (var i = 0; i < items.length; i++) collectTextFrames(items[i], frames);
            for (var f = 0; f < frames.length; f++) {
                collectParagraphs(frames[f].textRange, paragraphTargets);
                typeFrames.push(frames[f]);
            }
        }

        if (paragraphTargets.length === 0) {
            alert(getLabel("テキストが選択されていません。", "No text is selected."));
            return;
        }

        // 段落ごとに現在の行送りから % を逆算して自動行送りを適用 / Apply auto-leading per paragraph
        for (var t2 = 0; t2 < paragraphTargets.length; t2++) applyAutoLeadingToParagraph(paragraphTargets[t2]);
        // 基準は仮想ボディの上に固定（フレーム単位）/ Fix the leading basis to the top of the virtual body (per frame)
        for (var g = 0; g < typeFrames.length; g++) {
            try { typeFrames[g].textRange.leadingType = AutoLeadingType.TOPTOTOP; } catch (e) { }
        }
        app.redraw();
    }

    main();

})();
