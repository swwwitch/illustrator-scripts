#target illustrator
app.preferences.setBooleanPreference('ShowExternalJSXWarning', false);

/*

### 概要

選択したテキストの各文字に対して、ベースライン・比率・回転・カーニング・トラッキングをランダムに付与します。
seed付きの乱数でプレビューの見た目を安定させ、文字回転を適用したときはトラッキングを自動補正します。

詳細は README を参照してください。

### Overview

Randomizes the baseline shift, scale, rotation, kerning and tracking of each character in the selected text.
A seeded RNG keeps the preview stable, and the tracking is corrected automatically when character rotation is applied.

See the README for details.

*/

// =========================================
// 基本情報 / Basic info
// =========================================
var SCRIPT_NAME     = "AutoTouchType";                /* スクリプト名 / script name */
var SCRIPT_VERSION  = "v1.2.8";                       /* バージョン / version */
var SCRIPT_AUTHOR   = "Masahiro Takano (@swwwitch)";  /* 作者 / author */
var SCRIPT_RELEASED = "2026-02-16";                   /* 最初のリリース日 / first release date */
var SCRIPT_UPDATED  = "2026-09-19";                   /* 更新日 / last updated */

var SCRIPT_README_JA = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/AutoTouchType.md"; /* README（日本語） */
var SCRIPT_README_EN = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/AutoTouchType.md"; /* README (English) */

// Released under the MIT license
// http://opensource.org/licenses/mit-license.php

(function () {

    function getCurrentLang() {
        return ($.locale.indexOf("ja") === 0) ? "ja" : "en";
    }
    var uiLang = getCurrentLang();

    /* 日英ラベル定義 / Japanese-English label definitions */
    var LABELS = {
        dialogTitle: { ja: "オート文字タッチツール", en: "Auto Touch Type Tool" },
        alertNoDoc: { ja: "ドキュメントが開かれていません。", en: "No document is open." },
        alertSelectText: { ja: "テキストを選択してください。", en: "Please select text." },
        alertSelectTextRange: { ja: "TextFrame または TextRange を選択してください。", en: "Please select a TextFrame or TextRange." },
        alertEnterNumber: { ja: "数値を入力してください。", en: "Please enter a number." },
        alertNoJPFonts: { ja: "対象の和文フォント（Pr6 / Pr6N）が見つかりません。", en: "No target JP fonts (Pr6 / Pr6N) were found." },
        labelBaseline: { ja: "ベースライン", en: "Baseline" },
        labelScale: { ja: "水平／垂直比率", en: "Scale" },
        labelRotation: { ja: "文字回転", en: "Rotation" },
        labelKerning: { ja: "カーニング", en: "Kerning" },
        panelTouch: { ja: "文字タッチ", en: "Touch" },
        panelFont: { ja: "フォント", en: "Font" },
        chkFontRandom: { ja: "ランダム", en: "Random" },
        chkFontJPOnly: { ja: "和文フォントに限定", en: "Japanese only" },
        chkFontRansom: { ja: "「犯行声明文」風", en: "Ransom-note style" },
        panelRansom: { ja: "「犯行声明文」風", en: "Ransom-note style" },
        chkRansomEnable: { ja: "有効", en: "Enable" },
        chkRansomTrack: { ja: "トラッキング調整", en: "Adjust tracking" },
        btnRerun: { ja: "ランダム", en: "Random" },
        btnReset: { ja: "リセット", en: "Reset" },
        btnAllOn: { ja: "すべてON", en: "All ON" },
        btnAllOff: { ja: "すべてOFF", en: "All OFF" },
        btnCancel: { ja: "キャンセル", en: "Cancel" },
        btnOK: { ja: "OK", en: "OK" },
        labelZoom: { ja: "ズーム", en: "Zoom" },
        chkZoomLight: { ja: "軽量モード", en: "Light mode" },
        chkRotTrackComp: { ja: "文字回転によるトラッキング補正", en: "Tracking compensation for rotation" },
        tipFontRandom: { ja: "1文字ずつフォントを入れ替えます。", en: "Swaps the font of each character." },
        tipFontJPOnly: { ja: "入れ替え先を和文フォント（Pr6／Pr6N）だけに絞ります。", en: "Limits the replacement fonts to Japanese fonts (Pr6 / Pr6N)." },
        tipRansomEnable: { ja: "1文字ずつ大きさと書体をばらつかせ、切り貼りしたような見た目にします。", en: "Varies the size and typeface of each character, like letters cut from a magazine." },
        tipRansomTrack: { ja: "ばらついた文字幅に合わせて字間を詰めます。", en: "Tightens the spacing to match the varied character widths." },
        tipRansomTrackValue: { ja: "詰める量です。単位は1/1000em。", en: "How much to tighten, in 1/1000 em." },
        tipBaselineEnabled: { ja: "ベースラインシフトをかけるかどうかです。", en: "Whether to apply a baseline shift." },
        tipBaseline: { ja: "1文字ずつ上下にずらす最大量です。", en: "Maximum amount each character is shifted up or down." },
        tipScaleEnabled: { ja: "文字を長体・平体にするかどうかです。", en: "Whether to condense or extend the characters." },
        tipScale: { ja: "1文字ずつ変える水平／垂直比率の最大量です。", en: "Maximum change applied to each character\u0027s horizontal and vertical scale." },
        tipKerningEnabled: { ja: "字間をばらつかせるかどうかです。", en: "Whether to vary the spacing between characters." },
        tipKerning: { ja: "1文字ずつ変える字間の最大量です。単位は1/1000em。", en: "Maximum spacing change per character, in 1/1000 em." },
        tipRotationEnabled: { ja: "文字を回転させるかどうかです。", en: "Whether to rotate the characters." },
        tipRotation: { ja: "1文字ずつ回転させる最大角度です。", en: "Maximum rotation applied to each character." },
        tipRotTrackComp: { ja: "回転で広がった見た目の幅を、字間で打ち消します。", en: "Offsets the apparent width added by the rotation with the letter spacing." },
        tipAllOn: { ja: "文字タッチの4項目をすべてオンにします。", en: "Turns on all four touch settings." },
        tipAllOff: { ja: "文字タッチの4項目をすべてオフにします。", en: "Turns off all four touch settings." },
        tipZoom: { ja: "作業中の画面表示倍率を変えます。結果には影響しません。", en: "Changes the view zoom while you work. It does not affect the result." },
        tipZoomLight: { ja: "プレビューを簡易表示にして、文字数が多くても操作を軽くします。", en: "Simplifies the preview so long text stays responsive." },
        tipRerun: { ja: "同じ設定のまま、乱数だけ振り直します。", en: "Re-rolls the randomness while keeping the same settings." },
        tipReset: { ja: "すべての設定を初期値に戻します。", en: "Restores every setting to its default." }
    };

    function getLabel(key) {
        var entry = LABELS[key];
        if (!entry) return key;
        return entry[uiLang] || entry.ja || entry.en || key;
    }

    /* コロン付きの項目名を返す（日本語は全角、英語は半角） / Return a label with a colon */
    function labelText(key) {
        return getLabel(key) + (uiLang === "ja" ? "：" : ": ");
    }

    // =========================================
    // 単位 / Units
    // =========================================

    /* 単位テーブル（配列の添字が rulerType コードと一致：0=in, 1=mm, 2=pt …）/ Unit table; the array index equals the rulerType code */
    var UNITS = [
        { label: "in",    pointsPerUnit: 72 },                /* 0 */
        { label: "mm",    pointsPerUnit: 72 / 25.4 },         /* 1 */
        { label: "pt",    pointsPerUnit: 1 },                 /* 2 */
        { label: "pica",  pointsPerUnit: 12 },                /* 3 */
        { label: "cm",    pointsPerUnit: 72 / 2.54 },         /* 4 */
        { label: "Q",     pointsPerUnit: 72 / 25.4 * 0.25 },  /* 5 */
        { label: "px",    pointsPerUnit: 1 },                 /* 6 */
        { label: "ft/in", pointsPerUnit: 72 * 12 },           /* 7 */
        { label: "m",     pointsPerUnit: 72 / 25.4 * 1000 },  /* 8 */
        { label: "yd",    pointsPerUnit: 72 * 36 },           /* 9 */
        { label: "ft",    pointsPerUnit: 72 * 12 }            /* 10 */
    ];

    /* Q ではなく H と表示する設定キー / Preference keys that display H instead of Q */
    var HA_UNIT_PREF_KEYS = { "rulerType": true, "strokeUnits": true, "text/asianunits": true };

    /**
     * 設定キーごとの単位情報を取得する
     * @param {string} prefKey - 環境設定キー（省略時は "rulerType"）
     * @returns {{code: number, label: string, pointsPerUnit: number}} 単位情報
     */
    function getUnitInfo(prefKey) {
        var unitKey = prefKey || "rulerType";
        var unitCode = app.preferences.getIntegerPreference(unitKey);
        var unit = UNITS[unitCode] || UNITS[2];
        var label = (unitCode === 5 && HA_UNIT_PREF_KEYS[unitKey]) ? "H" : unit.label;
        return { code: unitCode, label: label, pointsPerUnit: unit.pointsPerUnit };
    }

    if (app.documents.length === 0) { alert(getLabel("alertNoDoc")); return; }
    var doc = app.activeDocument;
    if (!doc.selection || doc.selection.length === 0) { alert(getLabel("alertSelectText")); return; }

    // --- view zoom helpers (used by Zoom slider) ---
    function _getSelectionBounds(sel) {
        var left = sel[0].visibleBounds[0];
        var top = sel[0].visibleBounds[1];
        var right = sel[0].visibleBounds[2];
        var bottom = sel[0].visibleBounds[3];
        for (var i = 1; i < sel.length; i++) {
            var b = sel[i].visibleBounds;
            if (b[0] < left) left = b[0];
            if (b[1] > top) top = b[1];
            if (b[2] > right) right = b[2];
            if (b[3] < bottom) bottom = b[3];
        }
        return [left, top, right, bottom];
    }

    function _getBoundsCenter(b) {
        return [b[0] + (b[2] - b[0]) / 2, b[1] + (b[3] - b[1]) / 2];
    }

    function _clampZoomFactor(z) {
        if (z < 0.0313) z = 0.0313;
        if (z > 640.0) z = 640.0;
        return z;
    }

    function _applyZoom(view, percentage, centerPoint, doRedraw) {
        var zoomFactor = _clampZoomFactor(percentage / 100.0);
        try { view.zoom = zoomFactor; } catch (e) { }
        try { if (centerPoint) view.centerPoint = centerPoint; } catch (e) { }
        if (doRedraw !== false) {
            app.redraw();
        }
    }

    var __view = null;
    var __originalZoom = null;
    var __originalCenter = null;
    var __zoomTargetCenter = null;
    try {
        __view = doc.views[0];
        __originalZoom = __view.zoom;
        __originalCenter = __view.centerPoint;
        try {
            var __sel0 = doc.selection;
            if (__sel0 && __sel0.length > 0) {
                __zoomTargetCenter = _getBoundsCenter(_getSelectionBounds(__sel0));
            }
        } catch (e) { }
        if (!__zoomTargetCenter) __zoomTargetCenter = __originalCenter;
    } catch (e) { }

    function restoreViewIfNeeded() {
        try {
            if (!__view) return;
            if (__originalZoom != null) __view.zoom = __originalZoom;
            if (__originalCenter) __view.centerPoint = __originalCenter;
            app.redraw();
        } catch (e) { }
    }

    // --- manifesto style backgrounds (per-character rects via outline) ---
    var BG_LAYER_NAME = '__AutoTouchType_BG__';
    var BG_GROUP_NAME = '__BGRects__';

    function getSelectionTextFrames(selection) {
        var frames = [];
        if (!selection || selection.length === 0) return frames;

        function pushUnique(tf) {
            if (!tf || tf.typename !== 'TextFrame') return;
            for (var k = 0; k < frames.length; k++) {
                if (frames[k] === tf) return;
            }
            frames.push(tf);
        }

        for (var i = 0; i < selection.length; i++) {
            try {
                var it = selection[i];
                if (!it) continue;

                if (it.typename === 'TextFrame') {
                    pushUnique(it);
                } else if (it.typename === 'TextRange') {
                    // selected text inside a text frame
                    try {
                        var p = it.parent;
                        if (p && p.typename === 'TextFrame') pushUnique(p);
                        else if (p && p.parent && p.parent.typename === 'TextFrame') pushUnique(p.parent);
                    } catch (e) { }
                }
            } catch (e) { }
        }
        return frames;
    }

    function ensureBgLayer() {
        var lyr = null;
        try {
            for (var i = 0; i < doc.layers.length; i++) {
                try {
                    if (doc.layers[i].name === BG_LAYER_NAME) { lyr = doc.layers[i]; break; }
                } catch (e) { }
            }
        } catch (e) { }
        if (!lyr) {
            try { lyr = doc.layers.add(); lyr.name = BG_LAYER_NAME; } catch (e) { }
        }
        return lyr;
    }

    function removeBgGroupIfExists(bgLayer) {
        if (!bgLayer) return;
        try {
            for (var i = bgLayer.groupItems.length - 1; i >= 0; i--) {
                if (bgLayer.groupItems[i].name === BG_GROUP_NAME) bgLayer.groupItems[i].remove();
            }
        } catch (e) { }
    }

    function randInt(min, max) { return Math.floor(Math.random() * (max - min + 1)) + min; }

    function makeRandomFill() {
        var g = new GrayColor();
        g.gray = randInt(10, 50);
        return g;
    }

    function setRectStyle(rect) {
        try { rect.stroked = false; rect.filled = true; rect.fillColor = makeRandomFill(); } catch (e) { }
    }

    function jitterRectOutward(rect, maxPt) {
        if (!rect || rect.typename !== 'PathItem') return;
        if (!rect.pathPoints || rect.pathPoints.length < 4) return;
        var b;
        try { b = rect.geometricBounds; } catch (e) { return; }
        var cx = (b[0] + b[2]) / 2;
        var cy = (b[1] + b[3]) / 2;
        for (var i = 0; i < rect.pathPoints.length; i++) {
            try {
                var pp = rect.pathPoints[i];
                var ax = pp.anchor[0], ay = pp.anchor[1];
                var dx = ax - cx;
                var dy = ay - cy;
                var len = Math.sqrt(dx * dx + dy * dy);
                if (!len) continue;
                var d = Math.random() * maxPt;
                var ox = (dx / len) * d;
                var oy = (dy / len) * d;
                pp.anchor = [ax + ox, ay + oy];
                pp.leftDirection = [pp.leftDirection[0] + ox, pp.leftDirection[1] + oy];
                pp.rightDirection = [pp.rightDirection[0] + ox, pp.rightDirection[1] + oy];
            } catch (e) { }
        }
    }

    function addRectFromBounds(bgGroup, b) {
        var PAD = 1;
        var L = b[0] - PAD;
        var T = b[1] + PAD;
        var R = b[2] + PAD;
        var B = b[3] - PAD;
        var w = R - L;
        var h = T - B;
        if (w <= 0 || h <= 0) return null;
        var rect = bgGroup.pathItems.rectangle(T, L, w, h);
        setRectStyle(rect);
        jitterRectOutward(rect, 1);
        return rect;
    }

    function collectCharGroupsFromOutlined(outlined, out) {
        if (!outlined) return;

        function pushLeafUnits(container) {
            try {
                if (!container || !container.pageItems) return;
                for (var k = 0; k < container.pageItems.length; k++) {
                    var it = container.pageItems[k];
                    if (!it) continue;
                    if (it.typename === 'GroupItem') pushLeafUnits(it);
                    else if (it.typename === 'PathItem' || it.typename === 'CompoundPathItem') out.push(it);
                }
            } catch (e) { }
        }

        try {
            if (outlined.typename === 'GroupItem') {
                var hasPushed = false;
                if (outlined.groupItems && outlined.groupItems.length > 0) {
                    for (var i = 0; i < outlined.groupItems.length; i++) {
                        var g1 = outlined.groupItems[i];
                        if (!g1 || g1.typename !== 'GroupItem') continue;
                        if (g1.groupItems && g1.groupItems.length > 0) {
                            for (var j = 0; j < g1.groupItems.length; j++) { out.push(g1.groupItems[j]); hasPushed = true; }
                        } else { out.push(g1); hasPushed = true; }
                    }
                }
                if (hasPushed) return;
                pushLeafUnits(outlined);
                if (out.length > 0) return;
                out.push(outlined);
                return;
            }
            out.push(outlined);
        } catch (e) { }
    }

    function createBackgroundRectsByOutlining(frames) {
        if (!frames || frames.length === 0) return;
        var bgLayer = ensureBgLayer();
        removeBgGroupIfExists(bgLayer);
        var bgGroup = bgLayer.groupItems.add();
        bgGroup.name = BG_GROUP_NAME;

        for (var i = 0; i < frames.length; i++) {
            var tf = frames[i];
            if (!tf || tf.typename !== 'TextFrame') continue;
            var dup = null;
            var outlined = null;
            try {
                dup = tf.duplicate();
                try { dup.move(tf, ElementPlacement.PLACEAFTER); } catch (e) { }
            } catch (e) { continue; }
            try { outlined = dup.createOutline(); } catch (e) { try { if (dup) dup.remove(); } catch (e) { } continue; }
            try { if (dup) dup.remove(); } catch (e) { }

            var charGroups = [];
            collectCharGroupsFromOutlined(outlined, charGroups);
            for (var j = 0; j < charGroups.length; j++) {
                try { addRectFromBounds(bgGroup, charGroups[j].geometricBounds); } catch (e) { }
            }
            try { if (outlined) outlined.remove(); } catch (e) { }
        }

        try { bgGroup.zOrder(ZOrderMethod.SENDTOBACK); } catch (e) { }
        try { bgLayer.zOrder(ZOrderMethod.SENDTOBACK); } catch (e) { }
    }

    function clearBackgroundRectsIfAny() {
        var lyr = null;
        try {
            for (var i = 0; i < doc.layers.length; i++) {
                if (doc.layers[i] && doc.layers[i].name === BG_LAYER_NAME) { lyr = doc.layers[i]; break; }
            }
        } catch (e) { }
        if (!lyr) return;
        removeBgGroupIfExists(lyr);
    }

    // --- font cache (for Font panel) ---
    var __allFonts = null;
    try { __allFonts = app.textFonts; } catch (e) { __allFonts = null; }

    // Japanese font detection (updated; based on reference script)
    function hasJapaneseCharacters(str) {
        try {
            if (!str) return false;
            var japanesePattern = /[\u3040-\u309F\u30A0-\u30FF\u4E00-\u9FFF]/;
            return japanesePattern.test(String(str));
        } catch (e) {
            return false;
        }
    }

    function isJapaneseFont(font) {
        if (!font) return false;
        var fontName = "";
        var fontFamily = "";
        var fontFull = "";
        var fontPS = "";
        try { fontName = font.name ? String(font.name) : ""; } catch (e) { fontName = ""; }
        try { fontFamily = font.family ? String(font.family) : ""; } catch (e) { fontFamily = ""; }
        try { fontFull = font.fullName ? String(font.fullName) : ""; } catch (e) { fontFull = ""; }
        try { fontPS = font.postScriptName ? String(font.postScriptName) : ""; } catch (e) { fontPS = ""; }

        // Explicit exclusions (Latin / unintended Gothic variants)
        var _deny = [
            "Apple LiGothic",
            "RyoGothicStd",
            "-KO", "-KL", "LogoArl",
            "Kana"
        ];
        for (var di = 0; di < _deny.length; di++) {
            var dn = _deny[di];
            if (!dn) continue;
            if (fontName.indexOf(dn) !== -1) return false;
            if (fontFamily.indexOf(dn) !== -1) return false;
            if (fontFull.indexOf(dn) !== -1) return false;
            if (fontPS.indexOf(dn) !== -1) return false;
        }

        // Direct Japanese-character hit in any identifier
        if (hasJapaneseCharacters(fontName) || hasJapaneseCharacters(fontFamily) || hasJapaneseCharacters(fontFull)) {
            return true;
        }

        // Keyword-based heuristic (JP families + common JP font brands)
        var jpKeywords = [
            "ゴシック", "明朝", "丸ゴ", "教科書", "楷書",
            "Mincho", "Maru",
            "Hiragino", "ヒラギノ",
            "Yu Gothic", "Yu Mincho", "游ゴシック", "游明朝",
            "Meiryo", "メイリオ",
            "MS Gothic", "MS Mincho", "MS ゴシック", "MS 明朝",
            "Kozuka", "小塚",
            "Morisawa", "モリサワ",
            "Ryumin", "Shin Go", "新ゴ",
            "Heisei", "平成",
            "Klee", "クレー",
            "Tsukushi", "筑紫",
            "A-OTF", "AP-OTF ", "-OTF",
            "FOT", "Pr6N", "Pr6",
            "Noto Sans JP", "Noto Serif JP",
            "Source Han", "源ノ角", "源ノ明",
            "Min2"
        ];

        for (var i = 0; i < jpKeywords.length; i++) {
            var k = jpKeywords[i];
            if (!k) continue;
            if (fontName.indexOf(k) !== -1) return true;
            if (fontFamily.indexOf(k) !== -1) return true;
            if (fontFull.indexOf(k) !== -1) return true;
            if (fontPS.indexOf(k) !== -1) return true;
        }

        return false;
    }

    function getJPFonts() {
        var list = [];
        if (!__allFonts) return list;
        for (var i = 0; i < __allFonts.length; i++) {
            try {
                var f = __allFonts[i];
                if (!f) continue;
                if (isJapaneseFont(f)) list.push(f);
            } catch (e) { }
        }
        return list;
    }

    // JP font cache (heavy to build; reuse)
    var __jpFontsCache = null;
    function getJPFontsCached() {
        if (__jpFontsCache) return __jpFontsCache;
        __jpFontsCache = getJPFonts();
        return __jpFontsCache;
    }

    function collectTextRanges(selection) {
        var list = [];
        for (var i = 0; i < selection.length; i++) {
            var it = selection[i];
            if (!it) continue;
            if (it.typename === "TextRange") list.push(it);
            else if (it.typename === "TextFrame") list.push(it.textRange);
        }
        return list;
    }

    function selectionContainsNonAlnum(ranges) {
        if (!ranges || ranges.length === 0) return false;
        for (var i = 0; i < ranges.length; i++) {
            var tr = ranges[i];
            if (!tr) continue;
            try {
                var txt = tr.contents;
                for (var j = 0; j < txt.length; j++) {
                    var ch = txt.charAt(j);
                    if (!(/[A-Za-z0-9]/.test(ch))) {
                        if (ch === '\r' || ch === '\n') continue;
                        return true;
                    }
                }
            } catch (e) { }
        }
        return false;
    }

    function getKerningSafe(ch) {
        try {
            var k = ch.kerning; // may throw (e.g. Error 9551)
            return (typeof k === "number") ? k : 0;
        } catch (e) {
            return 0;
        }
    }

    var ranges = collectTextRanges(doc.selection);
    var selTextFrames = getSelectionTextFrames(doc.selection);
    if (ranges.length === 0) { alert(getLabel("alertSelectTextRange")); return; }

    // --- PreviewManager (No-Undo preview) ---
    // Goal: avoid History jumping back on every preview update.
    // Strategy:
    // - Preview updates simply overwrite character attributes (no undo).
    // - Cancel restores the original snapshot.
    // - OK applies final once (overwrites again) and closes.
    function PreviewManager() {
        this._hasPreview = false;
    }

    PreviewManager.prototype.addStep = function (fn) {
        if (typeof fn !== 'function') return;
        try { fn(); } catch (e) { }
        this._hasPreview = true;
    };

    PreviewManager.prototype.cancel = function () {
        if (!this._hasPreview) return;
        try { restoreOriginals(); } catch (e) { }
        this._hasPreview = false;
    };

    PreviewManager.prototype.confirm = function (fnFinal) {
        // No undo needed; simply apply final overwrite once.
        if (typeof fnFinal === 'function') {
            try { fnFinal(); } catch (e) { }
        }
        this._hasPreview = false;
    };

    var previewMgr = new PreviewManager();

    // Close reason flag: prevent onClose cleanup on successful OK
    var __closedByOK = false;

    // If Reset was executed and no new preview was generated, OK should not re-randomize.
    var __didReset = false;

    // --- snapshot originals (per character) ---
    // we store kerning and tracking as well
    var originals = []; // { ch, baselineShift, hScale, vScale, rotation, kerning, tracking, textFont }
    function snapshotOriginals() {
        originals = [];
        for (var r = 0; r < ranges.length; r++) {
            var tr = ranges[r];
            for (var c = 0; c < tr.length; c++) {
                var ch = tr.characters[c];
                var ca = ch.characterAttributes;
                // Some attributes may not exist in very old versions; assume present
                originals.push({
                    ch: ch,
                    baselineShift: ca.baselineShift,
                    hScale: ca.horizontalScale, // %
                    vScale: ca.verticalScale,   // %
                    rotation: ca.rotation,      // degrees
                    kerning: getKerningSafe(ch),
                    tracking: (typeof ca.tracking === "number") ? ca.tracking : 0,
                    textFont: ca.textFont
                });
            }
        }
    }

    function restoreOriginals() {
        for (var i = 0; i < originals.length; i++) {
            var ca = originals[i].ch.characterAttributes;
            ca.baselineShift = originals[i].baselineShift;
            ca.horizontalScale = originals[i].hScale;
            ca.verticalScale = originals[i].vScale;
            ca.rotation = originals[i].rotation;
            try {
                ca.kerningMethod = AutoKernType.NOAUTOKERN;
                originals[i].ch.kerning = originals[i].kerning;
            } catch (e) {
                // ignore if not supported
            }
            try {
                ca.tracking = originals[i].tracking;
            } catch (e) {
                // not all Illustrator versions expose tracking writable; ignore error
            }
            try {
                if (originals[i].textFont) ca.textFont = originals[i].textFont;
            } catch (e) {
                // ignore if not supported
            }
        }
    }

    // --- tracking compensation for per-character rotation ---
    // Based on the attached reference script: "Compensate Text Character Rotation with Tracking"
    // When per-character rotation is applied, the perceived spacing becomes uneven.
    // This logic calculates and applies tracking values to compensate for the gaps.

    function __calcTrackingCompSpacing(deg, content) {
        var rad = deg * (Math.PI / 180);
        var sine = Math.sin(rad);
        var absSine = Math.abs(sine);

        // GAP AFTER (Current Character)
        var factorAfter = (deg > 0) ? 680 : 1050;
        var valCurr = absSine * factorAfter * -1;

        // GAP BEFORE (Previous Character)
        var factorBefore = 180;
        var valPrev = sine * factorBefore * -1;

        // CASE CORRECTION (uppercase)
        try {
            if (content && content === content.toUpperCase() && content !== content.toLowerCase()) {
                valPrev = valPrev * 0.6;
                valCurr = valCurr * 1.05;
            }
        } catch (e) { }

        return { prev: valPrev, curr: valCurr };
    }

    function __getCharRotationDegSafe(ch) {
        var rot = 0;
        try {
            // Some builds expose character.rotation
            if (typeof ch.rotation === "number") return ch.rotation;
        } catch (e) { }
        try {
            // Our script sets characterAttributes.rotation
            if (ch && ch.characterAttributes && typeof ch.characterAttributes.rotation === "number") {
                return ch.characterAttributes.rotation;
            }
        } catch (e) { }
        try {
            // Legacy fallback
            if (typeof ch.characterRotation === "number") return ch.characterRotation;
        } catch (e) { }
        return rot;
    }

    function __applyTrackingCompForTextRange(tr) {
        if (!tr) return;
        var chars;
        try { chars = tr.characters; } catch (e) { chars = null; }
        if (!chars) return;

        var count = 0;
        try { count = chars.length; } catch (e) { count = 0; }
        if (count <= 1) return;

        var trackingMods = [];
        for (var k = 0; k < count; k++) trackingMods[k] = 0;

        // PASS 1: calculate forces
        for (var i = 0; i < count; i++) {
            var curChar = chars[i];
            if (!curChar) continue;

            var rot = __getCharRotationDegSafe(curChar);
            if (Math.abs(rot) > 1.0) {
                var ct = "";
                try { ct = curChar.contents; } catch (e) { ct = ""; }
                var vals = __calcTrackingCompSpacing(rot, ct);

                trackingMods[i] += vals.curr;
                if (i > 0) trackingMods[i - 1] += vals.prev;
            }
        }

        // PASS 2: apply values
        for (var j = 0; j < count; j++) {
            if (Math.abs(trackingMods[j]) > 0.5) {
                try {
                    // skip line breaks to avoid odd behavior
                    var _ct2 = "";
                    try { _ct2 = chars[j].contents; } catch (e) { _ct2 = ""; }
                    if (_ct2 === "\r" || _ct2 === "\n") continue;

                    // Set tracking directly (overrides existing tracking for a uniform look)
                    if (chars[j] && chars[j].characterAttributes) chars[j].characterAttributes.tracking = trackingMods[j];
                    else chars[j].tracking = trackingMods[j];
                } catch (e) { }
            }
        }
    }

    function __applyTrackingCompForRanges(rangesList) {
        if (!rangesList || rangesList.length === 0) return;
        for (var r = 0; r < rangesList.length; r++) {
            try { __applyTrackingCompForTextRange(rangesList[r]); } catch (e) { }
        }
    }

    // --- seeded RNG for stable preview ---
    function makeRng(seed) {
        var s = seed >>> 0;
        return function () {
            s = (1664525 * s + 1013904223) >>> 0;
            return s / 4294967296;
        };
    }
    function randSym(rng) { return rng() * 2.0 - 1.0; } // -1..1

    // maxAbsPt: baseline shift amplitude in pt
    // maxAbsHPct: scale amplitude in percent (e.g. 10 => 90..110)
    // maxAbsVPct: vertical scale amplitude
    // maxAbsDeg: rotation amplitude in degrees
    // maxAbsKern: kerning amplitude (/1000em units)
    // maxAbsTrk: tracking amplitude (/1000em units)
    function applyRandom(maxAbsPt, maxAbsHPct, maxAbsVPct, linkScale, maxAbsDeg, maxAbsKern, maxAbsTrk, seed, optFont) {
        var rng = makeRng(seed);

        optFont = optFont || {};
        var _doFontRandom = !!optFont.fontRandom;
        var _jpOnly = !!optFont.jpOnly;
        var _ransomTrack = (optFont.ransomTrack !== false); // デフォルトtrue扱い
        var _ransom = !!optFont.ransom;

        var _previewRansomTracking = !!optFont.previewRansomTracking;

        var _fontList = null;
        if (_doFontRandom) {
            _fontList = _jpOnly ? optFont.jpFonts : optFont.allFonts;
            if (!_fontList || _fontList.length === 0) _doFontRandom = false;
        }

        for (var i = 0; i < originals.length; i++) {
            var ca = originals[i].ch.characterAttributes;

            // font
            if (_doFontRandom) {
                try {
                    // skip whitespace / line breaks
                    var _ct = originals[i].ch.contents;
                    if (!(_ct === "\r" || _ct === "\n" || _ct === " ")) {
                        var idx = Math.floor(rng() * _fontList.length);
                        ca.textFont = _fontList[idx];
                    }
                } catch (e) { }
            }

            // baseline
            ca.baselineShift = randSym(rng) * maxAbsPt;

            // rotation (added to original rotation)
            ca.rotation = originals[i].rotation + (randSym(rng) * maxAbsDeg);

            // scale multipliers
            if (linkScale) {
                var m = 1.0 + (randSym(rng) * (maxAbsHPct / 100.0));
                ca.horizontalScale = originals[i].hScale * m;
                ca.verticalScale = originals[i].vScale * m;
            } else {
                var mh = 1.0 + (randSym(rng) * (maxAbsHPct / 100.0));
                var mv = 1.0 + (randSym(rng) * (maxAbsVPct / 100.0));
                ca.horizontalScale = originals[i].hScale * mh;
                ca.verticalScale = originals[i].vScale * mv;
            }

            // kerning
            try {
                ca.kerningMethod = AutoKernType.NOAUTOKERN;
                originals[i].ch.kerning = originals[i].kerning + (randSym(rng) * maxAbsKern);
            } catch (e) {
                // ignore if not supported
            }

            // tracking
            // - If ransom tracking is enabled (or preview-only ransom tracking), honor the fixed value.
            // - Otherwise, keep the baseline behavior here, then (optionally) apply rotation compensation after the loop.
            try {
                var baseTracking = originals[i].tracking;

                if ((_ransom && _ransomTrack) || _previewRansomTracking) {

                    var addVal = (typeof optFont.ransomTrackValue === "number") ? optFont.ransomTrackValue : 200;

                    // 文字回転によるトラッキング補正がONのときは、
                    // 既存（現在の）トラッキング値に加算する
                    if (optFont && optFont.rotTrackComp !== false) {
                        ca.tracking = baseTracking + addVal;
                    } else {
                        // 補正OFF時は従来どおり固定値として扱う
                        ca.tracking = addVal;
                    }

                } else {
                    ca.tracking = baseTracking + (randSym(rng) * maxAbsTrk);
                }
            } catch (e) {
                // ignore if not supported
            }
        }

        // If rotation was applied, compensate tracking to visually tighten spacing.
        // Do NOT override when ransom tracking is explicitly in control.
        // Can be disabled by UI via optFont.rotTrackComp.
        try {
            var __rotationApplied = (typeof maxAbsDeg === "number" && Math.abs(maxAbsDeg) > 0.0001);
            var __compEnabled = !(optFont && optFont.rotTrackComp === false); // default ON
            if (__rotationApplied && __compEnabled && !((_ransom && _ransomTrack) || _previewRansomTracking)) {
                __applyTrackingCompForRanges(ranges);
            }
        } catch (e) { }

        // Redraw can be expensive; allow callers (preview) to control it
        if (!(optFont && optFont.noRedraw === true)) {
            app.redraw();
        }
    }

    function parseNum(str) {
        var v = parseFloat(str);
        if (isNaN(v)) return null;
        return v;
    }

    snapshotOriginals();
    var seed = (new Date()).getTime() & 0xffffffff;

    // Ensure any previous BG artifacts are cleared at start
    try { clearBackgroundRectsIfAny(); } catch (e) { }

    // --- UI ---
    var w = new Window("dialog", getLabel("dialogTitle") + " " + SCRIPT_VERSION);
    // --- dialog position persistence ---
    var __dlgPrefKeyX = "AutoTouchType/dialogX";
    var __dlgPrefKeyY = "AutoTouchType/dialogY";

    try {
        var __savedX = app.preferences.getIntegerPreference(__dlgPrefKeyX);
        var __savedY = app.preferences.getIntegerPreference(__dlgPrefKeyY);
        if (!isNaN(__savedX) && !isNaN(__savedY)) {
            w.location = [__savedX, __savedY];
        }
    } catch (e) { }
    /* ダイアログの位置と透明度 / Dialog position & opacity */
    var dialogOpacity = 0.98;

    function setDialogOpacity(dlg, opacityValue) {
        try {
            dlg.opacity = opacityValue;
        } catch (e) {
            // some environments may not support opacity
        }
    }
    w.orientation = "column";
    w.alignChildren = ["fill", "top"];

    // --- panel: 文字タッチ ---
    var pnlTouch = w.add("panel", undefined, getLabel("panelTouch"));
    pnlTouch.orientation = "column";
    pnlTouch.alignChildren = ["fill", "top"];
    pnlTouch.margins = [15, 20, 15, 10];

    // --- Font area: horizontal layout ---
    var gFontRow = w.add("group");
    gFontRow.orientation = "row";
    gFontRow.alignChildren = ["fill", "top"];

    // --- panel: フォント ---
    var pnlFont = gFontRow.add("panel", undefined, getLabel("panelFont"));
    pnlFont.orientation = "column";
    pnlFont.alignChildren = ["left", "top"];
    pnlFont.margins = [15, 20, 15, 10];
    pnlFont.alignment = ["fill", "top"];

    var chkFontRandom = pnlFont.add("checkbox", undefined, getLabel("chkFontRandom"));
    chkFontRandom.helpTip = getLabel("tipFontRandom");
    var chkFontJPOnly = pnlFont.add("checkbox", undefined, getLabel("chkFontJPOnly"));
    chkFontJPOnly.helpTip = getLabel("tipFontJPOnly");

    function updateFontOptionEnabled() {
        // 「ランダム」がOFFのときは「和文フォントに限定」をディム
        try {
            var en = !!(chkFontRandom && chkFontRandom.value);
            if (chkFontJPOnly) {
                chkFontJPOnly.enabled = en;
                if (!en) chkFontJPOnly.value = false; // OFF時は強制的にチェック解除
            }
        } catch (e) { }
    }

    // --- panel: 「犯行声明文」風 ---
    var pnlRansom = gFontRow.add("panel", undefined, getLabel("panelRansom"));
    pnlRansom.orientation = "column";
    pnlRansom.alignChildren = ["left", "top"];
    pnlRansom.margins = [15, 20, 15, 10];
    pnlRansom.alignment = ["fill", "top"];

    var chkFontRansom = pnlRansom.add("checkbox", undefined, getLabel("chkRansomEnable"));
    chkFontRansom.helpTip = getLabel("tipRansomEnable");

    // tracking row: checkbox + value field
    var gRansomTrk = pnlRansom.add("group");
    gRansomTrk.orientation = "row";
    gRansomTrk.alignChildren = ["left", "center"];

    var chkRansomTrack = gRansomTrk.add("checkbox", undefined, getLabel("chkRansomTrack"));
    chkRansomTrack.helpTip = getLabel("tipRansomTrack");
    var edtRansomTrk = gRansomTrk.add("edittext", undefined, "200");
    edtRansomTrk.helpTip = getLabel("tipRansomTrackValue");
    edtRansomTrk.characters = 5;

    // defaults: OFF
    chkFontRandom.value = false;
    chkFontJPOnly.value = false;
    chkFontRansom.value = false;

    updateFontOptionEnabled();

    chkRansomTrack.value = true;      // 既存挙動（tracking固定）を維持するためデフォルトON
    chkRansomTrack.enabled = false;   // 「有効」がOFFの間はディム
    edtRansomTrk.enabled = false;     // 「有効」+「トラッキング調整」ONのときだけ有効

    function autoEnableJPOnlyIfNeeded() {
        try {
            if (selectionContainsNonAlnum(ranges)) {
                if (chkFontJPOnly && chkFontJPOnly.enabled) chkFontJPOnly.value = true;
            }
        } catch (e) { }
    }

    // Auto ON: if selection includes non-alnum (except CR/LF), enable JP-only
    autoEnableJPOnlyIfNeeded();

    var gBase = pnlTouch.add("group");
    var chkBase = gBase.add("checkbox", undefined, "");
    chkBase.helpTip = getLabel("tipBaselineEnabled");
    chkBase.value = true;
    chkBase.preferredSize.width = 15;
    var stBase = gBase.add("statictext", undefined, labelText("labelBaseline"));
    /* ベースラインの単位は環境設定の「文字」の単位に従う / The baseline unit follows the "text/asianunits" preference */
    var baseUnit = getUnitInfo("text/asianunits");
    var __baseUnitLabel = baseUnit.label;
    var __baseUnitFactorPt = baseUnit.pointsPerUnit;

    var defaultBasePt = 0;
    try {
        if (originals.length > 0) {
            var fs = originals[0].ch.characterAttributes.size;
            defaultBasePt = Math.round(fs / 12);
        }
    } catch (e) { }

    var defaultBase = 0; // displayed unit value
    try {
        defaultBase = Math.round(defaultBasePt / __baseUnitFactorPt);
        if (isNaN(defaultBase)) defaultBase = 0;
    } catch (e) { defaultBase = defaultBasePt; }

    // slider range: max = current text size (pt), expressed in current unit
    var __baseMaxPt = 50;
    try {
        if (originals.length > 0) {
            var __fsPt = originals[0].ch.characterAttributes.size; // pt
            __baseMaxPt = Math.max(1, Math.round(__fsPt));
        }
    } catch (e) { __baseMaxPt = 50; }

    var __baseMax = 50;
    try {
        __baseMax = Math.max(1, Math.round(__baseMaxPt / __baseUnitFactorPt));
    } catch (e) { __baseMax = 50; }

    var edtBase = gBase.add("edittext", undefined, String(defaultBase));
    edtBase.characters = 4;
    edtBase.helpTip = getLabel("tipBaseline");
    var stUnitBase = gBase.add("statictext", undefined, __baseUnitLabel);
    var sldBase = gBase.add("slider", undefined, defaultBase, 0, __baseMax);
    sldBase.preferredSize.width = 180;
    sldBase.helpTip = getLabel("tipBaseline");

    var gH = pnlTouch.add("group");
    var chkScale = gH.add("checkbox", undefined, "");
    chkScale.helpTip = getLabel("tipScaleEnabled");
    chkScale.value = true;
    chkScale.preferredSize.width = 15;
    var stH = gH.add("statictext", undefined, labelText("labelScale"));
    var edtH = gH.add("edittext", undefined, "10");
    edtH.characters = 4;
    edtH.helpTip = getLabel("tipScale");
    var stUnitH = gH.add("statictext", undefined, "%");
    var sldH = gH.add("slider", undefined, 10, 0, 200);
    sldH.preferredSize.width = 180;
    sldH.helpTip = getLabel("tipScale");

    var gKern = pnlTouch.add("group");
    var chkKern = gKern.add("checkbox", undefined, "");
    chkKern.helpTip = getLabel("tipKerningEnabled");
    chkKern.value = true;
    chkKern.preferredSize.width = 15;
    var stKern = gKern.add("statictext", undefined, labelText("labelKerning"));
    var edtKern = gKern.add("edittext", undefined, "50");
    edtKern.characters = 4;
    edtKern.helpTip = getLabel("tipKerning");
    var stUnitKern = gKern.add("statictext", undefined, "/1000em");
    var sldKern = gKern.add("slider", undefined, 50, -200, 200);
    sldKern.preferredSize.width = 180;
    sldKern.helpTip = getLabel("tipKerning");

    var gRot = pnlTouch.add("group");
    var chkRot = gRot.add("checkbox", undefined, "");
    chkRot.helpTip = getLabel("tipRotationEnabled");
    chkRot.value = true;
    chkRot.preferredSize.width = 15;
    var stRot = gRot.add("statictext", undefined, labelText("labelRotation"));
    var edtRot = gRot.add("edittext", undefined, "5");
    edtRot.characters = 4;
    edtRot.helpTip = getLabel("tipRotation");
    var stUnitRot = gRot.add("statictext", undefined, "°");
    var sldRot = gRot.add("slider", undefined, 5, 0, 30);
    sldRot.preferredSize.width = 180;
    sldRot.helpTip = getLabel("tipRotation");

    // --- buttons inside 文字タッチ panel (bottom) ---
    // 2 columns: left = All ON/OFF, right = rotation tracking compensation toggle
    var gTouchButtons = pnlTouch.add("group");
    gTouchButtons.orientation = "row";
    gTouchButtons.alignChildren = ["fill", "center"];
    gTouchButtons.alignment = "fill";
    gTouchButtons.margins = [0, 10, 0, 0];

    var gTouchLeft = gTouchButtons.add("group");
    gTouchLeft.orientation = "row";
    gTouchLeft.alignChildren = ["left", "center"];

    var btnAllOn = gTouchLeft.add("button", undefined, getLabel("btnAllOn"));
    btnAllOn.helpTip = getLabel("tipAllOn");
    var btnAllOff = gTouchLeft.add("button", undefined, getLabel("btnAllOff"));
    btnAllOff.helpTip = getLabel("tipAllOff");

    var gTouchSpacer = gTouchButtons.add("group");
    gTouchSpacer.orientation = "row";
    gTouchSpacer.add("statictext", undefined, "");
    gTouchSpacer.alignment = "fill";

    var gTouchRight = gTouchButtons.add("group");
    gTouchRight.orientation = "row";
    gTouchRight.alignChildren = ["right", "center"];

    var chkRotTrackComp = gTouchRight.add("checkbox", undefined, getLabel("chkRotTrackComp"));
    chkRotTrackComp.helpTip = getLabel("tipRotTrackComp");
    chkRotTrackComp.value = true; // default ON

    // Make these utility buttons slightly smaller
    try {
        var __smallBtn = [72, 22]; // [width, height]
        btnAllOn.preferredSize = __smallBtn;
        btnAllOff.preferredSize = __smallBtn;
    } catch (e) { }

    // --- label width align (left) ---
    try {
        var labels = [stBase, stH, stKern, stRot];
        var maxW = 0;
        for (var i = 0; i < labels.length; i++) {
            try {
                var w0 = labels[i].preferredSize.width;
                if (w0 > maxW) maxW = w0;
            } catch (e) { }
        }
        for (var j = 0; j < labels.length; j++) {
            try {
                labels[j].preferredSize.width = maxW;
                // left align
                labels[j].justify = "left";
            } catch (e) { }
        }
    } catch (e) { }

    // --- unit width align (left) ---
    try {
        var units = [stUnitBase, stUnitH, stUnitKern, stUnitRot];
        var maxU = 0;
        for (var ui = 0; ui < units.length; ui++) {
            try {
                var uw = units[ui].preferredSize.width;
                if (uw > maxU) maxU = uw;
            } catch (e) { }
        }
        for (var uj = 0; uj < units.length; uj++) {
            try {
                units[uj].preferredSize.width = maxU;
                units[uj].justify = "left";
            } catch (e) { }
        }
    } catch (e) { }

    // --- slider <-> edit sync ---
    function clamp(v, minV, maxV) {
        if (v < minV) return minV;
        if (v > maxV) return maxV;
        return v;
    }
    function syncFromEdit(edt, sld) {
        var v = parseNum(edt.text);
        if (v === null) return;
        sld.value = clamp(v, sld.minvalue, sld.maxvalue);
    }
    function syncFromSlider(sld, edt) {
        edt.text = String(Math.round(sld.value));
    }

    // --- arrow key increment for edittext ---
    function changeValueByArrowKey(editText) {
        editText.addEventListener("keydown", function (event) {
            if (!(event && (event.keyName === "Up" || event.keyName === "Down"))) return;

            var value = Number(editText.text);
            if (isNaN(value)) return;

            var keyboard = ScriptUI.environment.keyboardState;
            var delta = 1;

            if (keyboard.shiftKey) {
                delta = 10;
                // Shiftキー押下時は10の倍数にスナップ
                if (event.keyName === "Up") {
                    value = Math.ceil((value + 1) / delta) * delta;
                } else {
                    value = Math.floor((value - 1) / delta) * delta;
                }
            } else if (keyboard.altKey) {
                delta = 0.1;
                // Optionキー押下時は0.1単位で増減
                if (event.keyName === "Up") value += delta;
                else value -= delta;
            } else {
                delta = 1;
                if (event.keyName === "Up") value += delta;
                else value -= delta;
            }

            if (editText !== edtKern && editText !== edtRansomTrk && value < 0) value = 0;

            event.preventDefault();
            editText.text = String(value);

            // keep slider in sync (if exists)
            try {
                if (editText === edtBase) syncFromEdit(edtBase, sldBase);
                else if (editText === edtH) syncFromEdit(edtH, sldH);
                else if (editText === edtRot) syncFromEdit(edtRot, sldRot);
                else if (editText === edtKern) syncFromEdit(edtKern, sldKern);
            } catch (e) { }

            // preview update
            try { updatePreview(); } catch (e) { }
        });
    }

    // --- zoom row (UI only; logic will be added later) ---
    var gZoom = w.add("group");
    gZoom.orientation = "row";
    gZoom.alignChildren = ["center", "center"];
    gZoom.margins = [0, 0, 0, 0];

    var stZoom = gZoom.add("statictext", undefined, labelText("labelZoom"));
    var __initZoomPct = 100;
    try { if (__originalZoom != null) __initZoomPct = Math.round(__originalZoom * 100); } catch (e) { }
    if (__initZoomPct < 10) __initZoomPct = 10;
    if (__initZoomPct > 1600) __initZoomPct = 1600;
    var sldZoom = gZoom.add("slider", undefined, __initZoomPct, 10, 1600);
    sldZoom.helpTip = getLabel("tipZoom");
    sldZoom.preferredSize.width = 270;

    var chkZoomLight = gZoom.add("checkbox", undefined, getLabel("chkZoomLight"));
    chkZoomLight.helpTip = getLabel("tipZoomLight");
    chkZoomLight.value = false;

    // NOTE: applying zoom on every `onChanging` can be heavy.
    // Two modes:
    // - Normal: throttle updates during dragging
    // - Light mode: apply only once on release
    var __zoomLastApply = 0;
    var __zoomThrottleMs = 150;

    function __applyZoomFromSlider(valPct) {
        try {
            if (!__view) return;
            var pct = Math.round(valPct);
            if (pct < 10) pct = 10;
            if (pct > 1600) pct = 1600;
            _applyZoom(__view, pct, __zoomTargetCenter, true);
        } catch (e) { }
    }

    sldZoom.onChanging = function () {
        try {
            if (chkZoomLight && chkZoomLight.value) {
                // light mode: do nothing while dragging
                return;
            }

            var now = (new Date()).getTime();
            if (now - __zoomLastApply < __zoomThrottleMs) return;
            __zoomLastApply = now;

            __applyZoomFromSlider(this.value);
        } catch (e) { }
    };

    // Ensure the final value is applied when the drag ends.
    sldZoom.onChange = function () {
        __applyZoomFromSlider(this.value);
    };

    // If toggled while the dialog is open, apply once immediately for consistency.
    chkZoomLight.onClick = function () {
        __applyZoomFromSlider(sldZoom.value);
    };

    // --- bottom buttons (left / spacer / right) ---
    var btnRow = w.add("group");
    btnRow.orientation = "row";
    btnRow.alignChildren = ["fill", "center"];
    btnRow.margins = [0, 15, 0, 0];

    var btnLeft = btnRow.add("group");
    btnLeft.orientation = "row";
    btnLeft.alignChildren = ["left", "center"];

    var btnRerun = btnLeft.add("button", undefined, getLabel("btnRerun"));
    btnRerun.helpTip = getLabel("tipRerun");
    var btnReset = btnLeft.add("button", undefined, getLabel("btnReset"));
    btnReset.helpTip = getLabel("tipReset");

    function isTouchAllOff() {
        try {
            return (!chkBase.value && !chkScale.value && !chkRot.value && !chkKern.value);
        } catch (e) {
            return false;
        }
    }

    function updateRerunEnabled() {
        // 文字タッチがすべてOFF かつ フォント「ランダム」もOFF のときは再実行を無効化
        try {
            var touchOff = isTouchAllOff();
            var fontRandOff = !(chkFontRandom && chkFontRandom.value);
            btnRerun.enabled = !(touchOff && fontRandOff);
        } catch (e) { }
    }

    var btnSpacer = btnRow.add("group");
    btnSpacer.orientation = "row";
    btnSpacer.add("statictext", undefined, "");
    btnSpacer.alignment = "fill";

    var btnRight = btnRow.add("group");
    btnRight.orientation = "row";
    btnRight.alignChildren = ["right", "center"];
    var btnCancel = btnRight.add("button", undefined, getLabel("btnCancel"));
    var btnOK = btnRight.add("button", undefined, getLabel("btnOK"));

    // --- debounced preview (reduce heavy redraw on onChanging/key repeat) ---
    var __pvTaskId = null;
    var __pvDelayMs = 120;

    // scheduleTask needs a global callable string
    $.global.__ATT_doPreview = function () {
        try { __pvTaskId = null; } catch (e) { }
        try { updatePreview(); } catch (e) { }
    };

    function requestPreview() {
        try {
            if (__pvTaskId != null) {
                try { app.cancelTask(__pvTaskId); } catch (e) { }
                __pvTaskId = null;
            }
            __pvTaskId = app.scheduleTask("$.global.__ATT_doPreview()", __pvDelayMs, false);
        } catch (e) {
            // fallback
            try { updatePreview(); } catch (e) { }
        }
    }

    function updatePreview() {
        __didReset = false;
        var base = 0; // in pt
        if (chkBase.value) {
            var __b = parseNum(edtBase.text);
            if (__b === null) return;
            try { base = __b * __baseUnitFactorPt; } catch (e) { base = __b; }
        }

        var hPct = 0;
        if (chkScale.value) { hPct = parseNum(edtH.text); if (hPct === null) return; }

        var rot = 0;
        if (chkRot.value) { rot = parseNum(edtRot.text); if (rot === null) return; }

        var kern = 0;
        if (chkKern.value) { kern = parseNum(edtKern.text); if (kern === null) return; }

        var optFont = {
            fontRandom: (chkFontRandom && chkFontRandom.value),
            jpOnly: (chkFontJPOnly && chkFontJPOnly.value),
            ransom: false, // NOTE: 背景生成などはプレビューしない
            rotTrackComp: (chkRotTrackComp && chkRotTrackComp.value),
            previewRansomTracking: false,
            ransomTrackValue: null,
            allFonts: __allFonts,
            jpFonts: null,
            noRedraw: true
        };

        // Keep UI state as-is, but make it clear via dimming that preview ignores this option
        try { if (chkRotTrackComp) chkRotTrackComp.enabled = true; } catch (e) { }

        if (optFont.fontRandom && optFont.jpOnly) {
            optFont.jpFonts = getJPFontsCached();
            if (!optFont.jpFonts || optFont.jpFonts.length === 0) {
                alert(getLabel('alertNoJPFonts'));
                return;
            }
        }

        // Preview: reflect only ransom tracking fixed value (no background)
        try {
            if (chkFontRansom && chkFontRansom.value && chkRansomTrack && chkRansomTrack.value) {
                optFont.previewRansomTracking = true;
                var __pv = parseNum(edtRansomTrk.text);
                optFont.ransomTrackValue = (typeof __pv === "number" && !isNaN(__pv)) ? __pv : 200;
            }
        } catch (e) { }

        // Apply preview (no undo): overwrite attributes directly
        previewMgr.addStep(function () {
            applyRandom(base, hPct, hPct, true, rot, kern, 0, seed, optFont);
        });
        // One redraw for preview
        app.redraw();
    }

    edtBase.onChanging = function () { syncFromEdit(edtBase, sldBase); requestPreview(); };
    edtH.onChanging = function () { syncFromEdit(edtH, sldH); requestPreview(); };
    edtRot.onChanging = function () { syncFromEdit(edtRot, sldRot); requestPreview(); };
    edtKern.onChanging = function () { syncFromEdit(edtKern, sldKern); requestPreview(); };
    edtRansomTrk.onChanging = function () { try { requestPreview(); } catch (e) { } };

    // Patch arrow key logic to debounce preview
    function changeValueByArrowKey(editText) {
        editText.addEventListener("keydown", function (event) {
            if (!(event && (event.keyName === "Up" || event.keyName === "Down"))) return;

            var value = Number(editText.text);
            if (isNaN(value)) return;

            var keyboard = ScriptUI.environment.keyboardState;
            var delta = 1;

            if (keyboard.shiftKey) {
                delta = 10;
                // Shiftキー押下時は10の倍数にスナップ
                if (event.keyName === "Up") {
                    value = Math.ceil((value + 1) / delta) * delta;
                } else {
                    value = Math.floor((value - 1) / delta) * delta;
                }
            } else if (keyboard.altKey) {
                delta = 0.1;
                // Optionキー押下時は0.1単位で増減
                if (event.keyName === "Up") value += delta;
                else value -= delta;
            } else {
                delta = 1;
                if (event.keyName === "Up") value += delta;
                else value -= delta;
            }

            if (editText !== edtKern && editText !== edtRansomTrk && value < 0) value = 0;

            event.preventDefault();
            editText.text = String(value);

            // keep slider in sync (if exists)
            try {
                if (editText === edtBase) syncFromEdit(edtBase, sldBase);
                else if (editText === edtH) syncFromEdit(edtH, sldH);
                else if (editText === edtRot) syncFromEdit(edtRot, sldRot);
                else if (editText === edtKern) syncFromEdit(edtKern, sldKern);
            } catch (e) { }

            // preview update
            try { requestPreview(); } catch (e) { }
        });
    }
    changeValueByArrowKey(edtBase);
    changeValueByArrowKey(edtH);
    changeValueByArrowKey(edtRot);
    changeValueByArrowKey(edtKern);
    changeValueByArrowKey(edtRansomTrk);

    sldBase.onChanging = function () { syncFromSlider(sldBase, edtBase); requestPreview(); };
    sldH.onChanging = function () { syncFromSlider(sldH, edtH); requestPreview(); };
    sldRot.onChanging = function () { syncFromSlider(sldRot, edtRot); requestPreview(); };
    sldKern.onChanging = function () { syncFromSlider(sldKern, edtKern); requestPreview(); };

    btnOK.onClick = function () {
        var base = 0; // in pt
        if (chkBase.value) {
            var __bOK = parseNum(edtBase.text);
            if (__bOK === null) __bOK = 0;
            try { base = __bOK * __baseUnitFactorPt; } catch (e) { base = __bOK; }
        }

        var hPct = 0;
        if (chkScale.value) hPct = parseNum(edtH.text);

        var rot = 0;
        if (chkRot.value) rot = parseNum(edtRot.text);

        var kern = 0;
        if (chkKern.value) kern = parseNum(edtKern.text);

        // ransom tracking fixed value validation (OK時のみ)
        var __rtv = null;
        try {
            if (chkFontRansom && chkFontRansom.value && chkRansomTrack && chkRansomTrack.value) {
                __rtv = parseNum(edtRansomTrk.text);
                if (__rtv === null) {
                    alert(getLabel("alertEnterNumber"));
                    return;
                }
            }
        } catch (e) { __rtv = null; }

        if ((chkBase.value && base === null) ||
            (chkScale.value && hPct === null) ||
            (chkRot.value && rot === null) ||
            (chkKern.value && kern === null)) {
            alert(getLabel("alertEnterNumber"));
            return;
        }

        var optFont = {
            fontRandom: (chkFontRandom && chkFontRandom.value),
            jpOnly: (chkFontJPOnly && chkFontJPOnly.value),
            ransom: (chkFontRansom && chkFontRansom.value),
            ransomTrack: (chkRansomTrack && chkRansomTrack.value),
            rotTrackComp: (chkRotTrackComp && chkRotTrackComp.value),
            ransomTrackValue: __rtv,
            allFonts: __allFonts,
            jpFonts: null
        };

        if (optFont.fontRandom && optFont.jpOnly) {
            optFont.jpFonts = getJPFontsCached();
            if (!optFont.jpFonts || optFont.jpFonts.length === 0) {
                alert(getLabel('alertNoJPFonts'));
                return;
            }
        }

        // Commit:
        // - If Reset was just executed and there is no preview step applied, do NOT re-randomize.
        // - Otherwise, apply final once.
        if (__didReset && !previewMgr._hasPreview) {
            // no-op for text attributes (keep reset result)
        } else {
            // No-undo preview: do not cancel here; just overwrite with final apply

            var __applied = false;
            try {
                // First try: keep originals order (most stable / matches preview)
                applyRandom(base, hPct, hPct, true, rot, kern, 0, seed, optFont);
                __applied = true;
            } catch (e) {
                __applied = false;
            }

            if (!__applied) {
                try {
                    // Fallback: rebind selection-derived handles after undo
                    ranges = collectTextRanges(doc.selection);
                    selTextFrames = getSelectionTextFrames(doc.selection);
                    snapshotOriginals();
                } catch (e) { }
                try {
                    applyRandom(base, hPct, hPct, true, rot, kern, 0, seed, optFont);
                } catch (e) { }
            }
        }

        // manifesto style: background rects (OK時のみ)
        try {
            if (optFont.ransom) createBackgroundRectsByOutlining(selTextFrames);
            else clearBackgroundRectsIfAny();
        } catch (e) { }

        // prevent onClose cleanup (OK)
        __closedByOK = true;
        __didReset = false;
        // close dialog
        w.close(1);
    };

    btnRerun.onClick = function () {
        __didReset = false;
        // rerun
        try { seed = (new Date()).getTime() & 0xffffffff; } catch (e) { }
        try { requestPreview(); } catch (e) { }
        try { autoEnableJPOnlyIfNeeded(); } catch (e) { }
        try { updateRerunEnabled(); } catch (e) { }
    };

    btnReset.onClick = function () {
        // Reset selected text attributes only (do not touch any checkboxes)
        try { previewMgr.cancel(); } catch (e) { }
        try { previewMgr._hasPreview = false; } catch (e) { }
        try { clearBackgroundRectsIfAny(); } catch (e) { }

        // Reset baseline / scale / rotation / kerning / tracking
        try {
            for (var i = 0; i < originals.length; i++) {
                try {
                    var ch = originals[i].ch;
                    var ca = ch.characterAttributes;

                    // baseline
                    ca.baselineShift = 0;
                    originals[i].baselineShift = 0;

                    // scale
                    ca.horizontalScale = 100;
                    ca.verticalScale = 100;
                    originals[i].hScale = 100;
                    originals[i].vScale = 100;

                    // rotation
                    ca.rotation = 0;
                    originals[i].rotation = 0;

                    // kerning
                    try {
                        ca.kerningMethod = AutoKernType.NOAUTOKERN;
                        ch.kerning = 0;
                        originals[i].kerning = 0;
                    } catch (e) { }

                    // tracking
                    try {
                        ca.tracking = 0;
                        originals[i].tracking = 0;
                    } catch (e) { }

                } catch (e) { }
            }
        } catch (e) { }

        // Set all characters' font to the first character's font
        try {
            var __f0 = null;
            try { if (originals.length > 0) __f0 = originals[0].ch.characterAttributes.textFont; } catch (e) { __f0 = null; }
            if (__f0) {
                for (var fi = 0; fi < originals.length; fi++) {
                    try {
                        var _ct = originals[fi].ch.contents;
                        if (_ct === "\r" || _ct === "\n") continue;
                        var _ca = originals[fi].ch.characterAttributes;
                        _ca.textFont = __f0;
                        originals[fi].textFont = __f0;
                    } catch (e) { }
                }
            }
        } catch (e) { }

        app.redraw();

        // Keep JP-only auto rule consistent (checkbox state may remain as-is)
        try { updateFontOptionEnabled(); } catch (e) { }
        try { autoEnableJPOnlyIfNeeded(); } catch (e) { }
        try { updateRerunEnabled(); } catch (e) { }
        __didReset = true;
    };

    btnCancel.onClick = function () {
        // Cancel: undo preview step (if any) and cleanup BG
        try { previewMgr.cancel(); } catch (e) { }
        try { clearBackgroundRectsIfAny(); } catch (e) { }
        try { restoreViewIfNeeded(); } catch (e) { }
        app.redraw();
        __closedByOK = false;
        w.close(0);
    };

    syncFromEdit(edtBase, sldBase);
    syncFromEdit(edtH, sldH);
    syncFromEdit(edtRot, sldRot);
    syncFromEdit(edtKern, sldKern);

    // Checkbox events: update preview on click
    chkBase.onClick = function () { requestPreview(); updateRerunEnabled(); };
    chkScale.onClick = function () { requestPreview(); updateRerunEnabled(); };
    chkRot.onClick = function () { requestPreview(); updateRerunEnabled(); };
    chkKern.onClick = function () { requestPreview(); updateRerunEnabled(); };
    chkRotTrackComp.onClick = function () { requestPreview(); };

    // 文字タッチ: すべてON / すべてOFF
    btnAllOn.onClick = function () {
        try {
            chkBase.value = true;
            chkScale.value = true;
            chkRot.value = true;
            chkKern.value = true;

        } catch (e) { }
        try { updatePreview(); } catch (e) { }
        try { updateRerunEnabled(); } catch (e) { }
    };

    btnAllOff.onClick = function () {
        try {
            chkBase.value = false;
            chkScale.value = false;
            chkRot.value = false;
            chkKern.value = false;

        } catch (e) { }
        try { updatePreview(); } catch (e) { }
        try { updateRerunEnabled(); } catch (e) { }
    };

    chkFontRandom.onClick = function () {
        updateFontOptionEnabled();
        requestPreview();
        updateRerunEnabled();
    };
    chkFontJPOnly.onClick = function () { requestPreview(); updateRerunEnabled(); };
    chkFontRansom.onClick = function () {
        // NOTE: 犯行声明文風はOK時のみ実行（プレビュー不要）
        try {
            var en = (chkFontRansom && chkFontRansom.value);
            chkRansomTrack.enabled = en;
            edtRansomTrk.enabled = (en && chkRansomTrack && chkRansomTrack.value);
        } catch (e) { }
        try { updateRerunEnabled(); } catch (e) { }
        try { requestPreview(); } catch (e) { }
    };

    chkRansomTrack.onClick = function () {
        try {
            edtRansomTrk.enabled = (chkFontRansom && chkFontRansom.value) && (chkRansomTrack && chkRansomTrack.value);
        } catch (e) { }
        try { requestPreview(); } catch (e) { }
    };

    updatePreview();
    updateRerunEnabled();

    setDialogOpacity(w, dialogOpacity);
    // Safety: if dialog is closed by window manager, treat as cancel
    w.onClose = function () {

        // Save dialog position on close
        try {
            var __loc = w.location;
            if (__loc && __loc.length === 2) {
                app.preferences.setIntegerPreference(__dlgPrefKeyX, Math.round(__loc[0]));
                app.preferences.setIntegerPreference(__dlgPrefKeyY, Math.round(__loc[1]));
            }
        } catch (e) { }

        // If closed via OK, do NOT undo/cleanup (would remove committed BG rects)
        if (__closedByOK) return true;

        try { previewMgr.cancel(); } catch (e) { }
        try { clearBackgroundRectsIfAny(); } catch (e) { }
        try { restoreViewIfNeeded(); } catch (e) { }
        return true;
    };
    w.show();
})();
