#target illustrator
app.preferences.setBooleanPreference('ShowExternalJSXWarning', false);

/*

### 概要

選択したテキストのベースラインシフトを調整します。

詳細は README を参照してください。

### Overview

Adjusts the baseline shift of the selected text.

See the README for details.

*/

// =========================================
// 基本情報 / Basic info
// =========================================
var SCRIPT_NAME     = "SmartBaselineShifter";         /* スクリプト名 / script name */
var SCRIPT_VERSION  = "v2.2.1";                         /* バージョン / version */
var SCRIPT_AUTHOR   = "Masahiro Takano (@swwwitch)";  /* 作者 / author */
var SCRIPT_RELEASED = "2025-07-04";                   /* 最初のリリース日 / first release date */
var SCRIPT_UPDATED  = "2026-09-19";                   /* 更新日 / last updated */

var SCRIPT_README_JA   = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/SmartBaselineShifter.md"; /* README（日本語） */
var SCRIPT_README_EN   = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/SmartBaselineShifter.md"; /* README (English) */
var SCRIPT_ARTICLE_URL = "https://note.com/dtp_tranist/n/n5e41727cf265"; /* 紹介記事 / article URL */

// Released under the MIT license
// http://opensource.org/licenses/mit-license.php

(function () {

    function getCurrentLang() {
        return ($.locale.indexOf("ja") === 0) ? "ja" : "en";
    }
    var uiLang = getCurrentLang();

    var LABELS = {
        dialogTitle: {
            ja: "ベースライン調整 " + SCRIPT_VERSION,
            en: "Adjust Baseline " + SCRIPT_VERSION
        },
        targetCharLabel: {
            ja: "対象文字",
            en: "Target Character"
        },
        baseCharLabel: {
            ja: "基準文字",
            en: "Reference Character"
        },
        okBtnLabel: {
            ja: "調整",
            en: "Adjust"
        },
        adjustBtnLabel: {
            ja: "計算",
            en: "Calculate"
        },
        cancelBtnLabel: {
            ja: "キャンセル",
            en: "Cancel"
        },
        selectFrameMsg: {
            ja: "テキストフレームを選択してください。",
            en: "Select one or more text frames."
        },
        docOpenMsg: {
            ja: "ドキュメントが開かれていません。",
            en: "No document open."
        },
        invalidCharMsg: {
            ja: "対象文字は1文字以上、基準文字は1文字を入力してください。",
            en: "Enter at least one target character and exactly one reference character."
        },
        notFoundMsg: {
            ja: "対象文字が含まれていません。",
            en: "Target character not found."
        },
        errorMsg: {
            ja: "エラー: ",
            en: "Error: "
        },
        resetBtnLabel: {
            ja: "リセット",
            en: "Reset"
        },
        shiftAmountLabel: {
            ja: "シフト量",
            en: "Shift Amount"
        },
        autoPanelTitle: {
            ja: "自動調整（天地）",
            en: "Auto Adjust (Vertical)"
        },
        numericErrorMsg: {
            ja: "シフト量は数値で入力してください。",
            en: "Shift amount must be a number."
        },
        helpTips: {
            targetInput: {
                ja: "ベースラインをシフトする対象文字を入力します。",
                en: "Enter the character(s) to shift."
            },
            shiftInput: {
                ja: "手動で指定するベースラインシフト量（数値）です。",
                en: "Specify the baseline shift amount manually."
            },
            refInput: {
                ja: "基準となる文字を1文字入力します。",
                en: "Enter the reference character (1 character)."
            },
            calBtn: {
                ja: "対象文字と基準文字からシフト量を自動計算します。",
                en: "Calculate shift amount automatically."
            },
            finalOkBtn: {
                ja: "指定したシフト量を確定して適用します。",
                en: "Apply the specified shift amount."
            },
            resetBtn: {
                ja: "選択しているテキストのベースラインシフトを全リセットします。",
                en: "Reset baseline shifts in all text frames."
            }
        }
    };

    /**
     * コロン付きの項目名を返す（日本語は全角、英語は半角）
     * @param {string} key - LABELS のキー
     * @returns {string} コロンを添えたラベル
     */
    function labelText(key) {
        return LABELS[key][uiLang] + (uiLang === "ja" ? "：" : ": ");
    }

    /* =========================================
     * PreviewManager util
     * プレビュー時の履歴管理と一括Undoを制御するクラス
     * - addStep(): 変更を実行してUndo回数をカウント
     * - rollback(): プレビューで行った変更を全てUndo
     * - confirm(finalAction): rollback後に本番処理を1回だけ実行
     * ========================================= */
    function PreviewManager() {
        this.undoDepth = 0;

        this.addStep = function (func) {
            try {
                func();
                this.undoDepth++;
                app.redraw();
            } catch (e) {
                // プレビュー中にアラート連発は邪魔なので黙殺（必要なら一時的にalert復活）
                // alert("Preview Error: " + e);
            }
        };

        this.rollback = function () {
            while (this.undoDepth > 0) {
                try {
                    app.undo();
                } catch (e) {
                    // If undo fails, prevent counter drift
                    this.undoDepth = 0;
                    break;
                }
                this.undoDepth--;
            }
            app.redraw();
        };

        this.confirm = function (finalAction) {
            if (finalAction) {
                this.rollback();
                finalAction();
            } else {
                this.undoDepth = 0;
            }
        };
    }

    /* 言語判定 / Determine language from locale */
    // (Removed old getLang, using getCurrentLang and uiLang variable)

    // 再帰的に選択内のすべての TextFrame を抽出 / Recursively extract all TextFrames in selection
    function getAllTextFrames(selection) {
        var textFrames = [];

        function extractTextFrames(item) {
            if (item.typename === "TextFrame") {
                textFrames.push(item);
            } else if (item.typename === "GroupItem") {
                for (var i = 0; i < item.pageItems.length; i++) {
                    extractTextFrames(item.pageItems[i]);
                }
            }
        }

        for (var i = 0; i < selection.length; i++) {
            extractTextFrames(selection[i]);
        }

        return textFrames;
    }

    /* 単位テーブル（配列の添字が rulerType コードと一致：0=in, 1=mm, 2=pt …）/ Unit table; the array index equals the rulerType code */
    var UNITS = [
        { label: "in",    pointsPerUnit: 72 },                /* 0 */
        { label: "mm",    pointsPerUnit: 72 / 25.4 },         /* 1 */
        { label: "pt",    pointsPerUnit: 1 },                 /* 2 */
        { label: "pica",  pointsPerUnit: 12 },                /* 3 */
        { label: "cm",    pointsPerUnit: 72 / 2.54 },         /* 4 */
        { label: "Q",     pointsPerUnit: 72 / 25.4 * 0.25 },  /* 5 */
        { label: "px",    pointsPerUnit: 1 },                 /* 6 */
        { label: "ft/in", pointsPerUnit: 72 * 12 },           /* 7 */
        { label: "m",     pointsPerUnit: 72 / 25.4 * 1000 },  /* 8 */
        { label: "yd",    pointsPerUnit: 72 * 36 },           /* 9 */
        { label: "ft",    pointsPerUnit: 72 * 12 }            /* 10 */
    ];

    /* 単位コード5を「歯（H）」と表示する環境設定キー。文字サイズ（text/units）だけ「級（Q）」
       Preference keys that show unit code 5 as H; only the type size (text/units) shows Q */
    var HA_UNIT_PREF_KEYS = { "rulerType": true, "strokeUnits": true, "text/asianunits": true };

    /**
     * 設定キーごとの単位情報を取得する
     * @param {string} prefKey - 環境設定キー（省略時は "rulerType"）
     * @returns {{code: number, label: string, pointsPerUnit: number}} 単位情報
     */
    function getUnitInfo(prefKey) {
        var unitKey = prefKey || "rulerType";
        var unitCode = app.preferences.getIntegerPreference(unitKey);
        var unit = UNITS[unitCode] || UNITS[2];
        var label = (unitCode === 5 && HA_UNIT_PREF_KEYS[unitKey]) ? "H" : unit.label;
        return { code: unitCode, label: label, pointsPerUnit: unit.pointsPerUnit };
    }

    /* EditTextで上下キーによる値の増減を実装 / Enable arrow key increment/decrement on EditText */
    function changeValueByArrowKey(editText, allowNegative, targetInput, textFrames, previewMgr) {
        editText.addEventListener("keydown", function (event) {
            var value = Number(editText.text);
            if (isNaN(value)) return;

            var keyboard = ScriptUI.environment.keyboardState;
            var delta = 1;

            if (keyboard.shiftKey) {
                delta = 10;
                if (event.keyName == "Up") {
                    value = Math.ceil((value + 1) / delta) * delta;
                    event.preventDefault();
                } else if (event.keyName == "Down") {
                    value = Math.floor((value - 1) / delta) * delta;
                    event.preventDefault();
                }
            } else if (keyboard.altKey) {
                delta = 0.1;
                if (event.keyName == "Up") {
                    value += delta;
                    event.preventDefault();
                } else if (event.keyName == "Down") {
                    value -= delta;
                    event.preventDefault();
                }
            } else {
                delta = 1;
                if (event.keyName == "Up") {
                    value += delta;
                    event.preventDefault();
                } else if (event.keyName == "Down") {
                    value -= delta;
                    event.preventDefault();
                }
            }

            if (keyboard.altKey) {
                value = Math.round(value * 10) / 10; /* 小数第1位まで / Round to 1 decimal */
            } else {
                value = Math.round(value); /* 整数に丸め / Round to integer */
            }

            if (!allowNegative && value < 0) value = 0;

            event.preventDefault();
            editText.text = value;
            /* プレビュー更新 / Update preview */
            if (typeof previewShiftAll === "function" && targetInput && textFrames) {
                previewShiftAll(targetInput, editText, textFrames, previewMgr || null);
            }
        });
    }

    /* 指定テキストフレームの特定文字にベースラインシフトを適用 / Apply baseline shift to specific characters in a text frame */
    function applyBaselineShiftToChars(textFrame, targetChar, yOffset) {
        var chars = textFrame.textRange.characters;
        for (var j = 0; j < chars.length; j++) {
            var ch = chars[j].contents;
            if (ch && ch === targetChar) {
                chars[j].characterAttributes.baselineShift = -yOffset;
            }
        }
    }

    /* プレビューとして全選択テキストのベースラインシフトを更新 / Preview baseline shift for all selected text */
    function previewShiftAll(targetInput, shiftInput, textFrames, previewMgr) {
        var targetText = targetInput.text;
        var shiftValue = parseFloat(shiftInput.text);
        if (isNaN(shiftValue)) shiftValue = 0;

        if (!previewMgr) {
            // Fallback（通常はshowDialog内から呼ぶのでここには来ない想定）
            if (!targetText) {
                resetBaselineShift(textFrames);
                app.redraw();
                return;
            }
            applyShiftAll(targetText, shiftValue, textFrames);
            app.redraw();
            return;
        }

        // Always rollback previous preview first
        previewMgr.rollback();

        if (!targetText) {
            // Nothing to preview
            return;
        }

        previewMgr.addStep(function () {
            applyShiftAll(targetText, shiftValue, textFrames);
        });
    }

    /* ベースラインシフトを適用（共通処理） / Apply baseline shift (shared) */
    function applyShiftAll(targetText, shiftValue, textFrames) {
        resetBaselineShift(textFrames);

        for (var j = 0; j < textFrames.length; j++) {
            var tf = textFrames[j];
            for (var c = 0; c < targetText.length; c++) {
                var ch = targetText.charAt(c);
                applyBaselineShiftToChars(tf, ch, -shiftValue);
            }
        }
    }

    /* アイテムのジオメトリック境界から中心Y座標を取得 / Get center Y coordinate from geometric bounds */
    function getCenterY(item) {
        var bounds = item.geometricBounds;
        return bounds[1] - (bounds[1] - bounds[3]) / 2;
    }

    /* 指定文字でアウトラインを作成し中心Y座標を取得 / Create outline for character and get center Y */
    function createOutlineAndGetCenterY(textFrame, character) {
        var tempFrame = null;
        var outline = null;
        var centerY = 0;

        try {
            tempFrame = textFrame.duplicate();
            tempFrame.contents = character;
            tempFrame.filled = false;
            tempFrame.stroked = false;

            outline = tempFrame.createOutline();
            centerY = getCenterY(outline);

        } finally {
            // Ensure cleanup even if createOutline() fails
            try {
                if (outline) outline.remove();
            } catch (e1) { }
            try {
                if (tempFrame) tempFrame.remove();
            } catch (e2) { }
        }

        return centerY;
    }

    /* 選択テキスト内の全文字の出現頻度を集計し、デフォルト対象文字選択時は非英数字・非日本語のみ考慮 /
       Count frequency of all characters; when selecting default target, only consider non-alphanumeric, non-kanji, non-hiragana, non-katakana */
    function getSymbolFrequency(sel) {
        var charCount = {};
        for (var i = 0; i < sel.length; i++) {
            var item = sel[i];
            if (item.typename == "TextFrame") {
                var selText = item.contents;
                for (var j = 0; j < selText.length; j++) {
                    var c = selText.charAt(j);
                    // Count all characters
                    charCount[c] = (charCount[c] || 0) + 1;
                }
            }
        }
        return charCount;
    }

    /* 全テキストフレームのベースラインシフトをリセット / Reset baseline shift for all characters */
    function resetBaselineShift(textFrames) {
        for (var i = 0; i < textFrames.length; i++) {
            var tf = textFrames[i];
            try {
                // Strongest: clear per-character overrides in one go
                tf.textRange.characters.everyItem().characterAttributes.baselineShift = 0;
            } catch (e) {
                try {
                    // Next best: apply to the whole range
                    tf.textRange.characterAttributes.baselineShift = 0;
                } catch (e2) {
                    // Fallback: per-character reset
                    try {
                        var chars = tf.textRange.characters;
                        for (var j = 0; j < chars.length; j++) {
                            chars[j].characterAttributes.baselineShift = 0;
                        }
                    } catch (e3) {
                        // Ignore frames that cannot be processed
                    }
                }
            }
        }
    }

    /* 対象文字と基準文字を入力するダイアログを表示 / Show dialog to input target and reference characters */
    function showDialog(textFrames, previewMgr) {
        // var uiLang = getLang(); // Use global uiLang
        var dialog = new Window("dialog", LABELS.dialogTitle[uiLang]);
        dialog.orientation = "column";
        dialog.alignChildren = "left";

        // Preview manager is provided by main()
        if (!previewMgr) previewMgr = new PreviewManager();

        // 1️⃣ プレビュー制御用フラグ / Preview control flag
        var enablePreview = true;

        var mainGroup = dialog.add("group");
        mainGroup.orientation = "row";
        mainGroup.alignChildren = ["fill", "top"];

        /* デフォルト対象文字を全ユニークな非英数字・非日本語記号から抽出 / Default target from all unique non-alphanumeric, non-Japanese symbols */
        var defaultTarget = "";
        if (textFrames && textFrames.length > 0) {
            var charCount = getSymbolFrequency(textFrames);
            var targetChars = "";
            for (var key in charCount) {
                // Only consider non-alphanumeric, non-kanji, non-hiragana, non-katakana
                if (!key.match(/^[A-Za-z0-9\u3040-\u309F\u30A0-\u30FF\u4E00-\u9FFF]$/)) {
                    if (targetChars.indexOf(key) === -1) {
                        targetChars += key;
                    }
                }
            }
            defaultTarget = targetChars;
        }

        var inputGroup = mainGroup.add("group");
        inputGroup.orientation = "column";
        inputGroup.alignChildren = "left";
        inputGroup.margins = [15, 5, 15, 5];

        var targetGroup = inputGroup.add("group");
        targetGroup.add("statictext", undefined, labelText("targetCharLabel"));
        var targetInput = targetGroup.add("edittext", undefined, defaultTarget);
        targetInput.characters = 6;
        targetInput.active = true;
        targetInput.helpTip = LABELS.helpTips.targetInput[uiLang];
        targetInput.onChanging = updatePreview;

        var shiftGroup = inputGroup.add("group");
        shiftGroup.add("statictext", undefined, labelText("shiftAmountLabel"));
        var shiftInput = shiftGroup.add("edittext", undefined, "0");
        var unitLabel = shiftGroup.add("statictext", undefined, getUnitInfo("text/asianunits").label);
        shiftInput.characters = 6;
        changeValueByArrowKey(shiftInput, true, targetInput, textFrames, previewMgr);
        // 2️⃣ プレビュー制御フラグを用いたonChanging / Use preview control flag in onChanging
        shiftInput.onChanging = function () {
            updatePreview();
        };

        function updatePreview() {
            if (!enablePreview) return;
            previewShiftAll(targetInput, shiftInput, textFrames, previewMgr);
        }

        shiftInput.active = true;
        shiftGroup.margins = [0, 0, 0, 10];
        shiftInput.helpTip = LABELS.helpTips.shiftInput[uiLang];

        var autoPanel = inputGroup.add("panel", undefined, LABELS.autoPanelTitle[uiLang]);
        autoPanel.orientation = "column";
        autoPanel.alignChildren = "left";
        autoPanel.margins = [15, 20, 15, 5];

        var refGroup = autoPanel.add("group");
        refGroup.add("statictext", undefined, labelText("baseCharLabel"));
        var refInput = refGroup.add("edittext", undefined, "0");
        refInput.characters = 3;
        refInput.helpTip = LABELS.helpTips.refInput[uiLang];
        var calBtn = refGroup.add("button", [0, 0, 60, 25], LABELS.adjustBtnLabel[uiLang]);
        calBtn.helpTip = LABELS.helpTips.calBtn[uiLang];

        var buttonGroup = mainGroup.add("group");
        buttonGroup.orientation = "column";
        buttonGroup.alignChildren = "fill";

        var finalOkBtn = buttonGroup.add("button", undefined, LABELS.okBtnLabel[uiLang], {
            name: "ok"
        });
        finalOkBtn.helpTip = LABELS.helpTips.finalOkBtn[uiLang];
        var cancelBtn = buttonGroup.add("button", undefined, LABELS.cancelBtnLabel[uiLang], {
            name: "cancel"
        });

        buttonGroup.add("statictext", [0, 0, 0, 30], " "); // Spacer
        var resetBtn = buttonGroup.add("button", undefined, LABELS.resetBtnLabel[uiLang]);
        resetBtn.helpTip = LABELS.helpTips.resetBtn[uiLang];

        resetBtn.onClick = function () {
            if (!textFrames || textFrames.length == 0) {
                alert(LABELS.selectFrameMsg[uiLang]);
                return;
            }

            // Avoid immediate re-preview while resetting UI values
            enablePreview = false;

            // Rollback any previous preview and apply reset as a single preview step
            previewMgr.rollback();
            previewMgr.addStep(function () {
                resetBaselineShift(textFrames);
            });

            shiftInput.text = "0";
            enablePreview = true;
        };

        /* 自動調整ボタンのクリック処理 / Auto adjust button click */
        calBtn.onClick = function () {
            if (targetInput.text.length == 0) {
                alert(LABELS.invalidCharMsg[uiLang]);
                return;
            }
            if (refInput.text.length != 1) {
                alert(LABELS.invalidCharMsg[uiLang]);
                return;
            }
            if (!app.documents.length) {
                alert(LABELS.docOpenMsg[uiLang]);
                return;
            }
            if (!textFrames || textFrames.length == 0) {
                alert(LABELS.selectFrameMsg[uiLang]);
                return;
            }
            /* 最初の該当文字で基準文字とのY座標差分を計算し、シフト量を設定 / Calculate offset for first valid character */
            for (var i = 0; i < textFrames.length; i++) {
                var item = textFrames[i];
                if (item.typename == "TextFrame") {
                    var contents = item.contents;
                    for (var c = 0; c < targetInput.text.length; c++) {
                        var targetChar = targetInput.text.charAt(c);
                        if (contents.indexOf(targetChar) == -1) {
                            continue;
                        }
                        var refCenterY = createOutlineAndGetCenterY(item, refInput.text);
                        var targetCenterY = createOutlineAndGetCenterY(item, targetChar);
                        var yOffset = refCenterY - targetCenterY;
                        shiftInput.text = yOffset.toFixed(4);
                        updatePreview();
                        return;
                    }
                }
            }
        };

        /* OKボタンのクリック処理 / Final OK button click */
        finalOkBtn.onClick = function () {
            if (targetInput.text.length == 0) {
                alert(LABELS.invalidCharMsg[uiLang]);
                return;
            }
            var shiftValue = Number(shiftInput.text);
            if (isNaN(shiftValue)) {
                alert(LABELS.numericErrorMsg[uiLang]);
                return;
            }
            // 3️⃣ OKボタン押下時にプレビュー無効化 / Disable preview on OK
            enablePreview = false;

            // Do not confirm here; main() will confirm to keep undo as a single step
            dialog.close(1);
        };

        /* キャンセルボタンのクリック処理 / Cancel button click */
        cancelBtn.onClick = function () {
            previewMgr.rollback();
            dialog.close(0);
        };

        var offsetX = 300;
        var dialogOpacity = 0.97;

        function shiftDialogPosition(dlg, offsetX, offsetY) {
            dlg.onShow = function () {
                var currentX = dlg.location[0];
                var currentY = dlg.location[1];
                dlg.location = [currentX + offsetX, currentY + offsetY];
            };
        }

        function setDialogOpacity(dlg, opacityValue) {
            dlg.opacity = opacityValue;
        }

        setDialogOpacity(dialog, dialogOpacity);
        shiftDialogPosition(dialog, offsetX, 0);

        if (dialog.show() == 1) {
            var shiftValue = Number(shiftInput.text);
            return {
                target: targetInput.text,
                reference: refInput.text,
                shift: shiftValue
            };
        }
        return null;
    }

    /* メイン処理 / Main process */
    function main() {
        try {
            if (app.documents.length == 0) {
                alert(LABELS.docOpenMsg[uiLang]);
                return;
            }

            // --- 追加: テキスト範囲が選択されている場合は、そのストーリーの唯一のテキストフレームを選択し直す ---
            if (app.documents.length && app.selection && app.selection.constructor && app.selection.constructor.name === "TextRange") {
                var textFramesInStory = app.selection.story.textFrames;
                if (textFramesInStory.length === 1) {
                    app.executeMenuCommand("deselectall");
                    app.selection = [textFramesInStory[0]];
                    try {
                        app.selectTool("Adobe Select Tool");
                    } catch (e) { }
                }
            }
            // -----------------------------------------------------------------------

            var selection = app.activeDocument.selection;
            if (!selection || selection.length == 0) {
                alert(LABELS.selectFrameMsg[uiLang]);
                return;
            }

            var textFrames = getAllTextFrames(selection);
            if (textFrames.length == 0) {
                alert(LABELS.selectFrameMsg[uiLang]);
                return;
            }

            // Preview manager shared with dialog (undo-safe preview)
            var previewMgr = new PreviewManager();

            var input = showDialog(textFrames, previewMgr);
            if (!input) {
                // showDialog already rolled back on cancel
                return;
            }

            // Confirm in main: rollback preview and apply final action once (single undo step)
            var t = input.target;
            var s = Number(input.shift);
            if (isNaN(s)) s = 0;

            previewMgr.confirm(function () {
                applyShiftAll(t, s, textFrames);
            });

        } catch (e) {
            alert(LABELS.errorMsg[uiLang] + e);
        }
    }

    main();

})();
