#target illustrator
app.preferences.setBooleanPreference('ShowExternalJSXWarning', false);

/*

### 概要

選択した数値テキストを、指定した並び順でソートして連番を振り直します。

詳細は README を参照してください。

### Overview

Sorts the selected numeric text in a chosen order and renumbers it as a sequence.

See the README for details.

*/

// =========================================
// 基本情報 / Basic info
// =========================================
var SCRIPT_NAME     = "SmartRenumber";                /* スクリプト名 / script name */
var SCRIPT_VERSION  = "v2.0.1";                         /* バージョン / version */
var SCRIPT_AUTHOR   = "Masahiro Takano (@swwwitch)";  /* 作者 / author */
var SCRIPT_RELEASED = "2026-01-09";                   /* 最初のリリース日 / first release date */
var SCRIPT_UPDATED  = "2026-09-19";                   /* 更新日 / last updated */

var SCRIPT_README_JA = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/SmartRenumber.md"; /* README（日本語） */
var SCRIPT_README_EN = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/SmartRenumber.md"; /* README (English) */

// Released under the MIT license
// http://opensource.org/licenses/mit-license.php

(function () {

    // ダイアログ表示位置・透明度
    var DIALOG_OFFSET_X = 300;
    var DIALOG_OFFSET_Y = 0;
    var DIALOG_OPACITY = 0.98;

    function shiftDialogPosition(dialog, offsetX, offsetY) {
        var prevOnShow = dialog.onShow;
        dialog.onShow = function () {
            try { if (prevOnShow) prevOnShow(); } catch (e) {}
            try {
                var currentX = dialog.location[0];
                var currentY = dialog.location[1];
                dialog.location = [currentX + offsetX, currentY + offsetY];
            } catch (e2) {}
        };
    }

    function setDialogOpacity(dialog, opacityValue) {
        try { dialog.opacity = opacityValue; } catch (e) {}
    }

    /**
     * 現在の言語を取得
     */
    function getCurrentLang() {
        return ($.locale.indexOf("ja") === 0) ? "ja" : "en";
    }
    var uiLang = getCurrentLang();

    /**
     * 言語ラベル定義
     */
    var LABELS = {
        dialogTitle: { ja: "連番振り直し", en: "Smart Renumber" },
        startNum: { ja: "開始番号", en: "Start Number" },
        sortOrder: { ja: "並び順", en: "Sort Order" },
        textAdd: { ja: "テキスト追加", en: "Text Addition" },
        prefix: { ja: "接頭辞", en: "Prefix" },
        suffix: { ja: "接尾辞", en: "Suffix" },
        currentVal: { ja: "現在の数値順", en: "Current Value Order" },
        vertical: { ja: "垂直方向（上から下）", en: "Vertical (Top to Bottom)" },
        horizontal: { ja: "水平方向（左から右）", en: "Horizontal (Left to Right)" },
        zPattern: { ja: "Z方向（左→右、上→下）", en: "Z-Pattern (Left-to-Right, Row-major)" },
        nPattern: { ja: "N方向（上→下、左→右）", en: "N-Pattern (Top-to-Bottom, Column-major)" },
        stackTop: { ja: "重ね順（前面から）", en: "Layer Order (Front to Back)" },
        reverse: { ja: "逆順", en: "Reverse" },
        zeroPad: { ja: "ゼロ埋め", en: "Zero Padding" },
        ok: { ja: "OK", en: "OK" },
        cancel: { ja: "キャンセル", en: "Cancel" },
        errNoDoc: { ja: "ドキュメントが開かれていません。", en: "No document open." },
        errNoSelection: { ja: "テキストオブジェクトを選択してください。", en: "Please select text objects." },
        errNoNumeric: { ja: "数字が入力されたテキストオブジェクトが見つかりませんでした。", en: "No numeric text objects found." },
        tipStartNum: { ja: "振り直しの最初の数字です。", en: "First number of the new sequence." },
        tipCurrentVal: { ja: "いま入っている数字の小さい順に振り直します。", en: "Renumbers in ascending order of the current values." },
        tipVertical: { ja: "上にあるものから順に振り直します。", en: "Renumbers from the topmost object down." },
        tipHorizontal: { ja: "左にあるものから順に振り直します。", en: "Renumbers from the leftmost object to the right." },
        tipZPattern: { ja: "行ごとに左から右へ、行を上から下へ進みます。", en: "Moves left to right within a row, then down to the next row." },
        tipNPattern: { ja: "列ごとに上から下へ、列を左から右へ進みます。", en: "Moves top to bottom within a column, then right to the next column." },
        tipStackTop: { ja: "重ね順の前面にあるものから順に振り直します。", en: "Renumbers from the frontmost object backward." },
        tipReverse: { ja: "並び順を逆さにして振り直します。", en: "Reverses the order before renumbering." },
        tipZeroPad: { ja: "いちばん大きい番号の桁数に合わせて、頭に0を足します。", en: "Pads with leading zeros to match the widest number." },
        tipPrefix: { ja: "番号の前に付ける文字列です。", en: "Text placed before the number." },
        tipSuffix: { ja: "番号の後ろに付ける文字列です。", en: "Text placed after the number." }
    };

    function getLabel(key) {
        var entry = LABELS[key];
        if (!entry) return key;
        return entry[uiLang] || entry.en || key;
    }

    /* コロン付きの項目名を返す（日本語は全角、英語は半角） / Return a label with a colon */
    function labelText(key) {
        return getLabel(key) + (uiLang === "ja" ? "：" : ": ");
    }

    main();

    function main() {
        if (app.documents.length === 0) { alert(getLabel('errNoDoc')); return; }

        var doc = app.activeDocument;
        var currentSelection = doc.selection;

        if (currentSelection.length === 0) { alert(getLabel('errNoSelection')); return; }

        var textObjects = [];

        /* オブジェクト情報の取得 */
        for (var i = 0; i < currentSelection.length; i++) {
            if (currentSelection[i].typename === "TextFrame") {
                var content = currentSelection[i].contents;
                if (!isNaN(parseFloat(content)) && isFinite(content)) {
                    textObjects.push({
                        obj: currentSelection[i],
                        value: parseFloat(content),
                        x: currentSelection[i].left,
                        y: currentSelection[i].top,
                        stackOrder: i,
                        original: content
                    });
                }
            }
        }

        if (textObjects.length === 0) { alert(getLabel('errNoNumeric')); return; }

        // プレビュー時のUndo管理
        var previewMgr = new PreviewManager();

        /* ダイアログボックスの作成 */
        var win = new Window("dialog", getLabel('dialogTitle') + ' ' + SCRIPT_VERSION);
        win.orientation = "row";
        win.alignChildren = ["left", "top"];
        win.spacing = 20;
        win.margins = 20;

        // ダイアログの透明度と位置を調整
        setDialogOpacity(win, DIALOG_OPACITY);
        shiftDialogPosition(win, DIALOG_OFFSET_X, DIALOG_OFFSET_Y);

        /* 左カラム */
        var leftCol = win.add("group");
        leftCol.orientation = "column";
        leftCol.alignChildren = ["left", "top"];
        leftCol.spacing = 15;

        // 開始番号
        var groupStart = leftCol.add("group");
        groupStart.add("statictext", undefined, labelText('startNum'));
        var inputNumber = groupStart.add("edittext", undefined, "");
        var initialMin = textObjects.slice().sort(function (a, b) { return a.value - b.value; })[0].value;
        inputNumber.text = initialMin;
        inputNumber.characters = 8;
        inputNumber.helpTip = getLabel('tipStartNum');
        inputNumber.active = true;

        // 並び順パネル
        var sortPanel = leftCol.add("panel", undefined, getLabel('sortOrder'));
        sortPanel.orientation = "column";
        sortPanel.alignChildren = ["left", "top"];
        sortPanel.margins = [15, 20, 15, 10];
        sortPanel.spacing = 4;

        var rbIgnore = sortPanel.add("radiobutton", undefined, getLabel('currentVal'));
        rbIgnore.helpTip = getLabel('tipCurrentVal');
        var rbVertical = sortPanel.add("radiobutton", undefined, getLabel('vertical'));
        rbVertical.helpTip = getLabel('tipVertical');
        var rbHorizontal = sortPanel.add("radiobutton", undefined, getLabel('horizontal'));
        rbHorizontal.helpTip = getLabel('tipHorizontal');
        var rbZ = sortPanel.add("radiobutton", undefined, getLabel('zPattern'));
        rbZ.helpTip = getLabel('tipZPattern');
        var rbN = sortPanel.add("radiobutton", undefined, getLabel('nPattern'));
        rbN.helpTip = getLabel('tipNPattern');
        var rbStackTop = sortPanel.add("radiobutton", undefined, getLabel('stackTop'));
        rbStackTop.helpTip = getLabel('tipStackTop');
        rbIgnore.value = true;

        // オプション（横並び）
        var optionsGroup = leftCol.add("group");
        optionsGroup.orientation = "row";
        optionsGroup.spacing = 20;
        var chkReverse = optionsGroup.add("checkbox", undefined, getLabel('reverse'));
        chkReverse.helpTip = getLabel('tipReverse');
        var chkZeroPad = optionsGroup.add("checkbox", undefined, getLabel('zeroPad'));
        chkZeroPad.helpTip = getLabel('tipZeroPad');

        // テキスト追加パネル
        var textAddPanel = leftCol.add("panel", undefined, getLabel('textAdd'));
        textAddPanel.orientation = "column";
        textAddPanel.alignChildren = ["right", "top"];
        textAddPanel.margins = [15, 20, 15, 15];
        textAddPanel.spacing = 8;

        var groupPrefix = textAddPanel.add("group");
        groupPrefix.add("statictext", undefined, labelText('prefix'));
        var inputPrefix = groupPrefix.add("edittext", undefined, "");
        inputPrefix.characters = 12;
        inputPrefix.helpTip = getLabel('tipPrefix');

        var groupSuffix = textAddPanel.add("group");
        groupSuffix.add("statictext", undefined, labelText('suffix'));
        var inputSuffix = groupSuffix.add("edittext", undefined, "");
        inputSuffix.characters = 12;
        inputSuffix.helpTip = getLabel('tipSuffix');

        /* 右カラム */
        var rightCol = win.add("group");
        rightCol.orientation = "column";
        rightCol.alignChildren = ["fill", "top"];
        rightCol.preferredSize.width = 100;
        rightCol.spacing = 10;

        var btnOK = rightCol.add("button", undefined, getLabel('ok'), { name: "ok" });
        var btnCancel = rightCol.add("button", undefined, getLabel('cancel'), { name: "cancel" });

        btnCancel.onClick = function () {
            previewMgr.rollback();
            win.close(0);
        };

        btnOK.onClick = function () {
            // 一度プレビューを全てUndoしてから、最後に1回だけ本番適用（Undo 1回で戻せる）
            previewMgr.confirm(function () {
                var startNum = parseFloat(inputNumber.text);
                if (isNaN(startNum)) return;

                var prefix = inputPrefix.text;
                var suffix = inputSuffix.text;

                var sortedList = textObjects.slice();
                var threshold = 10;

                sortedList.sort(function (a, b) {
                    if (rbIgnore.value) return a.value - b.value;
                    if (rbVertical.value) return b.y - a.y;
                    if (rbHorizontal.value) return a.x - b.x;
                    if (rbStackTop.value) return a.stackOrder - b.stackOrder;

                    if (rbZ.value) {
                        if (Math.abs(a.y - b.y) > threshold) return b.y - a.y;
                        return a.x - b.x;
                    }
                    if (rbN.value) {
                        if (Math.abs(a.x - b.x) > threshold) return a.x - b.x;
                        return b.y - a.y;
                    }
                    return 0;
                });

                if (chkReverse.value) sortedList.reverse();

                var maxNum = startNum + sortedList.length - 1;
                var maxDigits = Math.floor(Math.abs(maxNum)).toString().length;

                for (var j = 0; j < sortedList.length; j++) {
                    var newNum = startNum + j;
                    var numStr = chkZeroPad.value ? zeroPad(newNum, maxDigits) : newNum.toString();
                    sortedList[j].obj.contents = prefix + numStr + suffix;
                }
                app.redraw();
            });
            win.close(1);
        };

        // ダイアログを×で閉じた場合もロールバック
        win.onClose = function () {
            previewMgr.rollback();
            return true;
        };

        /* プレビュー更新（Undo履歴を汚さない） */
        var updatePreview = function () {
            // 直前のプレビューを必ず巻き戻す
            previewMgr.rollback();

            previewMgr.addStep(function () {
                var startNum = parseFloat(inputNumber.text);
                if (isNaN(startNum)) return;

                var prefix = inputPrefix.text;
                var suffix = inputSuffix.text;

                var sortedList = textObjects.slice();
                var threshold = 10;

                sortedList.sort(function (a, b) {
                    if (rbIgnore.value) return a.value - b.value;
                    if (rbVertical.value) return b.y - a.y;
                    if (rbHorizontal.value) return a.x - b.x;
                    if (rbStackTop.value) return a.stackOrder - b.stackOrder;

                    if (rbZ.value) {
                        if (Math.abs(a.y - b.y) > threshold) return b.y - a.y;
                        return a.x - b.x;
                    }
                    if (rbN.value) {
                        if (Math.abs(a.x - b.x) > threshold) return a.x - b.x;
                        return b.y - a.y;
                    }
                    return 0;
                });

                if (chkReverse.value) sortedList.reverse();

                var maxNum = startNum + sortedList.length - 1;
                var maxDigits = Math.floor(Math.abs(maxNum)).toString().length;

                for (var j = 0; j < sortedList.length; j++) {
                    var newNum = startNum + j;
                    var numStr = chkZeroPad.value ? zeroPad(newNum, maxDigits) : newNum.toString();
                    sortedList[j].obj.contents = prefix + numStr + suffix;
                }
            });
        };

        /* イベントリスナー */
        changeValueByArrowKey(inputNumber, updatePreview);
        inputNumber.onChanging = updatePreview;
        inputPrefix.onChanging = updatePreview;
        inputSuffix.onChanging = updatePreview;
        rbIgnore.onClick = rbVertical.onClick = rbHorizontal.onClick =
            rbZ.onClick = rbN.onClick = rbStackTop.onClick =
            chkReverse.onClick = chkZeroPad.onClick = updatePreview;

        updatePreview();

        win.show();
    }

    /**
     * プレビュー時の履歴管理と一括Undoを制御するクラス
     * - updatePreview() のたびに rollback() → addStep() で「履歴を汚さないプレビュー」を実現
     * - OK確定時は confirm(finalAction) で「1回のUndo」で戻せるようにする
     */
    function PreviewManager() {
        this.undoDepth = 0;

        this.addStep = function (func) {
            try {
                func();
                this.undoDepth++;
                app.redraw();
            } catch (e) {
                alert("Preview Error: " + e);
            }
        };

        this.rollback = function () {
            while (this.undoDepth > 0) {
                try {
                    app.undo();
                } catch (e) {
                    // 何らかの理由でUndoできない場合は中断
                    break;
                }
                this.undoDepth--;
            }
            app.redraw();
        };

        this.confirm = function (finalAction) {
            if (finalAction) {
                this.rollback();
                finalAction();
            } else {
                this.undoDepth = 0;
            }
        };
    }

    /**
     * 矢印キーでの数値増減
     */
    function changeValueByArrowKey(editText, callback) {
        editText.addEventListener("keydown", function (event) {
            var value = Number(editText.text);
            if (isNaN(value)) return;
            var keyboard = ScriptUI.environment.keyboardState;
            var delta = 1;
            if (keyboard.shiftKey) {
                delta = 10;
                if (event.keyName == "Up") value = Math.ceil((value + 0.1) / delta) * delta;
                else if (event.keyName == "Down") value = Math.floor((value - 0.1) / delta) * delta;
                event.preventDefault();
            } else if (keyboard.altKey) {
                delta = 0.1;
                if (event.keyName == "Up") value += delta;
                else if (event.keyName == "Down") value -= delta;
                event.preventDefault();
            } else {
                if (event.keyName == "Up") value += 1;
                else if (event.keyName == "Down") value -= 1;
                if (event.keyName == "Up" || event.keyName == "Down") event.preventDefault();
            }
            value = keyboard.altKey ? Math.round(value * 10) / 10 : Math.round(value);
            editText.text = value;
            if (callback) callback();
        });
    }

    /**
     * ゼロ埋め処理
     */
    function zeroPad(num, digits) {
        var isNegative = num < 0;
        var absNum = Math.abs(num);
        var str = absNum.toString();
        while (str.length < digits) { str = "0" + str; }
        return (isNegative ? "-" : "") + str;
    }

})();
