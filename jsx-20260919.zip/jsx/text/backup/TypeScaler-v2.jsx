#targetengine "TypeScalerEngine"
#target illustrator
app.preferences.setBooleanPreference('ShowExternalJSXWarning', false);

/*

### 概要

選択したテキストのフォントサイズを、基準サイズと比率から算出して適用します。

詳細は README を参照してください。

### Overview

Sets the font size of the selected text from a base size and a ratio.

See the README for details.

*/

// =========================================
// 基本情報 / Basic info
// =========================================
var SCRIPT_NAME     = "TypeScaler-v2";                /* スクリプト名 / script name */
var SCRIPT_VERSION  = "v1.2";                         /* バージョン / version */
var SCRIPT_AUTHOR   = "Masahiro Takano (@swwwitch)";  /* 作者 / author */
var SCRIPT_RELEASED = "";                             /* 最初のリリース日 / first release date */
var SCRIPT_UPDATED  = "";                             /* 更新日 / last updated */

var SCRIPT_README_JA = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/TypeScaler-v2.md"; /* README（日本語） */
var SCRIPT_README_EN = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/TypeScaler-v2.md"; /* README (English) */

// Released under the MIT license
// http://opensource.org/licenses/mit-license.php

(function () {

    var persistentBaseSize = null;
    $.global.__sizeValue = $.global.__sizeValue || "12";
    $.global.__ratioIndex = ($.global.__ratioIndex !== undefined) ? $.global.__ratioIndex : 3;

    // スクリプトバージョン

    function getCurrentLang() {
      return ($.locale.indexOf("ja") === 0) ? "ja" : "en";
    }
    var lang = getCurrentLang();

    /* 日英ラベル定義 / Japanese-English label definitions */

    /* UIラベル定義 / UI Label Definitions */
    var LABELS = {
        dialogTitle: {
            ja: "タイプスケール " + SCRIPT_VERSION,
            en: "Type Scale " + SCRIPT_VERSION
        },
        baseLabel: {
            ja: "基準：",
            en: "Base:"
        },
        unitLabel: {
            ja: "（単位）",
            en: "(Unit)"
        },
        ratioDropdown: {
            ja: "倍率",
            en: "Ratio"
        },
        colNumber: {
            ja: "#",
            en: "#"
        },
        colFontSize: {
            ja: "フォントサイズ",
            en: "Font Size"
        },
        cancelBtn: {
            ja: "キャンセル",
            en: "Cancel"
        },
        okBtn: {
            ja: "OK",
            en: "OK"
        },
        alertSelectSize: {
            ja: "リストからサイズを選択してください。",
            en: "Please select a size from the list."
        },
        alertInvalidSize: {
            ja: "正しいサイズを選択してください。",
            en: "Please select a valid size."
        },
        alertApplyError: {
            ja: "フォントサイズの適用に失敗しました：",
            en: "Failed to apply font size: "
        }
    };

    /* 単位ラベル取得関数とマップ / Get unit label and mapping */
    function getUnitLabel(code, prefKey) {
      if (code === 5 && prefKey === "text/asianunits") {
        return "H";
      }
      return unitLabelMap[code] || "不明";
    }

    var unitLabelMap = {
     0: "in",
     1: "mm",
     2: "pt",
     3: "pica",
     4: "cm",
     5: "Q/H",
     6: "px"
    };

    /* 番号付きラベル生成関数 / Generate numbered labels */
    function createNumberedLabels(items, offset, unitLabel) {
      var labels = [];
      for (var i = 0; i < items.length; i++) {
        var label = (offset + i) + " - " + items[i] + (unitLabel ? " " + unitLabel : "");
        labels.push(label);
      }
      return labels;
    }

    function getSelectedTextFrames() {
      var sel = app.activeDocument.selection;
      var frames = [];
      for (var i = 0; i < sel.length; i++) {
        if (sel[i].typename === "TextFrame") {
          frames.push(sel[i]);
        }
      }
      return frames;
    }

    // =========================
    // フォントサイズ配列を倍率に基づいて生成 / Generate array of font sizes based on ratio
    // =========================
    function generateTypeScaleSizes(baseSize, ratio) {
      var sizes = [];
      var down = baseSize;
      for (var i = 0; i < 2; i++) {
        down /= ratio;
      }
      for (var i = 0; i < 7; i++) {
        sizes.push(Math.round(down * 10) / 10);
        down *= ratio;
      }
      return sizes;
    }

    // =========================
    // リストボックスを更新 / Update listbox with calculated font sizes
    // =========================
    function updateSizeList(sizeList, ratioPopup, baseSize, textUnitLabel) {
      sizeList.removeAll();
      if (isNaN(baseSize) || baseSize <= 0) return;
      var ratio = ratioPopup.selection ? ratioValues[ratioPopup.selection.index] : 1.25;
      var sizes = generateTypeScaleSizes(baseSize, ratio);
      // generateTypeScaleSizes は index 2 が基準サイズ。基準を 0、一番上（index 0）を -2 とする
      for (var j = 0; j < sizes.length; j++) {
        var stepNumber = j - 2;
        var item = sizeList.add("item", String(stepNumber));
        item.subItems[0].text = sizes[j] + " " + textUnitLabel;
      }
    }

    // =========================
    // 倍率ラベル・値配列
    // =========================
    var ratioLabels = [
      "Minor Second 1.067",
      "Major Second 1.125",
      "Minor Third 1.2",
      "Major Third 1.25",
      "Golden Ratio: ½ 1.309",
      "Perfect Fourth 1.333",
      "Augmented Fourth 1.414",
      "Golden Ratio 1.618"
    ];
    var ratioValues = [1.067, 1.125, 1.2, 1.25, 1.309, 1.333, 1.414, 1.618];

    (function () {
      if (app.documents.length > 0) main();
    })();

    /* メイン処理 / Main process */
    function main() {
      var previewFrame = null;

      // =========================
      // UI構築
      // =========================
      var dialog = new Window("dialog", LABELS.dialogTitle[lang]);
      dialog.orientation = "column";
      dialog.alignChildren = "left";

      var textUnitCode = app.preferences.getIntegerPreference("text/units");
      var textUnitLabel = getUnitLabel(textUnitCode, "text/units");

      // 基準サイズ入力（1列目）
      var sizeGroup = dialog.add("group");
      sizeGroup.orientation = "row";
      sizeGroup.spacing = 5;
      sizeGroup.alignment = "fill";
      sizeGroup.add("statictext", undefined, LABELS.baseLabel[lang]);
      var sizeInput = sizeGroup.add("edittext", undefined, $.global.__sizeValue);
      sizeInput.characters = 4;
      sizeGroup.add("statictext", undefined, LABELS.unitLabel[lang].replace("単位", textUnitLabel));
      changeValueByArrowKey(sizeInput);

      // 倍率ポップアップ（2列目）
      var ratioPopup = dialog.add("dropdownlist", undefined, ratioLabels);
      ratioPopup.selection = $.global.__ratioIndex;
      ratioPopup.alignment = "fill";

      // サイズ一覧（3列目・番号＋サイズの2カラム）
      var sizeList = dialog.add("listbox", undefined, [], {
        multiselect: false,
        numberOfColumns: 2,
        showHeaders: true,
        columnTitles: [LABELS.colNumber[lang], LABELS.colFontSize[lang]],
        columnWidths: [40, 130]
      });
      sizeList.preferredSize = [180, 136];
      sizeList.alignment = "fill";

      // ボタングループをダイアログ下部に追加
      var buttonGroup = dialog.add("group");
      buttonGroup.orientation = "row";
      buttonGroup.alignment = "center";
      var cancelBtn = buttonGroup.add("button", undefined, LABELS.cancelBtn[lang]);
      var okBtn = buttonGroup.add("button", undefined, LABELS.okBtn[lang]);

      // =========================
      // イベント定義
      // =========================

      // 基準サイズ入力変更時
      sizeInput.onChanging = function () {
        var inputValue = parseFloat(sizeInput.text);
        if (!isNaN(inputValue) && inputValue > 0) {
          persistentBaseSize = inputValue;
          $.global.__sizeInput = sizeInput;
        }
        $.global.__sizeValue = sizeInput.text;
        updateSizeList(sizeList, ratioPopup, inputValue, textUnitLabel);
      };

      // 倍率変更時
      ratioPopup.onChange = function () {
        var inputValue = parseFloat(sizeInput.text);
        updateSizeList(sizeList, ratioPopup, inputValue, textUnitLabel);
        $.global.__ratioPopup = ratioPopup;
        $.global.__ratioIndex = ratioPopup.selection ? ratioPopup.selection.index : 0;
      };

      // 選択リストアイテムからフォントサイズ値を取得 / Parse font size value from selected list item
      function getSelectedListSize() {
        if (!sizeList.selection) return NaN;
        // 2カラム目（サイズ）から数値を取得
        var sizeText = sizeList.selection.subItems[0].text;
        var parts = sizeText.split(" ");
        for (var i = 0; i < parts.length; i++) {
          if (parts[i].indexOf("pt") !== -1 || !isNaN(parseFloat(parts[i]))) {
            return parseFloat(parts[i]);
          }
        }
        return NaN;
      }

      // 選択テキストにフォントサイズを適用 / Apply font size to selected text
      function applySizeToSelection(sizeValue) {
        var sel = app.activeDocument.selection;
        for (var i = 0; i < sel.length; i++) {
          var item = sel[i];
          try {
            if (item.typename === "TextRange") {
              item.characterAttributes.size = sizeValue;
            } else if (item.typename === "TextFrame") {
              if (item.textRange && item.textRange.characters.length > 0) {
                item.textRange.characterAttributes.size = sizeValue;
              }
            }
          } catch (e) {
            alert(LABELS.alertApplyError[lang] + e.message);
          }
        }
        app.redraw();
        $.global.__sizeValue = sizeInput.text;
        $.global.__ratioIndex = ratioPopup.selection ? ratioPopup.selection.index : 0;
      }

      // サイズ一覧クリック時（ダイアログを閉じずに即適用）/ Apply on list click without closing dialog
      sizeList.onChange = function () {
        var sizeValue = getSelectedListSize();
        if (isNaN(sizeValue) || sizeValue <= 0) return;
        applySizeToSelection(sizeValue);
      };

      // OKボタン押下時（選択テキストにサイズ適用して閉じる）
      okBtn.onClick = function () {
        if (!sizeList.selection) {
          alert(LABELS.alertSelectSize[lang]);
          return;
        }
        var sizeValue = getSelectedListSize();
        if (isNaN(sizeValue) || sizeValue <= 0) {
          alert(LABELS.alertInvalidSize[lang]);
          return;
        }
        applySizeToSelection(sizeValue);
        // Remove previewFrame if present before closing dialog
        if (previewFrame && previewFrame.isValid) {
          try { previewFrame.remove(); } catch (e) {}
        }
        dialog.close();
      };

      // キャンセルボタン押下時
      cancelBtn.onClick = function () {
        dialog.close();
      };

      // =========================
      // 初期表示更新とダイアログ表示
      // =========================
      // --- Ensure text object selection when in text edit mode ---
      if (app.documents.length && app.selection.constructor.name === "TextRange") {
        var textFramesInStory = app.selection.story.textFrames;
        if (textFramesInStory.length === 1) {
          app.executeMenuCommand("deselectall");
          app.selection = [textFramesInStory[0]];
          try {
            app.selectTool("Adobe Select Tool");
          } catch (e) {}
        }
      }
      // -----------------------------------------------------------
      updateSizeList(sizeList, ratioPopup, parseFloat(sizeInput.text), textUnitLabel);
      // 選択テキストがない場合は listbox を無効化
      if (getSelectedTextFrames().length === 0) {
        sizeList.enabled = false;
      }

      // --- Opacity and position adjustment ---
      var offsetX = 300;
      var dialogOpacity = 0.97;

      function shiftDialogPosition(dlg, offsetX, offsetY) {
          dlg.onShow = function () {
              var currentX = dlg.location[0];
              var currentY = dlg.location[1];
              dlg.location = [currentX + offsetX, currentY + offsetY];
          };
      }

      function setDialogOpacity(dlg, opacityValue) {
          dlg.opacity = opacityValue;
      }

      setDialogOpacity(dialog, dialogOpacity);
      shiftDialogPosition(dialog, offsetX, 0);
      // --- End Opacity and position adjustment ---

      dialog.center();
      dialog.onShow = function() {
          sizeInput.active = true;
      };
      dialog.show();

      /* 上下キーで値を変更する関数 / Change value with up/down arrow keys */
      function changeValueByArrowKey(editText) {
          editText.addEventListener("keydown", function(event) {
              var value = Number(editText.text);
              if (isNaN(value)) return;

              var keyboard = ScriptUI.environment.keyboardState;
              var delta = 1;

              if (keyboard.shiftKey) {
                  delta = 10;
                  if (event.keyName == "Up") {
                      value = Math.ceil((value + 1) / delta) * delta;
                      event.preventDefault();
                  } else if (event.keyName == "Down") {
                      value = Math.floor((value - 1) / delta) * delta;
                      if (value < 0) value = 0;
                      event.preventDefault();
                  }
              } else if (keyboard.altKey) {
                  delta = 0.1;
                  if (event.keyName == "Up") {
                      value += delta;
                      event.preventDefault();
                  } else if (event.keyName == "Down") {
                      value -= delta;
                      event.preventDefault();
                  }
              } else {
                  delta = 1;
                  if (event.keyName == "Up") {
                      value += delta;
                      event.preventDefault();
                  } else if (event.keyName == "Down") {
                      value -= delta;
                      if (value < 0) value = 0;
                      event.preventDefault();
                  }
              }

              if (keyboard.altKey) {
                  value = Math.round(value * 10) / 10;
              } else {
                  value = Math.round(value);
              }

              editText.text = value;
          });
      }
    }

})();
