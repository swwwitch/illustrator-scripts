#target illustrator
app.preferences.setBooleanPreference('ShowExternalJSXWarning', false);

/*

### 概要

ドキュメント内で使用されているフォントを集計し、使用数順に一覧表示します。
一覧から選んだフォントを選択テキストへ即座に適用でき、テキストファイルとして書き出すこともできます。

詳細は README を参照してください。
https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/ApplyDocumentFonts.md

note記事も参照してください。
https://note.com/dtp_tranist/n/n01d6ef7e9b5f

### Overview

Collects the fonts used in the document and lists them in order of usage count.
A font picked from the list can be applied to the selected text right away, and the list can be exported as a text file.

See the README for details.
https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/ApplyDocumentFonts.md

*/

// =========================================
// 基本情報 / Basic info
// =========================================
var SCRIPT_NAME     = "ApplyDocumentFonts";           /* スクリプト名 / script name */
var SCRIPT_VERSION  = "v1.1.3";                       /* バージョン / version */
var SCRIPT_AUTHOR   = "Masahiro Takano (@swwwitch)";  /* 作者 / author */
var SCRIPT_RELEASED = "2025-02-25";                   /* 最初のリリース日 / first release date */
var SCRIPT_UPDATED  = "2026-09-19";                   /* 更新日 / last updated */

var SCRIPT_README_JA   = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/ApplyDocumentFonts.md"; /* README（日本語） */
var SCRIPT_README_EN   = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/ApplyDocumentFonts.md"; /* README (English) */
var SCRIPT_ARTICLE_URL = "https://note.com/dtp_tranist/n/n01d6ef7e9b5f"; /* 紹介記事 / article URL */

// Released under the MIT license
// http://opensource.org/licenses/mit-license.php

(function() {
    function getCurrentLang() {
        return ($.locale && $.locale.indexOf('ja') === 0) ? 'ja' : 'en';
    }

    var uiLang = getCurrentLang();
    var LABELS = {
        dialogTitle: {
            ja: "ドキュメントフォントを適用",
            en: "Apply Document Fonts"
        },
        searchLabel: {
            ja: "検索フィルター（フォント名・スタイル名・PostScript名に対応）",
            en: "Search Filter (Font Name, Style, PostScript Name)"
        },
        listLabel: {
            ja: "ドキュメントフォント（使用数順）",
            en: "Document Fonts (by Usage)"
        },
        tipFilter: {
            ja: "フォント名に含まれる文字で一覧を絞り込みます。",
            en: "Filters the list by text in the font name."
        },
        tipList: {
            ja: "ドキュメントで使われているフォントの一覧です。選んで OK すると、選択中のテキストに適用します。",
            en: "The fonts used in the document. Pick one and press OK to apply it to the selected text."
        },
        cancel: {
            ja: "キャンセル",
            en: "Cancel"
        },
        ok: {
            ja: "OK",
            en: "OK"
        },
        exportLabel: {
            ja: "書き出し",
            en: "Export"
        },
        noDocument: {
            ja: "ドキュメントが開かれていません。",
            en: "No document is open."
        },
        errorApplyFont: {
            ja: "フォントの適用に失敗しました。",
            en: "Failed to apply the font."
        },
        exportSuccess: {
            ja: "書き出しました：",
            en: "Font list saved:\n"
        },
        exportFail: {
            ja: "ファイルの書き出しに失敗しました。",
            en: "Failed to save the file."
        },
        exportHeader: {
            ja: "Adobe Illustrator ドキュメント情報",
            en: "Adobe Illustrator Document Info"
        },
        exportDocLabel: {
            ja: "ドキュメント : ",
            en: "Document: "
        },
        exportFontCount: {
            ja: "このドキュメントに使用されているフォント : ",
            en: "Fonts used in this document: "
        }
    };

    function main() {
        if (app.documents.length === 0) {
            alert(LABELS.noDocument[uiLang]);
            return;
        }

        var doc = app.activeDocument;
        var fontMap = {};
        var currentFontDisplayName = null;
        var originalFonts = [];

        function getFontDisplayName(textFont) {
            return textFont.style ? (textFont.family + " - " + textFont.style) : textFont.family;
        }

        function collectFontsFromTextFrame(textFrame) {
            if (!textFrame.contents || textFrame.contents.length === 0) return;
            try {
                var textFont = textFrame.textRange.characterAttributes.textFont;
                var displayName = getFontDisplayName(textFont);
                if (!fontMap[displayName]) {
                    fontMap[displayName] = {
                        count: 1,
                        postScriptName: textFont.name
                    };
                } else {
                    fontMap[displayName].count++;
                }
            } catch (e) {}
        }

        function collectFontsFromGroup(groupItem) {
            for (var i = 0; i < groupItem.pageItems.length; i++) {
                var item = groupItem.pageItems[i];
                if (item.typename === "TextFrame") {
                    collectFontsFromTextFrame(item);
                } else if (item.typename === "GroupItem") {
                    collectFontsFromGroup(item);
                }
            }
        }

        // グループ再帰走査を削除し、textFramesのみでフォント情報を収集
        for (var i = 0; i < doc.textFrames.length; i++) {
            collectFontsFromTextFrame(doc.textFrames[i]);
        }

        for (var s = 0; s < app.selection.length; s++) {
            if (app.selection[s].typename === "TextFrame") {
                try {
                    var selFont = app.selection[s].textRange.characterAttributes.textFont;
                    currentFontDisplayName = getFontDisplayName(selFont);
                    originalFonts.push({
                        item: app.selection[s],
                        font: selFont
                    });
                } catch (e) {}
            }
        }

        var sortedFonts = [];
        for (var name in fontMap) {
            if (fontMap.hasOwnProperty(name)) {
                sortedFonts.push({
                    displayName: name,
                    postScriptName: fontMap[name].postScriptName
                });
            }
        }
        sortedFonts.sort(function(a, b) {
            return a.displayName.localeCompare(b.displayName);
        });

        function getListBoxHeight(fontList) {
            return Math.min(300, Math.max(100, fontList.length * 20));
        }

        var dialog = new Window("dialog", LABELS.dialogTitle[uiLang]);
        dialog.orientation = "column";
        dialog.alignChildren = ["left", "top"];
        dialog.margins = 20;

        dialog.add("statictext", undefined, LABELS.searchLabel[uiLang]);
        var filterInput = dialog.add("edittext", undefined, "");
        filterInput.helpTip = LABELS.tipFilter[uiLang];
        filterInput.preferredSize = [400, 24];

        dialog.add("statictext", undefined, LABELS.listLabel[uiLang]);
        var listBox = dialog.add("listbox", undefined, [], { multiselect: false });
        listBox.helpTip = LABELS.tipList[uiLang];
        listBox.preferredSize = [400, getListBoxHeight(sortedFonts)];

        function updateListBox(filterText) {
            listBox.removeAll();
            var filter = filterText.toLowerCase();
            for (var i = 0; i < sortedFonts.length; i++) {
                var font = sortedFonts[i];
                if (filter === "" || font.displayName.toLowerCase().indexOf(filter) !== -1 || font.postScriptName.toLowerCase().indexOf(filter) !== -1) {
                    var count = fontMap[font.displayName].count;
                    var label = font.displayName + " (" + count + ")";
                    var item = listBox.add("item", label);
                    item.fontDisplayName = font.displayName;
                    item.postScriptName = font.postScriptName;
                }
            }
            if (listBox.items.length > 0) listBox.selection = 0;
        }

        updateListBox("");

        filterInput.onChanging = function() {
            updateListBox(filterInput.text);
        };

        // 再帰的にTextFrameへフォントを適用する関数
        function applyFontToItem(item, targetFont) {
            if (item.typename === "TextFrame") {
                item.textRange.characterAttributes.textFont = targetFont;
            } else if (item.typename === "GroupItem") {
                for (var i = 0; i < item.pageItems.length; i++) {
                    applyFontToItem(item.pageItems[i], targetFont);
                }
            } else if (item.typename === "CompoundPathItem" && item.pageItems && item.pageItems.length > 0) {
                for (var i = 0; i < item.pageItems.length; i++) {
                    applyFontToItem(item.pageItems[i], targetFont);
                }
            } else if (item.typename === "PathItem" || item.typename === "MeshItem") {
                // 何もしない
            } else if (item.typename === "ClipGroup" || (item.clipped && item.pageItems)) {
                for (var i = 0; i < item.pageItems.length; i++) {
                    applyFontToItem(item.pageItems[i], targetFont);
                }
            }
        }

        listBox.onChange = function() {
            if (!listBox.selection) return;
            try {
                var targetFont = app.textFonts.getByName(listBox.selection.postScriptName);
                for (var i = 0; i < app.selection.length; i++) {
                    applyFontToItem(app.selection[i], targetFont);
                }
                app.redraw();
            } catch (e) {
                alert(LABELS.errorApplyFont[uiLang]);
            }
        };

        var outerGroup = dialog.add("group");
        outerGroup.orientation = "row";
        outerGroup.alignChildren = ["fill", "center"];
        outerGroup.alignment = "fill";
        outerGroup.margins = [0, 10, 0, 0];
        outerGroup.spacing = 0;

        var leftGroup = outerGroup.add("group");
        leftGroup.orientation = "row";
        leftGroup.alignChildren = "left";
        leftGroup.alignment = ["left", "center"];
        var exportButton = leftGroup.add("button", undefined, LABELS.exportLabel[uiLang]);

        var spacer = outerGroup.add("group");
        spacer.alignment = ["fill", "fill"];
        spacer.minimumSize.width = 10;

        var rightGroup = outerGroup.add("group");
        rightGroup.orientation = "row";
        rightGroup.alignChildren = ["right", "center"];
        rightGroup.alignment = ["right", "center"];
        rightGroup.spacing = 10;
        var cancelButton = rightGroup.add("button", undefined, LABELS.cancel[uiLang], { name: "cancel" });
        var okButton = rightGroup.add("button", undefined, LABELS.ok[uiLang], { name: "ok" });

        okButton.onClick = function() {
            dialog.close();
        };

        cancelButton.onClick = function() {
            for (var i = 0; i < originalFonts.length; i++) {
                try {
                    originalFonts[i].item.textRange.characterAttributes.textFont = originalFonts[i].font;
                } catch (e) {}
            }
            app.redraw();
            dialog.close();
        };

        exportButton.onClick = function() {
            var docPath = doc.fullName.fsName;
            var docName = doc.name.replace(/\.[^\.]+$/, "");
            var defaultFileName = docName + ((uiLang === "ja") ? "-ドキュメントフォント一覧.txt" : "-Document-Font-List.txt");

            var desktopFolder = Folder.desktop;
            var saveFile = new File(desktopFolder.fsName + "/" + defaultFileName);

            var fontNames = [];
            for (var i = 0; i < listBox.items.length; i++) {
                fontNames.push(listBox.items[i].fontDisplayName);
            }

            var output = "";
            output += LABELS.exportHeader[uiLang] + "\n\n";
            output += LABELS.exportDocLabel[uiLang] + docPath + "\n\n";
            output += LABELS.exportFontCount[uiLang] + fontNames.length + "\n\n";
            output += fontNames.join("\n") + "\n";

            try {
                saveFile.encoding = "UTF-8";
                saveFile.open("w");
                saveFile.write(output);
                saveFile.close();
                alert(LABELS.exportSuccess[uiLang] + saveFile.fsName);
            } catch (e) {
                alert(LABELS.exportFail[uiLang]);
            }
        };

        dialog.show();
        listBox.active = true;
    }

    main();
})();
