#target illustrator
app.preferences.setBooleanPreference('ShowExternalJSXWarning', false);

/*

### 概要

指定したレイヤーをテンプレート化し、レイヤー名に接頭辞を付けます。

詳細は README を参照してください。
https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/SetTemplateLayer.md

### Overview

Turns a chosen layer into a template layer and prefixes its name.

See the README for details.
https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/SetTemplateLayer.md

*/

// =========================================
// 基本情報 / Basic info
// =========================================
var SCRIPT_NAME     = "SetTemplateLayer";             /* スクリプト名 / script name */
var SCRIPT_VERSION  = "v1.0.1";                         /* バージョン / version */
var SCRIPT_AUTHOR   = "Masahiro Takano (@swwwitch)";  /* 作者 / author */
var SCRIPT_RELEASED = "";                             /* 最初のリリース日 / first release date */
var SCRIPT_UPDATED  = "2026-09-19";                             /* 更新日 / last updated */

var SCRIPT_README_JA = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/SetTemplateLayer.md"; /* README（日本語） */
var SCRIPT_README_EN = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/SetTemplateLayer.md"; /* README (English) */

// Released under the MIT license
// http://opensource.org/licenses/mit-license.php

(function() {

    // =========================================================
    // 設定 / Settings
    // =========================================================

    var specifiedLayerName = "下絵"; /* 「指定」選択時の対象レイヤー名 / Target layer name for the "Specified" option */
    var COMMENT_PREFIX = "// "; /* レイヤー名に付ける接頭辞 / Prefix added to the layer name */

    // =========================================================
    // ローカライズ / Localization
    // =========================================================

    var uiLang = ($.locale && $.locale.indexOf("ja") === 0) ? "ja" : "en";

    var LABELS = {
        dialogTitle:   { ja: "テンプレートレイヤー設定 " + SCRIPT_VERSION, en: "Template Layer Setup " + SCRIPT_VERSION },
        panelTarget:   { ja: "対象", en: "Target" },
        radioSelected: { ja: "選択しているレイヤー", en: "Selected layer" },
        radioSpecified:{ ja: "指定", en: "Specified" },
        prefixComment: { ja: "レイヤー名に「" + COMMENT_PREFIX + "」を付ける", en: "Prefix layer name with \"" + COMMENT_PREFIX + "\"" },
        cancel:        { ja: "キャンセル", en: "Cancel" },
        tipSelected:   { ja: "レイヤーパネルで選択中のレイヤーをテンプレートにします。", en: "Turns the layer selected in the Layers panel into a template." },
        tipSpecified:  { ja: "名前で指定したレイヤーをテンプレートにします。無ければ作成します。", en: "Turns the layer with the given name into a template, creating it if needed." },
        tipPrefix:     { ja: "テンプレート化したレイヤーの名前に接頭辞を付けて、見分けやすくします。", en: "Prefixes the name of the template layer so it stands out." }
    };

    function getLabel(key) {
        return LABELS[key][uiLang];
    }

    // 名前でレイヤーを検索（見つからなければ null） / Find a layer by name (null if missing)
    function findLayerByName(doc, name) {
        for (var i = 0; i < doc.layers.length; i++) {
            if (doc.layers[i].name === name) {
                return doc.layers[i];
            }
        }
        return null;
    }

    // レイヤーをテンプレート化（任意で接頭辞を付与） / Turn a layer into a template (optionally prefix its name)
    function applyTemplateLayer(layer, addPrefix) {
        layer.visible = true;               // 表示する
        layer.locked = true;                // ロックする
        layer.printable = false;            // 印刷しない
        layer.dimPlacedImages = true;       // 配置した画像を薄く（暗く）表示する

        // レイヤー名に接頭辞を付ける（重複付与を防ぐ） / Prefix layer name (avoid duplicating)
        if (addPrefix && layer.name.indexOf(COMMENT_PREFIX) !== 0) {
            layer.name = COMMENT_PREFIX + layer.name;
        }
    }

    // =========================================================
    // 事前チェック / Pre-checks
    // =========================================================

    if (app.documents.length === 0) {
        alert("ドキュメントが開かれていません。");
        return;
    }

    var activeDoc = app.activeDocument;

    // =========================================================
    // ダイアログ / Dialog
    // =========================================================

    var dialog = new Window("dialog", getLabel("dialogTitle"));
    dialog.orientation = "column";
    dialog.alignChildren = "fill";
    dialog.margins = 16;
    dialog.spacing = 12;

    // --- パネル：対象 / Panel: Target ---
    var targetLayerPanel = dialog.add("panel", undefined, getLabel("panelTarget"));
    targetLayerPanel.orientation = "column";
    targetLayerPanel.alignChildren = "left";
    targetLayerPanel.margins = [16, 20, 16, 12];
    targetLayerPanel.spacing = 8;

    var selectedLayerRadio = targetLayerPanel.add("radiobutton", undefined, getLabel("radioSelected"));
    selectedLayerRadio.helpTip = getLabel("tipSelected");

    // 「指定 ____」を 1 行で構成 / Build "Specified ____" on one row
    var specifiedLayerRow = targetLayerPanel.add("group");
    specifiedLayerRow.orientation = "row";
    specifiedLayerRow.spacing = 2;
    var specifiedLayerRadio = specifiedLayerRow.add("radiobutton", undefined, getLabel("radioSpecified"));
    specifiedLayerRadio.helpTip = getLabel("tipSpecified");
    var specifiedLayerInput = specifiedLayerRow.add("edittext", undefined, specifiedLayerName);
    specifiedLayerInput.helpTip = getLabel("tipSpecified");
    specifiedLayerInput.characters = 8;

    // 「下絵」レイヤーがあれば「指定」、無ければ現在のレイヤーを既定に / Default to "Specified" if the layer exists, otherwise the current layer
    var hasSpecifiedLayer = (findLayerByName(activeDoc, specifiedLayerName) !== null);
    specifiedLayerRadio.value = hasSpecifiedLayer;
    selectedLayerRadio.value = !hasSpecifiedLayer;

    // ラジオは別コンテナのため手動で排他制御 / Radios live in different containers, so enforce exclusivity manually
    function selectTarget(useSelected) {
        selectedLayerRadio.value = useSelected;
        specifiedLayerRadio.value = !useSelected;
    }
    selectedLayerRadio.onClick     = function() { selectTarget(true); };
    specifiedLayerRadio.onClick    = function() { selectTarget(false); };
    specifiedLayerInput.onActivate = function() { selectTarget(false); };

    // --- チェックボックス：レイヤー名に接頭辞を付ける / Checkbox: prefix layer name ---
    var prefixCommentCheckbox = dialog.add("checkbox", undefined, getLabel("prefixComment"));
    prefixCommentCheckbox.helpTip = getLabel("tipPrefix");
    prefixCommentCheckbox.value = true; /* 既定でON / Default: ON */

    // --- ボタン / Buttons（Mac 規約：Cancel → OK） ---
    var buttonGroup = dialog.add("group");
    buttonGroup.orientation = "row";
    buttonGroup.alignment = "center";
    buttonGroup.add("button", undefined, getLabel("cancel"), { name: "cancel" });
    buttonGroup.add("button", undefined, "OK", { name: "ok" });

    if (dialog.show() !== 1) {
        return; /* キャンセル / Cancelled */
    }

    var useSelectedLayer = selectedLayerRadio.value;
    var addCommentPrefix = prefixCommentCheckbox.value;

    // 入力が空なら既定のレイヤー名を使用 / Fall back to the default layer name when blank
    var resolvedLayerName = specifiedLayerInput.text.replace(/^\s+|\s+$/g, "");
    if (resolvedLayerName === "") {
        resolvedLayerName = specifiedLayerName;
    }

    // =========================================================
    // 対象レイヤーの決定 / Resolve target layer
    // =========================================================

    var targetLayer = useSelectedLayer
        ? activeDoc.activeLayer
        : findLayerByName(activeDoc, resolvedLayerName);

    if (!targetLayer) {
        alert(useSelectedLayer
            ? "選択しているレイヤーが取得できませんでした。"
            : "「" + resolvedLayerName + "」レイヤーが見つかりません。");
        return;
    }

    // =========================================================
    // テンプレートレイヤーの設定を適用 / Apply template layer settings
    // =========================================================

    applyTemplateLayer(targetLayer, addCommentPrefix);

    // 報告用は接頭辞を除いた名前 / Report the name without the prefix
    var displayLayerName = targetLayer.name;
    if (displayLayerName.indexOf(COMMENT_PREFIX) === 0) {
        displayLayerName = displayLayerName.substring(COMMENT_PREFIX.length);
    }

    alert("「" + displayLayerName + "」レイヤーをテンプレートに設定しました。");

})();
