#target illustrator
app.preferences.setBooleanPreference('ShowExternalJSXWarning', false);

/*

### 概要

クリップグループ（クリッピングマスク）の「マスクパス」と「内容」を調整します。
ダイアログの操作はオートプレビューで即時反映されます。

詳細は README を参照してください。
https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/ClipMaskAdjust.md

### Overview

Adjusts the mask path and the contents of a clipping group.
Every change in the dialog is reflected immediately as an auto-preview.

See the README for details.
https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/ClipMaskAdjust.md

*/

// =========================================
// 基本情報 / Basic info
// =========================================
var SCRIPT_NAME     = "ClipMaskAdjust";               /* スクリプト名 / script name */
var SCRIPT_VERSION  = "v3.0.1";                           /* バージョン / version */
var SCRIPT_AUTHOR   = "Masahiro Takano (@swwwitch)";  /* 作者 / author */
var SCRIPT_RELEASED = "2026-01-03";                   /* 最初のリリース日 / first release date */
var SCRIPT_UPDATED  = "2026-09-19";                   /* 更新日 / last updated */

var SCRIPT_README_JA = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/ClipMaskAdjust.md"; /* README（日本語） */
var SCRIPT_README_EN = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/ClipMaskAdjust.md"; /* README (English) */

// Released under the MIT license
// http://opensource.org/licenses/mit-license.php

(function () {
    var doc = app.activeDocument;
    var currentSelection = doc.selection;

    // 初期選択（参照）を保持：最終確定時に選択を戻すため
    var originalSelection = [];
    for (var si = 0; si < currentSelection.length; si++) originalSelection.push(currentSelection[si]);

    if (currentSelection.length === 0) {
        // ローカライズ後にアラートを出すため、ここでは LANG/L が未定義
        alert("Please select a clipping mask group.");
        return;
    }

    // --- Localization (JA / EN) ---
    var LANG = (app.locale && app.locale.indexOf('ja') === 0) ? 'ja' : 'en';
    var LABELS = {
        ja: {
            dialogTitle: 'クリップグループの調整',
            selectClipMask: 'クリッピングマスクを選択してください。',
            anchor: '基準点',
            fitScale: 'フィットとスケール',
            maskPath: 'マスクパス',
            cover: '縦横比を保持して切り取り',
            contain: '縦横比を保持して縮小',
            none: 'サイズ保持',
            manual: 'スケールを指定',
            maskNone: 'そのまま',
            fitFrame: '内容に合わせる',
            square: '正方形に',
            round: '角丸',
            roundPanel: '角丸',
            circle: '正円',
            cancel: 'キャンセル',
            ok: 'OK',
            tweak: '微調整',
            tipAnchor: 'サイズを変えるときに動かさない位置です。3×3のマスで選びます。',
            tipTweak: 'この値だけ位置をずらします。↑↓キーで増減できます。',
            tipCover: '縦横比を保ったまま、マスクを埋めるように内容を拡大します。はみ出た部分は切り取られます。',
            tipContain: '縦横比を保ったまま、内容全体がマスクに収まるように縮小します。',
            tipNone: '内容の大きさは変えません。',
            tipManual: '倍率を数値で指定します。',
            tipMaskNone: 'マスクパスの形はそのままにします。',
            tipFitFrame: 'マスクパスを内容の外接範囲に合わせます。',
            tipSquare: 'マスクパスを正方形にします。',
            tipRound: 'マスクパスの角を丸めます。右の欄で半径を指定します。',
            tipCircle: 'マスクパスを正円にします。',
            x: 'X',
            y: 'Y'
        },
        en: {
            dialogTitle: 'Clip Group Adjust',
            selectClipMask: 'Please select a clipping mask group.',
            anchor: 'Anchor',
            fitScale: 'Fit & Scale',
            maskPath: 'Mask Path',
            cover: 'Proportions (Fill)',
            contain: 'Proportions (Fit)',
            none: 'Keep Size',
            manual: 'Set Scale',
            maskNone: 'None',
            fitFrame: 'Fit to Content',
            square: 'Square',
            round: 'Round Corners',
            roundPanel: 'Round Corners',
            circle: 'Circle',
            cancel: 'Cancel',
            ok: 'OK',
            tweak: 'Nudge',
            x: 'X',
            y: 'Y'
        }
    };
    var L = LABELS[LANG];

    // ここでローカライズ済みメッセージに置き換える（LANG/L 決定後）
    if (currentSelection.length === 0) {
        alert(L.selectClipMask);
        return;
    }

    // =========================================
    // 単位 / Units
    // =========================================

    /* 単位コードに対応する表示ラベルと、1単位あたりのポイント数
       Unit code -> display label and points per unit */
    var UNITS = [
        { label: "in",    pointsPerUnit: 72 },                /* 0 */
        { label: "mm",    pointsPerUnit: 72 / 25.4 },         /* 1 */
        { label: "pt",    pointsPerUnit: 1 },                 /* 2 */
        { label: "pica",  pointsPerUnit: 12 },                /* 3 */
        { label: "cm",    pointsPerUnit: 72 / 2.54 },         /* 4 */
        { label: "Q",     pointsPerUnit: 72 / 25.4 * 0.25 },  /* 5 */
        { label: "px",    pointsPerUnit: 1 },                 /* 6 */
        { label: "ft/in", pointsPerUnit: 72 * 12 },           /* 7 */
        { label: "m",     pointsPerUnit: 72 / 25.4 * 1000 },  /* 8 */
        { label: "yd",    pointsPerUnit: 72 * 36 },           /* 9 */
        { label: "ft",    pointsPerUnit: 72 * 12 }            /* 10 */
    ];

    /* 単位コード5を「歯（H）」と表示する環境設定キー。文字サイズ（text/units）だけ「級（Q）」
       Preference keys that show unit code 5 as H; only the type size (text/units) shows Q */
    var HA_UNIT_PREF_KEYS = { "rulerType": true, "strokeUnits": true, "text/asianunits": true };


    /**
     * UnitValue に渡せる単位名を返す（UnitValue が扱えない単位は pt に寄せる）
     * @returns {string} "mm" などの単位名
     */
    function getUnitValueUnit() {
        var unitCode = getUnitInfo().code;
        /* UnitValue は ft/in・m・yd・ft を扱えないため pt に寄せる / UnitValue does not take those */
        return (unitCode >= 0 && unitCode <= 6) ? UNITS[unitCode].label : "pt";
    }

    /**
     * 環境設定キーの単位を返す
     * @param {string} [prefKey] - "rulerType"（既定）/ "strokeUnits" / "text/units" / "text/asianunits"
     * @returns {{code: number, label: string, pointsPerUnit: number}} 単位の情報
     */
    function getUnitInfo(prefKey) {
        var unitKey = prefKey || "rulerType";
        var unitCode = app.preferences.getIntegerPreference(unitKey);
        /* 未知のコードは pt に寄せる / unknown codes fall back to points */
        var unit = UNITS[unitCode] || UNITS[2];
        /* 級（Q）と歯（H）は同じ長さだが、文字サイズは「Q」、距離は「H」と呼び分ける */
        var label = (unitCode === 5 && HA_UNIT_PREF_KEYS[unitKey]) ? "H" : unit.label;
        return { code: unitCode, label: label, pointsPerUnit: unit.pointsPerUnit };
    }

    function valueInCurrentUnitToPt(n) {
        var u = getUnitValueUnit();
        try {
            return new UnitValue(n, u).as('pt');
        } catch (e) {
            return n; // フォールバック（pt想定）
        }
    }

    function ptToValueInCurrentUnit(pt) {
        var u = getUnitValueUnit();
        try {
            return new UnitValue(pt, 'pt').as(u);
        } catch (e) {
            return pt;
        }
    }

    var CURRENT_UNIT_LABEL = getUnitInfo().label;

    // --- アピアランス消去（クリップグループ対象） ---
    // executeMenuCommand("clearAppearance") では環境差が出ることがあるため、アクションを一時生成して実行
    var CLEAR_APPEARANCE_ACTION_CODE = [
        "/version 3",
        "/name [ 20",
        "    5f5f7374746b335f617070656172616e63655f5f",
        "]",
        "/isOpen 1",
        "/actionCount 1",
        "/action-1 {",
        "    /name [ 5",
        "        636c656172",
        "    ]",
        "    /keyIndex 0",
        "    /colorIndex 0",
        "    /isOpen 0",
        "    /eventCount 1",
        "    /event-1 {",
        "        /useRulersIn1stQuadrant 0",
        "        /internalName (ai_plugin_appearance)",
        "        /localizedName [ 18",
        "            e382a2e38394e382a2e383a9e383b3e382b9",
        "        ]",
        "        /isOpen 0",
        "        /isOn 1",
        "        /hasDialog 0",
        "        /parameterCount 1",
        "        /parameter-1 {",
        "            /key 1835363957",
        "            /showInPalette 4294967295",
        "            /type (enumerated)",
        "            /name [ 27",
        "                e382a2e38394e382a2e383a9e383b3e382b9e38292e6b688e58ebb",
        "            ]",
        "            /value 6",
        "        }",
        "    }",
        "}"
    ].join("\n");

    function tempAction(actionCode, func) {
        var hexToString = function (hex) {
            return decodeURIComponent(hex.replace(/(.{2})/g, '%$1'));
        };

        var ActionItem = function ActionItem(index, name, parent) {
            this.index = index;
            this.name = name; // actionName
            this.parent = parent; // setName
        };
        ActionItem.prototype.exec = function (showDialog) {
            doScript(this.name, this.parent, showDialog);
        };

        var ActionItems = function ActionItems() { this.length = 0; };
        ActionItems.prototype.getByName = function (nameStr) {
            for (var i = 0, len = this.length; i < len; i++) {
                if (this[i].name == nameStr) return this[i];
            }
        };
        ActionItems.prototype.index = function (keyNumber) {
            if (keyNumber >= 0) return this[keyNumber];
            return this[this.length + keyNumber];
        };

        var regExpSetName = /^\/name\s+\[\s+\d+\s+([^\]]+?)\s+\]/m;
        var setNameMatch = actionCode.match(regExpSetName);
        // 何らかの理由でパースできない場合のフォールバック
        var setName = setNameMatch ? hexToString(setNameMatch[1].replace(/\s+/g, '')) : '__sttk3_appearance__';

        var regExpActionNames = /^\/action-\d+\s+\{\s+\/name\s+\[\s+\d+\s+([^\]]+?)\s+\]/mg;
        var actionItemsObj = new ActionItems();
        var i = 0;
        var matchObj;
        while ((matchObj = regExpActionNames.exec(actionCode))) {
            var actionName = hexToString(matchObj[1].replace(/\s+/g, ''));
            var actionObj = new ActionItem(i, actionName, setName);
            actionItemsObj[actionName] = actionObj;
            actionItemsObj[i] = actionObj;
            i++;
            if (i > 1000) break;
        }
        actionItemsObj.length = i;

        var failed = false;
        var aiaFileObj = new File(Folder.temp + '/tempActionSet.aia');
        try {
            aiaFileObj.open('w');
            aiaFileObj.write(actionCode);
        } catch (e) {
            failed = true;
            alert(e);
            return;
        } finally {
            aiaFileObj.close();
            if (failed) { try { aiaFileObj.remove(); } catch (e2) { } }
        }

        try { app.unloadAction(setName, ''); } catch (e3) { }

        var actionLoaded = false;
        var executed = false;
        try {
            app.loadAction(aiaFileObj);
            actionLoaded = true;
            func.call(func, actionItemsObj);
            executed = true;
        } catch (e4) {
            // ここではアラートを出さず、失敗してもスクリプト自体は継続
        } finally {
            if (actionLoaded) { try { app.unloadAction(setName, ''); } catch (e5) { } }
            try { aiaFileObj.remove(); } catch (e6) { }
        }
        return executed;
    }

    function setSelection(items) {
        try { app.executeMenuCommand('deselectall'); } catch (e) { }
        for (var i = 0; i < items.length; i++) {
            try { items[i].selected = true; } catch (e2) { }
        }
    }

    function clearAppearanceForClipGroups(selection) {
        // 現在の選択を保持（参照でOK）
        var original = [];
        for (var i = 0; i < selection.length; i++) original.push(selection[i]);

        var anyCleared = false;

        for (var j = 0; j < selection.length; j++) {
            var it = selection[j];
            if (it && it.typename === 'GroupItem' && it.clipped) {
                setSelection([it]);
                var ok = tempAction(CLEAR_APPEARANCE_ACTION_CODE, function (actionItems) {
                    actionItems[0].exec(false);
                });
                if (ok) anyCleared = true;
            }
        }

        // 選択状態を元に戻す
        setSelection(original);

        return anyCleared;
    }

    // --- 補助関数：角丸デフォルト値（pt）を計算 ---
    // （マスクパスの幅＋マスクパスの高さ）÷25（端数は繰り上げ）
    function getDefaultRoundRadiusFromMask(groupItem) {
        try {
            if (!groupItem || groupItem.typename !== 'GroupItem' || !groupItem.clipped) return null;
            var clipPath = null;
            for (var i = 0; i < groupItem.pageItems.length; i++) {
                var p = groupItem.pageItems[i];
                if (p && p.clipping) { clipPath = p; break; }
            }
            if (!clipPath) return null;
            var b = clipPath.geometricBounds; // [L, T, R, B]
            var w = b[2] - b[0];
            var h = b[1] - b[3];
            if (!isFinite(w) || !isFinite(h)) return null;
            var vPt = (w + h) / 25;
            if (!isFinite(vPt)) return null;
            // 現在の単位に変換して表示用の値を作る（端数は繰り上げ）
            var v = ptToValueInCurrentUnit(vPt);
            return Math.ceil(v);
        } catch (e) {
            return null;
        }
    }

    // --- 補助関数：現在のスケール（％）を取得 ---
    function getCurrentScale(groupItem) {
        var contents = [];
        for (var i = 0; i < groupItem.pageItems.length; i++) {
            if (!groupItem.pageItems[i].clipping) contents.push(groupItem.pageItems[i]);
        }
        if (contents.length === 0) return 100;
        var target = contents[0];
        var m = target.matrix;
        var scaleX = Math.sqrt(m.mValueA * m.mValueA + m.mValueB * m.mValueB);
        return (scaleX * 100).toFixed(2);
    }

    // --- 角丸用XML生成 ---
    function createRoundCornersEffectXML(radius) {
        var xml = '<LiveEffect name="Adobe Round Corners"><Dict data="R radius #value# "/></LiveEffect>';
        return xml.replace('#value#', radius);
    }

    // --- Round Corners: avoid stacking duplicate LiveEffects ---
    function stripRoundCornersEffect(effectStr) {
        if (!effectStr) return '';
        // Match any LiveEffect whose name contains "Round Corners" (handles serialization/name variants)
        return effectStr.replace(/<LiveEffect\b[^>]*\bname=['\"][^'\"]*Round Corners[^'\"]*['\"][^>]*>[\s\S]*?<\/LiveEffect>/g, '');
    }

    function removeRoundCornersEffect(targetItem) {
        if (!targetItem) return;
        try {
            var current = targetItem.appliedEffect || '';
            targetItem.appliedEffect = stripRoundCornersEffect(current);
        } catch (e) {
            // ignore
        }
    }

    function applyRoundCornersEffect(targetItem, radiusPt) {
        if (!targetItem) return;
        try {
            // まず既存の角丸だけ除去（他の効果は維持）
            var current = targetItem.appliedEffect || '';
            current = stripRoundCornersEffect(current);
            // appliedEffect の直接連結は環境によって無視されることがあるため、
            // 一度 appliedEffect を更新してから applyEffect で追加する
            targetItem.appliedEffect = current;
            targetItem.applyEffect(createRoundCornersEffectXML(radiusPt));
        } catch (e) {
            // Fallback: 何もしない（角丸は必須ではない）
            try { targetItem.applyEffect(createRoundCornersEffectXML(radiusPt)); } catch (e2) { }
        }
    }

    // Try to update the radius value inside an existing Round Corners LiveEffect without re-applying.
    // Returns true if updated, false if the effect block was not found or could not be rewritten.
    function updateRoundCornersRadiusOnly(targetItem, radiusPt) {
        if (!targetItem) return false;
        try {
            var effects = targetItem.appliedEffect || '';
            if (!effects) return false;

            // Round Corners を含む LiveEffect ブロックを抜き出す（名前の揺れ対策）
            var reEffect = /<LiveEffect\b[^>]*\bname=['\"][^'\"]*Round Corners[^'\"]*['\"][^>]*>[\s\S]*?<\/LiveEffect>/;
            var m = effects.match(reEffect);
            if (!m || !m[0]) return false;

            var block = m[0];

            // ブロック内の "R radius <number>" の最初の1箇所だけ差し替え
            var reRadius = /(R\s+radius\s+)(-?\d+(?:\.\d+)?)/;
            if (!reRadius.test(block)) return false;

            var newBlock = block.replace(reRadius, function (_, p1) {
                return p1 + String(radiusPt);
            });

            // 差し替えたブロックを戻す
            var newEffects = effects.replace(block, newBlock);
            targetItem.appliedEffect = newEffects;
            return true;
        } catch (e) {
            return false;
        }
    }

    // --- 矢印キーでの数値増減機能 ---
    function changeValueByArrowKey(editText, onUpdate, allowNegative) {
        editText.addEventListener("keydown", function (event) {
            var value = Number(editText.text);
            if (isNaN(value)) return;

            var keyboard = ScriptUI.environment.keyboardState;
            var delta = 1;

            if (keyboard.shiftKey) {
                delta = 10;
                if (event.keyName == "Up") {
                    value = Math.ceil((value + 1) / delta) * delta;
                    event.preventDefault();
                } else if (event.keyName == "Down") {
                    value = Math.floor((value - 1) / delta) * delta;
                    if (!allowNegative && value < 0) value = 0;
                    event.preventDefault();
                }
            } else if (keyboard.altKey) {
                delta = 0.1;
                if (event.keyName == "Up") {
                    value += delta;
                    event.preventDefault();
                } else if (event.keyName == "Down") {
                    value -= delta;
                    event.preventDefault();
                }
            } else {
                delta = 1;
                if (event.keyName == "Up") {
                    value += delta;
                    event.preventDefault();
                } else if (event.keyName == "Down") {
                    value -= delta;
                    if (!allowNegative && value < 0) value = 0;
                    event.preventDefault();
                }
            }

            if (keyboard.altKey) {
                value = Math.round(value * 10) / 10;
            } else {
                value = Math.round(value);
            }

            editText.text = value;
            if (onUpdate) onUpdate();
        });
    }

    var initialScale = getCurrentScale(currentSelection[0]);

    // UI作成
    var win = new Window("dialog", L.dialogTitle);
    win.orientation = "column";
    win.alignChildren = ["center", "top"];
    win.spacing = 15;

    var mainGroup = win.add("group");
    mainGroup.orientation = "row";
    mainGroup.alignChildren = ["fill", "top"];
    mainGroup.spacing = 10;
    var commonMargins = [15, 20, 15, 10];

    // --- 1. 基準点 ---
    var leftCol = mainGroup.add("group");
    leftCol.orientation = "column";
    leftCol.alignChildren = ["fill", "top"];
    leftCol.spacing = 10;

    var anchorPanel = leftCol.add("panel", undefined, L.anchor);
    anchorPanel.margins = commonMargins;
    anchorPanel.alignChildren = ["center", "center"];
    var anchorRadios = [];
    var matrixGroup = anchorPanel.add("group");
    matrixGroup.orientation = "column";
    matrixGroup.spacing = 5;
    for (var i = 0; i < 3; i++) {
        var row = matrixGroup.add("group");
        for (var j = 0; j < 3; j++) {
            var r = row.add("radiobutton", undefined, "");
            r.helpTip = L.tipAnchor;
            r.size = [15, 15];
            anchorRadios.push(r);
        }
    }
    anchorRadios[4].value = true;

    // --- 1.1 微調整 ---
    var tweakPanel = leftCol.add("panel", undefined, L.tweak);
    tweakPanel.margins = commonMargins;
    tweakPanel.alignChildren = ["left", "top"];
    tweakPanel.spacing = 6;

    var tweakXGroup = tweakPanel.add("group");
    tweakXGroup.orientation = "row";
    tweakXGroup.spacing = 5;
    tweakXGroup.add("statictext", undefined, L.x);
    var tweakXInput = tweakXGroup.add("edittext", undefined, "0");
    tweakXInput.helpTip = L.tipTweak;
    tweakXInput.characters = 4;
    tweakXGroup.add("statictext", undefined, CURRENT_UNIT_LABEL);

    var tweakYGroup = tweakPanel.add("group");
    tweakYGroup.orientation = "row";
    tweakYGroup.spacing = 5;
    tweakYGroup.add("statictext", undefined, L.y);
    var tweakYInput = tweakYGroup.add("edittext", undefined, "0");
    tweakYInput.helpTip = L.tipTweak;
    tweakYInput.characters = 4;
    tweakYGroup.add("statictext", undefined, CURRENT_UNIT_LABEL);

    changeValueByArrowKey(tweakXInput, updatePreview, true);
    changeValueByArrowKey(tweakYInput, updatePreview, true);
    tweakXInput.onChanging = updatePreview;
    tweakYInput.onChanging = updatePreview;

    // --- 2. スケール ---
    var fitPanel = mainGroup.add("panel", undefined, L.fitScale);
    fitPanel.margins = commonMargins;
    fitPanel.alignChildren = ["left", "top"];
    fitPanel.spacing = 8;

    var radioCover = fitPanel.add("radiobutton", undefined, L.cover);
    radioCover.helpTip = L.tipCover;
    var radioContain = fitPanel.add("radiobutton", undefined, L.contain);
    radioContain.helpTip = L.tipContain;
    var radioNone = fitPanel.add("radiobutton", undefined, L.none);
    radioNone.helpTip = L.tipNone;

    var manualScaleGroup = fitPanel.add("group");
    manualScaleGroup.orientation = "row";
    manualScaleGroup.spacing = 5;
    var radioManual = manualScaleGroup.add("radiobutton", undefined, L.manual);
    radioManual.helpTip = L.tipManual;
    var scaleInput = manualScaleGroup.add("edittext", undefined, initialScale);
    scaleInput.helpTip = L.tipManual;
    scaleInput.characters = 6;
    manualScaleGroup.add("statictext", undefined, "%");

    radioNone.value = true;
    changeValueByArrowKey(scaleInput, function () { setScaleRadio(radioManual); updatePreview(); });

    // --- 3. マスクパス ---
    var rightCol = mainGroup.add("group");
    rightCol.orientation = "column";
    rightCol.alignChildren = ["fill", "top"];
    rightCol.spacing = 10;

    var maskPanel = rightCol.add("panel", undefined, L.maskPath);
    maskPanel.margins = commonMargins;
    maskPanel.orientation = "column";
    maskPanel.alignChildren = ["left", "top"];
    maskPanel.spacing = 8;

    var maskNone = maskPanel.add("radiobutton", undefined, L.maskNone);
    maskNone.helpTip = L.tipMaskNone;
    var radioFitFrame = maskPanel.add("radiobutton", undefined, L.fitFrame);
    radioFitFrame.helpTip = L.tipFitFrame;
    var radioSquare = maskPanel.add("radiobutton", undefined, L.square);
    radioSquare.helpTip = L.tipSquare;

    // --- 3.1 角丸 ---
    var roundPanel = rightCol.add("panel", undefined, L.roundPanel);
    roundPanel.margins = commonMargins;
    roundPanel.orientation = "column";
    roundPanel.alignChildren = ["left", "top"];
    roundPanel.spacing = 8;

    var roundGroup = roundPanel.add("group");
    roundGroup.orientation = "row";
    roundGroup.spacing = 5;
    var checkRound = roundGroup.add("checkbox", undefined, L.round);
    checkRound.helpTip = L.tipRound;
    var defaultRound = getDefaultRoundRadiusFromMask(currentSelection[0]);
    var roundInput = roundGroup.add("edittext", undefined, (defaultRound != null ? String(defaultRound) : "10"));
    roundInput.helpTip = L.tipRound;
    roundInput.characters = 4;
    roundGroup.add("statictext", undefined, CURRENT_UNIT_LABEL);

    // ［正円］（ロジックは後で追加）
    var checkCircle = roundPanel.add("checkbox", undefined, L.circle);
    checkCircle.helpTip = L.tipCircle;
    checkCircle.value = false;
    updateCircleAvailability();

    maskNone.value = true;
    checkRound.value = false;
    changeValueByArrowKey(roundInput, function () { checkRound.value = true; clearAppearanceForClipGroups(currentSelection); updatePreview(); });
    // ボタン
    var btnGroup = win.add("group");
    var cancelBtn = btnGroup.add("button", undefined, L.cancel, { name: "cancel" });
    var okBtn = btnGroup.add("button", undefined, L.ok, { name: "ok" });

    // ---------------------------------------------------------
    // ロジック
    // ---------------------------------------------------------

    // 基準点ショートカット
    win.addEventListener("keydown", function (event) {
        if (win.activeControl === scaleInput || win.activeControl === roundInput) return;
        var key = event.keyName.toLowerCase();
        var keyMap = { 'q': 0, 'w': 1, 'e': 2, 'a': 3, 's': 4, 'd': 5, 'z': 6, 'x': 7, 'c': 8 };
        if (keyMap.hasOwnProperty(key)) {
            setAnchorRadio(keyMap[key]);
            resetTweakXY();
            updatePreview();
        }
    });

    var scaleRadios = [radioCover, radioContain, radioNone, radioManual];
    function setScaleRadio(selectedRadio) {
        for (var i = 0; i < scaleRadios.length; i++) scaleRadios[i].value = (scaleRadios[i] === selectedRadio);
    }

    function setAnchorRadio(index) {
        for (var i = 0; i < anchorRadios.length; i++) {
            anchorRadios[i].value = (i === index);
        }
    }

    function resetTweakXY() {
        tweakXInput.text = '0';
        tweakYInput.text = '0';
    }

    function updateCircleAvailability() {
        // 「正方形に」のときのみ「正円」を使える
        checkCircle.enabled = !!radioSquare.value;
    }

    function setRoundRadiusToHalfOfSquareMask() {
        try {
            var g = currentSelection[0];
            if (!g || g.typename !== 'GroupItem' || !g.clipped) return;

            // クリッピングパスを取得
            var clipPath = null;
            for (var i = 0; i < g.pageItems.length; i++) {
                var p = g.pageItems[i];
                if (p && p.clipping) { clipPath = p; break; }
            }
            if (!clipPath) return;

            // 見た目の寸法を基準にする（stroke等の影響を含める）
            var b = clipPath.visibleBounds; // [L,T,R,B]
            var w = b[2] - b[0];
            var h = b[1] - b[3];
            if (!isFinite(w) || !isFinite(h)) return;

            // 半径＝幅または高さの半分（正方形なら同値）→半径＝短辺の半分
            var radiusPt = Math.min(w, h) / 2;

            // 表示用：現在の rulerType 単位へ変換
            var v = ptToValueInCurrentUnit(radiusPt);
            v = Math.round(v * 100) / 100; // 小数2桁で整形
            roundInput.text = String(v);
        } catch (e) {
            // 失敗しても無視
        }
    }

    function getInputState() {
        var anchorIndex = 4;
        for (var i = 0; i < anchorRadios.length; i++) {
            if (anchorRadios[i].value) { anchorIndex = i; break; }
        }

        var fitMode = "cover";
        if (radioContain.value) fitMode = "contain";
        else if (radioNone.value) fitMode = "none";
        else if (radioManual.value) fitMode = "manual";

        var maskMode = "none";
        if (radioFitFrame.value) maskMode = "fitFrame";
        else if (radioSquare.value) maskMode = "makeSquare";

        var applyRound = !!checkRound.value;
        var manualScaleVal = parseFloat(scaleInput.text) || 100;
        var roundVal = valueInCurrentUnitToPt(parseFloat(roundInput.text) || 0);
        var tweakX = valueInCurrentUnitToPt(parseFloat(tweakXInput.text) || 0);
        var tweakY = valueInCurrentUnitToPt(parseFloat(tweakYInput.text) || 0);

        return {
            anchorIndex: anchorIndex,
            fitMode: fitMode,
            maskMode: maskMode,
            applyRound: applyRound,
            manualScaleVal: manualScaleVal,
            roundVal: roundVal,
            tweakX: tweakX,
            tweakY: tweakY
        };
    }

    function updatePreview() {
        // Undo を使わずに直接反映（角丸の重複だけは毎回除去してから再適用）
        for (var i = 0; i < currentSelection.length; i++) {
            var it = currentSelection[i];
            if (it && it.typename === 'GroupItem' && it.clipped) {
                removeRoundCornersEffect(it);
            }
        }

        var state = getInputState();
        processSelection(currentSelection, state.fitMode, state.maskMode, state.anchorIndex, state.manualScaleVal, state.roundVal, state.applyRound, state.tweakX, state.tweakY);
        if (state.fitMode !== "manual") scaleInput.text = getCurrentScale(currentSelection[0]);

        app.redraw();
    }

    radioCover.onClick = function () { setScaleRadio(this); updatePreview(); };
    radioContain.onClick = function () { setScaleRadio(this); updatePreview(); };
    radioNone.onClick = function () { setScaleRadio(this); updatePreview(); };
    radioManual.onClick = function () { setScaleRadio(this); updatePreview(); };

    radioSquare.onClick = function () {
        // 「正方形に」を選択したときは中央基準＆カバーに固定
        setScaleRadio(radioCover);
        for (var j = 0; j < anchorRadios.length; j++) anchorRadios[j].value = (j === 4);

        // 「正円」は「正方形に」のときのみ
        updateCircleAvailability();

        // 「正方形に」選択だけでは角丸値は変更しない（角丸値の自動設定は［正円］ON時のみ）
        updatePreview();
    };

    radioFitFrame.onClick = function () { updateCircleAvailability(); updatePreview(); };
    maskNone.onClick = function () { updateCircleAvailability(); updatePreview(); };
    checkRound.onClick = function () {
        // ［角丸］をOFFにしたら、クリップグループのアピアランスを消去して重複を防ぐ
        if (!checkRound.value) {
            clearAppearanceForClipGroups(currentSelection);
        }
        updatePreview();
    };
    checkCircle.onClick = function () {
        // ONにしたら「角丸」を自動ONし、半径を幅/高さの半分に設定
        if (checkCircle.value) {
            checkRound.value = true;
            setRoundRadiusToHalfOfSquareMask();

            // 角丸の値（UI表示）→ pt に変換
            var radiusPt = valueInCurrentUnitToPt(parseFloat(roundInput.text) || 0);

            // 既存の LiveEffect があれば「半径だけ」更新（新規適用しない）
            var ok = updateRoundCornersRadiusOnly(currentSelection[0], radiusPt);

            // 難しい場合（見つからない／形式が違う）は、アピアランス消去→再適用
            if (!ok) {
                clearAppearanceForClipGroups(currentSelection);
                applyRoundCornersEffect(currentSelection[0], radiusPt);
            }

            app.redraw();
            return;
        }

        // OFF にしただけでは処理を走らせない（新規に［角を丸くする］が適用されるのを防ぐ）
        app.redraw();
        return;
    };

    scaleInput.onChanging = function () {
        setScaleRadio(radioManual);
        updatePreview();
    };
    roundInput.onChanging = function () {
        checkRound.value = true;
        clearAppearanceForClipGroups(currentSelection);
        updatePreview();
    };
    for (var i = 0; i < anchorRadios.length; i++) {
        (function (idx) {
            anchorRadios[idx].onClick = function () {
                setAnchorRadio(idx);
                resetTweakXY();
                updatePreview();
            };
        })(i);
    }

    okBtn.onClick = function () {
        var state = getInputState();

        // 選択を戻してから処理（複数選択にも対応）
        setSelection(originalSelection);

        // 実行時に1回：クリップグループのアピアランスを消去
        clearAppearanceForClipGroups(originalSelection);

        // 入力状態で最終適用
        processSelection(originalSelection, state.fitMode, state.maskMode, state.anchorIndex, state.manualScaleVal, state.roundVal, state.applyRound, state.tweakX, state.tweakY);

        app.redraw();
        win.close();
    };
    cancelBtn.onClick = function () {
        // Undo を使わないため、現状の反映状態のまま閉じる
        win.close();
    };

    // 実行時に1回だけ：クリップグループのアピアランスを消去
    clearAppearanceForClipGroups(currentSelection);

    updatePreview();
    win.show();

    function processSelection(selection, fitMode, maskMode, anchorIndex, manualScale, roundVal, applyRound, tweakX, tweakY) {
        for (var i = 0; i < selection.length; i++) {
            var item = selection[i];
            if (item.typename === "GroupItem" && item.clipped) {
                fitContent(item, fitMode, maskMode, anchorIndex, manualScale, roundVal, applyRound, tweakX, tweakY);
            }
        }
    }

    function fitContent(groupItem, fitMode, maskMode, anchorIndex, manualScale, roundVal, applyRound, tweakX, tweakY) {
        var clipPath = null;
        var contents = [];
        for (var i = 0; i < groupItem.pageItems.length; i++) {
            var p = groupItem.pageItems[i];
            if (p.clipping) clipPath = p; else contents.push(p);
        }
        if (!clipPath || contents.length === 0) return;

        // 形状変更
        if (maskMode === "makeSquare") {
            var b = clipPath.geometricBounds;
            var w = b[2] - b[0], h = b[1] - b[3];
            var side = Math.min(w, h);
            var cx = b[0] + w / 2, cy = b[1] - h / 2;
            clipPath.width = side;
            clipPath.height = side;
            clipPath.position = [cx - side / 2, cy + side / 2];
        } else if (maskMode === "fitFrame") {
            var cb = getCombinedBounds(contents);
            if (cb) {
                clipPath.position = [cb[0], cb[1]];
                clipPath.width = cb[2] - cb[0];
                clipPath.height = cb[1] - cb[3];
                // ここでは return しない：後続の「フィットとスケール」処理を有効にする
            }
        }

        // 角丸エフェクト適用（対象をクリップグループに変更）
        if (applyRound) {
            applyRoundCornersEffect(groupItem, roundVal);
        }

        // 位置合わせは visibleBounds を基準に（上揃えがズレるケース対策）
        var frameBounds = clipPath.visibleBounds;
        var fW = frameBounds[2] - frameBounds[0];
        var fH = frameBounds[1] - frameBounds[3];

        for (var k = 0; k < contents.length; k++) {
            var content = contents[k];
            var cBounds = content.visibleBounds;
            var cW = cBounds[2] - cBounds[0];
            var cH = cBounds[1] - cBounds[3];

            var ratio = 1.0;
            if (fitMode === "cover") ratio = Math.max(fW / cW, fH / cH);
            else if (fitMode === "contain") ratio = Math.min(fW / cW, fH / cH);
            else if (fitMode === "manual") {
                var currentS = parseFloat(getCurrentScale(groupItem)) / 100;
                var targetS = manualScale / 100;
                ratio = (currentS === 0) ? 0 : targetS / currentS;
            }

            if (fitMode !== "none") {
                content.resize(ratio * 100, ratio * 100, true, true, true, true, ratio * 100);
                cBounds = content.visibleBounds;
                cW = cBounds[2] - cBounds[0]; cH = cBounds[1] - cBounds[3];
            }

            var col = anchorIndex % 3, row = Math.floor(anchorIndex / 3);
            var fRefX = (col === 0) ? frameBounds[0] : (col === 1) ? frameBounds[0] + fW / 2 : frameBounds[2];
            var fRefY = (row === 0) ? frameBounds[1] : (row === 1) ? frameBounds[1] - fH / 2 : frameBounds[3];
            var cRefX = (col === 0) ? cBounds[0] : (col === 1) ? cBounds[0] + cW / 2 : cBounds[2];
            var cRefY = (row === 0) ? cBounds[1] : (row === 1) ? cBounds[1] - cH / 2 : cBounds[3];
            content.translate((fRefX - cRefX) + tweakX, (fRefY - cRefY) + tweakY);
        }
    }

    function getCombinedBounds(items) {
        if (items.length === 0) return null;
        var b = items[0].geometricBounds;
        var l = b[0], t = b[1], r = b[2], bot = b[3];
        for (var i = 1; i < items.length; i++) {
            var nb = items[i].geometricBounds;
            if (nb[0] < l) l = nb[0]; if (nb[1] > t) t = nb[1];
            if (nb[2] > r) r = nb[2]; if (nb[3] < bot) bot = nb[3];
        }
        return [l, t, r, bot];
    }
})();
