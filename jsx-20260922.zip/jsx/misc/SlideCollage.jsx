#target illustrator
app.preferences.setBooleanPreference('ShowExternalJSXWarning', false);

/*

### 概要

指定した .ai / .pdf ファイルをグリッド配置し、ポートフォリオ用のサムネイル一覧を作成します。
読み込むアートボード番号やページを指定できます。

詳細は README を参照してください。
https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/SlideCollage.md

### Overview

Lays out the .ai and .pdf files you choose in a grid to build a portfolio-style thumbnail sheet.
The artboards or pages to import can be specified by number.

See the README for details.
https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/SlideCollage.md

*/

// =========================================
// 基本情報 / Basic info
// =========================================
var SCRIPT_NAME     = "SlideCollage";                 /* スクリプト名 / script name */
var SCRIPT_VERSION  = "v1.5.1";                         /* バージョン / version */
var SCRIPT_AUTHOR   = "Masahiro Takano (@swwwitch)";  /* 作者 / author */
var SCRIPT_RELEASED = "";                             /* 最初のリリース日 / first release date */
var SCRIPT_UPDATED  = "2026-09-19";                             /* 更新日 / last updated */

var SCRIPT_README_JA = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/SlideCollage.md"; /* README（日本語） */
var SCRIPT_README_EN = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/SlideCollage.md"; /* README (English) */

// Released under the MIT license
// http://opensource.org/licenses/mit-license.php

(function () {

    function getCurrentLang() {
        return ($.locale.indexOf("ja") === 0) ? "ja" : "en";
    }
    var uiLang = getCurrentLang();

    /* 日英ラベル定義 / Japanese-English label definitions */
    var LABELS = {
        dialogTitle: {
            ja: "Slide Collage for Illustrator",
            en: "Slide Collage for Illustrator"
        },

        // Panels
        panelLoad: { ja: "アートボードの読み込み", en: "Load Artboards" },
        panelSource: { ja: "読み込みファイル", en: "Source File" },
        panelItem: { ja: "アイテム", en: "Items" },
        panelGrid: { ja: "グリッド", en: "Grid" },
        panelLayout: { ja: "レイアウト", en: "Layout" },
        panelArtboard: { ja: "アートボードとマスク", en: "Artboard & Mask" },

        // Load panel
        labelArtboards: { ja: "アートボード", en: "Artboards" },
        btnLoad: { ja: "ファイル指定", en: "Select File" },
        btnImport: { ja: "読み込み", en: "Load" },
        range: { ja: "指定", en: "Range" },
        total: { ja: "総数", en: "Total" },
        dlgPickFile: { ja: "PDF/AIを選択してください", en: "Select a PDF/AI" },
        filterPick: { ja: "PDF/AI:*.pdf;*.ai", en: "PDF/AI:*.pdf;*.ai" },
        alertLinkUnknown: { ja: "画像のリンク先が不明でした。", en: "Image link not found." },
        alertPageCountFail: { ja: "リンク画像のページ数を取得できませんでした。", en: "Could not get the page length of PlacedItem." },
        alertPickPdfAi: { ja: "PDFまたはAIファイルを選択してください。", en: "Please select a PDF or AI file." },
        notSelected: { ja: "未指定", en: "Not selected" },

        // Item panel
        cropArt: { ja: "アート", en: "Art" },
        cropTrim: { ja: "トリミング", en: "Trim" },
        cropCrop: { ja: "仕上がり", en: "Crop" },
        cropBleed: { ja: "裁ち落とし", en: "Bleed" },
        round: { ja: "角丸", en: "Round" },

        // Grid panel
        direction: { ja: "方向：", en: "Flow: " },
        dirH: { ja: "横", en: "Horizontal" },
        dirV: { ja: "縦", en: "Vertical" },
        dirRandom: { ja: "ランダム", en: "Random" },
        dist: { ja: "配分：", en: "Distribution: " },
        evenPlus: { ja: "＋1スロット", en: "+1 slot" },
        cols: { ja: "列数", en: "Cols" },
        spacing: { ja: "間隔", en: "Gap" },
        shift: { ja: "ずらし", en: "Shift" },

        panelEven: { ja: "偶数列", en: "Even Columns" },

        // Layout panel
        scale: { ja: "スケール", en: "Scale" },
        rotate: { ja: "回転", en: "Rotate" },
        offsetX: { ja: "横方向の位置調整", en: "Offset X" },
        offsetY: { ja: "縦方向の位置調整", en: "Offset Y" },

        // Artboard panel
        margin: { ja: "マージン", en: "Margin" },
        mask: { ja: "マスク", en: "Mask" },
        maskRound: { ja: "マスク角丸", en: "Mask Round" },
        bg: { ja: "背景色", en: "Background" },

        // Buttons
        cancel: { ja: "キャンセル", en: "Cancel" },
        ok: { ja: "OK", en: "OK" },

        // Zoom
        zoom: { ja: "画面ズーム", en: "Zoom" },
        lightMode: { ja: "軽量モード", en: "Light mode" },

        // File / Alerts
        fileDialogTitle: { ja: "配置するファイル（.ai または .pdf）を選択してください", en: "Select a file to place (.ai or .pdf)" },
        alertNeedDoc: { ja: "ドキュメントを開いてから実行してください。", en: "Please open a document before running." },
        alertPlaceError: { ja: "配置中にエラーが発生しました。", en: "An error occurred while placing items." },
        alertNeedFile: { ja: "先に［ファイル指定］で読み込みファイルを選択してください。", en: "Please select a source file first." },

        // Units / Defaults
        unitPercent: { ja: "%", en: "%" },
        unitDegree: { ja: "°", en: "°" },
        gapSpace: { ja: " ", en: " " },

        defaultPages: { ja: "1-20", en: "1-20" },
        defaultHex: { ja: "#000000", en: "#000000" },
        defaultCols: { ja: "5", en: "5" },
        defaultSpacing: { ja: "0", en: "0" },
        defaultShift: { ja: "0", en: "0" },
        defaultScale: { ja: "100", en: "100" },
        defaultRotate: { ja: "-12", en: "-12" },
        defaultRound: { ja: "10", en: "10" }
    };

    function getLabel(key) {
        var o = LABELS[key];
        if (!o) return key;
        return o[uiLang] || o.en || o.ja || key;
    }

    // Safe alert helper (used by __TMKPageCount_ module)
    if (typeof safeAlertKey === "undefined") {
        var safeAlertKey = function (key) {
            try { alert(getLabel(key)); } catch (e) { }
        };
    }

    // =========================================
    // Unit utilities (rulerType)
    // =========================================

    /* 単位テーブル（配列の添字が rulerType コードと一致：0=in, 1=mm, 2=pt …）/ Unit table; the array index equals the rulerType code */
    var UNITS = [
        { label: "in",    pointsPerUnit: 72 },                /* 0 */
        { label: "mm",    pointsPerUnit: 72 / 25.4 },         /* 1 */
        { label: "pt",    pointsPerUnit: 1 },                 /* 2 */
        { label: "pica",  pointsPerUnit: 12 },                /* 3 */
        { label: "cm",    pointsPerUnit: 72 / 2.54 },         /* 4 */
        { label: "Q",     pointsPerUnit: 72 / 25.4 * 0.25 },  /* 5 */
        { label: "px",    pointsPerUnit: 1 },                 /* 6 */
        { label: "ft/in", pointsPerUnit: 72 * 12 },           /* 7 */
        { label: "m",     pointsPerUnit: 72 / 25.4 * 1000 },  /* 8 */
        { label: "yd",    pointsPerUnit: 72 * 36 },           /* 9 */
        { label: "ft",    pointsPerUnit: 72 * 12 }            /* 10 */
    ];

    /* 単位コード5を「歯（H）」と表示する環境設定キー。文字サイズ（text/units）だけ「級（Q）」
       Preference keys that show unit code 5 as H; only the type size (text/units) shows Q */
    var HA_UNIT_PREF_KEYS = { "rulerType": true, "strokeUnits": true, "text/asianunits": true };

    /**
     * 設定キーごとの単位情報を取得する
     * @param {string} prefKey - 環境設定キー（省略時は "rulerType"）
     * @returns {{code: number, label: string, pointsPerUnit: number}} 単位情報
     */
    function getUnitInfo(prefKey) {
        var unitKey = prefKey || "rulerType";
        var unitCode = app.preferences.getIntegerPreference(unitKey);
        var unit = UNITS[unitCode] || UNITS[2];
        var label = (unitCode === 5 && HA_UNIT_PREF_KEYS[unitKey]) ? "H" : unit.label;
        return { code: unitCode, label: label, pointsPerUnit: unit.pointsPerUnit };
    }

    function __SC_round(n, digits) {
        var p = Math.pow(10, digits);
        return Math.round(n * p) / p;
    }

    function __SC_ptToUnit(pt, factor) {
        if (!(factor > 0)) factor = 1;
        return pt / factor;
    }

    function __SC_unitToPt(val, factor) {
        if (!(factor > 0)) factor = 1;
        return val * factor;
    }

    // =========================================
    // PDF Import crop (trim / bleed / art)
    // =========================================

    // UI mode constants
    var __SC_CROP_ART = 4;
    var __SC_CROP_TRIM = 3;
    var __SC_CROP_BLEED = 2;
    var __SC_CROP_CROP = 1;
    var __SC_CROP_MEDIA = 0;

    // ============================================================
    // TMK Page Count Module (collision-safe)
    // - Estimate total pages (last page number) of linked PDF/AI
    // - No relink / no placedItems.add
    // ============================================================

    var PC = (function () {

        function PC_getLastPageFromSelection(selectionItems) {
            var placed = PC_findFirstPlacedItem(selectionItems);
            if (!placed) return null;

            var f = placed.file;
            if (!f) {
                safeAlertKey('alertLinkUnknown');
                return null;
            }

            var name = decodeURIComponent(f.name);
            if (!/\.(?:pdf|ai)$/i.test(name)) return null;

            var last = PC_getPageLengthFromFile(f);
            if (!last || isNaN(Number(last)) || Number(last) <= 0) {
                safeAlertKey('alertPageCountFail');
                return null;
            }

            return Number(last);
        }

        function PC_updateResultFromPlacedOrFile(doc, fileObjOrNull, setPathTextFn, setResultTextFn) {
            var placedTemp = null;

            try {
                // If a file is provided, place it temporarily to reuse existing selection-based logic
                if (fileObjOrNull) {
                    var name = decodeURIComponent(fileObjOrNull.name);
                    if (!/\.(?:pdf|ai)$/i.test(name)) {
                        safeAlertKey('alertPickPdfAi');
                        if (setResultTextFn) setResultTextFn(null);
                        return;
                    }

                    try {
                        placedTemp = doc.placedItems.add();
                        placedTemp.file = fileObjOrNull;

                        // Place near the visible top-left so it can be seen (briefly)
                        try {
                            var vb = doc.activeView && doc.activeView.bounds ? doc.activeView.bounds : null; // [left, top, right, bottom]
                            if (vb && vb.length === 4) {
                                placedTemp.position = [vb[0], vb[1]];
                            }
                        } catch (e) { }

                        // Use the existing logic without modifying it
                        var lastFromFile = PC_getLastPageFromSelection([placedTemp]);
                        if (setPathTextFn) setPathTextFn(fileObjOrNull);
                        if (setResultTextFn) setResultTextFn(lastFromFile);
                    } finally {
                        if (placedTemp) {
                            try { placedTemp.remove(); } catch (e) { }
                        }
                    }
                    return;
                }

                // No file provided: use current selection (PlacedItem must be selected)
                var last = PC_getLastPageFromSelection(doc.selection);

                // Attempt to show the currently selected placed file path
                try {
                    var placedSel = PC_findFirstPlacedItem(doc.selection);
                    if (placedSel && placedSel.file && setPathTextFn) setPathTextFn(placedSel.file);
                } catch (e) { }

                if (setResultTextFn) setResultTextFn(last);
            } catch (e) {
                alert(e);
                try { if (setResultTextFn) setResultTextFn(null); } catch (e) { }
            }
        }

        function PC_findFirstPlacedItem(items) {
            if (!items || items.length <= 0) return null;
            for (var i = 0; i < items.length; i++) {
                var it = items[i];
                if (!it) continue;
                var n = (it.constructor && it.constructor.name) ? it.constructor.name : '';
                if (n === 'PlacedItem') return it;
                if (n === 'GroupItem') {
                    var hit = PC_findFirstPlacedItem(it.pageItems);
                    if (hit) return hit;
                }
            }
            return null;
        }

        // pdf/aiから総ページ数を推定（既存ロジックを維持しつつ最小化）
        function PC_getPageLengthFromFile(file) {
            var tg = /<<\/Count\s(\d+)/;
            var c1 = /<<\/Type\/Page\/Parent/;
            var c2 = /\/Type\s\/Page\s/;
            var c3 = /\/StructParents\s\d+.*\/Type\/Page>>/;
            var tg2 = /<<\/Linearized\s.+\/N\s(\d+)\/T\s.+>>/;
            var tg3 = /\/Type\/Pages/;
            var tg4 = /\/Count\s(\d+)/;

            var res, wd, len = 0, num = 0;
            try {
                file.open('r');
                while (!file.eof) {
                    wd = file.readln();
                    if (tg.test(wd) || tg2.test(wd)) { res = Number(RegExp.$1); break; }
                    if (c1.test(wd) || c2.test(wd) || c3.test(wd)) len++;
                    if (tg3.test(wd)) {
                        wd = file.readln();
                        if (tg4.test(wd)) { num = Number(RegExp.$1); if (len < num) len = num; }
                    }
                }
                if (len > 0) res = len;
            } catch (e) {
                alert(e);
            } finally {
                try { file.close(); } catch (e) { }
            }
            return res;
        }
        function PC_countFromRangeText(s) {
            if (!s) return 0;
            s = String(s).replace(/\s+/g, '');
            s = s.replace(/^[\[\(\{\u3010\uFF3B]?/, '').replace(/[\]\)\}\u3011\uFF3D]?$/, '');
            if (!s) return 0;

            var parts = s.split(/[,\u3001]/);
            var seen = {};
            var count = 0;

            for (var i = 0; i < parts.length; i++) {
                var p = parts[i];
                if (!p) continue;

                var m = p.match(/^(\d+)-(\d+)$/);
                if (m) {
                    var a = parseInt(m[1], 10);
                    var b = parseInt(m[2], 10);
                    if (isNaN(a) || isNaN(b)) continue;
                    var step = (a <= b) ? 1 : -1;
                    for (var n = a; step > 0 ? n <= b : n >= b; n += step) {
                        var key = String(n);
                        if (!seen[key]) { seen[key] = true; count++; }
                    }
                    continue;
                }

                var v = parseInt(p, 10);
                if (!isNaN(v)) {
                    var k = String(v);
                    if (!seen[k]) { seen[k] = true; count++; }
                }
            }

            return count;
        }

        function PC_updateTotalFromRange(rangeText, currentTotalText) {
            try {
                var c = PC_countFromRangeText(rangeText);
                var cur = String(currentTotalText || '');
                if (!cur) {
                    return c ? String(c) : '';
                }
                return cur;
            } catch (e) { }
            return String(currentTotalText || '');
        }

        return {
            getLastPageFromSelection: PC_getLastPageFromSelection,
            updateResultFromPlacedOrFile: PC_updateResultFromPlacedOrFile,
            findFirstPlacedItem: PC_findFirstPlacedItem,
            getPageLengthFromFile: PC_getPageLengthFromFile,
            countFromRangeText: PC_countFromRangeText,
            updateTotalFromRange: PC_updateTotalFromRange
        };
    })();

    /**
     * Set PDF import crop box preference.
     * Illustrator のバージョン差異を吸収するため、複数キーに試行します。
     * 期待する値（多くの環境で）: 0=Media, 1=Crop, 2=Bleed, 3=Trim, 4=Art
     */
    function __SC_setPdfCropPreference(cropVal) {
        var keys = [
            "plugin/PDFImport/CropToBox",
            "plugin/PDFImport/CropTo",
            "plugin/PDFImport/CropBox",
            "plugin/PDFImport/CropToType"
        ];
        for (var i = 0; i < keys.length; i++) {
            try {
                app.preferences.setIntegerPreference(keys[i], cropVal);
            } catch (e) { }
        }
    }

    // Placing .ai in Illustrator uses the PDF import pipeline as well (AI is PDF-compatible),
    // so we treat .ai as "PDF-like" for page/artboard selection.
    function __SC_isPdfLikeFile(f) {
        try {
            if (!f) return false;
            var n = (f.name || "").toLowerCase();
            return (n.indexOf(".pdf") > -1) || (n.indexOf(".ai") > -1);
        } catch (e) {
            return false;
        }
    }

    // UI-only: crop box options are meaningful for PDF; keep disabled for AI.
    function __SC_isPdfFile(f) {
        try {
            if (!f) return false;
            var n = (f.name || "").toLowerCase();
            return (n.indexOf(".pdf") > -1);
        } catch (e) {
            return false;
        }
    }

    // =========================================
    // Auto-fit measurement cache (session only)
    // key: fileFsName|cropMode|page
    // value: { w:Number, h:Number }
    // =========================================

    function __SC_getAutoFitMeasureCache() {
        if (!$.global.__SC_autoFitMeasureCache) $.global.__SC_autoFitMeasureCache = {};
        return $.global.__SC_autoFitMeasureCache;
    }

    function __SC_getAutoFitMeasureKey(fileA, cropMode, pageNum) {
        var p = "";
        try { p = (fileA && fileA.fsName) ? String(fileA.fsName) : String(fileA); } catch (e) { p = String(fileA); }
        return p + "|" + String(cropMode) + "|" + String(pageNum);
    }

    function __SC_getAutoFitMeasure(fileA, cropMode, pageNum) {
        try {
            var box = __SC_getAutoFitMeasureCache();
            var k = __SC_getAutoFitMeasureKey(fileA, cropMode, pageNum);
            var v = box[k];
            if (v && v.w > 0 && v.h > 0) return v;
        } catch (e) { }
        return null;
    }

    function __SC_setAutoFitMeasure(fileA, cropMode, pageNum, w, h) {
        try {
            if (!(w > 0 && h > 0)) return;
            var box = __SC_getAutoFitMeasureCache();
            var k = __SC_getAutoFitMeasureKey(fileA, cropMode, pageNum);
            box[k] = { w: w, h: h };
        } catch (e) { }
    }

    // 入力された文字列（例："1-20", "1,3,5"）を数字の配列に変換する関数
    function parsePageNumbers(inputStr) {
        var result = [];
        var parts = inputStr.split(',');

        for (var i = 0; i < parts.length; i++) {
            var part = parts[i].replace(/^\s+|\s+$/g, '');

            if (part.indexOf('-') > -1) {
                var bounds = part.split('-');
                var start = parseInt(bounds[0], 10);
                var end = parseInt(bounds[1], 10);

                if (!isNaN(start) && !isNaN(end)) {
                    var min = Math.min(start, end);
                    var max = Math.max(start, end);
                    for (var j = min; j <= max; j++) {
                        result.push(j);
                    }
                }
            } else {
                var num = parseInt(part, 10);
                if (!isNaN(num)) {
                    result.push(num);
                }
            }
        }
        return result;
    }

    // =========================================
    // Global updatePreview wrapper (for scheduleTask / global callbacks)
    // =========================================
    // `updatePreview` itself is defined inside main(). When something calls `updatePreview()`
    // from the global scope, route it to the latest function stored in $.global.
    function updatePreview() {
        try {
            if ($.global.__SC_updatePreview) {
                $.global.__SC_updatePreview();
            }
        } catch (e) { }
    }

    // =========================================
    // TMK Zoom Module (collision-safe + Light mode)
    // - Light mode: apply zoom only on slider release
    // =========================================

    function __TMKZoom_captureViewState(doc) {
        var st = { view: null, zoom: null, center: null };
        try {
            st.view = doc.activeView;
            st.zoom = st.view.zoom;
            st.center = st.view.centerPoint;
        } catch (e) { }
        return st;
    }

    function __TMKZoom_restoreViewState(doc, state) {
        if (!state) return;
        try {
            var v = state.view || doc.activeView;
            if (v && state.zoom != null) v.zoom = state.zoom;
            if (v && state.center != null) v.centerPoint = state.center;
        } catch (e) { }
    }

    function __TMKZoom_addControls(parent, doc, labelText, initialState, options) {
        options = options || {};
        var minZoom = (typeof options.min === "number") ? options.min : 0.1;
        var maxZoom = (typeof options.max === "number") ? options.max : 16;
        var sliderWidth = (typeof options.sliderWidth === "number") ? options.sliderWidth : 360;
        var doRedraw = (options.redraw !== false);

        // Light mode options
        var showLightMode = (options.lightMode !== false);            // default: show
        var lightModeLabel = options.lightModeLabel || "Light mode";
        var lightModeDefault = (options.lightModeDefault === true);   // default: false

        // UI group
        var g = parent.add("group");
        g.orientation = "row";
        g.alignChildren = ["center", "center"];
        g.alignment = "center";
        try { if (options.margins) g.margins = options.margins; } catch (e) { }

        var stLabel = g.add("statictext", undefined, String(labelText || "Zoom"));

        // Initial zoom
        var initZoom = 1;
        try {
            if (initialState && initialState.zoom != null) initZoom = Number(initialState.zoom);
            else initZoom = Number(doc.activeView.zoom);
        } catch (e) { }
        if (!initZoom || isNaN(initZoom)) initZoom = 1;

        var sld = g.add("slider", undefined, initZoom, minZoom, maxZoom);
        try { sld.preferredSize.width = sliderWidth; } catch (e) { }

        var chkLight = null;
        if (showLightMode) {
            chkLight = g.add("checkbox", undefined, String(lightModeLabel));
            chkLight.value = lightModeDefault;
        }

        function isLightMode() {
            return !!(chkLight && chkLight.value);
        }

        function applyZoom(z) {
            try {
                var v = (initialState && initialState.view) ? initialState.view : doc.activeView;
                if (!v) return;
                v.zoom = z;
                if (doRedraw) { app.redraw(); }
            } catch (e) { }
        }

        function syncFromView() {
            try {
                var v = (initialState && initialState.view) ? initialState.view : doc.activeView;
                if (!v) return;
                sld.value = v.zoom;
            } catch (e) { }
        }

        // Live drag (disabled in light mode)
        sld.onChanging = function () {
            if (isLightMode()) return; // ✅ lightweight: do nothing while dragging
            applyZoom(Number(sld.value));
        };

        // Always apply once on release
        sld.onChange = function () {
            applyZoom(Number(sld.value));
        };

        if (chkLight) {
            chkLight.onClick = function () {
                // Toggle feels consistent: apply current value immediately
                try { applyZoom(Number(sld.value)); } catch (e) { }
            };
        }

        return {
            group: g,
            label: stLabel,
            slider: sld,
            lightModeCheckbox: chkLight,
            applyZoom: applyZoom,
            syncFromView: syncFromView,
            restoreInitial: function () { __TMKZoom_restoreViewState(doc, initialState); }
        };
    }

    // =========================================
    // main() 分散化用ヘルパー
    // =========================================

    function __SC_getSourceDocKey(fileObj) {
        try { return (fileObj && fileObj.fsName) ? String(fileObj.fsName) : String(fileObj); }
        catch (e) { return String(fileObj); }
    }

    function __SC_getSourcePageCount(fileObj) {
        try {
            if (!fileObj) return 0;

            if (!$.global.__SC_sourcePageCountCache) $.global.__SC_sourcePageCountCache = {};
            var cache = $.global.__SC_sourcePageCountCache;
            var key = __SC_getSourceDocKey(fileObj);
            if (cache[key] && cache[key] > 0) return cache[key];

            var tempDoc = null;
            var n = 0;
            try {
                tempDoc = app.open(fileObj);
                try { n = (tempDoc && tempDoc.artboards) ? tempDoc.artboards.length : 0; } catch (e) { n = 0; }
            } catch (e) {
                n = 0;
            } finally {
                try { if (tempDoc) tempDoc.close(SaveOptions.DONOTSAVECHANGES); } catch (e) { }
            }

            if (n > 0) cache[key] = n;
            return n;
        } catch (e) { }
        return 0;
    }

    function __SC_repeatPagesWithinCount(pages, maxCount) {
        if (!pages || pages.length === 0) return pages;
        if (!(maxCount > 0)) return pages;
        var out = [];
        for (var i = 0; i < pages.length; i++) {
            var p = parseInt(pages[i], 10);
            if (isNaN(p) || p < 1) p = 1;
            var m = ((p - 1) % maxCount) + 1;
            out.push(m);
        }
        return out;
    }

    function __SC_filterPagesWithinCount(pages, maxCount) {
        if (!pages || pages.length === 0) return pages;
        if (!(maxCount > 0)) return pages;
        var out = [];
        for (var i = 0; i < pages.length; i++) {
            var p = parseInt(pages[i], 10);
            if (isNaN(p)) continue;
            if (p < 1 || p > maxCount) continue;
            out.push(p);
        }
        return out;
    }

    function __SC_expandPagesToTotal(basePages, totalCount) {
        if (!basePages || basePages.length === 0) return [];
        var n = parseInt(totalCount, 10);
        if (isNaN(n) || n <= 0) n = basePages.length;
        var out = [];
        for (var i = 0; i < n; i++) out.push(basePages[i % basePages.length]);
        return out;
    }

    function __SC_buildTargetPages(specifiedStr, totalCount, sourceCount) {
        var base = [];
        try { base = parsePageNumbers(String(specifiedStr || '')); } catch (e) { base = []; }
        if (!base || base.length === 0) base = [1];
        if (sourceCount > 0) {
            base = __SC_filterPagesWithinCount(base, sourceCount);
        }
        if (!base || base.length === 0) base = [1];
        var t = parseInt(totalCount, 10);
        if (isNaN(t) || t <= 0) return base;
        return __SC_expandPagesToTotal(base, t);
    }

    function __SC_toHalfWidthDigits(s) {
        s = String(s || '');
        return s.replace(/[０-９]/g, function (ch) {
            return String.fromCharCode(ch.charCodeAt(0) - 0xFEE0);
        });
    }
    // -----------------------------------------
    // Source file page/artboard count (session cache)
    // - For .ai: artboards length
    // - For .pdf: pages are represented as artboards when opened
    // -----------------------------------------

    // Parse first positive integer from text (accepts full-width digits, trims, ignores suffix)
    function __SC_parsePositiveInt(s) {
        try {
            s = __SC_toHalfWidthDigits(String(s || '')).replace(/\s+/g, '');
            if (!s) return 0;
            // allow brackets like [13]
            s = s.replace(/^[\[\(\{\u3010\uFF3B]?/, '').replace(/[\]\)\}\u3011\uFF3D]?$/, '');
            var m = s.match(/(\d+)/);
            if (!m) return 0;
            var v = parseInt(m[1], 10);
            if (isNaN(v) || v <= 0) return 0;
            return v;
        } catch (e) {
            return 0;
        }
    }

    function __SC_removeItemSafe(it) {
        try { if (it) it.remove(); } catch (e) { }
    }

    function __SC_clearPreviewCache(__previewCache) {
        // remove group (removes its children automatically)
        if (__previewCache.group) {
            __SC_removeItemSafe(__previewCache.group);
        }
        __previewCache.group = null;
        __previewCache.currentRot = 0;

        // clear arrays (items already removed with group)
        __previewCache.items = [];
        __previewCache.baseW = [];
        __previewCache.baseH = [];

        // remove bg
        __SC_removeItemSafe(__previewCache.bgItem);
        __previewCache.bgItem = null;

        __previewCache.pagesKey = "";
        __previewCache.cropMode = null;
        __previewCache.previewWrapped = false;
        __previewCache.previewRoundRadiusPt = 0;
        __previewCache.randOrder = null;
        __previewCache.finalRandOrder = null;
    }

    // Remove any leftover preview group(s) by name (safety net)
    function __SC_removePreviewGroupByName(doc) {
        try {
            if (!doc) return;
            var name = '__SC_previewGroup__';
            // Try multiple passes because removing changes indices
            for (var pass = 0; pass < 3; pass++) {
                var removed = false;
                try {
                    for (var i = doc.groupItems.length - 1; i >= 0; i--) {
                        var g = doc.groupItems[i];
                        if (g && g.name === name) {
                            try { g.remove(); } catch (e) { }
                            removed = true;
                        }
                    }
                } catch (e) { }
                if (!removed) break;
            }
        } catch (e) { }
    }
    function __SC_shuffleIndexArray(n) {
        var a = [];
        for (var i = 0; i < n; i++) a.push(i);
        for (var j = a.length - 1; j > 0; j--) {
            var k = Math.floor(Math.random() * (j + 1));
            var t = a[j];
            a[j] = a[k];
            a[k] = t;
        }
        return a;
    }

    function __SC_ensureRandomOrder(__previewCache) {
        var n = (__previewCache.items) ? __previewCache.items.length : 0;
        if (n <= 1) { __previewCache.randOrder = null; return; }
        if (!__previewCache.randOrder || __previewCache.randOrder.length !== n) {
            __previewCache.randOrder = __SC_shuffleIndexArray(n);
        }
    }

    function __SC_clearRandomOrder(__previewCache) {
        __previewCache.randOrder = null;
    }

    function main() {

        // Cached source page/artboard count
        var __SC_sourceCount = 0;

        if (app.documents.length === 0) {
            alert(getLabel("alertNeedDoc"));
            return;
        }

        var doc = app.activeDocument;
        // Current source file selected by user (set via UI). If null, the user has not selected any file yet.
        var fileA = null;

        // =========================================
        // Preview/cache state (main local)
        // =========================================

        // プレビュー用に配置したアイテムを保持する配列
        var previewItems = [];

        // Preview cache: placed items are created on [読み込み] and reused until next load
        var __previewCache = {
            items: [],
            baseW: [],
            baseH: [],
            pagesKey: "",
            cropMode: null,
            bgItem: null,
            group: null,
            currentRot: 0,
            randOrder: null,
            finalRandOrder: null,
            previewWrapped: false,
            previewRoundRadiusPt: 0
        };

        // 現在の定規単位（rulerType）
        var rulerUnit = getUnitInfo("rulerType");

        // 既定値は pt ベースで保持し、表示時に定規単位へ変換
        var DEFAULT_SPACING_PT = 20;
        var DEFAULT_MARGIN_PT = 20;

        // ラベル幅（列数/間隔/列ずらし/スケール/回転/横/縦 を揃える）
        var LABEL_W = 60;
        // 位置調整ラベル幅（横方向の位置調整/縦方向の位置調整）
        var OFFSET_LABEL_W = 140;
        // 単位・補助ラベル幅（空白/pt/%/° を揃える）
        var UNIT_W = 24;

        // スライダー幅（列数/列ずらし/スケール/回転/横/縦 を揃える）
        var SLIDER_W = 140;

        // 自動フィット（UIは非表示。ロジックは維持して常にON）
        var AUTO_FIT_ENABLED = true;

        // 2. ダイアログボックスの作成
        var win = new Window("dialog", getLabel("dialogTitle") + " " + SCRIPT_VERSION);
        win.alignChildren = "fill";
        win.center();

        // === 2カラム構成 ===
        var mainRow = win.add("group");
        mainRow.orientation = "row";
        mainRow.alignChildren = ["fill", "fill"];

        // 左カラム
        var leftCol = mainRow.add("group");
        leftCol.orientation = "column";
        leftCol.alignChildren = "fill";

        // 右カラム
        var rightCol = mainRow.add("group");
        rightCol.orientation = "column";
        rightCol.alignChildren = "fill";

        // Panel: 読み込みファイル / Source file
        var pnlSource = leftCol.add('panel', undefined, getLabel('panelSource'));
        pnlSource.orientation = 'column';
        pnlSource.alignChildren = ['left', 'top'];
        pnlSource.margins = [15, 20, 15, 10];

        // ファイル指定ボタン（v5ロジックで fileA / ページ数推定を更新）
        var btnBrowse = pnlSource.add('button', undefined, getLabel('btnLoad'));

        // ファイル名表示
        var etPath = pnlSource.add('statictext', undefined, getLabel('notSelected'));
        etPath.characters = 20;

        // Panel: アートボード
        var pnlAB = leftCol.add('panel', undefined, getLabel('panelLoad'));
        pnlAB.orientation = 'column';
        pnlAB.alignChildren = ['left', 'top'];
        pnlAB.margins = [15, 20, 15, 10];

        // === 2カラム（左：指定/総数, 右：読み込み） ===
        var rowTop = pnlAB.add('group');
        rowTop.orientation = 'row';
        rowTop.alignChildren = ['fill', 'center'];

        // --- 左カラム ---
        var colLeft = rowTop.add('group');
        colLeft.orientation = 'column';
        colLeft.alignChildren = ['left', 'center'];

        // 範囲
        var rowRange = colLeft.add('group');
        rowRange.orientation = 'row';
        rowRange.alignChildren = ['left', 'center'];
        rowRange.add('statictext', undefined, getLabel('range'));
        var etRange = rowRange.add('edittext', undefined, '');
        etRange.characters = 10;
        etRange.enabled = true;

        // Backward-compatible alias: existing logic expects editPages
        var editPages = etRange;

        // 総数
        var rowTotal = colLeft.add('group');
        rowTotal.orientation = 'row';
        rowTotal.alignChildren = ['left', 'center'];
        rowTotal.add('statictext', undefined, getLabel('total'));
        var etTotal = rowTotal.add('edittext', undefined, '');
        etTotal.characters = 4;
        etTotal.enabled = true;

        // true: 指定から総数を自動更新 / false: ユーザーが総数を手入力
        var __SC_autoTotal = true;

        // --- 右カラム ---
        var colRight = rowTop.add('group');
        colRight.orientation = 'column';
        colRight.alignChildren = ['right', 'center'];
        colRight.alignment = ['fill', 'center'];

        var rowLoadBtn = colRight.add('group');
        rowLoadBtn.orientation = 'row';
        rowLoadBtn.alignChildren = ['right', 'center'];
        var btnPreview = rowLoadBtn.add('button', undefined, getLabel('btnImport'));

        btnPreview.onClick = function () {
            // Require file selection
            if (!fileA) {
                safeAlertKey('alertNeedFile');
                return;
            }

            // Build target pages from 指定/総数/sourceCount
            var pages = [];
            try { pages = getTargetPagesFromUI(); } catch (e) { pages = []; }
            if (!pages || pages.length === 0) pages = [1];

            // If Total is empty, show the resolved count
            try {
                var curT = String(etTotal.text || '');
                if (!curT) etTotal.text = String(pages.length);
            } catch (e) { }

            // Clear previous cache/items (and any leftovers)
            __SC_clearPreviewCache(__previewCache);
            __SC_removePreviewGroupByName(doc);
            previewItems = [];

            // Create a persistent group to keep rotation/cleanup stable
            try {
                __previewCache.group = doc.groupItems.add();
                __previewCache.group.name = '__SC_previewGroup__';
            } catch (e) {
                __previewCache.group = null;
            }

            var cropMode = 2;
            try { cropMode = getCropModeFromUI(); } catch (e) { cropMode = 2; }

            __previewCache.items = [];
            __previewCache.baseW = [];
            __previewCache.baseH = [];
            __previewCache.cropMode = cropMode;
            __previewCache.pagesKey = String(etRange.text || '');
            __previewCache.previewWrapped = false;
            __previewCache.previewRoundRadiusPt = 0;

            // Place each requested page/artboard
            for (var i = 0; i < pages.length; i++) {
                var p = parseInt(pages[i], 10);
                if (isNaN(p) || p < 1) p = 1;

                var it = null;
                try {
                    if (__SC_isPdfLikeFile(fileA)) {
                        __SC_setPdfCropPreference(cropMode);
                    }
                    __SC_setImportPageNumber(fileA, p);

                    it = doc.placedItems.add();
                    it.file = fileA;

                    // Move into the preview group so later rotation/layout acts on a single container
                    try { if (__previewCache.group) it.moveToEnd(__previewCache.group); } catch (e) { }

                    __previewCache.items.push(it);
                    __previewCache.baseW.push(it.width);
                    __previewCache.baseH.push(it.height);
                } catch (ePlace) {
                    // Clean up partially created item
                    try { if (it) it.remove(); } catch (e) { }
                } finally {
                    try { __SC_resetImportPageNumber(fileA); } catch (e) { }
                }
            }

            // Create / update background if enabled
            try {
                if (cbBg && cbBg.value) {
                    __previewCache.bgItem = __SC_drawArtboardBackground(doc, getBgRGBColorOrDefault());
                    try { __previewCache.bgItem.zOrder(ZOrderMethod.SENDTOBACK); } catch (e) { }
                }
            } catch (e) { }

            // Apply current layout settings to the newly placed items
            applyLayoutToCachedItems();
            var core = (__previewCache.group ? [__previewCache.group] : __previewCache.items);
            previewItems = (__previewCache.bgItem ? [__previewCache.bgItem].concat(core) : core);
            app.redraw();
        };

        // Preserve intended import handler (legacy wiring later in the script may overwrite btnPreview.onClick)
        var __SC_importHandler = btnPreview.onClick;

        function setPathText(f) {
            // Also update current source file reference (fileA)
            fileA = f || null;
            initSourceDependentUI();

            try {
                if (f) {
                    etPath.text = decodeURIComponent(f.name);
                    etPath.helpTip = decodeURIComponent(f.fsName);
                } else {
                    etPath.text = getLabel('notSelected');
                    etPath.helpTip = '';
                }
            } catch (e) {
                try {
                    etPath.text = f ? String(f.name) : getLabel('notSelected');
                    etPath.helpTip = f ? String(f.fsName) : '';
                } catch (__) {
                    etPath.text = getLabel('notSelected');
                    etPath.helpTip = '';
                }
            }
        }

        function setResultText(last) {
            if (!last) {
                etRange.text = '';
                etTotal.text = '';
            } else {
                etRange.text = '1-' + last;
                try { __SC_sourceCount = parseInt(last, 10) || 0; } catch (e) { __SC_sourceCount = 0; }
                // Do not override user's manual Total. Only auto-sync when we are already in auto mode,
                // or when Total is empty (fresh state).
                try {
                    var cur = String(etTotal.text || '');
                    if (__SC_autoTotal || cur === '' || cur === getLabel('notSelected')) {
                        __SC_autoTotal = true;
                    }
                } catch (e) {
                    // keep current __SC_autoTotal
                }
                etTotal.text = PC.updateTotalFromRange(etRange.text, etTotal.text);
            }
        }

        function initSourceDependentUI() {
            try {
                if (typeof ddCrop !== "undefined" && ddCrop) {
                    ddCrop.enabled = __SC_isPdfFile(fileA);
                }
            } catch (e) { }
        }

        function triggerPreviewUpdate() {
            updatePreview();
        }

        function syncLayoutInputsBeforeFinalize() {
            try { syncColsFromEdit(); } catch (e) { }
            try { syncSpacingFromEdit(); } catch (e) { }
            try { syncShiftFromEdit(); } catch (e) { }
            try { syncScaleFromEdit(); } catch (e) { }
            try { syncRotateFromEdit(); } catch (e) { }

            try {
                var m = parseFloat(editMargin.text);
                if (isNaN(m) || m < 0) m = 0;
                editMargin.text = String(__SC_round(m, 2));
            } catch (e) { }

            try {
                var r = parseFloat(editRound.text);
                if (isNaN(r) || r < 0) r = 0;
                editRound.text = String(__SC_round(r, 2));
            } catch (e) { }

            try {
                var mr = parseFloat(editMaskRound.text);
                if (isNaN(mr) || mr < 0) mr = 0;
                editMaskRound.text = String(__SC_round(mr, 2));
            } catch (e) { }

            try {
                updateMaskUI();
                updateBgControls();
                initSourceDependentUI();
            } catch (e) { }
        }

        function bakePreviewRandomOrderForFinalize() {
            try {
                if (getFlowMode() !== 2) return;
                if (!__previewCache.items || __previewCache.items.length <= 1) return;
                if (!__previewCache.randOrder || __previewCache.randOrder.length !== __previewCache.items.length) return;

                var orderedItems = [];
                var orderedBaseW = [];
                var orderedBaseH = [];
                for (var i = 0; i < __previewCache.randOrder.length; i++) {
                    var idx = __previewCache.randOrder[i];
                    orderedItems.push(__previewCache.items[idx]);
                    orderedBaseW.push(__previewCache.baseW[idx]);
                    orderedBaseH.push(__previewCache.baseH[idx]);
                }

                __previewCache.items = orderedItems;
                __previewCache.baseW = orderedBaseW;
                __previewCache.baseH = orderedBaseH;

                var identity = [];
                for (var j = 0; j < orderedItems.length; j++) identity.push(j);
                __previewCache.randOrder = identity.slice(0);
                __previewCache.finalRandOrder = identity.slice(0);
            } catch (e) { }
        }

        btnBrowse.onClick = function () {
            var f = File.openDialog(getLabel('dlgPickFile'), getLabel('filterPick'));
            if (!f) return;
            PC.updateResultFromPlacedOrFile(doc, f, setPathText, setResultText);
        };

        etRange.onChanging = function () {
            etTotal.text = PC.updateTotalFromRange(etRange.text, etTotal.text);
        };

        etTotal.onChanging = function () {
            __SC_autoTotal = false;
            var v = __SC_parsePositiveInt(etTotal.text);
            if (!v) return; // allow empty / in-progress
            etTotal.text = String(v);
        };

        // --- トリミングパネル（配置範囲：PDF のトリミング設定） ---
        var panelCrop = leftCol.add("panel", undefined, getLabel("panelItem"));
        panelCrop.alignChildren = "left";
        panelCrop.margins = [15, 20, 15, 10];

        // panelCrop.add("statictext", undefined, "トリミング");
        var ddCrop = panelCrop.add("dropdownlist", undefined, [getLabel("cropArt"), getLabel("cropTrim"), getLabel("cropCrop"), getLabel("cropBleed")]);
        ddCrop.minimumSize.width = 160;

        /* 角丸 / Round corners */
        var groupRound = panelCrop.add("group");
        groupRound.orientation = "row";
        groupRound.alignChildren = ["left", "center"];

        var cbRound = groupRound.add("checkbox", undefined, getLabel("round"));
        cbRound.value = false;

        var editRound = groupRound.add("edittext", undefined, getLabel("defaultRound"));
        editRound.characters = 3;

        groupRound.add("statictext", undefined, rulerUnit.label);

        // 初期状態
        editRound.enabled = cbRound.value;

        cbRound.onClick = function () {
            editRound.enabled = cbRound.value;
        };

        // デフォルト：仕上がり
        ddCrop.selection = 2;

        initSourceDependentUI();

        // Initial: try selection
        PC.updateResultFromPlacedOrFile(doc, null, setPathText, setResultText);
        initSourceDependentUI();

        function getTargetPagesFromUI() {
            var specified = String(etRange.text || '');
            var total = __SC_parsePositiveInt(etTotal.text);
            var srcCount = 0;
            try {
                srcCount = (__SC_sourceCount > 0)
                    ? __SC_sourceCount
                    : __SC_getSourcePageCount(fileA);
            } catch (e) {
                srcCount = 0;
            }
            return __SC_buildTargetPages(specified, total, srcCount);
        }

        function getCropModeFromUI() {
            var idx = (ddCrop.selection) ? ddCrop.selection.index : 2;
            // 0:アート / 1:トリミング / 2:仕上がり / 3:裁ち落とし
            if (idx === 0) return __SC_CROP_ART;
            if (idx === 1) return __SC_CROP_TRIM;
            if (idx === 3) return __SC_CROP_BLEED;
            // 仕上がりは CropBox を想定（環境差があるため失敗時は無視される）
            return __SC_CROP_CROP;
        }

        // -----------------------------------------
        // Import page/artboard selection
        // - PDF: uses PDFImport/PageNumber
        // - AI: uses IllustratorImport/ArtboardNumber (+ PlaceArtboards)
        // -----------------------------------------
        function __SC_setImportPageNumber(fileObj, pageNum) {
            var n = parseInt(pageNum, 10);
            if (isNaN(n) || n < 1) n = 1;
            try {
                // Use PDFImport for both PDF and AI (AI is handled by the PDF import pipeline when placing)
                app.preferences.setIntegerPreference("plugin/PDFImport/PageNumber", n);
            } catch (e) { }
        }

        function __SC_resetImportPageNumber(fileObj) {
            try {
                app.preferences.setIntegerPreference("plugin/PDFImport/PageNumber", 1);
            } catch (e) { }
        }

        /* グリッド / Grid */
        var panelLayout = rightCol.add("panel", undefined, getLabel("panelGrid"));
        panelLayout.alignChildren = "left";
        panelLayout.margins = [15, 20, 15, 10];

        // 方向（配置順）
        var groupDir = panelLayout.add("group");
        groupDir.orientation = "row";
        groupDir.alignChildren = ["left", "center"];

        groupDir.add("statictext", undefined, getLabel("direction"));

        var rbDirH = groupDir.add("radiobutton", undefined, getLabel("dirH"));
        var rbDirV = groupDir.add("radiobutton", undefined, getLabel("dirV"));
        var rbDirR = groupDir.add("radiobutton", undefined, getLabel("dirRandom"));

        // デフォルト：縦方向
        rbDirV.value = true;

        // 0=横方向, 1=縦方向, 2=ランダム
        function getFlowMode() {
            if (rbDirR.value) return 2;
            if (rbDirV.value) return 1;
            return 0;
        }

        rbDirH.onClick = triggerPreviewUpdate;
        rbDirV.onClick = triggerPreviewUpdate;
        rbDirR.onClick = triggerPreviewUpdate;

        // 列数
        var groupCols = panelLayout.add("group");
        groupCols.orientation = "row";
        groupCols.alignChildren = ["left", "center"];

        var stCols = groupCols.add("statictext", undefined, getLabel("cols"));
        stCols.preferredSize.width = LABEL_W;
        var editCols = groupCols.add("edittext", undefined, getLabel("defaultCols"));
        editCols.characters = 4;

        var gapCols = groupCols.add("statictext", undefined, getLabel("gapSpace"));
        gapCols.preferredSize.width = UNIT_W;

        var spacerCols = groupCols.add("group");
        spacerCols.alignment = ["fill", "fill"];
        spacerCols.minimumSize.width = 0;

        var sldCols = groupCols.add("slider", undefined, 5, 0, 10);
        sldCols.preferredSize.width = SLIDER_W;

        function syncColsFromEdit() {
            var v = parseInt(editCols.text, 10);
            if (isNaN(v) || v < 0) v = 0;
            if (v > 10) v = 10;
            editCols.text = String(v);
            sldCols.value = v;
        }

        function syncColsFromSlider() {
            var v = Math.round(sldCols.value);
            if (v < 0) v = 0;
            if (v > 10) v = 10;
            editCols.text = String(v);
        }

        syncColsFromEdit();
        editCols.onChanging = function () {
            syncColsFromEdit();
            triggerPreviewUpdate();
        };
        sldCols.onChanging = function () {
            syncColsFromSlider();
            triggerPreviewUpdate();
        };

        // リアルタイムプレビュー（確定時）

        var groupSpacing = panelLayout.add("group");
        var stSpacing = groupSpacing.add("statictext", undefined, getLabel("spacing"));
        stSpacing.preferredSize.width = LABEL_W;
        var editSpacing = groupSpacing.add("edittext", undefined, String(__SC_round(__SC_ptToUnit(DEFAULT_SPACING_PT, rulerUnit.pointsPerUnit), 2)));
        editSpacing.characters = 4;
        var stSpacingUnit = groupSpacing.add("statictext", undefined, rulerUnit.label);
        stSpacingUnit.preferredSize.width = UNIT_W;

        // 間隔スライダー（右側）
        var spacerSpacing = groupSpacing.add("group");
        spacerSpacing.alignment = ["fill", "fill"];
        spacerSpacing.minimumSize.width = 0;

        var sldSpacing = groupSpacing.add("slider", undefined, 0, 0, 100);
        sldSpacing.preferredSize.width = SLIDER_W;

        // 間隔

        function syncSpacingFromEdit() {
            var v = parseFloat(editSpacing.text);
            if (isNaN(v) || v < 0) v = 0;
            if (v > 100) v = 100;
            v = __SC_round(v, 2);
            editSpacing.text = String(v);
            sldSpacing.value = v;
        }

        function syncSpacingFromSlider() {
            var v = sldSpacing.value;
            if (isNaN(v) || v < 0) v = 0;
            if (v > 100) v = 100;
            v = __SC_round(v, 2);
            editSpacing.text = String(v);
        }

        // 初期同期
        syncSpacingFromEdit();

        // 連動
        editSpacing.onChanging = function () {
            syncSpacingFromEdit();
            triggerPreviewUpdate();
        };
        sldSpacing.onChanging = function () {
            syncSpacingFromSlider();
            triggerPreviewUpdate();
        };

        // --- 偶数列パネル（配分/ずらし） ---
        var panelEven = rightCol.add("panel", undefined, getLabel("panelEven"));
        panelEven.alignChildren = "left";
        panelEven.margins = [15, 20, 15, 10];

        // 配分モード
        var groupDist = panelEven.add("group");
        groupDist.orientation = "row";
        groupDist.alignChildren = ["left", "center"];

        // var stDist = groupDist.add("statictext", undefined, getLabel("dist"));
        // stDist.preferredSize.width = LABEL_W;

        var cbEvenPlus = groupDist.add("checkbox", undefined, getLabel("evenPlus"));

        cbEvenPlus.helpTip = (uiLang === "ja")
            ? "偶数列にスロットを1つ追加します。空きが出ることがあります。"
            : "Adds one extra slot to even columns. Empty spaces may appear.";

        cbEvenPlus.value = false;

        cbEvenPlus.onClick = triggerPreviewUpdate;

        // ずらし（Yオフセット）
        var groupColShift = panelEven.add("group");
        groupColShift.orientation = "row";
        groupColShift.alignChildren = ["left", "center"];

        var cbColShift = groupColShift.add("checkbox", undefined, getLabel("shift"));

        cbColShift.helpTip = (uiLang === "ja")
            ? "偶数列だけのYオフセット（上下方向のずらし）"
            : "Y-offset applied to even columns only.";

        cbColShift.preferredSize.width = LABEL_W;
        cbColShift.value = true;

        var editColShift = groupColShift.add("edittext", undefined, getLabel("defaultShift"));
        editColShift.characters = 4;

        var stShiftUnit = groupColShift.add("statictext", undefined, rulerUnit.label);
        stShiftUnit.preferredSize.width = UNIT_W;

        var spacerShift = groupColShift.add("group");
        spacerShift.alignment = ["fill", "fill"];
        spacerShift.minimumSize.width = 0;

        var sldColShift = groupColShift.add("slider", undefined, 0, -200, 200);
        sldColShift.preferredSize.width = SLIDER_W;

        function syncShiftFromEdit() {
            var v = parseFloat(editColShift.text);
            if (isNaN(v)) v = 0;
            if (v < -200) v = -200;
            if (v > 200) v = 200;
            editColShift.text = String(v);
            sldColShift.value = v;
        }

        function syncShiftFromSlider() {
            var v = sldColShift.value;
            v = Math.round(v);
            if (v < -200) v = -200;
            if (v > 200) v = 200;
            editColShift.text = String(v);
        }

        syncShiftFromEdit();

        editColShift.onChanging = function () {
            syncShiftFromEdit();
            triggerPreviewUpdate();
        };
        sldColShift.onChanging = function () {
            syncShiftFromSlider();
            triggerPreviewUpdate();
        };

        // 初期状態
        editColShift.enabled = cbColShift.value;
        sldColShift.enabled = cbColShift.value;

        cbColShift.onClick = function () {
            editColShift.enabled = cbColShift.value;
            sldColShift.enabled = cbColShift.value;
            triggerPreviewUpdate();
        };

        /* レイアウト / Layout */
        var panelLayoutRight = rightCol.add("panel", undefined, getLabel("panelLayout"));
        panelLayoutRight.alignChildren = "left";
        panelLayoutRight.margins = [15, 20, 15, 10];

        // --- アートボードとマスクパネル（左カラム） ---
        var panelArtboard = leftCol.add("panel", undefined, getLabel("panelArtboard"));
        panelArtboard.alignChildren = "left";
        panelArtboard.margins = [15, 20, 15, 10];

        // 背景色（アートボードと同じ大きさの図形を作成）
        var groupBg = panelArtboard.add("group");
        groupBg.orientation = "row";
        groupBg.alignChildren = ["left", "center"];

        var cbBg = groupBg.add("checkbox", undefined, getLabel("bg"));
        cbBg.value = true;

        // カラーチップ（表示用）
        var colorSwatch = groupBg.add("panel");
        colorSwatch.preferredSize = [24, 24];

        // HEX 入力
        var editBgHex = groupBg.add("edittext", undefined, getLabel("defaultHex"));
        editBgHex.characters = 7;

        function makeRGBColor(r, g, b) {
            var c = new RGBColor();
            c.red = r; c.green = g; c.blue = b;
            return c;
        }

        function parseHexToRGBColor(hexStr) {
            var s = String(hexStr || "").replace(/^\s+|\s+$/g, "");
            if (s.charAt(0) !== "#") s = "#" + s;
            if (!/^#[0-9a-fA-F]{6}$/.test(s)) return null;
            var r = parseInt(s.substr(1, 2), 16);
            var g = parseInt(s.substr(3, 2), 16);
            var b = parseInt(s.substr(5, 2), 16);
            if (isNaN(r) || isNaN(g) || isNaN(b)) return null;
            return makeRGBColor(r, g, b);
        }

        function setSwatchRGB(r, g, b) {
            try {
                var gg = colorSwatch.graphics;
                gg.backgroundColor = gg.newBrush(gg.BrushType.SOLID_COLOR, [r / 255, g / 255, b / 255, 1]);
                gg.foregroundColor = gg.newPen(gg.PenType.SOLID_COLOR, [0, 0, 0, 1], 1);
            } catch (e) { }
        }

        function getBgRGBColorOrDefault() {
            var c = parseHexToRGBColor(editBgHex.text);
            if (c) return c;
            return makeRGBColor(0, 0, 0);
        }

        function updateBgControls() {
            var en = cbBg.value;
            colorSwatch.enabled = en;
            editBgHex.enabled = en;

            var c = getBgRGBColorOrDefault();
            setSwatchRGB(c.red, c.green, c.blue);
        }

        updateBgControls();

        cbBg.onClick = function () {
            updateBgControls();
        };

        // HEX は入力確定時だけでOK（重くしない）
        editBgHex.onChange = function () {
            updateBgControls();
        };

        // --- カラーピッカー（スウォッチクリック） ---
        function openBgColorPicker() {
            var init = getBgRGBColorOrDefault();
            var c = new RGBColor();
            c.red = init.red;
            c.green = init.green;
            c.blue = init.blue;

            if (app.showColorPicker(c)) {
                function toHex(n) {
                    var s = n.toString(16);
                    return (s.length === 1) ? "0" + s : s;
                }
                var hex = "#" + toHex(c.red) + toHex(c.green) + toHex(c.blue);
                editBgHex.text = hex;
                updateBgControls();
                try { updateBgOnly(); } catch (e) { }
            }
        }

        colorSwatch.onClick = function () {
            openBgColorPicker();
        };

        try {
            colorSwatch.addEventListener("mousedown", function () {
                openBgColorPicker();
            });
        } catch (e) { }

        // マスク（OK時に配置物をマージン内側でクリッピング）
        var cbMask = panelArtboard.add("checkbox", undefined, getLabel("mask"));
        cbMask.value = true;

        // 外側余白
        var groupMargin = panelArtboard.add("group");
        var stMargin = groupMargin.add("statictext", undefined, getLabel("margin"));
        var editMargin = groupMargin.add("edittext", undefined, String(__SC_round(__SC_ptToUnit(DEFAULT_MARGIN_PT, rulerUnit.pointsPerUnit), 2)));
        editMargin.characters = 5;
        groupMargin.add("statictext", undefined, rulerUnit.label);

        // editMargin.onChange = function () { updatePreview(); };

        // マスク角丸（マスクしたクリップグループに角丸を適用）
        var groupMaskRound = panelArtboard.add("group");
        groupMaskRound.orientation = "row";
        groupMaskRound.alignChildren = ["left", "center"];

        var cbMaskRound = groupMaskRound.add("checkbox", undefined, getLabel("maskRound"));
        cbMaskRound.value = false;

        var editMaskRound = groupMaskRound.add("edittext", undefined, "20");
        editMaskRound.characters = 3;

        groupMaskRound.add("statictext", undefined, rulerUnit.label);

        // 初期状態
        editMaskRound.enabled = cbMask.value && cbMaskRound.value;

        // --- mask-round UI enable/disable helper and hook ---
        function updateMaskRoundUI() {
            var en = !!cbMask.value;
            groupMaskRound.enabled = en;
            // Ensure inner input reflects both mask and checkbox
            editMaskRound.enabled = en && cbMaskRound.value;
        }

        // --- mask & margin/mask-round UI helper ---
        function updateMaskUI() {
            var en = !!cbMask.value;
            groupMargin.enabled = en;
            updateMaskRoundUI();
        }

        // 初期状態（マスクOFFならディム）
        updateMaskUI();

        // マスク切替で追従
        cbMask.onClick = function () {
            updateMaskUI();
        };

        cbMaskRound.onClick = function () {
            // マスクOFFのときは常にディム
            editMaskRound.enabled = cbMask.value && cbMaskRound.value;
        };

        // スケール
        var groupScale = panelLayoutRight.add("group");
        groupScale.orientation = "row";
        groupScale.alignChildren = ["left", "center"];

        var stScale = groupScale.add("statictext", undefined, getLabel("scale"));
        stScale.preferredSize.width = LABEL_W;
        var editScale = groupScale.add("edittext", undefined, getLabel("defaultScale"));
        editScale.characters = 4;

        var stScaleUnit = groupScale.add("statictext", undefined, getLabel("unitPercent"));
        stScaleUnit.preferredSize.width = UNIT_W;

        var spacerScale = groupScale.add("group");
        spacerScale.alignment = ["fill", "fill"];
        spacerScale.minimumSize.width = 0;

        var sldScale = groupScale.add("slider", undefined, 100, 10, 250);
        sldScale.preferredSize.width = SLIDER_W;

        function syncScaleFromEdit() {
            var v = parseFloat(editScale.text);
            if (isNaN(v)) v = 100;
            if (v < 10) v = 10;
            if (v > 250) v = 250;
            v = Math.round(v);
            editScale.text = String(v);
            sldScale.value = v;
        }

        function syncScaleFromSlider() {
            var v = Math.round(sldScale.value);
            if (v < 10) v = 10;
            if (v > 250) v = 250;
            editScale.text = String(v);
        }

        // 初期同期
        syncScaleFromEdit();

        // 連動
        editScale.onChanging = function () {
            syncScaleFromEdit();
            updatePreview();
        };
        sldScale.onChanging = function () {
            syncScaleFromSlider();
            updatePreview();
        };

        // リアルタイムプレビュー

        // スケールUIは常に操作可能（自動フィットのロジックは維持）
        editScale.enabled = true;
        sldScale.enabled = true;

        // 回転（全体を回転）
        var groupRotate = panelLayoutRight.add("group");
        groupRotate.orientation = "row";
        groupRotate.alignChildren = ["left", "center"];

        var cbRotate = groupRotate.add("checkbox", undefined, getLabel("rotate"));
        cbRotate.helpTip = (uiLang === "ja")
            ? "配置したアイテム全体を回転します（アートボード中心基準）。"
            : "Rotate the entire placed layout (centered on the artboard).";
        cbRotate.preferredSize.width = LABEL_W;
        cbRotate.value = true;

        var editRotate = groupRotate.add("edittext", undefined, getLabel("defaultRotate"));
        editRotate.characters = 4;

        var stRotateUnit = groupRotate.add("statictext", undefined, getLabel("unitDegree"));
        stRotateUnit.preferredSize.width = UNIT_W;

        var spacerRotate = groupRotate.add("group");
        spacerRotate.alignment = ["fill", "fill"];
        spacerRotate.minimumSize.width = 0;

        var sldRotate = groupRotate.add("slider", undefined, -12, -30, 30);
        sldRotate.preferredSize.width = SLIDER_W;

        function syncRotateFromEdit() {
            var v = parseFloat(editRotate.text);
            if (isNaN(v)) v = 0;
            if (v < -30) v = -30;
            if (v > 30) v = 30;
            v = Math.round(v);
            editRotate.text = String(v);
            sldRotate.value = v;
        }

        function syncRotateFromSlider() {
            var v = sldRotate.value;
            v = Math.round(v);
            if (v < -30) v = -30;
            if (v > 30) v = 30;
            editRotate.text = String(v);
        }

        // 初期同期
        syncRotateFromEdit();

        // 連動
        editRotate.onChanging = function () {
            syncRotateFromEdit();
            updatePreview();
        };
        sldRotate.onChanging = function () {
            syncRotateFromSlider();
            updatePreview();
        };

        // リアルタイムプレビュー

        // 初期状態
        editRotate.enabled = cbRotate.value;
        sldRotate.enabled = cbRotate.value;

        cbRotate.onClick = function () {
            editRotate.enabled = cbRotate.value;
            sldRotate.enabled = cbRotate.value;
            updatePreview();
        };

        // 位置調整スライダー範囲（アートボードサイズに合わせる）
        var __abSizeUnit = (function () {
            try {
                var ab = doc.artboards[doc.artboards.getActiveArtboardIndex()];
                var r = ab.artboardRect; // [left, top, right, bottom]
                var wPt = Math.abs(r[2] - r[0]);
                var hPt = Math.abs(r[1] - r[3]);
                var wU = __SC_ptToUnit(wPt, rulerUnit.pointsPerUnit);
                var hU = __SC_ptToUnit(hPt, rulerUnit.pointsPerUnit);
                if (!isFinite(wU) || wU <= 0) wU = 200;
                if (!isFinite(hU) || hU <= 0) hU = 200;
                return { x: wU, y: hU };
            } catch (e) {
                return { x: 200, y: 200 };
            }
        })();

        // 全体位置（スライダー）
        // ※数値表示は不要（スライダーのみ）

        // 横位置
        var groupOffsetX = panelLayoutRight.add("group");
        var cbOffsetX = groupOffsetX.add("checkbox", undefined, getLabel("offsetX"));
        cbOffsetX.preferredSize.width = OFFSET_LABEL_W;
        cbOffsetX.value = false;

        var spacerOffX = groupOffsetX.add("group");
        spacerOffX.alignment = ["fill", "fill"];
        spacerOffX.minimumSize.width = 0;

        var sldOffsetX = groupOffsetX.add("slider", undefined, 0, -__abSizeUnit.x, __abSizeUnit.x);
        sldOffsetX.preferredSize.width = SLIDER_W;
        if (sldOffsetX.value < -__abSizeUnit.x) sldOffsetX.value = -__abSizeUnit.x;
        if (sldOffsetX.value > __abSizeUnit.x) sldOffsetX.value = __abSizeUnit.x;
        sldOffsetX.enabled = cbOffsetX.value;
        cbOffsetX.onClick = function () {
            sldOffsetX.enabled = cbOffsetX.value;
            triggerPreviewUpdate();
        };
        sldOffsetX.onChanging = triggerPreviewUpdate;

        // 縦位置（＋で下へ）
        var groupOffsetY = panelLayoutRight.add("group");
        var cbOffsetY = groupOffsetY.add("checkbox", undefined, getLabel("offsetY"));
        cbOffsetY.preferredSize.width = OFFSET_LABEL_W;
        cbOffsetY.value = false;

        var spacerOffY = groupOffsetY.add("group");
        spacerOffY.alignment = ["fill", "fill"];
        spacerOffY.minimumSize.width = 0;

        var sldOffsetY = groupOffsetY.add("slider", undefined, 0, -__abSizeUnit.y, __abSizeUnit.y);
        sldOffsetY.preferredSize.width = SLIDER_W;
        if (sldOffsetY.value < -__abSizeUnit.y) sldOffsetY.value = -__abSizeUnit.y;
        if (sldOffsetY.value > __abSizeUnit.y) sldOffsetY.value = __abSizeUnit.y;
        sldOffsetY.enabled = cbOffsetY.value;
        cbOffsetY.onClick = function () {
            sldOffsetY.enabled = cbOffsetY.value;
            triggerPreviewUpdate();
        };
        sldOffsetY.onChanging = triggerPreviewUpdate;

        // -----------------------------------------
        // 列ずらしデフォルト計算
        // A: 各アイテムの高さ（現在のスケール/回転を反映）
        // defaultShift = (A + 間隔) / 2
        // -----------------------------------------

        function getArtboardInnerSizePt(marginPt) {
            var activeAB = doc.artboards[doc.artboards.getActiveArtboardIndex()];
            var abRect = activeAB.artboardRect; // [left, top, right, bottom]
            var abW = Math.abs(abRect[2] - abRect[0]);
            var abH = Math.abs(abRect[1] - abRect[3]);
            var m = (typeof marginPt === "number" && !isNaN(marginPt) && marginPt >= 0) ? marginPt : 0;
            abW -= m * 2;
            abH -= m * 2;
            if (abW <= 0) abW = 1;
            if (abH <= 0) abH = 1;
            return { w: abW, h: abH };
        }

        function calcAutoScalePctForUI(pages, colsNum, gapPt, marginPt, rotateEnabled, rotateDeg) {
            if (!pages || pages.length === 0) return 100;

            var inner = getArtboardInnerSizePt(marginPt);
            var abW = inner.w;
            var abH = inner.h;

            var w = 0, h = 0;
            var pageNum0 = pages[0];
            var cropMode0 = getCropModeFromUI();

            var cached = __SC_getAutoFitMeasure(fileA, cropMode0, pageNum0);
            if (cached) {
                w = cached.w;
                h = cached.h;
            } else {
                var temp = null;
                try {
                    if (__SC_isPdfLikeFile(fileA)) {
                        __SC_setPdfCropPreference(cropMode0);
                    }
                    __SC_setImportPageNumber(fileA, pageNum0);
                    temp = doc.placedItems.add();
                    temp.file = fileA;
                    w = temp.width;
                    h = temp.height;
                } catch (e) {
                    w = 0; h = 0;
                } finally {
                    try { if (temp) temp.remove(); } catch (e2) { }
                    try { __SC_resetImportPageNumber(fileA); } catch (e3) { }
                }
                __SC_setAutoFitMeasure(fileA, cropMode0, pageNum0, w, h);
            }

            if (!(w > 0 && h > 0)) return 100;

            var total = pages.length;
            var rowsNum = Math.ceil(total / colsNum);

            var needW = (colsNum * w) + ((colsNum - 1) * gapPt);
            var needH = (rowsNum * h) + ((rowsNum - 1) * gapPt);

            // 回転がある場合は「グリッド全体」を回転させた外接サイズで見積もる
            if (rotateEnabled && rotateDeg !== 0) {
                var rad = Math.abs(rotateDeg) * Math.PI / 180.0;
                var s = Math.sin(rad);
                var c = Math.cos(rad);
                var rW = Math.abs(needW * c) + Math.abs(needH * s);
                var rH = Math.abs(needW * s) + Math.abs(needH * c);
                needW = rW;
                needH = rH;
            }

            if (!(needW > 0 && needH > 0)) return 100;

            var sW = (abW > 0) ? (abW / needW) : 1;
            var sH = (abH > 0) ? (abH / needH) : 1;
            var sMin = Math.min(sW, sH);
            if (!(sMin > 0)) sMin = 1;

            // 整数（%）に丸め
            var pct = Math.round(sMin * 100);
            if (!(pct > 0)) pct = 100;
            return pct;
        }

        function calcDefaultColShiftPt() {
            var pages = parsePageNumbers(editPages.text);

            // Repeat pages/artboards when requested count exceeds source count

            try {
                var srcCount = __SC_getSourcePageCount(fileA);
                if (srcCount > 0) {
                    pages = __SC_repeatPagesWithinCount(pages, srcCount);
                }
            } catch (e) { }

            if (!pages || pages.length === 0) pages = [1];

            var colsNum = parseInt(editCols.text, 10) || 5;

            var spacingUnit = parseFloat(editSpacing.text);
            if (isNaN(spacingUnit) || spacingUnit < 0) spacingUnit = 0;
            var marginUnit = parseFloat(editMargin.text);
            if (isNaN(marginUnit) || marginUnit < 0) marginUnit = 0;

            var spacingPt = __SC_unitToPt(spacingUnit, rulerUnit.pointsPerUnit);
            var marginPt = __SC_unitToPt(marginUnit, rulerUnit.pointsPerUnit);

            var rot = parseFloat(editRotate.text);
            if (isNaN(rot)) rot = 0;
            var rotateEnabled = cbRotate.value;

            // scalePct は「追加倍率（%）」として扱う（自動フィットの結果に乗算）
            var userScale = parseFloat(editScale.text);
            if (isNaN(userScale) || userScale <= 0) userScale = 100;
            if (userScale < 1) userScale = 1;

            var baseScale = 100;
            if (AUTO_FIT_ENABLED) {
                baseScale = calcAutoScalePctForUI(pages, colsNum, spacingPt, marginPt, rotateEnabled, rot);
            }

            var scalePct = baseScale * (userScale / 100.0);
            if (!(scalePct > 0)) scalePct = baseScale;

            var temp = null;
            var h = 0;
            try {
                if (__SC_isPdfLikeFile(fileA)) {
                    __SC_setPdfCropPreference(getCropModeFromUI());
                }
                __SC_setImportPageNumber(fileA, pages[0]);
                temp = doc.placedItems.add();
                temp.file = fileA;

                try { temp.resize(scalePct, scalePct); } catch (eResize) { }

                h = temp.height;
            } catch (e) {
                h = 0;
            } finally {
                try { if (temp) temp.remove(); } catch (e2) { }
                try { __SC_resetImportPageNumber(fileA); } catch (e3) { }
            }

            if (!(h > 0)) return 0;
            return (h + spacingPt) / 2;
        }

        // 初期値：列ずらしのデフォルトを計算して反映（チェックはOFFのまま）
        // fileA 未選択の状態では計算できないため、選択後（読み込み時）に計算する
        try {
            if (fileA) {
                var defShiftPt = calcDefaultColShiftPt();
                var defShiftUnit = __SC_ptToUnit(defShiftPt, rulerUnit.pointsPerUnit);
                editColShift.text = String(__SC_round(defShiftUnit, 2));
            }
        } catch (e) {
            // 失敗時は従来の 0
        }

        // =========================================
        // Zoom controls (bottom)
        // =========================================

        var __zoomState = __TMKZoom_captureViewState(doc);

        // Ensure import button uses the intended handler (supports Total)
        if (__SC_importHandler) btnPreview.onClick = __SC_importHandler;

        var zoomCtrl = __TMKZoom_addControls(win, doc, getLabel("zoom"), __zoomState, {
            min: 0.1,
            max: 4,
            sliderWidth: 340,
            margins: [0, 0, 0, 10],
            redraw: true,

            // ✅ lightweight mode
            lightMode: true,
            lightModeLabel: getLabel("lightMode"),
            lightModeDefault: false
        });

        // ボタン類（左：リセット / 右：キャンセル・OK）
        var groupButtons = win.add("group");
        groupButtons.orientation = "row";
        groupButtons.alignChildren = ["fill", "center"];

        // 左
        var leftBtnGroup = groupButtons.add("group");
        leftBtnGroup.orientation = "row";
        leftBtnGroup.alignChildren = ["left", "center"];
        var btnReset = leftBtnGroup.add("button", undefined, "リセット");
        var cbLightPreview = leftBtnGroup.add("checkbox", undefined, "軽量プレビュー");
        cbLightPreview.value = true;

        // 中央スペーサー
        var spacer = groupButtons.add("group");
        spacer.alignment = ["fill", "fill"];
        spacer.minimumSize.width = 0;

        // 右
        var rightBtnGroup = groupButtons.add("group");
        rightBtnGroup.orientation = "row";
        rightBtnGroup.alignChildren = ["right", "center"];
        var btnCancel = rightBtnGroup.add("button", undefined, getLabel("cancel"), { name: "cancel" });
        var btnOk = rightBtnGroup.add("button", undefined, getLabel("ok"), { name: "ok" });

        // (Preview/cache declarations moved earlier in main)

        function resetUIToDefaults() {
            try {
                // Load
                // editPages.text = getLabel("defaultPages");
                cbLightPreview.value = true;

                // Item
                ddCrop.selection = 2;
                ddCrop.enabled = __SC_isPdfFile(fileA);

                cbRound.value = false;
                editRound.text = getLabel("defaultRound");
                editRound.enabled = cbRound.value;

                // Grid
                rbDirV.value = true;

                // 列数: 4
                editCols.text = "4";
                syncColsFromEdit();

                editSpacing.text = String(__SC_round(__SC_ptToUnit(DEFAULT_SPACING_PT, rulerUnit.pointsPerUnit), 2));
                syncSpacingFromEdit();

                // Even columns
                cbEvenPlus.value = false;

                // ずらし: OFF
                cbColShift.value = false;
                editColShift.text = getLabel("defaultShift");
                syncShiftFromEdit();
                editColShift.enabled = cbColShift.value;
                sldColShift.enabled = cbColShift.value;

                // Layout
                editScale.text = getLabel("defaultScale");
                syncScaleFromEdit();

                // 回転: OFF
                cbRotate.value = false;
                editRotate.text = getLabel("defaultRotate");
                syncRotateFromEdit();
                editRotate.enabled = cbRotate.value;
                sldRotate.enabled = cbRotate.value;

                // 横方向の位置調整：左右余白が等しくなるよう自動計算
                cbOffsetY.value = false;
                sldOffsetY.value = 0;
                sldOffsetY.enabled = false;

                // default is OFF; we turn ON only if we can compute a sensible center offset
                cbOffsetX.value = false;
                sldOffsetX.value = 0;
                sldOffsetX.enabled = false;

                try {
                    // Compute in pt
                    var pagesForCenter = parsePageNumbers(editPages.text);
                    if (!pagesForCenter || pagesForCenter.length === 0) pagesForCenter = [1];

                    var colsForCenter = parseInt(editCols.text, 10);
                    if (isNaN(colsForCenter) || colsForCenter < 1) colsForCenter = 1;

                    var spacingU = parseFloat(editSpacing.text);
                    if (isNaN(spacingU) || spacingU < 0) spacingU = 0;
                    var marginU = parseFloat(editMargin.text);
                    if (isNaN(marginU) || marginU < 0) marginU = 0;

                    var spacingPt = __SC_unitToPt(spacingU, rulerUnit.pointsPerUnit);
                    var marginPt = __SC_unitToPt(marginU, rulerUnit.pointsPerUnit);

                    var cropMode = getCropModeFromUI();

                    // Base auto-fit scale (rotation OFF for reset)
                    var baseScale = calcAutoScalePctForUI(pagesForCenter, colsForCenter, spacingPt, marginPt, false, 0);
                    var userScale = parseFloat(editScale.text);
                    if (isNaN(userScale) || userScale <= 0) userScale = 100;
                    var finalScale = baseScale * (userScale / 100.0);

                    // Measure item width (cache-first)
                    var itemW = 0;
                    try {
                        if (__previewCache.items && __previewCache.items.length > 0) {
                            // Use cached base width
                            var bw0 = __previewCache.baseW[0];
                            if (!(bw0 > 0)) bw0 = __previewCache.items[0].width;
                            itemW = bw0 * (finalScale / 100.0);
                        } else {
                            // Fallback: temp place once
                            var temp = null;
                            try {
                                if (__SC_isPdfLikeFile(fileA)) {
                                    __SC_setPdfCropPreference(cropMode);
                                }
                                app.preferences.setIntegerPreference("plugin/PDFImport/PageNumber", pagesForCenter[0]);
                                temp = doc.placedItems.add();
                                temp.file = fileA;
                                try { temp.resize(finalScale, finalScale); } catch (e) { }
                                itemW = temp.width;
                            } catch (eTmp) {
                                itemW = 0;
                            } finally {
                                try { if (temp) temp.remove(); } catch (e) { }
                                try { app.preferences.setIntegerPreference("plugin/PDFImport/PageNumber", 1); } catch (e) { }
                            }
                        }
                    } catch (e) {
                        itemW = 0;
                    }

                    if (itemW > 0) {
                        var gridW = (colsForCenter * itemW) + ((colsForCenter - 1) * spacingPt);

                        var ab = doc.artboards[doc.artboards.getActiveArtboardIndex()];
                        var r = ab.artboardRect;
                        var abWpt = Math.abs(r[2] - r[0]);
                        var innerW = abWpt - (marginPt * 2);
                        if (innerW < 1) innerW = 1;

                        var oxPt = (innerW - gridW) / 2;
                        // Convert to unit for slider value
                        var oxU = __SC_ptToUnit(oxPt, rulerUnit.pointsPerUnit);

                        if (isFinite(oxU)) {
                            cbOffsetX.value = true;
                            sldOffsetX.enabled = true;
                            sldOffsetX.value = oxU;
                        }
                    }
                } catch (eCenter) { }

                // Artboard & Mask
                cbBg.value = true;
                editBgHex.text = getLabel("defaultHex");
                updateBgControls();

                cbMask.value = true;
                // margin back to default
                editMargin.text = String(__SC_round(__SC_ptToUnit(DEFAULT_MARGIN_PT, rulerUnit.pointsPerUnit), 2));
                // update mask UI states
                updateMaskUI();

                cbMaskRound.value = false;
                editMaskRound.text = "20";
                editMaskRound.enabled = cbMask.value && cbMaskRound.value;

            } catch (e) { }
        }

        btnReset.onClick = function () {
            // Reset UI only; keep loaded items cached
            resetUIToDefaults();

            // If already loaded, re-apply layout immediately
            if (__previewCache.items && __previewCache.items.length > 0) {
                applyLayoutToCachedItems();
                var core = (__previewCache.group ? [__previewCache.group] : __previewCache.items);
                previewItems = (__previewCache.bgItem ? [__previewCache.bgItem].concat(core) : core);
                app.redraw();
            }
        };

        function calcAutoFitPctFromWH(w, h, total, colsNum, gapPt, abW, abH, evenPlusEnabled, doColShift, colShiftPt, doRotate, rotDeg) {
            if (!(w > 0 && h > 0)) return 100;
            if (!(colsNum > 0)) colsNum = 1;

            var rowsNum = Math.ceil(total / colsNum);

            // 偶数列＋1（スロット追加）: 配置に使うスロット表から最大行数を算出
            if (evenPlusEnabled && colsNum >= 2) {
                var base = Math.floor(total / colsNum);
                var rem = total - (base * colsNum);
                var maxH = 0;
                for (var c = 0; c < colsNum; c++) {
                    var hC = base;
                    if (c < rem) hC += 1;          // 標準の余り配分
                    if ((c % 2) === 1) hC += 1;    // 偶数列（2,4,6...）= 0-based 1,3,5... に +1 スロット
                    if (hC > maxH) maxH = hC;
                }
                if (maxH < 1) maxH = 1;
                rowsNum = maxH;
            }

            var needW = (colsNum * w) + ((colsNum - 1) * gapPt);
            var needH = (rowsNum * h) + ((rowsNum - 1) * gapPt);

            if (doColShift && colShiftPt !== 0) {
                needH += Math.abs(colShiftPt);
            }

            // 回転がある場合は「グリッド全体」を回転させた外接サイズで見積もる
            if (doRotate && rotDeg !== 0) {
                var rad = Math.abs(rotDeg) * Math.PI / 180.0;
                var s = Math.sin(rad);
                var c = Math.cos(rad);
                var gW = needW;
                var gH = needH;
                needW = Math.abs(gW * c) + Math.abs(gH * s);
                needH = Math.abs(gW * s) + Math.abs(gH * c);
            }

            if (!(needW > 0 && needH > 0)) return 100;
            var sW = (abW > 0) ? (abW / needW) : 1;
            var sH = (abH > 0) ? (abH / needH) : 1;
            var sMin = Math.min(sW, sH);
            if (!(sMin > 0)) sMin = 1;
            var pct = Math.round(sMin * 100);
            if (!(pct > 0)) pct = 100;
            return pct;
        }

        function applyLayoutToCachedItems() {
            if (!__previewCache.items || __previewCache.items.length === 0) return;

            // Artboard inner rect (margin excluded)
            var activeAB = doc.artboards[doc.artboards.getActiveArtboardIndex()];
            var abRect = activeAB.artboardRect;
            var startX = abRect[0];
            var startY = abRect[1];
            var abW = Math.abs(abRect[2] - abRect[0]);
            var abH = Math.abs(abRect[1] - abRect[3]);

            var marginUnit = parseFloat(editMargin.text);
            if (isNaN(marginUnit) || marginUnit < 0) marginUnit = 0;
            var marginPt = __SC_unitToPt(marginUnit, rulerUnit.pointsPerUnit);

            startX += marginPt;
            startY -= marginPt;
            abW -= marginPt * 2;
            abH -= marginPt * 2;
            if (abW <= 0) abW = 1;
            if (abH <= 0) abH = 1;

            var colsNum = parseInt(editCols.text, 10);
            if (isNaN(colsNum) || colsNum < 1) colsNum = 1;

            var spacingUnit = parseFloat(editSpacing.text);
            if (isNaN(spacingUnit) || spacingUnit < 0) spacingUnit = 0;
            var gapPt = __SC_unitToPt(spacingUnit, rulerUnit.pointsPerUnit);

            var doColShift = !!cbColShift.value;
            var colShiftUnit = parseFloat(editColShift.text);
            if (isNaN(colShiftUnit)) colShiftUnit = 0;
            var colShiftPt = __SC_unitToPt(colShiftUnit, rulerUnit.pointsPerUnit);

            var flowMode = getFlowMode();
            // Random mode: prepare a persistent shuffle order
            if (flowMode === 2) {
                if (__previewCache.finalRandOrder && __previewCache.finalRandOrder.length === __previewCache.items.length) {
                    __previewCache.randOrder = __previewCache.finalRandOrder.slice(0);
                } else {
                    __SC_ensureRandomOrder(__previewCache);
                }
            } else {
                __SC_clearRandomOrder(__previewCache);
            }
            var evenPlusEnabled = !!cbEvenPlus.value;

            var doRotate = !!cbRotate.value;
            var rot = parseFloat(editRotate.text);
            if (isNaN(rot)) rot = 0;

            var userScale = parseFloat(editScale.text);
            if (isNaN(userScale) || userScale <= 0) userScale = 100;
            if (userScale < 1) userScale = 1;

            // base size from the first loaded item (unscaled)
            var w0 = __previewCache.baseW[0] || __previewCache.items[0].width;
            var h0 = __previewCache.baseH[0] || __previewCache.items[0].height;

            var baseScale = calcAutoFitPctFromWH(w0, h0, __previewCache.items.length, colsNum, gapPt, abW, abH, evenPlusEnabled, doColShift, colShiftPt, doRotate, rot);
            var finalScale = baseScale * (userScale / 100.0);

            // Even+1 slot heights (slot table) to compute col/row mapping
            var colHeights = null;
            var colStart = null;
            if (evenPlusEnabled && colsNum >= 2) {
                var totalN = __previewCache.items.length;
                var base = Math.floor(totalN / colsNum);
                var rem = totalN - (base * colsNum);
                colHeights = [];
                for (var c = 0; c < colsNum; c++) {
                    var hh = base;
                    if (c < rem) hh += 1;
                    if ((c % 2) === 1) hh += 1; // +1 slot for even columns
                    colHeights.push(hh);
                }
                colStart = [0];
                for (var c2 = 0; c2 < colsNum; c2++) colStart[c2 + 1] = colStart[c2] + colHeights[c2];
            }
            function indexToColRow(iIndex) {
                if (colHeights && colStart) {
                    for (var c = 0; c < colHeights.length; c++) {
                        if (iIndex >= colStart[c] && iIndex < colStart[c + 1]) {
                            return { col: c, row: iIndex - colStart[c] };
                        }
                    }
                    return { col: colHeights.length - 1, row: 0 };
                }
                var rowsN = Math.ceil(__previewCache.items.length / colsNum);
                if (flowMode === 1 || flowMode === 2) {
                    return { col: Math.floor(iIndex / rowsN), row: (iIndex % rowsN) };
                }
                return { col: (iIndex % colsNum), row: Math.floor(iIndex / colsNum) };
            }

            // Update background fill if enabled
            try {
                if (cbBg.value && __previewCache.bgItem) {
                    __previewCache.bgItem.fillColor = getBgRGBColorOrDefault();
                }
            } catch (e) { }

            // If we previously grouped for rotation, un-rotate back to 0 by delta
            if (__previewCache.group && __previewCache.currentRot !== 0) {
                try {
                    __previewCache.group.rotate(-__previewCache.currentRot);
                } catch (e) { }
                __previewCache.currentRot = 0;
            }

            // Resize & position each item (absolute, using baseW/baseH)
            for (var i = 0; i < __previewCache.items.length; i++) {
                var idxItem = i;
                if (flowMode === 2 && __previewCache.randOrder) {
                    idxItem = __previewCache.randOrder[i];
                }
                var it = __previewCache.items[idxItem];
                if (!it) continue;

                var bw = __previewCache.baseW[idxItem];
                var bh = __previewCache.baseH[idxItem];
                if (!(bw > 0) || !(bh > 0)) {
                    bw = it.width;
                    bh = it.height;
                }

                // Apply size (avoid cumulative scaling)
                try {
                    it.width = bw * (finalScale / 100.0);
                    it.height = bh * (finalScale / 100.0);
                } catch (e) { }

                // Map to grid position
                var cr = indexToColRow(i);
                var x = startX + (cr.col * (it.width + gapPt));
                var y = startY - (cr.row * (it.height + gapPt));

                // Even-column Y shift
                if (doColShift && colShiftPt !== 0 && (cr.col % 2 === 1)) {
                    if (colShiftPt > 0) y -= colShiftPt;
                    else y += Math.abs(colShiftPt);
                }

                try { it.position = [x, y]; } catch (e) { }
            }

            // -------------------------------------------------
            // Round Corners in preview (heavy mode only)
            // - 軽量プレビューOFFのときだけ、各アイテムをクリップ化して角丸を適用
            // -------------------------------------------------
            try {
                var isHeavyPreview = !cbLightPreview.value;
                if (isHeavyPreview && cbRound.value) {
                    var roundUnit = parseFloat(editRound.text);
                    if (isNaN(roundUnit) || roundUnit < 0) roundUnit = 0;
                    var roundPt = __SC_unitToPt(roundUnit, rulerUnit.pointsPerUnit);

                    if (roundPt > 0) {
                        // Ensure every item is a clip GroupItem (retry per-item; do NOT rely on one-shot flag)
                        var allWrapped = true;
                        for (var wi = 0; wi < __previewCache.items.length; wi++) {
                            var it0 = __previewCache.items[wi];
                            if (!it0) { allWrapped = false; continue; }

                            if (it0.typename !== "GroupItem") {
                                allWrapped = false;

                                // Try to wrap this item now
                                var clipGrp = null;
                                try { clipGrp = __SC_wrapWithClipGroup(doc, it0); } catch (e) { clipGrp = null; }

                                if (clipGrp) {
                                    // Keep the index mapping stable (important for baseW/baseH and randOrder)
                                    __previewCache.items[wi] = clipGrp;

                                    // Move the new clip group into the persistent rotation group (if any)
                                    try { if (__previewCache.group) clipGrp.moveToEnd(__previewCache.group); } catch (e) { }
                                }
                            }
                        }

                        // Mark as wrapped only if all items are groups
                        __previewCache.previewWrapped = allWrapped;

                        // Apply effect when radius changed OR when we just created groups
                        if (__previewCache.previewRoundRadiusPt !== roundPt) {
                            for (var ei = 0; ei < __previewCache.items.length; ei++) {
                                try {
                                    var itG = __previewCache.items[ei];
                                    if (itG && itG.typename === "GroupItem") {
                                        __SC_applyRoundCorners([itG], roundPt);
                                    }
                                } catch (e) { }
                            }
                            __previewCache.previewRoundRadiusPt = roundPt;
                        }
                    }
                }
            } catch (e) { }

            // Rotation (group-based) and center to artboard center
            if (doRotate && rot !== 0 && __previewCache.group) {
                try {
                    __previewCache.group.rotate(rot);
                    __previewCache.currentRot = rot;
                    __SC_moveItemCenterToArtboardCenter(doc, __previewCache.group);

                    // Apply offsets after centering
                    var oxPt = (cbOffsetX.value) ? __SC_unitToPt(sldOffsetX.value, rulerUnit.pointsPerUnit) : 0;
                    var oyPt = (cbOffsetY.value) ? __SC_unitToPt(sldOffsetY.value, rulerUnit.pointsPerUnit) : 0;
                    if (oxPt !== 0 || oyPt !== 0) {
                        __previewCache.group.translate(oxPt, -oyPt);
                    }
                } catch (e) { }
            } else {
                // Non-rotate offsets: apply by shifting start already is done in non-rotate path; here we just apply nothing.
            }

            app.redraw();
        }

        function updateBgOnly() {
            try {
                // 読み込み前ならキャンバス更新不要（UI側は updateBgControls がやる）
                if (!__previewCache.items || __previewCache.items.length === 0) {
                    app.redraw();
                    return;
                }

                if (cbBg.value) {
                    // 背景ON：bgItemが無ければ作る
                    if (!__previewCache.bgItem) {
                        try {
                            __previewCache.bgItem = __SC_drawArtboardBackground(doc, getBgRGBColorOrDefault());
                        } catch (e) {
                            __previewCache.bgItem = null;
                        }
                    }
                    // 色だけ更新
                    if (__previewCache.bgItem) {
                        try { __previewCache.bgItem.fillColor = getBgRGBColorOrDefault(); } catch (e) { }
                        try { __previewCache.bgItem.zOrder(ZOrderMethod.SENDTOBACK); } catch (e) { }
                    }
                } else {
                    // 背景OFF：bgItemを消す
                    if (__previewCache.bgItem) {
                        removeItemSafe(__previewCache.bgItem);
                        __previewCache.bgItem = null;
                    }
                }

                // previewItems も同期
                var core = (__previewCache.group ? [__previewCache.group] : __previewCache.items);
                previewItems = (__previewCache.bgItem ? [__previewCache.bgItem].concat(core) : core);

                app.redraw();
            } catch (e) { }
        }

        function clearPreview() {
            // If cache exists, do not remove its items here
            if (__previewCache.items && __previewCache.items.length > 0) {
                return;
            }
            for (var i = previewItems.length - 1; i >= 0; i--) {
                try { previewItems[i].remove(); } catch (e) { }
            }
            previewItems = [];
            app.redraw();
        }

        function __SC_updatePreviewImpl() {
            // 既存キャッシュがある場合は再配置せず更新
            if (__previewCache.items && __previewCache.items.length > 0) {
                applyLayoutToCachedItems();
                // Keep previewItems for cancel/cleanup paths
                var core = (__previewCache.group ? [__previewCache.group] : __previewCache.items);
                previewItems = (__previewCache.bgItem ? [__previewCache.bgItem].concat(core) : core);
                return;
            }
            // 未読み込みの場合は何もしない（ユーザーが[読み込み]を押す）
        }

        // =========================================
        // Step2+Step3: Centralized realtime-preview wiring (debounced)
        // - 読み込み＞アートボード（editPages）は対象外
        // - debounce: 300ms
        // =========================================

        var PREVIEW_DEBOUNCE_MS = 300;
        var __previewTaskId = null;

        // Expose updatePreview for app.scheduleTask
        $.global.__SC_updatePreview = __SC_updatePreviewImpl;

        function requestPreview() {
            try {
                if (__previewTaskId) {
                    app.cancelTask(__previewTaskId);
                    __previewTaskId = null;
                }
            } catch (e) { }

            try {
                __previewTaskId = app.scheduleTask("$.global.__SC_updatePreview();", PREVIEW_DEBOUNCE_MS, false);
            } catch (e2) {
                // Fallback: run immediately
                try { __SC_updatePreviewImpl(); } catch (e3) { }
            }
        }

        function wireRealtimePreview() {
            cbLightPreview.onClick = function () { requestPreview(); };
            // ✅ 読み込み＞アートボード（editPages）は対象外

            // アイテム
            ddCrop.onChange = function () { requestPreview(); };
            editRound.onChange = function () { requestPreview(); };
            var _oldRound = cbRound.onClick;
            cbRound.onClick = function () { _oldRound(); requestPreview(); };

            // グリッド：方向
            rbDirH.onClick = function () { __SC_clearRandomOrder(__previewCache); requestPreview(); };
            rbDirV.onClick = function () { __SC_clearRandomOrder(__previewCache); requestPreview(); };
            rbDirR.onClick = function () { __SC_clearRandomOrder(__previewCache); requestPreview(); };

            // グリッド：偶数列＋1
            cbEvenPlus.onClick = function () { requestPreview(); };

            // グリッド：列数
            editCols.onChange = function () { syncColsFromEdit(); requestPreview(); };
            sldCols.onChange = function () { syncColsFromSlider(); requestPreview(); };

            // グリッド：間隔
            editSpacing.onChange = function () { syncSpacingFromEdit(); requestPreview(); };
            sldSpacing.onChange = function () { syncSpacingFromSlider(); requestPreview(); };

            // グリッド：ズレ
            editColShift.onChange = function () { syncShiftFromEdit(); requestPreview(); };
            sldColShift.onChange = function () { syncShiftFromSlider(); requestPreview(); };
            var _oldShift = cbColShift.onClick;
            cbColShift.onClick = function () { _oldShift(); requestPreview(); };

            // アートボード
            editMargin.onChange = function () { requestPreview(); };
            var _oldBg = cbBg.onClick;
            cbBg.onClick = function () {
                if (_oldBg) _oldBg();        // updateBgControls()
                updateBgOnly();         // レイアウト再計算しない
            };

            var _oldHex = editBgHex.onChange;
            editBgHex.onChange = function () {
                if (_oldHex) _oldHex();      // updateBgControls()
                updateBgOnly();         // レイアウト再計算しない
            };

            // 右カラム：レイアウト
            editScale.onChange = function () { __SC_syncScaleFromEdit(); requestPreview(); };
            sldScale.onChange = function () { __SC_syncScaleFromSlider(); requestPreview(); };

            editRotate.onChange = function () { __SC_syncRotateFromEdit(); requestPreview(); };
            sldRotate.onChange = function () { __SC_syncRotateFromSlider(); requestPreview(); };
            var _oldRot = cbRotate.onClick;
            cbRotate.onClick = function () { _oldRot(); requestPreview(); };

            var _oldOffX = cbOffsetX.onClick;
            cbOffsetX.onClick = function () { _oldOffX(); requestPreview(); };
            sldOffsetX.onChange = function () { requestPreview(); };

            var _oldOffY = cbOffsetY.onClick;
            cbOffsetY.onClick = function () { _oldOffY(); requestPreview(); };
            sldOffsetY.onChange = function () { requestPreview(); };
        }

        // 初期配線
        wireRealtimePreview();

        // =========================================
        // Arrow-key increment for edittexts (↑↓ / Shift / Option)
        // =========================================

        function changeValueByArrowKey(editText, allowNegative, afterChange) {
            editText.addEventListener("keydown", function (event) {
                var value = Number(editText.text);
                if (isNaN(value)) return;

                var keyboard = ScriptUI.environment.keyboardState;
                var delta = 1;

                if (keyboard.shiftKey) {
                    delta = 10;
                    if (event.keyName === "Up") {
                        value = Math.ceil((value + 1) / delta) * delta;
                        try { event.preventDefault(); } catch (e0) { }
                    } else if (event.keyName === "Down") {
                        value = Math.floor((value - 1) / delta) * delta;
                        try { event.preventDefault(); } catch (e1) { }
                    } else {
                        return;
                    }
                } else if (keyboard.altKey) {
                    delta = 0.1;
                    if (event.keyName === "Up") {
                        value += delta;
                        try { event.preventDefault(); } catch (e2) { }
                    } else if (event.keyName === "Down") {
                        value -= delta;
                        try { event.preventDefault(); } catch (e3) { }
                    } else {
                        return;
                    }
                } else {
                    delta = 1;
                    if (event.keyName === "Up") {
                        value += delta;
                        try { event.preventDefault(); } catch (e4) { }
                    } else if (event.keyName === "Down") {
                        value -= delta;
                        try { event.preventDefault(); } catch (e5) { }
                    } else {
                        return;
                    }
                }

                if (keyboard.altKey) {
                    value = Math.round(value * 10) / 10; // 0.1
                } else {
                    value = Math.round(value); // integer
                }

                if (!allowNegative && value < 0) value = 0;

                editText.text = String(value);

                if (typeof afterChange === "function") {
                    try { afterChange(); } catch (e6) { }
                }
            });
        }

        // Apply to edit fields (do NOT apply to editPages)
        changeValueByArrowKey(editCols, false, function () { syncColsFromEdit(); requestPreview(); });
        changeValueByArrowKey(editSpacing, false, function () { syncSpacingFromEdit(); requestPreview(); });
        changeValueByArrowKey(editColShift, true, function () { syncShiftFromEdit(); requestPreview(); });
        changeValueByArrowKey(editScale, false, function () { __SC_syncScaleFromEdit(); requestPreview(); });
        changeValueByArrowKey(editRotate, true, function () { __SC_syncRotateFromEdit(); requestPreview(); });

        // Left column
        changeValueByArrowKey(editMargin, false, function () { requestPreview(); });
        changeValueByArrowKey(editRound, false, function () { requestPreview(); });
        changeValueByArrowKey(editMaskRound, false, function () { /* mask is OK-only */ });

        // 角丸（ライブエフェクト）
        function __SC_createRoundCornersEffectXML(radiusPt) {
            var r = (typeof radiusPt === "number" && !isNaN(radiusPt)) ? radiusPt : 0;
            if (r < 0) r = 0;
            // NOTE: Illustrator LiveEffect XML expects pt
            var xml = '<LiveEffect name="Adobe Round Corners"><Dict data="R radius ' + r + ' "/></LiveEffect>';
            return xml;
        }

        function __SC_applyRoundCorners(items, radiusPt) {
            if (!items || items.length === 0) return;
            var xml = __SC_createRoundCornersEffectXML(radiusPt);
            for (var i = 0; i < items.length; i++) {
                try {
                    items[i].applyEffect(xml);
                } catch (e) {
                    // ignore
                }
            }
        }

        // 各配置アイテムを同サイズのパスでクリップグループ化
        function __SC_wrapWithClipGroup(doc, item) {
            if (!item) return null;

            var b;
            try {
                b = item.geometricBounds;
            } catch (e) {
                try { b = item.visibleBounds; } catch (e2) { return null; }
            }
            if (!b || b.length < 4) return null;

            // bounds: [left, top, right, bottom]
            var left = b[0];
            var top = b[1];
            var w = Math.abs(b[2] - b[0]);
            var h = Math.abs(b[1] - b[3]);
            if (w <= 0) w = 1;
            if (h <= 0) h = 1;

            // マスク用パス（塗りなし・線なし）
            var maskPath = doc.activeLayer.pathItems.rectangle(top, left, w, h);
            maskPath.stroked = false;
            maskPath.filled = false;
            maskPath.clipping = true;

            var grp = doc.groupItems.add();

            // まず中身（placed item）を末尾へ
            try { item.moveToEnd(grp); } catch (e3) { }
            // マスクは最前面（グループ先頭）
            try { maskPath.moveToBeginning(grp); } catch (e4) { }

            grp.clipped = true;
            return grp;
        }

        function __SC_drawArtboardBackground(doc, fillColor) {
            var ab = doc.artboards[doc.artboards.getActiveArtboardIndex()];
            var r = ab.artboardRect; // [left, top, right, bottom]
            var left = r[0];
            var top = r[1];
            var w = Math.abs(r[2] - r[0]);
            var h = Math.abs(r[1] - r[3]);

            // rectangle(top, left, width, height)
            var bg = doc.activeLayer.pathItems.rectangle(top, left, w, h);
            bg.stroked = false;
            bg.filled = true;
            bg.fillColor = fillColor || makeRGBColor(0, 0, 0);

            try { bg.zOrder(ZOrderMethod.SENDTOBACK); } catch (e) { }
            return bg;
        }

        function __SC_applyArtboardMask(doc, itemsToClip, marginPt) {
            if (!itemsToClip || itemsToClip.length === 0) return null;

            var ab = doc.artboards[doc.artboards.getActiveArtboardIndex()];
            var r = ab.artboardRect; // [left, top, right, bottom]
            var m = (typeof marginPt === "number" && !isNaN(marginPt) && marginPt >= 0) ? marginPt : 0;

            var left = r[0] + m;
            var top = r[1] - m;
            var w = Math.abs(r[2] - r[0]) - (m * 2);
            var h = Math.abs(r[1] - r[3]) - (m * 2);
            if (w <= 0) w = 1;
            if (h <= 0) h = 1;

            // マスク用パス（塗りなし・線なし）
            var maskPath = doc.activeLayer.pathItems.rectangle(top, left, w, h);
            maskPath.stroked = false;
            maskPath.filled = false;
            maskPath.clipping = true;

            var grp = doc.groupItems.add();

            // まずクリップ対象をグループへ（末尾へ）
            for (var i = itemsToClip.length - 1; i >= 0; i--) {
                try {
                    itemsToClip[i].moveToEnd(grp);
                } catch (e1) { }
            }

            // マスクは最前面（グループ先頭）に
            try { maskPath.moveToBeginning(grp); } catch (e0) { }

            grp.clipped = true;
            return grp;
        }

        function __SC_getBoundsCenter(bounds) {
            // bounds: [left, top, right, bottom]
            var cx = (bounds[0] + bounds[2]) / 2;
            var cy = (bounds[1] + bounds[3]) / 2;
            return { x: cx, y: cy };
        }

        function __SC_getArtboardCenter(doc) {
            var ab = doc.artboards[doc.artboards.getActiveArtboardIndex()];
            var r = ab.artboardRect; // [left, top, right, bottom]
            return { x: (r[0] + r[2]) / 2, y: (r[1] + r[3]) / 2 };
        }

        function __SC_moveItemCenterToArtboardCenter(doc, item) {
            if (!item) return;
            var b;
            try {
                b = item.geometricBounds;
            } catch (e) {
                try { b = item.visibleBounds; } catch (e2) { return; }
            }
            if (!b || b.length < 4) return;

            var cItem = __SC_getBoundsCenter(b);
            var cAb = __SC_getArtboardCenter(doc);

            var dx = cAb.x - cItem.x;
            var dy = cAb.y - cItem.y;

            try {
                item.translate(dx, dy);
            } catch (e3) { }
        }

        function placeArtboards(targetPages, cols, spacing, scalePct, autoFit, outerMargin, colShiftEnabled, colShiftPt, rotateEnabled, rotateDeg, bgEnabled, bgFillColor, cropMode, offsetXPt, offsetYPt, flowMode, evenPlusEnabled, roundEnabled, roundRadiusPt, lightPreview) {
            var placedItemsOnly = [];
            var bgItem = null;
            var __lightPreview = !!lightPreview;
            if (bgEnabled) {
                try {
                    bgItem = __SC_drawArtboardBackground(doc, bgFillColor);
                } catch (eBg) {
                    bgItem = null;
                }
            }

            // 現在のアクティブなアートボードの左上を基準点にする
            var activeAB = doc.artboards[doc.artboards.getActiveArtboardIndex()];
            var abRect = activeAB.artboardRect; // [left, top, right, bottom]
            var startX = abRect[0];
            var startY = abRect[1];

            var abW = Math.abs(abRect[2] - abRect[0]);
            var abH = Math.abs(abRect[1] - abRect[3]);

            var margin = (typeof outerMargin === "number" && !isNaN(outerMargin) && outerMargin >= 0) ? outerMargin : 0;

            var doColShift = !!colShiftEnabled;
            var colShift = (typeof colShiftPt === "number" && !isNaN(colShiftPt)) ? colShiftPt : 0;
            var doRotate = !!rotateEnabled;
            var rot = (typeof rotateDeg === "number" && !isNaN(rotateDeg)) ? rotateDeg : 0;

            // 外側余白を適用
            startX += margin;
            startY -= margin;
            abW -= margin * 2;
            abH -= margin * 2;

            if (abW <= 0) abW = 1;
            if (abH <= 0) abH = 1;

            // 全体位置オフセット（横：＋で右、縦：＋で下）
            var ox = (typeof offsetXPt === "number" && !isNaN(offsetXPt)) ? offsetXPt : 0;
            var oy = (typeof offsetYPt === "number" && !isNaN(offsetYPt)) ? offsetYPt : 0;

            // 回転で全体をアートボード中心に合わせる場合は、ここでのオフセットは二重適用になるため保留し、回転後に適用する
            var willCenterAfterRotate = (doRotate && rot !== 0);
            if (!willCenterAfterRotate) {
                startX += ox;
                startY -= oy;
            }

            // scalePct は「追加倍率（%）」として扱う（自動フィットの結果に乗算）
            function calcAutoScalePct(pages, colsNum, gapPt) {
                if (!pages || pages.length === 0) return 100;
                var w = 0, h = 0;
                var pageNum0 = pages[0];

                // cache hit
                var cached = __SC_getAutoFitMeasure(fileA, cropMode, pageNum0);
                if (cached) {
                    w = cached.w;
                    h = cached.h;
                } else {
                    var temp = null;
                    try {
                        if (__SC_isPdfLikeFile(fileA)) {
                            __SC_setPdfCropPreference(cropMode);
                        }
                        app.preferences.setIntegerPreference("plugin/PDFImport/PageNumber", pageNum0);
                        temp = doc.placedItems.add();
                        temp.file = fileA;
                        w = temp.width;
                        h = temp.height;
                    } catch (e) {
                        w = 0; h = 0;
                    } finally {
                        try { if (temp) temp.remove(); } catch (e2) { }
                    }

                    // store
                    __SC_setAutoFitMeasure(fileA, cropMode, pageNum0, w, h);
                }

                if (!(w > 0 && h > 0)) return 100;

                var total = pages.length;
                var rowsNum = Math.ceil(total / colsNum);

                // 偶数列＋1（スロット追加）: 配置に使うスロット表から最大行数を算出
                if (evenPlusEnabled && colsNum >= 2) {
                    var base = Math.floor(total / colsNum);
                    var rem = total - (base * colsNum);
                    var maxH = 0;
                    for (var c = 0; c < colsNum; c++) {
                        var hC = base;
                        if (c < rem) hC += 1;
                        if ((c % 2) === 1) hC += 1;
                        if (hC > maxH) maxH = hC;
                    }
                    if (maxH < 1) maxH = 1;
                    rowsNum = maxH;
                }

                var needW = (colsNum * w) + ((colsNum - 1) * gapPt);
                var needH = (rowsNum * h) + ((rowsNum - 1) * gapPt);

                if (doColShift && colShift !== 0) {
                    needH += Math.abs(colShift);
                }

                // 回転がある場合は「グリッド全体」を回転させた外接サイズで見積もる
                if (doRotate && rot !== 0) {
                    var rad = Math.abs(rot) * Math.PI / 180.0;
                    var s = Math.sin(rad);
                    var c = Math.cos(rad);

                    var gW = needW;
                    var gH = needH;

                    var rW = Math.abs(gW * c) + Math.abs(gH * s);
                    var rH = Math.abs(gW * s) + Math.abs(gH * c);

                    needW = rW;
                    needH = rH;
                }

                if (!(needW > 0 && needH > 0)) return 100;

                // Auto-fit uses artboard inner size (exclude outer margin)
                var innerW = abW;
                var innerH = abH;

                if (margin > 0) {
                    innerW = abW; // already margin-subtracted above in placeArtboards
                    innerH = abH; // already margin-subtracted above in placeArtboards
                }

                var sW = (innerW > 0) ? (innerW / needW) : 1;
                var sH = (innerH > 0) ? (innerH / needH) : 1;
                var s = Math.min(sW, sH);
                if (!(s > 0)) s = 1;

                // 整数（%）に丸め
                var pct = Math.round(s * 100);
                if (!(pct > 0)) pct = 100;
                return pct;
            }

            // scalePct は「追加倍率（%）」として扱う（自動フィットの結果に乗算）
            var userScale = (typeof scalePct === "number" && !isNaN(scalePct) && scalePct > 0) ? scalePct : 100;
            if (userScale < 1) userScale = 1;

            var baseScale = 100;
            if (autoFit) {
                baseScale = calcAutoScalePct(targetPages, cols, spacing);
            } else {
                baseScale = 100;
            }

            var finalScale = baseScale * (userScale / 100.0);
            if (!(finalScale > 0)) finalScale = baseScale;

            var refW = null;
            var refH = null;

            // 配置順（ランダム対応）
            function __SC_shuffle(arr) {
                for (var i = arr.length - 1; i > 0; i--) {
                    var j = Math.floor(Math.random() * (i + 1));
                    var t = arr[i];
                    arr[i] = arr[j];
                    arr[j] = t;
                }
                return arr;
            }

            var order = [];
            for (var oi = 0; oi < targetPages.length; oi++) order.push(oi);
            if (flowMode === 2) {
                __SC_shuffle(order);
            }

            // 偶数列＋1 用の列高さテーブル（配分モード）を事前計算
            var __evenColHeights = null;
            var __evenColStart = null; // cumulative start index per column
            if (evenPlusEnabled) {
                var __colsN = cols;
                if (!(__colsN > 0)) __colsN = 1;
                if (__colsN >= 2) {
                    var __totalN = targetPages.length;
                    var __base = Math.floor(__totalN / __colsN);
                    var __rem = __totalN - (__base * __colsN);

                    __evenColHeights = [];

                    // 配分：標準配分（rem） + 偶数列に追加スロット(+1)
                    // ※合計スロット数は totalN を超える場合があり、その分は空きになる（4/5/4/5 など）
                    for (var __c = 0; __c < __colsN; __c++) {
                        var h = __base;
                        if (__c < __rem) h += 1;        // 標準の余り配分
                        if ((__c % 2) === 1) h += 1;    // 偶数列（2,4,6...）= 0-based 1,3,5... に +1 スロット
                        __evenColHeights.push(h);
                    }

                    __evenColStart = [0];
                    for (var __c4 = 0; __c4 < __colsN; __c4++) {
                        __evenColStart[__c4 + 1] = __evenColStart[__c4] + __evenColHeights[__c4];
                    }
                }
            }

            function __SC_indexToColRowEven(iIndex) {
                // returns {col,row}
                if (!__evenColHeights || !__evenColStart) return null;
                var colsN = __evenColHeights.length;
                // linear search is fine for <=20 cols
                for (var c = 0; c < colsN; c++) {
                    var start = __evenColStart[c];
                    var end = __evenColStart[c + 1];
                    if (iIndex >= start && iIndex < end) {
                        return { col: c, row: (iIndex - start) };
                    }
                }
                // fallback
                return { col: colsN - 1, row: 0 };
            }

            try {
                for (var i = 0; i < targetPages.length; i++) {
                    var abNumber = targetPages[order[i]];
                    if (__SC_isPdfLikeFile(fileA)) {
                        __SC_setPdfCropPreference(cropMode);
                    }
                    __SC_setImportPageNumber(fileA, abNumber);

                    var placedItem = doc.placedItems.add();
                    placedItem.file = fileA;

                    // 先に縮尺（中心基準）
                    try {
                        placedItem.resize(finalScale, finalScale);
                    } catch (eResize) {
                        // resize 失敗時は無視して続行
                    }

                    // 1つ目のサイズを基準にグリッド計算（ページごとにサイズが違っても配置が崩れにくい）
                    if (refW === null || refH === null) {
                        refW = placedItem.width;
                        refH = placedItem.height;
                    }

                    // 配置位置の計算（横方向=行優先 / 縦方向=列優先）

                    var totalN = targetPages.length;
                    var colsN = cols;
                    if (!(colsN > 0)) colsN = 1;

                    // 通常の行数
                    var rowsN = Math.ceil(totalN / colsN);
                    if (!(rowsN > 0)) rowsN = 1;

                    var colIndex, rowIndex;

                    // 偶数列＋1（配分モード）が有効な場合は、方向に関わらず列配分を優先
                    if (__evenColHeights && __evenColStart) {
                        var cr = __SC_indexToColRowEven(i);
                        colIndex = cr.col;
                        rowIndex = cr.row;
                    } else if (flowMode === 1 || flowMode === 2) {
                        // 縦方向（列優先）/ ランダム（縦配置）
                        rowIndex = i % rowsN;
                        colIndex = Math.floor(i / rowsN);
                    } else {
                        // 横方向（行優先）
                        colIndex = i % colsN;
                        rowIndex = Math.floor(i / colsN);
                    }

                    var posX = startX + (colIndex * (refW + spacing));
                    var posY = startY - (rowIndex * (refH + spacing));

                    // 偶数列（2列目,4列目...）の上下位置を調整
                    // 正の値：下へずらす
                    // 負の値：上へずらす
                    if (doColShift && colShift !== 0 && (colIndex % 2 === 1)) {
                        if (colShift > 0) {
                            posY -= colShift;
                        } else {
                            posY += Math.abs(colShift);
                        }
                    }

                    placedItem.position = [posX, posY];

                    if (__lightPreview) {
                        // 軽量プレビュー：クリップ/角丸は省略
                        placedItemsOnly.push(placedItem);
                    } else {
                        // 配置したアイテムを同サイズのパスでクリップグループ化
                        var clipGrp = null;
                        try {
                            clipGrp = __SC_wrapWithClipGroup(doc, placedItem);
                        } catch (eClip) {
                            clipGrp = null;
                        }

                        // 角丸（ライブエフェクト）：クリップグループに適用
                        if (roundEnabled && (typeof roundRadiusPt === "number") && !isNaN(roundRadiusPt) && roundRadiusPt > 0) {
                            if (clipGrp) {
                                __SC_applyRoundCorners([clipGrp], roundRadiusPt);
                            } else {
                                // フォールバック：クリップ化に失敗した場合はアイテムに適用
                                __SC_applyRoundCorners([placedItem], roundRadiusPt);
                            }
                        }

                        placedItemsOnly.push(clipGrp ? clipGrp : placedItem);
                    }
                }

                // 列ずらし適用後に「全体」を回転（背景は回転させない）
                if (doRotate && rot !== 0 && placedItemsOnly.length > 0) {
                    var grp = null;
                    try {
                        grp = doc.groupItems.add();

                        // moveToBeginning は順序が反転しやすいので逆順で移動して見た目順を維持
                        for (var gi = placedItemsOnly.length - 1; gi >= 0; gi--) {
                            try { placedItemsOnly[gi].moveToBeginning(grp); } catch (eMove) { }
                        }

                        try { grp.rotate(rot); } catch (eGrpRot) { }

                        // 回転後：アイテム全体の中心をアートボード中心に合わせる
                        __SC_moveItemCenterToArtboardCenter(doc, grp);

                        // 回転適用時も位置調整（横：＋で右、縦：＋で下）
                        if (ox !== 0 || oy !== 0) {
                            try { grp.translate(ox, -oy); } catch (ePos) { }
                        }

                        placedItemsOnly = [grp];
                    } catch (eGrp) {
                        // グループ化/回転に失敗しても配置済みアイテムは残す
                    }
                }

            } catch (e) {
                alert(getLabel("alertPlaceError"));
            } finally {
                try { app.preferences.setIntegerPreference("plugin/PDFImport/PageNumber", 1); } catch (e) { }
                try { __SC_resetImportPageNumber(fileA); } catch (e) { }
            }
            var allItems = placedItemsOnly;
            if (bgItem) {
                allItems = [bgItem].concat(placedItemsOnly);
            }
            return {
                items: allItems,
                maskItems: placedItemsOnly,
                scale: finalScale
            };
        }

        // プレビューボタン
        btnPreview.onClick = function () {
            // Rebuild cache on explicit load
            __SC_clearPreviewCache(__previewCache);

            var pages = parsePageNumbers(editPages.text);
            // Repeat pages/artboards when requested count exceeds source count
            try {
                var srcCount = getSourcePageCount(fileA);
                if (srcCount > 0) {
                    pages = repeatPagesWithinCount(pages, srcCount);
                }
            } catch (e) { }
            if (!pages || pages.length === 0) return;

            var cropMode = getCropModeFromUI();

            // Background (always created on load if enabled)
            if (cbBg.value) {
                try {
                    __previewCache.bgItem = __SC_drawArtboardBackground(doc, getBgRGBColorOrDefault());
                } catch (e) {
                    __previewCache.bgItem = null;
                }
            }

            // Place items once
            for (var i = 0; i < pages.length; i++) {
                try {
                    if (__SC_isPdfLikeFile(fileA)) {
                        __SC_setPdfCropPreference(cropMode);
                    }
                    __SC_setImportPageNumber(fileA, pages[i]);
                    var it = doc.placedItems.add();
                    it.file = fileA;
                    __previewCache.items.push(it);
                    __previewCache.baseW.push(it.width);
                    __previewCache.baseH.push(it.height);
                } catch (e) {
                    // ignore individual failures
                }
            }
            try { __SC_resetImportPageNumber(fileA); } catch (e) { }

            __previewCache.cropMode = cropMode;
            __previewCache.pagesKey = String(editPages.text);

            // --- create persistent group for fast rotation ---
            try {
                var grp = doc.groupItems.add();
                for (var gi = __previewCache.items.length - 1; gi >= 0; gi--) {
                    try { __previewCache.items[gi].moveToBeginning(grp); } catch (e) { }
                }
                __previewCache.group = grp;
                __previewCache.currentRot = 0;
            } catch (eGrp) {
                __previewCache.group = null;
                __previewCache.currentRot = 0;
            }

            // Apply layout immediately
            applyLayoutToCachedItems();
            var core = (__previewCache.group ? [__previewCache.group] : __previewCache.items);
            previewItems = (__previewCache.bgItem ? [__previewCache.bgItem].concat(core) : core);
        };

        // キャンセルボタン
        btnCancel.onClick = function () {
            // Stop any pending debounced preview task (prevents callbacks after close)
            try {
                if (__previewTaskId) {
                    app.cancelTask(__previewTaskId);
                    __previewTaskId = null;
                }
            } catch (e) { }

            // Preview cache removal is enough (clearPreview() would early-return when cache exists)
            __SC_clearPreviewCache(__previewCache);

            try { if (zoomCtrl) zoomCtrl.restoreInitial(); } catch (eZ) { }
            __SC_saveDialogBounds(win.bounds);
            win.close(2);
        };

        // OKボタン
        btnOk.onClick = function () {

            // Finalize should not destroy the current preview cache here.
            // The success path after win.show() decides whether to reuse the visible preview
            // or place fresh items. Clearing here causes duplication / mismatch bugs.

            // Bake the exact preview random order into the cache so finalize cannot reshuffle.
            bakePreviewRandomOrderForFinalize();

            // Normalize current UI values so the success path reads the same state as the preview.
            syncLayoutInputsBeforeFinalize();

            // For non-random modes, refresh the visible preview once so the last preview matches current UI.
            if (__previewCache.items && __previewCache.items.length > 0) {
                if (shouldRelayoutOnFinalize()) {
                    applyLayoutToCachedItems();
                }
                app.redraw();
            }

            __SC_saveDialogBounds(win.bounds);
            win.close(1);
        };

        if (win.show() === 1) {

            // If preview objects already exist, they are the final result.
            // Do not place/duplicate a second set on OK.
            if (__previewCache.items && __previewCache.items.length > 0) {
                __previewCache.finalRandOrder = null;
                __previewCache.randOrder = null;
                return;
            }

            var finalPages = parsePageNumbers(editPages.text);
            // Repeat pages/artboards when requested count exceeds source count
            try {
                var srcCount2 = getSourcePageCount(fileA);
                if (srcCount2 > 0) {
                    finalPages = repeatPagesWithinCount(finalPages, srcCount2);
                }
            } catch (e) { }
            var finalCols = parseInt(editCols.text, 10) || 5;
            var finalSpacingUnit = parseFloat(editSpacing.text);
            if (isNaN(finalSpacingUnit) || finalSpacingUnit < 0) finalSpacingUnit = 0;
            var finalMarginUnit = parseFloat(editMargin.text);
            if (isNaN(finalMarginUnit) || finalMarginUnit < 0) finalMarginUnit = 0;

            var finalSpacing = __SC_unitToPt(finalSpacingUnit, rulerUnit.pointsPerUnit);
            var finalMargin = __SC_unitToPt(finalMarginUnit, rulerUnit.pointsPerUnit);

            var finalScalePct = parseFloat(editScale.text);
            if (isNaN(finalScalePct) || finalScalePct <= 0) finalScalePct = 100;

            var finalColShiftUnit = parseFloat(editColShift.text);
            if (isNaN(finalColShiftUnit)) finalColShiftUnit = 0;
            var finalColShiftPt = __SC_unitToPt(finalColShiftUnit, rulerUnit.pointsPerUnit);

            var finalRot = parseFloat(editRotate.text);
            if (isNaN(finalRot)) finalRot = 0;

            // 全体位置（スライダー値は定規単位とみなし pt に変換）
            var finalOffsetXPt = (cbOffsetX.value) ? __SC_unitToPt(sldOffsetX.value, rulerUnit.pointsPerUnit) : 0;
            var finalOffsetYPt = (cbOffsetY.value) ? __SC_unitToPt(sldOffsetY.value, rulerUnit.pointsPerUnit) : 0;

            // 角丸設定
            var finalRoundEnabled = cbRound.value;
            var finalRoundUnit = parseFloat(editRound.text);
            if (isNaN(finalRoundUnit) || finalRoundUnit < 0) finalRoundUnit = 0;
            var finalRoundPt = __SC_unitToPt(finalRoundUnit, rulerUnit.pointsPerUnit);

            var cropMode = getCropModeFromUI();
            var bgFillColor = getBgRGBColorOrDefault();
            var res = placeArtboards(finalPages, finalCols, finalSpacing, finalScalePct, AUTO_FIT_ENABLED, finalMargin, cbColShift.value, finalColShiftPt, cbRotate.value, finalRot, cbBg.value, bgFillColor, cropMode, finalOffsetXPt, finalOffsetYPt, getFlowMode(), cbEvenPlus.value, finalRoundEnabled, finalRoundPt, false);

            // OK時のみ：マージン内側で配置物をマスク（背景は含めない）
            if (cbMask.value && res && res.maskItems && res.maskItems.length > 0) {
                var maskGrp = __SC_applyArtboardMask(doc, res.maskItems, finalMargin);

                // マスク角丸：マスクグループに適用
                if (maskGrp && cbMaskRound.value) {
                    var mrUnit = parseFloat(editMaskRound.text);
                    if (isNaN(mrUnit) || mrUnit < 0) mrUnit = 0;
                    var mrPt = __SC_unitToPt(mrUnit, rulerUnit.pointsPerUnit);
                    if (mrPt > 0) {
                        try { __SC_applyRoundCorners([maskGrp], mrPt); } catch (eMR) { }
                    }
                }
            }
        }

        // ダイアログ終了後に選択解除 / Clear selection after closing dialog
        try { doc.selection = null; } catch (eSel) { }
    }

    main();

})();
