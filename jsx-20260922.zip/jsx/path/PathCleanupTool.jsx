#target illustrator
#targetengine "PathCleanupToolEngine"
app.preferences.setBooleanPreference('ShowExternalJSXWarning', false);

/*

### 概要

選択したパス（グループ・複合パスの中も含む）のアンカーポイントとハンドルを整理します。
削除・変換の内容を選び、アンカー数とハンドル数の増減を確認してから実行できます。

詳細は README を参照してください。
https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/PathCleanupTool.md

note記事も参照してください。
https://note.com/dtp_tranist/n/nd82f59bf63a8

### Overview

Tidies the anchor points and handles of the selected paths, including those inside groups and compound paths.
You choose what to remove or convert and can see how the anchor and handle counts will change before running it.

See the README for details.
https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/PathCleanupTool.md

*/

// =========================================
// 基本情報 / Basic info
// =========================================
var SCRIPT_NAME     = "PathCleanupTool";              /* スクリプト名 / script name */
var SCRIPT_VERSION  = "v1.6.3";                       /* バージョン / version */
var SCRIPT_AUTHOR   = "Masahiro Takano (@swwwitch)";  /* 作者 / author */
var SCRIPT_RELEASED = "2026-03-01";                   /* 最初のリリース日 / first release date */
var SCRIPT_UPDATED  = "2026-09-19";                   /* 更新日 / last updated */

var SCRIPT_README_JA   = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/PathCleanupTool.md"; /* README（日本語） */
var SCRIPT_README_EN   = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/PathCleanupTool.md"; /* README (English) */
var SCRIPT_ARTICLE_URL = "https://note.com/dtp_tranist/n/nd82f59bf63a8"; /* 紹介記事 / article URL */

// Released under the MIT license
// http://opensource.org/licenses/mit-license.php

(function () {

    /* 許容誤差の初期値（ダイアログで調整可能） / Default tolerances (adjustable in dialog) */
    var TOL_ANCHOR_COLLINEAR = 0.02; /* 直線上アンカー削除の許容誤差 / Redundant-anchor removal */
    var TOL_HANDLE_COLLINEAR = 0.01; /* 直線区間ハンドル整理の許容誤差 / Straight-segment handle normalization */
    var TOL_SAMEPOINT = 0.02;        /* 同一点判定の許容誤差 / Coincident-point check */

    // =========================================
    // ローカライズ / Localization
    // =========================================

    /** 現在の UI 言語（"ja" / "en"）を判定して返します。 */
    function getCurrentLang() {
        return ($.locale.indexOf("ja") === 0) ? "ja" : "en";
    }
    var uiLang = getCurrentLang();

    /**
     * 日英ラベル定義（カテゴリ別） / Japanese-English label definitions (by category)
     * getLabel("dialog.title") のようにドット区切りで参照する。短い文言は1行で記述。
     * @type {Object}
     */
    var LABELS = {
        dialog: {
            title: { ja: "パスの最適化", en: "Path Optimization" }
        },
        panel: {
            info:          { ja: "情報", en: "Info" },
            convertPoints: { ja: "アンカーポイントを変換", en: "Convert anchor points" },
            addPoints:     { ja: "アンカーポイントを追加", en: "Add anchor points" },
            pathOps:       { ja: "その他", en: "Other" }
        },
        tab: {
            process: { ja: "削除対象", en: "Removal Targets" },
            other:   { ja: "変換", en: "Transform" }
        },
        checkbox: {
            removeSameAnchors: { ja: "同じ座標のアンカーポイント", en: "Duplicate anchor points" },
            removeAnchors:     { ja: "直線上のアンカーポイント", en: "Collinear anchor points" },
            removeHandles:     { ja: "パスと同じ角度のハンドル", en: "Handles on straight segments" }
        },
        radio: {
            convertSmooth:  { ja: "スムーズポイントに", en: "To smooth points" },
            convertCorner:  { ja: "コーナーポイントに", en: "To corner points" },
            addAnchors:     { ja: "中間に追加", en: "At midpoints" },
            addExtremePoints: { ja: "極点を追加", en: "Add Extreme Points" },
            splitAtAnchors: { ja: "アンカーポイントで分割", en: "Split at anchor points" },
            fillHoles:      { ja: "マド埋め", en: "Fill holes" }
        },
        label: {
            pathCount:   { ja: "パスの数", en: "Paths" },
            anchorCount: { ja: "アンカーポイント数", en: "Anchor points" },
            handleCount: { ja: "ハンドル数", en: "Handles" },
            tolAnchor:   { ja: "許容誤差", en: "Tolerance" },
            tolHandle:   { ja: "許容誤差", en: "Tolerance" }
        },
        button: {
            ok:     { ja: "OK", en: "OK" },
            cancel: { ja: "キャンセル", en: "Cancel" }
        },
        alert: {
            noDocument:    { ja: "ドキュメントが開かれていません。", en: "No document is open." },
            needSelection: { ja: "パスを選択してから実行してください。", en: "Please select paths before running." },
            lostSelection: { ja: "選択していたオブジェクトが見つからないため、処理を中止しました。", en: "The selected objects are no longer available, so processing was cancelled." }
        },
        tooltip: {
            removeSameAnchors: { ja: "連続して同じ座標にあるアンカーポイントを1つに統合します（離れた位置の同座標は対象外）。", en: "Merges consecutive anchors that share the same coordinates (non-adjacent duplicates are ignored)." },
            removeAnchors:     { ja: "前後のアンカーと一直線上にある冗長なアンカーポイントを削除します。", en: "Removes redundant anchors that lie on a straight line between their neighbors." },
            removeHandles:     { ja: "直線とみなせる区間のハンドルをアンカーに戻します（見た目を変えずにハンドルを整理）。", en: "Resets handles on segments that are effectively straight (tidies handles without changing appearance)." },
            tolAnchor:         { ja: "値が大きいほど、より緩く「直線上」と判定して多くのアンカーを削除します（0.01〜3.00）。", en: "Higher values treat more anchors as collinear and remove more of them (0.01–3.00)." },
            tolHandle:         { ja: "値が大きいほど、より緩く「直線」と判定して多くのハンドルを戻します（0.01〜3.00）。", en: "Higher values treat more segments as straight and reset more handles (0.01–3.00)." },
            addAnchors:        { ja: "各セグメントの中間に1点ずつアンカーポイントを追加します。", en: "Adds one anchor at the midpoint of each segment." },
            addExtremePoints:  { ja: "曲線の上下左右の端（水平・垂直の接線位置＝極点）にアンカーポイントを追加します。", en: "Adds anchors at the curve's extrema (points of horizontal/vertical tangency)." },
            splitAtAnchors:    { ja: "各セグメントを独立したオープンパスに分割します（元のパスは削除）。", en: "Splits each segment into a separate open path (the original path is removed)." },
            fillHoles:         { ja: "複合パスを解除して合体し、穴（マド）を埋めます。選択に複合パスが無い場合は使用できません。", en: "Releases the compound path and unites it to fill holes. Unavailable when the selection has no compound path." }
        }
    };

    // =========================================
    // UIレイアウトの共通設定 / Shared UI layout
    // =========================================

    /* ウィンドウ・パネルの余白と間隔 / Window & panel margins and spacing */
    var WINDOW_MARGINS = 16;               /* ウィンドウ外周の余白 / window margin */
    var WINDOW_SPACING = 12;               /* ウィンドウ内の要素間隔 / window spacing */
    var PANEL_MARGINS  = [16, 20, 16, 12]; /* パネル余白 [左,上,右,下] / panel margins */
    var PANEL_SPACING  = 8;                /* パネル内の要素間隔 / panel spacing */

    /**
     * ウィンドウに共通レイアウトを適用します。
     * @param {Window} win - 対象のダイアログウィンドウ。
     * @param {number} [spacing] - 要素間隔（省略時は WINDOW_SPACING）。
     * @returns {void}
     */
    function setupWindow(win, spacing) {
        win.orientation = "column";
        win.alignChildren = "fill";
        win.margins = WINDOW_MARGINS;
        win.spacing = (typeof spacing === "number") ? spacing : WINDOW_SPACING;
    }

    /**
     * パネル（タブを含む）に共通レイアウトを適用します。
     * @param {Panel} panel - 対象のパネル。
     * @param {number} [spacing] - 要素間隔（省略時は PANEL_SPACING）。
     * @returns {void}
     */
    function setupPanel(panel, spacing) {
        panel.orientation = "column";
        panel.alignChildren = ["fill", "top"];
        panel.alignment = "fill";
        panel.margins = PANEL_MARGINS;
        panel.spacing = (typeof spacing === "number") ? spacing : PANEL_SPACING;
    }

    (function () {
        // --- shared settings / helpers ---
        /* 共通設定とヘルパー / Shared settings and helpers */
        /* 許容誤差は冒頭「ユーザー設定 / User Settings」で定義（ダイアログで上書き）
           Tolerances are defined in the "User Settings" section at the top (overridden by the dialog). */

        /**
         * パス情報の集計値。
         * @typedef {Object} InfoCounts
         * @property {number} paths - パス数。
         * @property {number} anchors - アンカーポイント数。
         * @property {number} handles - ハンドル数。
         */

        /**
         * シミュレーション用のパスモデル（DOMを書き換えず増減を予測する軽量表現）。
         * @typedef {Object} PathModel
         * @property {boolean} closed - クローズドパスなら true。
         * @property {Array<PathModelPoint>} pts - アンカー点の配列。
         */

        /**
         * パスモデルの1点。各座標は [x, y] の数値配列。
         * @typedef {Object} PathModelPoint
         * @property {Array<number>} a - アンカー座標。
         * @property {Array<number>} l - 左方向線（leftDirection）座標。
         * @property {Array<number>} r - 右方向線（rightDirection）座標。
         * @property {PointType} t - アンカーの種類（書き戻し時に復元）。
         */

        /**
         * 実処理中の例外を最小限ログ出力します（UI位置の保存・復元系は従来どおり silent）。
         * @param {string} context - エラー発生箇所を示すラベル。
         * @param {Error} e - 捕捉した例外。
         * @returns {void}
         */
        function logProcessError(context, e) {
            try {
                $.writeln("[PathCleanupTool] " + context + ": " + e);
            } catch (ignored) {
                // ignore logging failure
            }
        }

        /** ドキュメントが1つ以上開かれていれば true。 */
        function hasDocument() {
            return app.documents.length > 0;
        }

        /**
         * ネストした LABELS 定義から現在の言語のラベルを取得します。
         * @param {string} keyPath - "dialog.title" のようなドット区切りのキー。
         * @returns {string} 現在の言語のラベル文字列。該当なしの場合はキー文字列。
         */
        function getLabel(keyPath) {
            var parts = String(keyPath).split(".");
            var node = LABELS;
            for (var i = 0; i < parts.length; i++) {
                if (!node) break;
                node = node[parts[i]];
            }
            if (!node) return String(keyPath);
            return node[uiLang] || node.ja || String(keyPath);
        }

        /** ラベル keyPath 末尾にコロンを付けて返します（日本語は全角、英語は半角）。 */
        function labelText(keyPath) {
            return getLabel(keyPath) + (uiLang === 'ja' ? '：' : ': ');
        }

        /**
         * ドキュメント・選択の有無を検証し、選択配列を返します。無ければ警告を表示。
         * @returns {?Array<PageItem>} 選択オブジェクト配列。ドキュメント無し／未選択なら null。
         */
        function getSelectionOrAlert() {
            if (!hasDocument()) {
                alert(getLabel('alert.noDocument'));
                return null;
            }
            var doc = app.activeDocument;
            var currentSelection = doc.selection;
            if (!(currentSelection instanceof Array) || currentSelection.length === 0) {
                alert(getLabel('alert.needSelection'));
                return null;
            }
            return currentSelection;
        }

        /**
         * 3点が一直線上にあるかを、点Bから直線A-Cまでの垂直距離で判定します。
         * @param {Array<number>} pointA - 点A [x, y]。
         * @param {Array<number>} pointB - 点B（直線上にあるか判定する点） [x, y]。
         * @param {Array<number>} pointC - 点C [x, y]。
         * @param {number} [tolerance] - 距離の許容誤差（pt、省略時は TOL_ANCHOR_COLLINEAR）。
         * @returns {boolean} 一直線上とみなせれば true。
         */
        function isCollinear(pointA, pointB, pointC, tolerance) {
            /* 0 が既定値に化けないよう != null で判定する */
            tolerance = (tolerance != null) ? tolerance : TOL_ANCHOR_COLLINEAR;
            /* 外積をそのまま比較するとセグメント長に比例して感度が変わり、
               ハンドル側の許容誤差（垂直距離）と意味がずれるため距離で揃える */
            return isPointOnLineByDistance(pointA, pointC, pointB, tolerance);
        }

        /**
         * 2点がほぼ同一座標かを判定します（マンハッタン距離で比較）。
         * @param {Array<number>} pointA - 点A [x, y]。
         * @param {Array<number>} pointB - 点B [x, y]。
         * @param {number} [tolerance] - 許容誤差（省略時は TOL_SAMEPOINT）。
         * @returns {boolean} 同一とみなせれば true。
         */
        function samePoint(pointA, pointB, tolerance) {
            /* 0 が既定値に化けないよう != null で判定する */
            tolerance = (tolerance != null) ? tolerance : TOL_SAMEPOINT;
            return (Math.abs(pointA[0] - pointB[0]) + Math.abs(pointA[1] - pointB[1])) < tolerance;
        }

        /**
         * 点が線分の延長を含む直線上にあるかを、点から直線までの垂直距離で判定します。
         * 線分が極端に短い場合は samePoint にフォールバックします。
         * @param {Array<number>} lineStart - 直線の始点 [x, y]。
         * @param {Array<number>} lineEnd - 直線の終点 [x, y]。
         * @param {Array<number>} testPoint - 判定する点 [x, y]。
         * @param {number} [tolerance] - 距離の許容誤差（pt、省略時は TOL_HANDLE_COLLINEAR）。
         * @returns {boolean} 直線上とみなせれば true。
         */
        function isPointOnLineByDistance(lineStart, lineEnd, testPoint, tolerance) {
            tolerance = (tolerance != null) ? tolerance : TOL_HANDLE_COLLINEAR;

            var abx = lineEnd[0] - lineStart[0];
            var aby = lineEnd[1] - lineStart[1];
            var len = Math.sqrt(abx * abx + aby * aby);

            if (len < 1e-9) {
                // a と b がほぼ同一点
                return samePoint(lineStart, testPoint, Math.max(TOL_SAMEPOINT, tolerance));
            }

            // cross product magnitude / |AB| = perpendicular distance
            var apx = testPoint[0] - lineStart[0];
            var apy = testPoint[1] - lineStart[1];
            var area2 = abx * apy - aby * apx; // signed
            var dist = Math.abs(area2) / len;
            return dist <= tolerance;
        }

        // --- dialog position persistence (session only) ---
        // Store ONLY window location (x,y). Bounds can include size and may restore too small, making UI appear blank.
        // Stored in the target engine's global object; reset when Illustrator quits.
        var DLG_LOC_KEY = "__PathCleanupTool_DialogLocation__";

        /**
         * 保存済みのダイアログ表示位置を読み込みます（セッション内のみ）。
         * @returns {?Array<number>} [x, y] 位置。未保存・不正なら null。
         */
        function loadDialogLocation() {
            try {
                var savedLocation = $.global[DLG_LOC_KEY];
                if (!savedLocation || savedLocation.length !== 2) return null;
                return [Number(savedLocation[0]), Number(savedLocation[1])];
            } catch (e) {
                return null;
            }
        }

        /**
         * ダイアログの表示位置を保存します（セッション内のみ）。
         * @param {Window} dlg - 対象のダイアログウィンドウ。
         * @returns {void}
         */
        function saveDialogLocation(dlg) {
            if (!dlg) return;
            try {
                var dialogLocation = dlg.location; // [x,y]
                if (!dialogLocation || dialogLocation.length !== 2) return;
                $.global[DLG_LOC_KEY] = [Number(dialogLocation[0]), Number(dialogLocation[1])];
            } catch (e) {
                // ignore
            }
        }

        /**
         * 保存済み位置があればダイアログに復元します。
         * @param {Window} dlg - 対象のダイアログウィンドウ。
         * @returns {void}
         */
        function tryRestoreDialogLocation(dlg) {
            var savedLocation = loadDialogLocation();
            if (!savedLocation) return;
            try {
                dlg.location = savedLocation;
            } catch (e) {
                // ignore
            }
        }

        /**
         * オブジェクトがロック／非表示か（親・レイヤーを遡って）を判定します。
         * @param {PageItem} item - 判定対象のオブジェクト。
         * @returns {boolean} ロックまたは非表示なら true。
         */
        function isSkippableItem(item) {
            var currentItem = item;
            while (currentItem) {
                try {
                    // PageItem / GroupItem / PathItem etc.
                    if (currentItem.locked === true) return true;
                    if (currentItem.hidden === true) return true;

                    // Layer
                    if (currentItem.typename === "Layer") {
                        if (currentItem.locked === true) return true;
                        if (currentItem.visible === false) return true;
                    }

                    // If the item has a layer reference, also respect it
                    if (currentItem.layer) {
                        try {
                            if (currentItem.layer.locked === true) return true;
                            if (currentItem.layer.visible === false) return true;
                        } catch (e) { }
                    }
                } catch (e) {
                    // ignore property access errors
                }

                // Walk up
                try {
                    currentItem = currentItem.parent;
                } catch (e) {
                    break;
                }

                // Stop when reaching document-like root
                if (!currentItem || currentItem.typename === "Document") break;
            }
            return false;
        }

        /**
         * 選択オブジェクトから PathItem を再帰的に収集します（グループ／複合パスを展開）。
         * @param {PageItem} item - 走査対象のオブジェクト。
         * @param {Array<PathItem>} pathItems - 収集先の配列（破壊的に追加）。
         * @returns {void}
         */
        function collectPathItemsFromAny(item, pathItems) {
            if (!item) return;
            if (isSkippableItem(item)) return;

            try {
                // Direct PathItem
                if (item.typename === "PathItem") {
                    pathItems.push(item);
                    return;
                }

                // CompoundPathItem contains pathItems
                if (item.typename === "CompoundPathItem") {
                    for (var i = 0; i < item.pathItems.length; i++) {
                        if (!isSkippableItem(item.pathItems[i])) pathItems.push(item.pathItems[i]);
                    }
                    return;
                }

                // GroupItem (including clipped groups)
                if (item.typename === "GroupItem") {
                    for (var g = 0; g < item.pageItems.length; g++) {
                        collectPathItemsFromAny(item.pageItems[g], pathItems);
                    }
                    return;
                }

                // Other container types we may want to traverse
                if (item.pageItems && item.pageItems.length) {
                    for (var p = 0; p < item.pageItems.length; p++) {
                        collectPathItemsFromAny(item.pageItems[p], pathItems);
                    }
                }
            } catch (e) {
                logProcessError("collectPathItemsFromAny", e);
            }
        }

        /**
         * 選択配列から処理対象の PathItem 一覧を収集して返します。
         * 収集時に isSkippableItem() でロック／非表示を除外済みのため、
         * targets を受け取る各関数（*OnTargets / *ForTargets）は再判定しない。
         * @param {Array<PageItem>} selection - 選択オブジェクト配列。
         * @returns {Array<PathItem>} ロック／非表示を除外した対象 PathItem 配列。
         */
        function getTargetPathItemsFromSelection(selection) {
            var pathItems = [];
            for (var i = 0; i < selection.length; i++) {
                collectPathItemsFromAny(selection[i], pathItems);
            }
            return pathItems;
        }

        /**
         * オブジェクト（およびグループ内）に、マド（穴）を持つ複合パスが含まれるかを再帰判定します。
         * サブパスが2つ以上の CompoundPathItem を「マドあり」とみなします。ロック／非表示は対象外。
         * @param {PageItem} item - 判定対象のオブジェクト。
         * @returns {boolean} マドを持つ複合パスがあれば true。
         */
        function itemHasHoles(item) {
            if (!item || isSkippableItem(item)) return false;
            try {
                if (item.typename === 'CompoundPathItem') {
                    return item.pathItems.length >= 2;
                }
                if (item.typename === 'GroupItem') {
                    for (var i = 0; i < item.pageItems.length; i++) {
                        if (itemHasHoles(item.pageItems[i])) return true;
                    }
                }
            } catch (e) {
                logProcessError('itemHasHoles', e);
            }
            return false;
        }

        /**
         * 選択内にマド（穴）を持つ複合パスが1つでもあるかを判定します（マド埋めの有効判定に使用）。
         * @param {Array<PageItem>} selection - 選択オブジェクト配列。
         * @returns {boolean} マドを持つ複合パスがあれば true。
         */
        function selectionHasHoles(selection) {
            if (!selection || !selection.length) return false;
            for (var i = 0; i < selection.length; i++) {
                if (itemHasHoles(selection[i])) return true;
            }
            return false;
        }

        /**
         * 指定 targets からパス数・アンカー数・ハンドル数を集計します。
         * @param {Array<PathItem>} targets - 対象の PathItem 配列。
         * @returns {InfoCounts} 集計結果。
         */
        function getInfoCountsFromTargets(targets) {
            var info = { paths: 0, anchors: 0, handles: 0 };
            if (!targets || !targets.length) return info;

            for (var i = 0; i < targets.length; i++) {
                var item = targets[i];
                if (!item) continue;
                info.paths++;

                var pts = item.pathPoints;
                var n = pts.length;
                info.anchors += n;

                for (var k = 0; k < n; k++) {
                    var pt = pts[k];
                    if (!samePoint(pt.leftDirection, pt.anchor, TOL_SAMEPOINT)) info.handles++;
                    if (!samePoint(pt.rightDirection, pt.anchor, TOL_SAMEPOINT)) info.handles++;
                }
            }

            return info;
        }

        // =========================================
        // パスモデル / Path model
        // =========================================
        /* 情報パネルの予測と実処理は、どちらもこのモデル関数を通す。
           アルゴリズムをここ1箇所に集約し、実処理は結果を applyModelToPath() で書き戻す。
           Both the preview and the actual processing go through these model functions. */

        /** PathPoint pt をモデル点 PathModelPoint（{a, l, r, t}）に複製します。 */
        function clonePointModel(pt) {
            return {
                a: [pt.anchor[0], pt.anchor[1]],
                l: [pt.leftDirection[0], pt.leftDirection[1]],
                r: [pt.rightDirection[0], pt.rightDirection[1]],
                t: pt.pointType
            };
        }

        /**
         * PathItem を編集可能なパスモデルに複製します。
         * @param {PathItem} item - 複製元のパス。
         * @returns {PathModel} 複製したパスモデル。
         */
        function clonePathModel(item) {
            var pts = item.pathPoints;
            var out = [];
            for (var i = 0; i < pts.length; i++) {
                out.push(clonePointModel(pts[i]));
            }
            return {
                closed: !!item.closed,
                pts: out
            };
        }

        /** 2つのモデル座標 a, b がほぼ同一（TOL_SAMEPOINT 基準）なら true。 */
        function samePointModel(a, b) {
            return samePoint(a, b, TOL_SAMEPOINT);
        }

        /** モデル点 p にハンドルが無い（直線的：左右ともアンカーと一致）なら true。 */
        function isStraightPointModel(p) {
            return samePointModel(p.a, p.l) && samePointModel(p.a, p.r);
        }

        /**
         * セグメント (p0 → p1) が見た目として直線かを判定します。
         * 両端アンカーを結ぶ直線に p0 右ハンドル・p1 左ハンドルが近ければ直線とみなす。
         * @param {PathModelPoint} p0 - 始点モデル点。
         * @param {PathModelPoint} p1 - 終点モデル点。
         * @param {number} [tolerance] - 距離の許容誤差（pt、省略時は TOL_HANDLE_COLLINEAR）。
         * @returns {boolean} 直線とみなせれば true。
         */
        function isStraightSegmentModel(p0, p1, tolerance) {
            /* 0 が既定値に化けないよう != null で判定する */
            tolerance = (tolerance != null) ? tolerance : TOL_HANDLE_COLLINEAR;
            return isPointOnLineByDistance(p0.a, p1.a, p0.r, tolerance) &&
                isPointOnLineByDistance(p0.a, p1.a, p1.l, tolerance);
        }

        /**
         * 同一座標のアンカーポイント（重複点）を削除します。
         * 連続して同座標のアンカーのみ対象（離れた位置の同座標は対象外）。オープンパスの端点は削除しない。
         * 削除する点の右方向線は残す点へ引き継ぎ、見た目が変わらないようにする。
         * @param {PathModel} pathM - 対象のパスモデル（破壊的に更新）。
         * @returns {number} 削除したアンカー数。
         */
        function removeDuplicateAnchorsModel(pathM) {
            var removed = 0;
            var pts = pathM.pts;
            var isClosed = pathM.closed;
            var n = pts.length;
            if (n < 2) return 0;

            /* 削除でインデックスがずれるのを防ぐため、後ろから走査する
               オープンパスは端点を除外、クローズドパスは全点が対象（最低2点は残す） */
            var start = isClosed ? (n - 1) : (n - 2);
            var end = isClosed ? 0 : 1;

            for (var i = start; i >= end; i--) {
                var curLen = pts.length;
                if (curLen <= 2) break;

                if (i > curLen - 1) i = curLen - 1;
                if (!isClosed && (i <= 0 || i >= curLen - 1)) continue;

                var prevIndex = isClosed ? ((i - 1 + curLen) % curLen) : (i - 1);
                if (prevIndex < 0 || prevIndex > curLen - 1) continue;

                if (samePointModel(pts[prevIndex].a, pts[i].a)) {
                    /* 削除する点が「出ていく側」のハンドルを持っているため、残す点へ引き継ぐ。
                       引き継がないと重複解消のたびに後続セグメントの曲線が直線に潰れる */
                    pts[prevIndex].r = [pts[i].r[0], pts[i].r[1]];
                    /* 入り側と出側で別々のハンドルを持つ点はスムーズでは表現できない */
                    pts[prevIndex].t = PointType.CORNER;
                    pts.splice(i, 1);
                    removed++;
                }
            }

            return removed;
        }

        /**
         * 直線上の冗長なアンカーポイントを削除します。
         * 対象は「その点自身にハンドルが無い」「前後のセグメントがどちらも直線」
         * 「前後アンカーと一直線上にある」の3条件を満たす点のみ。オープンパスの端点は削除しない。
         * @param {PathModel} pathM - 対象のパスモデル（破壊的に更新）。
         * @returns {number} 削除したアンカー数。
         */
        function removeRedundantAnchorsModel(pathM) {
            var removed = 0;
            var pts = pathM.pts;
            var isClosed = pathM.closed;

            if (pts.length < 3) return 0;

            /* オープンパスは端点を削除しない。削除でインデックスがずれるため後ろから走査する */
            var startIndex = isClosed ? (pts.length - 1) : (pts.length - 2);
            var endIndex = isClosed ? 0 : 1;

            for (var i = startIndex; i >= endIndex; i--) {
                var currentLen = pts.length;
                if (currentLen < 3) break;

                // 削除でインデックスが範囲外になった場合に備えて補正
                if (i > currentLen - 1) i = currentLen - 1;
                if (i < endIndex) break;

                var pA = pts[(i - 1 + currentLen) % currentLen];
                var pB = pts[i];
                var pC = pts[(i + 1) % currentLen];

                /* B自身にハンドルが無いだけでは足りない。pA の右ハンドル／pC の左ハンドルが
                   線から外れていると前後のセグメントは曲線なので、B を消すと形が変わる。
                   判定はアンカー側の許容誤差で統一する（ハンドル側スライダーの影響を受けない） */
                if (isStraightPointModel(pB) &&
                    isStraightSegmentModel(pA, pB, TOL_ANCHOR_COLLINEAR) &&
                    isStraightSegmentModel(pB, pC, TOL_ANCHOR_COLLINEAR) &&
                    isCollinear(pA.a, pB.a, pC.a, TOL_ANCHOR_COLLINEAR)) {
                    pts.splice(i, 1);
                    removed++;
                }
            }

            return removed;
        }

        /**
         * 直線になっているベジェ区間のハンドルをアンカーに戻します。
         * オープンパスの最初のセグメントの始点側／最後のセグメントの終点側ハンドルは触らない。
         * @param {PathModel} pathM - 対象のパスモデル（破壊的に更新）。
         * @returns {number} リセットしたハンドル数（左右それぞれ1カウント）。
         */
        function removeRedundantHandlesModel(pathM) {
            var changed = 0;
            var pts = pathM.pts;
            var len = pts.length;
            if (len < 2) return 0;

            var isClosed = pathM.closed;
            var segCount = isClosed ? len : (len - 1);

            for (var i = 0; i < segCount; i++) {
                var p0 = pts[i];
                var p1 = pts[(i + 1) % len];

                if (!isStraightSegmentModel(p0, p1)) continue;

                // オープンパス端点のハンドルは触らない / Do not modify endpoint handles for open paths
                var isOpen = !isClosed;
                var isFirstSeg = isOpen && (i === 0);
                var isLastSeg = isOpen && (i === (segCount - 1));

                /* 片側だけハンドルが無い点はスムーズでは表現できないため、コーナーに落とす
                   （SMOOTH のまま書き戻すと Illustrator 側でハンドルを戻される場合がある） */
                if (!isFirstSeg && !samePointModel(p0.r, p0.a)) {
                    p0.r = [p0.a[0], p0.a[1]];
                    p0.t = PointType.CORNER;
                    changed++;
                }

                if (!isLastSeg && !samePointModel(p1.l, p1.a)) {
                    p1.l = [p1.a[0], p1.a[1]];
                    p1.t = PointType.CORNER;
                    changed++;
                }
            }

            return changed;
        }

        /**
         * モデル上のハンドル数を数えます（左右それぞれ1カウント）。
         * @param {PathModel} pathM - 対象のパスモデル。
         * @returns {number} ハンドル数。
         */
        function countHandlesModel(pathM) {
            var c = 0;
            var pts = pathM.pts;
            for (var i = 0; i < pts.length; i++) {
                var p = pts[i];
                if (!samePointModel(p.l, p.a)) c++;
                if (!samePointModel(p.r, p.a)) c++;
            }
            return c;
        }

        /**
         * モデルにクリーンアップを適用します。
         * 実行順は 重複→冗長→ハンドル→冗長→重複。ハンドルを直線区間から外すと
         * 「ハンドルがあるから消せない」と判定されていたアンカーが新たに対象になるため折り返す。
         * @param {PathModel} pathM - 対象のパスモデル（破壊的に更新）。
         * @param {boolean} doSameAnchors - 重複アンカー削除を含める場合は true。
         * @param {boolean} doAnchors - 直線上の冗長アンカー削除を含める場合は true。
         * @param {boolean} doHandles - 直線区間のハンドル削除を含める場合は true。
         * @returns {number} 削除・リセットした総数（0 なら変化なし）。
         */
        function runCleanupOnModel(pathM, doSameAnchors, doAnchors, doHandles) {
            var changed = 0;
            if (doSameAnchors) changed += removeDuplicateAnchorsModel(pathM);
            if (doAnchors) changed += removeRedundantAnchorsModel(pathM);
            if (doHandles) changed += removeRedundantHandlesModel(pathM);
            if (doAnchors) changed += removeRedundantAnchorsModel(pathM);
            if (doSameAnchors) changed += removeDuplicateAnchorsModel(pathM);
            return changed;
        }

        /**
         * モデルの内容を PathItem へ書き戻します。
         * 余った点を末尾から削除したうえで全点を上書きします。
         * パスを作り直さず同一 PathItem を保持するため、アピアランスは維持されます。
         * @param {PathItem} item - 書き戻し先のパス。
         * @param {PathModel} pathM - 書き戻すパスモデル。
         * @returns {void}
         */
        function applyModelToPath(item, pathM) {
            var modelPoints = pathM.pts;
            if (modelPoints.length < 2) return;

            try {
                var pts = item.pathPoints;
                while (pts.length > modelPoints.length) {
                    pts[pts.length - 1].remove();
                }
                for (var i = 0; i < modelPoints.length; i++) {
                    var pt = pts[i];
                    var m = modelPoints[i];
                    pt.anchor = m.a;
                    pt.pointType = m.t;
                    pt.leftDirection = m.l;
                    pt.rightDirection = m.r;
                }
            } catch (e) {
                logProcessError('applyModelToPath', e);
            }
        }

        /**
         * 指定 targets にクリーンアップを実行します（モデル上で処理してから書き戻す）。
         * @param {Array<PathItem>} targets - 対象の PathItem 配列。
         * @param {boolean} doSameAnchors - 重複アンカー削除を行うか。
         * @param {boolean} doAnchors - 直線上の冗長アンカー削除を行うか。
         * @param {boolean} doHandles - 直線区間のハンドル削除を行うか。
         * @returns {number} 変化のあったパス数。
         */
        function runCleanupOnTargets(targets, doSameAnchors, doAnchors, doHandles) {
            if (!targets || !targets.length) return 0;

            var changedPaths = 0;
            for (var i = 0; i < targets.length; i++) {
                var item = targets[i];
                if (!item) continue;

                try {
                    var pathModel = clonePathModel(item);
                    if (runCleanupOnModel(pathModel, doSameAnchors, doAnchors, doHandles) === 0) continue;
                    applyModelToPath(item, pathModel);
                    changedPaths++;
                } catch (e) {
                    logProcessError('runCleanupOnTargets', e);
                }
            }

            return changedPaths;
        }

        /**
         * クリーンアップ実行後のアンカー数・ハンドル数を予測します。
         * DOM は書き換えず、複製したモデル上で実処理とまったく同じ関数・同じ実行順を通します。
         * @param {Array<PathItem>} targets - 対象の PathItem 配列。
         * @param {boolean} doSameAnchors - 重複アンカー削除を含める場合は true。
         * @param {boolean} doAnchors - 直線上の冗長アンカー削除を含める場合は true。
         * @param {boolean} doHandles - 直線区間のハンドル削除を含める場合は true。
         * @param {InfoCounts} [infoNow] - 実行前の集計値（省略時はここで集計）。ダイアログ表示中は変化しないため使い回す。
         * @returns {{paths: number, anchorsNow: number, anchorsAfter: number, handlesNow: number, handlesAfter: number}} 予測結果。
         */
        function getPredictedInfoCountsForTargets(targets, doSameAnchors, doAnchors, doHandles, infoNow) {
            if (!infoNow) infoNow = getInfoCountsFromTargets(targets);

            var anchorsAfterTotal = 0;
            var handlesAfterTotal = 0;

            for (var t = 0; t < (targets ? targets.length : 0); t++) {
                var item = targets[t];
                if (!item) continue;

                var pathModel = clonePathModel(item);
                runCleanupOnModel(pathModel, doSameAnchors, doAnchors, doHandles);

                anchorsAfterTotal += pathModel.pts.length;
                handlesAfterTotal += countHandlesModel(pathModel);
            }

            return {
                paths: infoNow.paths,
                anchorsNow: infoNow.anchors,
                anchorsAfter: anchorsAfterTotal,
                handlesNow: infoNow.handles,
                handlesAfter: handlesAfterTotal
            };
        }

        /**
         * 「変換」タブ（変換・分割）の予測情報を取得します。
         * corner=全ハンドル削除／smooth=全アンカーに左右ハンドル付与／add=各セグメントに1点追加／
         * extreme=各曲線セグメントの極点数を実測して加算／split=各セグメントを独立パス化／
         * fillHoles=結果を事前算出できないため未確定（"-"）。
         * @param {Array<PathItem>} targets - 対象の PathItem 配列。
         * @param {string} mode - 変換モード（'smooth' | 'corner' | 'add' | 'extreme' | 'split' | 'fillHoles'）。
         * @param {InfoCounts} [infoNow] - 実行前の集計値（省略時はここで集計）。ダイアログ表示中は変化しないため使い回す。
         * @returns {{paths: number, pathsAfter: (number|string), anchorsNow: number, anchorsAfter: (number|string), handlesNow: number, handlesAfter: (number|string)}} 予測結果。
         */
        function getPredictedInfoForConvert(targets, mode, infoNow) {
            if (!infoNow) infoNow = getInfoCountsFromTargets(targets);
            var pathsAfter = infoNow.paths;
            var anchorsAfter = infoNow.anchors;
            var handlesAfter = infoNow.handles;

            if (!targets || !targets.length) {
                return { paths: 0, pathsAfter: 0, anchorsNow: 0, anchorsAfter: 0, handlesNow: 0, handlesAfter: 0 };
            }

            if (mode === 'corner') {
                // 全ハンドル削除
                handlesAfter = 0;
            } else if (mode === 'smooth') {
                /* 全アンカーに左右ハンドルが付く。ただしオープンパスは端点の外側
                   （始点の左・終点の右）にハンドルが付かないため、1本につき2つ引く */
                var openPaths = 0;
                for (var s = 0; s < targets.length; s++) {
                    if (targets[s] && !targets[s].closed) openPaths++;
                }
                handlesAfter = infoNow.anchors * 2 - openPaths * 2;
            } else if (mode === 'add') {
                // 各セグメントに1点追加
                var totalSegs = 0;
                for (var i = 0; i < targets.length; i++) {
                    var item = targets[i];
                    if (!item) continue;
                    var n = item.pathPoints.length;
                    totalSegs += item.closed ? n : (n - 1);
                }
                anchorsAfter = infoNow.anchors + totalSegs;
                handlesAfter = '-';
            } else if (mode === 'split') {
                // 各セグメントが独立パスに
                var totalSegs2 = 0;
                for (var j = 0; j < targets.length; j++) {
                    var item2 = targets[j];
                    if (!item2) continue;
                    var n2 = item2.pathPoints.length;
                    totalSegs2 += item2.closed ? n2 : (n2 - 1);
                }
                pathsAfter = totalSegs2;
                anchorsAfter = totalSegs2 * 2;
                handlesAfter = '-';
            } else if (mode === 'extreme') {
                // 各曲線セグメントの極点数を実測して加算
                anchorsAfter = infoNow.anchors + countExtremaForTargets(targets);
                handlesAfter = '-';
            } else if (mode === 'fillHoles') {
                // パスファインダー結果は事前に正確に出せないため未確定
                pathsAfter = '-';
                anchorsAfter = '-';
                handlesAfter = '-';
            }

            return {
                paths: infoNow.paths,
                pathsAfter: pathsAfter,
                anchorsNow: infoNow.anchors,
                anchorsAfter: anchorsAfter,
                handlesNow: infoNow.handles,
                handlesAfter: handlesAfter
            };
        }

        // --- UI ---
        /**
         * showDialog() の戻り値。
         * @typedef {Object} DialogResult
         * @property {boolean} ok - OK で閉じたら true。
         * @property {string} activeMode - 実行タブ（'process' | 'other'）。
         * @property {boolean} doRemoveSameAnchors - 重複アンカー削除を行うか。
         * @property {boolean} doRemoveAnchors - 直線上の冗長アンカー削除を行うか。
         * @property {boolean} doRemoveHandles - 直線区間のハンドル削除を行うか。
         * @property {string} convertMode - 変換モード（'smooth' | 'corner' | 'add' | 'extreme' | 'split' | 'fillHoles'）。
         */

        /**
         * メインダイアログを表示し、ユーザーの選択結果を返します。
         * @param {Array<PathItem>} frozenTargets - ダイアログ表示時点で固定した対象パス（予測表示に使用）。
         * @param {boolean} hasHoles - 選択内にマド（穴）を持つ複合パスがあるか（false のとき「マド埋め」を無効化）。
         * @returns {DialogResult} 実行内容を表す結果オブジェクト。
         */
        function showDialog(frozenTargets, hasHoles) {
            /* 実行前の集計はダイアログ表示中に変化しないため、1回だけ数えて使い回す
               （スライダー操作のたびに全パスを数え直さないようにするため） */
            var frozenInfoNow = getInfoCountsFromTargets(frozenTargets);

            /**
             * 現在アクティブなタブに対応する実行モードを返します。
             * @returns {string} 'other'（「変換」タブ）または 'process'（「削除対象」タブ）。
             */
            function getActiveMode() {
                return (tabbedPanel.selection === tabOther) ? 'other' : 'process';
            }
            var dlg = new Window('dialog', getLabel('dialog.title') + ' ' + SCRIPT_VERSION);
            setupWindow(dlg);

            tryRestoreDialogLocation(dlg);
            dlg.onClose = function () {
                saveDialogLocation(dlg);
            };

            var infoPanel = dlg.add('panel', undefined, getLabel('panel.info'));
            setupPanel(infoPanel);

            /**
             * 情報パネルに「ラベル：値」の行を追加します。
             * @param {string} labelKey - ラベルの LABELS ドット区切りキー。
             * @returns {StaticText} 値表示用の StaticText（後で text を更新する）。
             */
            function addInfoRow(labelKey) {
                var infoRow = infoPanel.add('group');
                infoRow.orientation = 'row';
                infoRow.alignChildren = ['left', 'center'];

                var rowLabel = infoRow.add('statictext', undefined, labelText(labelKey));
                rowLabel.characters = 13;
                rowLabel.justify = 'right';

                /* characters は最小幅なので小さく取り、「128 → 96」形式は fill で
                   行の余りを使って表示する（ここでウィンドウ幅を広げないため） */
                var rowValue = infoRow.add('statictext', undefined, '0');
                rowValue.characters = 4;
                rowValue.alignment = ['fill', 'center'];
                return rowValue;
            }

            /**
             * 許容誤差の入力文字列を数値に変換します（角括弧・全角括弧・空白を除去）。
             * @param {string} text - 入力文字列。
             * @returns {number} 変換した数値。空文字なら NaN。
             */
            function parseToleranceText(text) {
                if (!text) return NaN;
                // accept formats like "[0.01]", "0.01", and full-width brackets
                text = String(text).replace(/\[/g, '').replace(/\]/g, '').replace(/［/g, '').replace(/］/g, '').replace(/\s/g, '');
                return parseFloat(text);
            }

            var pathCountValue = addInfoRow('label.pathCount');
            var anchorCountValue = addInfoRow('label.anchorCount');
            var handleCountValue = addInfoRow('label.handleCount');

            /** 「beforeValue → afterValue」の矢印連結文字列を生成します。 */
            function formatArrow(beforeValue, afterValue) {
                return String(beforeValue) + " → " + String(afterValue);
            }

            /**
             * 「削除対象」タブの現在のチェック状態で情報パネルの予測値を更新します。
             * @returns {void}
             */
            function refreshInfoPreview() {
                var predictedInfo = getPredictedInfoCountsForTargets(
                    frozenTargets,
                    removeSameAnchorsCheckbox.value,
                    removeAnchorsCheckbox.value,
                    removeHandlesCheckbox.value,
                    frozenInfoNow);
                pathCountValue.text = String(predictedInfo.paths);
                anchorCountValue.text = formatArrow(predictedInfo.anchorsNow, predictedInfo.anchorsAfter);
                handleCountValue.text = formatArrow(predictedInfo.handlesNow, predictedInfo.handlesAfter);
                updateOkEnabled();
            }

            /**
             * 「変換」タブの予測値で情報パネルを更新します。
             * @param {string} mode - 変換モード（'smooth' | 'corner' | 'add' | 'extreme' | 'split' | 'fillHoles'）。
             * @returns {void}
             */
            function refreshInfoForConvert(mode) {
                var predictedInfo = getPredictedInfoForConvert(frozenTargets, mode, frozenInfoNow);
                pathCountValue.text = formatArrow(predictedInfo.paths, predictedInfo.pathsAfter);
                anchorCountValue.text = formatArrow(predictedInfo.anchorsNow, predictedInfo.anchorsAfter);
                handleCountValue.text = formatArrow(predictedInfo.handlesNow, predictedInfo.handlesAfter);
                updateOkEnabled();
            }

            /**
             * 実行できる内容が選ばれているかに応じて OK ボタンの有効／無効を切り替えます。
             * 「削除対象」タブでチェックが1つも無いと実行しても何も起きないため無効にします。
             * @returns {void}
             */
            function updateOkEnabled() {
                /* ボタン生成前にも予測表示が走るため、その時点では何もしない */
                if (!btnOK) return;
                if (tabbedPanel.selection === tabOther) {
                    btnOK.enabled = true;
                    return;
                }
                btnOK.enabled = removeSameAnchorsCheckbox.value ||
                    removeAnchorsCheckbox.value ||
                    removeHandlesCheckbox.value;
            }

            /**
             * 「変換」タブで選択中のラジオボタンから変換モードを返します。
             * どれも選択されていない場合は、無効化されることのない 'smooth' に倒す
             * （'fillHoles' は選択内容によってディム表示になるためフォールバックに使わない）。
             * @returns {string} 'smooth' | 'corner' | 'add' | 'extreme' | 'split' | 'fillHoles'。
             */
            function getSelectedConvertMode() {
                if (cornerRadio.value) return 'corner';
                if (addAnchorsRadio.value) return 'add';
                if (extremePointsRadio.value) return 'extreme';
                if (splitRadio.value) return 'split';
                if (fillHolesRadio.value) return 'fillHoles';
                return 'smooth';
            }

            /**
             * アクティブなタブに応じて情報パネルの予測表示を切り替えます。
             * @returns {void}
             */
            function refreshByActiveTab() {
                if (tabbedPanel.selection === tabOther) {
                    refreshInfoForConvert(getSelectedConvertMode());
                } else {
                    refreshInfoPreview();
                }
            }

            var tabbedPanel = dlg.add('tabbedpanel');
            tabbedPanel.alignChildren = ['fill', 'top'];

            // --- Tab 1: 削除対象 ---
            var tabProcess = tabbedPanel.add('tab', undefined, getLabel('tab.process'));
            setupPanel(tabProcess);
            /* タブ内の右余白を詰める（PANEL_MARGINS の右16→6）。サブプロパティ代入は反映されないため配列で上書き */
            tabProcess.margins = [16, 20, 6, 12];

            var removeSameAnchorsCheckbox = tabProcess.add('checkbox', undefined, getLabel('checkbox.removeSameAnchors'));
            removeSameAnchorsCheckbox.helpTip = getLabel('tooltip.removeSameAnchors');
            removeSameAnchorsCheckbox.value = true;

            /* 許容誤差のUIはアンカー用とハンドル用で中身が同一のため、1つの生成関数にまとめる
               The anchor and handle tolerance blocks are identical, so one builder creates both. */
            var TOL_MIN = 0.01;
            var TOL_MAX = 3;

            /* アンカー数が多いと onChanging 1回ごとの全パス再計算が重くなるため、
               しきい値を超える選択ではスライダーを離したとき（onChange）だけ予測を更新する */
            var HEAVY_ANCHOR_LIMIT = 2000;
            var isHeavySelection = frozenInfoNow.anchors > HEAVY_ANCHOR_LIMIT;

            /**
             * 許容誤差を有効範囲（0.01〜3.00、小数2桁）に丸めます。
             * @param {number} toleranceValue - 入力値。
             * @param {number} fallbackValue - NaN のときに返す値。
             * @returns {number} 丸めた許容誤差。
             */
            function clampTolerance(toleranceValue, fallbackValue) {
                if (isNaN(toleranceValue)) return fallbackValue;
                if (toleranceValue < TOL_MIN) toleranceValue = TOL_MIN;
                if (toleranceValue > TOL_MAX) toleranceValue = TOL_MAX;
                return Math.round(toleranceValue * 100) / 100;
            }

            /**
             * 数値入力欄で↑↓キーによる増減を有効にします（Shift併用で0.1刻み）。
             * @param {EditText} inputField - 対象の入力欄。
             * @param {function(number):void} onValueChanged - 増減後の値を受け取るコールバック。
             * @returns {void}
             */
            function changeValueByArrowKey(inputField, onValueChanged) {
                inputField.addEventListener('keydown', function (event) {
                    if (event.keyName != 'Up' && event.keyName != 'Down') return;
                    var currentValue = parseToleranceText(inputField.text);
                    if (isNaN(currentValue)) return;

                    /* 修飾キーは event から読む（keyboardState は macOS で誤報あり）
                       Read the modifier from event (keyboardState misreports on macOS) */
                    var shiftPressed = event.shiftKey;
                    if (shiftPressed === undefined) {
                        shiftPressed = ScriptUI.environment.keyboardState.shiftKey;
                    }

                    var stepDirection = (event.keyName == 'Up') ? 1 : -1;
                    event.preventDefault();
                    onValueChanged(currentValue + stepDirection * (shiftPressed ? 0.1 : 0.01));
                });
            }

            /**
             * 「チェックボックス＋許容誤差（ラベル・入力欄・スライダー）」を1組生成します。
             * @param {Object} config - 生成設定。
             * @param {string} config.checkboxKey - チェックボックスの LABELS キー。
             * @param {string} config.checkboxTooltipKey - チェックボックスの tooltip の LABELS キー。
             * @param {string} config.labelKey - 許容誤差ラベルの LABELS キー。
             * @param {string} config.tooltipKey - 許容誤差まわりの tooltip の LABELS キー。
             * @param {number} config.initial - 許容誤差の初期値。
             * @param {Array<number>} [config.margins] - グループ余白 [左,上,右,下]。
             * @param {function(number):void} config.onCommit - 確定した許容誤差を受け取るコールバック。
             * @returns {{checkbox: Checkbox, setEnabled: function(boolean):void}} 生成したUIへのアクセサ。
             */
            function createToleranceBlock(config) {
                var group = tabProcess.add('group');
                group.orientation = 'column';
                group.alignChildren = ['left', 'top'];
                if (config.margins) group.margins = config.margins;

                var checkbox = group.add('checkbox', undefined, getLabel(config.checkboxKey));
                checkbox.helpTip = getLabel(config.checkboxTooltipKey);
                checkbox.value = true;

                var row = group.add('group');
                row.orientation = 'row';
                row.alignChildren = ['left', 'center'];
                row.margins = [20, 0, 0, 0];

                var label = row.add('statictext', undefined, labelText(config.labelKey));
                label.helpTip = getLabel(config.tooltipKey);
                label.characters = 10;

                var input = row.add('edittext', undefined, config.initial.toFixed(2));
                input.helpTip = getLabel(config.tooltipKey);
                input.characters = 6;

                var slider = group.add('slider', undefined, Math.round(config.initial * 100), TOL_MIN * 100, TOL_MAX * 100);
                slider.helpTip = getLabel(config.tooltipKey);
                slider.preferredSize.width = 160;
                slider.indent = 20;

                var currentValue = config.initial;

                /**
                 * 入力欄・スライダー・呼び出し元の値を、丸めた許容誤差に揃えます。
                 * @param {number} toleranceValue - 設定する許容誤差。
                 * @param {boolean} refresh - 予測表示も更新する場合は true。
                 * @returns {void}
                 */
                function sync(toleranceValue, refresh) {
                    currentValue = clampTolerance(toleranceValue, currentValue);
                    input.text = currentValue.toFixed(2);
                    slider.value = Math.round(currentValue * 100);
                    config.onCommit(currentValue);
                    if (refresh) refreshInfoPreview();
                }

                /* ドラッグ中（onChanging）は重い選択では表示更新を省き、離したとき（onChange）に反映する */
                slider.onChanging = function () {
                    sync(slider.value / 100, !isHeavySelection);
                };
                slider.onChange = function () {
                    sync(slider.value / 100, true);
                };
                input.onChange = function () {
                    sync(parseToleranceText(input.text), true);
                };
                changeValueByArrowKey(input, function (steppedValue) {
                    sync(steppedValue, true);
                });

                return {
                    checkbox: checkbox,
                    /* スライダーは入力欄と別グループにあるため、行だけを切り替えると消し忘れる */
                    setEnabled: function (enabled) {
                        row.enabled = enabled;
                        slider.enabled = enabled;
                    }
                };
            }

            var anchorToleranceBlock = createToleranceBlock({
                checkboxKey: 'checkbox.removeAnchors',
                checkboxTooltipKey: 'tooltip.removeAnchors',
                labelKey: 'label.tolAnchor',
                tooltipKey: 'tooltip.tolAnchor',
                initial: TOL_ANCHOR_COLLINEAR,
                margins: [0, 15, 0, 15],
                onCommit: function (toleranceValue) {
                    TOL_ANCHOR_COLLINEAR = toleranceValue;
                }
            });
            var removeAnchorsCheckbox = anchorToleranceBlock.checkbox;

            var handleToleranceBlock = createToleranceBlock({
                checkboxKey: 'checkbox.removeHandles',
                checkboxTooltipKey: 'tooltip.removeHandles',
                labelKey: 'label.tolHandle',
                tooltipKey: 'tooltip.tolHandle',
                initial: TOL_HANDLE_COLLINEAR,
                onCommit: function (toleranceValue) {
                    TOL_HANDLE_COLLINEAR = toleranceValue;
                }
            });
            var removeHandlesCheckbox = handleToleranceBlock.checkbox;

            removeSameAnchorsCheckbox.onClick = function () {
                refreshInfoPreview();
            };
            removeAnchorsCheckbox.onClick = function () {
                anchorToleranceBlock.setEnabled(removeAnchorsCheckbox.value);
                refreshInfoPreview();
            };
            removeHandlesCheckbox.onClick = function () {
                handleToleranceBlock.setEnabled(removeHandlesCheckbox.value);
                refreshInfoPreview();
            };

            // 初回反映
            refreshInfoPreview();
            anchorToleranceBlock.setEnabled(removeAnchorsCheckbox.value);
            handleToleranceBlock.setEnabled(removeHandlesCheckbox.value);

            // --- Tab 2: 変換 ---
            var tabOther = tabbedPanel.add('tab', undefined, getLabel('tab.other'));
            setupPanel(tabOther);
            /* タブ内の右余白を詰める（PANEL_MARGINS の右16→6）。サブプロパティ代入は反映されないため配列で上書き */
            tabOther.margins = [16, 20, 6, 12];

            // パネル1：アンカーポイントを変換（スムーズ／コーナー）
            var convertPointsPanel = tabOther.add('panel', undefined, getLabel('panel.convertPoints'));
            setupPanel(convertPointsPanel);
            var smoothRadio = convertPointsPanel.add('radiobutton', undefined, getLabel('radio.convertSmooth'));
            var cornerRadio = convertPointsPanel.add('radiobutton', undefined, getLabel('radio.convertCorner'));

            // パネル2：アンカーポイントを追加（アンカー追加／極点追加）
            var addPointsPanel = tabOther.add('panel', undefined, getLabel('panel.addPoints'));
            setupPanel(addPointsPanel);
            var addAnchorsRadio = addPointsPanel.add('radiobutton', undefined, getLabel('radio.addAnchors'));
            addAnchorsRadio.helpTip = getLabel('tooltip.addAnchors');
            var extremePointsRadio = addPointsPanel.add('radiobutton', undefined, getLabel('radio.addExtremePoints'));
            extremePointsRadio.helpTip = getLabel('tooltip.addExtremePoints');

            // パネル3：その他（分割／マド埋め）
            var pathOpsPanel = tabOther.add('panel', undefined, getLabel('panel.pathOps'));
            setupPanel(pathOpsPanel);
            var splitRadio = pathOpsPanel.add('radiobutton', undefined, getLabel('radio.splitAtAnchors'));
            splitRadio.helpTip = getLabel('tooltip.splitAtAnchors');
            var fillHolesRadio = pathOpsPanel.add('radiobutton', undefined, getLabel('radio.fillHoles'));
            fillHolesRadio.helpTip = getLabel('tooltip.fillHoles');

            // 選択内にマド（複合パス）が無ければ「マド埋め」は無効化（ディム表示）
            if (!hasHoles) {
                fillHolesRadio.enabled = false;
            }

            smoothRadio.value = true;

            // パネルをまたぐ radiobutton は ScriptUI の自動排他が効かないため、
            // 全ラジオを1グループとして手動で単一選択を維持する
            var convertRadios = [smoothRadio, cornerRadio, addAnchorsRadio, extremePointsRadio, splitRadio, fillHolesRadio];

            /**
             * 指定ラジオだけを選択状態にし、他をすべて解除して予測表示を更新します。
             * @param {RadioButton} selectedRadio - 選択状態にするラジオボタン。
             * @returns {void}
             */
            function selectConvertRadio(selectedRadio) {
                for (var r = 0; r < convertRadios.length; r++) {
                    convertRadios[r].value = (convertRadios[r] === selectedRadio);
                }
                refreshInfoForConvert(getSelectedConvertMode());
            }

            for (var radioIndex = 0; radioIndex < convertRadios.length; radioIndex++) {
                (function (radio) {
                    radio.onClick = function () {
                        selectConvertRadio(radio);
                    };
                })(convertRadios[radioIndex]);
            }

            tabbedPanel.onChange = function () {
                refreshByActiveTab();
            };

            tabbedPanel.selection = 0;

            var buttonRow = dlg.add('group');
            buttonRow.orientation = 'row';
            buttonRow.alignChildren = ['center', 'center'];
            buttonRow.alignment = ['center', 'top'];
            buttonRow.margins = [0, 10, 0, 0];

            var btnCancel = buttonRow.add('button', undefined, getLabel('button.cancel'), { name: 'cancel' });
            var btnOK = buttonRow.add('button', undefined, getLabel('button.ok'), { name: 'ok' });

            /* ボタン生成前の予測表示では OK の状態を反映できないため、ここで一度反映する */
            updateOkEnabled();

            var dialogResult = {
                ok: false,
                activeMode: 'process',
                doRemoveSameAnchors: false,
                doRemoveAnchors: false,
                doRemoveHandles: false,
                convertMode: 'smooth'
            };

            btnOK.onClick = function () {
                dialogResult.ok = true;
                dialogResult.activeMode = getActiveMode();
                dialogResult.doRemoveSameAnchors = removeSameAnchorsCheckbox.value;
                dialogResult.doRemoveAnchors = removeAnchorsCheckbox.value;
                dialogResult.doRemoveHandles = removeHandlesCheckbox.value;
                dialogResult.convertMode = getSelectedConvertMode();
                saveDialogLocation(dlg);
                dlg.close(1);
            };
            btnCancel.onClick = function () {
                saveDialogLocation(dlg);
                dlg.close(0);
            };

            dlg.show();
            return dialogResult;
        }

        // --- 変換・分割ロジック ---
        /**
         * パスの全アンカーをコーナーポイント化し、ハンドルを除去します。
         * @param {PathItem} pathItem - 対象のパス。
         * @returns {void}
         */
        function convertToCorner(pathItem) {
            var points = pathItem.pathPoints;
            for (var k = 0; k < points.length; k++) {
                var pt = points[k];
                pt.pointType = PointType.CORNER;
                pt.leftDirection = pt.anchor;
                pt.rightDirection = pt.anchor;
            }
        }

        /**
         * パスの全アンカーをスムーズポイント化し、前後アンカーの距離・角度に応じてハンドルを補正します。
         * @param {PathItem} pathItem - 対象のパス。
         * @returns {void}
         */
        function convertToSmooth(pathItem) {
            var points = pathItem.pathPoints;
            for (var k = 0; k < points.length; k++) {
                var pt = points[k];
                pt.pointType = PointType.SMOOTH;

                // クローズドパスは循環参照、オープンパス端点は片側だけを参照する
                var anchor = pt.anchor;
                var isClosed = !!pathItem.closed;
                var prevPt = null;
                var nextPt = null;

                if (isClosed || k > 0) {
                    prevPt = points[(k - 1 + points.length) % points.length];
                }
                if (isClosed || k < points.length - 1) {
                    nextPt = points[(k + 1) % points.length];
                }

                var dPrev = prevPt ? Math.sqrt(
                    Math.pow(prevPt.anchor[0] - anchor[0], 2) +
                    Math.pow(prevPt.anchor[1] - anchor[1], 2)
                ) : 0;
                var dNext = nextPt ? Math.sqrt(
                    Math.pow(nextPt.anchor[0] - anchor[0], 2) +
                    Math.pow(nextPt.anchor[1] - anchor[1], 2)
                ) : 0;

                var lenLeft = dPrev / 3;
                var lenRight = dNext / 3;

                var angleFactor = 1;
                var balanceFactor = 1;

                var prevVecX = prevPt ? (prevPt.anchor[0] - anchor[0]) : 0;
                var prevVecY = prevPt ? (prevPt.anchor[1] - anchor[1]) : 0;
                var nextVecX = nextPt ? (nextPt.anchor[0] - anchor[0]) : 0;
                var nextVecY = nextPt ? (nextPt.anchor[1] - anchor[1]) : 0;

                // 前後アンカーが同一点または極端に近い場合の 0 除算を防ぐ
                var EPS = 1e-6;
                var hasPrev = dPrev > EPS;
                var hasNext = dNext > EPS;

                var dirX = 1;
                var dirY = 0;

                if (hasPrev && hasNext) {
                    var tVecX = nextVecX / dNext - prevVecX / dPrev;
                    var tVecY = nextVecY / dNext - prevVecY / dPrev;
                    var tLen = Math.sqrt(tVecX * tVecX + tVecY * tVecY);

                    if (tLen < 0.0001) {
                        dirX = nextVecX / dNext;
                        dirY = nextVecY / dNext;
                    } else {
                        dirX = tVecX / tLen;
                        dirY = tVecY / tLen;
                    }
                } else if (hasNext) {
                    dirX = nextVecX / dNext;
                    dirY = nextVecY / dNext;
                } else if (hasPrev) {
                    dirX = -prevVecX / dPrev;
                    dirY = -prevVecY / dPrev;
                }

                // 鋭角や前後距離の偏りが大きい場合は、ハンドル長を少しだけ抑える
                if (hasPrev && hasNext) {
                    var inDirX = -prevVecX / dPrev;
                    var inDirY = -prevVecY / dPrev;
                    var outDirX = nextVecX / dNext;
                    var outDirY = nextVecY / dNext;

                    var dot = inDirX * outDirX + inDirY * outDirY;
                    if (dot < -1) dot = -1;
                    if (dot > 1) dot = 1;

                    var turnAngle = Math.acos(dot);
                    var angleNorm = turnAngle / Math.PI; // 0..1
                    angleFactor = 1 - (0.35 * angleNorm);

                    var minLen = Math.min(dPrev, dNext);
                    var maxLen = Math.max(dPrev, dNext);
                    var imbalance = (maxLen > EPS) ? (1 - (minLen / maxLen)) : 0; // 0..1
                    balanceFactor = 1 - (0.25 * imbalance);
                }

                lenLeft *= angleFactor * balanceFactor;
                lenRight *= angleFactor * balanceFactor;

                // 8方向へ丸めず、計算した接線方向をそのまま使う
                pt.leftDirection = [
                    anchor[0] - dirX * lenLeft,
                    anchor[1] - dirY * lenLeft
                ];
                pt.rightDirection = [
                    anchor[0] + dirX * lenRight,
                    anchor[1] + dirY * lenRight
                ];
            }
        }

        /**
         * オブジェクトを再帰的にたどり、含まれるパスへスムーズ／コーナー変換を適用します。
         * @param {PageItem} item - 対象オブジェクト（PathItem／CompoundPathItem／GroupItem）。
         * @param {string} mode - 'smooth' または 'corner'。
         * @returns {void}
         */
        function convertPathItem(item, mode) {
            if (!item || isSkippableItem(item)) return;
            var convertFn = (mode === 'smooth') ? convertToSmooth : convertToCorner;
            if (item.typename === 'PathItem') {
                convertFn(item);
            } else if (item.typename === 'CompoundPathItem') {
                for (var i = 0; i < item.pathItems.length; i++) {
                    if (!isSkippableItem(item.pathItems[i])) {
                        convertFn(item.pathItems[i]);
                    }
                }
            } else if (item.typename === 'GroupItem') {
                /* convertPathItem は入口で isSkippableItem() を見るため、ここでは重ねて判定しない */
                for (var j = 0; j < item.pageItems.length; j++) {
                    convertPathItem(item.pageItems[j], mode);
                }
            }
        }

        /**
         * 分割後のパスを置く位置の基準になるオブジェクトを返します。
         * 通常は元のパス自身ですが、複合パスの子の場合は複合パス自身を返します。
         * 開いたパスは複合パスへ戻せないため、複合パスを基準に move すれば外へ逃がせます。
         * @param {PathItem} pathItem - 分割対象のパス。
         * @returns {PageItem} 重ね順の基準になるオブジェクト。
         */
        function getSplitAnchorItem(pathItem) {
            var anchorItem = pathItem;
            try {
                var parent = pathItem.parent;
                while (parent && parent.typename === 'CompoundPathItem') {
                    anchorItem = parent;
                    parent = parent.parent;
                }
            } catch (e) {
                logProcessError('getSplitAnchorItem', e);
            }
            return anchorItem;
        }

        /**
         * パスを各セグメントごとの独立したオープンパスに分割します（元のパスは削除）。
         * @param {PathItem} pathItem - 分割対象のパス。
         * @returns {void}
         */
        function splitAtAnchors(pathItem) {
            var pts = pathItem.pathPoints;
            if (pts.length < 2) return;

            var anchorItem = getSplitAnchorItem(pathItem);
            var segCount = pathItem.closed ? pts.length : pts.length - 1;
            var previousPath = null;

            for (var s = 0; s < segCount; s++) {
                var startIndex = s;
                var endIndex = (s + 1) % pts.length;
                var startPoint = pts[startIndex];
                var endPoint = pts[endIndex];

                /* duplicate() は効果・グラフィックスタイル・破線・不透明度まで丸ごと複製するため、
                   属性を1つずつコピーするより取りこぼしがない */
                var newPath = pathItem.duplicate();

                /* 元のパスがあった位置へ移す。複合パスの子の複製は複合パス内に落ちるので、
                   この move が「複合パスの外へ逃がす」処理も兼ねる（開いたパスは複合パスへ戻せない）。
                   PLACEBEFORE は基準のすぐ前面、PLACEAFTER はすぐ背面に入るため、
                   1本目だけ基準の前面に置き、2本目以降は直前に作ったパスの背面へ繋げて順序を保つ */
                try {
                    if (previousPath) {
                        newPath.move(previousPath, ElementPlacement.PLACEAFTER);
                    } else {
                        newPath.move(anchorItem, ElementPlacement.PLACEBEFORE);
                    }
                    previousPath = newPath;
                } catch (e) {
                    logProcessError('splitAtAnchors.move', e);
                }

                /* 複合パスから出したあとでないと開けないため、move の後に closed を落とす */
                newPath.closed = false;

                /* 複製は元と同じ点数なので、2点に詰めてからセグメントの座標で上書きする */
                while (newPath.pathPoints.length > 2) {
                    newPath.pathPoints[newPath.pathPoints.length - 1].remove();
                }

                var newStartPoint = newPath.pathPoints[0];
                newStartPoint.anchor = startPoint.anchor;
                newStartPoint.leftDirection = startPoint.anchor;
                newStartPoint.rightDirection = startPoint.rightDirection;
                newStartPoint.pointType = startPoint.pointType;

                var newEndPoint = newPath.pathPoints[1];
                newEndPoint.anchor = endPoint.anchor;
                newEndPoint.leftDirection = endPoint.leftDirection;
                newEndPoint.rightDirection = endPoint.anchor;
                newEndPoint.pointType = endPoint.pointType;
            }

            pathItem.remove();
        }

        /**
         * マド埋め：グループ化 → 複合パス解除 → ライブパスファインダー（合体）
         * → アピアランス展開 → グループ解除を実行します。
         * @returns {void}
         */
        function fillHolesOnSelection() {
            /* DOM で立てた選択が反映される前にコマンドが走らないよう、先に画面を更新する */
            app.redraw();
            /* executeMenuCommand は実行できないコマンドでも例外を投げず何もしないため、
               冒頭の group と対になる ungroup をそのまま呼ぶ */
            app.executeMenuCommand('group');
            app.executeMenuCommand('noCompoundPath');
            app.executeMenuCommand('Live Pathfinder Add');
            app.executeMenuCommand('expandStyle');
            app.executeMenuCommand('ungroup');
        }

        /**
         * オブジェクトを再帰的にたどり、含まれるパスをアンカーで分割します。
         * @param {PageItem} item - 対象オブジェクト（PathItem／CompoundPathItem／GroupItem）。
         * @returns {void}
         */
        function splitItem(item) {
            if (!item || isSkippableItem(item)) return;
            if (item.typename === 'PathItem') {
                splitAtAnchors(item);
            } else if (item.typename === 'CompoundPathItem') {
                var childPaths = [];
                for (var i = 0; i < item.pathItems.length; i++) {
                    if (!isSkippableItem(item.pathItems[i])) {
                        childPaths.push(item.pathItems[i]);
                    }
                }
                for (var ii = 0; ii < childPaths.length; ii++) {
                    splitAtAnchors(childPaths[ii]);
                }
                /* 子をすべて開いたパスとして外へ出したため、空になった複合パスを残さない */
                try {
                    if (item.pathItems.length === 0) item.remove();
                } catch (e) {
                    logProcessError('splitItem.removeEmptyCompoundPath', e);
                }
            } else if (item.typename === 'GroupItem') {
                /* splitAtAnchors がグループへ新しいパスを足すため、先に子をスナップショットする
                   （スキップ判定は再帰先の splitItem が入口で行う） */
                var childItems = [];
                for (var j = 0; j < item.pageItems.length; j++) {
                    childItems.push(item.pageItems[j]);
                }
                for (var jj = 0; jj < childItems.length; jj++) {
                    splitItem(childItems[jj]);
                }
            }
        }

        // --- 極点（Extreme Points）追加ロジック ---
        /** 2点 a, b を t（0〜1）で線形補間した座標 [x, y] を返します。 */
        function lerpPoint(a, b, t) {
            return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t];
        }

        /**
         * 3次ベジェを媒介変数 t で2本に分割します（de Casteljau）。
         * @param {Array<Array<number>>} controlPoints - 制御点4つ [P0, P1, P2, P3]。
         * @param {number} t - 分割位置（0〜1）。
         * @returns {{left: Array<Array<number>>, right: Array<Array<number>>}} 分割後の左右の制御点列。
         */
        function splitCubic(controlPoints, t) {
            var p01 = lerpPoint(controlPoints[0], controlPoints[1], t);
            var p12 = lerpPoint(controlPoints[1], controlPoints[2], t);
            var p23 = lerpPoint(controlPoints[2], controlPoints[3], t);
            var p012 = lerpPoint(p01, p12, t);
            var p123 = lerpPoint(p12, p23, t);
            var p0123 = lerpPoint(p012, p123, t);
            return { left: [controlPoints[0], p01, p012, p0123], right: [p0123, p123, p23, controlPoints[3]] };
        }

        /**
         * 1次元の3次ベジェ f(t) について f'(t)=0 となる t（極値）を求めます。
         * @param {number} v0 - P0 成分。
         * @param {number} v1 - P1 成分。
         * @param {number} v2 - P2 成分。
         * @param {number} v3 - P3 成分。
         * @returns {Array<number>} (0,1) の範囲にある t の配列。
         */
        function extremaParamsOfComponent(v0, v1, v2, v3) {
            var diff0 = v1 - v0;
            var diff1 = v2 - v1;
            var diff2 = v3 - v2;
            var quadA = diff0 - 2 * diff1 + diff2;
            var quadB = 2 * (diff1 - diff0);
            var quadC = diff0;
            var roots = [];
            var EPS = 1e-6;
            if (Math.abs(quadA) < EPS) {
                if (Math.abs(quadB) > EPS) roots.push(-quadC / quadB);
            } else {
                var discriminant = quadB * quadB - 4 * quadA * quadC;
                if (discriminant >= 0) {
                    var sqrtDiscriminant = Math.sqrt(discriminant);
                    roots.push((-quadB + sqrtDiscriminant) / (2 * quadA));
                    roots.push((-quadB - sqrtDiscriminant) / (2 * quadA));
                }
            }
            var paramsInRange = [];
            for (var i = 0; i < roots.length; i++) {
                if (roots[i] > EPS && roots[i] < 1 - EPS) paramsInRange.push(roots[i]);
            }
            return paramsInRange;
        }

        /**
         * セグメント（p0→p1）でハンドルが水平/垂直になる媒介変数 t を求めます。
         * 直線セグメント（両端ハンドルがアンカーと一致）は対象外で空配列を返す。
         * @param {PathPoint} p0 - 始点アンカー。
         * @param {PathPoint} p1 - 終点アンカー。
         * @returns {Array<number>} 昇順・重複除去済みの t 配列。
         */
        function bezierExtremaParams(p0, p1) {
            var isStraight = samePoint(p0.rightDirection, p0.anchor, TOL_SAMEPOINT) &&
                samePoint(p1.leftDirection, p1.anchor, TOL_SAMEPOINT);
            if (isStraight) return [];

            var P0 = p0.anchor, P1 = p0.rightDirection, P2 = p1.leftDirection, P3 = p1.anchor;
            var paramsX = extremaParamsOfComponent(P0[0], P1[0], P2[0], P3[0]); /* 垂直接線 dx/dt=0 */
            var paramsY = extremaParamsOfComponent(P0[1], P1[1], P2[1], P3[1]); /* 水平接線 dy/dt=0 */
            var extremaParams = paramsX.concat(paramsY);

            extremaParams.sort(function (x, y) { return x - y; });
            var uniqueParams = [];
            for (var i = 0; i < extremaParams.length; i++) {
                if (uniqueParams.length === 0 || Math.abs(extremaParams[i] - uniqueParams[uniqueParams.length - 1]) > 1e-4) uniqueParams.push(extremaParams[i]);
            }
            return uniqueParams;
        }

        /**
         * セグメントを複数の t（元セグメントの媒介変数）で分割し、
         * 端点ハンドルの更新値と挿入する内部アンカーを返します。
         * @param {Array<number>} P0 - 始点アンカー座標。
         * @param {Array<number>} P1 - 始点右ハンドル座標。
         * @param {Array<number>} P2 - 終点左ハンドル座標。
         * @param {Array<number>} P3 - 終点アンカー座標。
         * @param {Array<number>} extremaParams - 昇順の分割 t 配列。
         * @returns {{startRight: Array<number>, endLeft: Array<number>, interior: Array<Object>}} 分割結果。
         */
        function splitSegmentAtParams(P0, P1, P2, P3, extremaParams) {
            var currentCurve = [P0, P1, P2, P3];
            var prevParam = 0;
            var interior = [];
            var startRight = P1;
            for (var k = 0; k < extremaParams.length; k++) {
                var localT = (extremaParams[k] - prevParam) / (1 - prevParam);
                var pieces = splitCubic(currentCurve, localT);
                if (k === 0) {
                    startRight = pieces.left[1];
                } else {
                    interior[interior.length - 1].right = pieces.left[1];
                }
                interior.push({
                    anchor: pieces.left[3],
                    left: pieces.left[2],
                    right: pieces.right[1]
                });
                currentCurve = pieces.right;
                prevParam = extremaParams[k];
            }
            return { startRight: startRight, endLeft: currentCurve[2], interior: interior };
        }

        /**
         * パスの各曲線セグメントの極点にアンカーを追加します（同一オブジェクトを維持したまま再構築）。
         * @param {PathItem} pathItem - 対象のパス。
         * @returns {number} 追加したアンカー数。
         */
        function addExtremePointsToPath(pathItem) {
            var pts = pathItem.pathPoints;
            var n = pts.length;
            if (n < 2) return 0;

            var isClosed = !!pathItem.closed;
            var segCount = isClosed ? n : (n - 1);

            /* 既存アンカーの左右ハンドル（更新用）と、各セグメント直後に挿入する内部点 */
            var leftHandles = [];
            var rightHandles = [];
            var interiorAfter = [];
            for (var i = 0; i < n; i++) {
                leftHandles[i] = [pts[i].leftDirection[0], pts[i].leftDirection[1]];
                rightHandles[i] = [pts[i].rightDirection[0], pts[i].rightDirection[1]];
                interiorAfter[i] = [];
            }

            var added = 0;
            for (var s = 0; s < segCount; s++) {
                var j = (s + 1) % n;
                var extremaParams = bezierExtremaParams(pts[s], pts[j]);
                if (!extremaParams.length) continue;

                var splitResult = splitSegmentAtParams(
                    pts[s].anchor, pts[s].rightDirection,
                    pts[j].leftDirection, pts[j].anchor, extremaParams
                );
                rightHandles[s] = splitResult.startRight;
                leftHandles[j] = splitResult.endLeft;
                interiorAfter[s] = splitResult.interior;
                added += splitResult.interior.length;
            }

            if (added === 0) return 0;

            /* 新しい順序で点仕様を組み立てる（既存アンカー＋各セグメント直後の内部点） */
            var newPoints = [];
            for (var a = 0; a < n; a++) {
                newPoints.push({
                    anchor: [pts[a].anchor[0], pts[a].anchor[1]],
                    left: leftHandles[a],
                    right: rightHandles[a],
                    type: pts[a].pointType
                });
                var insertedPoints = interiorAfter[a];
                for (var b = 0; b < insertedPoints.length; b++) {
                    newPoints.push({
                        anchor: insertedPoints[b].anchor,
                        left: insertedPoints[b].left,
                        right: insertedPoints[b].right,
                        type: PointType.SMOOTH
                    });
                }
            }

            /* 同一 PathItem を保持したまま、点数を合わせて全点を上書き（アピアランス維持） */
            while (pathItem.pathPoints.length < newPoints.length) {
                pathItem.pathPoints.add();
            }
            for (var c = 0; c < newPoints.length; c++) {
                var pt = pathItem.pathPoints[c];
                pt.anchor = newPoints[c].anchor;
                pt.pointType = newPoints[c].type;
                pt.leftDirection = newPoints[c].left;
                pt.rightDirection = newPoints[c].right;
            }

            return added;
        }

        /**
         * オブジェクトを再帰的にたどり、含まれるパスの極点にアンカーを追加します。
         * @param {PageItem} item - 対象オブジェクト（PathItem／CompoundPathItem／GroupItem）。
         * @returns {void}
         */
        function addExtremePointsToItem(item) {
            if (!item || isSkippableItem(item)) return;
            if (item.typename === 'PathItem') {
                try {
                    addExtremePointsToPath(item);
                } catch (e) {
                    logProcessError("addExtremePointsToPath", e);
                }
            } else if (item.typename === 'CompoundPathItem') {
                /* addExtremePointsToItem は入口で isSkippableItem() を見るため、ここでは重ねて判定しない */
                for (var i = 0; i < item.pathItems.length; i++) {
                    addExtremePointsToItem(item.pathItems[i]);
                }
            } else if (item.typename === 'GroupItem') {
                for (var j = 0; j < item.pageItems.length; j++) {
                    addExtremePointsToItem(item.pageItems[j]);
                }
            }
        }

        /**
         * 指定 targets に対して追加される極点アンカー数を予測します（実際には変更しない）。
         * @param {Array<PathItem>} targets - 対象の PathItem 配列。
         * @returns {number} 追加されるアンカー総数。
         */
        function countExtremaForTargets(targets) {
            var total = 0;
            if (!targets || !targets.length) return total;
            for (var i = 0; i < targets.length; i++) {
                var item = targets[i];
                if (!item) continue;
                try {
                    var pts = item.pathPoints;
                    var n = pts.length;
                    if (n < 2) continue;
                    var isClosed = !!item.closed;
                    var segCount = isClosed ? n : (n - 1);
                    for (var s = 0; s < segCount; s++) {
                        var j = (s + 1) % n;
                        total += bezierExtremaParams(pts[s], pts[j]).length;
                    }
                } catch (e) {
                    logProcessError("countExtremaForTargets", e);
                }
            }
            return total;
        }

        // ダイアログ表示時点の選択を確定（予測と実行を同一対象に揃える）
        var selectionAtOpen = getSelectionOrAlert();
        if (!selectionAtOpen) return;
        var targetsAtOpen = getTargetPathItemsFromSelection(selectionAtOpen);
        var hasHolesAtOpen = selectionHasHoles(selectionAtOpen);

        var ui = showDialog(targetsAtOpen, hasHolesAtOpen);
        if (!ui.ok) return;

        // タブindex依存だと ScriptUI 環境差で誤判定しうるため、明示状態で分岐する
        /**
         * 選択をダイアログ表示時点のスナップショットに復元します。
         * @param {Array<PageItem>} selectionSnapshot - 復元する選択オブジェクト配列。
         * @returns {number} 復元できたオブジェクト数。
         */
        function restoreSelection(selectionSnapshot) {
            var restoredCount = 0;
            try {
                if (!hasDocument()) return 0;
                var doc = app.activeDocument;
                doc.selection = null;
                for (var i = 0; i < selectionSnapshot.length; i++) {
                    var item = selectionSnapshot[i];
                    if (!item) continue;
                    try {
                        item.selected = true;
                        restoredCount++;
                    } catch (e) {
                        // skip items that can no longer be selected
                    }
                }
            } catch (e) {
                logProcessError("restoreSelection", e);
            }
            return restoredCount;
        }

        /**
         * 選択依存メニューコマンド用に、スキップ対象を除いた PathItem だけを選択復元します。
         * @param {Array<PageItem>} selectionSnapshot - 元の選択スナップショット。
         * @returns {number} 復元できた PathItem 数。
         */
        function restoreSelectableSelection(selectionSnapshot) {
            var restoredCount = 0;
            try {
                if (!hasDocument()) return 0;
                var doc = app.activeDocument;
                var selectablePathItems = getTargetPathItemsFromSelection(selectionSnapshot);

                doc.selection = null;
                for (var i = 0; i < selectablePathItems.length; i++) {
                    var pathItem = selectablePathItems[i];
                    if (!pathItem) continue;
                    try {
                        pathItem.selected = true;
                        restoredCount++;
                    } catch (e) {
                        // skip items that can no longer be selected
                    }
                }
            } catch (e) {
                logProcessError("restoreSelectableSelection", e);
            }
            return restoredCount;
        }

        // 実行前に選択を復元（1つも復元できなければ中止して理由を伝える）
        if (restoreSelection(selectionAtOpen) === 0) {
            alert(getLabel('alert.lostSelection'));
            return;
        }

        if (ui.activeMode === 'other') {
            // --- 「変換」タブ: 変換・分割処理 ---
            /* splitItem / addExtremePointsToItem / convertPathItem はいずれも入口で
               isSkippableItem() を見るため、ここでは重ねて判定しない */
            var selectionSnapshot = selectionAtOpen.slice(0);
            if (ui.convertMode === 'add') {
                if (restoreSelectableSelection(selectionSnapshot) > 0) {
                    /* DOM で立てた選択が反映される前にコマンドが走らないよう、先に画面を更新する */
                    app.redraw();
                    app.executeMenuCommand('Add Anchor Points2');
                }
            } else if (ui.convertMode === 'split') {
                for (var i = 0; i < selectionSnapshot.length; i++) {
                    splitItem(selectionSnapshot[i]);
                }
            } else if (ui.convertMode === 'extreme') {
                for (var j = 0; j < selectionSnapshot.length; j++) {
                    addExtremePointsToItem(selectionSnapshot[j]);
                }
            } else if (ui.convertMode === 'fillHoles') {
                /* マド埋めは複合パス自体に対する操作なので、子パスに分解せず
                   ダイアログ表示時点の選択をそのまま復元する */
                if (restoreSelection(selectionSnapshot) > 0) {
                    fillHolesOnSelection();
                }
            } else {
                for (var k = 0; k < selectionSnapshot.length; k++) {
                    convertPathItem(selectionSnapshot[k], ui.convertMode);
                }
            }
        } else {
            // --- 「削除対象」タブ: クリーンアップ処理 ---
            if (!ui.doRemoveSameAnchors && !ui.doRemoveAnchors && !ui.doRemoveHandles) {
                return;
            }

            // 情報パネルの予測とまったく同じ関数・同じ実行順を通す
            runCleanupOnTargets(targetsAtOpen, ui.doRemoveSameAnchors, ui.doRemoveAnchors, ui.doRemoveHandles);
        }
    })();

})();
