#target illustrator
app.preferences.setBooleanPreference('ShowExternalJSXWarning', false);

/*

### 概要

Illustratorの各種環境設定をダイアログから変更します。
単位、文字設定、変形／整列設定などを1つのパネルで調整できます。

詳細は README を参照してください。
https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/PreferenceManager-unit.md

### Overview

Changes a range of Illustrator preferences from a dialog.
Units, text settings and transform/align settings are all adjusted in a single panel.

See the README for details.
https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/PreferenceManager-unit.md

*/

// =========================================
// 基本情報 / Basic info
// =========================================
var SCRIPT_NAME     = "PreferenceManager-unit";       /* スクリプト名 / script name */
var SCRIPT_VERSION  = "v1.2.2";                         /* バージョン / version */
var SCRIPT_AUTHOR   = "Masahiro Takano (@swwwitch)";  /* 作者 / author */
var SCRIPT_RELEASED = "2025-08-04";                   /* 最初のリリース日 / first release date */
var SCRIPT_UPDATED  = "2026-09-19";                   /* 更新日 / last updated */

var SCRIPT_README_JA = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/PreferenceManager-unit.md"; /* README（日本語） */
var SCRIPT_README_EN = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/PreferenceManager-unit.md"; /* README (English) */

// Released under the MIT license
// http://opensource.org/licenses/mit-license.php

(function () {

    /* 現在のUI言語を取得 / Get the current UI language */
    function getCurrentLang() {
        return ($.locale.indexOf("ja") === 0) ? "ja" : "en";
    }
    var uiLang = getCurrentLang();

    /* UIラベル定義 / UI Label Definitions */
    var LABELS = {
        dialogTitle: {
            ja: "まとめて環境設定 " + SCRIPT_VERSION,
            en: "Preferences " + SCRIPT_VERSION
        },
        tipModePrintPt: { ja: "一般=mm、線=pt、文字=pt、東アジア言語のオプション=pt にまとめて切り替えます。", en: "Sets General=mm, Stroke=pt, Text=pt, East Asian=pt." },
        tipModePrintQ: { ja: "一般=mm、線=mm、文字=Q、東アジア言語のオプション=Q にまとめて切り替えます。", en: "Sets General=mm, Stroke=mm, Text=Q, East Asian=Q." },
        tipModeOnscreen: { ja: "一般・線・文字・東アジア言語のオプションをすべて px に切り替えます。", en: "Sets General, Stroke, Text and East Asian all to px." },
        tipUnitGeneral: { ja: "定規やパネルに表示される、既定の長さの単位です。", en: "Default unit shown on rulers and panels." },
        tipUnitStroke: { ja: "線幅の入力・表示に使う単位です。", en: "Unit used for stroke weights." },
        tipUnitType: { ja: "フォントサイズや行送りに使う単位です。", en: "Unit used for font size and leading." },
        tipUnitAsian: { ja: "東アジア言語のオプションで使う単位です。", en: "Unit used for East Asian typography options." },
        tipKeyValue: { ja: "矢印キー1回で動く距離です。", en: "How far one arrow key press moves things." },
        tipCornerRadius: { ja: "角丸ツールの既定の半径です。", en: "Default radius used by the rounded rectangle tool." },
        tipSizeValue: { ja: "文字サイズ・行送りを増減する1回ぶんの量です。", en: "How much one step changes the type size or leading." },
        tipBaselineValue: { ja: "ベースラインシフトを増減する1回ぶんの量です。", en: "How much one step changes the baseline shift." },
        tipFontEnglish: { ja: "フォント名を英語表記で表示します。", en: "Shows font names in English." },
        tipRecentFonts: { ja: "フォントメニューの先頭に並ぶ「最近使用したフォント」の表示件数です。0 で非表示になります。", en: "How many recently used fonts appear at the top of the font menu. 0 hides the list." },
        tipGlyphBounds: { ja: "整列の基準を、仮想ボディではなく字形の実際の輪郭にします。", en: "Aligns text by the actual glyph outlines instead of the em box." },
        tipPreviewBounds: { ja: "線幅や効果を含めた見た目の端を、オブジェクトの境界として扱います。", en: "Treats the visible edges including strokes and effects as the object bounds." },
        tipTransformPattern: { ja: "オブジェクトを変形したとき、塗りのパターンも一緒に変形します。", en: "Transforms the pattern fill along with the object." },
        tipScaleCorners: { ja: "拡大・縮小したとき、ライブコーナーの角丸も一緒に変わります。", en: "Scales live corner radii along with the object." },
        tipScaleStroke: { ja: "拡大・縮小したとき、線幅と効果も一緒に変わります。", en: "Scales stroke weights and effects along with the object." },
        tipRealtimeDrawing: { ja: "ドラッグ中もオブジェクトの結果を表示しながら描画・編集します。", en: "Draws and edits with a live result while dragging." },
        modePrintPt: {
            ja: "プリント（pt）",
            en: "Print (pt)"
        },
        modePrintQ: {
            ja: "プリント（Q）",
            en: "Print (Q)"
        },
        modeOnscreen: {
            ja: "オンスクリーン（px）",
            en: "Onscreen (px)"
        },
        unitsTitle: {
            ja: "単位",
            en: "Units"
        },
        // --- Inserted localization for unit dropdowns ---
        generalUnit: {
            ja: "一般",
            en: "General"
        },
        strokeUnit: {
            ja: "線",
            en: "Stroke"
        },
        textUnit: {
            ja: "文字",
            en: "Type"
        },
        asianUnit: {
            ja: "東アジア言語",
            en: "East Asian Type"
        },
        // -----------------------------------------------
        textTitle: {
            ja: "テキスト",
            en: "Text"
        },
        fontEnglish: {
            ja: "フォント名を英語表記",
            en: "Show Font Names in English"
        },
        recentFonts: {
            ja: "最近使用したフォント",
            en: "Recent Fonts"
        },
        transformTitle: {
            ja: "変形と整列",
            en: "Transform & Align"
        },
        previewBounds: {
            ja: "プレビュー境界",
            en: "Preview Bounds"
        },
        transformPattern: {
            ja: "パターンを変形",
            en: "Transform Pattern Tiles"
        },
        scaleCorners: {
            ja: "角を拡大・縮小",
            en: "Scale Corners"
        },
        scaleStroke: {
            ja: "線幅と効果も拡大・縮小",
            en: "Scale Strokes & Effects"
        },
        realtimeDrawing: {
            ja: "リアルタイムの描画と編集",
            en: "Real-time Drawing & Editing"
        },
        glyphBounds: {
            ja: "字形の境界に整列",
            en: "Align to Glyph Bounds"
        },
        pointText: {
            ja: "ポイント文字",
            en: "Point Type"
        },
        areaText: {
            ja: "エリア内文字",
            en: "Area Type"
        },
        ok: {
            ja: "OK",
            en: "OK"
        },
        cancel: {
            ja: "キャンセル",
            en: "Cancel"
        },
        leadingLabel: {
            ja: "サイズ/行送り：",
            en: "Size/Leading:"
        },
        baselineLabel: {
            ja: "ベースライン：",
            en: "Baseline Shift:"
        },
        // ---- Added missing localized labels ----
        generalTitle: {
            ja: "一般",
            en: "General"
        },
        keyInputLabel: {
            ja: "キー増加：",
            en: "Keyboard Increment::"
        },
        cornerRadiusLabel: {
            ja: "角丸の半径：",
            en: "Corner Radius:"
        },
        textDetailTitle: {
            ja: "テキスト",
            en: "Text"
        }
    };

    /* ↑↓キーで値を増減 / Change value with arrow keys */
    function changeValueByArrowKey(editText) {
        editText.addEventListener("keydown", function(event) {
            var value = Number(editText.text);
            if (isNaN(value)) return;

            var keyboard = ScriptUI.environment.keyboardState;
            var delta = 1;

            if (keyboard.shiftKey) {
                delta = 10;
                if (event.keyName == "Up") {
                    value = Math.ceil((value + 1) / delta) * delta;
                    event.preventDefault();
                } else if (event.keyName == "Down") {
                    value = Math.floor((value - 1) / delta) * delta;
                    if (value < 0) value = 0;
                    event.preventDefault();
                }
            } else if (keyboard.altKey) {
                delta = 0.1;
                if (event.keyName == "Up") {
                    value += delta;
                    event.preventDefault();
                } else if (event.keyName == "Down") {
                    value -= delta;
                    event.preventDefault();
                }
            } else {
                delta = 1;
                if (event.keyName == "Up") {
                    value += delta;
                    event.preventDefault();
                } else if (event.keyName == "Down") {
                    value -= delta;
                    if (value < 0) value = 0;
                    event.preventDefault();
                }
            }

            if (keyboard.altKey) {
                value = Math.round(value * 10) / 10; /* 小数第1位まで / Round to 1 decimal place */
            } else {
                value = Math.round(value);
            }

            editText.text = value;
            editText.notify("onChange"); /* 値変更をトリガー / Trigger value change */
        });
    }

    /* 単位テーブル（配列の添字が rulerType コードと一致：0=in, 1=mm, 2=pt …）/ Unit table; the array index equals the rulerType code */
    var UNITS = [
        { label: "in",    pointsPerUnit: 72 },                /* 0 */
        { label: "mm",    pointsPerUnit: 72 / 25.4 },         /* 1 */
        { label: "pt",    pointsPerUnit: 1 },                 /* 2 */
        { label: "pica",  pointsPerUnit: 12 },                /* 3 */
        { label: "cm",    pointsPerUnit: 72 / 2.54 },         /* 4 */
        { label: "Q",     pointsPerUnit: 72 / 25.4 * 0.25 },  /* 5 */
        { label: "px",    pointsPerUnit: 1 },                 /* 6 */
        { label: "ft/in", pointsPerUnit: 72 * 12 },           /* 7 */
        { label: "m",     pointsPerUnit: 72 / 25.4 * 1000 },  /* 8 */
        { label: "yd",    pointsPerUnit: 72 * 36 },           /* 9 */
        { label: "ft",    pointsPerUnit: 72 * 12 }            /* 10 */
    ];

    /* 単位コード5を「歯（H）」と表示する環境設定キー。文字サイズ（text/units）だけ「級（Q）」
       Preference keys that show unit code 5 as H; only the type size (text/units) shows Q */
    var HA_UNIT_PREF_KEYS = { "rulerType": true, "strokeUnits": true, "text/asianunits": true };

    /**
     * 設定キーごとの単位情報を取得する
     * @param {string} prefKey - 環境設定キー（省略時は "rulerType"）
     * @returns {{code: number, label: string, pointsPerUnit: number}} 単位情報
     */
    function getUnitInfo(prefKey) {
        var unitKey = prefKey || "rulerType";
        var unitCode = app.preferences.getIntegerPreference(unitKey);
        var unit = UNITS[unitCode] || UNITS[2];
        var label = (unitCode === 5 && HA_UNIT_PREF_KEYS[unitKey]) ? "H" : unit.label;
        return { code: unitCode, label: label, pointsPerUnit: unit.pointsPerUnit };
    }

    /**
     * 単位コードと環境設定キーから表示ラベルを返す
     * @param {number} unitCode - 単位コード
     * @param {string} [prefKey] - 環境設定キー（単位コード5の Q／H を分けるために使う）
     * @returns {string} 表示ラベル
     */
    function getUnitLabel(unitCode, prefKey) {
        var unit = UNITS[unitCode] || UNITS[2];
        return (unitCode === 5 && HA_UNIT_PREF_KEYS[prefKey || "rulerType"]) ? "H" : unit.label;
    }

    /* 単位換算ユーティリティ / Unit conversion utilities */
    function getPtFactorFromUnitCode(unitCode) {
        return (UNITS[unitCode] || UNITS[2]).pointsPerUnit;
    }

    function convertFromPt(valuePt, unitCode) {
        return valuePt / getPtFactorFromUnitCode(unitCode);
    }

    function convertToPt(valueUnit, unitCode) {
        return valueUnit * getPtFactorFromUnitCode(unitCode);
    }

    /* 複数チェックボックスを環境設定キーにバインド / Bind multiple checkboxes to preference keys */
    function bindCheckboxes(pairs) {
        for (var i = 0; i < pairs.length; i++) {
            (function(pair) {
                pair.checkbox.onClick = function() {
                    app.preferences.setBooleanPreference(pair.prefKey, pair.checkbox.value === true);
                };
            })(pairs[i]);
        }
    }

    /* ダイアログ位置を調整 / Adjust dialog position */
    function shiftDialogPosition(dlg, offsetX, offsetY) {
        dlg.onShow = function() {
            var currentX = dlg.location[0];
            var currentY = dlg.location[1];
            dlg.location = [currentX + offsetX, currentY + offsetY];
        };
    }

    /* ダイアログの透明度を設定 / Set dialog opacity */
    function setDialogOpacity(dlg, opacityValue) {
        dlg.opacity = opacityValue;
    }

    /* メイン処理 / Main entry point */
    function main() {
        var pref = app.preferences;

        var dialog = new Window('dialog');
        dialog.text = LABELS.dialogTitle[uiLang];
        dialog.orientation = 'column';
        dialog.alignChildren = ['fill', 'top'];

        /* ダイアログ位置と透明度の調整 / Adjust dialog position and opacity */
        var offsetX = 300;
        var dialogOpacity = 0.97;
        setDialogOpacity(dialog, dialogOpacity);
        shiftDialogPosition(dialog, offsetX, 0);

        /* モード選択ラジオボタン / Mode Selection Radio Buttons */
        var modeGroup = dialog.add('group');
        modeGroup.orientation = 'row';
        modeGroup.alignChildren = ['center', 'center']; // 中央揃え
        modeGroup.alignment = ['center', 'top']; // グループ自体を中央に配置
        modeGroup.margins = [15, 10, 15, 10];

        var radioPrintPt = modeGroup.add('radiobutton', undefined, LABELS.modePrintPt[uiLang]);
        radioPrintPt.helpTip = LABELS.tipModePrintPt[uiLang];
        var radioPrintQ = modeGroup.add('radiobutton', undefined, LABELS.modePrintQ[uiLang]);
        radioPrintQ.helpTip = LABELS.tipModePrintQ[uiLang];
        var radioOnscreen = modeGroup.add('radiobutton', undefined, LABELS.modeOnscreen[uiLang]);
        radioOnscreen.helpTip = LABELS.tipModeOnscreen[uiLang];
        // radioPrintPt.value = true; // デフォルト選択を無効化
        // None selected by default; set all to false on dialog show
        dialog.onShow = function() {
            radioPrintPt.value = false;
            radioPrintQ.value = false;
            radioOnscreen.value = false;
        };

        /* 2カラムのメインコンテナ / Two-column main container */
        var mainGroup = dialog.add('group');
        mainGroup.orientation = 'row';
        mainGroup.alignChildren = ['fill', 'top'];

        /* 左カラム / Left column */
        var leftColumn = mainGroup.add('group');
        leftColumn.orientation = 'column';
        leftColumn.alignChildren = ['fill', 'top'];

        /* 単位パネルを追加 / Add "Units" panel */
        var unitsPanel = leftColumn.add('panel', undefined, LABELS.unitsTitle[uiLang]);
        unitsPanel.orientation = 'column';
        unitsPanel.alignChildren = ['left', 'top'];
        unitsPanel.margins = [8, 20, 8, 15];

        /* 一般パネルを追加 / Add "General" panel */
        var generalPanel = leftColumn.add('panel', undefined, LABELS.generalTitle[uiLang]);
        generalPanel.orientation = 'column';
        generalPanel.alignChildren = ['left', 'top'];
        generalPanel.margins = [8, 20, 8, 15];

        // 単位ラベル取得ヘルパー
        function getGeneralUnitLabel() {
            var code = app.preferences.getIntegerPreference("rulerType");
            return getUnitLabel(code, "rulerType");
        }

        // キー増加
        var groupKeyInput = generalPanel.add('group');
        groupKeyInput.orientation = 'row';
        var labelKey = groupKeyInput.add('statictext', undefined, LABELS.keyInputLabel[uiLang]);
        labelKey.characters = 12;
        labelKey.justify = 'right';
        var unitCodeKey = app.preferences.getIntegerPreference("rulerType");
        var keyValuePt = pref.getRealPreference("cursorKeyLength");
        var keyValue = convertFromPt(keyValuePt, unitCodeKey);
        var inputKey = groupKeyInput.add('edittext', undefined, keyValue.toFixed(1));
        inputKey.helpTip = LABELS.tipKeyValue[uiLang];
        inputKey.characters = 4;
        var unitLabelKey = groupKeyInput.add('statictext', undefined, getGeneralUnitLabel());
        unitLabelKey.characters = 4; // 幅を広げる
        inputKey.onChange = function() {
            var value = parseFloat(inputKey.text);
            if (!isNaN(value)) {
                var ptValue = convertToPt(value, app.preferences.getIntegerPreference("rulerType"));
                pref.setRealPreference("cursorKeyLength", ptValue);
                refreshValues();
            }
        };
        /* ↑↓キー操作を適用 / Apply arrow key value change */
        changeValueByArrowKey(inputKey);

        // 角丸の半径
        var groupCornerRadius = generalPanel.add('group');
        groupCornerRadius.orientation = 'row';
        var labelCorner = groupCornerRadius.add('statictext', undefined, LABELS.cornerRadiusLabel[uiLang]);
        labelCorner.characters = 12;
        labelCorner.justify = 'right';
        var cornerUnitCode = app.preferences.getIntegerPreference("rulerType");
        var cornerValuePt = pref.getRealPreference("ovalRadius");
        var cornerValue = convertFromPt(cornerValuePt, cornerUnitCode);
        var inputCornerRadius = groupCornerRadius.add('edittext', undefined, cornerValue.toFixed(1));
        inputCornerRadius.helpTip = LABELS.tipCornerRadius[uiLang];
        inputCornerRadius.characters = 4;
        var unitLabelCorner = groupCornerRadius.add('statictext', undefined, getGeneralUnitLabel());
        unitLabelCorner.characters = 4; // 幅を広げる
        inputCornerRadius.onChange = function() {
            var value = parseFloat(inputCornerRadius.text);
            if (!isNaN(value)) {
                var ptValue = convertToPt(value, app.preferences.getIntegerPreference("rulerType"));
                pref.setRealPreference("ovalRadius", ptValue);
                refreshValues();
            }
        };
        /* ↑↓キー操作を適用 / Apply arrow key value change */
        changeValueByArrowKey(inputCornerRadius);

        /* テキスト詳細パネルを追加 / Add "Text Details" panel */
        // --- Unit label helpers for text detail panel ---
        function getTextUnitLabel() {
            var code = app.preferences.getIntegerPreference("text/units");
            return getUnitLabel(code, "text/units");
        }

        function getAsianUnitLabel() {
            var code = app.preferences.getIntegerPreference("text/asianunits");
            return getUnitLabel(code, "text/asianunits");
        }
        var textDetailPanel = leftColumn.add('panel', undefined, LABELS.textDetailTitle[uiLang]);
        textDetailPanel.orientation = 'column';
        textDetailPanel.alignChildren = ['left', 'top'];
        textDetailPanel.margins = [8, 20, 8, 15];

        // サイズ行送り
        var groupLeading = textDetailPanel.add('group');
        groupLeading.orientation = 'row';
        var labelLeading = groupLeading.add('statictext', undefined, LABELS.leadingLabel[uiLang]);
        labelLeading.characters = 12;
        labelLeading.justify = 'right';
        var sizeUnitCode = app.preferences.getIntegerPreference("text/units");
        var sizeValuePt = pref.getRealPreference("text/sizeIncrement");
        var sizeValue = convertFromPt(sizeValuePt, sizeUnitCode);
        var inputLeading = groupLeading.add('edittext', undefined, sizeValue.toFixed(1));
        inputLeading.helpTip = LABELS.tipSizeValue[uiLang];
        inputLeading.characters = 4;
        var unitLabelLeading = groupLeading.add('statictext', undefined, getTextUnitLabel());
        unitLabelLeading.characters = 4; // 幅を広げる
        inputLeading.onChange = function() {
            var value = parseFloat(inputLeading.text);
            if (!isNaN(value)) {
                var ptValue = convertToPt(value, app.preferences.getIntegerPreference("text/units"));
                pref.setRealPreference("text/sizeIncrement", ptValue);
                refreshValues();
            }
        };
        /* ↑↓キー操作を適用 / Apply arrow key value change */
        changeValueByArrowKey(inputLeading);

        // ベースラインシフト
        var groupBaseline = textDetailPanel.add('group');
        groupBaseline.orientation = 'row';
        var labelBaseline = groupBaseline.add('statictext', undefined, LABELS.baselineLabel[uiLang]);
        labelBaseline.characters = 12;
        labelBaseline.justify = 'right';
        var baselineUnitCode = app.preferences.getIntegerPreference("text/asianunits");
        var baselineValuePt = pref.getRealPreference("text/riseIncrement");
        var baselineValue = convertFromPt(baselineValuePt, baselineUnitCode);
        var inputBaseline = groupBaseline.add('edittext', undefined, baselineValue.toFixed(1));
        inputBaseline.helpTip = LABELS.tipBaselineValue[uiLang];
        inputBaseline.characters = 4;
        var unitLabelBaseline = groupBaseline.add('statictext', undefined, getAsianUnitLabel());
        unitLabelBaseline.characters = 4; // 幅を広げる
        inputBaseline.onChange = function() {
            var value = parseFloat(inputBaseline.text);
            if (!isNaN(value)) {
                var ptValue = convertToPt(value, app.preferences.getIntegerPreference("text/asianunits"));
                pref.setRealPreference("text/riseIncrement", ptValue);
                refreshValues();
            }
        };
        /* ↑↓キー操作を適用 / Apply arrow key value change */
        changeValueByArrowKey(inputBaseline);

        var unitDropdowns = {};

        function createUnitDropdown(parent, label, prefKey) {
            var group = parent.add('group');
            group.orientation = 'row';
            var labelControl = group.add('statictext', undefined, label + "：");
            labelControl.characters = 12;
            labelControl.justify = 'right';

            var dropdown = group.add('dropdownlist', undefined, []);
            dropdown.characters = 9; // ← 幅を6文字分に指定
            /* ラベルを追加（添字が単位コード）/ Add the labels (the index is the unit code) */
            for (var code = 0; code < UNITS.length; code++) {
                dropdown.add('item', getUnitLabel(code, prefKey));
            }

            var currentCode = app.preferences.getIntegerPreference(prefKey);
            dropdown.selection = dropdown.find(getUnitLabel(currentCode, prefKey)) || dropdown.find("pt");

            dropdown.onChange = function() {
                var selectedLabel = dropdown.selection.text;
                for (var c = 0; c < UNITS.length; c++) {
                    if (getUnitLabel(c, prefKey) === selectedLabel) {
                        app.preferences.setIntegerPreference(prefKey, c);
                        break;
                    }
                }
            };

            unitDropdowns[prefKey] = dropdown;
        }

        /* 各プルダウンを作成 */
        createUnitDropdown(unitsPanel, LABELS.generalUnit[uiLang], "rulerType");
        createUnitDropdown(unitsPanel, LABELS.strokeUnit[uiLang], "strokeUnits");
        createUnitDropdown(unitsPanel, LABELS.textUnit[uiLang], "text/units");
        createUnitDropdown(unitsPanel, LABELS.asianUnit[uiLang], "text/asianunits");

        function setUnitsForMode(mode) {
            if (mode === "printPt") {
                unitDropdowns["rulerType"].selection = unitDropdowns["rulerType"].find("mm"); // 一般は mm
                unitDropdowns["strokeUnits"].selection = unitDropdowns["strokeUnits"].find("pt");
                unitDropdowns["text/units"].selection = unitDropdowns["text/units"].find("pt");
                unitDropdowns["text/asianunits"].selection = unitDropdowns["text/asianunits"].find("pt");

                // 値を更新（すべてptで保存、UIはmm/pt表示）
                var rulerCode = 1; // mm
                var textCode = 2; // pt
                var asianCode = 2; // pt
                pref.setRealPreference("cursorKeyLength", convertToPt(0.1, rulerCode));
                pref.setRealPreference("ovalRadius", convertToPt(1, rulerCode));
                pref.setRealPreference("text/sizeIncrement", convertToPt(1.0, textCode));
                pref.setRealPreference("text/riseIncrement", convertToPt(0.1, asianCode));

            } else if (mode === "printQ") {
                unitDropdowns["rulerType"].selection = unitDropdowns["rulerType"].find("mm");
                unitDropdowns["strokeUnits"].selection = unitDropdowns["strokeUnits"].find("mm");
                var qhUnitCode = 5;
                unitDropdowns["text/units"].selection = unitDropdowns["text/units"].find(getUnitLabel(qhUnitCode, "text/units"));
                unitDropdowns["text/asianunits"].selection = unitDropdowns["text/asianunits"].find(getUnitLabel(qhUnitCode, "text/asianunits"));

                // 値を更新（すべてptで保存、UIはmm/Q/H表示）
                var rulerCodeQ = 1; // mm
                pref.setRealPreference("cursorKeyLength", convertToPt(1, rulerCodeQ));
                pref.setRealPreference("ovalRadius", convertToPt(2, rulerCodeQ));
                pref.setRealPreference("text/sizeIncrement", convertToPt(1, qhUnitCode));
                pref.setRealPreference("text/riseIncrement", convertToPt(0.1, qhUnitCode));

            } else if (mode === "onscreen") {
                unitDropdowns["rulerType"].selection = unitDropdowns["rulerType"].find("px");
                unitDropdowns["strokeUnits"].selection = unitDropdowns["strokeUnits"].find("px");
                unitDropdowns["text/units"].selection = unitDropdowns["text/units"].find("px");
                unitDropdowns["text/asianunits"].selection = unitDropdowns["text/asianunits"].find("px");

                // 値を更新
                var pxCode = 6;
                pref.setRealPreference("cursorKeyLength", convertToPt(1, pxCode));
                pref.setRealPreference("ovalRadius", convertToPt(1, pxCode));
                pref.setRealPreference("text/sizeIncrement", convertToPt(1, pxCode));
                pref.setRealPreference("text/riseIncrement", convertToPt(0.5, pxCode));
            }

            /* Trigger onChange manually to update preferences */
            for (var key in unitDropdowns) {
                if (unitDropdowns[key].selection) {
                    unitDropdowns[key].onChange();
                }
            }

            refreshUnitLabels();
            refreshValues();
        }

        // --- Helper to refresh unit labels in panels ---
        function refreshUnitLabels() {
            // Update General panel unit labels
            groupKeyInput.children[groupKeyInput.children.length - 1].text = getGeneralUnitLabel();
            groupCornerRadius.children[groupCornerRadius.children.length - 1].text = getGeneralUnitLabel();
            // Update Text Detail panel unit labels
            groupLeading.children[groupLeading.children.length - 1].text = getTextUnitLabel();
            groupBaseline.children[groupBaseline.children.length - 1].text = getAsianUnitLabel();
        }

        // --- Helper to refresh numeric field values with unit conversion ---
        function refreshValues() {
            var unitCodeKey = app.preferences.getIntegerPreference("rulerType");
            inputKey.text = convertFromPt(pref.getRealPreference("cursorKeyLength"), unitCodeKey).toFixed(1);

            var cornerUnitCode = app.preferences.getIntegerPreference("rulerType");
            inputCornerRadius.text = convertFromPt(pref.getRealPreference("ovalRadius"), cornerUnitCode).toFixed(1);

            var sizeUnitCode = app.preferences.getIntegerPreference("text/units");
            inputLeading.text = convertFromPt(pref.getRealPreference("text/sizeIncrement"), sizeUnitCode).toFixed(1);

            var baselineUnitCode = app.preferences.getIntegerPreference("text/asianunits");
            inputBaseline.text = convertFromPt(pref.getRealPreference("text/riseIncrement"), baselineUnitCode).toFixed(1);
        }

        radioPrintPt.onClick = function() {
            setUnitsForMode("printPt");
            refreshUnitLabels();
        };
        radioPrintQ.onClick = function() {
            setUnitsForMode("printQ");
            refreshUnitLabels();
        };
        radioOnscreen.onClick = function() {
            setUnitsForMode("onscreen");
            refreshUnitLabels();
        };

        /* 右カラム / Right column */
        var rightColumn = mainGroup.add('group');
        rightColumn.orientation = 'column';
        rightColumn.alignChildren = ['fill', 'top'];

        /* テキストパネルを追加 / Add "Text" panel */
        var textPanel = rightColumn.add('panel', undefined, LABELS.textTitle[uiLang]);
        textPanel.orientation = 'column';
        textPanel.alignChildren = ['left', 'top'];
        textPanel.margins = [8, 20, 8, 15];

        var checkboxFontEnglish = textPanel.add('checkbox', undefined, LABELS.fontEnglish[uiLang]);
        checkboxFontEnglish.helpTip = LABELS.tipFontEnglish[uiLang];
        checkboxFontEnglish.value = app.preferences.getBooleanPreference("text/useEnglishFontNames");
        checkboxFontEnglish.onClick = function() {
            app.preferences.setBooleanPreference("text/useEnglishFontNames", checkboxFontEnglish.value === true);
        };

        /* --- 新しい 最近使用したフォントの表示数 ロジック（UI調整） --- */
        var currentRecentCount = app.preferences.getIntegerPreference("text/recentFontMenu/showNEntries");
        var groupRecentFonts = textPanel.add('group');
        groupRecentFonts.orientation = 'row';

        var checkboxRecentFonts = groupRecentFonts.add('checkbox', undefined, LABELS.recentFonts[uiLang]);
        checkboxRecentFonts.helpTip = LABELS.tipRecentFonts[uiLang];
        checkboxRecentFonts.value = (currentRecentCount > 0);

        var inputRecentFonts = groupRecentFonts.add('edittext', undefined, currentRecentCount.toString());
        inputRecentFonts.helpTip = LABELS.tipRecentFonts[uiLang];
        inputRecentFonts.characters = 3;
        inputRecentFonts.enabled = checkboxRecentFonts.value;

        checkboxRecentFonts.onClick = function() {
            if (checkboxRecentFonts.value) {
                if (parseInt(inputRecentFonts.text, 10) === 0 || isNaN(parseInt(inputRecentFonts.text, 10))) {
                    inputRecentFonts.text = "1";
                }
                inputRecentFonts.enabled = true;
                app.preferences.setIntegerPreference("text/recentFontMenu/showNEntries", parseInt(inputRecentFonts.text, 10));
            } else {
                inputRecentFonts.enabled = false;
                inputRecentFonts.text = "0";
                app.preferences.setIntegerPreference("text/recentFontMenu/showNEntries", 0);
            }
        };

        inputRecentFonts.onChange = function() {
            var value = parseInt(inputRecentFonts.text, 10);
            if (!isNaN(value)) {
                app.preferences.setIntegerPreference("text/recentFontMenu/showNEntries", value);
                checkboxRecentFonts.value = (value > 0);
                inputRecentFonts.enabled = checkboxRecentFonts.value;
            }
        };

        var glyphPanel = rightColumn.add('panel', undefined, LABELS.glyphBounds[uiLang]);
        glyphPanel.orientation = 'column';
        glyphPanel.alignChildren = ['left', 'top'];
        glyphPanel.margins = [8, 20, 8, 15];

        var checkboxPoint = glyphPanel.add('checkbox', undefined, LABELS.pointText[uiLang]);
        checkboxPoint.helpTip = LABELS.tipGlyphBounds[uiLang];
        checkboxPoint.value = app.preferences.getBooleanPreference('EnableActualPointTextSpaceAlign');

        var checkboxArea = glyphPanel.add('checkbox', undefined, LABELS.areaText[uiLang]);
        checkboxArea.helpTip = LABELS.tipGlyphBounds[uiLang];
        checkboxArea.value = app.preferences.getBooleanPreference('EnableActualAreaTextSpaceAlign');

        bindCheckboxes([{
                checkbox: checkboxPoint,
                prefKey: 'EnableActualPointTextSpaceAlign'
            },
            {
                checkbox: checkboxArea,
                prefKey: 'EnableActualAreaTextSpaceAlign'
            }
        ]);

        /* その他パネルを追加 / Add "Transform & Align" panel */
        var otherPanel = rightColumn.add('panel', undefined, LABELS.transformTitle[uiLang]);
        otherPanel.orientation = 'column';
        otherPanel.alignChildren = ['left', 'top'];
        otherPanel.margins = [8, 20, 8, 15];

        //　プレビュー境界
        var checkboxPreview = otherPanel.add('checkbox', undefined, LABELS.previewBounds[uiLang]);
        checkboxPreview.helpTip = LABELS.tipPreviewBounds[uiLang];
        checkboxPreview.value = app.preferences.getBooleanPreference("includeStrokeInBounds");
        checkboxPreview.onClick = function() {
            app.preferences.setBooleanPreference("includeStrokeInBounds", checkboxPreview.value === true);
        };

        // パターンを変形
        var checkboxPattern = otherPanel.add('checkbox', undefined, LABELS.transformPattern[uiLang]);
        checkboxPattern.helpTip = LABELS.tipTransformPattern[uiLang];
        checkboxPattern.value = app.preferences.getBooleanPreference("transformPatterns");
        checkboxPattern.onClick = function() {
            app.preferences.setBooleanPreference("transformPatterns", checkboxPattern.value === true);
        };

        // 角を拡大・縮小
        var checkboxCorner = otherPanel.add('checkbox', undefined, LABELS.scaleCorners[uiLang]);
        checkboxCorner.helpTip = LABELS.tipScaleCorners[uiLang];
        // 初期値を取得（1=ON, 2=OFF）
        checkboxCorner.value = (app.preferences.getIntegerPreference("policyForPreservingCorners") === 1);
        checkboxCorner.onClick = function() {
            app.preferences.setIntegerPreference(
                "policyForPreservingCorners",
                checkboxCorner.value ? 1 : 2
            );
        };

        /* 線幅と効果も拡大・縮小 */
        var checkboxStroke = otherPanel.add('checkbox', undefined, LABELS.scaleStroke[uiLang]);
        checkboxStroke.helpTip = LABELS.tipScaleStroke[uiLang];
        checkboxStroke.value = app.preferences.getBooleanPreference("scaleLineWeight");
        checkboxStroke.onClick = function() {
            app.preferences.setBooleanPreference("scaleLineWeight", checkboxStroke.value === true);
        };

        /* リアルタイムの描画と編集 */
        var checkboxRealtime = otherPanel.add('checkbox', undefined, LABELS.realtimeDrawing[uiLang]);
        checkboxRealtime.helpTip = LABELS.tipRealtimeDrawing[uiLang];
        checkboxRealtime.value = app.preferences.getBooleanPreference("LiveEdit_State_Machine");
        checkboxRealtime.onClick = function() {
            app.preferences.setBooleanPreference("LiveEdit_State_Machine", checkboxRealtime.value === true);
        };

        var group2 = dialog.add('group', undefined, {
            name: 'group2'
        });
        group2.orientation = 'row';
        group2.alignChildren = ['center', 'center']; /* 中央揃え */
        group2.alignment = ['center', 'bottom']; /* ダイアログ内で中央に配置 */

        var cancelBtn = group2.add('button', undefined, LABELS.cancel[uiLang], {
            name: 'cancel'
        });
        cancelBtn.preferredSize.width = 90;

        var okBtn = group2.add('button', undefined, LABELS.ok[uiLang], {
            name: 'ok'
        });
        okBtn.preferredSize.width = 90;

        dialog.show();
    }

    main();

})();
