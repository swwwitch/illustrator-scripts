#target illustrator
#targetengine "FontClipboard"
app.preferences.setBooleanPreference('ShowExternalJSXWarning', false);

/*

### 概要

CopyTextAttributesToClipboard.jsx が保存した文字属性を、選択中のテキストへ適用します。
適用する属性はダイアログのチェックボックスで選べ、文字ツールでの部分選択にも対応します。

詳細は README を参照してください。
https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/ApplyTextAttributesFromClipboard.md

### Overview

Applies the text attributes saved by CopyTextAttributesToClipboard.jsx to the current text selection.
Which attributes are applied is chosen with checkboxes in the dialog, and partial selections made with the Type tool are supported.

See the README for details.
https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/ApplyTextAttributesFromClipboard.md

*/

// =========================================
// 基本情報 / Basic info
// =========================================
var SCRIPT_NAME     = "ApplyTextAttributesFromClipboard"; /* スクリプト名 / script name */
var SCRIPT_VERSION  = "v1.3.2";                       /* バージョン / version */
var SCRIPT_AUTHOR   = "Masahiro Takano (@swwwitch)";  /* 作者 / author */
var SCRIPT_RELEASED = "2021-04-10";                   /* 最初のリリース日 / first release date */
var SCRIPT_UPDATED  = "2026-09-19";                   /* 更新日 / last updated */

var SCRIPT_README_JA = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/ApplyTextAttributesFromClipboard.md"; /* README（日本語） */
var SCRIPT_README_EN = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/ApplyTextAttributesFromClipboard.md"; /* README (English) */

// Released under the MIT license
// http://opensource.org/licenses/mit-license.php

(function () {

    function getCurrentLocaleLang() {
        return ($.locale.indexOf("ja") === 0) ? "ja" : "en";
    }

    var uiLang = getCurrentLocaleLang();

    /* 日英ラベル定義 / Japanese-English label definitions */
    var LABELS = {
        dialogTitle: {
            ja: "文字属性を適用",
            en: "Apply Text Attributes"
        },
        previewCheckbox: {
            ja: "プレビュー",
            en: "Preview"
        },
        tipFillGraphicStyleNone: {
            ja: "塗りもグラフィックスタイルも適用しません。文字の属性だけを反映します。",
            en: "Applies neither the fill nor the graphic style. Only the character attributes are copied."
        },
        tipFill: {
            ja: "コピー元の塗りカラーを適用します。",
            en: "Applies the fill color taken from the source."
        },
        tipGraphicStyle: {
            ja: "コピー元に付いていたグラフィックスタイルを適用します。ドキュメントに同名のスタイルが無いと適用できません。",
            en: "Applies the graphic style the source carried. It needs a style of the same name in this document."
        },
        tipPreview: {
            ja: "結果を画面で確認します。キャンセルすると元に戻ります。",
            en: "Shows the result on the canvas. Cancel restores the original state."
        },
        errorNoDocument: {
            ja: "ドキュメントを開いてください。",
            en: "Please open a document."
        },
        errorNoCopiedAttributes: {
            ja: "先に「文字属性をコピー」スクリプトを実行してください。",
            en: "Run the Copy Text Attributes script first."
        },
        errorNoTextSelection: {
            ja: "テキストオブジェクトを選択するか、テキスト編集モードで文字列を選択してください。",
            en: "Select text objects, or select text in text editing mode."
        },
        errorEmptyTextRange: {
            ja: "文字のある範囲を選択してください。",
            en: "Select a text range that contains characters."
        },
        errorNoApplyItem: {
            ja: "適用する項目をひとつ以上選んでください。",
            en: "Select at least one item to apply."
        },
        errorFontNotFoundPrefix: {
            ja: "フォント \"",
            en: "Font \""
        },
        errorFontNotFoundSuffix: {
            ja: "\" が見つかりませんでした。\nこの環境にインストールされていない可能性があります。",
            en: "\" was not found.\nIt may not be installed in this environment."
        },
        fontSizeLeadingPanelTitle: {
            ja: "フォント・サイズ、行送り",
            en: "Font, Size & Leading"
        },
        kerningPanelTitle: {
            ja: "カーニング関連",
            en: "Kerning"
        },
        paragraphOtherPanelTitle: {
            ja: "段落属性ほか",
            en: "Paragraph & Other"
        },
        fillGraphicStylePanelTitle: {
            ja: "塗りとグラフィックスタイル",
            en: "Fill & Graphic Style"
        },
        fillGraphicStyleNoneOption: {
            ja: "しない",
            en: "None"
        },
        graphicStyleLabel: {
            ja: "グラフィックスタイル",
            en: "Graphic Style"
        },
        graphicStyleNotFound: {
            ja: "（未登録）",
            en: "(not in document)"
        },
        fontLabel: {
            ja: "フォント",
            en: "Font"
        },
        sizeLabel: {
            ja: "フォントサイズ",
            en: "Font size"
        },
        leadingLabel: {
            ja: "行送り",
            en: "Leading"
        },
        autoLeadingLabel: {
            ja: "自動行送り",
            en: "Auto leading"
        },
        tsumeLabel: {
            ja: "文字ツメ",
            en: "Tsume"
        },
        trackingLabel: {
            ja: "トラッキング",
            en: "Tracking"
        },
        kerningMethodLabel: {
            ja: "自動カーニング",
            en: "Auto kerning"
        },
        proportionalMetricsLabel: {
            ja: "プロポーショナルメトリクス",
            en: "Proportional metrics"
        },
        orientationLabel: {
            ja: "組み方向",
            en: "Orientation"
        },
        justificationLabel: {
            ja: "行揃え",
            en: "Alignment"
        },
        fillColorLabel: {
            ja: "塗り",
            en: "Fill"
        },
        fillColorNone: {
            ja: "なし",
            en: "None"
        },
        horizontalOrientation: {
            ja: "横組み",
            en: "Horizontal"
        },
        verticalOrientation: {
            ja: "縦組み",
            en: "Vertical"
        },
        onValue: {
            ja: "ON",
            en: "On"
        },
        offValue: {
            ja: "OFF",
            en: "Off"
        },
        notStored: {
            ja: "（未記憶）",
            en: "(not stored)"
        },
        cancelButton: {
            ja: "キャンセル",
            en: "Cancel"
        },
        applyButton: {
            ja: "適用",
            en: "Apply"
        }
    };

    // =========================================
    // UI設定 / UI settings
    // =========================================

    var ATTRIBUTE_LABEL_WIDTH = 185;

    function getLabel(key) {
        return (LABELS[key] && LABELS[key][uiLang]) ? LABELS[key][uiLang] : key;
    }

    function labelText(key) {
        return getLabel(key) + (uiLang === "ja" ? "：" : ":");
    }

    // =========================================
    // 単位ユーティリティ / Unit utilities
    // =========================================

    // =========================================
    // 単位 / Units
    // =========================================

    /* 単位コードに対応する表示ラベルと、1単位あたりのポイント数
       Unit code -> display label and points per unit */
    var UNITS = [
        { label: "in",    pointsPerUnit: 72 },                /* 0 */
        { label: "mm",    pointsPerUnit: 72 / 25.4 },         /* 1 */
        { label: "pt",    pointsPerUnit: 1 },                 /* 2 */
        { label: "pica",  pointsPerUnit: 12 },                /* 3 */
        { label: "cm",    pointsPerUnit: 72 / 2.54 },         /* 4 */
        { label: "Q",     pointsPerUnit: 72 / 25.4 * 0.25 },  /* 5 */
        { label: "px",    pointsPerUnit: 1 },                 /* 6 */
        { label: "ft/in", pointsPerUnit: 72 * 12 },           /* 7 */
        { label: "m",     pointsPerUnit: 72 / 25.4 * 1000 },  /* 8 */
        { label: "yd",    pointsPerUnit: 72 * 36 },           /* 9 */
        { label: "ft",    pointsPerUnit: 72 * 12 }            /* 10 */
    ];

    /* 単位コード5を「歯（H）」と表示する環境設定キー。文字サイズ（text/units）だけ「級（Q）」
       Preference keys that show unit code 5 as H; only the type size (text/units) shows Q */
    var HA_UNIT_PREF_KEYS = { "rulerType": true, "strokeUnits": true, "text/asianunits": true };

    /**
     * 環境設定キーの単位を返す
     * @param {string} [prefKey] - "rulerType"（既定）/ "strokeUnits" / "text/units" / "text/asianunits"
     * @returns {{code: number, label: string, pointsPerUnit: number}} 単位の情報
     */
    function getUnitInfo(prefKey) {
        var unitKey = prefKey || "rulerType";
        var unitCode = app.preferences.getIntegerPreference(unitKey);
        /* 未知のコードは pt に寄せる / unknown codes fall back to points */
        var unit = UNITS[unitCode] || UNITS[2];
        /* 級（Q）と歯（H）は同じ長さだが、文字サイズは「Q」、距離は「H」と呼び分ける */
        var label = (unitCode === 5 && HA_UNIT_PREF_KEYS[unitKey]) ? "H" : unit.label;
        return { code: unitCode, label: label, pointsPerUnit: unit.pointsPerUnit };
    }

    /* 単位コードとpt換算係数のマップ / Unit code to point conversion factor map */
    /* 1単位あたりのpt値を定義 / Defines point value per unit */
    var preferenceUnitPointFactorMap = {
        0: 72,                 // in
        1: 72 / 25.4,          // mm
        2: 1,                  // pt
        3: 12,                 // pica
        4: 72 / 2.54,          // cm
        5: 72 / 25.4 * 0.25,   // Q/H（0.25mm） / Q/H (0.25 mm)
        6: 1,                  // px
        7: 72 * 12,            // ft/in
        8: 72 / 0.0254,        // m
        9: 72 * 36,            // yd
        10: 72 * 12            // ft
    };

    /* pt値を指定単位へ変換 / Convert point value to the specified unit */
    function convertPointsToPreferenceUnit(pointValue, unitCode) {
        var pointFactor = preferenceUnitPointFactorMap[unitCode] || 1;
        return pointValue / pointFactor;
    }

    /* 数値を表示用に丸める / Round number for display */
    function formatNumberForDisplay(value, digits) {
        var multiplier = Math.pow(10, digits);
        var rounded = Math.round(value * multiplier) / multiplier;
        return String(rounded);
    }

    /* pt値を現在の文字単位で表示 / Format point value using current text unit */
    function formatPointValueForDialog(pointValue) {
        var textUnit = getUnitInfo("text/units");
        var unitCode = textUnit.code;
        var textUnitLabel = textUnit.label;
        var displayValue = convertPointsToPreferenceUnit(pointValue, unitCode);
        return formatNumberForDisplay(displayValue, 3) + " " + textUnitLabel;
    }

    // =========================================
    // 塗り色ユーティリティ / Fill color utilities
    // =========================================

    /* 色を安全に複製 / Safely clone a color */
    // 復元・適用時の独立性を保つため、毎回新規インスタンスを返す
    function cloneColor(color) {
        if (!color) return null;
        switch (color.typename) {
            case "RGBColor":
                var rgb = new RGBColor();
                rgb.red = color.red;
                rgb.green = color.green;
                rgb.blue = color.blue;
                return rgb;
            case "CMYKColor":
                var cmyk = new CMYKColor();
                cmyk.cyan = color.cyan;
                cmyk.magenta = color.magenta;
                cmyk.yellow = color.yellow;
                cmyk.black = color.black;
                return cmyk;
            case "GrayColor":
                var gray = new GrayColor();
                gray.gray = color.gray;
                return gray;
            case "SpotColor":
                var spot = new SpotColor();
                spot.spot = color.spot;
                spot.tint = color.tint;
                return spot;
            case "GradientColor":
                var grad = new GradientColor();
                grad.gradient = color.gradient;
                grad.angle = color.angle;
                grad.length = color.length;
                grad.origin = color.origin;
                grad.matrix = color.matrix;
                return grad;
            case "NoColor":
                return new NoColor();
            default:
                return null;
        }
    }

    /* 色を表示用文字列へ整形 / Format color for display */
    function formatColorForDialog(color) {
        if (!color || !color.typename) return getLabel("fillColorNone");
        switch (color.typename) {
            case "RGBColor":
                return "RGB(" + Math.round(color.red) + ", " + Math.round(color.green) + ", " + Math.round(color.blue) + ")";
            case "CMYKColor":
                return "CMYK(" + Math.round(color.cyan) + ", " + Math.round(color.magenta) + ", " + Math.round(color.yellow) + ", " + Math.round(color.black) + ")";
            case "GrayColor":
                return "Gray(" + Math.round(color.gray) + ")";
            case "SpotColor":
                try {
                    return "Spot: " + color.spot.name + " (" + Math.round(color.tint) + "%)";
                } catch (e) {
                    return "Spot";
                }
            case "GradientColor":
                try {
                    return "Gradient: " + color.gradient.name;
                } catch (e) {
                    return "Gradient";
                }
            case "NoColor":
                return getLabel("fillColorNone");
            default:
                return color.typename;
        }
    }

    /* テキスト範囲の塗り色を取得 / Get fill color from text range */
    function getTextRangeFillColor(textRange) {
        try {
            return textRange.characterAttributes.fillColor;
        } catch (e) {
            return null;
        }
    }

    /* テキスト範囲へ塗り色を適用 / Apply fill color to a text range */
    // textRange.characterAttributes に一括代入すると例外が出ないまま無視されてブラックになることがあるため、
    // FillStrokeSwitcher と同じく文字単位の代入を優先し、文字列挙ができないときだけ範囲一括にフォールバックする
    function applyFillColorToTextRange(textRange, color) {
        if (!textRange || !color) return false;

        var characters = null;
        try {
            characters = textRange.characters;
        } catch (e1) {
            characters = null;
        }

        if (characters && characters.length > 0) {
            var appliedAny = false;
            for (var i = 0; i < characters.length; i++) {
                var clonedForChar = cloneColor(color);
                if (!clonedForChar) continue;
                try {
                    characters[i].characterAttributes.fillColor = clonedForChar;
                    appliedAny = true;
                } catch (charError) {
                }
            }
            if (appliedAny) return true;
        }

        /* 文字列挙ができない場合の最終フォールバック / Final fallback when characters cannot be enumerated */
        var clonedForRange = cloneColor(color);
        if (!clonedForRange) return false;
        try {
            textRange.characterAttributes.fillColor = clonedForRange;
            return true;
        } catch (e2) {
        }

        return false;
    }

    // =========================================
    // グラフィックスタイルユーティリティ / Graphic style utilities
    // =========================================

    /* ドキュメント内のグラフィックスタイルを名前で検索 / Find a graphic style by name in the active document */
    function findGraphicStyleByName(name) {
        if (!name) return null;
        try {
            if (!app.activeDocument || !app.activeDocument.graphicStyles) return null;
            for (var i = 0; i < app.activeDocument.graphicStyles.length; i++) {
                try {
                    if (app.activeDocument.graphicStyles[i].name === name) {
                        return app.activeDocument.graphicStyles[i];
                    }
                } catch (graphicStyleNameError) {
                }
            }
        } catch (e) {
        }
        return null;
    }

    /* 名前を指定してグラフィックスタイルを安全に適用 / Apply a graphic style by name safely */
    function applyGraphicStyleSafely(textFrame, graphicStyleName) {
        if (!textFrame || !graphicStyleName) return false;
        var graphicStyle = findGraphicStyleByName(graphicStyleName);
        if (!graphicStyle) return false;
        try {
            graphicStyle.applyTo(textFrame);
            return true;
        } catch (e) {
            return false;
        }
    }

    /* グラフィックスタイル適用前の TextFrame 外観属性を退避 / Capture TextFrame appearance affected by graphic style */
    // 完全な外観復元は不可能だが、塗り・線・不透明度・描画モードを戻すことで多くのケースを救う
    function captureTextFrameAppearance(textFrame) {
        if (!textFrame) return null;
        var captured = {};
        for (var i = 0; i < APPEARANCE_PROPERTIES.length; i++) {
            copyAppearanceProperty(captured, textFrame, APPEARANCE_PROPERTIES[i]);
        }
        return captured;
    }

    /* 退避・復元する TextFrame の外観プロパティ / TextFrame appearance properties that are saved and restored */
    var APPEARANCE_PROPERTIES = [
        { name: "fillColor", isColor: true },
        { name: "strokeColor", isColor: true },
        { name: "filled", isColor: false },
        { name: "stroked", isColor: false },
        { name: "strokeWidth", isColor: false },
        { name: "opacity", isColor: false },
        { name: "blendingMode", isColor: false }
    ];

    /* 退避した TextFrame 外観属性を復元 / Restore captured TextFrame appearance */
    function restoreTextFrameAppearance(textFrame, captured) {
        if (!textFrame || !captured) return;
        for (var i = 0; i < APPEARANCE_PROPERTIES.length; i++) {
            var property = APPEARANCE_PROPERTIES[i];
            if (typeof captured[property.name] === "undefined" || captured[property.name] === null) continue;
            copyAppearanceProperty(textFrame, captured, property);
        }
    }

    /**
     * 外観プロパティを1つ写す
     * 種類によっては持っていないプロパティがあり、読み書きで例外になるため1つずつ受け流す。
     * @param {object} targetObject - 写し先
     * @param {object} sourceObject - 写し元
     * @param {object} property - APPEARANCE_PROPERTIES の1項目
     * @returns {void}
     */
    function copyAppearanceProperty(targetObject, sourceObject, property) {
        try {
            targetObject[property.name] = property.isColor ?
                cloneColor(sourceObject[property.name]) :
                sourceObject[property.name];
        } catch (e) {}
    }

    // =========================================
    // 文字属性ユーティリティ / Text attribute utilities
    // =========================================

    /* 選択から適用対象を取得 / Get apply targets from selection */
    function getApplyTargetsFromSelection(selection) {
        var targets = [];

        if (selection && selection.typename === "TextRange") {
            targets.push({
                textRange: selection,
                textFrame: getParentTextFrameFromTextRange(selection)
            });
            return targets;
        }

        if (selection && selection.length) {
            for (var selectionIndex = 0; selectionIndex < selection.length; selectionIndex++) {
                var selectedItem = selection[selectionIndex];
                if (!selectedItem || selectedItem.typename !== "TextFrame") continue;

                targets.push({
                    textRange: selectedItem.textRange,
                    textFrame: selectedItem
                });
            }
        }

        return targets;
    }

    /* テキスト範囲から親TextFrameを取得 / Get parent TextFrame from text range */
    // テキスト編集モードでは textRange.parent が Story を返すことがあるため
    // story.textFrames 経由で TextFrame を取得する
    function getParentTextFrameFromTextRange(textRange) {
        if (!textRange) return null;
        try {
            var story = textRange.story;
            if (story && story.textFrames && story.textFrames.length > 0) {
                return story.textFrames[0];
            }
        } catch (e) { }
        var parentItem = textRange.parent;
        while (parentItem && parentItem.typename !== "TextFrame") {
            parentItem = parentItem.parent;
        }
        return parentItem || null;
    }

    /* 段落ごとの行揃えを退避 / Capture justification for each paragraph */
    function captureParagraphJustifications(textRange) {
        var justifications = [];
        if (!textRange) return justifications;

        try {
            if (textRange.paragraphs && textRange.paragraphs.length > 0) {
                for (var paragraphIndex = 0; paragraphIndex < textRange.paragraphs.length; paragraphIndex++) {
                    justifications.push(textRange.paragraphs[paragraphIndex].paragraphAttributes.justification);
                }
            }
        } catch (e) {
            try {
                justifications.push(textRange.paragraphAttributes.justification);
            } catch (e2) {
            }
        }

        return justifications;
    }

    /* 段落ごとの行揃えを復元 / Restore justification for each paragraph */
    function restoreParagraphJustifications(textRange, textFrame, justifications) {
        if (!textRange || !justifications || justifications.length === 0) return;

        try {
            if (textRange.paragraphs && textRange.paragraphs.length > 0) {
                for (var paragraphIndex = 0; paragraphIndex < textRange.paragraphs.length; paragraphIndex++) {
                    var sourceIndex = (paragraphIndex < justifications.length) ? paragraphIndex : justifications.length - 1;
                    var originalJustification = justifications[sourceIndex];

                    try {
                        textRange.paragraphs[paragraphIndex].paragraphAttributes.justification = originalJustification;
                    } catch (paragraphAttrError) {
                    }

                    try {
                        textRange.paragraphs[paragraphIndex].justification = originalJustification;
                    } catch (paragraphDirectError) {
                    }
                }
            }
        } catch (e) {
            // 段落単位で復元できない場合でも代表値の復元は続行 / Continue restoring the representative value even if paragraph-level restore fails
        }

        /* 最後に代表値をTextRange/TextFrameへも戻す / Finally restore the representative value to TextRange/TextFrame as well */
        applyJustificationSafely(textRange, textFrame, justifications[0]);
    }

    /* 現在の属性を退避 / Capture current attributes */
    // 混在書式時に値が不定になるのを避けるため先頭文字を基準にする /
    // Use the first character to avoid ambiguous values when formatting is mixed
    function captureCurrentTextAttributes(textRange, textFrame) {
        var firstCharacter = textRange.characters[0];
        var characterAttributes = firstCharacter.characterAttributes;
        var paragraphAttributes = firstCharacter.paragraphAttributes;
        return {
            fontName: characterAttributes.textFont.name,
            size: characterAttributes.size,
            leading: characterAttributes.leading,
            autoLeading: characterAttributes.autoLeading,
            tsume: characterAttributes.Tsume,
            tracking: characterAttributes.tracking,
            kerningMethod: characterAttributes.kerningMethod,
            proportionalMetrics: characterAttributes.proportionalMetrics,
            orientation: textFrame ? textFrame.orientation : null,
            justification: paragraphAttributes.justification,
            paragraphJustifications: captureParagraphJustifications(textRange),
            fillColor: cloneColor(getTextRangeFillColor(firstCharacter)),
            /* グラフィックスタイル適用は TextFrame 外観を書き換えるため、退避しておく
               Graphic style application rewrites the TextFrame appearance, so capture it */
            textFrameAppearance: captureTextFrameAppearance(textFrame)
        };
    }

    /* 実際に適用した属性だけを退避値へ戻す / Restore only applied attributes to captured values */
    // appliedState を受け取り、プレビューで実際に変更した項目だけ退避値へ戻す
    // 混在書式の未適用項目を代表値で上書きしないため、通常の完全復元とは分けて扱う
    // （特に自動カーニングは復元のためにダイナミックアクションを読み込む必要があるため、未適用なら呼び出さない）
    function restoreAppliedTextAttributes(textRange, textFrame, capturedAttributes, appliedState) {
        if (!capturedAttributes) return;
        if (!appliedState) return;

        var characterAttributes = textRange.characterAttributes;

        if (appliedState.applyFont) {
            try {
                characterAttributes.textFont = app.textFonts.getByName(capturedAttributes.fontName);
            } catch (e) {
                // 復元時にフォントが見つからない場合は無視 / Ignore if the font cannot be found while restoring
            }
        }

        if (appliedState.applySize) {
            characterAttributes.size = capturedAttributes.size;
        }

        if (appliedState.applyAutoLeading) {
            characterAttributes.autoLeading = capturedAttributes.autoLeading;
        }

        if (appliedState.applyLeading && !capturedAttributes.autoLeading) {
            characterAttributes.autoLeading = false;
            characterAttributes.leading = capturedAttributes.leading;
        }

        if (appliedState.applyTsume) {
            characterAttributes.Tsume = Math.round(capturedAttributes.tsume);
        }

        if (appliedState.applyTracking) {
            characterAttributes.tracking = capturedAttributes.tracking;
        }

        /* 自動カーニングは適用していないときは復元不要（ダイナミックアクションのロードを避ける） */
        /*   Skip kerning restore unless it was actually applied (avoid loading the dynamic action) */
        if (appliedState && appliedState.applyKerningMethod) {
            applyKerningMethodSafely(characterAttributes, capturedAttributes, textRange);
        }

        if (appliedState.applyProportionalMetrics) {
            characterAttributes.proportionalMetrics = capturedAttributes.proportionalMetrics;
        }

        if (appliedState.applyJustification) {
            if (capturedAttributes.paragraphJustifications && capturedAttributes.paragraphJustifications.length > 0) {
                restoreParagraphJustifications(textRange, textFrame, capturedAttributes.paragraphJustifications);
            }
            if (typeof capturedAttributes.justification !== "undefined" && capturedAttributes.justification !== null) {
                applyJustificationSafely(textRange, textFrame, capturedAttributes.justification);
            }
        }

        if (appliedState.applyOrientation && textFrame && capturedAttributes.orientation !== null && typeof capturedAttributes.orientation !== "undefined") {
            textFrame.orientation = capturedAttributes.orientation;
        }

        /* 適用していたモードに応じて塗り or グラフィックスタイル外観を戻す /
           Restore fill or graphic-style appearance based on the mode that was applied */
        if (appliedState.fillGraphicStyleMode === "fill" && capturedAttributes.fillColor) {
            applyFillColorToTextRange(textRange, capturedAttributes.fillColor);
        } else if (appliedState.fillGraphicStyleMode === "graphicStyle" && capturedAttributes.textFrameAppearance) {
            restoreTextFrameAppearance(textFrame, capturedAttributes.textFrameAppearance);
        }
    }

    /* 複数対象の現在属性を退避 / Capture current attributes for multiple targets */
    function captureCurrentTextAttributesForTargets(targets) {
        var capturedList = [];
        for (var targetIndex = 0; targetIndex < targets.length; targetIndex++) {
            capturedList.push(captureCurrentTextAttributes(targets[targetIndex].textRange, targets[targetIndex].textFrame));
        }
        return capturedList;
    }

    /* 複数対象で実際に適用した属性だけを退避値へ戻す / Restore only applied attributes for multiple targets */
    function restoreAppliedTextAttributesForTargets(targets, capturedList, appliedState) {
        if (!targets || !capturedList) return;
        for (var targetIndex = 0; targetIndex < targets.length; targetIndex++) {
            restoreAppliedTextAttributes(targets[targetIndex].textRange, targets[targetIndex].textFrame, capturedList[targetIndex], appliedState);
        }
    }

    /* 自動カーニングがメトリクスか判定 / Check whether auto kerning is Metrics */
    function isMetricsKerningMethod(copiedAttributes) {
        if (!copiedAttributes) return false;

        try {
            if (copiedAttributes.kerningMethod === AutoKernType.AUTO) return true;
        } catch (e) {
        }

        var kerningMethodLabel = copiedAttributes.kerningMethodLabel;
        if (typeof kerningMethodLabel === "string") {
            return kerningMethodLabel === "メトリクス" || kerningMethodLabel === "Metrics";
        }

        return false;
    }

    /* 自動カーニングがオプティカルか判定 / Check whether auto kerning is Optical */
    function isOpticalKerningMethod(copiedAttributes) {
        if (!copiedAttributes) return false;

        try {
            if (copiedAttributes.kerningMethod === AutoKernType.OPTICAL) return true;
        } catch (e) {
        }

        var kerningMethodLabel = copiedAttributes.kerningMethodLabel;
        if (typeof kerningMethodLabel === "string") {
            return kerningMethodLabel === "オプティカル" || kerningMethodLabel === "Optical";
        }

        return false;
    }

    /* 自動カーニングが0か判定 / Check whether auto kerning is 0 */
    function isZeroKerningMethod(copiedAttributes) {
        if (!copiedAttributes) return false;

        var kerningMethodLabel = copiedAttributes.kerningMethodLabel;
        if (typeof kerningMethodLabel === "string") {
            return kerningMethodLabel === "なし" || kerningMethodLabel === "None";
        }

        try {
            return copiedAttributes.kerningMethod === AutoKernType.NOAUTOKERN;
        } catch (e) {
        }

        return false;
    }

    /* 現在の選択を配列として退避 / Capture current selection as an array */
    function captureSelectionForRestore() {
        var selectionItems = [];

        try {
            if (app.selection && app.selection.length) {
                for (var selectionIndex = 0; selectionIndex < app.selection.length; selectionIndex++) {
                    selectionItems.push(app.selection[selectionIndex]);
                }
            } else if (app.selection) {
                selectionItems.push(app.selection);
            }
        } catch (e) {
        }

        return selectionItems;
    }

    /* 退避した選択を復元 / Restore captured selection */
    function restoreSelectionFromCapture(selectionItems) {
        try {
            app.selection = null;
        } catch (e) {
        }

        if (!selectionItems || selectionItems.length === 0) return;

        try {
            app.selection = selectionItems;
        } catch (e2) {
            try {
                app.selection = selectionItems[0];
            } catch (e3) {
            }
        }
    }

    /* アクション適用前に対象テキスト範囲を選択 / Select target text range before applying an action */
    function selectTextRangeForAction(textRange) {
        if (!textRange) return false;

        try {
            textRange.select();
            return true;
        } catch (e) {
        }

        try {
            app.selection = textRange;
            return true;
        } catch (e2) {
        }

        return false;
    }

    /* 選択を退避・復元しながらアクションを実行 / Run an action while preserving the original selection */
    function runKerningActionWithSelection(textRange, actionFunction) {
        if (!actionFunction) return;

        var originalSelection = captureSelectionForRestore();
        try {
            selectTextRangeForAction(textRange);
            actionFunction();
        } finally {
            restoreSelectionFromCapture(originalSelection);
        }
    }

    /* 自動カーニングを安全に適用 / Apply auto kerning safely */
    function applyKerningMethodSafely(characterAttributes, copiedAttributes, textRange) {
        if (!characterAttributes || !copiedAttributes) return;

        if ((typeof copiedAttributes.kerningMethod === "undefined" || copiedAttributes.kerningMethod === null) &&
            (typeof copiedAttributes.kerningMethodLabel !== "string" || copiedAttributes.kerningMethodLabel.length === 0)) return;

        /* Illustrator ExtendScriptでは自動カーニング／メトリクス・オプティカル・0を取得できても直接適用できないため、対象範囲を選択してからアクションで適用する必要がある / In Illustrator ExtendScript, auto kerning Metrics, Optical, and 0 cannot be applied directly even if they can be read, so it is necessary to select the target range and apply it with an action. */
        if (isMetricsKerningMethod(copiedAttributes)) {
            try {
                runKerningActionWithSelection(textRange, function () { runKerningActionByType('metrics'); });
            } catch (actionError) {
                // アクションでメトリクスを適用できない場合はスキップ / Skip if Metrics cannot be applied by action
            }
            return;
        }

        if (isOpticalKerningMethod(copiedAttributes)) {
            try {
                runKerningActionWithSelection(textRange, function () { runKerningActionByType('optical'); });
            } catch (actionError2) {
                // アクションでオプティカルを適用できない場合はスキップ / Skip if Optical cannot be applied by action
            }
            return;
        }

        if (isZeroKerningMethod(copiedAttributes)) {
            try {
                runKerningActionWithSelection(textRange, function () { runKerningActionByType('zero'); });
            } catch (actionError3) {
                // アクションで0を適用できない場合はスキップ / Skip if 0 cannot be applied by action
            }
            return;
        }

        try {
            characterAttributes.kerningMethod = copiedAttributes.kerningMethod;
        } catch (e) {
            // カーニング方式が現在の文字範囲に適用できない場合はスキップ / Skip if the kerning method cannot be applied to the current text range
        }
    }

    /* 自動カーニング用ダイナミックアクションのキャッシュ / Cache for auto kerning dynamic actions */
    // 同じ種別のアクションを複数テキストへ繰り返し適用しても loadAction が一度で済むよう、現在ロード中の種別を保持する
    // #targetengine "FontClipboard" はエンジンが残り続けるため、main の開始時に必ず resetKerningActionCache() を呼んで初期化する
    var kerningActionCache = {
        setName: 'Kerning',
        loadedType: null,
        aiaBodies: {
            metrics: '/version 3' + '/name [ 7' + ' 4b65726e696e67' + ']' + '/isOpen 1' + '/actionCount 1' + '/action-1 {' + ' /name [ 7' + ' 4d657472696373' + ' ]' + ' /keyIndex 0' + ' /colorIndex 0' + ' /isOpen 1' + ' /eventCount 1' + ' /event-1 {' + ' /useRulersIn1stQuadrant 0' + ' /internalName (adobe_SLOCharacterPalette)' + ' /localizedName [ 6' + ' e69687e5ad97' + ' ]' + ' /isOpen 1' + ' /isOn 1' + ' /hasDialog 0' + ' /parameterCount 1' + ' /parameter-1 {' + ' /key 1635019621' + ' /showInPalette 4294967295' + ' /type (boolean)' + ' /value 0' + ' }' + ' }' + '}',
            optical: '/version 3' + '/name [ 7' + ' 4b65726e696e67' + ']' + '/isOpen 1' + '/actionCount 1' + '/action-1 {' + ' /name [ 7' + ' 4f70746963616c' + ' ]' + ' /keyIndex 0' + ' /colorIndex 0' + ' /isOpen 1' + ' /eventCount 1' + ' /event-1 {' + ' /useRulersIn1stQuadrant 0' + ' /internalName (adobe_SLOCharacterPalette)' + ' /localizedName [ 6' + ' e69687e5ad97' + ' ]' + ' /isOpen 1' + ' /isOn 1' + ' /hasDialog 0' + ' /parameterCount 1' + ' /parameter-1 {' + ' /key 1869638501' + ' /showInPalette 4294967295' + ' /type (boolean)' + ' /value 1' + ' }' + ' }' + '}',
            zero: '/version 3' + '/name [ 7' + ' 4b65726e696e67' + ']' + '/isOpen 1' + '/actionCount 1' + '/action-1 {' + ' /name [ 8' + ' 4b65726e696e6730' + ' ]' + ' /keyIndex 0' + ' /colorIndex 0' + ' /isOpen 1' + ' /eventCount 1' + ' /event-1 {' + ' /useRulersIn1stQuadrant 0' + ' /internalName (adobe_SLOCharacterPalette)' + ' /localizedName [ 6' + ' e69687e5ad97' + ' ]' + ' /isOpen 1' + ' /isOn 1' + ' /hasDialog 0' + ' /parameterCount 1' + ' /parameter-1 {' + ' /key 1801810542' + ' /showInPalette 4294967295' + ' /type (integer)' + ' /value 0' + ' }' + ' }' + '}'
        },
        actionNames: {
            metrics: 'Metrics',
            optical: 'Optical',
            zero: 'Kerning0'
        }
    };

    /* キャッシュ状態を初期化 / Reset cache state */
    // #targetengine の永続性により持ち越される loadedType を毎回クリアする
    function resetKerningActionCache() {
        kerningActionCache.loadedType = null;
    }

    /* 指定種別のダイナミックアクションを必要なときだけ読み込む / Lazy-load the kerning action of the given type */
    function ensureKerningActionLoaded(type) {
        if (kerningActionCache.loadedType === type) return;

        /* 別種別がロード中の場合は入れ替え / Swap if a different type is currently loaded */
        if (kerningActionCache.loadedType !== null) {
            try {
                app.unloadAction(kerningActionCache.setName, '');
            } catch (unloadError) {
            }
            kerningActionCache.loadedType = null;
        }

        var actionBody = kerningActionCache.aiaBodies[type];
        if (!actionBody) return;

        var actionFile = new File(Folder.temp.fsName + '/ScriptAction_Kerning_' + new Date().getTime() + '_' + Math.floor(Math.random() * 100000) + '.aia');
        try {
            actionFile.open('w');
            actionFile.write(actionBody);
            actionFile.close();
            app.loadAction(actionFile);
            kerningActionCache.loadedType = type;
        } finally {
            try {
                if (actionFile.exists) actionFile.remove();
            } catch (removeError) {
            }
        }
    }

    /* キャッシュされたカーニングアクションを実行 / Run a cached kerning action */
    function runKerningActionByType(type) {
        ensureKerningActionLoaded(type);
        if (kerningActionCache.loadedType !== type) return;
        app.doScript(kerningActionCache.actionNames[type], kerningActionCache.setName, false);
    }

    /* 読み込んだカーニングアクションを破棄 / Unload the cached kerning action */
    function unloadCachedKerningAction() {
        if (kerningActionCache.loadedType === null) return;
        try {
            app.unloadAction(kerningActionCache.setName, '');
        } catch (unloadError) {
        }
        kerningActionCache.loadedType = null;
    }

    /* 対応する行揃え値か判定 / Check whether the justification value is supported */
    function isSupportedJustification(justification) {
        try {
            return justification === Justification.LEFT ||
                justification === Justification.CENTER ||
                justification === Justification.RIGHT ||
                justification === Justification.FULLJUSTIFYLASTLINELEFT ||
                justification === Justification.FULLJUSTIFYLASTLINECENTER ||
                justification === Justification.FULLJUSTIFYLASTLINERIGHT ||
                justification === Justification.FULLJUSTIFY;
        } catch (e) {
            return false;
        }
    }

    /* 行揃えを安全に適用 / Apply justification safely */
    function applyJustificationSafely(textRange, textFrame, justification) {
        if (!textRange) return false;
        if (typeof justification === "undefined" || justification === null) return false;
        if (!isSupportedJustification(justification)) return false;

        try {
            textRange.paragraphAttributes.justification = justification;
            return true;
        } catch (e) {
            // textRangeへ直接適用できない場合は段落単位へフォールバック / Fall back to paragraph-level apply
        }

        var applied = false;
        try {
            if (textRange.paragraphs && textRange.paragraphs.length > 0) {
                for (var paragraphIndex = 0; paragraphIndex < textRange.paragraphs.length; paragraphIndex++) {
                    try {
                        textRange.paragraphs[paragraphIndex].paragraphAttributes.justification = justification;
                        applied = true;
                    } catch (paragraphError) {
                        try {
                            textRange.paragraphs[paragraphIndex].justification = justification;
                            applied = true;
                        } catch (paragraphDirectError) {
                        }
                    }
                }
            }
        } catch (e2) {
            // 段落単位で適用できない場合はTextFrame全体へフォールバック / Fall back to the whole TextFrame
        }

        if (applied) return true;

        try {
            if (textFrame && textFrame.textRange) {
                textFrame.textRange.paragraphAttributes.justification = justification;
                return true;
            }
        } catch (e3) {
            // 行揃えが現在の範囲に適用できない場合はスキップ / Skip if justification cannot be applied to the current range
        }

        return false;
    }

    /* コピー済み属性を適用 / Apply copied attributes */
    function applyCopiedTextAttributes(textRange, textFrame, copiedAttributes, uiState) {
        var characterAttributes = textRange.characterAttributes;

        if (uiState.applyFont) {
            try {
                var targetFont = app.textFonts.getByName(copiedAttributes.font.name);
                characterAttributes.textFont = targetFont;
            } catch (e) {
                throw new Error(getLabel("errorFontNotFoundPrefix") + copiedAttributes.font.name + getLabel("errorFontNotFoundSuffix"));
            }
        }

        if (uiState.applySize) {
            characterAttributes.size = copiedAttributes.size;
        }

        if (uiState.applyAutoLeading) {
            characterAttributes.autoLeading = copiedAttributes.autoLeading;
        }

        if (uiState.applyLeading && !copiedAttributes.autoLeading) {
            characterAttributes.autoLeading = false;
            characterAttributes.leading = copiedAttributes.leading;
        }

        if (uiState.applyTsume) {
            characterAttributes.Tsume = Math.round(copiedAttributes.tsume);
        }

        if (uiState.applyTracking) {
            characterAttributes.tracking = copiedAttributes.tracking;
        }

        if (uiState.applyKerningMethod) {
            applyKerningMethodSafely(characterAttributes, copiedAttributes, textRange);
        }

        if (uiState.applyProportionalMetrics) {
            characterAttributes.proportionalMetrics = copiedAttributes.proportionalMetrics;
        }

        if (uiState.applyJustification && typeof copiedAttributes.justification !== "undefined" && copiedAttributes.justification !== null) {
            applyJustificationSafely(textRange, textFrame, copiedAttributes.justification);
        }

        if (uiState.applyOrientation && textFrame && copiedAttributes.orientation !== null) {
            textFrame.orientation = copiedAttributes.orientation;
        }

        /* モードに応じて塗り or グラフィックスタイルを適用 /
           Apply either fill or graphic style depending on the selected mode */
        if (uiState.fillGraphicStyleMode === "fill" && copiedAttributes.fillColor) {
            applyFillColorToTextRange(textRange, copiedAttributes.fillColor);
        } else if (uiState.fillGraphicStyleMode === "graphicStyle" && textFrame && copiedAttributes.graphicStyleName) {
            applyGraphicStyleSafely(textFrame, copiedAttributes.graphicStyleName);
        }
    }

    /* 複数対象へコピー済み属性を適用 / Apply copied attributes to multiple targets */
    function applyCopiedTextAttributesToTargets(targets, copiedAttributes, uiState) {
        for (var targetIndex = 0; targetIndex < targets.length; targetIndex++) {
            applyCopiedTextAttributes(targets[targetIndex].textRange, targets[targetIndex].textFrame, copiedAttributes, uiState);
        }
    }

    /* UI状態を取得 / Read UI state */
    function readApplyUIState(ui) {
        var fillGraphicStyleMode = "none";
        if (ui.rbFill && ui.rbFill.value) {
            fillGraphicStyleMode = "fill";
        } else if (ui.rbGraphicStyle && ui.rbGraphicStyle.value) {
            fillGraphicStyleMode = "graphicStyle";
        }
        return {
            applyFont: ui.cbFont.value,
            applySize: ui.cbSize.value,
            applyLeading: ui.cbLeading.value,
            applyAutoLeading: ui.cbAutoLeading.value,
            applyTsume: ui.cbTsume.value,
            applyTracking: ui.cbTracking.value,
            applyKerningMethod: ui.cbKerningMethod.value,
            applyProportionalMetrics: ui.cbProportionalMetrics.value,
            applyOrientation: ui.cbOrientation.value,
            applyJustification: ui.cbJustification.value,
            fillGraphicStyleMode: fillGraphicStyleMode
        };
    }

    /* 適用対象があるか確認 / Check whether any item should be applied */
    function hasAnyApplyTarget(uiState) {
        return uiState.applyFont ||
            uiState.applySize ||
            uiState.applyLeading ||
            uiState.applyAutoLeading ||
            uiState.applyTsume ||
            uiState.applyTracking ||
            uiState.applyKerningMethod ||
            uiState.applyProportionalMetrics ||
            uiState.applyOrientation ||
            uiState.applyJustification ||
            (uiState.fillGraphicStyleMode && uiState.fillGraphicStyleMode !== "none");
    }

    /* コピー済み属性の有無を確認 / Check whether copied attributes exist */
    function hasCopiedFont(copiedAttributes) {
        return !!(
            copiedAttributes &&
            copiedAttributes.font &&
            typeof copiedAttributes.font.name === "string" &&
            copiedAttributes.font.name.length > 0
        );
    }

    function hasCopiedSize(copiedAttributes) {
        return !!(
            copiedAttributes &&
            typeof copiedAttributes.size === "number" &&
            !isNaN(copiedAttributes.size) &&
            copiedAttributes.size > 0
        );
    }

    function hasCopiedNumber(copiedAttributes, key) {
        return !!(
            copiedAttributes &&
            typeof copiedAttributes[key] === "number" &&
            !isNaN(copiedAttributes[key])
        );
    }

    function hasCopiedBoolean(copiedAttributes, key) {
        return !!(
            copiedAttributes &&
            typeof copiedAttributes[key] === "boolean"
        );
    }

    function hasCopiedOrientation(copiedAttributes) {
        return !!(
            copiedAttributes &&
            copiedAttributes.orientation !== null &&
            typeof copiedAttributes.orientation !== "undefined"
        );
    }

    function hasCopiedJustification(copiedAttributes) {
        return !!(
            copiedAttributes &&
            copiedAttributes.justification !== null &&
            typeof copiedAttributes.justification !== "undefined" &&
            isSupportedJustification(copiedAttributes.justification)
        );
    }

    /* コピー済みの塗り色があるか確認 / Check whether copied fill color exists */
    function hasCopiedFillColor(copiedAttributes) {
        if (!copiedAttributes) return false;
        var color = copiedAttributes.fillColor;
        if (!color || !color.typename) return false;
        return color.typename !== "NoColor";
    }

    /* コピー済みのグラフィックスタイル名があるか確認 / Check whether a copied graphic style name exists */
    function hasCopiedGraphicStyleName(copiedAttributes) {
        return !!(
            copiedAttributes &&
            typeof copiedAttributes.graphicStyleName === "string" &&
            copiedAttributes.graphicStyleName.length > 0
        );
    }

    /* コピー済みの自動カーニングがあるか確認 / Check whether copied auto kerning exists */
    function hasCopiedKerningMethod(copiedAttributes) {
        if (!copiedAttributes) return false;

        if (copiedAttributes.kerningMethod !== null && typeof copiedAttributes.kerningMethod !== "undefined") {
            return true;
        }

        return !!(
            typeof copiedAttributes.kerningMethodLabel === "string" &&
            copiedAttributes.kerningMethodLabel.length > 0
        );
    }

    /* ON/OFF表示を返す / Return ON/OFF display text */
    function formatBooleanForDialog(value) {
        return value ? getLabel("onValue") : getLabel("offValue");
    }

    /* 組み方向表示を返す / Return orientation display text */
    function formatOrientationForDialog(orientation) {
        if (orientation === TextOrientation.VERTICAL) {
            return getLabel("verticalOrientation");
        }
        return getLabel("horizontalOrientation");
    }

    /* ラベル幅を固定したチェックボックス行を追加 / Add checkbox row with fixed label width */
    function addAttributeCheckboxRow(parent, labelKey, valueText, isAvailable, defaultValue, labelWidth) {
        var rowGroup = parent.add("group");
        rowGroup.orientation = "row";
        rowGroup.alignChildren = ["left", "center"];
        rowGroup.spacing = 6;

        var label = rowGroup.add("statictext", undefined, labelText(labelKey));
        label.preferredSize.width = labelWidth;
        label.justify = "right";

        var checkboxLabel = isAvailable ? valueText : getLabel("notStored");
        var checkbox = rowGroup.add("checkbox", undefined, checkboxLabel);
        checkbox.value = isAvailable && defaultValue;
        checkbox.enabled = isAvailable;
        return checkbox;
    }

    /* フォントとスタイルを2行で表示するチェックボックス行を追加 / Add checkbox row that displays font and style in two lines */
    function addFontCheckboxRow(parent, fontText, styleText, isAvailable, defaultValue, labelWidth) {
        var CHECKBOX_TEXT_OFFSET = 22;

        var rowGroup = parent.add("group");
        rowGroup.orientation = "row";
        rowGroup.alignChildren = ["left", "top"];
        rowGroup.spacing = 6;

        var label = rowGroup.add("statictext", undefined, labelText("fontLabel"));
        label.preferredSize.width = labelWidth;
        label.justify = "right";

        var valueGroup = rowGroup.add("group");
        valueGroup.orientation = "column";
        valueGroup.alignChildren = "left";
        valueGroup.spacing = 2;

        var checkboxLabel = isAvailable ? fontText : getLabel("notStored");
        var checkbox = valueGroup.add("checkbox", undefined, checkboxLabel);
        checkbox.value = isAvailable && defaultValue;
        checkbox.enabled = isAvailable;

        if (isAvailable) {
            var styleRow = valueGroup.add("group");
            styleRow.orientation = "row";
            styleRow.alignChildren = ["left", "center"];
            styleRow.spacing = 0;
            styleRow.margins = [0, 5, 0, 0];

            var spacer = styleRow.add("statictext", undefined, "");
            spacer.preferredSize.width = CHECKBOX_TEXT_OFFSET;

            styleRow.add("statictext", undefined, styleText);
        }

        return checkbox;
    }

    /* Optionクリックで対象以外をOFFにする / Turn off other checkboxes with Option-click */
    function bindExclusiveOptionClick(checkboxes) {
        for (var checkboxIndex = 0; checkboxIndex < checkboxes.length; checkboxIndex++) {
            (function (targetCheckbox) {
                targetCheckbox.onClick = function () {
                    if (!ScriptUI.environment.keyboardState.altKey) return;

                    for (var i = 0; i < checkboxes.length; i++) {
                        if (!checkboxes[i].enabled) continue;
                        checkboxes[i].value = (checkboxes[i] === targetCheckbox);
                    }
                };
            })(checkboxes[checkboxIndex]);
        }
    }

    // =========================================
    // メイン処理 / Main process
    // =========================================

    (function () {
        if (app.documents.length === 0) {
            alert(getLabel("errorNoDocument"));
            return;
        }

        /* 同じ #targetengine の $.global.FontClipboard から取得 / Read from $.global.FontClipboard in the same #targetengine */
        var copiedTextAttributes = $.global.FontClipboard;

        var hasFont = hasCopiedFont(copiedTextAttributes);
        var hasSize = hasCopiedSize(copiedTextAttributes);
        var hasLeading = hasCopiedNumber(copiedTextAttributes, "leading");
        var hasAutoLeading = hasCopiedBoolean(copiedTextAttributes, "autoLeading");
        var hasTsume = hasCopiedNumber(copiedTextAttributes, "tsume");
        var hasTracking = hasCopiedNumber(copiedTextAttributes, "tracking");
        var hasKerningMethod = hasCopiedKerningMethod(copiedTextAttributes);
        var hasProportionalMetrics = hasCopiedBoolean(copiedTextAttributes, "proportionalMetrics");
        var hasOrientation = hasCopiedOrientation(copiedTextAttributes);
        var hasJustification = hasCopiedJustification(copiedTextAttributes);
        var hasFillColor = hasCopiedFillColor(copiedTextAttributes);
        var hasGraphicStyleNameStored = hasCopiedGraphicStyleName(copiedTextAttributes);

        if (!hasFont && !hasSize && !hasLeading && !hasAutoLeading && !hasTsume && !hasTracking && !hasKerningMethod && !hasProportionalMetrics && !hasOrientation && !hasJustification && !hasFillColor && !hasGraphicStyleNameStored) {
            alert(getLabel("errorNoCopiedAttributes"));
            return;
        }

        var applyTargets = getApplyTargetsFromSelection(app.selection);

        if (applyTargets.length === 0) {
            alert(getLabel("errorNoTextSelection"));
            return;
        }

        for (var applyTargetIndex = 0; applyTargetIndex < applyTargets.length; applyTargetIndex++) {
            if (applyTargets[applyTargetIndex].textRange.characters.length === 0) {
                alert(getLabel("errorEmptyTextRange"));
                return;
            }
        }

        var canApplyOrientation = true;
        for (var orientationTargetIndex = 0; orientationTargetIndex < applyTargets.length; orientationTargetIndex++) {
            if (!applyTargets[orientationTargetIndex].textFrame) {
                canApplyOrientation = false;
                break;
            }
        }

        /* ダイアログ / Dialog */
        var dlg = new Window("dialog", getLabel("dialogTitle") + " " + SCRIPT_VERSION);
        dlg.alignChildren = "left";
        dlg.margins = [16, 16, 26, 16];
        dlg.spacing = 10;

        var fontDisplay = hasFont ? (copiedTextAttributes.font.family || getLabel("notStored")) : getLabel("notStored");
        var fontStyleDisplay = hasFont ? (copiedTextAttributes.font.style || getLabel("notStored")) : getLabel("notStored");
        var sizeDisplay = hasSize ? formatPointValueForDialog(copiedTextAttributes.size) : getLabel("notStored");
        var leadingDisplay = hasLeading ? formatPointValueForDialog(copiedTextAttributes.leading) : getLabel("notStored");
        var autoLeadingDisplay = hasAutoLeading ? formatBooleanForDialog(copiedTextAttributes.autoLeading) : getLabel("notStored");
        var tsumeDisplay = hasTsume ? String(copiedTextAttributes.tsume) : getLabel("notStored");
        var trackingDisplay = hasTracking ? String(copiedTextAttributes.tracking) : getLabel("notStored");
        var kerningMethodDisplay = hasKerningMethod
            ? (copiedTextAttributes.kerningMethodLabel || String(copiedTextAttributes.kerningMethod))
            : getLabel("notStored");
        var proportionalMetricsDisplay = hasProportionalMetrics ? formatBooleanForDialog(copiedTextAttributes.proportionalMetrics) : getLabel("notStored");
        var orientationDisplay = hasOrientation
            ? (copiedTextAttributes.orientationLabel || formatOrientationForDialog(copiedTextAttributes.orientation))
            : getLabel("notStored");
        var justificationDisplay = hasJustification
            ? (copiedTextAttributes.justificationLabel || String(copiedTextAttributes.justification))
            : getLabel("notStored");
        var fillColorDisplay = hasFillColor
            ? (copiedTextAttributes.fillColorLabel || formatColorForDialog(copiedTextAttributes.fillColor))
            : getLabel("notStored");

        var fontSizeLeadingPanel = dlg.add("panel", undefined, getLabel("fontSizeLeadingPanelTitle"));
        fontSizeLeadingPanel.orientation = "column";
        fontSizeLeadingPanel.alignChildren = "left";
        fontSizeLeadingPanel.margins = [15, 20, 15, 10];
        fontSizeLeadingPanel.spacing = 4;
        fontSizeLeadingPanel.alignment = ["fill", "top"];

        var cbFont = addFontCheckboxRow(fontSizeLeadingPanel, fontDisplay, fontStyleDisplay, hasFont, true, ATTRIBUTE_LABEL_WIDTH);
        var cbSize = addAttributeCheckboxRow(fontSizeLeadingPanel, "sizeLabel", sizeDisplay, hasSize, false, ATTRIBUTE_LABEL_WIDTH);
        var cbLeading = addAttributeCheckboxRow(fontSizeLeadingPanel, "leadingLabel", leadingDisplay, hasLeading, false, ATTRIBUTE_LABEL_WIDTH);
        /* コピー元が自動行送りの場合は、行送りの適用はできないためチェックボックスを無効化
           Disable leading checkbox when the copied source uses auto leading */
        if (hasAutoLeading && copiedTextAttributes.autoLeading === true) {
            cbLeading.enabled = false;
            cbLeading.value = false;
        }
        var cbAutoLeading = addAttributeCheckboxRow(fontSizeLeadingPanel, "autoLeadingLabel", autoLeadingDisplay, hasAutoLeading, false, ATTRIBUTE_LABEL_WIDTH);

        var kerningPanel = dlg.add("panel", undefined, getLabel("kerningPanelTitle"));
        kerningPanel.orientation = "column";
        kerningPanel.alignChildren = "left";
        kerningPanel.margins = [15, 20, 15, 10];
        kerningPanel.spacing = 4;
        kerningPanel.alignment = ["fill", "top"];

        var cbKerningMethod = addAttributeCheckboxRow(kerningPanel, "kerningMethodLabel", kerningMethodDisplay, hasKerningMethod, false, ATTRIBUTE_LABEL_WIDTH);
        var cbProportionalMetrics = addAttributeCheckboxRow(kerningPanel, "proportionalMetricsLabel", proportionalMetricsDisplay, hasProportionalMetrics, false, ATTRIBUTE_LABEL_WIDTH);
        var cbTracking = addAttributeCheckboxRow(kerningPanel, "trackingLabel", trackingDisplay, hasTracking, false, ATTRIBUTE_LABEL_WIDTH);
        var cbTsume = addAttributeCheckboxRow(kerningPanel, "tsumeLabel", tsumeDisplay, hasTsume, false, ATTRIBUTE_LABEL_WIDTH);

        var paragraphOtherPanel = dlg.add("panel", undefined, getLabel("paragraphOtherPanelTitle"));
        paragraphOtherPanel.orientation = "column";
        paragraphOtherPanel.alignChildren = "left";
        paragraphOtherPanel.margins = [15, 20, 15, 10];
        paragraphOtherPanel.spacing = 4;
        paragraphOtherPanel.alignment = ["fill", "top"];

        var cbOrientation = addAttributeCheckboxRow(paragraphOtherPanel, "orientationLabel", orientationDisplay, hasOrientation, false, ATTRIBUTE_LABEL_WIDTH);
        cbOrientation.enabled = hasOrientation && canApplyOrientation;
        var cbJustification = addAttributeCheckboxRow(paragraphOtherPanel, "justificationLabel", justificationDisplay, hasJustification, false, ATTRIBUTE_LABEL_WIDTH);

        /* 塗りとグラフィックスタイル：3択ラジオで排他 / Fill & Graphic Style: 3-way radio */
        var fillGraphicStylePanel = dlg.add("panel", undefined, getLabel("fillGraphicStylePanelTitle"));
        fillGraphicStylePanel.orientation = "column";
        fillGraphicStylePanel.alignChildren = "left";
        fillGraphicStylePanel.margins = [15, 20, 15, 10];
        fillGraphicStylePanel.spacing = 4;
        fillGraphicStylePanel.alignment = ["fill", "top"];

        var hasCopiedGSName = hasCopiedGraphicStyleName(copiedTextAttributes);
        var graphicStyleExistsInDoc = hasCopiedGSName && !!findGraphicStyleByName(copiedTextAttributes.graphicStyleName);
        var graphicStyleRowText;
        if (hasCopiedGSName) {
            graphicStyleRowText = graphicStyleExistsInDoc
                ? copiedTextAttributes.graphicStyleName
                : copiedTextAttributes.graphicStyleName + " " + getLabel("graphicStyleNotFound");
        } else {
            graphicStyleRowText = getLabel("notStored");
        }

        var FILL_GS_RADIO_NAME_WIDTH = 165;

        /* 「しない」行 / "None" row */
        var fgsNoneRow = fillGraphicStylePanel.add("group");
        fgsNoneRow.orientation = "row";
        fgsNoneRow.alignChildren = ["left", "center"];
        fgsNoneRow.spacing = 6;
        var rbFillGraphicStyleNone = fgsNoneRow.add("radiobutton", undefined, getLabel("fillGraphicStyleNoneOption"));
        rbFillGraphicStyleNone.helpTip = getLabel("tipFillGraphicStyleNone");

        /* 「塗り」行 / "Fill" row */
        var fgsFillRow = fillGraphicStylePanel.add("group");
        fgsFillRow.orientation = "row";
        fgsFillRow.alignChildren = ["left", "center"];
        fgsFillRow.spacing = 6;
        var rbFill = fgsFillRow.add("radiobutton", undefined, getLabel("fillColorLabel"));
        rbFill.helpTip = getLabel("tipFill");
        rbFill.preferredSize.width = FILL_GS_RADIO_NAME_WIDTH;
        rbFill.enabled = hasFillColor;
        fgsFillRow.add("statictext", undefined, hasFillColor ? fillColorDisplay : getLabel("notStored"));

        /* 「グラフィックスタイル」行 / "Graphic Style" row */
        var fgsGSRow = fillGraphicStylePanel.add("group");
        fgsGSRow.orientation = "row";
        fgsGSRow.alignChildren = ["left", "center"];
        fgsGSRow.spacing = 6;
        var rbGraphicStyle = fgsGSRow.add("radiobutton", undefined, getLabel("graphicStyleLabel"));
        rbGraphicStyle.helpTip = getLabel("tipGraphicStyle");
        rbGraphicStyle.preferredSize.width = FILL_GS_RADIO_NAME_WIDTH;
        rbGraphicStyle.enabled = graphicStyleExistsInDoc && canApplyOrientation;
        fgsGSRow.add("statictext", undefined, graphicStyleRowText);

        /* 初期選択：Copy 側で保存された fillOrGraphicStyle に従う /
           Default selection: follow the fillOrGraphicStyle saved by the Copy script */
        var copiedFillGSMode = copiedTextAttributes && copiedTextAttributes.fillOrGraphicStyle;
        if (copiedFillGSMode === "graphicStyle" && rbGraphicStyle.enabled) {
            rbGraphicStyle.value = true;
        } else if (copiedFillGSMode === "fill" && rbFill.enabled) {
            rbFill.value = true;
        } else {
            rbFillGraphicStyleNone.value = true;
        }

        /* 別グループに置いたラジオは自動排他にならないので手動で同期する /
           Radios in separate groups are not auto-exclusive in ScriptUI, so sync manually */
        var fillGraphicStyleRadios = [rbFillGraphicStyleNone, rbFill, rbGraphicStyle];
        function enforceFillGraphicStyleExclusivity(selected) {
            for (var fgsIndex = 0; fgsIndex < fillGraphicStyleRadios.length; fgsIndex++) {
                fillGraphicStyleRadios[fgsIndex].value = (fillGraphicStyleRadios[fgsIndex] === selected);
            }
        }

        var attributeCheckboxes = [
            cbFont,
            cbSize,
            cbLeading,
            cbAutoLeading,
            cbKerningMethod,
            cbProportionalMetrics,
            cbTracking,
            cbTsume,
            cbOrientation,
            cbJustification
        ];
        bindExclusiveOptionClick(attributeCheckboxes);

        /* ボタンエリア（cbPreviewを含む）を先に生成し、updatePreviewから安全に参照できるようにする

           Build the button area (including cbPreview) first so updatePreview can reference it safely */

        var buttonArea = dlg.add("group");
        buttonArea.orientation = "row";
        buttonArea.alignChildren = ["fill", "center"];
        buttonArea.alignment = "fill";
        buttonArea.margins = [0, 10, 0, 0];

        var previewGroup = buttonArea.add("group");
        previewGroup.orientation = "row";
        previewGroup.alignChildren = ["left", "center"];
        var cbPreview = previewGroup.add("checkbox", undefined, getLabel("previewCheckbox"));
        cbPreview.helpTip = getLabel("tipPreview");
        cbPreview.value = false;

        var spacer = buttonArea.add("group");
        spacer.alignment = ["fill", "center"];
        spacer.minimumSize.width = 20;

        var btnGroup = buttonArea.add("group");
        btnGroup.orientation = "row";
        btnGroup.alignment = ["right", "center"];
        btnGroup.add("button", undefined, getLabel("cancelButton"), { name: "cancel" });
        btnGroup.add("button", undefined, getLabel("applyButton"), { name: "ok" });

        /* スクリプト実行ごとにアクションキャッシュを初期化（#targetengine の永続性対策）
           Reset the action cache at the start of each run (handles #targetengine persistence) */
        resetKerningActionCache();

        var originalTextAttributesList = captureCurrentTextAttributesForTargets(applyTargets);
        var isPreviewApplied = false;
        /* 直近の適用状態を保持し、復元時に「実際に適用した項目だけ戻す」判定に使う
           Track the last applied state so restore can selectively undo only what was applied */
        var lastAppliedState = null;

        try {
            function removePreview() {
                if (!isPreviewApplied) return;
                restoreAppliedTextAttributesForTargets(applyTargets, originalTextAttributesList, lastAppliedState);
                isPreviewApplied = false;
                lastAppliedState = null;
            }

            function updatePreview() {
                if (!cbPreview.value) {
                    removePreview();
                    return;
                }

                try {
                    removePreview();
                    var previewState = readApplyUIState({
                        cbFont: cbFont,
                        cbSize: cbSize,
                        cbLeading: cbLeading,
                        cbAutoLeading: cbAutoLeading,
                        cbTsume: cbTsume,
                        cbTracking: cbTracking,
                        cbKerningMethod: cbKerningMethod,
                        cbProportionalMetrics: cbProportionalMetrics,
                        cbOrientation: cbOrientation,
                        cbJustification: cbJustification,
                        rbFill: rbFill,
                        rbGraphicStyle: rbGraphicStyle
                    });
                    applyCopiedTextAttributesToTargets(applyTargets, copiedTextAttributes, previewState);
                    isPreviewApplied = true;
                    lastAppliedState = previewState;
                    app.redraw();
                } catch (e) {
                    restoreAppliedTextAttributesForTargets(applyTargets, originalTextAttributesList, lastAppliedState);
                    isPreviewApplied = false;
                    lastAppliedState = null;
                    cbPreview.value = false;
                    alert(e.message);
                }
            }

            cbPreview.onClick = updatePreview;

            for (var previewCheckboxIndex = 0; previewCheckboxIndex < attributeCheckboxes.length; previewCheckboxIndex++) {
                attributeCheckboxes[previewCheckboxIndex].onClick = (function (originalOnClick) {
                    return function () {
                        if (originalOnClick) originalOnClick.call(this);
                        updatePreview();
                    };
                })(attributeCheckboxes[previewCheckboxIndex].onClick);
            }

            /* 塗り/グラフィックスタイルのラジオ：排他化＋プレビュー更新 /
               Fill/Graphic-style radios: enforce exclusivity and trigger preview */
            for (var fgsRadioIndex = 0; fgsRadioIndex < fillGraphicStyleRadios.length; fgsRadioIndex++) {
                (function (radioButton) {
                    radioButton.onClick = function () {
                        enforceFillGraphicStyleExclusivity(radioButton);
                        updatePreview();
                    };
                })(fillGraphicStyleRadios[fgsRadioIndex]);
            }

            var dialogResult = dlg.show();
            if (dialogResult !== 1) {
                restoreAppliedTextAttributesForTargets(applyTargets, originalTextAttributesList, lastAppliedState);
                isPreviewApplied = false;
                lastAppliedState = null;
                return;
            }

            var applyState = readApplyUIState({
                cbFont: cbFont,
                cbSize: cbSize,
                cbLeading: cbLeading,
                cbAutoLeading: cbAutoLeading,
                cbTsume: cbTsume,
                cbTracking: cbTracking,
                cbKerningMethod: cbKerningMethod,
                cbProportionalMetrics: cbProportionalMetrics,
                cbOrientation: cbOrientation,
                cbJustification: cbJustification,
                rbFill: rbFill,
                rbGraphicStyle: rbGraphicStyle
            });

            if (!hasAnyApplyTarget(applyState)) {
                restoreAppliedTextAttributesForTargets(applyTargets, originalTextAttributesList, lastAppliedState);
                isPreviewApplied = false;
                lastAppliedState = null;
                alert(getLabel("errorNoApplyItem"));
                return;
            }

            /* 適用 / Apply */
            // textRange 全体に対して characterAttributes を書き換える / Rewrite characterAttributes for the entire textRange
            // プレビューONで表示済みの状態は適用内容と一致するため、戻す→再適用はスキップ /
            // When preview is ON, the on-screen state already matches applyState, so skip the revert/re-apply cycle
            try {
                if (isPreviewApplied && cbPreview.value) {
                    isPreviewApplied = false;
                    /* lastAppliedState は表示中の状態を保持し続ける / Keep lastAppliedState reflecting the current on-screen state */
                } else {
                    removePreview();
                    applyCopiedTextAttributesToTargets(applyTargets, copiedTextAttributes, applyState);
                    lastAppliedState = applyState;
                }
            } catch (e) {
                restoreAppliedTextAttributesForTargets(applyTargets, originalTextAttributesList, lastAppliedState);
                isPreviewApplied = false;
                lastAppliedState = null;
                alert(e.message);
                return;
            }
        } finally {
            /* スクリプト終了時にダイナミックアクションをアンロード / Unload the dynamic action when the script ends */
            unloadCachedKerningAction();
        }
    })();

})();
