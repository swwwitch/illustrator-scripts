#target illustrator
app.preferences.setBooleanPreference('ShowExternalJSXWarning', false);

/*

### 概要

選択中の2つのテキストオブジェクトの内容を入れ替えます。
入れ替える対象（文字列／スタイル／座標）はダイアログで選べます。

詳細は README を参照してください。
https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/SwapTextSpecial.md

note記事も参照してください。
https://note.com/dtp_tranist/n/n071e09af28a7

### Overview

Swaps the contents of two selected text objects.
A dialog picks what is swapped: the contents, the style, or the position.

See the README for details.
https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/SwapTextSpecial.md

*/

// =========================================
// 基本情報 / Basic info
// =========================================
var SCRIPT_NAME     = "SwapTextSpecial";              /* スクリプト名 / script name */
var SCRIPT_VERSION  = "v1.0.1";                       /* バージョン / version */
var SCRIPT_AUTHOR   = "Masahiro Takano (@swwwitch)";  /* 作者 / author */
var SCRIPT_RELEASED = "";                             /* 最初のリリース日 / first release date */
var SCRIPT_UPDATED  = "2026-09-19";                             /* 更新日 / last updated */

var SCRIPT_README_JA   = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/SwapTextSpecial.md"; /* README（日本語） */
var SCRIPT_README_EN   = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/SwapTextSpecial.md"; /* README (English) */
var SCRIPT_ARTICLE_URL = "https://note.com/dtp_tranist/n/n071e09af28a7"; /* 紹介記事 / article URL */

// Released under the MIT license
// http://opensource.org/licenses/mit-license.php

(function () {

    var uiLang = (function () {
        /* 日本語 / English */
        return ($.locale && $.locale.indexOf("ja") === 0) ? "ja" : "en";
    })();

    function getLabel(obj) {
        return obj[uiLang] || obj.en;
    }

    var LABELS = {
        dialogTitle: { ja: "テキストの入れ替え " + SCRIPT_VERSION, en: "Swap Text " + SCRIPT_VERSION },
        panelTarget: { ja: "入れ替える対象", en: "Swap target" },
        modeContents: { ja: "文字列", en: "String" },
        modeFormat: { ja: "書式", en: "Format" },
        modePosition: { ja: "座標", en: "Position" },
        cancel: { ja: "キャンセル", en: "Cancel" },
        noDocument: { ja: "ドキュメントが開かれていません。", en: "No document is open." },
        needTwo: { ja: "テキストオブジェクトを2つ選択してください。", en: "Please select two text objects." },
        needText: { ja: "選択した2つは両方ともテキストオブジェクトである必要があります。", en: "Both selected objects must be text objects." },
        tipModeContents: { ja: "2つのテキストの文字列だけを入れ替えます。書式と位置はそのままです。", en: "Swaps only the strings. The formatting and positions stay put." },
        tipModeFormat: { ja: "フォント・サイズ・色などの書式だけを入れ替えます。文字列と位置はそのままです。", en: "Swaps only the formatting, such as font, size, and colour. The strings and positions stay put." },
        tipModePosition: { ja: "2つのテキストの位置だけを入れ替えます。中身はそのままです。", en: "Swaps only the positions. The contents stay put." }
    };

    // =============================================================
    // ダイアログ / Dialog
    // =============================================================

    function showSwapDialog() {
        var dialog = new Window("dialog", getLabel(LABELS.dialogTitle));
        dialog.alignChildren = "fill";

        var targetPanel = dialog.add("panel", undefined, getLabel(LABELS.panelTarget));
        targetPanel.orientation = "column";
        targetPanel.alignChildren = "left";
        targetPanel.margins = [15, 20, 15, 15];

        var radioContents = targetPanel.add("radiobutton", undefined, getLabel(LABELS.modeContents));
        radioContents.helpTip = getLabel(LABELS.tipModeContents);
        var radioFormat = targetPanel.add("radiobutton", undefined, getLabel(LABELS.modeFormat));
        radioFormat.helpTip = getLabel(LABELS.tipModeFormat);
        var radioPosition = targetPanel.add("radiobutton", undefined, getLabel(LABELS.modePosition));
        radioPosition.helpTip = getLabel(LABELS.tipModePosition);
        radioContents.value = true;

        var buttonGroup = dialog.add("group");
        buttonGroup.alignment = "right";
        var cancelButton = buttonGroup.add("button", undefined, getLabel(LABELS.cancel), { name: "cancel" });
        var okButton = buttonGroup.add("button", undefined, "OK", { name: "ok" });

        if (dialog.show() !== 1) {
            return null;
        }

        if (radioFormat.value) return "format";
        if (radioPosition.value) return "position";
        return "contents";
    }

    // =============================================================
    // 入れ替え処理 / Swap operations
    // =============================================================

    function swapContents(firstTextFrame, secondTextFrame) {
        var firstContents = firstTextFrame.contents;
        var secondContents = secondTextFrame.contents;
        firstTextFrame.contents = secondContents;
        secondTextFrame.contents = firstContents;
    }

    /*
       入れ替える書式（characterAttributes）の一覧。
       List of character attributes to swap. textFont はフォント＋スタイルを兼ねる。
    */
    var FORMAT_ATTRIBUTE_KEYS = [
        "textFont",        /* フォント＋スタイル / font family + style */
        "size",            /* サイズ / size */
        "fillColor",       /* 文字カラー / text color */
        "strokeColor",     /* 線カラー / stroke color */
        "strokeWeight",    /* 線幅 / stroke weight */
        "tracking",        /* トラッキング / tracking */
        "leading",         /* 行送り / leading */
        "autoLeading",     /* 自動行送り / auto leading */
        "horizontalScale", /* 水平比率 / horizontal scale */
        "verticalScale",   /* 垂直比率 / vertical scale */
        "baselineShift",   /* ベースラインシフト / baseline shift */
        "capitalization"   /* 大文字小文字 / capitalization */
    ];

    function captureFormatAttributes(textFrame) {
        var attributes = textFrame.textRange.characterAttributes;
        var captured = {};
        for (var i = 0; i < FORMAT_ATTRIBUTE_KEYS.length; i++) {
            var key = FORMAT_ATTRIBUTE_KEYS[i];
            try {
                captured[key] = attributes[key];
            } catch (e) {}
        }
        return captured;
    }

    function applyFormatAttributes(textFrame, captured) {
        var attributes = textFrame.textRange.characterAttributes;
        for (var i = 0; i < FORMAT_ATTRIBUTE_KEYS.length; i++) {
            var key = FORMAT_ATTRIBUTE_KEYS[i];
            if (!captured.hasOwnProperty(key)) continue;
            try {
                attributes[key] = captured[key];
            } catch (e) {}
        }
    }

    function swapFormat(firstTextFrame, secondTextFrame) {
        /* 両方の書式を先に取得してから入れ替える / Capture both before applying */
        var firstAttributes = captureFormatAttributes(firstTextFrame);
        var secondAttributes = captureFormatAttributes(secondTextFrame);
        applyFormatAttributes(firstTextFrame, secondAttributes);
        applyFormatAttributes(secondTextFrame, firstAttributes);
    }

    function swapPosition(firstTextFrame, secondTextFrame) {
        /*
           position はベースライン基準で上端/左端が崩れるため geometricBounds を使う。
           Use geometricBounds (not position) because TextFrame.position is baseline-based.
           geometricBounds = [left, top, right, bottom]
        */
        app.redraw(); // bounds が更新されない環境対策 / refresh stale bounds

        var firstBounds = firstTextFrame.geometricBounds;
        var secondBounds = secondTextFrame.geometricBounds;

        var deltaX = secondBounds[0] - firstBounds[0];
        var deltaY = secondBounds[1] - firstBounds[1];

        firstTextFrame.translate(deltaX, deltaY);
        secondTextFrame.translate(-deltaX, -deltaY);
    }

    // =============================================================
    // メイン / Main
    // =============================================================

    function main() {
        if (app.documents.length === 0) {
            alert(getLabel(LABELS.noDocument));
            return;
        }

        var doc = app.activeDocument;
        var selectedItems = doc.selection;

        if (selectedItems.length !== 2) {
            alert(getLabel(LABELS.needTwo));
            return;
        }
        if (selectedItems[0].typename !== "TextFrame" || selectedItems[1].typename !== "TextFrame") {
            alert(getLabel(LABELS.needText));
            return;
        }

        var mode = showSwapDialog();
        if (mode === null) {
            return;
        }

        var firstTextFrame = selectedItems[0];
        var secondTextFrame = selectedItems[1];

        if (mode === "format") {
            swapFormat(firstTextFrame, secondTextFrame);
        } else if (mode === "position") {
            swapPosition(firstTextFrame, secondTextFrame);
        } else {
            swapContents(firstTextFrame, secondTextFrame);
        }
    }

    main();

})();
