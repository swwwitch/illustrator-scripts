#target illustrator
app.preferences.setBooleanPreference('ShowExternalJSXWarning', false);
#targetengine "SwwwitchPalettes"
/*
SCRIPTMETA-BEGIN
Script-ID=com.swwwitch.illustrator.ArtboardNavigatorPalette
Name=アートボードナビゲーター
Author=Masahiro Takano (@swwwitch)
Target-App=Illustrator
Version=1.2.15
Description-BEGIN
アートボード間をなめらかにズーム移動する常駐パレットです。
先頭・前・全体表示・次・末尾のボタンとキーボードショートカットで移動できます。

A persistent palette for moving smoothly between artboards, zooming as it goes.
Buttons and keyboard shortcuts cover first, previous, fit-all, next and last.
Description-END
SCRIPTMETA-END
*/

/*

### 概要

アートボード間をなめらかにズーム移動する常駐パレットです。
先頭・前・全体表示・次・末尾のボタンとキーボードショートカットで移動できます。

詳細は README を参照してください。
https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/ArtboardNavigatorPalette.md

note記事も参照してください。
https://note.com/dtp_tranist/n/nee7de364c3dc

### Overview

A persistent palette for moving smoothly between artboards, zooming as it goes.
Buttons and keyboard shortcuts cover first, previous, fit-all, next and last.

See the README for details.
https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/ArtboardNavigatorPalette.md

*/

// =========================================
// 基本情報 / Basic info
// =========================================
var SCRIPT_NAME     = "ArtboardNavigatorPalette";     /* スクリプト名 / script name */
var SCRIPT_VERSION  = "v1.2.15";                      /* バージョン / version */
var SCRIPT_AUTHOR   = "Masahiro Takano (@swwwitch)";  /* 作者 / author */
var SCRIPT_RELEASED = "";                             /* 最初のリリース日 / first release date */
var SCRIPT_UPDATED  = "2026-10-10";                   /* 更新日 / last updated */

var SCRIPT_DESCRIPTION_JA = "アートボードナビゲーター"; /* README の見出し / README title (Japanese) */

var SCRIPT_README_JA   = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/ArtboardNavigatorPalette.md"; /* README（日本語） */
var SCRIPT_README_EN   = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/ArtboardNavigatorPalette.md"; /* README (English) */
var SCRIPT_ARTICLE_URL = "https://note.com/dtp_tranist/n/nee7de364c3dc"; /* 紹介記事 / article URL */
var SCRIPT_SOURCE_URL  = "https://github.com/swwwitch/illustrator-scripts/blob/master/jsx/artboard/ArtboardNavigatorPalette.jsx"; /* 最新版のソース / latest source */

// Released under the MIT license
// http://opensource.org/licenses/mit-license.php

(function () {
    // =========================================
    // ユーザー設定 / User Settings
    // =========================================

    // アートボードラベルの見た目（ここで自由に調整できる） / Tunable label appearance
    var LABEL_BACKGROUND_OPACITY = 80; // 背景の長方形の不透明度（%）/ background opacity (%)
    var LABEL_TEXT_OPACITY = 100;      // アートボード名（文字）の不透明度（%）/ text opacity (%)
    var LABEL_FONT_RATIO = 0.03;       // 文字サイズ＝アートボード幅 × この比率 / font size = artboard width × this ratio

    // =========================================
    // レイアウト / Layout
    // =========================================
    var PALETTE_PREFERRED_SIZE = [210, 200];       /* パレットの初期サイズ / initial palette size */
    var NAV_BUTTON_SIZE = 26;                      /* ナビゲーションボタンの一辺 / side of a navigation button */
    var NAV_BUTTON_SPACING = 7;                    /* ナビゲーションボタンの間隔 / spacing between navigation buttons */
    var NAV_BUTTON_ROW_MARGINS = [5, 5, 5, 10];    /* ボタン行の余白（下だけ +5）/ button row margins (+5 at the bottom) */
    var SLIDER_PREFERRED_SIZE = [120, -1];         /* スライダーの幅 / slider width */
    var LIST_TOGGLE_ROW_MARGINS = 5;               /* 「アートボード一覧」行の余白 / margins of the list toggle row */
    var LIST_COLUMN_WIDTHS = [44, 156];            /* 一覧の列幅（番号｜名前）/ list column widths */
    var LIST_PREFERRED_SIZE = [210, 150];          /* 一覧の初期サイズ / initial list size */

    // UIレイアウト（再利用パーツ） / UI layout (reusable)

    /* ウィンドウ・パネルの余白と間隔 / Window & panel margins and spacing */
    var WINDOW_MARGINS = 16;                 /* ウィンドウ外周の余白 / window margin */
    var WINDOW_SPACING = 12;                 /* ウィンドウ内の要素間隔 / window spacing */
    var PANEL_MARGINS  = [16, 20, 16, 12];   /* パネル余白 [左,上,右,下] / panel margins */
    var PANEL_SPACING  = 12;                 /* パネル内の要素間隔 / panel spacing */
    var COLUMN_SPACING = 12;                 /* 2カラムの間隔 / gap between columns */
    var TAB_MARGINS    = [15, 20, 5, 10];    /* タブ余白 [左,上,右,下] / tab margins */

    /**
     * ウィンドウの共通設定
     * @param {Window} targetWindow - 対象のウィンドウ
     * @param {number} [spacing] - 要素間隔（省略時は WINDOW_SPACING）
     * @returns {void}
     */
    function setupWindow(targetWindow, spacing) {
        targetWindow.orientation = "column";
        targetWindow.alignChildren = "fill";
        targetWindow.margins = WINDOW_MARGINS;
        targetWindow.spacing = (typeof spacing === "number") ? spacing : WINDOW_SPACING;
    }

    /**
     * パネルの共通設定（子は幅いっぱい。ボタンは alignment = "left" で広げない）
     * @param {Panel} targetPanel - 対象のパネル
     * @param {number} [spacing] - 要素間隔（省略時は PANEL_SPACING）
     * @returns {void}
     */
    function setupPanel(targetPanel, spacing) {
        targetPanel.orientation = "column";
        targetPanel.alignChildren = ["fill", "top"];
        targetPanel.alignment = "fill";
        targetPanel.margins = PANEL_MARGINS;
        targetPanel.spacing = (typeof spacing === "number") ? spacing : PANEL_SPACING;
    }

    /**
     * タブの共通設定
     * @param {Tab} targetTab - 対象のタブ
     * @param {number} [spacing] - 要素間隔（省略時は変えない）
     * @returns {void}
     */
    function setupTab(targetTab, spacing) {
        targetTab.orientation = "column";
        targetTab.alignChildren = "fill";
        targetTab.margins = TAB_MARGINS;
        if (typeof spacing === "number") targetTab.spacing = spacing;
    }

    /**
     * 横並びの行グループの共通設定（ボタン列など）。
     * alignment と alignChildren を対で指定し、中のボタンが横に伸びたり天地がずれたりしないようにする
     * @param {Group} rowGroup - 対象のグループ
     * @param {string|string[]} [rowAlignment] - 横方向の alignment（省略時は "left"）。配列ならそのまま使う
     * @param {number} [spacing] - 要素間隔（省略時は PANEL_SPACING）
     * @returns {void}
     */
    function setupRow(rowGroup, rowAlignment, spacing) {
        rowGroup.orientation = "row";
        rowGroup.alignment = (rowAlignment instanceof Array) ? rowAlignment : [rowAlignment || "left", "center"];
        rowGroup.alignChildren = ["left", "center"];
        rowGroup.spacing = (typeof spacing === "number") ? spacing : PANEL_SPACING;
    }

    /**
     * ボタンの高さを指定した px だけ詰める（レイアウトが決まったあとに呼ぶ）
     * @param {Button} targetButton - 対象のボタン
     * @param {number} trimPixels - 詰める量（px）
     * @returns {void}
     */
    function trimButtonHeight(targetButton, trimPixels) {
        /* レイアウト前は size が無い / size is not set until the layout runs */
        if (!targetButton.size) return;
        targetButton.size = [targetButton.size.width, targetButton.size.height - trimPixels];
    }

    // UIレイアウト（再利用パーツ）ここまで / End of the reusable UI layout

    // =========================================
    // ローカライズ / Localization
    // =========================================

    // ローカライズ（再利用パーツ） / Localization (reusable)

    /**
     * UI の言語を返す（"ja" で始まるロケールは日本語、それ以外は英語）
     * @returns {string} "ja" または "en"
     */
    function getCurrentLang() {
        return (String($.locale || "").indexOf("ja") === 0) ? "ja" : "en";
    }

    var uiLang = getCurrentLang();

    /**
     * LABELS から今の UI 言語の文言を取り出す。
     * @param {string|Object} labelRef - "dialog.title" のようなパス、または { ja, en }
     * @param {Object|Array} [placeholderValues] - { name: 値 } なら {name} を、[値, …] なら %1, %2 … を差し込む
     * @returns {string} 文言。パスが見つからなければパスの文字列、{ ja, en } が無ければ空文字
     */
    function getLabel(labelRef, placeholderValues) {
        var labelEntry = labelRef;
        if (typeof labelRef === "string") {
            var labelPathKeys = labelRef.split(".");
            labelEntry = LABELS;
            for (var i = 0; i < labelPathKeys.length && labelEntry != null; i++) {
                labelEntry = labelEntry[labelPathKeys[i]];
            }
        }
        var labelString;
        if (typeof labelEntry === "string") labelString = labelEntry;
        else if (labelEntry != null && labelEntry[uiLang] != null) labelString = labelEntry[uiLang];
        else if (labelEntry != null && labelEntry.en != null) labelString = labelEntry.en;
        else return (typeof labelRef === "string") ? labelRef : "";
        return fillLabelPlaceholders(String(labelString), placeholderValues);
    }

    /**
     * 項目名の文言の末尾にコロンを付ける（日本語は半角スペース＋半角コロン「 :」、英語は「:」。Illustrator の線パネルなどの項目名に合わせる）
     * @param {string|Object} labelRef - getLabel と同じ
     * @param {Object|Array} [placeholderValues] - getLabel と同じ
     * @returns {string} コロン付きの文言
     */
    function labelText(labelRef, placeholderValues) {
        return getLabel(labelRef, placeholderValues) + (uiLang === "ja" ? " :" : ":");
    }

    /**
     * 「項目名 : 値」の1行を返す（日本語は「件数 : 5」、英語は「Count: 5」。どちらもコロンのあとに空白を入れる）
     * @param {string|Object} labelRef - getLabel と同じ
     * @param {string|number} value - コロンのあとに続ける値
     * @returns {string} 項目名と値をつないだ文字列
     */
    function labelValueText(labelRef, value) {
        return labelText(labelRef) + " " + value;
    }

    /**
     * 文言の {name} や %1 に値を差し込む
     * @param {string} labelString - 文言
     * @param {Object|Array} [placeholderValues] - { name: 値 } または [値, …]
     * @returns {string} 差し込んだ文言
     */
    function fillLabelPlaceholders(labelString, placeholderValues) {
        if (placeholderValues == null) return labelString;
        if (placeholderValues instanceof Array) {
            /* 大きい番号から置き換え、%1 が %10 の一部を置き換えないようにする / Replace from the highest index so %1 does not eat into %10 */
            for (var i = placeholderValues.length; i >= 1; i--) {
                labelString = labelString.split("%" + i).join(String(placeholderValues[i - 1]));
            }
            return labelString;
        }
        for (var placeholderKey in placeholderValues) {
            if (!placeholderValues.hasOwnProperty(placeholderKey)) continue;
            labelString = labelString.split("{" + placeholderKey + "}").join(String(placeholderValues[placeholderKey]));
        }
        return labelString;
    }

    // ローカライズ（再利用パーツ）ここまで / End of the reusable localization

    var LABELS = {
        dialog: {
            title: { ja: "アートボードナビゲーター", en: "Artboard Navigator" }
        },
        alert: {
            needIllustrator: { ja: "Adobe Illustratorで実行してください。", en: "Please run this in Adobe Illustrator." },
            needArtboards: { ja: "アートボードが2つ以上あるドキュメントで実行してください。", en: "Please run this on a document with two or more artboards." }
        },
        tooltip: {
            first: { ja: "最初のアートボードへ", en: "First artboard" },
            prev: { ja: "前のアートボードへ (Ctrl+Shift+Opt+←)", en: "Previous artboard (Ctrl+Shift+Opt+←)" },
            list: { ja: "すべてのアートボードを画面に収める (Ctrl+Shift+Opt+↑)", en: "Fit all artboards in the window (Ctrl+Shift+Opt+↑)" },
            next: { ja: "次のアートボードへ (Ctrl+Shift+Opt+→)", en: "Next artboard (Ctrl+Shift+Opt+→)" },
            last: { ja: "最後のアートボードへ", en: "Last artboard" },
            animation: {
                ja: "OFFにすると、補間せずに移動先へ瞬時に切り替えます。",
                en: "When off, jumps to the destination instantly without animating."
            },
            speed: { ja: "移動アニメーションの速さです。右ほど速くなります。", en: "Speed of the move animation. Faster toward the right." },
            ease: {
                ja: "ONで終わりに向けて減速し、OFFで等速に移動します。",
                en: "Slows down toward the end when on; moves at a constant speed when off."
            },
            prezi: {
                ja: "個別のアートボードへ移動するとき、途中で一度ズームアウトしてから寄せます。",
                en: "Zooms out partway through each move to an artboard, then zooms back in."
            },
            preziDip: {
                ja: "Preziライクモードで途中に引くズームの量です。右ほど大きく引きます。",
                en: "How far to zoom out mid-move in Prezi-like mode. Stronger toward the right."
            },
            showLabel: {
                ja: "移動先のアートボードの左上に「番号：名前」を表示します（プリントされない専用レイヤーに描画）。",
                en: "Shows \"number: name\" at the top left of the destination artboard, on a dedicated non-printing layer."
            },
            listVisible: { ja: "パレット下部のアートボード一覧を表示します。", en: "Shows the artboard list at the bottom of the palette." },
            artboardList: { ja: "行をクリックすると、そのアートボードへ移動します。", en: "Click a row to move to that artboard." }
        },
        panel: {
            options: { ja: "オプション", en: "Options" }
        },
        checkbox: {
            animation: { ja: "アニメーション", en: "Animation" },
            ease: { ja: "イーズアウト", en: "Ease out" },
            prezi: { ja: "Preziライクモード", en: "Prezi-like mode" },
            showLabel: { ja: "アートボード名を表示", en: "Show artboard name" },
            listVisible: { ja: "アートボード一覧を表示", en: "Show artboard list" }
        },
        fieldLabel: {
            speed: { ja: "スピード", en: "Speed" },
            preziDip: { ja: "俯瞰の強さ", en: "Zoom-out amount" }
        },
        column: {
            number: { ja: "番号", en: "No." },
            name: { ja: "アートボード名", en: "Artboard name" }
        }
    };

    // =========================================
    // 前提チェック / Preconditions
    // =========================================

    if (app.name !== "Adobe Illustrator") {
        alert(getLabel("alert.needIllustrator"));
        return;
    }

    // 単一アートボード（または2つ未満）のときはパレットを出さずに終了
    // Exit without showing the palette unless there are 2+ artboards
    if (app.documents.length === 0 || app.activeDocument.artboards.length < 2) {
        alert(getLabel("alert.needArtboards"));
        return;
    }

    // =========================================
    // 設定とアニメーション / Settings & animation
    // =========================================

    var PALETTE_TITLE = getLabel("dialog.title") + " " + SCRIPT_VERSION;
    var POSITION_FILE = new File(Folder.userData + "/ArtboardNavigator/palette-position.txt");

    // 設定の保存（再利用パーツ） / Settings store (reusable)

    var SETTINGS_STORE_FOLDER_NAME = "illustrator-scripts"; /* Folder.userData の下に作るフォルダー / folder created under Folder.userData */
    var SETTINGS_STORE_MAX_DEPTH = 32;                                /* 入れ子の上限（循環参照よけ）/ nesting limit (guards against cycles) */

    /**
     * 設定の保存先を作る。寿命は "session"（Illustrator の終了まで）か "persistent"（ファイルに保存）
     * @param {string} storeName - 保存名（ふつうは SCRIPT_NAME）。ファイル名と $.global のキーに使う
     * @param {string} lifetime - "session" または "persistent"
     * @param {Object} [storeOptions] - { legacy: function () → 旧形式の保存値のオブジェクト|null }
     * @returns {{load: Function, save: Function, clear: Function}} 読み込み・保存・消去の関数
     */
    function createSettingsStore(storeName, lifetime, storeOptions) {
        var isPersistent = (lifetime === "persistent");
        var legacyReader = (storeOptions && typeof storeOptions.legacy === "function") ? storeOptions.legacy : null;
        var safeStoreName = String(storeName).replace(/[\\\/:*?"<>|]/g, "_");
        var sessionKey = "__" + safeStoreName + "_Settings";
        var settingsFile = isPersistent
            ? new File(Folder.userData + "/" + SETTINGS_STORE_FOLDER_NAME + "/" + safeStoreName + ".json")
            : null;

        /**
         * 保存してある文字列を返す
         * @returns {string|null} 保存文字列。1度も保存していなければ null
         */
        function readStoredText() {
            if (!isPersistent) {
                return (typeof $.global[sessionKey] === "string") ? $.global[sessionKey] : null;
            }
            return settingsStoreReadTextFile(settingsFile);
        }

        /**
         * 文字列を保存する
         * @param {string} storedText - 保存する文字列
         * @returns {boolean} 保存できたら true
         */
        function writeStoredText(storedText) {
            if (!isPersistent) {
                $.global[sessionKey] = storedText;
                return true;
            }
            return settingsStoreWriteTextFile(settingsFile, storedText);
        }

        /**
         * 保存値を読み込み、既定値と突き合わせて返す（型の合わない値・知らない項目は捨てる）
         * @param {Object} defaultSettings - 既定値
         * @returns {Object} 設定（毎回新しいオブジェクト）
         */
        function load(defaultSettings) {
            var savedSettings = null;
            try {
                var storedText = readStoredText();
                if (storedText !== null) {
                    savedSettings = settingsStoreParse(storedText);
                } else if (legacyReader) {
                    savedSettings = legacyReader();
                }
            } catch (e) {
                $.writeln("SettingsStore.load(" + storeName + "): " + e);
                savedSettings = null;
            }
            return settingsStoreMerge(defaultSettings, savedSettings);
        }

        /**
         * 設定を保存する
         * @param {Object} settingValues - 保存する値
         * @returns {boolean} 保存できたら true
         */
        function save(settingValues) {
            try {
                return writeStoredText(settingsStoreSerialize(settingValues, "", 0));
            } catch (e) {
                $.writeln("SettingsStore.save(" + storeName + "): " + e);
                return false;
            }
        }

        /**
         * 保存を消す。旧形式を読み継ぐストアでは空の保存を書き、旧設定が戻らないようにする
         * @returns {boolean} 消せたら true
         */
        function clear() {
            if (legacyReader) return writeStoredText("{}");
            if (!isPersistent) {
                try { delete $.global[sessionKey]; } catch (e) { $.global[sessionKey] = undefined; }
                return true;
            }
            try {
                return settingsFile.exists ? settingsFile.remove() : true;
            } catch (e) {
                $.writeln("SettingsStore.clear(" + storeName + "): " + e);
                return false;
            }
        }

        return { load: load, save: save, clear: clear };
    }

    /**
     * 旧形式の設定ファイルを読む（key=value の行 / toSource / JSON を自動判別。eval は使わない）
     * @param {File|string} legacyFileOrPath - 旧ファイルかそのパス
     * @returns {Object|null} 読み込んだ値（key=value は値がすべて文字列）。無い・読めないときは null
     */
    function readSettingsLegacyFile(legacyFileOrPath) {
        try {
            var legacyFile = (legacyFileOrPath instanceof File) ? legacyFileOrPath : new File(legacyFileOrPath);
            var legacyText = settingsStoreReadTextFile(legacyFile);
            return (legacyText === null) ? null : settingsStoreParseLegacyText(legacyText);
        } catch (e) {
            $.writeln("readSettingsLegacyFile: " + e);
            return null;
        }
    }

    /**
     * app.preferences に文字列で保存していた旧設定を読む（形式は readSettingsLegacyFile と同じく自動判別）
     * @param {string} preferenceKey - 環境設定のキー
     * @returns {Object|null} 読み込んだ値。無い・読めないときは null
     */
    function readSettingsLegacyPreference(preferenceKey) {
        try {
            var legacyText = app.preferences.getStringPreference(preferenceKey);
            if (!legacyText) return null;
            return settingsStoreParseLegacyText(String(legacyText));
        } catch (e) {
            $.writeln("readSettingsLegacyPreference: " + e);
            return null;
        }
    }

    /**
     * テキストファイルを UTF-8 で読む
     * @param {File} textFile - 読むファイル
     * @returns {string|null} 中身。ファイルが無ければ null
     */
    function settingsStoreReadTextFile(textFile) {
        if (!textFile.exists) return null;
        textFile.encoding = "UTF-8";
        if (!textFile.open("r")) throw new Error("cannot open " + textFile.fsName);
        try {
            return textFile.read().replace(/^\uFEFF/, "");
        } finally {
            textFile.close();
        }
    }

    /**
     * テキストファイルを UTF-8 で書く（フォルダーが無ければ作る）
     * @param {File} textFile - 書くファイル
     * @param {string} fileText - 中身
     * @returns {boolean} 書けたら true
     */
    function settingsStoreWriteTextFile(textFile, fileText) {
        try {
            var parentFolder = textFile.parent;
            if (!parentFolder.exists && !parentFolder.create()) throw new Error("cannot create " + parentFolder.fsName);
            textFile.encoding = "UTF-8";
            textFile.lineFeed = "Unix";
            if (!textFile.open("w")) throw new Error("cannot open " + textFile.fsName);
            try {
                textFile.write(fileText);
            } finally {
                textFile.close();
            }
            return true;
        } catch (e) {
            $.writeln("SettingsStore write: " + e);
            return false;
        }
    }

    /**
     * 値が配列か
     * @param {*} checkedValue - 調べる値
     * @returns {boolean} 配列なら true
     */
    function settingsStoreIsArray(checkedValue) {
        return Object.prototype.toString.call(checkedValue) === "[object Array]";
    }

    /**
     * 値が素のオブジェクト（{ } で作ったもの）か
     * @param {*} checkedValue - 調べる値
     * @returns {boolean} 素のオブジェクトなら true
     */
    function settingsStoreIsPlainObject(checkedValue) {
        return checkedValue !== null && typeof checkedValue === "object"
            && Object.prototype.toString.call(checkedValue) === "[object Object]"
            && checkedValue.constructor === Object;
    }

    /**
     * 文字列を JSON の文字列リテラルにする（ASCII 以外は \uXXXX にして、文字コードの取り違えに強くする）
     * @param {string} sourceText - 文字列
     * @returns {string} 引用符つきの文字列
     */
    function settingsStoreQuote(sourceText) {
        var quotedText = "\"";
        for (var i = 0; i < sourceText.length; i++) {
            var charCode = sourceText.charCodeAt(i);
            var oneChar = sourceText.charAt(i);
            if (oneChar === "\"" || oneChar === "\\") quotedText += "\\" + oneChar;
            else if (oneChar === "\n") quotedText += "\\n";
            else if (oneChar === "\r") quotedText += "\\r";
            else if (oneChar === "\t") quotedText += "\\t";
            else if (charCode < 0x20 || charCode > 0x7E) quotedText += "\\u" + ("0000" + charCode.toString(16)).slice(-4);
            else quotedText += oneChar;
        }
        return quotedText + "\"";
    }

    /**
     * 値を JSON の文字列にする（オブジェクトは1項目1行、中身が値だけの配列は1行）。
     * undefined・関数・DOM オブジェクトは項目ごと省き、配列の中では null にする。有限でない数値は null
     * @param {*} sourceValue - 値
     * @param {string} indentText - 今の字下げ
     * @param {number} depth - 入れ子の深さ
     * @returns {string|undefined} JSON の文字列。書けない値は undefined
     */
    function settingsStoreSerialize(sourceValue, indentText, depth) {
        if (depth > SETTINGS_STORE_MAX_DEPTH) throw new Error("settings are nested too deeply");
        if (sourceValue === null) return "null";
        var valueType = typeof sourceValue;
        if (valueType === "boolean") return sourceValue ? "true" : "false";
        if (valueType === "number") return isFinite(sourceValue) ? String(sourceValue) : "null";
        if (valueType === "string") return settingsStoreQuote(sourceValue);
        var innerIndent = indentText + "  ";
        var itemTexts = [];
        var i;
        if (settingsStoreIsArray(sourceValue)) {
            var hasNested = false;
            for (i = 0; i < sourceValue.length; i++) {
                var itemText = settingsStoreSerialize(sourceValue[i], innerIndent, depth + 1);
                itemTexts.push(itemText === undefined ? "null" : itemText);
                if (sourceValue[i] !== null && typeof sourceValue[i] === "object") hasNested = true;
            }
            if (!itemTexts.length) return "[]";
            if (!hasNested) return "[" + itemTexts.join(", ") + "]";
            return "[\n" + innerIndent + itemTexts.join(",\n" + innerIndent) + "\n" + indentText + "]";
        }
        if (settingsStoreIsPlainObject(sourceValue)) {
            for (var key in sourceValue) {
                if (!sourceValue.hasOwnProperty(key)) continue;
                var memberText = settingsStoreSerialize(sourceValue[key], innerIndent, depth + 1);
                if (memberText !== undefined) itemTexts.push(settingsStoreQuote(key) + ": " + memberText);
            }
            if (!itemTexts.length) return "{}";
            return "{\n" + innerIndent + itemTexts.join(",\n" + innerIndent) + "\n" + indentText + "}";
        }
        return undefined; /* 関数・DOM オブジェクトなど / functions, DOM objects, etc. */
    }

    /**
     * JSON（と toSource の出力）を読む。eval は使わない。
     * キーの引用符なし・'…' の文字列・全体の ( ) ・末尾のカンマ・(void 0) も受け付ける
     * @param {string} sourceText - 読む文字列
     * @returns {*} 読み込んだ値
     */
    function settingsStoreParse(sourceText) {
        var readPos = 0;
        var textLength = sourceText.length;

        /**
         * 読み取り位置で失敗を知らせる
         * @param {string} reasonText - 理由
         * @returns {void}
         */
        function fail(reasonText) {
            throw new Error("settings parse error at " + readPos + ": " + reasonText);
        }

        /**
         * 空白を読み飛ばす
         * @returns {void}
         */
        function skipSpaces() {
            while (readPos < textLength && /\s/.test(sourceText.charAt(readPos))) readPos++;
        }

        /**
         * 識別子（英数字・_・$）を読む
         * @returns {string} 識別子。無ければ空文字
         */
        function readWord() {
            var startPos = readPos;
            while (readPos < textLength && /[\w$]/.test(sourceText.charAt(readPos))) readPos++;
            return sourceText.substring(startPos, readPos);
        }

        /**
         * 引用符で囲んだ文字列を読む（" と ' のどちらでも）
         * @returns {string} 文字列
         */
        function readString() {
            var quoteChar = sourceText.charAt(readPos++);
            var resultText = "";
            while (readPos < textLength) {
                var oneChar = sourceText.charAt(readPos++);
                if (oneChar === quoteChar) return resultText;
                if (oneChar !== "\\") { resultText += oneChar; continue; }
                var escapeChar = sourceText.charAt(readPos++);
                if (escapeChar === "n") resultText += "\n";
                else if (escapeChar === "r") resultText += "\r";
                else if (escapeChar === "t") resultText += "\t";
                else if (escapeChar === "b") resultText += "\b";
                else if (escapeChar === "f") resultText += "\f";
                else if (escapeChar === "v") resultText += "\v";
                else if (escapeChar === "0") resultText += "\0";
                else if (escapeChar === "u" || escapeChar === "x") {
                    var hexLength = (escapeChar === "u") ? 4 : 2;
                    var hexText = sourceText.substr(readPos, hexLength);
                    if (!new RegExp("^[0-9A-Fa-f]{" + hexLength + "}$").test(hexText)) fail("bad escape");
                    resultText += String.fromCharCode(parseInt(hexText, 16));
                    readPos += hexLength;
                } else resultText += escapeChar;
            }
            fail("unterminated string");
        }

        /**
         * 値を1つ読む
         * @param {number} depth - 入れ子の深さ
         * @returns {*} 値
         */
        function readValue(depth) {
            if (depth > SETTINGS_STORE_MAX_DEPTH) fail("nested too deeply");
            skipSpaces();
            var oneChar = sourceText.charAt(readPos);
            if (oneChar === "{") return readObject(depth);
            if (oneChar === "[") return readArray(depth);
            if (oneChar === "\"" || oneChar === "'") return readString();
            if (oneChar === "(") {
                readPos++;
                var innerValue = readValue(depth + 1);
                skipSpaces();
                if (sourceText.charAt(readPos) !== ")") fail("expected )");
                readPos++;
                return innerValue;
            }
            var numberMatch = /^-?(\d+\.?\d*|\.\d+)([eE][+\-]?\d+)?/.exec(sourceText.substring(readPos, readPos + 64));
            if (numberMatch) {
                readPos += numberMatch[0].length;
                return Number(numberMatch[0]);
            }
            var wordText = readWord();
            if (wordText === "true") return true;
            if (wordText === "false") return false;
            if (wordText === "null") return null;
            if (wordText === "NaN") return NaN;
            if (wordText === "Infinity") return Infinity;
            if (wordText === "void") { readValue(depth + 1); return undefined; } /* toSource の (void 0) */
            fail("unexpected " + (wordText || oneChar || "end of text"));
        }

        /**
         * 配列を読む
         * @param {number} depth - 入れ子の深さ
         * @returns {Array} 配列
         */
        function readArray(depth) {
            var resultArray = [];
            readPos++;
            skipSpaces();
            while (sourceText.charAt(readPos) !== "]") {
                resultArray.push(readValue(depth + 1));
                skipSpaces();
                if (sourceText.charAt(readPos) === ",") { readPos++; skipSpaces(); continue; }
                if (sourceText.charAt(readPos) !== "]") fail("expected , or ]");
            }
            readPos++;
            return resultArray;
        }

        /**
         * オブジェクトを読む（__proto__ のキーは捨てる）
         * @param {number} depth - 入れ子の深さ
         * @returns {Object} オブジェクト
         */
        function readObject(depth) {
            var resultObject = {};
            readPos++;
            skipSpaces();
            while (sourceText.charAt(readPos) !== "}") {
                var keyChar = sourceText.charAt(readPos);
                var memberKey = (keyChar === "\"" || keyChar === "'") ? readString() : readWord();
                if (memberKey === "") fail("expected a key");
                skipSpaces();
                if (sourceText.charAt(readPos) !== ":") fail("expected :");
                readPos++;
                var memberValue = readValue(depth + 1);
                if (memberKey !== "__proto__") resultObject[memberKey] = memberValue;
                skipSpaces();
                if (sourceText.charAt(readPos) === ",") { readPos++; skipSpaces(); continue; }
                if (sourceText.charAt(readPos) !== "}") fail("expected , or }");
            }
            readPos++;
            return resultObject;
        }

        var parsedValue = readValue(0);
        skipSpaces();
        if (readPos < textLength) fail("unexpected text after the value");
        return parsedValue;
    }

    /**
     * 旧形式の文字列を読む。{ [ ( で始まれば JSON / toSource、それ以外は key=value の行とみなす
     * @param {string} legacyText - 旧形式の文字列
     * @returns {Object|null} 読み込んだ値
     */
    function settingsStoreParseLegacyText(legacyText) {
        var trimmedText = legacyText.replace(/^\uFEFF/, "").replace(/^\s+|\s+$/g, "");
        if (trimmedText === "") return null;
        if (/^[\{\[\(]/.test(trimmedText)) return settingsStoreParse(trimmedText);
        var keyValues = {};
        var textLines = trimmedText.split(/\r\n|\r|\n/);
        for (var i = 0; i < textLines.length; i++) {
            var separatorIndex = textLines[i].indexOf("=");
            if (separatorIndex < 1) continue;
            var lineKey = textLines[i].substring(0, separatorIndex).replace(/^\s+|\s+$/g, "");
            if (lineKey !== "" && lineKey !== "__proto__") keyValues[lineKey] = textLines[i].substring(separatorIndex + 1);
        }
        return keyValues;
    }

    /**
     * 値を深くコピーする（素のデータだけ。関数・DOM オブジェクトは null）
     * @param {*} sourceValue - コピー元
     * @returns {*} コピー
     */
    function settingsStoreClone(sourceValue) {
        if (sourceValue === null || typeof sourceValue !== "object") {
            return (typeof sourceValue === "function" || sourceValue === undefined) ? null : sourceValue;
        }
        var i;
        if (settingsStoreIsArray(sourceValue)) {
            var arrayCopy = [];
            for (i = 0; i < sourceValue.length; i++) arrayCopy.push(settingsStoreClone(sourceValue[i]));
            return arrayCopy;
        }
        if (!settingsStoreIsPlainObject(sourceValue)) return null;
        var objectCopy = {};
        for (var key in sourceValue) {
            if (sourceValue.hasOwnProperty(key)) objectCopy[key] = settingsStoreClone(sourceValue[key]);
        }
        return objectCopy;
    }

    /**
     * 保存値を既定値と突き合わせる。型は既定値に合わせ、合わなければ既定値を使う。
     * 既定値が {} か null なら中身を問わず受け取り、配列は配列なら受け取る。既定値に無い項目は捨てる
     * @param {*} defaultValue - 既定値
     * @param {*} savedValue - 保存値
     * @returns {*} 突き合わせた値（新しいオブジェクト）
     */
    function settingsStoreMerge(defaultValue, savedValue) {
        if (defaultValue === null || defaultValue === undefined) {
            return (savedValue === undefined) ? null : settingsStoreClone(savedValue);
        }
        var defaultType = typeof defaultValue;
        var savedType = typeof savedValue;
        if (defaultType === "boolean") {
            if (savedType === "boolean") return savedValue;
            if (savedValue === 1 || savedValue === "1" || savedValue === "true") return true;
            if (savedValue === 0 || savedValue === "0" || savedValue === "false") return false;
            return defaultValue;
        }
        if (defaultType === "number") {
            if (savedType === "number" && isFinite(savedValue)) return savedValue;
            if (savedType === "string" && /\S/.test(savedValue)) {
                var parsedNumber = Number(savedValue);
                if (isFinite(parsedNumber)) return parsedNumber;
            }
            return defaultValue;
        }
        if (defaultType === "string") {
            if (savedType === "string") return savedValue;
            if (savedType === "number" && isFinite(savedValue)) return String(savedValue);
            if (savedType === "boolean") return String(savedValue);
            return defaultValue;
        }
        if (settingsStoreIsArray(defaultValue)) {
            return settingsStoreClone(settingsStoreIsArray(savedValue) ? savedValue : defaultValue);
        }
        if (defaultType === "object") {
            var savedIsObject = settingsStoreIsPlainObject(savedValue);
            var hasDefaultKeys = false;
            var mergedObject = {};
            for (var key in defaultValue) {
                if (!defaultValue.hasOwnProperty(key)) continue;
                hasDefaultKeys = true;
                mergedObject[key] = settingsStoreMerge(defaultValue[key], savedIsObject ? savedValue[key] : undefined);
            }
            /* 既定値が {} なら自由な入れ物として中身ごと受け取る / an empty default {} is a free-form map */
            if (!hasDefaultKeys && savedIsObject) return settingsStoreClone(savedValue);
            return mergedObject;
        }
        return defaultValue;
    }

    // 設定の保存（再利用パーツ）ここまで / End of the reusable settings store

    /* 設定の保存先は Folder.userData/illustrator-scripts/ArtboardNavigatorPalette.json。
       旧版の ArtboardNavigator/settings.txt は最初の1回だけ読み継ぐ
       Settings live in illustrator-scripts/ArtboardNavigatorPalette.json; the old settings.txt is read once */
    var settingsStore = createSettingsStore(SCRIPT_NAME, "persistent", {
        legacy: function () {
            return readSettingsLegacyFile(Folder.userData + "/ArtboardNavigator/settings.txt");
        }
    });

    // スピードは 1（遅い）〜10（速い）。速いほどステップ数を減らして素早く移動する。
    // Speed runs from 1 (slow) to 10 (fast); faster speeds use fewer steps
    var MIN_SPEED = 1;
    var MAX_SPEED = 10;
    var DEFAULT_SPEED = 6;
    var SLOW_STEP_COUNT = 40; // 最も遅いときのステップ数 / steps at the slowest speed
    var FAST_STEP_COUNT = 6;  // 最も速いときのステップ数 / steps at the fastest speed

    // 前回終了時の設定（無ければ既定値で埋める）/ Settings from the last session (defaults fill the gaps)
    var savedSettings = settingsStore.load({
        animation: true,
        speed: DEFAULT_SPEED,
        ease: true,
        prezi: true,
        preziDip: 0.2,
        listVisible: true,
        showLabel: true
    });

    var initialSpeed = clampNumber(savedSettings.speed, MIN_SPEED, MAX_SPEED);
    var animationStepCount = speedToStepCount(initialSpeed);
    var frameDelayMs = 6;

    // Prezi モードで途中に下げるズーム比率（0=引かない 〜 1=最大、中央 0.5）/ Prezi zoom-out ratio
    var preziDipRatio = clampNumber(savedSettings.preziDip, 0, 1);

    // 画面いっぱいに対する余白率（92% に収める）/ Fit ratio against the full view (fit within 92%)
    var fitMarginRatio = 0.92;

    // 保持する BridgeTalk ジョブの上限 / Max BridgeTalk jobs kept alive
    var MAX_PENDING_JOBS = 12;

    // =========================================
    // パレットの状態 / Palette state
    // =========================================

    // ボタンの配色は環境設定「ユーザーインターフェイスの明るさ」に追従
    // 明るいUI = 白バック・枠線・黒記号 / 暗いUI = 黒バック・白記号（従来）
    var useLightButtons = isLightUI();

    // BridgeTalk: ナビゲーション本体をメインエンジンへ登録済みか / Whether the worker is installed in the main engine
    var workerInstalled = false;

    // 一覧を作り直している間は onChange による移動を止める / Suppress navigation while the list is being rebuilt
    var isPopulatingList = false;

    // 一覧表示時のウィンドウ高さ（再表示でこの値へ正確に戻す）/ Palette height with the list shown (restored when it reappears)
    var shownWindowHeight = null;

    // すでに開いているパレットがあれば閉じてから作り直す（多重表示・再実行対策）
    // 前回のウィンドウがすでに破棄されていると close() が例外になるため try で包む
    if ($.global.artboardNavigatorWindow) {
        try {
            $.global.artboardNavigatorWindow.close();
        } catch (e) {
        }
        $.global.artboardNavigatorWindow = null;
    }

    if (!$.global.artboardNavigatorJobs) {
        $.global.artboardNavigatorJobs = [];
    }

    // ラベルは worker（メインエンジン）が専用レイヤー（ロックON・プリントOFF）へ描画し、
    // 切替ごとに作り直す。OFF・全体表示・閉じる時はレイヤーごと削除する。

    var navButtonDefinitions = [
        { tip: getLabel("tooltip.first"), icon: "first", command: "first" },
        { tip: getLabel("tooltip.prev"), icon: "prev", command: "prev" },
        { tip: getLabel("tooltip.list"), icon: "list", command: "list" },
        { tip: getLabel("tooltip.next"), icon: "next", command: "next" },
        { tip: getLabel("tooltip.last"), icon: "last", command: "last" }
    ];

    // コマンド名 → ボタンの対応（先頭／最終ボタンの有効・無効切替に使う）
    var navButtonsByCommand = {};

    // キーボードショートカット（再利用パーツ） / Keyboard shortcuts (reusable)

    /* 入力中はショートカットを止めるコントロールの種類 / Control types that swallow keys while focused */
    var KEY_SHORTCUT_TYPING_TYPES = { edittext: true, dropdownlist: true, listbox: true };

    /* 修飾キーの並び順（キーの表記をそろえる）/ Canonical order of modifiers in a key spec */
    var KEY_SHORTCUT_MODIFIERS = ["SHIFT", "ALT", "CMD"];

    /* 修飾キーの別名 / Aliases accepted for the modifiers */
    var KEY_SHORTCUT_MODIFIER_ALIASES = {
        SHIFT: "SHIFT",
        ALT: "ALT", OPTION: "ALT", OPT: "ALT",
        CMD: "CMD", COMMAND: "CMD", META: "CMD", CTRL: "CMD", CONTROL: "CMD"
    };

    /**
     * キーの指定（"Shift+R" など）を、照合用の表記（"SHIFT+R"）にそろえる
     * @param {string} keySpec - キーの指定。修飾キーは "Shift+" / "Alt+" / "Cmd+" を前に付ける
     * @returns {string} 照合用の表記（大文字、修飾キーは SHIFT → ALT → CMD の順）
     */
    function normalizeKeyShortcutSpec(keySpec) {
        var specParts = String(keySpec).split("+");
        var baseKey = specParts.pop().toUpperCase();
        var modifierFlags = {};
        for (var i = 0; i < specParts.length; i++) {
            var modifierName = KEY_SHORTCUT_MODIFIER_ALIASES[specParts[i].toUpperCase()];
            if (modifierName) modifierFlags[modifierName] = true;
        }
        return buildKeyShortcutSpec(modifierFlags, baseKey);
    }

    /**
     * 修飾キーの状態とキー名から照合用の表記を組み立てる
     * @param {Object} modifierFlags - { SHIFT: true, ALT: true, CMD: true } のうち押されているもの
     * @param {string} baseKey - 大文字のキー名
     * @returns {string} 照合用の表記
     */
    function buildKeyShortcutSpec(modifierFlags, baseKey) {
        var specText = "";
        for (var i = 0; i < KEY_SHORTCUT_MODIFIERS.length; i++) {
            if (modifierFlags[KEY_SHORTCUT_MODIFIERS[i]]) specText += KEY_SHORTCUT_MODIFIERS[i] + "+";
        }
        return specText + baseKey;
    }

    /**
     * keydown イベントから照合用の表記を作る。修飾キーはイベントと keyboardState の両方を見る
     * @param {Object} keyEvent - keydown イベント
     * @returns {string} 照合用の表記。キー名が無いときは空文字
     */
    function readKeyShortcutSpec(keyEvent) {
        if (!keyEvent || !keyEvent.keyName) return "";
        var keyboardState = {};
        try { keyboardState = ScriptUI.environment.keyboardState; } catch (e) { }
        var modifierFlags = {
            SHIFT: !!(keyEvent.shiftKey || keyboardState.shiftKey),
            ALT: !!(keyEvent.altKey || keyboardState.altKey),
            CMD: !!(keyEvent.metaKey || keyEvent.ctrlKey || keyboardState.metaKey || keyboardState.ctrlKey)
        };
        return buildKeyShortcutSpec(modifierFlags, String(keyEvent.keyName).toUpperCase());
    }

    /**
     * コントロールが押せる状態か（自分と親がすべて有効で表示中か）を返す
     * @param {Object} control - コントロール
     * @returns {boolean} 押せるなら true
     */
    function isKeyShortcutControlUsable(control) {
        for (var node = control; node; node = node.parent) {
            if (node.enabled === false || node.visible === false) return false;
        }
        return true;
    }

    /**
     * キーを受けたコントロールが、文字を入力する欄か
     * @param {Object} focusedControl - イベントの発生元
     * @param {Object[]} numericFields - 数値だけの欄（ショートカットを効かせる）
     * @returns {boolean} 入力中としてショートカットを止めるなら true
     */
    function isKeyShortcutTypingTarget(focusedControl, numericFields) {
        if (!focusedControl || !KEY_SHORTCUT_TYPING_TYPES[focusedControl.type]) return false;
        for (var i = 0; i < numericFields.length; i++) {
            if (numericFields[i] === focusedControl) return false;
        }
        return true;
    }

    /**
     * コントロールをクリックしたときと同じ動作をする
     * ラジオは同じ親のラジオを外して選び、チェックボックスは反転してから onClick を呼ぶ
     * @param {Object} control - ラジオボタン・チェックボックス・ボタンなど
     * @returns {void}
     */
    function pressKeyShortcutControl(control) {
        if (control.type === "radiobutton") {
            /* 同じ親の直下だけが排他になるので、クリックと同じく兄弟を外す / Clear siblings like a click would */
            var siblings = control.parent ? control.parent.children : [];
            for (var i = 0; i < siblings.length; i++) {
                if (siblings[i] !== control && siblings[i].type === "radiobutton") siblings[i].value = false;
            }
            control.value = true;
        } else if (control.type === "checkbox") {
            control.value = !control.value;
        }
        if (typeof control.onClick === "function") {
            control.onClick.call(control);
        } else if (control.type === "button" && typeof control.notify === "function") {
            /* onClick の無い OK・キャンセルは notify で既定の動作（閉じる）を起こす / Let default buttons close the dialog */
            control.notify("onClick");
        }
    }

    /**
     * 1つのショートカットを実行する
     * @param {Object|Function} shortcutTarget - コントロール、または関数
     * @param {Object} keyEvent - keydown イベント
     * @returns {boolean} キーを使ったなら true（false なら文字をそのまま通す）
     */
    function runKeyShortcutTarget(shortcutTarget, keyEvent) {
        var targetControl = shortcutTarget;
        if (typeof shortcutTarget === "function") {
            var runResult = shortcutTarget(keyEvent);
            if (runResult === false || runResult === null) return false;
            if (!runResult || typeof runResult !== "object" || !runResult.type) return true;
            targetControl = runResult;
        }
        /* 無効なコントロールのキーも使ったことにして、数値欄へ文字を入れない / Consume the key even when disabled */
        if (isKeyShortcutControlUsable(targetControl)) pressKeyShortcutControl(targetControl);
        return true;
    }

    /**
     * キーの指定に修飾キーの表示名を当てて、ツールチップ用の表記にする
     * @param {string} normalizedSpec - 照合用の表記（"SHIFT+R" など）
     * @returns {string} 表示用の表記（"Shift+R" など）
     */
    function formatKeyShortcutLabel(normalizedSpec) {
        var isMac = ($.os.indexOf("Mac") === 0);
        var displayNames = { SHIFT: "Shift", ALT: isMac ? "Option" : "Alt", CMD: isMac ? "Cmd" : "Ctrl" };
        var specParts = normalizedSpec.split("+");
        var baseKey = specParts.pop();
        var labelText = "";
        for (var i = 0; i < specParts.length; i++) labelText += displayNames[specParts[i]] + "+";
        if (baseKey.length > 1) baseKey = baseKey.charAt(0) + baseKey.substring(1).toLowerCase();
        return labelText + baseKey;
    }

    /**
     * コントロールのツールチップの末尾にキーを足す（すでに書いてあれば足さない）
     * @param {Object} control - コントロール
     * @param {string} normalizedSpec - 照合用の表記
     * @returns {void}
     */
    function appendKeyShortcutToTip(control, normalizedSpec) {
        var keyLabel = formatKeyShortcutLabel(normalizedSpec);
        var currentTip = control.helpTip ? String(control.helpTip) : "";
        if (currentTip.indexOf("（" + keyLabel) >= 0 || currentTip.indexOf("(" + keyLabel) >= 0) return;
        var keySuffix = (uiLang === "ja") ? "（" + keyLabel + "）" : " (" + keyLabel + ")";
        control.helpTip = currentTip ? currentTip + keySuffix : keyLabel;
    }

    /**
     * ダイアログ・パレットに文字キーのショートカットを付ける
     * @param {Window} targetWindow - キーを受けるダイアログ・パレット
     * @param {Object} shortcutMap - { "L": ラジオ, "Shift+R": ボタン, "G": 関数, "Escape": { target: 関数, inFields: true } }
     * @param {Object} [shortcutOptions] - numericFields（数値だけの欄の配列）/ afterKey（キーを使ったあとに呼ぶ関数）/ showInTip（ツールチップにキーを足す）
     * @returns {Object} 照合用の表記 → { target, inFields } の表（テスト・デバッグ用）
     */
    function addKeyShortcuts(targetWindow, shortcutMap, shortcutOptions) {
        var shortcutSettings = shortcutOptions || {};
        var numericFields = shortcutSettings.numericFields || [];
        var bindingTable = {};

        for (var keySpec in shortcutMap) {
            if (!shortcutMap.hasOwnProperty(keySpec)) continue;
            var mapEntry = shortcutMap[keySpec];
            if (!mapEntry) continue;
            var isWrapped = (typeof mapEntry === "object" && !mapEntry.type && mapEntry.target);
            var normalizedSpec = normalizeKeyShortcutSpec(keySpec);
            bindingTable[normalizedSpec] = {
                target: isWrapped ? mapEntry.target : mapEntry,
                inFields: !!(isWrapped && mapEntry.inFields)
            };
            var tipControl = bindingTable[normalizedSpec].target;
            if (shortcutSettings.showInTip && typeof tipControl === "object" && tipControl.type) {
                appendKeyShortcutToTip(tipControl, normalizedSpec);
            }
        }

        /* キャプチャで受けて、数値欄に文字が入る前に止める / Capture phase keeps the letter out of numeric fields */
        targetWindow.addEventListener("keydown", function (keyEvent) {
            var binding = bindingTable[readKeyShortcutSpec(keyEvent)];
            if (!binding) return;
            if (!binding.inFields && isKeyShortcutTypingTarget(keyEvent.target, numericFields)) return;
            if (!runKeyShortcutTarget(binding.target, keyEvent)) return;
            if (keyEvent.preventDefault) keyEvent.preventDefault();
            if (typeof shortcutSettings.afterKey === "function") shortcutSettings.afterKey(keyEvent);
        }, true);

        return bindingTable;
    }

    // キーボードショートカット（再利用パーツ）ここまで / End of the reusable keyboard shortcuts

    // =========================================
    // パレット / Palette
    // =========================================

    var paletteWindow = new Window("palette", PALETTE_TITLE, undefined, { resizeable: true });
    $.global.artboardNavigatorWindow = paletteWindow;

    setupWindow(paletteWindow);
    paletteWindow.preferredSize = PALETTE_PREFERRED_SIZE;

    var navButtonRow = addNavButtonRow(paletteWindow);

    var optionControls = addOptionsPanel(paletteWindow);
    var animationCheckbox = optionControls.animationCheckbox;
    var speedSlider = optionControls.speedSlider;
    var easeCheckbox = optionControls.easeCheckbox;
    var preziCheckbox = optionControls.preziCheckbox;
    var preziDipSlider = optionControls.preziDipSlider;
    var showArtboardNameCheckbox = optionControls.showArtboardNameCheckbox;

    var listControls = addArtboardListSection(paletteWindow);
    var listVisibilityCheckbox = listControls.listVisibilityCheckbox;
    var artboardListBox = listControls.artboardListBox;

    bindPaletteEvents();

    paletteWindow.show();
    refreshArtboardList();

    // 前回 OFF だった場合は一覧を畳んだ状態で開く（show 後に高さを詰める）
    if (!listVisibilityCheckbox.value) {
        applyArtboardListVisibility(false);
    }

    // 起動直後にワーカーを登録しておく（最初のクリックも短い呼び出しだけで済む）
    if (typeof BridgeTalk !== "undefined") {
        installNavigationWorker();
    }

    // =========================================
    // パレットの組み立て / Building the palette
    // =========================================

    /**
     * スピード値（1〜10）をステップ数に変換する / Convert a speed value (1-10) to a step count
     * @param {number} speed - スピード値
     * @returns {number} アニメーションのステップ数
     */
    function speedToStepCount(speed) {
        var ratio = (speed - MIN_SPEED) / (MAX_SPEED - MIN_SPEED); // 0〜1
        var steps = Math.round(SLOW_STEP_COUNT - ratio * (SLOW_STEP_COUNT - FAST_STEP_COUNT));
        if (steps < FAST_STEP_COUNT) { steps = FAST_STEP_COUNT; }
        if (steps > SLOW_STEP_COUNT) { steps = SLOW_STEP_COUNT; }
        return steps;
    }

    /**
     * ナビゲーションボタンの行を追加する
     * @param {Window} parentWindow - 追加先のパレット
     * @returns {Group} ボタンの行
     */
    function addNavButtonRow(parentWindow) {
        var buttonRow = parentWindow.add("group");
        buttonRow.orientation = "row";
        buttonRow.alignChildren = ["center", "center"];
        buttonRow.alignment = ["center", "top"];
        buttonRow.spacing = NAV_BUTTON_SPACING;
        buttonRow.margins = NAV_BUTTON_ROW_MARGINS;

        for (var i = 0; i < navButtonDefinitions.length; i++) {
            addNavButton(buttonRow, navButtonDefinitions[i]);
        }
        return buttonRow;
    }

    /**
     * 項目名とスライダーの行を追加する（ラベル・スライダーの両方に tooltip を付ける）
     * @param {Panel} parentPanel - 追加先のパネル
     * @param {string} labelKey - fieldLabel.* と tooltip.* に共通のキー
     * @param {number} initialValue - 初期値
     * @param {number} minValue - 最小値
     * @param {number} maxValue - 最大値
     * @returns {{row: Group, slider: Slider}} 追加した行とスライダー
     */
    function addSliderRow(parentPanel, labelKey, initialValue, minValue, maxValue) {
        var sliderRow = parentPanel.add("group");
        sliderRow.orientation = "row";
        sliderRow.alignChildren = ["left", "center"];
        sliderRow.alignment = ["fill", "top"];

        var sliderLabel = sliderRow.add("statictext", undefined, labelText("fieldLabel." + labelKey));
        sliderLabel.helpTip = getLabel("tooltip." + labelKey);
        var valueSlider = sliderRow.add("slider", undefined, initialValue, minValue, maxValue);
        valueSlider.alignment = ["fill", "center"];
        valueSlider.preferredSize = SLIDER_PREFERRED_SIZE;
        valueSlider.helpTip = getLabel("tooltip." + labelKey);
        return { row: sliderRow, slider: valueSlider };
    }

    /**
     * 前回の設定値と tooltip 付きのチェックボックスを追加する
     * @param {Group|Panel} parentGroup - 追加先
     * @param {string} labelKey - checkbox.* と tooltip.* に共通のキー
     * @param {string} settingKey - 設定のキー
     * @returns {Checkbox} 追加したチェックボックス
     */
    function addSettingCheckbox(parentGroup, labelKey, settingKey) {
        var settingCheckbox = parentGroup.add("checkbox", undefined, getLabel("checkbox." + labelKey));
        settingCheckbox.helpTip = getLabel("tooltip." + labelKey);
        settingCheckbox.value = savedSettings[settingKey];
        return settingCheckbox;
    }

    /**
     * スライダーの値をドラッグ中から反映し、離したときに設定を保存する
     * @param {Slider} valueSlider - 対象のスライダー
     * @param {Function} applySliderValue - 値を受け取って反映する関数
     * @returns {void}
     */
    function bindLiveSlider(valueSlider, applySliderValue) {
        valueSlider.onChanging = function () {
            applySliderValue(this.value);
        };
        valueSlider.onChange = function () {
            applySliderValue(this.value);
            saveSettings();
        };
    }

    /**
     * オプション設定パネルを追加する / Add the options panel
     * @param {Window} parentWindow - 追加先のパレット
     * @returns {object} animationCheckbox / speedSlider / easeCheckbox / preziCheckbox / preziDipSlider / showArtboardNameCheckbox
     */
    function addOptionsPanel(parentWindow) {
        var optionsPanel = parentWindow.add("panel", undefined, getLabel("panel.options"));
        setupPanel(optionsPanel, 6);

        // アニメーションの ON/OFF（OFF で以降のオプションをディム表示）
        var animationToggle = addSettingCheckbox(optionsPanel, "animation", "animation");

        // 前後のアートボードへ移動するスピード（右ほど速い） / Speed of moving to the prev/next artboard (faster toward the right)
        var speedControls = addSliderRow(optionsPanel, "speed", initialSpeed, MIN_SPEED, MAX_SPEED);
        bindLiveSlider(speedControls.slider, function (speedValue) {
            animationStepCount = speedToStepCount(speedValue);
        });

        // イーズの ON/OFF（OFF で線形＝イーズなし）
        var easeToggle = addSettingCheckbox(optionsPanel, "ease", "ease");
        easeToggle.onClick = function () {
            saveSettings();
        };

        // Prezi モード：前後移動の途中で一度ズームを下げてから寄せる（Prezi 風）
        var preziToggle = addSettingCheckbox(optionsPanel, "prezi", "prezi");

        // Prezi モードで下げるズーム量（中央 0.5、左ほど弱く右ほど強い） / Prezi zoom-out amount
        var preziDipControls = addSliderRow(optionsPanel, "preziDip", preziDipRatio, 0, 1);
        bindLiveSlider(preziDipControls.slider, function (dipValue) {
            preziDipRatio = dipValue;
        });

        /**
         * 引きスライダーはアニメーション ON かつ Prezi モード ON のときだけ有効にする
         * @returns {void}
         */
        function applyPreziDipEnabled() {
            preziDipControls.row.enabled = animationToggle.value && preziToggle.value;
        }

        preziToggle.onClick = function () {
            applyPreziDipEnabled();
            saveSettings();
        };

        /**
         * アニメーション OFF のときは以降のオプションをすべてディム表示する
         * @param {boolean} enabled - アニメーションが ON なら true
         * @returns {void}
         */
        function applyAnimationEnabled(enabled) {
            speedControls.row.enabled = enabled;
            easeToggle.enabled = enabled;
            preziToggle.enabled = enabled;
            applyPreziDipEnabled();
        }

        animationToggle.onClick = function () {
            applyAnimationEnabled(this.value);
            saveSettings();
        };

        applyAnimationEnabled(animationToggle.value);

        // アートボード名ラベルの表示 ON/OFF
        // ON のときだけ、移動先の左上に「番号：アートボード名」を専用レイヤー
        //（ロックON・プリントOFF）へ描画する。OFF のときは描画もレイヤー作成もしない。
        var showLabelToggle = addSettingCheckbox(optionsPanel, "showLabel", "showLabel");
        showLabelToggle.onClick = function () {
            if (!this.value) {
                removeLabelLayerDirect();
                requestLabelRemoval();
            }
            saveSettings();
        };

        return {
            animationCheckbox: animationToggle,
            speedSlider: speedControls.slider,
            easeCheckbox: easeToggle,
            preziCheckbox: preziToggle,
            preziDipSlider: preziDipControls.slider,
            showArtboardNameCheckbox: showLabelToggle
        };
    }

    /**
     * 「アートボード一覧」のチェックボックスと一覧（番号｜アートボード名）を追加する
     * @param {Window} parentWindow - 追加先のパレット
     * @returns {{listVisibilityCheckbox: Checkbox, artboardListBox: ListBox}} 追加したコントロール
     */
    function addArtboardListSection(parentWindow) {
        // アートボード一覧の表示 ON/OFF（OFF で一覧を隠し、領域も確保しない）
        var listVisibilityRow = parentWindow.add("group");
        listVisibilityRow.orientation = "row";
        listVisibilityRow.alignChildren = ["center", "center"];
        listVisibilityRow.alignment = ["fill", "top"];
        listVisibilityRow.margins = LIST_TOGGLE_ROW_MARGINS;

        var listVisibilityToggle = addSettingCheckbox(listVisibilityRow, "listVisible", "listVisible");

        // アートボード一覧（番号｜アートボード名）。行を選ぶとそのアートボードへ移動
        var artboardList = parentWindow.add("listbox", undefined, [], {
            numberOfColumns: 2,
            showHeaders: true,
            columnTitles: [getLabel("column.number"), getLabel("column.name")],
            columnWidths: LIST_COLUMN_WIDTHS
        });
        artboardList.helpTip = getLabel("tooltip.artboardList");
        // リサイズ時に一覧が縦横とも追従して広がるようにする
        artboardList.alignment = ["fill", "fill"];
        artboardList.preferredSize = LIST_PREFERRED_SIZE;

        // 一覧の表示／非表示を切り替え、OFF のときは領域も確保しない
        listVisibilityToggle.onClick = function () {
            applyArtboardListVisibility(this.value);
            saveSettings();
        };

        artboardList.onChange = function () {
            if (isPopulatingList) {
                return;
            }
            if (this.selection) {
                runNavigation(String(this.selection.index));
            }
        };

        return { listVisibilityCheckbox: listVisibilityToggle, artboardListBox: artboardList };
    }

    /**
     * パレットのリサイズ・移動・閉じる・アクティブ化・キー操作のイベントを登録する
     * @returns {void}
     */
    function bindPaletteEvents() {
        // ウィンドウのリサイズに追従してレイアウトを再配置
        paletteWindow.onResizing = paletteWindow.onResize = function () {
            this.layout.resize();
        };

        restoreWindowPosition(paletteWindow);

        paletteWindow.onMove = function () {
            saveWindowPosition(paletteWindow);
        };

        paletteWindow.onClose = function () {
            saveWindowPosition(paletteWindow);
            saveSettings();
            // 表示中のラベルをメインエンジン側で消してから閉じる
            requestLabelRemoval();
            $.global.artboardNavigatorWindow = null;
        };

        paletteWindow.onActivate = function () {
            // 環境設定のUI明るさが変わっていたらボタンの配色を切り替えて描き直す
            var isLightNow = isLightUI();
            if (isLightNow !== useLightButtons) {
                useLightButtons = isLightNow;
                try {
                    for (var i = 0; i < navButtonRow.children.length; i++) {
                        navButtonRow.children[i].notify("onDraw");
                    }
                } catch (redrawError) {
                }
            }
            refreshArtboardList();
        };

        // キーボードショートカット（パレットにフォーカスがあるとき）
        // Control + Shift + Option + ← … 前のアートボードへ
        // Control + Shift + Option + → … 次のアートボードへ
        // Control + Shift + Option + ↑ … 全アートボードを一覧表示
        // ※ Option は ScriptUI では altKey
        var shortcutCommands = { Left: "prev", Right: "next", Up: "list" };
        paletteWindow.addEventListener("keydown", function (keyEvent) {
            if (!keyEvent.ctrlKey || !keyEvent.shiftKey || !keyEvent.altKey) {
                return;
            }
            if (shortcutCommands.hasOwnProperty(keyEvent.keyName)) {
                runNavigation(shortcutCommands[keyEvent.keyName]);
                keyEvent.preventDefault();
            }
        });

        // パレットは Esc で閉じないので、閉じる処理を割り当てる（入力中も効かせる）
        // Palettes do not close on Esc by themselves; map it to close, also while typing
        addKeyShortcuts(paletteWindow, {
            "Escape": { target: function () { paletteWindow.close(); }, inFields: true }
        });
    }

    // =========================================
    // ボタン生成・アイコン描画 / Buttons & icons
    // =========================================

    /**
     * ナビゲーションボタンを1つ生成して配置する / Create and place one navigation button
     * @param {Group} parentGroup - 追加先の行
     * @param {{tip: string, icon: string, command: string}} buttonDefinition - ボタンの定義
     * @returns {void}
     */
    function addNavButton(parentGroup, buttonDefinition) {
        var navButton = parentGroup.add("button", undefined, "");
        navButton.helpTip = buttonDefinition.tip;
        navButton.preferredSize = [NAV_BUTTON_SIZE, NAV_BUTTON_SIZE];
        navButton.minimumSize = [NAV_BUTTON_SIZE, NAV_BUTTON_SIZE];
        navButton.maximumSize = [NAV_BUTTON_SIZE, NAV_BUTTON_SIZE];
        navButton.iconType = buttonDefinition.icon;
        navButton.navCommand = buttonDefinition.command;
        navButton.pressed = false;
        navButtonsByCommand[buttonDefinition.command] = navButton;
        navButton.onDraw = function () {
            drawNavButton(this);
        };
        navButton.onClick = function () {
            runNavigation(this.navCommand);
        };
        // クリック中だけ背景の明るさを少し変える（押下フィードバック）。ボタン外へ出たときも戻す
        navButton.addEventListener("mousedown", function () {
            setNavButtonPressed(this, true);
        });
        navButton.addEventListener("mouseup", function () {
            setNavButtonPressed(this, false);
        });
        navButton.addEventListener("mouseout", function () {
            setNavButtonPressed(this, false);
        });
    }

    /**
     * ボタンの押下状態を変え、変わったときだけ描き直す
     * @param {Button} navButton - 対象のボタン
     * @param {boolean} isPressed - 押されているなら true
     * @returns {void}
     */
    function setNavButtonPressed(navButton, isPressed) {
        if (navButton.pressed === isPressed) {
            return;
        }
        navButton.pressed = isPressed;
        navButton.notify("onDraw");
    }

    /**
     * 環境設定のUI明るさが明るい側かどうか / Whether the UI brightness preference is on the light side
     * uiBrightness は 0（最暗）〜1（最明）の 4 段階。
     * 0=暗 / 0.5=やや暗め → 暗いUI、0.51=やや明るめ / 1=明るい → 明るいUI。
     * 「やや暗め(0.5)」を暗い側に含めるため 0.5 より大きいかで判定する。
     * @returns {boolean} 明るいUIなら true
     */
    function isLightUI() {
        try {
            return app.preferences.getRealPreference("uiBrightness") > 0.5;
        } catch (e) {
            return false;
        }
    }

    /**
     * ボタンの背景とアイコンを描画する / Draw the button background and icon
     * 明るいUI = 白バック＋枠線＋黒記号 / 暗いUI = 黒バック＋白記号
     * @param {Button} navButton - 描画するボタン
     * @returns {void}
     */
    function drawNavButton(navButton) {
        var graphics = navButton.graphics;
        var buttonWidth = navButton.size[0];
        var buttonHeight = navButton.size[1];

        var backgroundColor = useLightButtons ? [1, 1, 1, 1] : [0.30, 0.30, 0.30, 1];
        var glyphColor = useLightButtons ? [0.15, 0.15, 0.15, 1] : [0.92, 0.92, 0.92, 1];

        // クリック中は明るさを少しだけ変える（明るいUIは少し暗く、暗いUIは少し明るく）
        if (navButton.pressed) {
            backgroundColor = useLightButtons ? [0.86, 0.86, 0.86, 1] : [0.46, 0.46, 0.46, 1];
        }

        // 無効（端にいる先頭／最終ボタン）は記号を淡くしてグレーアウト表示
        if (navButton.enabled === false) {
            glyphColor = useLightButtons ? [0.75, 0.75, 0.75, 1] : [0.50, 0.50, 0.50, 1];
        }

        graphics.newPath();
        graphics.rectPath(0, 0, buttonWidth, buttonHeight);
        graphics.fillPath(graphics.newBrush(graphics.BrushType.SOLID_COLOR, backgroundColor));
        // 明るいUIでは白バックが背景に溶けるので枠線を足す
        if (useLightButtons) {
            graphics.newPath();
            graphics.rectPath(0, 0, buttonWidth, buttonHeight);
            graphics.strokePath(graphics.newPen(graphics.PenType.SOLID_COLOR, [0.62, 0.62, 0.62, 1], 1));
        }

        drawNavGlyph(graphics, navButton.iconType, glyphColor);
    }

    /**
     * 折れ線を1本描く
     * @param {ScriptUIGraphics} graphics - 描画先
     * @param {Object} glyphPen - ペン
     * @param {number[][]} points - 頂点 [[x, y], ...]
     * @returns {void}
     */
    function strokePolyline(graphics, glyphPen, points) {
        graphics.newPath();
        graphics.moveTo(points[0][0], points[0][1]);
        for (var i = 1; i < points.length; i++) {
            graphics.lineTo(points[i][0], points[i][1]);
        }
        graphics.strokePath(glyphPen);
    }

    /**
     * < / > / グリッド / |< / >| のアイコン形状を描く / Draw the glyph
     * @param {ScriptUIGraphics} graphics - 描画先
     * @param {string} iconType - "first" / "prev" / "list" / "next" / "last"
     * @param {number[]} glyphColor - 記号の色 [r, g, b, a]
     * @returns {void}
     */
    function drawNavGlyph(graphics, iconType, glyphColor) {
        if (iconType === "list") {
            // 2×2 のサムネイル風グリッド
            var listPen = graphics.newPen(graphics.PenType.SOLID_COLOR, glyphColor, 1.0);
            var cellSize = 6;
            var cellOrigins = [[5, 5], [15, 5], [5, 15], [15, 15]];
            for (var i = 0; i < cellOrigins.length; i++) {
                // セルごとに newPath() で前のパス（背景・枠の矩形を含む）をクリアしてから描く。
                // これを省くとボタン外枠の矩形が残ってグリフ色で stroke され、枠が濃く見える。
                graphics.newPath();
                graphics.rectPath(cellOrigins[i][0], cellOrigins[i][1], cellSize, cellSize);
                graphics.strokePath(listPen);
            }
            return;
        }

        var glyphPen = graphics.newPen(graphics.PenType.SOLID_COLOR, glyphColor, 1.6);
        if (iconType === "first") {
            // |< 形状（左端の縦棒＋左向き山）
            strokePolyline(graphics, glyphPen, [[9, 7], [9, 19]]);
            strokePolyline(graphics, glyphPen, [[18, 7], [13, 13], [18, 19]]);
        } else if (iconType === "last") {
            // >| 形状（右向き山＋右端の縦棒）
            strokePolyline(graphics, glyphPen, [[8, 7], [13, 13], [8, 19]]);
            strokePolyline(graphics, glyphPen, [[17, 7], [17, 19]]);
        } else if (iconType === "prev") {
            // < 形状
            strokePolyline(graphics, glyphPen, [[16, 7], [10, 13], [16, 19]]);
        } else if (iconType === "next") {
            // > 形状
            strokePolyline(graphics, glyphPen, [[10, 7], [16, 13], [10, 19]]);
        }
    }

    // =========================================
    // ナビゲーションと一覧 / Navigation & list
    // =========================================

    /**
     * ナビゲーションを実行する（必要ならワーカーを登録） / Run navigation (install worker if needed)
     * listbox 選択はクリック時にパレット側で確定（onResult に依存しない）。
     * ラベル描画と削除は worker 側で行う。OFF にしたときはパレット側でも直接削除する。
     * @param {string} navCommand - "first" / "prev" / "list" / "next" / "last" / 絶対インデックスの文字列
     * @returns {void}
     */
    function runNavigation(navCommand) {
        if (typeof BridgeTalk === "undefined") {
            return;
        }
        if (!workerInstalled) {
            installNavigationWorker();
        }

        // パレット側で移動先の絶対インデックスを確定（listbox の選択を現在地とみなす）
        var targetIndex = resolveTargetIndex(navCommand);
        if (targetIndex < 0) {
            // 全体表示と、解決できなかったコマンドはそのままワーカーへ委ねる
            sendNavigation(navCommand, true);
            return;
        }
        // 一覧の選択を即反映し、ワーカーには絶対インデックスを渡して両者を一致させる
        selectArtboardInList(targetIndex);
        sendNavigation(String(targetIndex), true);
    }

    /**
     * 一覧の行数（無ければドキュメントのアートボード数）を返す
     * @returns {number} アートボード数（ドキュメントを参照できなければ -1）
     */
    function getArtboardCount() {
        var artboardCount = artboardListBox.items.length;
        if (artboardCount > 0) {
            return artboardCount;
        }
        // 常駐パレットからは app.activeDocument が例外になることがある
        try {
            return app.activeDocument.artboards.length;
        } catch (e) {
            return -1;
        }
    }

    /**
     * ナビゲーションコマンドを移動先の絶対インデックスへ解決する（list は -1） / Resolve a command to an absolute artboard index (-1 for list)
     * @param {string} navCommand - ナビゲーションコマンド
     * @returns {number} 移動先のインデックス（解決できなければ -1）
     */
    function resolveTargetIndex(navCommand) {
        var artboardCount = getArtboardCount();
        if (artboardCount < 0 || navCommand === "list") {
            return -1;
        }
        var currentIndex = getCurrentArtboardIndex();
        if (navCommand === "prev") {
            return (currentIndex - 1 + artboardCount) % artboardCount;
        }
        if (navCommand === "next") {
            return (currentIndex + 1) % artboardCount;
        }
        if (navCommand === "first") {
            return 0;
        }
        if (navCommand === "last") {
            return artboardCount - 1;
        }
        var explicitIndex = parseInt(navCommand, 10);
        if (!isNaN(explicitIndex) && explicitIndex >= 0 && explicitIndex < artboardCount) {
            return explicitIndex;
        }
        return -1;
    }

    /**
     * 現在地とみなすインデックス（listbox の選択 → 無ければドキュメント） / Current index (listbox selection, fallback to document)
     * @returns {number} 現在のインデックス
     */
    function getCurrentArtboardIndex() {
        if (artboardListBox.selection) {
            return artboardListBox.selection.index;
        }
        // 常駐パレットからは app.activeDocument が例外になることがある
        try {
            return app.activeDocument.artboards.getActiveArtboardIndex();
        } catch (e) {
            return 0;
        }
    }

    /**
     * onChange を発火させずに一覧の選択を更新する / Select a list row without triggering onChange
     * @param {number} rowIndex - 選択する行
     * @returns {void}
     */
    function selectArtboardInList(rowIndex) {
        if (rowIndex < 0 || rowIndex >= artboardListBox.items.length) {
            return;
        }
        isPopulatingList = true;
        artboardListBox.selection = rowIndex;
        isPopulatingList = false;
        updateNavButtonStates(rowIndex);
    }

    /**
     * 先頭にいるとき先頭ボタン、最終にいるとき最終ボタンを無効化する / Disable first/last button at the respective ends
     * prev/next は循環移動なので常に有効のまま。
     * @param {number} [currentIndex] - 現在のインデックス（省略時は getCurrentArtboardIndex()）
     * @returns {void}
     */
    function updateNavButtonStates(currentIndex) {
        var artboardCount = getArtboardCount();
        if (artboardCount < 0) {
            return;
        }
        if (typeof currentIndex !== "number" || currentIndex < 0) {
            currentIndex = getCurrentArtboardIndex();
        }
        setButtonEnabled(navButtonsByCommand.first, currentIndex > 0);
        setButtonEnabled(navButtonsByCommand.last, currentIndex < artboardCount - 1);
    }

    /**
     * ボタンの有効状態を変え、変わったときだけ再描画する / Set a button's enabled state and repaint if it changed
     * @param {Button} navButton - 対象のボタン
     * @param {boolean} isEnabled - 有効にするなら true
     * @returns {void}
     */
    function setButtonEnabled(navButton, isEnabled) {
        if (!navButton || navButton.enabled === isEnabled) {
            return;
        }
        navButton.enabled = isEnabled;
        try {
            navButton.notify("onDraw");
        } catch (e) {
        }
    }

    /**
     * アートボード一覧を再構築し現在のものを選択する / Rebuild the artboard list and select the active one
     * 先に値を取得し、取得できたときだけ作り直す（失敗時は現状維持で空白化を防ぐ）
     * @returns {void}
     */
    function refreshArtboardList() {
        if (app.documents.length === 0) {
            return;
        }

        var activeIndex;
        var artboardNames = [];

        // 常駐パレットからはドキュメントを一時的に参照できないことがある。そのときは現状維持
        try {
            var doc = app.activeDocument;
            activeIndex = doc.artboards.getActiveArtboardIndex();
            for (var i = 0; i < doc.artboards.length; i++) {
                artboardNames.push(doc.artboards[i].name);
            }
        } catch (e) {
            return;
        }

        if (artboardNames.length === 0) {
            return;
        }

        isPopulatingList = true;
        artboardListBox.removeAll();
        for (var j = 0; j < artboardNames.length; j++) {
            var listItem = artboardListBox.add("item", String(j + 1));
            listItem.subItems[0].text = artboardNames[j];
        }
        if (activeIndex >= 0 && activeIndex < artboardListBox.items.length) {
            artboardListBox.selection = activeIndex;
        }
        isPopulatingList = false;

        // 先頭／最終ボタンの有効・無効を現在地に合わせて更新
        updateNavButtonStates(activeIndex);
    }

    /**
     * 一覧の表示／非表示を切り替える（OFF は領域も確保せずパレットを縮める） / Toggle the list and shrink/grow the palette by its height
     * OFF 時は layout(true) で残りの要素にぴったり収まる高さへ詰め、ON 時は記録した高さへ正確に戻す
     * @param {boolean} showList - 一覧を表示するなら true
     * @returns {void}
     */
    function applyArtboardListVisibility(showList) {
        var keptWidth = paletteWindow.size[0];

        if (showList) {
            artboardListBox.visible = true;
            // 固定 preferredSize を解除してから再計算（解除しないと縮まらない）
            paletteWindow.preferredSize = [-1, -1];
            paletteWindow.layout.layout(true);
            // 幅は維持し、高さは OFF 前の値へ戻す（手動リサイズも保持）
            paletteWindow.size = [keptWidth, (shownWindowHeight !== null) ? shownWindowHeight : paletteWindow.size[1]];
            shownWindowHeight = null;
            paletteWindow.layout.resize();
        } else {
            // 戻すべき高さを記録してから、一覧を隠した状態の実高さへ詰める
            shownWindowHeight = paletteWindow.size[1];
            artboardListBox.visible = false;

            paletteWindow.preferredSize = [-1, -1];
            paletteWindow.layout.layout(true);

            paletteWindow.size = [keptWidth, paletteWindow.bounds.height];
            paletteWindow.layout.resize();
        }
    }

    // =========================================
    // BridgeTalk でメインエンジンへ処理を送る / Sending work to the main engine
    // =========================================

    /**
     * BridgeTalk ジョブを保持して送信する（完了・失敗で配列から外す。送信完了前に GC されないため）
     * @param {BridgeTalk} bridgeTalk - 送るジョブ
     * @param {Function} [onFailure] - 失敗時に追加で呼ぶ処理
     * @returns {void}
     */
    function sendTrackedJob(bridgeTalk, onFailure) {
        bridgeTalk.onResult = function () {
            removeNavigationJob(bridgeTalk);
        };
        bridgeTalk.onError = function () {
            removeNavigationJob(bridgeTalk);
            if (onFailure) {
                onFailure();
            }
        };
        $.global.artboardNavigatorJobs.push(bridgeTalk);
        trimNavigationJobs();
        bridgeTalk.send();
    }

    /**
     * ナビゲーション本体をメインエンジンへ一度だけ登録する / Install the worker into the main engine once
     * 以降のクリックは短い呼び出しだけ送るので、毎回の送信ペイロードが最小になる。
     * @returns {void}
     */
    function installNavigationWorker() {
        var bridgeTalk = newIllustratorBridgeTalk();
        bridgeTalk.body = "$.global.artboardNavigatorWorker = (" + getNavigationWorkerSource() + ");";
        sendTrackedJob(bridgeTalk);
        workerInstalled = true;
    }

    /**
     * ワーカー関数のソースを返す（toString() が関数の後ろのコメントまで取り込むので、終わりの目印で切り詰める）
     * @returns {string} 送信する関数のソース
     */
    function getNavigationWorkerSource() {
        var workerSource = navigationWorker.toString();
        var endMarkerIndex = workerSource.indexOf("/* @@navigation-worker-end@@ */");
        if (endMarkerIndex < 0) {
            return workerSource;
        }
        return workerSource.substring(0, endMarkerIndex) + "}";
    }

    /**
     * 登録済みワーカーを短い呼び出しだけで実行する / Invoke the installed worker with a short call
     * @param {string} navCommand - ナビゲーションコマンド
     * @param {boolean} allowReinstall - 失敗時にワーカーを登録し直して1回だけ再試行するなら true
     * @returns {void}
     */
    function sendNavigation(navCommand, allowReinstall) {
        var bridgeTalk = newIllustratorBridgeTalk();
        bridgeTalk.body = buildNavigationCall(navCommand);
        sendTrackedJob(bridgeTalk, function () {
            // ワーカー未登録などで失敗したら、登録し直して1回だけ再試行
            if (allowReinstall) {
                workerInstalled = false;
                installNavigationWorker();
                sendNavigation(navCommand, false);
            }
        });
    }

    /**
     * メインエンジンへラベル即時消去を依頼する（パレットを閉じるときなど） / Ask the main engine to remove labels now (e.g. on close)
     * @returns {void}
     */
    function requestLabelRemoval() {
        if (typeof BridgeTalk === "undefined") {
            return;
        }
        try {
            var bridgeTalk = newIllustratorBridgeTalk();
            bridgeTalk.body = "if($.global.artboardNavigatorRemoveLabels)$.global.artboardNavigatorRemoveLabels();";
            // 送信完了前に GC されないよう、他の送信と同じジョブ配列で保持する
            sendTrackedJob(bridgeTalk);
        } catch (e) {
        }
    }

    /**
     * パレット側から "ArtboardNavigator" レイヤーを直接削除する / Remove the "ArtboardNavigator" layer directly from the palette engine
     * requestLabelRemoval（メインエンジン経由）は worker 関数が未定義だと無効なため、
     * 「アートボード名を表示」OFF の瞬間に確実に消すための、BridgeTalk に依存しない直接削除。
     * 前回セッションからドキュメントに残った専用レイヤーも、未ナビゲートのまま OFF にすれば消える。
     * @returns {void}
     */
    function removeLabelLayerDirect() {
        if (app.documents.length === 0) {
            return;
        }
        try {
            var doc = app.activeDocument;
            for (var i = doc.layers.length - 1; i >= 0; i--) {
                if (doc.layers[i].name === "ArtboardNavigator") {
                    try {
                        doc.layers[i].locked = false;
                        doc.layers[i].remove();
                    } catch (layerError) {
                    }
                }
            }
            app.redraw();
        } catch (e) {
        }
    }

    /**
     * Illustrator 宛ての BridgeTalk を生成する / Create a BridgeTalk addressed to Illustrator
     * @returns {BridgeTalk} 宛先を設定した BridgeTalk
     */
    function newIllustratorBridgeTalk() {
        var bridgeTalk = new BridgeTalk();
        bridgeTalk.target = BridgeTalk.appSpecifier;
        return bridgeTalk;
    }

    /**
     * 登録済みワーカーの呼び出し文を組み立てる / Build the call string for the installed worker
     * @param {string} navCommand - ナビゲーションコマンド
     * @returns {string} メインエンジンで評価する呼び出し文
     */
    function buildNavigationCall(navCommand) {
        return "$.global.artboardNavigatorWorker(" +
            quoteForScript(navCommand) + "," +
            animationStepCount + "," +
            frameDelayMs + "," +
            fitMarginRatio + "," +
            String(!!easeCheckbox.value) + "," +
            String(!!preziCheckbox.value) + "," +
            String(!!animationCheckbox.value) + "," +
            preziDipRatio + "," +
            LABEL_FONT_RATIO + "," +
            LABEL_BACKGROUND_OPACITY + "," +
            LABEL_TEXT_OPACITY + "," +
            String(!!showArtboardNameCheckbox.value) +
            ");";
    }

    /**
     * 文字列を安全に引用符で囲む / Quote a string safely for embedding in script
     * @param {string} value - 囲む値
     * @returns {string} 引用符付きの文字列リテラル
     */
    function quoteForScript(value) {
        return '"' + String(value).replace(/\\/g, "\\\\").replace(/"/g, '\\"') + '"';
    }

    /**
     * 保留中の BridgeTalk ジョブを一定数に保つ / Keep pending BridgeTalk jobs under a limit
     * @returns {void}
     */
    function trimNavigationJobs() {
        var pendingJobs = $.global.artboardNavigatorJobs;
        while (pendingJobs.length > MAX_PENDING_JOBS) {
            pendingJobs.shift();
        }
    }

    /**
     * 完了したジョブを配列から取り除く / Remove a finished job from the array
     * @param {BridgeTalk} bridgeTalk - 取り除くジョブ
     * @returns {void}
     */
    function removeNavigationJob(bridgeTalk) {
        var pendingJobs = $.global.artboardNavigatorJobs;
        for (var i = pendingJobs.length - 1; i >= 0; i--) {
            if (pendingJobs[i] === bridgeTalk) {
                pendingJobs.splice(i, 1);
            }
        }
    }

    // =========================================
    // メインエンジンで実行される本体（BridgeTalk で送信）/ Worker run in the main engine (sent via BridgeTalk)
    // ※ この関数は toString() で文字列化して送るため、外側の変数を参照せず引数とアプリ DOM だけで完結させる。
    //   JSDoc を付けず、関数内のコメントは /* */ だけにする（toString() の出力が壊れて構文エラーになるため）
    //   toString() は関数の後ろのコメントまで取り込むので、末尾の目印 @@navigation-worker-end@@ で切り詰めて送る（消さないこと）
    // =========================================

    /* メインエンジンで移動を実行する本体 / Worker that performs the move in the main engine */
    function navigationWorker(navCommand, stepCount, delayMs, marginRatio, useEasing, preziMode, animate, preziDipRatio, labelFontRatio, labelBackgroundOpacity, labelTextOpacity, showLabel) {
        try {
            if (!app.documents || app.documents.length < 1) {
                return "ドキュメントが開かれていません。";
            }

            var doc = app.activeDocument;
            if (doc.artboards.length < 2) {
                return "アートボードが2つ以上必要です。";
            }

            var activeView = doc.views[0];
            var targetView;

            /* Prezi 風のズームダウンは個別アートボードへの移動時のみ（全体表示では使わない） */
            var usePreziDip = false;

            /* 移動先のラベルを出すアートボード番号（-1 = ラベルを出さない＝全体表示） */
            var labelIndex = -1;

            /* ラベルは専用レイヤー "ArtboardNavigator"（ロックON・プリントOFF）に描画する。 */
            var LABEL_LAYER_NAME = "ArtboardNavigator";
            var LABEL_ITEM_NAME = "__ArtboardNavigatorLabel";

            /* パレットからの即時消去依頼（チェックOFF・パレットを閉じる時など）に応える削除関数。 */
            /* 専用レイヤーごと削除し、レイヤーも残さない。文字列から呼べるよう $.global に公開。 */
            if (typeof $.global.artboardNavigatorRemoveLabels !== "function") {
                $.global.artboardNavigatorRemoveLabels = function () {
                    try {
                        if (app.documents.length === 0) {
                            return;
                        }
                        var labelDoc = app.activeDocument;
                        for (var k = labelDoc.layers.length - 1; k >= 0; k--) {
                            if (labelDoc.layers[k].name === "ArtboardNavigator") {
                                try {
                                    labelDoc.layers[k].locked = false;
                                    labelDoc.layers[k].remove();
                                } catch (layerError) {
                                }
                            }
                        }
                        app.redraw();
                    } catch (removeError) {
                    }
                };
            }

            if (navCommand === "list") {
                targetView = measureAllArtboardsView();
            } else {
                var targetIndex = resolveWorkerTargetIndex(navCommand);
                if (targetIndex < 0) {
                    return "範囲外のアートボード: " + navCommand;
                }
                targetView = measureArtboardView(targetIndex);
                doc.artboards.setActiveArtboardIndex(targetIndex);
                usePreziDip = preziMode;
                labelIndex = targetIndex;
            }

            animateViewTo(targetView.centerX, targetView.centerY, targetView.zoom, usePreziDip);

            /* 移動後に左上ラベルを更新。 */
            /* ・「アートボード名を表示」OFF、または全体表示のときは描画せず専用レイヤーごと削除 */
            /* ・ラベル描画が失敗しても移動自体は成立させる */
            try {
                if (showLabel && labelIndex >= 0) {
                    showArtboardLabel(labelIndex);
                } else {
                    removeLabelLayer();
                    app.redraw();
                }
            } catch (labelError) {
            }

            return "ok";

            /* ----- 以下、メインエンジン内のヘルパー（巻き上げで先に定義扱い） ----- */
            /* 役割ごとに ①アニメーション ②ビュー計測 ③ラベルレイヤー操作 ④ラベル処理 に分かれる。 */

            /* ===== ⓪ 移動先 / Destination ===== */

            /* コマンドを移動先のアートボード番号にする（範囲外は -1） / Resolve a command to an artboard index (-1 when out of range) */
            function resolveWorkerTargetIndex(workerCommand) {
                var artboardCount = doc.artboards.length;
                var currentIndex = doc.artboards.getActiveArtboardIndex();
                if (workerCommand === "prev") { return (currentIndex - 1 + artboardCount) % artboardCount; }
                if (workerCommand === "next") { return (currentIndex + 1) % artboardCount; }
                if (workerCommand === "first") { return 0; }
                if (workerCommand === "last") { return artboardCount - 1; }
                /* 一覧から選ばれた絶対インデックス（数値文字列） */
                var explicitIndex = parseInt(workerCommand, 10);
                if (isNaN(explicitIndex) || explicitIndex < 0 || explicitIndex >= artboardCount) { return -1; }
                return explicitIndex;
            }

            /* ===== ① アニメーション / Animation ===== */

            /* 現在のビューから目標へなめらかに移動 / Animate the view from current to target */
            function animateViewTo(targetCenterX, targetCenterY, targetZoom, preziDip) {
                /* アニメーション OFF のときは補間せず一気に目標へジャンプ */
                if (!animate) {
                    activeView.centerPoint = [targetCenterX, targetCenterY];
                    activeView.zoom = targetZoom;
                    app.redraw();
                    return;
                }

                var startCenterPoint = activeView.centerPoint;
                var startCenterX = startCenterPoint[0];
                var startCenterY = startCenterPoint[1];
                var startZoom = activeView.zoom;

                /* 移動量に応じてステップ数を調整（小さい移動は少ないステップで素早く） */
                var effectiveSteps = resolveStepCount(
                    startCenterX, startCenterY, startZoom,
                    targetCenterX, targetCenterY, targetZoom
                );

                for (var i = 1; i <= effectiveSteps; i++) {
                    var progress = i / effectiveSteps;

                    /* useEasing が OFF のときは線形（イーズなし） */
                    /* ON のときは easeOutQuad（出だしは速く、終わりにゆっくり減速） */
                    /* ＝押した瞬間に動き出すので開始のタイムラグを感じにくい */
                    var easedProgress = useEasing
                        ? 1 - (1 - progress) * (1 - progress)
                        : progress;

                    var frameCenterX = startCenterX + (targetCenterX - startCenterX) * easedProgress;
                    var frameCenterY = startCenterY + (targetCenterY - startCenterY) * easedProgress;
                    var frameZoom = startZoom + (targetZoom - startZoom) * easedProgress;

                    /* Prezi モード：移動の中盤でズームを最大 preziDipRatio ぶん下げ、 */
                    /* 出入りは sin カーブで滑らかに（始点・終点では 1.0 に戻る） */
                    if (preziDip) {
                        var dipMultiplier = 1 - preziDipRatio * Math.sin(progress * Math.PI);
                        if (dipMultiplier < 0.05) { dipMultiplier = 0.05; } /* ズーム 0 を回避 */
                        frameZoom = frameZoom * dipMultiplier;
                    }

                    activeView.centerPoint = [frameCenterX, frameCenterY];
                    activeView.zoom = frameZoom;

                    app.redraw();
                    sleep(delayMs);
                }

                /* 最後に正確に合わせる */
                activeView.centerPoint = [targetCenterX, targetCenterY];
                activeView.zoom = targetZoom;
                app.redraw();
            }

            /* 移動量に応じてステップ数を決める / Decide step count from the move magnitude */
            /* 画面に対するパン量とズーム変化率の大きい方を minSteps〜stepCount に対応づける */
            function resolveStepCount(startX, startY, startZoom, targetX, targetY, targetZoom) {
                var magnitude;

                try {
                    var viewBounds = activeView.bounds;
                    /* viewBounds = [left, top, right, bottom]（現在ズームでのドキュメント座標） */
                    var visibleExtent = Math.max(
                        Math.abs(viewBounds[2] - viewBounds[0]),
                        Math.abs(viewBounds[1] - viewBounds[3])
                    );

                    var moveDistance = Math.sqrt((targetX - startX) * (targetX - startX) + (targetY - startY) * (targetY - startY));
                    var moveFraction = (visibleExtent > 0) ? (moveDistance / visibleExtent) : 1;

                    var maxZoom = Math.max(startZoom, targetZoom);
                    var zoomFraction = (maxZoom > 0) ? (Math.abs(targetZoom - startZoom) / maxZoom) : 0;

                    magnitude = Math.max(moveFraction, zoomFraction);
                } catch (e) {
                    /* 計測できなければフルステップ */
                    return stepCount;
                }

                if (magnitude > 1) {
                    magnitude = 1;
                }

                var minSteps = Math.max(2, Math.round(stepCount * 0.2));
                var resolvedSteps = Math.round(stepCount * magnitude);

                if (resolvedSteps < minSteps) {
                    resolvedSteps = minSteps;
                }
                if (resolvedSteps > stepCount) {
                    resolvedSteps = stepCount;
                }

                return resolvedSteps;
            }

            /* ===== ② ビュー計測（中心・ズームの算出）/ View metrics ===== */

            /* 指定アートボードの中心とズームを求める / Compute center and zoom for one artboard */
            function measureArtboardView(artboardIndex) {
                var artboardRect = doc.artboards[artboardIndex].artboardRect;
                /* artboardRect = [left, top, right, bottom]（Illustrator は y 上向きで top > bottom） */

                return {
                    centerX: (artboardRect[0] + artboardRect[2]) / 2,
                    centerY: (artboardRect[1] + artboardRect[3]) / 2,
                    zoom: computeFitZoom(artboardRect[2] - artboardRect[0], artboardRect[1] - artboardRect[3], artboardIndex)
                };
            }

            /* 全アートボードを収める中心とズームを求める / Compute center and zoom to fit all artboards */
            function measureAllArtboardsView() {
                var unionRect = doc.artboards[0].artboardRect.slice(0);

                for (var i = 1; i < doc.artboards.length; i++) {
                    var artboardRect = doc.artboards[i].artboardRect;
                    if (artboardRect[0] < unionRect[0]) { unionRect[0] = artboardRect[0]; }
                    if (artboardRect[1] > unionRect[1]) { unionRect[1] = artboardRect[1]; }
                    if (artboardRect[2] > unionRect[2]) { unionRect[2] = artboardRect[2]; }
                    if (artboardRect[3] < unionRect[3]) { unionRect[3] = artboardRect[3]; }
                }

                return {
                    centerX: (unionRect[0] + unionRect[2]) / 2,
                    centerY: (unionRect[1] + unionRect[3]) / 2,
                    zoom: computeFitZoom(unionRect[2] - unionRect[0], unionRect[1] - unionRect[3], "all")
                };
            }

            /* 対象を収めるズームを activeView.bounds から算出 / Compute fit zoom from activeView.bounds */
            /* メニューコマンドもビュー変更も使わないため、移動開始前のタイムラグが出ない。 */
            function computeFitZoom(targetWidth, targetHeight, fallbackTarget) {
                try {
                    var viewBounds = activeView.bounds;
                    /* viewBounds = [left, top, right, bottom]（ドキュメント座標） */
                    var visibleWidth = Math.abs(viewBounds[2] - viewBounds[0]);
                    var visibleHeight = Math.abs(viewBounds[1] - viewBounds[3]);

                    if (visibleWidth > 0 && visibleHeight > 0 && targetWidth > 0 && targetHeight > 0) {
                        var currentZoom = activeView.zoom;
                        var fitZoom = Math.min(
                            currentZoom * visibleWidth / targetWidth,
                            currentZoom * visibleHeight / targetHeight
                        );
                        return fitZoom * marginRatio;
                    }
                } catch (e) {
                }

                /* フォールバック: 実際に fitin / fitall して計測（環境差対策） */
                return measureFitZoomByMenu(fallbackTarget);
            }

            /* fitin/fitall で実測するフォールバック / Fallback that measures via fitin/fitall */
            function measureFitZoomByMenu(fallbackTarget) {
                var beforeCenterPoint = activeView.centerPoint;
                var beforeZoom = activeView.zoom;

                if (fallbackTarget === "all") {
                    app.executeMenuCommand("fitall");
                } else {
                    doc.artboards.setActiveArtboardIndex(fallbackTarget);
                    app.executeMenuCommand("fitin");
                }

                var fitZoom = activeView.zoom;

                activeView.centerPoint = beforeCenterPoint;
                activeView.zoom = beforeZoom;

                return fitZoom * marginRatio;
            }

            /* 指定ミリ秒だけ待機（同期、アニメーションのフレーム間隔用） / Busy-wait for the given milliseconds (animation frame delay) */
            function sleep(durationMs) {
                var sleepStartTime = new Date().getTime();
                while (new Date().getTime() - sleepStartTime < durationMs) { }
            }

            /* ===== ③ ラベルレイヤー操作 / Label layer ===== */

            /* ラベル専用レイヤーを探す（無ければ null） / Find the dedicated label layer (null if absent) */
            function findLabelLayer() {
                for (var i = 0; i < doc.layers.length; i++) {
                    if (doc.layers[i].name === LABEL_LAYER_NAME) {
                        return doc.layers[i];
                    }
                }
                return null;
            }

            /* ラベル専用レイヤーごと削除（レイヤーも残さない） / Remove the dedicated label layer entirely */
            function removeLabelLayer() {
                var labelLayer = findLabelLayer();
                if (!labelLayer) {
                    return;
                }
                /* 親レイヤーのロックなどで削除できないことがある */
                try {
                    labelLayer.locked = false;
                    labelLayer.remove();
                } catch (removeError) {
                }
            }

            /* ===== ④ ラベル処理（描画）/ Label drawing ===== */

            /* ドキュメントのカラースペースに合わせて白／黒を作る / Build white or black for the document color space */
            function makeLabelColor(isWhite) {
                if (doc.documentColorSpace === DocumentColorSpace.CMYK) {
                    var cmykColor = new CMYKColor();
                    cmykColor.cyan = 0;
                    cmykColor.magenta = 0;
                    cmykColor.yellow = 0;
                    cmykColor.black = isWhite ? 0 : 100;
                    return cmykColor;
                }
                var rgbColor = new RGBColor();
                var channelValue = isWhite ? 255 : 0;
                rgbColor.red = channelValue;
                rgbColor.green = channelValue;
                rgbColor.blue = channelValue;
                return rgbColor;
            }

            /* アートボード左上に「番号：名前」ラベルを専用レイヤー（ロックON・プリントOFF）へ描画 / Draw the "index: name" label on a dedicated locked, non-printing layer */
            function showArtboardLabel(artboardIndex) {
                var artboard = doc.artboards[artboardIndex];
                var artboardRect = artboard.artboardRect; /* [left, top, right, bottom] */

                /* 文字サイズはアートボード幅に比例（画面フィット後の見た目をほぼ一定に） */
                var fontSize = Math.max(1, (artboardRect[2] - artboardRect[0]) * labelFontRatio);
                var edgeMargin = fontSize * 0.6;

                /* 専用レイヤーを作り直す（位置・内容をリセットし、常に1枚に保つ）。 */
                /* 作業レイヤーを巻き込まないよう、描画後にアクティブレイヤーを元へ戻す。 */
                var prevActiveLayer = doc.activeLayer;
                removeLabelLayer();
                var labelLayer = doc.layers.add();
                labelLayer.name = LABEL_LAYER_NAME;

                var labelGroup = labelLayer.groupItems.add();
                labelGroup.name = LABEL_ITEM_NAME;

                var textFrame = addLabelText(labelLayer, (artboardIndex + 1) + "：" + artboard.name, fontSize);
                var backgroundRect = addLabelBackground(labelLayer, textFrame, fontSize);

                /* 重ね順を明示：背景の長方形を背面（PLACEATEND）、テキストを前面（PLACEATBEGINNING）へ。 */
                /* 挿入順に依存せず、必ずテキストが前面・長方形が背面になる。 */
                backgroundRect.move(labelGroup, ElementPlacement.PLACEATEND);
                textFrame.move(labelGroup, ElementPlacement.PLACEATBEGINNING);

                /* アートボードの左上へ少し内側に配置 */
                labelGroup.position = [artboardRect[0] + edgeMargin, artboardRect[1] - edgeMargin];

                /* レイヤーをプリントOFF・ロックON にし、作業レイヤーを元に戻す */
                labelLayer.printable = false;
                labelLayer.locked = true;
                /* 元のレイヤーがロック・非表示だと戻せないことがある */
                try {
                    doc.activeLayer = prevActiveLayer;
                } catch (restoreError) {
                }

                app.redraw();
            }

            /* ラベルの文字（白・HiraginoSans-W6）を作る / Create the label text (white, HiraginoSans-W6) */
            function addLabelText(labelLayer, labelContents, fontSize) {
                var textFrame = labelLayer.textFrames.pointText([0, 0]);
                textFrame.contents = labelContents;
                var labelCharAttributes = textFrame.textRange.characterAttributes;
                /* フォントが入っていない環境では既定のフォントのまま */
                try {
                    labelCharAttributes.textFont = app.textFonts.getByName("HiraginoSans-W6");
                } catch (fontError) {
                }
                labelCharAttributes.size = fontSize;
                labelCharAttributes.fillColor = makeLabelColor(true);
                textFrame.opacity = labelTextOpacity;
                return textFrame;
            }

            /* 文字を囲む背景の長方形（黒）を作る / Create the black background rectangle around the text */
            function addLabelBackground(labelLayer, textFrame, fontSize) {
                var paddingX = fontSize * 0.45;
                var paddingY = fontSize * 0.30;
                var textBounds = textFrame.geometricBounds; /* [left, top, right, bottom] */
                var backgroundRect = labelLayer.pathItems.rectangle(
                    textBounds[1] + paddingY,
                    textBounds[0] - paddingX,
                    (textBounds[2] - textBounds[0]) + paddingX * 2,
                    (textBounds[1] - textBounds[3]) + paddingY * 2
                );
                backgroundRect.stroked = false;
                backgroundRect.filled = true;
                backgroundRect.fillColor = makeLabelColor(false);
                backgroundRect.opacity = labelBackgroundOpacity;
                return backgroundRect;
            }
        } catch (e) {
            return "エラー: " + e.message;
        }
        /* @@navigation-worker-end@@ */
    }

    // =========================================
    // ウィンドウ位置の保存・復元 / Palette position
    // =========================================

    /**
     * 保存したウィンドウ位置を復元する / Restore the saved window position
     * @param {Window} targetWindow - 対象のパレット
     * @returns {void}
     */
    function restoreWindowPosition(targetWindow) {
        if (!POSITION_FILE.exists) {
            return;
        }

        try {
            if (!POSITION_FILE.open("r")) {
                return;
            }
            var savedPositionText = POSITION_FILE.read();
            POSITION_FILE.close();

            var positionParts = savedPositionText.split(",");
            if (positionParts.length !== 2) {
                return;
            }

            var savedLeft = parseInt(positionParts[0], 10);
            var savedTop = parseInt(positionParts[1], 10);
            if (isNaN(savedLeft) || isNaN(savedTop)) {
                return;
            }

            // モニタ構成の変更などで画面外（不可視）になる位置は無視し、既定位置で開く
            if (!isLocationVisible(savedLeft, savedTop)) {
                return;
            }

            targetWindow.location = [savedLeft, savedTop];
        } catch (e) {
        }
    }

    /**
     * 指定座標（ウィンドウ左上）がいずれかのスクリーン内で、タイトルバーを掴める範囲か
     * Whether the top-left point sits on a screen with the title bar reachable
     * @param {number} windowLeft - ウィンドウ左上の X
     * @param {number} windowTop - ウィンドウ左上の Y
     * @returns {boolean} 見える位置なら true（スクリーン情報が取れないときも true）
     */
    function isLocationVisible(windowLeft, windowTop) {
        var screens = $.screens;
        // スクリーン情報を取得できない環境では従来どおり許可
        if (!screens || !screens.length) {
            return true;
        }
        for (var i = 0; i < screens.length; i++) {
            var screenBounds = screens[i];
            // 左上がスクリーン内に収まり、右端・下端には掴むための余白（幅60/高さ40）を残す
            if (windowLeft >= screenBounds.left && windowLeft <= screenBounds.right - 60 &&
                windowTop >= screenBounds.top && windowTop <= screenBounds.bottom - 40) {
                return true;
            }
        }
        return false;
    }

    /**
     * 現在のウィンドウ位置を保存する / Save the current window position
     * @param {Window} targetWindow - 対象のパレット
     * @returns {void}
     */
    function saveWindowPosition(targetWindow) {
        try {
            var prefFolder = POSITION_FILE.parent;
            if (!prefFolder.exists) {
                prefFolder.create();
            }

            if (!POSITION_FILE.open("w")) {
                return;
            }
            POSITION_FILE.write(targetWindow.location[0] + "," + targetWindow.location[1]);
            POSITION_FILE.close();
        } catch (e) {
        }
    }

    // =========================================
    // 各設定の保存・復元 / Settings
    // =========================================

    /**
     * 現在の各設定を保存する / Save current settings
     * @returns {void}
     */
    function saveSettings() {
        settingsStore.save({
            animation: !!animationCheckbox.value,
            speed: speedSlider.value,
            ease: !!easeCheckbox.value,
            prezi: !!preziCheckbox.value,
            preziDip: preziDipSlider.value,
            listVisible: !!listVisibilityCheckbox.value,
            showLabel: !!showArtboardNameCheckbox.value
        });
    }

    /**
     * 数値を範囲内に収める / Clamp a number into a range
     * @param {number} sourceValue - 元の値
     * @param {number} minValue - 下限
     * @param {number} maxValue - 上限
     * @returns {number} 範囲内に収めた値
     */
    function clampNumber(sourceValue, minValue, maxValue) {
        return Math.min(maxValue, Math.max(minValue, sourceValue));
    }

})();
