#target illustrator
#targetengine "KeepActiveArtboardOnlyEngine"
app.preferences.setBooleanPreference('ShowExternalJSXWarning', false);

/*
SCRIPTMETA-BEGIN
Script-ID=com.swwwitch.illustrator.KeepActiveArtboardOnly
Name=アクティブなアートボードだけを残す
Author=Masahiro Takano (@swwwitch)
Target-App=Illustrator
Version=1.2.11
Release-Date=2025-08-15
Description-BEGIN
アクティブなアートボードだけを残すか、空のアートボードをまとめて削除します。
アクティブなアートボードだけを残す場合は、その外側にあるオブジェクト（ガイドを含む）も削除できます。

Keeps only the active artboard, or removes every empty artboard in one pass.
When the active artboard is kept, the objects outside it — guides included — can be deleted as well.
Description-END
SCRIPTMETA-END
*/

/*

### 概要

アクティブなアートボードだけを残すか、空のアートボードをまとめて削除します。
アクティブなアートボードだけを残す場合は、その外側にあるオブジェクト（ガイドを含む）も削除できます。

詳細は README を参照してください。
https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/KeepActiveArtboardOnly.md

### Overview

Keeps only the active artboard, or removes every empty artboard in one pass.
When the active artboard is kept, the objects outside it — guides included — can be deleted as well.

See the README for details.
https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/KeepActiveArtboardOnly.md

*/

// =========================================
// 基本情報 / Basic info
// =========================================
var SCRIPT_NAME     = "KeepActiveArtboardOnly";       /* スクリプト名 / script name */
var SCRIPT_VERSION  = "v1.2.11";                      /* バージョン / version */
var SCRIPT_AUTHOR   = "Masahiro Takano (@swwwitch)";  /* 作者 / author */
var SCRIPT_RELEASED = "2025-08-15";                   /* 最初のリリース日 / first release date */
var SCRIPT_UPDATED  = "2026-10-16";                   /* 更新日 / last updated */

var SCRIPT_DESCRIPTION_JA = "アクティブなアートボードだけを残す"; /* README の見出し / README title (Japanese) */

var SCRIPT_README_JA  = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/KeepActiveArtboardOnly.md"; /* README（日本語） */
var SCRIPT_README_EN  = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/KeepActiveArtboardOnly.md"; /* README (English) */
var SCRIPT_SOURCE_URL = "https://github.com/swwwitch/illustrator-scripts/blob/master/jsx/artboard/KeepActiveArtboardOnly.jsx"; /* 最新版のソース / latest source */

// Released under the MIT license
// http://opensource.org/licenses/mit-license.php

(function () {

    // =========================================
    // ユーザー設定 / User settings
    // =========================================

    /* アクティブなアートボード以外を削除するとき、外側のオブジェクトも削除するか / Delete the objects outside the kept artboard */
    var DEFAULT_DELETE_OUTSIDE_OBJECTS = true;

    /* 空のアートボードを探すとき、非表示のレイヤー・オブジェクトを無視するか / Ignore hidden layers and objects while looking for empty artboards */
    var DEFAULT_IGNORE_HIDDEN = true;

    // =========================================
    // レイアウト / Layout
    // =========================================

    // UIレイアウト（再利用パーツ） / UI layout (reusable)

    /* ウィンドウ・パネルの余白と間隔 / Window & panel margins and spacing */
    var WINDOW_MARGINS = 16;                 /* ウィンドウ外周の余白 / window margin */
    var WINDOW_SPACING = 12;                 /* ウィンドウ内の要素間隔 / window spacing */
    var PANEL_MARGINS  = [16, 20, 16, 12];   /* パネル余白 [左,上,右,下] / panel margins */
    var PANEL_SPACING  = 12;                 /* パネル内の要素間隔 / panel spacing */
    var COLUMN_SPACING = 12;                 /* 2カラムの間隔 / gap between columns */
    var TAB_MARGINS    = [15, 20, 5, 10];    /* タブ余白 [左,上,右,下] / tab margins */

    /**
     * ウィンドウの共通設定
     * @param {Window} targetWindow - 対象のウィンドウ
     * @param {number} [spacing] - 要素間隔（省略時は WINDOW_SPACING）
     * @returns {void}
     */
    function setupWindow(targetWindow, spacing) {
        targetWindow.orientation = "column";
        targetWindow.alignChildren = "fill";
        targetWindow.margins = WINDOW_MARGINS;
        targetWindow.spacing = (typeof spacing === "number") ? spacing : WINDOW_SPACING;
    }

    /**
     * パネルの共通設定（子は幅いっぱい。ボタンは alignment = "left" で広げない）
     * @param {Panel} targetPanel - 対象のパネル
     * @param {number} [spacing] - 要素間隔（省略時は PANEL_SPACING）
     * @returns {void}
     */
    function setupPanel(targetPanel, spacing) {
        targetPanel.orientation = "column";
        targetPanel.alignChildren = ["fill", "top"];
        targetPanel.alignment = "fill";
        targetPanel.margins = PANEL_MARGINS;
        targetPanel.spacing = (typeof spacing === "number") ? spacing : PANEL_SPACING;
    }

    /**
     * タブの共通設定
     * @param {Tab} targetTab - 対象のタブ
     * @param {number} [spacing] - 要素間隔（省略時は変えない）
     * @returns {void}
     */
    function setupTab(targetTab, spacing) {
        targetTab.orientation = "column";
        targetTab.alignChildren = "fill";
        targetTab.margins = TAB_MARGINS;
        if (typeof spacing === "number") targetTab.spacing = spacing;
    }

    /**
     * 横並びの行グループの共通設定（ボタン列など）。
     * alignment と alignChildren を対で指定し、中のボタンが横に伸びたり天地がずれたりしないようにする
     * @param {Group} rowGroup - 対象のグループ
     * @param {string|string[]} [rowAlignment] - 横方向の alignment（省略時は "left"）。配列ならそのまま使う
     * @param {number} [spacing] - 要素間隔（省略時は PANEL_SPACING）
     * @returns {void}
     */
    function setupRow(rowGroup, rowAlignment, spacing) {
        rowGroup.orientation = "row";
        rowGroup.alignment = (rowAlignment instanceof Array) ? rowAlignment : [rowAlignment || "left", "center"];
        rowGroup.alignChildren = ["left", "center"];
        rowGroup.spacing = (typeof spacing === "number") ? spacing : PANEL_SPACING;
    }

    /**
     * ボタンの高さを指定した px だけ詰める（レイアウトが決まったあとに呼ぶ）
     * @param {Button} targetButton - 対象のボタン
     * @param {number} trimPixels - 詰める量（px）
     * @returns {void}
     */
    function trimButtonHeight(targetButton, trimPixels) {
        /* レイアウト前は size が無い / size is not set until the layout runs */
        if (!targetButton.size) return;
        targetButton.size = [targetButton.size.width, targetButton.size.height - trimPixels];
    }

    // UIレイアウト（再利用パーツ）ここまで / End of the reusable UI layout

    var OPTION_INDENT_MARGINS = [18, 0, 0, 2];  /* ラジオ直下のオプションのインデント */
    var COUNT_TEXT_WIDTH = 220;                 /* 件数表示の幅（後から伸びないため確保） */
    var BUTTON_WIDTH = 80;                      /* ボタン幅 */

    // =========================================
    // ローカライズ / Localization
    // =========================================

    // ローカライズ（再利用パーツ） / Localization (reusable)

    /**
     * UI の言語を返す（"ja" で始まるロケールは日本語、それ以外は英語）
     * @returns {string} "ja" または "en"
     */
    function getCurrentLang() {
        return (String($.locale || "").indexOf("ja") === 0) ? "ja" : "en";
    }

    var uiLang = getCurrentLang();

    /**
     * LABELS から今の UI 言語の文言を取り出す。
     * @param {string|Object} labelRef - "dialog.title" のようなパス、または { ja, en }
     * @param {Object|Array} [placeholderValues] - { name: 値 } なら {name} を、[値, …] なら %1, %2 … を差し込む
     * @returns {string} 文言。パスが見つからなければパスの文字列、{ ja, en } が無ければ空文字
     */
    function getLabel(labelRef, placeholderValues) {
        var labelEntry = labelRef;
        if (typeof labelRef === "string") {
            var labelPathKeys = labelRef.split(".");
            labelEntry = LABELS;
            for (var i = 0; i < labelPathKeys.length && labelEntry != null; i++) {
                labelEntry = labelEntry[labelPathKeys[i]];
            }
        }
        var labelString;
        if (typeof labelEntry === "string") labelString = labelEntry;
        else if (labelEntry != null && labelEntry[uiLang] != null) labelString = labelEntry[uiLang];
        else if (labelEntry != null && labelEntry.en != null) labelString = labelEntry.en;
        else return (typeof labelRef === "string") ? labelRef : "";
        return fillLabelPlaceholders(String(labelString), placeholderValues);
    }

    /**
     * 項目名の文言の末尾にコロンを付ける（日本語は半角スペース＋半角コロン「 :」、英語は「:」。Illustrator の線パネルなどの項目名に合わせる）
     * @param {string|Object} labelRef - getLabel と同じ
     * @param {Object|Array} [placeholderValues] - getLabel と同じ
     * @returns {string} コロン付きの文言
     */
    function labelText(labelRef, placeholderValues) {
        return getLabel(labelRef, placeholderValues) + (uiLang === "ja" ? " :" : ":");
    }

    /**
     * 「項目名 : 値」の1行を返す（日本語は「件数 : 5」、英語は「Count: 5」。どちらもコロンのあとに空白を入れる）
     * @param {string|Object} labelRef - getLabel と同じ
     * @param {string|number} value - コロンのあとに続ける値
     * @returns {string} 項目名と値をつないだ文字列
     */
    function labelValueText(labelRef, value) {
        return labelText(labelRef) + " " + value;
    }

    /**
     * 文言の {name} や %1 に値を差し込む
     * @param {string} labelString - 文言
     * @param {Object|Array} [placeholderValues] - { name: 値 } または [値, …]
     * @returns {string} 差し込んだ文言
     */
    function fillLabelPlaceholders(labelString, placeholderValues) {
        if (placeholderValues == null) return labelString;
        if (placeholderValues instanceof Array) {
            /* 大きい番号から置き換え、%1 が %10 の一部を置き換えないようにする / Replace from the highest index so %1 does not eat into %10 */
            for (var i = placeholderValues.length; i >= 1; i--) {
                labelString = labelString.split("%" + i).join(String(placeholderValues[i - 1]));
            }
            return labelString;
        }
        for (var placeholderKey in placeholderValues) {
            if (!placeholderValues.hasOwnProperty(placeholderKey)) continue;
            labelString = labelString.split("{" + placeholderKey + "}").join(String(placeholderValues[placeholderKey]));
        }
        return labelString;
    }

    // ローカライズ（再利用パーツ）ここまで / End of the reusable localization

    /* 日英ラベル定義 / Japanese-English label definitions */
    var LABELS = {
        dialog: {
            title: { ja: "アートボードの削除", en: "Remove Artboards" }
        },
        panel: {
            mode: { ja: "削除するアートボード", en: "Artboards to remove" }
        },
        radio: {
            keepActive: { ja: "アクティブなアートボード以外", en: "All but the active artboard" },
            empty:      { ja: "空のアートボード", en: "Empty artboards" }
        },
        checkbox: {
            deleteOutsideObjects: { ja: "アートボード外のオブジェクトも削除", en: "Also delete the objects outside it" },
            ignoreHidden:         { ja: "非表示レイヤー、非表示オブジェクトは無視", en: "Ignore hidden layers and hidden objects" }
        },
        fieldLabel: {
            removalTarget: { ja: "削除対象アートボード数", en: "Artboards to remove" }
        },
        tooltip: {
            keepActive: {
                ja: "アクティブなアートボードだけを残し、ほかのアートボードを削除します。",
                en: "Keeps just the active artboard and removes the others."
            },
            empty: {
                ja: "オブジェクトが載っていないアートボードをまとめて削除します。",
                en: "Removes every artboard with nothing on it."
            },
            deleteOutsideObjects: {
                ja: "残したアートボードの外側にあるオブジェクトとオブジェクトガイドも削除します。",
                en: "Also deletes the objects and object guides that sit outside the artboard you keep."
            },
            ignoreHidden: {
                ja: "非表示のレイヤーやオブジェクトしか載っていないアートボードも「空」とみなします。オフにすると、見えていなくても中身があれば残します。",
                en: "Treats an artboard holding only hidden layers or objects as empty. Off keeps it as long as anything is on it."
            },
            singleArtboard: {
                ja: "アートボードが1枚しかないため削除できません。",
                en: "Only one artboard exists; cannot remove."
            }
        },
        button: {
            ok:     { ja: "OK", en: "OK" },
            cancel: { ja: "キャンセル", en: "Cancel" }
        },
        alert: {
            noDocument: { ja: "ドキュメントが開かれていません。", en: "No document is open." }
        }
    };

    // =========================================
    // 重なり判定 / Hit testing
    // =========================================

    /* 共線とみなす外積の許容値 / Cross product below this counts as collinear */
    var COLLINEAR_EPSILON = 1e-6;

    /**
     * 点が矩形の内側（境界を含む）にあるか判定する
     * @param {number} x - X座標
     * @param {number} y - Y座標
     * @param {number[]} rect - 矩形 [left, top, right, bottom]
     * @returns {boolean} 内側にあれば true
     */
    function isPointInRect(x, y, rect) {
        return (x >= rect[0] && x <= rect[2] && y <= rect[1] && y >= rect[3]);
    }

    /**
     * 2Dベクトルの外積を返す
     * @param {number} ax - ベクトルAのX成分
     * @param {number} ay - ベクトルAのY成分
     * @param {number} bx - ベクトルBのX成分
     * @param {number} by - ベクトルBのY成分
     * @returns {number} 外積
     */
    function cross2D(ax, ay, bx, by) {
        return ax * by - ay * bx;
    }

    /**
     * 線分同士が交差するか判定する（共線で重なる場合も true）
     * @param {number} p1x - 線分Pの始点X
     * @param {number} p1y - 線分Pの始点Y
     * @param {number} p2x - 線分Pの終点X
     * @param {number} p2y - 線分Pの終点Y
     * @param {number} q1x - 線分Qの始点X
     * @param {number} q1y - 線分Qの始点Y
     * @param {number} q2x - 線分Qの終点X
     * @param {number} q2y - 線分Qの終点Y
     * @returns {boolean} 交差していれば true
     */
    function segmentsIntersect(p1x, p1y, p2x, p2y, q1x, q1y, q2x, q2y) {
        var pDx = p2x - p1x,
            pDy = p2y - p1y;
        var qDx = q2x - q1x,
            qDy = q2y - q1y;
        var denominator = cross2D(pDx, pDy, qDx, qDy);
        var p1ToQ1Dx = q1x - p1x,
            p1ToQ1Dy = q1y - p1y;

        if (denominator === 0) {
            /* 平行。共線でなければ交差しない / Parallel: no intersection unless collinear */
            if (Math.abs(cross2D(p1ToQ1Dx, p1ToQ1Dy, pDx, pDy)) > COLLINEAR_EPSILON) return false;
            /* 共線なら各軸への投影で重なりを見る / Collinear: check the overlap on each axis */
            var overlapX = !(Math.max(p1x, p2x) < Math.min(q1x, q2x) || Math.max(q1x, q2x) < Math.min(p1x, p2x));
            var overlapY = !(Math.max(p1y, p2y) < Math.min(q1y, q2y) || Math.max(q1y, q2y) < Math.min(p1y, p2y));
            return overlapX && overlapY;
        }

        var tParam = cross2D(p1ToQ1Dx, p1ToQ1Dy, qDx, qDy) / denominator;
        var uParam = cross2D(p1ToQ1Dx, p1ToQ1Dy, pDx, pDy) / denominator;
        return (tParam >= 0 && tParam <= 1 && uParam >= 0 && uParam <= 1);
    }

    /**
     * 線分が矩形と交差するか判定する
     * @param {number} x1 - 線分の始点X
     * @param {number} y1 - 線分の始点Y
     * @param {number} x2 - 線分の終点X
     * @param {number} y2 - 線分の終点Y
     * @param {number[]} rect - 矩形 [left, top, right, bottom]
     * @returns {boolean} 交差していれば true
     */
    function segmentIntersectsRect(x1, y1, x2, y2, rect) {
        /* 端点のどちらかが矩形内なら交差 / Either endpoint inside means a hit */
        if (isPointInRect(x1, y1, rect) || isPointInRect(x2, y2, rect)) return true;

        var left = rect[0],
            top = rect[1],
            right = rect[2],
            bottom = rect[3];

        return segmentsIntersect(x1, y1, x2, y2, left, top, right, top) ||
            segmentsIntersect(x1, y1, x2, y2, left, bottom, right, bottom) ||
            segmentsIntersect(x1, y1, x2, y2, left, top, left, bottom) ||
            segmentsIntersect(x1, y1, x2, y2, right, top, right, bottom);
    }

    /**
     * パスがアートボードと重なるか判定する（境界ボックスではなくパスの実体で判定）
     * @param {PathItem} pathItem - 判定するパス
     * @param {number[]} artboardRect - アートボードの矩形 [left, top, right, bottom]
     * @returns {boolean} 重なっていれば true
     */
    function pathIntersectsArtboard(pathItem, artboardRect) {
        try {
            var pathPoints = pathItem.pathPoints;
            if (!pathPoints || pathPoints.length === 0) return false;

            for (var i = 0; i < pathPoints.length; i++) {
                /* 開パスでは最後のアンカーから始点へは結ばない / Open paths do not wrap back to the start */
                if (!pathItem.closed && i === pathPoints.length - 1) break;
                var currentAnchor = pathPoints[i].anchor;
                var nextAnchor = pathPoints[(i + 1) % pathPoints.length].anchor;
                if (segmentIntersectsRect(currentAnchor[0], currentAnchor[1], nextAnchor[0], nextAnchor[1], artboardRect)) return true;
            }
            return false;
        } catch (e) {
            return false;
        }
    }

    /**
     * ページアイテムがアートボードと重なるか判定する
     * パス・複合パスはパスの実体で、それ以外は境界ボックスで判定する
     * @param {PageItem} pageItem - 判定するアイテム
     * @param {number[]} artboardRect - アートボードの矩形 [left, top, right, bottom]
     * @returns {boolean} 重なっていれば true
     */
    function itemIntersectsArtboard(pageItem, artboardRect) {
        if (pageItem.typename === 'CompoundPathItem') {
            var subPaths = pageItem.pathItems;
            for (var i = 0; i < subPaths.length; i++) {
                if (pathIntersectsArtboard(subPaths[i], artboardRect)) return true;
            }
            return false;
        }
        if (pageItem.typename === 'PathItem') {
            return pathIntersectsArtboard(pageItem, artboardRect);
        }
        /* その他は境界ボックスでフォールバック / Fall back to the bounding box */
        return rectsOverlap(artboardRect, pageItem.geometricBounds);
    }

    /**
     * アートボードと境界ボックスが重なるか判定する
     * @param {number[]} artboardRect - アートボードの矩形 [left, top, right, bottom]
     * @param {number[]} itemBounds - アイテムの境界 [left, top, right, bottom]
     * @returns {boolean} 重なっていれば true
     */
    function rectsOverlap(artboardRect, itemBounds) {
        return (
            itemBounds[0] < artboardRect[2] &&
            itemBounds[2] > artboardRect[0] &&
            itemBounds[1] > artboardRect[3] &&
            itemBounds[3] < artboardRect[1]
        );
    }

    // =========================================
    // ロック・表示状態の一時解除 / Relaxing locks and visibility
    // =========================================

    /**
     * レイヤーの状態を控えてロック・非表示・テンプレートを解除する（サブレイヤーとグループも再帰）
     * @param {Layer} layer - 対象レイヤー
     * @param {object[]} stateLog - 状態の控え
     * @returns {void}
     */
    function captureAndUnlockLayer(layer, stateLog) {
        stateLog.push({
            type: 'Layer',
            ref: layer,
            locked: layer.locked,
            visible: layer.visible,
            template: layer.template
        });

        layer.locked = false;
        layer.visible = true;
        if (layer.template === true) layer.template = false;

        for (var i = 0; i < layer.layers.length; i++) {
            captureAndUnlockLayer(layer.layers[i], stateLog);
        }
        for (var j = 0; j < layer.groupItems.length; j++) {
            captureAndUnlockGroup(layer.groupItems[j], stateLog);
        }
        captureAndUnlockItems(layer, stateLog);
    }

    /**
     * グループの状態を控えてロック・非表示を解除する（ネストしたグループも再帰）
     * @param {GroupItem} groupItem - 対象グループ
     * @param {object[]} stateLog - 状態の控え
     * @returns {void}
     */
    function captureAndUnlockGroup(groupItem, stateLog) {
        stateLog.push({
            type: 'Group',
            ref: groupItem,
            locked: groupItem.locked,
            visible: groupItem.visible
        });

        groupItem.locked = false;
        groupItem.visible = true;

        for (var i = 0; i < groupItem.groupItems.length; i++) {
            captureAndUnlockGroup(groupItem.groupItems[i], stateLog);
        }
        captureAndUnlockItems(groupItem, stateLog);
    }

    /**
     * コンテナ配下のページアイテムの状態を控えてロック・非表示を解除する
     * @param {Layer|GroupItem} container - レイヤーまたはグループ
     * @param {object[]} stateLog - 状態の控え
     * @returns {void}
     */
    function captureAndUnlockItems(container, stateLog) {
        try {
            var pageItems = container.pageItems;
            for (var i = 0; i < pageItems.length; i++) {
                var pageItem = pageItems[i];
                stateLog.push({
                    type: 'Item',
                    ref: pageItem,
                    locked: pageItem.locked,
                    hidden: pageItem.hidden
                });
                if (pageItem.locked) pageItem.locked = false;
                if (pageItem.hidden) pageItem.hidden = false;
            }
        } catch (e) { }
    }

    /**
     * ドキュメント全体のロック・表示状態を控えて一時解除する
     * @param {Document} doc - 対象ドキュメント
     * @returns {object[]} 復元用の状態の控え
     */
    function captureAndUnlockStructure(doc) {
        var stateLog = [];
        for (var i = 0; i < doc.layers.length; i++) {
            captureAndUnlockLayer(doc.layers[i], stateLog);
        }
        return stateLog;
    }

    /**
     * 控えた状態を復元する（下位から順に戻す）
     * @param {object[]} savedStates - captureAndUnlockStructure() が返した控え
     * @returns {void}
     */
    function restoreStructure(savedStates) {
        for (var i = savedStates.length - 1; i >= 0; i--) {
            var savedState = savedStates[i];
            /* 削除済みのオブジェクトは参照できない / deleted objects can no longer be restored */
            try {
                savedState.ref.locked = savedState.locked;
                if (savedState.type === 'Item') {
                    savedState.ref.hidden = savedState.hidden;
                } else {
                    savedState.ref.visible = savedState.visible;
                }
                if (savedState.type === 'Layer') savedState.ref.template = savedState.template;
            } catch (e) { }
        }
    }

    // =========================================
    // 空アートボードの判定 / Empty artboard detection
    // =========================================

    /**
     * オブジェクトと祖先がすべて表示状態か判定する
     * @param {PageItem} pageItem - 対象アイテム
     * @returns {boolean} 表示されていれば true
     */
    function isItemVisible(pageItem) {
        try {
            var ancestorNode = pageItem;
            while (ancestorNode && ancestorNode.typename !== "Document") {
                if (ancestorNode.typename === "Layer") {
                    if (ancestorNode.visible === false) return false;
                } else if (ancestorNode.hidden) {
                    return false;
                }
                ancestorNode = ancestorNode.parent;
            }
        } catch (err) {
            return false;
        }
        return true;
    }

    /**
     * アートボード上に占有オブジェクトがあるか判定する
     * @param {Document} doc - 対象ドキュメント
     * @param {number[]} artboardRect - アートボードの矩形 [left, top, right, bottom]
     * @param {boolean} ignoreHidden - 非表示のレイヤー・オブジェクトを無視するか
     * @returns {boolean} 占有オブジェクトがあれば true
     */
    function hasOccupantOnArtboard(doc, artboardRect, ignoreHidden) {
        var pageItems = doc.pageItems;
        for (var i = 0; i < pageItems.length; i++) {
            var pageItem = pageItems[i];
            var visible = isItemVisible(pageItem);
            if (ignoreHidden && !visible) continue;
            try {
                var bounds = visible ? pageItem.visibleBounds : pageItem.geometricBounds;
                if (rectsOverlap(artboardRect, bounds)) return true;
            } catch (err) {
                /* 境界を取得できないアイテムは無視 / Skip items without bounds */
            }
        }
        return false;
    }

    /**
     * 空アートボードのインデックス一覧を返す
     * @param {Document} doc - 対象ドキュメント
     * @param {boolean} ignoreHidden - 非表示のレイヤー・オブジェクトを無視するか
     * @returns {number[]} 空アートボードのインデックス
     */
    function findEmptyArtboardIndices(doc, ignoreHidden) {
        var indices = [];
        for (var i = 0; i < doc.artboards.length; i++) {
            if (!hasOccupantOnArtboard(doc, doc.artboards[i].artboardRect, ignoreHidden)) {
                indices.push(i);
            }
        }
        return indices;
    }

    // =========================================
    // 削除処理 / Removal
    // =========================================

    /**
     * 指定インデックスのアートボードを削除する（最後の1枚は残す）
     * @param {Document} doc - 対象ドキュメント
     * @param {number[]} indices - 削除するアートボードのインデックス
     * @returns {number} 削除した枚数
     */
    function removeArtboardsByIndices(doc, indices) {
        var artboards = doc.artboards;
        var removedCount = 0;
        /* 末尾から削除してインデックスのずれを避ける / Remove from the end so the indices stay valid */
        for (var i = indices.length - 1; i >= 0; i--) {
            if (artboards.length <= 1) break;
            try {
                artboards[indices[i]].remove();
                removedCount++;
            } catch (err) { }
        }
        return removedCount;
    }

    /**
     * アクティブなアートボードと重ならないオブジェクトガイドを削除する（ルーラーガイドは対象外）
     * @param {Document} doc - 対象ドキュメント
     * @returns {void}
     */
    function removeGuidesOutsideArtboard(doc) {
        try {
            var artboardRect = doc.artboards[doc.artboards.getActiveArtboardIndex()].artboardRect;

            var guidesToRemove = [];
            for (var i = doc.pageItems.length - 1; i >= 0; i--) {
                var pageItem = doc.pageItems[i];
                if (pageItem.guides !== true) continue;
                if (!itemIntersectsArtboard(pageItem, artboardRect)) guidesToRemove.push(pageItem);
            }
            for (var j = 0; j < guidesToRemove.length; j++) guidesToRemove[j].remove();
        } catch (e) {
            /* 取得できないアイテムがあっても可能な範囲で続ける / Best effort */
        }
    }

    /**
     * アクティブなアートボードの外側にあるオブジェクトを削除する
     * @param {Document} doc - 対象ドキュメント
     * @returns {void}
     */
    function deleteObjectsOutsideActiveArtboard(doc) {
        /* ロック・非表示・テンプレートのままでは選択できないため一時解除 / Relax locks and visibility first */
        var savedStructureStates = captureAndUnlockStructure(doc);

        removeGuidesOutsideArtboard(doc);

        /* アートボード上を選択→反転→削除 / Select on the artboard, invert, then delete */
        app.executeMenuCommand('selectallinartboard');
        app.executeMenuCommand('Inverse menu item');
        app.executeMenuCommand('clear');

        restoreStructure(savedStructureStates);
    }

    /**
     * アクティブなアートボードだけを残す
     * @param {Document} doc - 対象ドキュメント
     * @param {boolean} deleteOutsideObjects - 外側のオブジェクトも削除するか
     * @returns {void}
     */
    function keepActiveArtboardOnly(doc, deleteOutsideObjects) {
        if (doc.artboards.length > 1) {
            var activeArtboardIndex = doc.artboards.getActiveArtboardIndex();
            /* 末尾から削除してインデックスのずれを避ける / Remove from the end so the indices stay valid */
            for (var i = doc.artboards.length - 1; i >= 0; i--) {
                if (i !== activeArtboardIndex) doc.artboards.remove(i);
            }
        }

        if (deleteOutsideObjects) deleteObjectsOutsideActiveArtboard(doc);
    }

    // =========================================
    // ダイアログ / Dialog
    // =========================================

    // ダイアログの位置と不透明度（再利用パーツ） / Dialog position and opacity (reusable)

    var DIALOG_OPACITY = 0.98;       /* ダイアログの不透明度 / dialog opacity */
    var DIALOG_AVOID_MARGIN = 60;    /* 選択範囲の推定位置の両側に取る余裕（px）/ margin on each side of the estimated selection (px) */
    var DIALOG_AVOID_MAX_ITEMS = 100; /* 選択範囲を測るオブジェクトの上限 / max items measured for the selection bounds */

    /**
     * ダイアログの不透明度を設定し、前回閉じた位置で開いて、動かした位置を記録するようにする。
     * 開く位置が選択中のオブジェクトに重なりそうなときは、左右の反対側へずらす（Illustrator のみ）。
     * 既存の onShow / onMove / onClose は先に呼んでから、位置の復元・記録を行う。
     * @param {Window} dialog - 対象のダイアログ
     * @param {string} storageKey - 位置を覚えるキー（ふつうは SCRIPT_NAME）
     * @returns {void}
     */
    function prepareDialogWindow(dialog, storageKey) {
        /* 同じダイアログを開き直すときは、選択範囲を測り直すだけにする（ハンドラーを重ねない）
           When the same dialog is shown again, only re-measure the selection (don't stack handlers) */
        if (dialog.dialogWindowState) {
            dialog.dialogWindowState.selectionSpan = getSelectionViewSpan();
            dialog.dialogWindowState.avoidedLocation = null;
            return;
        }
        var locationKey = "__" + storageKey + "_DialogLocation";
        var previousOnShow = dialog.onShow;
        var previousOnMove = dialog.onMove;
        var previousOnClose = dialog.onClose;
        var windowState = {
            selectionSpan: getSelectionViewSpan(), /* 選択範囲は show() の前に測る / measured before show() */
            screenWidth: null,                     /* 最初に開いたときに推定する / estimated on the first show */
            avoidedLocation: null                  /* 避けるためにずらした位置（記録しない）/ location set to avoid the selection (not remembered) */
        };
        dialog.dialogWindowState = windowState;

        dialog.opacity = DIALOG_OPACITY;

        /* 今の位置を記録する / Remember the current location */
        function rememberDialogLocation() {
            var currentLocation = [dialog.location[0], dialog.location[1]];
            var avoidedLocation = windowState.avoidedLocation;
            if (avoidedLocation && currentLocation[0] === avoidedLocation[0] && currentLocation[1] === avoidedLocation[1]) return;
            $.global[locationKey] = currentLocation;
        }

        dialog.onShow = function () {
            /* 最初に開くときの既定の位置は画面の横中央なので、画面の幅を逆算できる。2回目からは前回の位置なので使い回す
               On the first show the default location is centered horizontally, which gives the screen width; reuse it afterwards */
            if (windowState.screenWidth === null) windowState.screenWidth = dialog.location[0] * 2 + dialog.bounds.width;
            if (previousOnShow) previousOnShow.apply(this, arguments);
            /* $.screens は実際の画面の大きさと合わない（Mac で 1280×524 など）ので、画面内かは判定しない
               $.screens does not match the real display (e.g. 1280x524 on a Mac), so no on-screen check */
            var savedLocation = $.global[locationKey];
            if (savedLocation) dialog.location = [savedLocation[0], savedLocation[1]];
            if (windowState.selectionSpan) {
                var avoidLeft = findDialogLeftAvoidingSelection(dialog.location[0], dialog.bounds.width, windowState.screenWidth, windowState.selectionSpan);
                if (avoidLeft !== null) {
                    dialog.location = [avoidLeft, dialog.location[1]];
                    /* 代入後の値で比べる（丸められることがある）/ Compare with the value after assignment, which may be rounded */
                    windowState.avoidedLocation = [dialog.location[0], dialog.location[1]];
                }
            }
        };
        dialog.onMove = function () {
            if (previousOnMove) previousOnMove.apply(this, arguments);
            rememberDialogLocation();
        };
        dialog.onClose = function () {
            rememberDialogLocation();
            /* false を返すと閉じるのを取りやめるので、戻り値は元の onClose のものを返す
               Returning false cancels the close, so pass the original onClose result through */
            if (previousOnClose) return previousOnClose.apply(this, arguments);
        };
    }

    /**
     * 選択中のオブジェクトが、ドキュメントの表示域の左端から画面上で何 px の範囲にあるかを返す。
     * @returns {{left: number, right: number, viewWidth: number}|null} 選択が無い・測れないときは null
     */
    function getSelectionViewSpan() {
        try {
            if (app.name !== "Adobe Illustrator" || !app.documents.length) return null;
            var targetDoc = app.activeDocument;
            var selectedItems = targetDoc.selection;
            /* 文字ツールで文字を選択しているときは TextRange が返り、[0] が無い / Selecting characters with the Type tool returns a TextRange, which has no [0] */
            if (!selectedItems || selectedItems.typename === "TextRange" || !selectedItems.length || !selectedItems[0].visibleBounds) return null;
            var itemCount = Math.min(selectedItems.length, DIALOG_AVOID_MAX_ITEMS);
            var spanLeft = Infinity;
            var spanRight = -Infinity;
            for (var i = 0; i < itemCount; i++) {
                var itemBounds = selectedItems[i].visibleBounds;
                if (itemBounds[0] < spanLeft) spanLeft = itemBounds[0];
                if (itemBounds[2] > spanRight) spanRight = itemBounds[2];
            }
            var activeView = targetDoc.activeView; /* 複数ウィンドウで開いていても今のウィンドウ / the current window even with multiple windows */
            var viewBounds = activeView.bounds;
            var zoom = activeView.zoom;
            var viewWidth = (viewBounds[2] - viewBounds[0]) * zoom;
            /* 表示域の外にはみ出した部分は数えない / Ignore the part outside the view */
            var left = Math.max(0, (spanLeft - viewBounds[0]) * zoom);
            var right = Math.min(viewWidth, (spanRight - viewBounds[0]) * zoom);
            if (right <= left) return null;
            return { left: left, right: right, viewWidth: viewWidth };
        } catch (e) {
            /* テキスト編集中など測れないときは避けない / Do not avoid when it cannot be measured, e.g. while editing text */
            return null;
        }
    }

    /**
     * ダイアログが選択範囲に重なるなら、重ならない左端の位置を返す。
     * 表示域は画面の横中央にあるとみなし、ずれは DIALOG_AVOID_MARGIN で吸収する。
     * @param {number} dialogLeft - 今のダイアログの左端
     * @param {number} dialogWidth - ダイアログの幅
     * @param {number} screenWidth - 画面の幅
     * @param {{left: number, right: number, viewWidth: number}} selectionSpan - getSelectionViewSpan() の結果
     * @returns {number|null} ずらした左端。重ならない・どちらにも収まらないときは null
     */
    function findDialogLeftAvoidingSelection(dialogLeft, dialogWidth, screenWidth, selectionSpan) {
        var viewLeft = (screenWidth - selectionSpan.viewWidth) / 2;
        var avoidLeft = viewLeft + selectionSpan.left - DIALOG_AVOID_MARGIN;
        var avoidRight = viewLeft + selectionSpan.right + DIALOG_AVOID_MARGIN;
        if (dialogLeft + dialogWidth <= avoidLeft || dialogLeft >= avoidRight) return null;

        var leftSideLeft = avoidLeft - dialogWidth;   /* 選択範囲の左に置くとき / placed left of the selection */
        var rightSideLeft = avoidRight;               /* 選択範囲の右に置くとき / placed right of the selection */
        var fitsLeft = leftSideLeft >= 0;
        var fitsRight = rightSideLeft + dialogWidth <= screenWidth;
        /* 選択範囲が画面の右寄りなら左へ、左寄りなら右へ逃がす / Move away from the side the selection leans to */
        var preferLeft = (avoidLeft + avoidRight) / 2 > screenWidth / 2;
        if (preferLeft && fitsLeft) return leftSideLeft;
        if (fitsRight) return rightSideLeft;
        if (fitsLeft) return leftSideLeft;
        return null;
    }

    // ダイアログの位置と不透明度（再利用パーツ）ここまで / End of the reusable dialog position and opacity

    // ボタン行（再利用パーツ） / Button row (reusable)

    var BUTTON_ROW_TOP_MARGIN = 5; /* ボタン行の上の余白 / top margin of the button row */
    var BUTTON_ROW_BOTTOM_MARGIN = 14; /* ボタン行の下の余白。ダイアログの下余白と合わせて約30px（Illustrator 標準のダイアログに合わせる） / bottom margin; with the dialog margin about 30px, like Illustrator's own dialogs */
    var BUTTON_ROW_SPACING = 10;   /* ボタンどうしの間隔 / spacing between buttons */
    var BUTTON_ROW_CENTER_MAX_WIDTH = 240; /* 右のボタンだけの行を中央に置く、ダイアログの内側の最大幅（px、左右の余白を除く）。広いダイアログは右揃え / max inner dialog width (px, margins excluded) that centers a right-only row; wider dialogs keep it right-aligned */

    /**
     * ダイアログ下部のボタン行を作る。
     * 通常は「左のグループ・伸びるスペーサー・右のグループ」、centered なら行そのものを左右中央に置く
     * @param {Window|Group|Panel} parent - 行を足す先（ふつうはダイアログ）
     * @param {Object} [rowOptions] - { centered: true } で左右中央に並べる
     * @returns {{rowGroup: Group, leftGroup: Group|null, rightGroup: Group|null}} 行と左右のグループ（centered のときは左右が null）
     */
    function addButtonRow(parent, rowOptions) {
        var isCentered = !!(rowOptions && rowOptions.centered);
        var btnRowGroup = parent.add("group");
        btnRowGroup.orientation = "row";
        btnRowGroup.margins = [0, BUTTON_ROW_TOP_MARGIN, 0, BUTTON_ROW_BOTTOM_MARGIN];
        btnRowGroup.spacing = BUTTON_ROW_SPACING;

        if (isCentered) {
            btnRowGroup.alignment = ["center", "bottom"];
            btnRowGroup.alignChildren = ["center", "center"];
            return { rowGroup: btnRowGroup, leftGroup: null, rightGroup: null };
        }

        btnRowGroup.alignment = ["fill", "bottom"];

        var btnLeftGroup = btnRowGroup.add("group");
        btnLeftGroup.alignChildren = ["left", "center"];
        btnLeftGroup.spacing = BUTTON_ROW_SPACING;

        /* 余りの幅を吸って、右のグループを右端に寄せる / Absorbs the extra width so the right group sits at the right edge */
        var spacer = btnRowGroup.add("group");
        spacer.alignment = ["fill", "fill"];
        spacer.minimumSize.width = 0;

        var btnRightGroup = btnRowGroup.add("group");
        btnRightGroup.alignChildren = ["right", "center"];
        btnRightGroup.spacing = BUTTON_ROW_SPACING;

        return { rowGroup: btnRowGroup, leftGroup: btnLeftGroup, rightGroup: btnRightGroup };
    }

    /**
     * 左のグループにボタンが無い（右のボタンだけの）行を、ダイアログの幅に合わせて揃える。
     * 内側の幅（左右の余白を除く）が BUTTON_ROW_CENTER_MAX_WIDTH 以下なら左右中央、それより広ければ右揃えのまま。
     * 幅はレイアウトが決まるまで分からないので、ダイアログを表示した時点（show イベント）で判定する。
     * ボタンをすべて足したあと、show() の前に呼ぶ。centered で作った行や、左にボタンがある行はそのまま
     * @param {{rowGroup: Group, leftGroup: Group|null, rightGroup: Group|null}} buttonRow - addButtonRow() の戻り値
     * @returns {void}
     */
    function alignRightOnlyButtonRow(buttonRow) {
        if (!buttonRow.leftGroup || buttonRow.leftGroup.children.length > 0) return;
        var dialogWindow = buttonRow.rowGroup.window;
        dialogWindow.addEventListener("show", function () {
            if (!buttonRow.leftGroup) return;
            var btnRowGroup = buttonRow.rowGroup;
            /* 行の幅＝ダイアログの内側の幅（左右の余白を除く）/ The row spans the dialog's inner width (margins excluded) */
            if (!btnRowGroup.size || btnRowGroup.size.width > BUTTON_ROW_CENTER_MAX_WIDTH) return;
            /* 左のグループとスペーサーを外し、右のグループだけを中央に置く / Drop the left group and the spacer so only the right group remains, centered */
            btnRowGroup.remove(buttonRow.leftGroup);
            btnRowGroup.remove(btnRowGroup.children[0]); /* 左のグループを外すと先頭はスペーサー / the spacer is first once the left group is gone */
            btnRowGroup.alignment = ["center", "bottom"];
            btnRowGroup.alignChildren = ["center", "center"];
            buttonRow.leftGroup = null;
            dialogWindow.layout.layout(true);
        });
    }

    // ボタン行（再利用パーツ）ここまで / End of the reusable button row

    /**
     * インデントしたオプション用のグループを作る
     * @param {Panel} parentPanel - 追加先のパネル
     * @returns {Group} オプションを並べるグループ
     */
    function addOptionGroup(parentPanel) {
        var optionGroup = parentPanel.add('group');
        optionGroup.orientation = 'column';
        optionGroup.alignChildren = 'left';
        optionGroup.margins = OPTION_INDENT_MARGINS;
        optionGroup.spacing = 6;
        return optionGroup;
    }

    /**
     * オプションダイアログを表示する
     * @param {object} artboardStats - { total: number, emptyIgnoreHidden: number, emptyAll: number }
     * @returns {object|null} 選択内容。キャンセル時は null
     */
    function showOptionsDialog(artboardStats) {
        var removeDialog = new Window('dialog', getLabel('dialog.title') + ' ' + SCRIPT_VERSION);
        setupWindow(removeDialog);

        var modePanel = removeDialog.add('panel', undefined, getLabel('panel.mode'));
        setupPanel(modePanel, 6);

        /* ラジオは同じ親の中だけ排他になるため、2つともパネル直下に置く
           Radios are only exclusive within one parent, so both sit directly in the panel */
        var keepActiveRadio = modePanel.add('radiobutton', undefined, getLabel('radio.keepActive'));
        keepActiveRadio.helpTip = getLabel('tooltip.keepActive');
        keepActiveRadio.value = true;

        var keepActiveOptionGroup = addOptionGroup(modePanel);
        var deleteOutsideCheckbox = keepActiveOptionGroup.add('checkbox', undefined, getLabel('checkbox.deleteOutsideObjects'));
        deleteOutsideCheckbox.helpTip = getLabel('tooltip.deleteOutsideObjects');
        deleteOutsideCheckbox.value = DEFAULT_DELETE_OUTSIDE_OBJECTS;

        var emptyRadio = modePanel.add('radiobutton', undefined, getLabel('radio.empty'));
        emptyRadio.helpTip = getLabel('tooltip.empty');

        var emptyOptionGroup = addOptionGroup(modePanel);
        var emptyCountText = emptyOptionGroup.add('statictext', undefined, '');
        emptyCountText.preferredSize.width = COUNT_TEXT_WIDTH;
        var ignoreHiddenCheckbox = emptyOptionGroup.add('checkbox', undefined, getLabel('checkbox.ignoreHidden'));
        ignoreHiddenCheckbox.helpTip = getLabel('tooltip.ignoreHidden');
        ignoreHiddenCheckbox.value = DEFAULT_IGNORE_HIDDEN;

        /* アートボードが1枚のときは「空のアートボード」を選べない / Only one artboard leaves nothing to remove */
        var canRemoveEmpty = (artboardStats.total > 1);
        if (!canRemoveEmpty) {
            emptyRadio.enabled = false;
            emptyRadio.helpTip = getLabel('tooltip.singleArtboard');
        }

        /* ボタン行（右寄せの キャンセル／OK）/ Button row (Cancel / OK on the right) */
        var buttonRow = addButtonRow(removeDialog);
        var btnCancel = buttonRow.rightGroup.add('button', undefined, getLabel('button.cancel'), { name: 'cancel' });
        var btnOK = buttonRow.rightGroup.add('button', undefined, getLabel('button.ok'), { name: 'ok' });
        btnCancel.preferredSize.width = BUTTON_WIDTH;
        btnOK.preferredSize.width = BUTTON_WIDTH;

        /**
         * モードに応じてオプションの活性・件数表示・OKの活性を更新する
         * @returns {void}
         */
        function syncDialogState() {
            deleteOutsideCheckbox.enabled = keepActiveRadio.value;

            var emptyModeSelected = emptyRadio.value;
            emptyCountText.enabled = emptyModeSelected;
            ignoreHiddenCheckbox.enabled = emptyModeSelected;

            var emptyCount = ignoreHiddenCheckbox.value ? artboardStats.emptyIgnoreHidden : artboardStats.emptyAll;
            /* 英語はコロンのあとに空白を入れる / add a space after the colon in English */
            emptyCountText.text = labelText('fieldLabel.removalTarget') + (uiLang === 'ja' ? '' : ' ') + emptyCount;

            /* 空アートボードが0枚のときは実行できない / Nothing to do when no artboard is empty */
            btnOK.enabled = emptyModeSelected ? (emptyCount > 0) : true;
        }

        /* クリックだけでなくキーボード操作でも更新 / Refresh on click and on keyboard change */
        keepActiveRadio.onClick = keepActiveRadio.onChanging = syncDialogState;
        emptyRadio.onClick = emptyRadio.onChanging = syncDialogState;
        ignoreHiddenCheckbox.onClick = syncDialogState;
        syncDialogState();

        alignRightOnlyButtonRow(buttonRow);
        prepareDialogWindow(removeDialog, SCRIPT_NAME);
        if (removeDialog.show() !== 1) return null;

        return {
            mode: keepActiveRadio.value ? 'keepActive' : 'empty',
            deleteOutsideObjects: deleteOutsideCheckbox.value,
            ignoreHidden: ignoreHiddenCheckbox.value
        };
    }

    // =========================================
    // メイン処理 / Main
    // =========================================

    /**
     * エントリポイント：ダイアログ→削除
     * @returns {void}
     */
    function main() {
        if (app.documents.length === 0) {
            alert(getLabel('alert.noDocument'));
            return;
        }

        var doc = app.activeDocument;

        /* 非表示の扱いを切り替えても即座に件数を出せるよう、先に両方を数えておく
           Count both ways up front so the dialog can switch instantly */
        var emptyIndicesIgnoreHidden = findEmptyArtboardIndices(doc, true);
        var emptyIndicesAll = findEmptyArtboardIndices(doc, false);

        var removalOptions = showOptionsDialog({
            total: doc.artboards.length,
            emptyIgnoreHidden: emptyIndicesIgnoreHidden.length,
            emptyAll: emptyIndicesAll.length
        });
        if (!removalOptions) return;

        if (removalOptions.mode === 'keepActive') {
            keepActiveArtboardOnly(doc, removalOptions.deleteOutsideObjects);
        } else {
            removeArtboardsByIndices(doc, removalOptions.ignoreHidden ? emptyIndicesIgnoreHidden : emptyIndicesAll);
        }
    }

    main();

})();
