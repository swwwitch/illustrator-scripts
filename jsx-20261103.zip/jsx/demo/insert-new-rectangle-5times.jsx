#target illustrator
app.preferences.setBooleanPreference("ShowExternalJSXWarning", false);

/*
SCRIPTMETA-BEGIN
Script-ID=com.swwwitch.illustrator.InsertNewRectangle5Times
Name=表示領域の中心付近に正方形を5つ作成
Author=Masahiro Takano (@swwwitch)
Target-App=Illustrator
Version=1.3.1
Release-Date=2025-04-01
Description-BEGIN
現在の表示領域の中心付近に、黒く塗ってランダムな不透明度を与えた正方形を5つ作成し、重ならないように配置してから「Convert to Shape」「Make Pixel Perfect」コマンドを適用します。

Creates five black squares with random opacity near the center of the current view, places them so that
they do not overlap, and applies the "Convert to Shape" and "Make Pixel Perfect" commands.
Description-END
SCRIPTMETA-END
*/

/*

### 概要

現在の表示領域の中心付近に、黒く塗ってランダムな不透明度を与えた正方形を5つ作成し、重ならないように配置してから「Convert to Shape」「Make Pixel Perfect」コマンドを適用します。

詳細は README を参照してください。
https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/InsertNewRectangle5Times.md

note記事も参照してください。
https://note.com/dtp_tranist/n/n509eb6aa0a19

### Overview

Creates five black squares with random opacity near the center of the current view, places them so that
they do not overlap, and applies the "Convert to Shape" and "Make Pixel Perfect" commands.

See the README for details.
https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/InsertNewRectangle5Times.md

*/

// =========================================
// 基本情報 / Basic info
// =========================================
var SCRIPT_NAME     = "InsertNewRectangle5Times";     /* スクリプト名 / script name */
var SCRIPT_VERSION  = "v1.3.1";                       /* バージョン / version */
var SCRIPT_AUTHOR   = "Masahiro Takano (@swwwitch)";  /* 作者 / author */
var SCRIPT_RELEASED = "2025-04-01";                   /* 最初のリリース日 / first release date */
var SCRIPT_UPDATED  = "2026-10-04";                   /* 更新日 / last updated */

var SCRIPT_DESCRIPTION_JA = "表示領域の中心付近に正方形を5つ作成"; /* README の見出し / README title (Japanese) */

var SCRIPT_README_JA   = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/InsertNewRectangle5Times.md"; /* README（日本語） */
var SCRIPT_README_EN   = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/InsertNewRectangle5Times.md"; /* README (English) */
var SCRIPT_ARTICLE_URL = "https://note.com/dtp_tranist/n/n509eb6aa0a19"; /* 紹介記事 / article URL */
var SCRIPT_SOURCE_URL  = "https://github.com/swwwitch/illustrator-scripts/blob/master/jsx/demo/insert-new-rectangle-5times.jsx"; /* 最新版のソース / latest source */

// Released under the MIT license
// http://opensource.org/licenses/mit-license.php

(function() {

    // =========================================
    // ユーザー設定 / User Settings
    // =========================================
    var RECT_SIZE     = 100; /* 作成する正方形の一辺 / side length of the square */
    var RECT_COUNT    = 5;   /* 作成する個数 / number of squares */
    var SCATTER_RANGE = 40;  /* 初期配置のばらつき（±px）/ initial scatter range (±px) */
    var OPACITY_MIN   = 30;  /* 不透明度の下限（%）/ minimum opacity (%) */
    var OPACITY_MAX   = 100; /* 不透明度の上限（%）/ maximum opacity (%) */

    /* 重なり回避の探索条件（100px角×5個なので少し広めに）/ Overlap avoidance search settings */
    var PLACEMENT_OPTIONS = {
        padding: 6,           /* オブジェクト間の最小間隔 / minimum gap between items */
        baseX: 160,           /* 水平方向の探索幅 / horizontal search range */
        baseY: 160,           /* 垂直方向の探索幅 / vertical search range */
        maxScaleFactor: 20,   /* 探索幅を広げる最大倍率 / maximum search range multiplier */
        attemptsPerItem: 300  /* 1個あたりの試行回数 / attempts per item */
    };

    // =========================================
    // ローカライズ / Localization
    // =========================================
    // ローカライズ（再利用パーツ） / Localization (reusable)

    /**
     * UI の言語を返す（"ja" で始まるロケールは日本語、それ以外は英語）
     * @returns {string} "ja" または "en"
     */
    function getCurrentLang() {
        return (String($.locale || "").indexOf("ja") === 0) ? "ja" : "en";
    }

    var uiLang = getCurrentLang();

    /**
     * LABELS から今の UI 言語の文言を取り出す。
     * @param {string|Object} labelRef - "dialog.title" のようなパス、または { ja, en }
     * @param {Object|Array} [placeholderValues] - { name: 値 } なら {name} を、[値, …] なら %1, %2 … を差し込む
     * @returns {string} 文言。パスが見つからなければパスの文字列、{ ja, en } が無ければ空文字
     */
    function getLabel(labelRef, placeholderValues) {
        var labelEntry = labelRef;
        if (typeof labelRef === "string") {
            var labelPathKeys = labelRef.split(".");
            labelEntry = LABELS;
            for (var i = 0; i < labelPathKeys.length && labelEntry != null; i++) {
                labelEntry = labelEntry[labelPathKeys[i]];
            }
        }
        var labelString;
        if (typeof labelEntry === "string") labelString = labelEntry;
        else if (labelEntry != null && labelEntry[uiLang] != null) labelString = labelEntry[uiLang];
        else if (labelEntry != null && labelEntry.en != null) labelString = labelEntry.en;
        else return (typeof labelRef === "string") ? labelRef : "";
        return fillLabelPlaceholders(String(labelString), placeholderValues);
    }

    /**
     * 項目名の文言の末尾にコロンを付ける（日本語は半角スペース＋半角コロン「 :」、英語は「:」。Illustrator の線パネルなどの項目名に合わせる）
     * @param {string|Object} labelRef - getLabel と同じ
     * @param {Object|Array} [placeholderValues] - getLabel と同じ
     * @returns {string} コロン付きの文言
     */
    function labelText(labelRef, placeholderValues) {
        return getLabel(labelRef, placeholderValues) + (uiLang === "ja" ? " :" : ":");
    }

    /**
     * 「項目名 : 値」の1行を返す（日本語は「件数 : 5」、英語は「Count: 5」。どちらもコロンのあとに空白を入れる）
     * @param {string|Object} labelRef - getLabel と同じ
     * @param {string|number} value - コロンのあとに続ける値
     * @returns {string} 項目名と値をつないだ文字列
     */
    function labelValueText(labelRef, value) {
        return labelText(labelRef) + " " + value;
    }

    /**
     * 文言の {name} や %1 に値を差し込む
     * @param {string} labelString - 文言
     * @param {Object|Array} [placeholderValues] - { name: 値 } または [値, …]
     * @returns {string} 差し込んだ文言
     */
    function fillLabelPlaceholders(labelString, placeholderValues) {
        if (placeholderValues == null) return labelString;
        if (placeholderValues instanceof Array) {
            /* 大きい番号から置き換え、%1 が %10 の一部を置き換えないようにする / Replace from the highest index so %1 does not eat into %10 */
            for (var i = placeholderValues.length; i >= 1; i--) {
                labelString = labelString.split("%" + i).join(String(placeholderValues[i - 1]));
            }
            return labelString;
        }
        for (var placeholderKey in placeholderValues) {
            if (!placeholderValues.hasOwnProperty(placeholderKey)) continue;
            labelString = labelString.split("{" + placeholderKey + "}").join(String(placeholderValues[placeholderKey]));
        }
        return labelString;
    }

    // ローカライズ（再利用パーツ）ここまで / End of the reusable localization

    var LABELS = {
        alert: {
            noDocument: { ja: "ドキュメントがありません。", en: "No document is open." },
            noEditableLayer: {
                ja: "ロック解除かつ表示されているレイヤーがありません。",
                en: "No unlocked and visible layers found."
            }
        }
    };

    // =========================================
    // ユーティリティ / Utilities
    // =========================================

    /**
     * ドキュメントのカラーモードに応じた黒を返す
     * @param {Document} doc - 対象ドキュメント
     * @returns {CMYKColor|RGBColor} 黒のカラーオブジェクト
     */
    function getBlackFillColor(doc) {
        if (doc.documentColorSpace === DocumentColorSpace.CMYK) {
            var blackCmyk = new CMYKColor();
            blackCmyk.cyan = 0;
            blackCmyk.magenta = 0;
            blackCmyk.yellow = 0;
            blackCmyk.black = 100;
            return blackCmyk;
        }
        var blackRgb = new RGBColor();
        blackRgb.red = 0;
        blackRgb.green = 0;
        blackRgb.blue = 0;
        return blackRgb;
    }

    /**
     * ロックされておらず表示されている最初のレイヤーを返す
     * @param {Document} doc - 対象ドキュメント
     * @returns {Layer} 編集可能なレイヤー。見つからない場合は null
     */
    function getUnlockedVisibleLayer(doc) {
        for (var i = 0; i < doc.layers.length; i++) {
            var candidateLayer = doc.layers[i];
            if (!candidateLayer.locked && candidateLayer.visible) return candidateLayer;
        }
        return null;
    }

    /**
     * 作成先レイヤーを決め、必要ならアクティブレイヤーを切り替える
     * @param {Document} doc - 対象ドキュメント
     * @returns {Layer} 作成先レイヤー。見つからない場合は null
     */
    function resolveTargetLayer(doc) {
        var targetLayer = doc.activeLayer;
        if (!targetLayer.locked && targetLayer.visible) return targetLayer;

        /* ロック／非表示なら、順にロック解除かつ表示のレイヤーを探す / Fall back to the first editable layer */
        var editableLayer = getUnlockedVisibleLayer(doc);
        if (!editableLayer) return null;

        doc.activeLayer = editableLayer;
        return editableLayer;
    }

    /**
     * 2つのバウンディングボックスが指定間隔以内で重なっているか判定する
     * @param {number[]} bounds - 判定するバウンズ [left, top, right, bottom]
     * @param {number[]} otherBounds - 比較先のバウンズ [left, top, right, bottom]
     * @param {number} padding - 重なりとみなす余白
     * @returns {boolean} 重なっていれば true
     */
    function isOverlapping(bounds, otherBounds, padding) {
        return !(bounds[2] + padding < otherBounds[0] ||
                 bounds[0] - padding > otherBounds[2] ||
                 bounds[1] + padding < otherBounds[3] ||
                 bounds[3] - padding > otherBounds[1]);
    }

    /**
     * 元の位置を起点にランダム移動を繰り返し、互いに重ならない位置へ配置する
     * @param {Array<{item: PageItem, position: number[]}>} itemPlacements - 対象と元の位置の組
     * @param {object} placementOptions - PLACEMENT_OPTIONS と同じ形の探索条件
     * @returns {boolean} 全件を配置できたら true
     */
    function placeItemsAvoidOverlap(itemPlacements, placementOptions) {
        if (!itemPlacements || itemPlacements.length === 0) return false;

        var scaleFactor = 1;

        while (scaleFactor <= placementOptions.maxScaleFactor) {
            var placedBounds = [];
            var allPlaced = true;

            for (var i = 0; i < itemPlacements.length; i++) {
                var placement = itemPlacements[i];
                var isPlaced = false;

                for (var attempt = 0; attempt < placementOptions.attemptsPerItem; attempt++) {
                    var randX = (Math.random() * 2 - 1) * placementOptions.baseX * scaleFactor;
                    var randY = (Math.random() * 2 - 1) * placementOptions.baseY * scaleFactor;
                    placement.item.position = [placement.position[0] + randX, placement.position[1] + randY];

                    var candidateBounds = placement.item.visibleBounds;
                    var hasOverlap = false;
                    for (var j = 0; j < placedBounds.length; j++) {
                        if (isOverlapping(candidateBounds, placedBounds[j], placementOptions.padding)) {
                            hasOverlap = true;
                            break;
                        }
                    }

                    if (!hasOverlap) {
                        placedBounds.push(candidateBounds);
                        isPlaced = true;
                        break;
                    }
                }

                if (!isPlaced) {
                    allPlaced = false;
                    break;
                }
            }

            if (allPlaced) return true;

            /* 収まらなければ探索幅を広げて再試行 / Widen the search range and retry */
            scaleFactor += 1;
        }

        return false;
    }

    /**
     * 中央に残っている同じサイズ・同じ位置の長方形を削除する
     * @param {Layer} targetLayer - 対象レイヤー
     * @param {number} rectTop - 判定する上端座標
     * @param {number} rectLeft - 判定する左端座標
     * @param {number} rectSize - 判定する一辺の長さ
     * @returns {void}
     */
    function removeExistingCenterRect(targetLayer, rectTop, rectLeft, rectSize) {
        for (var i = targetLayer.pathItems.length - 1; i >= 0; i--) {
            var pathItem = targetLayer.pathItems[i];
            if (Math.abs(pathItem.top - rectTop) < 1 && Math.abs(pathItem.left - rectLeft) < 1 &&
                Math.abs(pathItem.width - rectSize) < 1 && Math.abs(pathItem.height - rectSize) < 1) {
                try {
                    pathItem.remove();
                } catch (e) {
                    /* 削除できないものは飛ばす / Skip items that cannot be removed */
                }
            }
        }
    }

    // =========================================
    // メイン処理 / Main
    // =========================================

    /**
     * 表示中心付近に正方形を複数作成し、重ならないように配置してコマンドを適用する
     * @returns {void}
     */
    function main() {
        /* ドキュメント確認 / Ensure a document is open */
        if (app.documents.length === 0) {
            alert(getLabel(LABELS.alert.noDocument));
            return;
        }

        var doc = app.activeDocument;

        var targetLayer = resolveTargetLayer(doc);
        if (!targetLayer) {
            alert(getLabel(LABELS.alert.noEditableLayer));
            return;
        }

        /* 表示領域の中心座標を取得 / Get view center */
        var viewCenter = doc.activeView.centerPoint;
        var viewCenterX = viewCenter[0];
        var viewCenterY = viewCenter[1];

        /* 中央に残っている既存の長方形を削除 / Remove the existing center rectangle if any */
        removeExistingCenterRect(targetLayer, viewCenterY + RECT_SIZE / 2, viewCenterX - RECT_SIZE / 2, RECT_SIZE);

        /* いったん表示中心付近に作成し、後で重なり回避で再配置する / Create near the center, reposition later */
        var blackColor = getBlackFillColor(doc);
        var squares = [];
        var itemPlacements = [];
        for (var i = 0; i < RECT_COUNT; i++) {
            var offsetX = Math.random() * SCATTER_RANGE * 2 - SCATTER_RANGE;
            var offsetY = Math.random() * SCATTER_RANGE * 2 - SCATTER_RANGE;

            var square = targetLayer.pathItems.rectangle(
                viewCenterY + offsetY + RECT_SIZE / 2,
                viewCenterX + offsetX - RECT_SIZE / 2,
                RECT_SIZE,
                RECT_SIZE
            );
            square.fillColor = blackColor;
            square.stroked = false;
            square.opacity = Math.random() * (OPACITY_MAX - OPACITY_MIN) + OPACITY_MIN;
            squares.push(square);
            itemPlacements.push({ item: square, position: square.position }); /* position: [left, top] */
        }

        /* 重ならないように配置 / Place without overlapping */
        placeItemsAvoidOverlap(itemPlacements, PLACEMENT_OPTIONS);

        /* 作成した正方形だけを選択 / Select the created squares only */
        doc.selection = null;
        for (var k = 0; k < squares.length; k++) {
            squares[k].selected = true;
        }

        /* 選択オブジェクトにコマンドを適用 / Apply commands to the selection */
        app.executeMenuCommand("Convert to Shape");
        app.executeMenuCommand("Make Pixel Perfect");
    }

    main();

})();
