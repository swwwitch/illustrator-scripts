#targetengine "SwwwitchPalettes"
#target illustrator
app.preferences.setBooleanPreference('ShowExternalJSXWarning', false);

/*
SCRIPTMETA-BEGIN
Script-ID=com.swwwitch.illustrator.DocumentFontListSelectorPalette
Name=使用中の文字組み合わせを一覧から選択
Author=Masahiro Takano (@swwwitch)
Target-App=Illustrator
Version=1.1.10
Description-BEGIN
ドキュメント内のテキストで使われている書式の組み合わせ（フォント・サイズ・行送り・文字ツメ・トラッキング・自動カーニング・プロポーショナルメトリクス）を収集し、重複を除いた一覧をパレットに表示します。
同じフォントでも設定が異なれば、別の候補としてリストアップします。

Collects the formatting combinations used by the text in the document — font, size, leading, tsume, tracking, auto-kerning and proportional metrics — and lists them, deduplicated, in a palette.
The same font appears as separate entries when these settings differ.
Description-END
SCRIPTMETA-END
*/

/*

### 概要

ドキュメント内のテキストで使われている書式の組み合わせ（フォント・サイズ・行送り・文字ツメ・トラッキング・自動カーニング・プロポーショナルメトリクス）を収集し、重複を除いた一覧をパレットに表示します。
同じフォントでも設定が異なれば、別の候補としてリストアップします。

詳細は README を参照してください。
https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/DocumentFontListSelectorPalette.md

### Overview

Collects the formatting combinations used by the text in the document — font, size, leading, tsume, tracking, auto-kerning and proportional metrics — and lists them, deduplicated, in a palette.
The same font appears as separate entries when these settings differ.

See the README for details.
https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/DocumentFontListSelectorPalette.md

*/

// =========================================
// 基本情報 / Basic info
// =========================================
var SCRIPT_NAME     = "DocumentFontListSelectorPalette";  /* スクリプト名 / script name */
var SCRIPT_VERSION  = "v1.1.10";                      /* バージョン / version */
var SCRIPT_AUTHOR   = "Masahiro Takano (@swwwitch)";  /* 作者 / author */
var SCRIPT_RELEASED = "";                             /* 最初のリリース日 / first release date */
var SCRIPT_UPDATED  = "2026-10-10";                   /* 更新日 / last updated */

var SCRIPT_DESCRIPTION_JA = "使用中の文字組み合わせを一覧から選択"; /* README の見出し / README title (Japanese) */

var SCRIPT_README_JA  = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/DocumentFontListSelectorPalette.md"; /* README（日本語） */
var SCRIPT_README_EN  = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/DocumentFontListSelectorPalette.md"; /* README (English) */
var SCRIPT_SOURCE_URL = "https://github.com/swwwitch/illustrator-scripts/blob/master/jsx/fonts/DocumentFontListSelectorPalette.jsx"; /* 最新版のソース / latest source */

// Released under the MIT license
// http://opensource.org/licenses/mit-license.php

(function () {

    // ローカライズ / Localization
    // =========================================

    // ローカライズ（再利用パーツ） / Localization (reusable)

    /**
     * UI の言語を返す（"ja" で始まるロケールは日本語、それ以外は英語）
     * @returns {string} "ja" または "en"
     */
    function getCurrentLang() {
        return (String($.locale || "").indexOf("ja") === 0) ? "ja" : "en";
    }

    var uiLang = getCurrentLang();

    /**
     * LABELS から今の UI 言語の文言を取り出す。
     * @param {string|Object} labelRef - "dialog.title" のようなパス、または { ja, en }
     * @param {Object|Array} [placeholderValues] - { name: 値 } なら {name} を、[値, …] なら %1, %2 … を差し込む
     * @returns {string} 文言。パスが見つからなければパスの文字列、{ ja, en } が無ければ空文字
     */
    function getLabel(labelRef, placeholderValues) {
        var labelEntry = labelRef;
        if (typeof labelRef === "string") {
            var labelPathKeys = labelRef.split(".");
            labelEntry = LABELS;
            for (var i = 0; i < labelPathKeys.length && labelEntry != null; i++) {
                labelEntry = labelEntry[labelPathKeys[i]];
            }
        }
        var labelString;
        if (typeof labelEntry === "string") labelString = labelEntry;
        else if (labelEntry != null && labelEntry[uiLang] != null) labelString = labelEntry[uiLang];
        else if (labelEntry != null && labelEntry.en != null) labelString = labelEntry.en;
        else return (typeof labelRef === "string") ? labelRef : "";
        return fillLabelPlaceholders(String(labelString), placeholderValues);
    }

    /**
     * 項目名の文言の末尾にコロンを付ける（日本語は半角スペース＋半角コロン「 :」、英語は「:」。Illustrator の線パネルなどの項目名に合わせる）
     * @param {string|Object} labelRef - getLabel と同じ
     * @param {Object|Array} [placeholderValues] - getLabel と同じ
     * @returns {string} コロン付きの文言
     */
    function labelText(labelRef, placeholderValues) {
        return getLabel(labelRef, placeholderValues) + (uiLang === "ja" ? " :" : ":");
    }

    /**
     * 「項目名 : 値」の1行を返す（日本語は「件数 : 5」、英語は「Count: 5」。どちらもコロンのあとに空白を入れる）
     * @param {string|Object} labelRef - getLabel と同じ
     * @param {string|number} value - コロンのあとに続ける値
     * @returns {string} 項目名と値をつないだ文字列
     */
    function labelValueText(labelRef, value) {
        return labelText(labelRef) + " " + value;
    }

    /**
     * 文言の {name} や %1 に値を差し込む
     * @param {string} labelString - 文言
     * @param {Object|Array} [placeholderValues] - { name: 値 } または [値, …]
     * @returns {string} 差し込んだ文言
     */
    function fillLabelPlaceholders(labelString, placeholderValues) {
        if (placeholderValues == null) return labelString;
        if (placeholderValues instanceof Array) {
            /* 大きい番号から置き換え、%1 が %10 の一部を置き換えないようにする / Replace from the highest index so %1 does not eat into %10 */
            for (var i = placeholderValues.length; i >= 1; i--) {
                labelString = labelString.split("%" + i).join(String(placeholderValues[i - 1]));
            }
            return labelString;
        }
        for (var placeholderKey in placeholderValues) {
            if (!placeholderValues.hasOwnProperty(placeholderKey)) continue;
            labelString = labelString.split("{" + placeholderKey + "}").join(String(placeholderValues[placeholderKey]));
        }
        return labelString;
    }

    // ローカライズ（再利用パーツ）ここまで / End of the reusable localization

    /* ラベル定義 / Label definitions */
    var LABELS = {
        dialog: {
            title: { ja: "ドキュメントフォントリスト", en: "Document Font List" }
        },
        column: {
            count: { ja: "使用数", en: "Count" },
            font: { ja: "フォント", en: "Font" },
            size: { ja: "サイズ", en: "Size" },
            leading: { ja: "行送り", en: "Leading" },
            kern: { ja: "自動カーニング", en: "Auto Kerning" },
            tsume: { ja: "文字ツメ", en: "Tsume" },
            tracking: { ja: "トラッキング", en: "Tracking" },
            propMetrics: { ja: "プロポーショナル", en: "Prop. Metrics" }
        },
        control: {
            applyOnClick: { ja: "クリックで適用", en: "Apply on click" },
            currentArtboardOnly: { ja: "現在のアートボードに限定", en: "Current artboard only" },
            includeHidden: { ja: "非表示のテキストを含む", en: "Include hidden text" },
            includeLocked: { ja: "ロックされたテキストを含む", en: "Include locked text" }
        },
        tooltip: {
            applyOnClick:        { ja: "一覧の行をクリックした時点で、そのフォントを選択中のテキストへ適用します。", en: "Applies the font to the selected text as soon as you click a row." },
            currentArtboardOnly: { ja: "現在のアートボードに載っているテキストだけを集計します。", en: "Counts only the text on the current artboard." },
            includeHidden:       { ja: "非表示のテキストも集計に含めます。", en: "Includes hidden text in the tally." },
            includeLocked:       { ja: "ロックされたテキストも集計に含めます。", en: "Includes locked text in the tally." },
            comboList:           { ja: "ドキュメントで使われているフォントの一覧です。行を選ぶと、そのフォントのテキストが選択されます。", en: "The fonts used in the document. Selecting a row selects the text that uses it." }
        },
        button: {
            refresh: { ja: "リストを更新", en: "Refresh list" },
            selectMatching: { ja: "選択した条件のフォントを選択", en: "Select matching text" }
        },
        autoLeading: { ja: "自動", en: "Auto" },
        autoKern: {
            mono: { ja: "和文等幅", en: "Metrics - Roman Only" },
            zero: { ja: "0", en: "0" },
            metrics: { ja: "メトリクス", en: "Metrics" },
            optical: { ja: "オプティカル", en: "Optical" }
        },
        status: {
            needSelection: { ja: "適用先のテキストを選択してください。", en: "Select the text to apply to." },
            needCondition: { ja: "一覧から条件を選択してください。", en: "Select a condition from the list." },
            noMatch: { ja: "一致するテキストが見つかりませんでした。", en: "No matching text was found." }
        }
    };

    // =========================================
    // メインエンジンで実行する DOM 処理 / DOM helpers run on the main engine
    //
    // 以下の関数群は toString() で連結し、BridgeTalk 本文に同梱して
    // メインエンジン（生きた DOM を持つ）で eval される。常駐エンジン側
    // からは直接呼ばず、本文への埋め込み用途のみ。
    // These are concatenated via toString() and embedded in the BridgeTalk
    // body, then eval'd on the main engine (which has a live DOM).
    // =========================================

    /* 型名を安全に取得 / Safely resolve a type name */
    function getTypeName(targetObject) {
        if (targetObject === null || targetObject === undefined) return "";
        if (targetObject.typename) return targetObject.typename;
        try {
            return targetObject.constructor ? targetObject.constructor.name : "";
        } catch (e) {
            return "";
        }
    }

    /* 選択アイテムからテキスト範囲を集める（グループは再帰）/ Collect text ranges from an item (recurse into groups) */
    function collectRangesFromItem(selectedItem, rangesOut) {
        var itemTypeName = getTypeName(selectedItem);
        if (itemTypeName === "TextFrame") {
            rangesOut.push(selectedItem.textRange);
        } else if (itemTypeName === "TextRange") {
            rangesOut.push(selectedItem);
        } else if (itemTypeName === "GroupItem") {
            for (var i = 0; i < selectedItem.pageItems.length; i++) collectRangesFromItem(selectedItem.pageItems[i], rangesOut);
        }
    }

    /* 選択中のテキスト範囲を取得 / Get selected text ranges from the current document */
    function getSelectedTextRanges() {
        var documentRef = app.activeDocument;
        var currentSelection = documentRef.selection;
        var selectedRanges = [];
        if (!currentSelection) return selectedRanges;
        /* テキスト編集モードでは selection が TextRange になる / In text-edit mode the selection is a TextRange */
        if (getTypeName(currentSelection) === "TextRange") {
            selectedRanges.push(currentSelection);
            return selectedRanges;
        }
        if (currentSelection.length === 0) return selectedRanges;
        for (var i = 0; i < currentSelection.length; i++) {
            collectRangesFromItem(currentSelection[i], selectedRanges);
        }
        return selectedRanges;
    }

    /* AutoKernType を ID 文字列へ / Convert an AutoKernType value to an id string */
    function kernMethodToId(kernMethodValue) {
        var kernMethodText = String(kernMethodValue);
        if (kernMethodText === String(AutoKernType.AUTO)) return "metrics";
        if (kernMethodText === String(AutoKernType.OPTICAL)) return "optical";
        if (kernMethodText === String(AutoKernType.METRICSROMANONLY)) return "mono";
        if (kernMethodText === String(AutoKernType.NOAUTOKERN)) return "zero";
        return "zero";
    }

    /* 方式 ID を AutoKernType の列挙値へ変換 / Resolve a method id to an AutoKernType enum value
       和文等幅は欧文のみメトリクス（METRICSROMANONLY）/ Japanese equal width = METRICSROMANONLY */
    function resolveAutoKernType(kernMethodId) {
        if (kernMethodId === "mono") return AutoKernType.METRICSROMANONLY;
        if (kernMethodId === "metrics") return AutoKernType.AUTO;
        if (kernMethodId === "optical") return AutoKernType.OPTICAL;
        return AutoKernType.NOAUTOKERN;
    }

    /* 小数2桁までで末尾ゼロを落とす / Round to 2 decimals and trim trailing zeros */
    function formatNumber(numericValue) {
        if (numericValue === null || numericValue === undefined || isNaN(numericValue)) return "?";
        var roundedValue = Math.round(numericValue * 100) / 100;
        return String(roundedValue);
    }

    /* フォントの表示名（ファミリー＋スタイル）/ Display name of a font (family + style) */
    function getFontDisplayName(textFont) {
        if (!textFont) return "(no font)";
        var fontFamily = textFont.family || textFont.name || "";
        var fontStyle = textFont.style || "";
        return fontFamily + (fontStyle ? " " + fontStyle : "");
    }

    /* 1文字の属性から組み合わせオブジェクトを作る（読めなければ null）/ Build a combination object from one character's attributes (null if unreadable)
       属性は同じ characterAttributes 上にあり、読めるときは一括で読めるので try は1つ
       The attributes live on the same characterAttributes object, so a single try suffices */
    function readComboFromCharacter(character) {
        try {
            var charAttributes = character.characterAttributes;
            var textFont = charAttributes.textFont;
            if (!textFont) return null;
            return {
                psName: textFont.name,
                displayName: getFontDisplayName(textFont),
                size: charAttributes.size,
                leading: charAttributes.leading,
                autoLeading: charAttributes.autoLeading ? true : false,
                tsume: charAttributes.Tsume,
                tracking: charAttributes.tracking,
                kernId: kernMethodToId(charAttributes.kerningMethod),
                proportionalMetrics: charAttributes.proportionalMetrics ? true : false
            };
        } catch (e) {
            return null;
        }
    }

    /* 組み合わせの重複排除キー / Dedupe key for a combination */
    function comboKey(combo) {
        return [
            combo.psName,
            formatNumber(combo.size),
            combo.autoLeading ? "auto" : formatNumber(combo.leading),
            String(Math.round(combo.tsume)),
            String(Math.round(combo.tracking)),
            combo.kernId,
            combo.proportionalMetrics ? "p1" : "p0"
        ].join("|");
    }

    /* 現在のアートボードの矩形を取得（取れなければ null）/ Get the active artboard rect ([L,T,R,B]); null if unavailable */
    function getActiveArtboardRect(documentRef) {
        try {
            var activeIndex = documentRef.artboards.getActiveArtboardIndex();
            return documentRef.artboards[activeIndex].artboardRect;
        } catch (e) {
            return null;
        }
    }

    /* テキストフレームがアートボード矩形と重なるか / Whether a text frame overlaps the artboard rect
       Illustrator の y 軸は上が大きい（top > bottom）。矩形が無ければ常に true */
    function frameOverlapsArtboard(textFrame, artboardRect) {
        if (!artboardRect) return true;
        var bounds;
        try { bounds = textFrame.geometricBounds; } catch (e) { return false; }
        var frameLeft = bounds[0], frameTop = bounds[1], frameRight = bounds[2], frameBottom = bounds[3];
        var artLeft = artboardRect[0], artTop = artboardRect[1], artRight = artboardRect[2], artBottom = artboardRect[3];
        if (frameRight < artLeft || frameLeft > artRight) return false;
        if (frameBottom > artTop || frameTop < artBottom) return false;
        return true;
    }

    /* アイテムが表示されているか（自身と親グループの hidden、所属レイヤーの visible を遡って確認）/ Whether an item is visible
       自身・親グループの hidden、所属レイヤーの visible を親方向にたどって判定 / Walks up parents checking item.hidden and layer.visible */
    function isItemVisible(pageItem) {
        var node = pageItem;
        try {
            while (node) {
                var nodeType = node.typename;
                if (nodeType === "Document") break;
                if (nodeType === "Layer") {
                    if (!node.visible) return false;
                } else {
                    if (node.hidden) return false;
                }
                node = node.parent;
            }
        } catch (e) { }
        return true;
    }

    /* アイテムがロックされていないか（自身と親グループの locked、所属レイヤーの locked を遡って確認）/ Whether an item is unlocked
       自身・親グループの locked、所属レイヤーの locked を親方向にたどって判定 / Walks up parents checking item.locked and layer.locked */
    function isItemUnlocked(pageItem) {
        var node = pageItem;
        try {
            while (node) {
                var nodeType = node.typename;
                if (nodeType === "Document") break;
                if (node.locked) return false;
                node = node.parent;
            }
        } catch (e) { }
        return true;
    }

    /* ドキュメントを走査し、組み合わせを TAB 区切り行（LF 連結）で返す / Scan the document; return combos as TAB-joined rows (LF-joined)
       currentArtboardOnly が true なら現在のアートボードと重なるフレームだけ対象 / If currentArtboardOnly, only frames overlapping the active artboard
       includeHidden が false なら非表示のテキストフレームは除外 / If includeHidden is false, skip hidden text frames
       includeLocked が false ならロックされたテキストフレームは除外 / If includeLocked is false, skip locked text frames
       使用数 = その組み合わせを含むテキストフレームの数（1フレーム内で複数回使っても1）/ count = number of text frames that use the combo (a frame counts once)
       1行 = psName \t displayName \t size \t leading \t autoLeading(0/1) \t tsume \t tracking \t kernId \t proportionalMetrics(0/1) \t count */
    function collectDocumentCombosRaw(documentRef, currentArtboardOnly, includeHidden, includeLocked) {
        var comboOrder = [], comboData = {}, comboRows = [];
        var TAB = String.fromCharCode(9), LF = String.fromCharCode(10);
        var artboardRect = currentArtboardOnly ? getActiveArtboardRect(documentRef) : null;
        var textFrames = documentRef.textFrames;
        for (var f = 0; f < textFrames.length; f++) {
            if (!includeHidden && !isItemVisible(textFrames[f])) continue;
            if (!includeLocked && !isItemUnlocked(textFrames[f])) continue;
            if (artboardRect && !frameOverlapsArtboard(textFrames[f], artboardRect)) continue;
            var characters;
            try { characters = textFrames[f].characters; } catch (eFrame) { continue; }
            var seenInFrame = {};
            for (var c = 0; c < characters.length; c++) {
                var combo = readComboFromCharacter(characters[c]);
                if (!combo) continue;
                var dedupeKey = comboKey(combo);
                if (!comboData[dedupeKey]) {
                    comboData[dedupeKey] = { combo: combo, count: 0 };
                    comboOrder.push(dedupeKey);
                }
                // 同じフレーム内で同じ組み合わせを複数回使っても使用数は1だけ増やす / Count each frame once per combo
                if (!seenInFrame[dedupeKey]) {
                    seenInFrame[dedupeKey] = true;
                    comboData[dedupeKey].count++;
                }
            }
        }
        for (var i = 0; i < comboOrder.length; i++) {
            var entry = comboData[comboOrder[i]];
            var entryCombo = entry.combo;
            comboRows.push([
                entryCombo.psName, entryCombo.displayName, String(entryCombo.size), String(entryCombo.leading),
                entryCombo.autoLeading ? "1" : "0", String(entryCombo.tsume), String(entryCombo.tracking), entryCombo.kernId,
                entryCombo.proportionalMetrics ? "1" : "0", String(entry.count)
            ].join(TAB));
        }
        return comboRows.join(LF);
    }

    /* 選択範囲に組み合わせを適用 / Apply a combination to the given ranges
       戻り値: 適用できた範囲数 / Returns the number of ranges applied */
    function applyComboToRanges(selectedRanges, combo) {
        var textFont = null;
        try { textFont = app.textFonts.getByName(combo.psName); } catch (eGet) { textFont = null; }
        var kernType = resolveAutoKernType(combo.kernId);
        var appliedCount = 0;
        for (var i = 0; i < selectedRanges.length; i++) {
            // 属性は同じ characterAttributes に連続代入するので try は1範囲につき1つ
            // All attributes go on the same characterAttributes, so one try per range
            try {
                var charAttributes = selectedRanges[i].characterAttributes;
                if (textFont) charAttributes.textFont = textFont;
                if (!isNaN(combo.size)) charAttributes.size = combo.size;
                if (combo.autoLeading) {
                    charAttributes.autoLeading = true;
                } else if (!isNaN(combo.leading)) {
                    charAttributes.autoLeading = false;
                    charAttributes.leading = combo.leading;
                }
                charAttributes.Tsume = combo.tsume;
                if (!isNaN(combo.tracking)) charAttributes.tracking = combo.tracking;
                charAttributes.kerningMethod = kernType;
                charAttributes.proportionalMetrics = combo.proportionalMetrics ? true : false;
                appliedCount++;
            } catch (eApplyRange) { }
        }
        return appliedCount;
    }

    /* 組み合わせに一致する文字を含むテキストフレームを選択 / Select text frames containing characters that match the combo
       戻り値: 選択したフレーム数 / Returns the number of selected frames */
    function selectFramesMatchingCombo(documentRef, combo, currentArtboardOnly, includeHidden, includeLocked) {
        var targetKey = comboKey(combo);
        var artboardRect = currentArtboardOnly ? getActiveArtboardRect(documentRef) : null;
        var textFrames = documentRef.textFrames;
        var matchedFrames = [];
        for (var f = 0; f < textFrames.length; f++) {
            if (!includeHidden && !isItemVisible(textFrames[f])) continue;
            if (!includeLocked && !isItemUnlocked(textFrames[f])) continue;
            if (artboardRect && !frameOverlapsArtboard(textFrames[f], artboardRect)) continue;
            var characters;
            try { characters = textFrames[f].characters; } catch (eFrame) { continue; }
            for (var c = 0; c < characters.length; c++) {
                var charCombo = readComboFromCharacter(characters[c]);
                if (charCombo && comboKey(charCombo) === targetKey) { matchedFrames.push(textFrames[f]); break; }
            }
        }
        // 一致0件のときは現在の選択を保持（消してから「なし」と出さない）/ Keep the current selection when nothing matched
        if (matchedFrames.length === 0) return 0;
        // 配列を直接代入すれば既存選択を一括置換できる / Assigning the array replaces the current selection wholesale
        documentRef.selection = matchedFrames;
        return matchedFrames.length;
    }

    // =========================================
    // メインエンジン委譲 / Main-engine delegation (BridgeTalk)
    // =========================================

    /* メインエンジンへ送る処理関数 / Functions shipped to the main engine */
    var WORKER_FUNCTIONS = [
        getTypeName, collectRangesFromItem, getSelectedTextRanges,
        kernMethodToId, resolveAutoKernType, formatNumber,
        getFontDisplayName, readComboFromCharacter, comboKey,
        getActiveArtboardRect, frameOverlapsArtboard, isItemVisible, isItemUnlocked,
        collectDocumentCombosRaw, applyComboToRanges, selectFramesMatchingCombo
    ];

    /* 関数配列を toString() で連結してソース文字列にする / Join the function array into a source string */
    function buildWorkerSource() {
        var workerSource = "";
        for (var i = 0; i < WORKER_FUNCTIONS.length; i++) workerSource += WORKER_FUNCTIONS[i].toString() + "\n";
        return workerSource;
    }
    var workerSourceCache = null;
    function getWorkerSource() {
        if (workerSourceCache === null) workerSourceCache = buildWorkerSource();
        return workerSourceCache;
    }

    /* メインエンジンで実行されるディスパッチャ / Dispatcher executed on the main engine
       getCombos: 組み合わせ一覧 / applyCombo: 選択へ適用 / selectMatching: 条件一致フレームを選択
       結果は "OK:<payload>" または "ERR:<msg>" の文字列で返す */
    function dispatch(actionId, params) {
        if (app.documents.length === 0) return "ERR:nodoc";
        try { app.activeDocument; } catch (e) { return "ERR:nodoc"; }

        if (actionId === "getCombos") {
            return "OK:" + encodeURIComponent(collectDocumentCombosRaw(app.activeDocument, params && params.currentArtboardOnly, params && params.includeHidden, params && params.includeLocked));
        }
        if (actionId === "applyCombo") {
            var selectedRanges = getSelectedTextRanges();
            if (selectedRanges.length === 0) return "OK:nosel";
            var appliedCount = 0;
            try {
                appliedCount = applyComboToRanges(selectedRanges, params);
            } catch (errApply) {
                return "ERR:" + (errApply && errApply.message ? errApply.message : String(errApply));
            }
            app.redraw();
            return "OK:" + appliedCount;
        }
        if (actionId === "selectMatching") {
            var matchedCount = selectFramesMatchingCombo(app.activeDocument, params, params && params.currentArtboardOnly, params && params.includeHidden, params && params.includeLocked);
            app.redraw();
            return "OK:" + matchedCount;
        }
        return "OK:0";
    }
    var DISPATCH_SOURCE = "(" + dispatch.toString() + ")";

    /* パラメータを安全な JS リテラル文字列へ / Serialize params to a safe JS literal
       params はフラグだけ（getCombos）か comboToParams（全フィールド＋フラグ）か null / flag-only, full combo+flag, or null
       currentArtboardOnly / includeHidden は常に出力する / the flags are always emitted */
    function paramsToSource(params) {
        if (!params) return "{}";
        function numberLiteral(value) { return isNaN(value) ? "NaN" : value; }
        function stringLiteral(value) { return 'decodeURIComponent("' + encodeURIComponent(value) + '")'; }
        function boolLiteral(value) { return value ? "true" : "false"; }
        var fields = [];
        if (params.psName !== undefined) {
            fields.push("psName:" + stringLiteral(params.psName));
            fields.push("kernId:" + stringLiteral(params.kernId));
            fields.push("size:" + numberLiteral(params.size));
            fields.push("leading:" + numberLiteral(params.leading));
            fields.push("tsume:" + (isNaN(params.tsume) ? 0 : params.tsume));
            fields.push("tracking:" + numberLiteral(params.tracking));
            fields.push("autoLeading:" + boolLiteral(params.autoLeading));
            fields.push("proportionalMetrics:" + boolLiteral(params.proportionalMetrics));
        }
        fields.push("currentArtboardOnly:" + boolLiteral(params.currentArtboardOnly));
        fields.push("includeHidden:" + boolLiteral(params.includeHidden));
        fields.push("includeLocked:" + boolLiteral(params.includeLocked));
        return "{" + fields.join(",") + "}";
    }

    /*
     * 本文をメインエンジンへ送り、結果マーカーを解析して onDone(status, payload) を呼ぶ。
     * BridgeTalk は本文送信時にバックスラッシュをエスケープするため、コード全体を
     * encodeURIComponent で包んで送り、ターゲットで decodeURIComponent + eval して復元する。
     * Send the body to the main engine and parse the result marker.
     */
    function sendWorker(workerCode, onDone) {
        var bridge = new BridgeTalk();
        bridge.target = BridgeTalk.appSpecifier;
        bridge.body = "eval(decodeURIComponent(\"" + encodeURIComponent(workerCode) + "\"));";
        bridge.onResult = function (response) {
            var responseBody = response.body || "";
            var colonIndex = responseBody.indexOf(":");
            var statusMarker = colonIndex >= 0 ? responseBody.substring(0, colonIndex) : responseBody;
            var markerPayload = colonIndex >= 0 ? responseBody.substring(colonIndex + 1) : "";
            if (statusMarker === "OK") onDone("ok", markerPayload);
            else onDone("error", markerPayload);
        };
        bridge.onError = function (response) { onDone("error", response && response.body ? response.body : "BridgeTalk error"); };
        bridge.send();
    }

    /* メインエンジンへアクションを委譲（非同期）/ Delegate an action to the main engine (async) */
    function runWorker(actionId, params, onDone) {
        var workerCode = getWorkerSource() + "\nvar __result=" + DISPATCH_SOURCE + "(\"" + actionId + "\"," + paramsToSource(params) + ");__result;";
        sendWorker(workerCode, onDone);
    }

    // =========================================
    // ラベル・解析（パレット側）/ Labels & parsing (palette side)
    // =========================================

    /* カーニング method id を表示ラベルへ / Kerning method id to a display label */
    function kernLabel(kernMethodId) {
        var labelEntry = LABELS.autoKern[kernMethodId];
        return labelEntry ? getLabel(labelEntry) : "—";
    }

    /* 各列のセル文字列を組み立て / Build the per-column cell strings
       [使用数, フォント, サイズ, 行送り, 自動カーニング, 文字ツメ, トラッキング, プロポーショナル] */
    function comboCells(combo) {
        var countText = isNaN(combo.count) ? "?" : String(combo.count);
        var sizeText = formatNumber(combo.size) + "pt";
        var leadingText = combo.autoLeading
            ? getLabel(LABELS.autoLeading)
            : formatNumber(combo.leading) + "pt";
        var tsumeText = String(Math.round(combo.tsume));
        var trackingText = isNaN(combo.tracking) ? "?" : String(Math.round(combo.tracking));
        var propMetricsText = combo.proportionalMetrics ? "ON" : "OFF";
        return [countText, combo.displayName, sizeText, leadingText, kernLabel(combo.kernId), tsumeText, trackingText, propMetricsText];
    }

    /* 委譲結果（デコード済み）を組み合わせ配列に復元し、表示順に並べる / Parse the worker payload into combos and sort them */
    function parseCombosPayload(rawPayload) {
        var combos = [];
        if (!rawPayload) return combos;
        var TAB = String.fromCharCode(9), LF = String.fromCharCode(10);
        var comboRows = rawPayload.split(LF);
        for (var i = 0; i < comboRows.length; i++) {
            var fields = comboRows[i].split(TAB);
            if (fields.length < 10) continue;
            var combo = {
                psName: fields[0],
                displayName: fields[1],
                size: parseFloat(fields[2]),
                leading: parseFloat(fields[3]),
                autoLeading: fields[4] === "1",
                tsume: parseFloat(fields[5]),
                tracking: parseFloat(fields[6]),
                kernId: fields[7],
                proportionalMetrics: fields[8] === "1",
                count: parseInt(fields[9], 10)
            };
            combo.cells = comboCells(combo);
            combos.push(combo);
        }
        // フォント名→サイズ→行送り→自動カーニング→ツメ→トラッキング→プロポーショナル の順で並べる / Sort by font, size, leading, kerning, Tsume, tracking, prop-metrics
        combos.sort(function (a, b) {
            if (a.displayName !== b.displayName) return a.displayName < b.displayName ? -1 : 1;
            if ((a.size || 0) !== (b.size || 0)) return (a.size || 0) - (b.size || 0);
            if ((a.leading || 0) !== (b.leading || 0)) return (a.leading || 0) - (b.leading || 0);
            if (a.kernId !== b.kernId) return a.kernId < b.kernId ? -1 : 1;
            if ((a.tsume || 0) !== (b.tsume || 0)) return (a.tsume || 0) - (b.tsume || 0);
            if ((a.tracking || 0) !== (b.tracking || 0)) return (a.tracking || 0) - (b.tracking || 0);
            if (a.proportionalMetrics !== b.proportionalMetrics) return a.proportionalMetrics ? 1 : -1;
            return 0;
        });
        return combos;
    }

    /* 組み合わせを適用パラメータへ / Convert a combo to apply params */
    function comboToParams(combo) {
        return {
            psName: combo.psName,
            size: combo.size,
            leading: combo.leading,
            autoLeading: combo.autoLeading,
            tsume: combo.tsume,
            tracking: combo.tracking,
            kernId: combo.kernId,
            proportionalMetrics: combo.proportionalMetrics
        };
    }

    // =========================================
    // UI構築 / Build UI
    // =========================================

    // UIレイアウト（再利用パーツ） / UI layout (reusable)

    /* ウィンドウ・パネルの余白と間隔 / Window & panel margins and spacing */
    var WINDOW_MARGINS = 16;                 /* ウィンドウ外周の余白 / window margin */
    var WINDOW_SPACING = 12;                 /* ウィンドウ内の要素間隔 / window spacing */
    var PANEL_MARGINS  = [16, 20, 16, 12];   /* パネル余白 [左,上,右,下] / panel margins */
    var PANEL_SPACING  = 12;                 /* パネル内の要素間隔 / panel spacing */
    var COLUMN_SPACING = 12;                 /* 2カラムの間隔 / gap between columns */
    var TAB_MARGINS    = [15, 20, 5, 10];    /* タブ余白 [左,上,右,下] / tab margins */

    /**
     * ウィンドウの共通設定
     * @param {Window} targetWindow - 対象のウィンドウ
     * @param {number} [spacing] - 要素間隔（省略時は WINDOW_SPACING）
     * @returns {void}
     */
    function setupWindow(targetWindow, spacing) {
        targetWindow.orientation = "column";
        targetWindow.alignChildren = "fill";
        targetWindow.margins = WINDOW_MARGINS;
        targetWindow.spacing = (typeof spacing === "number") ? spacing : WINDOW_SPACING;
    }

    /**
     * パネルの共通設定（子は幅いっぱい。ボタンは alignment = "left" で広げない）
     * @param {Panel} targetPanel - 対象のパネル
     * @param {number} [spacing] - 要素間隔（省略時は PANEL_SPACING）
     * @returns {void}
     */
    function setupPanel(targetPanel, spacing) {
        targetPanel.orientation = "column";
        targetPanel.alignChildren = ["fill", "top"];
        targetPanel.alignment = "fill";
        targetPanel.margins = PANEL_MARGINS;
        targetPanel.spacing = (typeof spacing === "number") ? spacing : PANEL_SPACING;
    }

    /**
     * タブの共通設定
     * @param {Tab} targetTab - 対象のタブ
     * @param {number} [spacing] - 要素間隔（省略時は変えない）
     * @returns {void}
     */
    function setupTab(targetTab, spacing) {
        targetTab.orientation = "column";
        targetTab.alignChildren = "fill";
        targetTab.margins = TAB_MARGINS;
        if (typeof spacing === "number") targetTab.spacing = spacing;
    }

    /**
     * 横並びの行グループの共通設定（ボタン列など）。
     * alignment と alignChildren を対で指定し、中のボタンが横に伸びたり天地がずれたりしないようにする
     * @param {Group} rowGroup - 対象のグループ
     * @param {string|string[]} [rowAlignment] - 横方向の alignment（省略時は "left"）。配列ならそのまま使う
     * @param {number} [spacing] - 要素間隔（省略時は PANEL_SPACING）
     * @returns {void}
     */
    function setupRow(rowGroup, rowAlignment, spacing) {
        rowGroup.orientation = "row";
        rowGroup.alignment = (rowAlignment instanceof Array) ? rowAlignment : [rowAlignment || "left", "center"];
        rowGroup.alignChildren = ["left", "center"];
        rowGroup.spacing = (typeof spacing === "number") ? spacing : PANEL_SPACING;
    }

    /**
     * ボタンの高さを指定した px だけ詰める（レイアウトが決まったあとに呼ぶ）
     * @param {Button} targetButton - 対象のボタン
     * @param {number} trimPixels - 詰める量（px）
     * @returns {void}
     */
    function trimButtonHeight(targetButton, trimPixels) {
        /* レイアウト前は size が無い / size is not set until the layout runs */
        if (!targetButton.size) return;
        targetButton.size = [targetButton.size.width, targetButton.size.height - trimPixels];
    }

    // UIレイアウト（再利用パーツ）ここまで / End of the reusable UI layout

    /* パレットを組み立てて参照を返す（イベント未接続）/ Build the palette and return references (events not wired yet) */
    function createPaletteUI() {
        var palette = new Window("palette", getLabel(LABELS.dialog.title) + " " + SCRIPT_VERSION);
        setupWindow(palette);

        var columnTitles = [
            getLabel(LABELS.column.count),
            getLabel(LABELS.column.font),
            getLabel(LABELS.column.size),
            getLabel(LABELS.column.leading),
            getLabel(LABELS.column.kern),
            getLabel(LABELS.column.tsume),
            getLabel(LABELS.column.tracking),
            getLabel(LABELS.column.propMetrics)
        ];
        var columnWidths = [50, 160, 60, 70, 90, 70, 70, 70];

        // 最上部：走査オプションのチェックボックスを横並び・左右中央に配置 / Topmost: scan-option checkboxes in one row, centered horizontally
        //   ロックされたテキストを含む（OFF ならロックされたフレームを除外）/ Include locked text (off = skip locked frames)
        //   非表示のテキストを含む（OFF なら非表示フレームを除外）/ Include hidden text (off = skip hidden frames)
        //   現在のアートボードに限定 / Limit the scan to the active artboard
        var topRow = palette.add("group");
        topRow.orientation = "row";
        topRow.alignment = ["center", "top"];
        topRow.spacing = 16;
        // 下マージンを +5（チェックボックス行とリストの間隔を少し広げる）/ +5 bottom margin (a bit more gap below the checkboxes)
        topRow.margins = [0, 0, 0, 5];

        var includeLockedCheckbox = topRow.add("checkbox", undefined, getLabel(LABELS.control.includeLocked));
        includeLockedCheckbox.helpTip = getLabel(LABELS.tooltip.includeLocked);
        includeLockedCheckbox.value = true;

        var includeHiddenCheckbox = topRow.add("checkbox", undefined, getLabel(LABELS.control.includeHidden));
        includeHiddenCheckbox.helpTip = getLabel(LABELS.tooltip.includeHidden);
        includeHiddenCheckbox.value = true;

        var currentArtboardCheckbox = topRow.add("checkbox", undefined, getLabel(LABELS.control.currentArtboardOnly));
        currentArtboardCheckbox.helpTip = getLabel(LABELS.tooltip.currentArtboardOnly);
        currentArtboardCheckbox.value = false;

        var comboListBox = palette.add("listbox", undefined, [], {
            multiselect: false,
            numberOfColumns: columnTitles.length,
            showHeaders: true,
            columnTitles: columnTitles,
            columnWidths: columnWidths
        });
        comboListBox.helpTip = getLabel(LABELS.tooltip.comboList);
        comboListBox.preferredSize = [640, 300];

        // ボタンエリア：左＝クリックで適用 / 中央＝スペーサー / 右＝条件一致テキストを選択
        // Button area: left = apply-on-click / center = spacer / right = select matching text
        var buttonRow = palette.add("group");
        buttonRow.orientation = "row";
        buttonRow.alignment = ["fill", "center"];
        // 上マージンを +10（リストとボタンの間隔を少し広げる）/ +10 top margin (a bit more gap above the buttons)
        buttonRow.margins = [0, 10, 0, 0];

        // 左：クリックで適用するか（OFF のあいだはクリックしても適用しない）/ Left: whether a click applies (no apply while OFF)
        var applyOnClickCheckbox = buttonRow.add("checkbox", undefined, getLabel(LABELS.control.applyOnClick));
        applyOnClickCheckbox.helpTip = getLabel(LABELS.tooltip.applyOnClick);
        applyOnClickCheckbox.alignment = ["left", "center"];
        applyOnClickCheckbox.value = true;

        // 中央：スペーサー（伸びて左右を端へ押し出す。空グループが幅0に潰れないよう最小幅を持たせる）
        // Center: spacer that stretches to push the sides apart (minimum width so an empty group won't collapse to 0)
        var spacer = buttonRow.add("group");
        spacer.alignment = ["fill", "center"];
        spacer.minimumSize = [10, 1];

        // 右：一覧を再走査 / Right: rescan the list
        var refreshButton = buttonRow.add("button", undefined, getLabel(LABELS.button.refresh));
        refreshButton.alignment = ["right", "center"];

        // 右：選択中の条件に一致するテキストを選択 / Right: select text matching the selected condition
        var selectMatchingButton = buttonRow.add("button", undefined, getLabel(LABELS.button.selectMatching));
        selectMatchingButton.alignment = ["right", "center"];

        return {
            palette: palette,
            comboListBox: comboListBox,
            includeLockedCheckbox: includeLockedCheckbox,
            includeHiddenCheckbox: includeHiddenCheckbox,
            currentArtboardCheckbox: currentArtboardCheckbox,
            applyOnClickCheckbox: applyOnClickCheckbox,
            refreshButton: refreshButton,
            selectMatchingButton: selectMatchingButton
        };
    }

    /* パレットにイベントを接続 / Wire palette events */
    function bindPaletteEvents(paletteUI) {
        // BridgeTalk は非同期なので、連打による委譲の重複を抑止 / Guard against overlapping async delegations
        var applyInProgress = false;
        var currentCombos = [];

        /* 組み合わせ一覧を読み直して listbox に反映 / Reload the combos into the listbox */
        function refreshCombos() {
            runWorker("getCombos", { currentArtboardOnly: paletteUI.currentArtboardCheckbox.value, includeHidden: paletteUI.includeHiddenCheckbox.value, includeLocked: paletteUI.includeLockedCheckbox.value }, function (status, payload) {
                paletteUI.comboListBox.removeAll();
                currentCombos = (status === "ok") ? parseCombosPayload(decodeURIComponent(payload)) : [];
                for (var i = 0; i < currentCombos.length; i++) {
                    var cells = currentCombos[i].cells;
                    var listItem = paletteUI.comboListBox.add("item", cells[0]);
                    for (var col = 1; col < cells.length; col++) listItem.subItems[col - 1].text = cells[col];
                    listItem.comboIndex = i;
                }
            });
        }

        // ---- シングルクリックで選択テキストへ適用 / A single click applies to the selection ----
        // 適用先は委譲時にメインエンジンが現在の選択を読む。選択が無ければワーカーが
        // "OK:nosel" を返すので、その場合だけ警告する。
        // The main engine reads the live selection at apply time; if nothing is
        // selected it returns "OK:nosel", and only then do we warn.
        paletteUI.comboListBox.onChange = function () {
            if (!paletteUI.comboListBox.selection) return;
            // 「クリックで適用」が OFF なら何もしない / Do nothing while "Apply on click" is OFF
            if (!paletteUI.applyOnClickCheckbox.value) return;
            if (applyInProgress) return;
            var combo = currentCombos[paletteUI.comboListBox.selection.comboIndex];
            if (!combo) return;
            applyInProgress = true;
            runWorker("applyCombo", comboToParams(combo), function (status, payload) {
                applyInProgress = false;
                // 選択が無いときだけ警告（適用0件＝ロック範囲などとは区別）/ Warn only when nothing was selected (distinct from 0 applied)
                if (status === "ok" && payload === "nosel") {
                    alert(getLabel(LABELS.status.needSelection));
                }
            });
        };

        // ---- 選択中の条件に一致するテキストを選択 / Select text matching the selected condition ----
        paletteUI.selectMatchingButton.onClick = function () {
            if (!paletteUI.comboListBox.selection) {
                alert(getLabel(LABELS.status.needCondition));
                return;
            }
            var combo = currentCombos[paletteUI.comboListBox.selection.comboIndex];
            if (!combo) return;
            // 一致選択後は選択が変わるので、クリック適用を自動 OFF にする / Selection changes after matching, so turn apply-on-click OFF
            paletteUI.applyOnClickCheckbox.value = false;
            var matchingParams = comboToParams(combo);
            matchingParams.currentArtboardOnly = paletteUI.currentArtboardCheckbox.value;
            matchingParams.includeHidden = paletteUI.includeHiddenCheckbox.value;
            matchingParams.includeLocked = paletteUI.includeLockedCheckbox.value;
            runWorker("selectMatching", matchingParams, function (status, payload) {
                if (status === "ok" && payload === "0") {
                    alert(getLabel(LABELS.status.noMatch));
                }
            });
        };

        // 「リストを更新」で一覧を再走査 / Rescan the list on demand
        paletteUI.refreshButton.onClick = function () { refreshCombos(); };

        // 「現在のアートボードに限定」を切り替えたら一覧を再走査 / Rescan when the artboard-only toggle changes
        paletteUI.currentArtboardCheckbox.onClick = function () { refreshCombos(); };

        // 「非表示のテキストを含む」を切り替えたら一覧を再走査 / Rescan when the include-hidden toggle changes
        paletteUI.includeHiddenCheckbox.onClick = function () { refreshCombos(); };

        // 「ロックされたテキストを含む」を切り替えたら一覧を再走査 / Rescan when the include-locked toggle changes
        paletteUI.includeLockedCheckbox.onClick = function () { refreshCombos(); };

        // 表示のたびに一覧を再走査 / Rescan the combos whenever the palette is shown
        paletteUI.palette.onShow = function () { refreshCombos(); };

        // Esc でパレットを閉じる / Close the palette on Esc
        paletteUI.palette.addEventListener("keydown", function (keyEvent) {
            if (keyEvent.keyName === "Escape") paletteUI.palette.close();
        });
    }

    // =========================================
    // メイン処理 / Main
    // =========================================
    /* 常駐エンジンにパレット参照を保持するキー（CloseAllPalettes.jsx から閉じるため）
       Key holding the palette reference in the persistent engine (so CloseAllPalettes.jsx can close it) */
    var PALETTE_GLOBAL_KEY = "__documentFontListSelectorPalette";

    function main() {
        var paletteUI = createPaletteUI();
        bindPaletteEvents(paletteUI);
        /* 閉じたら常駐エンジンの参照をクリア / Clear the persistent-engine reference on close */
        paletteUI.palette.onClose = function () { $.global[PALETTE_GLOBAL_KEY] = null; };
        paletteUI.palette.show();
        $.global[PALETTE_GLOBAL_KEY] = paletteUI.palette;
    }

    main();

})();
