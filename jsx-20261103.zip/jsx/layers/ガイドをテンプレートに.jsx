#target illustrator
app.preferences.setBooleanPreference('ShowExternalJSXWarning', false);

/*
SCRIPTMETA-BEGIN
Script-ID=com.swwwitch.illustrator.GuidesToTemplate
Name=「Guides Preview for Trim View」レイヤーをテンプレート化
Author=Masahiro Takano (@swwwitch)
Target-App=Illustrator
Version=1.0.1
Description-BEGIN
「Guides Preview for Trim View」レイヤーを作成し、そのレイヤーをテンプレート化します。

Creates the "Guides Preview for Trim View" layer and turns it into a template layer.
Description-END
SCRIPTMETA-END
*/

/*

### 概要

「Guides Preview for Trim View」レイヤーを作成し、そのレイヤーをテンプレート化します。

詳細は README を参照してください。
https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/ガイドをテンプレートに.md

### Overview

Creates the "Guides Preview for Trim View" layer and turns it into a template layer.

See the README for details.
https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/ガイドをテンプレートに.md

*/

// =========================================
// 基本情報 / Basic info
// =========================================
var SCRIPT_NAME     = "ガイドをテンプレートに";                  /* スクリプト名 / script name */
var SCRIPT_VERSION  = "v1.0.1";                       /* バージョン / version */
var SCRIPT_AUTHOR   = "Masahiro Takano (@swwwitch)";  /* 作者 / author */
var SCRIPT_RELEASED = "";                             /* 最初のリリース日 / first release date */
var SCRIPT_UPDATED  = "2026-10-04";                   /* 更新日 / last updated */

var SCRIPT_DESCRIPTION_JA = "「Guides Preview for Trim View」レイヤーをテンプレート化"; /* README の見出し / README title (Japanese) */

var SCRIPT_README_JA  = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/ガイドをテンプレートに.md"; /* README（日本語） */
var SCRIPT_README_EN  = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/ガイドをテンプレートに.md"; /* README (English) */
var SCRIPT_SOURCE_URL = "https://github.com/swwwitch/illustrator-scripts/blob/master/jsx/layers/ガイドをテンプレートに.jsx"; /* 最新版のソース / latest source */

// Released under the MIT license
// http://opensource.org/licenses/mit-license.php

(function() {

    // =========================================================
    // 設定 / Settings
    // =========================================================

    var NEW_LAYER_NAME = "Guides Preview for Trim View"; /* 作成するレイヤー名 / Name of the layer to create */

    // =========================================================
    // ローカライズ / Localization
    // =========================================================

    // ローカライズ（再利用パーツ） / Localization (reusable)

    /**
     * UI の言語を返す（"ja" で始まるロケールは日本語、それ以外は英語）
     * @returns {string} "ja" または "en"
     */
    function getCurrentLang() {
        return (String($.locale || "").indexOf("ja") === 0) ? "ja" : "en";
    }

    var uiLang = getCurrentLang();

    /**
     * LABELS から今の UI 言語の文言を取り出す。
     * @param {string|Object} labelRef - "dialog.title" のようなパス、または { ja, en }
     * @param {Object|Array} [placeholderValues] - { name: 値 } なら {name} を、[値, …] なら %1, %2 … を差し込む
     * @returns {string} 文言。パスが見つからなければパスの文字列、{ ja, en } が無ければ空文字
     */
    function getLabel(labelRef, placeholderValues) {
        var labelEntry = labelRef;
        if (typeof labelRef === "string") {
            var labelPathKeys = labelRef.split(".");
            labelEntry = LABELS;
            for (var i = 0; i < labelPathKeys.length && labelEntry != null; i++) {
                labelEntry = labelEntry[labelPathKeys[i]];
            }
        }
        var labelString;
        if (typeof labelEntry === "string") labelString = labelEntry;
        else if (labelEntry != null && labelEntry[uiLang] != null) labelString = labelEntry[uiLang];
        else if (labelEntry != null && labelEntry.en != null) labelString = labelEntry.en;
        else return (typeof labelRef === "string") ? labelRef : "";
        return fillLabelPlaceholders(String(labelString), placeholderValues);
    }

    /**
     * 項目名の文言の末尾にコロンを付ける（日本語は半角スペース＋半角コロン「 :」、英語は「:」。Illustrator の線パネルなどの項目名に合わせる）
     * @param {string|Object} labelRef - getLabel と同じ
     * @param {Object|Array} [placeholderValues] - getLabel と同じ
     * @returns {string} コロン付きの文言
     */
    function labelText(labelRef, placeholderValues) {
        return getLabel(labelRef, placeholderValues) + (uiLang === "ja" ? " :" : ":");
    }

    /**
     * 「項目名 : 値」の1行を返す（日本語は「件数 : 5」、英語は「Count: 5」。どちらもコロンのあとに空白を入れる）
     * @param {string|Object} labelRef - getLabel と同じ
     * @param {string|number} value - コロンのあとに続ける値
     * @returns {string} 項目名と値をつないだ文字列
     */
    function labelValueText(labelRef, value) {
        return labelText(labelRef) + " " + value;
    }

    /**
     * 文言の {name} や %1 に値を差し込む
     * @param {string} labelString - 文言
     * @param {Object|Array} [placeholderValues] - { name: 値 } または [値, …]
     * @returns {string} 差し込んだ文言
     */
    function fillLabelPlaceholders(labelString, placeholderValues) {
        if (placeholderValues == null) return labelString;
        if (placeholderValues instanceof Array) {
            /* 大きい番号から置き換え、%1 が %10 の一部を置き換えないようにする / Replace from the highest index so %1 does not eat into %10 */
            for (var i = placeholderValues.length; i >= 1; i--) {
                labelString = labelString.split("%" + i).join(String(placeholderValues[i - 1]));
            }
            return labelString;
        }
        for (var placeholderKey in placeholderValues) {
            if (!placeholderValues.hasOwnProperty(placeholderKey)) continue;
            labelString = labelString.split("{" + placeholderKey + "}").join(String(placeholderValues[placeholderKey]));
        }
        return labelString;
    }

    // ローカライズ（再利用パーツ）ここまで / End of the reusable localization

    var LABELS = {
        noDocument: { ja: "ドキュメントが開かれていません。", en: "No document is open." }
    };

    // =========================================================
    // 関数 / Functions
    // =========================================================

    // 名前でレイヤーを検索（見つからなければ null） / Find a layer by name (null if missing)
    function findLayerByName(doc, name) {
        for (var i = 0; i < doc.layers.length; i++) {
            if (doc.layers[i].name === name) {
                return doc.layers[i];
            }
        }
        return null;
    }

    // ドキュメント内のガイド（パス）をすべて収集 / Collect all guide paths in the document
    function collectGuidePaths(doc) {
        var guidePaths = [];
        var documentPaths = doc.pathItems;
        for (var i = 0; i < documentPaths.length; i++) {
            if (documentPaths[i].guides === true) {
                guidePaths.push(documentPaths[i]);
            }
        }
        return guidePaths;
    }

    // ドキュメントのカラースペースに応じたマゼンタを生成 / Build a magenta color for the document's color space
    function createMagentaColor(doc) {
        if (doc.documentColorSpace === DocumentColorSpace.RGB) {
            var rgb = new RGBColor();
            rgb.red = 255; rgb.green = 0; rgb.blue = 255;
            return rgb;
        }
        var cmyk = new CMYKColor();
        cmyk.cyan = 0; cmyk.magenta = 100; cmyk.yellow = 0; cmyk.black = 0;
        return cmyk;
    }

    // ガイドを解除して線をマゼンタにする / Release the guide and set its stroke to magenta
    function releaseGuideToMagenta(guidePath, magentaColor) {
        guidePath.guides = false;                 // ガイドを解除 / Release the guide
        guidePath.filled = false;                 // 塗りなし / No fill
        guidePath.stroked = true;                 // 線あり / Stroked
        guidePath.strokeColor = magentaColor;     // 線色をマゼンタに / Magenta stroke
        if (!guidePath.strokeWidth) {
            guidePath.strokeWidth = 1;            // 線幅が 0 のとき既定値を付与 / Give a default width when 0
        }
    }

    // レイヤーをテンプレート化 / Turn a layer into a template
    function applyTemplateLayer(layer) {
        layer.visible = true;               // 表示する
        layer.locked = true;                // ロックする
        layer.printable = false;            // 印刷しない
    }

    // =========================================================
    // 事前チェック / Pre-checks
    // =========================================================

    if (app.documents.length === 0) {
        alert(getLabel("noDocument"));
        return;
    }

    var activeDoc = app.activeDocument;

    // 前提条件：対象レイヤーが既にあれば削除して終了（トグル動作） / Precondition: if the layer already exists, remove it and stop (toggle)
    var existingLayer = findLayerByName(activeDoc, NEW_LAYER_NAME);
    if (existingLayer !== null) {
        existingLayer.locked = false; // ロック中だと削除できないため解除 / Unlock so it can be removed
        existingLayer.remove();
        app.executeMenuCommand('TrimView'); // トリミング表示を切り替え / Toggle Trim View
        return; // ガイドの収集以降は実行しない / Skip the guide-collection logic
    }

    // =========================================================
    // 全レイヤーのロック/表示状態を退避して一時解除 / Save and temporarily clear lock/visibility of all layers
    // =========================================================

    var savedLayerStates = [];
    for (var i = 0; i < activeDoc.layers.length; i++) {
        var layer = activeDoc.layers[i];
        savedLayerStates.push({ layer: layer, locked: layer.locked, visible: layer.visible });
        layer.locked = false;
        layer.visible = true;
    }

    function restoreLayerStates() {
        for (var i = 0; i < savedLayerStates.length; i++) {
            savedLayerStates[i].layer.locked = savedLayerStates[i].locked;
            savedLayerStates[i].layer.visible = savedLayerStates[i].visible;
        }
    }

    // =========================================================
    // ガイドの収集・複製（途中でエラーが出ても finally で必ず状態復帰） / Collect & duplicate guides (finally always restores state)
    // =========================================================

    var previewLayer = null;
    try {
        var guidePaths = collectGuidePaths(activeDoc);
        if (guidePaths.length === 0) {
            app.executeMenuCommand('TrimView'); // ガイドが無ければ表示トグルのみ / No guides: only toggle Trim View
            return;
        }

        // 新規レイヤーを作成し、ガイドを複製 / Create a new layer and duplicate guides into it
        previewLayer = activeDoc.layers.add();
        previewLayer.name = NEW_LAYER_NAME;

        var magentaColor = createMagentaColor(activeDoc);
        for (var i = 0; i < guidePaths.length; i++) {
            var duplicatedGuide = guidePaths[i].duplicate(previewLayer, ElementPlacement.PLACEATEND);
            releaseGuideToMagenta(duplicatedGuide, magentaColor); // ガイド解除＋マゼンタ化 / Release guide + magenta
        }
    } finally {
        // 元レイヤーの状態を復帰（新規レイヤーはこの後テンプレート化） / Restore original layers (the new layer is templated next)
        restoreLayerStates();
    }

    // =========================================================
    // テンプレートレイヤーの設定を適用 / Apply template layer settings
    // =========================================================

    applyTemplateLayer(previewLayer);

    app.executeMenuCommand('TrimView'); // トリミング表示を切り替え / Toggle Trim View

})();
