#target illustrator
#targetengine "LogoGridMakerEngine"
app.preferences.setBooleanPreference('ShowExternalJSXWarning', false);

/*
SCRIPTMETA-BEGIN
Script-ID=com.swwwitch.illustrator.LogoGridMaker
Name=ロゴ用の補助線とクリアスペースを生成
Author=Masahiro Takano (@swwwitch)
Target-App=Illustrator
Version=1.5.7
Release-Date=2026-04-10
Description-BEGIN
選択オブジェクトの visibleBounds を基準に、ロゴ用の補助線およびクリアスペースを生成します。
「文字形状からグリッド構造を抽出する」ことを目的としたスクリプトです。

Generates construction lines and clear space for a logo, based on the visibleBounds of the selection.
The script is aimed at extracting a grid structure from letterforms.
Description-END
SCRIPTMETA-END
*/

/*

### 概要

選択オブジェクトの visibleBounds を基準に、ロゴ用の補助線およびクリアスペースを生成します。
「文字形状からグリッド構造を抽出する」ことを目的としたスクリプトです。

詳細は README を参照してください。
https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/LogoGridMaker.md

note記事も参照してください。
https://note.com/dtp_tranist/n/n95a285784495

### Overview

Generates construction lines and clear space for a logo, based on the visibleBounds of the selection.
The script is aimed at extracting a grid structure from letterforms.

See the README for details.
https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/LogoGridMaker.md

*/

// =========================================
// 基本情報 / Basic info
// =========================================
var SCRIPT_NAME     = "LogoGridMaker";                /* スクリプト名 / script name */
var SCRIPT_VERSION  = "v1.5.7";                       /* バージョン / version */
var SCRIPT_AUTHOR   = "Masahiro Takano (@swwwitch)";  /* 作者 / author */
var SCRIPT_RELEASED = "2026-04-10";                   /* 最初のリリース日 / first release date */
var SCRIPT_UPDATED  = "2026-10-04";                   /* 更新日 / last updated */

var SCRIPT_DESCRIPTION_JA = "ロゴ用の補助線とクリアスペースを生成"; /* README の見出し / README title (Japanese) */

var SCRIPT_README_JA   = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/LogoGridMaker.md"; /* README（日本語） */
var SCRIPT_README_EN   = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/LogoGridMaker.md"; /* README (English) */
var SCRIPT_ARTICLE_URL = "https://note.com/dtp_tranist/n/n95a285784495"; /* 紹介記事 / article URL */
var SCRIPT_SOURCE_URL  = "https://github.com/swwwitch/illustrator-scripts/blob/master/jsx/misc/LogoGridMaker.jsx"; /* 最新版のソース / latest source */

// Released under the MIT license
// http://opensource.org/licenses/mit-license.php

(function () {

    // =========================================
    // ユーザー設定 / User Settings
    // =========================================

    /* 補助線の外観 / Appearance of the guide lines */
    var LINE_STYLE = {
        grayTint: 100,          /* 線のグレー濃度（K%） / gray tint of the lines */
        boundsMultiplier: 4     /* ［境界線を強調］時の線幅倍率 / stroke multiplier for emphasized bounds */
    };

    /* クリアスペースの外観 / Appearance of the clear space */
    var CLEAR_SPACE_STYLE = {
        cyan: 60,               /* 帯のシアン濃度（C%） / cyan tint of the bands */
        fillOpacity: 20,        /* 塗りの不透明度（%） / fill opacity */
        strokeWidth: 0.25       /* 枠線の線幅（pt） / stroke width of the bands */
    };

    /* ライン検出のしきい値 / Thresholds of the line detection */
    var DETECTION = {
        coordTolerance: 0.001,       /* 同じ座標とみなす許容値（pt） / tolerance for identical coordinates */
        clusterRatio: 0.03,          /* クラスタ許容値＝対象サイズ×この比率 / cluster tolerance ratio */
        clusterMin: 1.0,             /* クラスタ許容値の下限（pt） / minimum cluster tolerance */
        clusterMax: 5.0,             /* クラスタ許容値の上限（pt） / maximum cluster tolerance */
        shortSegmentRatio: 0.03,     /* 短いセグメントを捨てる比率（平均長比） / ratio used to drop short segments */
        shortSegmentFloor: 2,        /* 短いセグメント判定の下限（pt） / floor of the short segment threshold */
        horizontalFlatness: 0.2,     /* 水平とみなす上下の差（pt） / vertical gap that still counts as horizontal */
        horizontalMinRun: 0.5,       /* 水平とみなす最小の長さ（pt） / minimum run that counts as horizontal */
        fallbackLineRatio: 0.3,      /* 内部の線を推定できないときの位置比率 / ratio used when inner lines are unknown */
        descenderRatio: 0.15,        /* ディセンダーとみなす下方向の比率 / ratio that still counts as a descender */
        xHeightRatio: 0.68,          /* ミーンライン候補が並んだときに優先する高さの比率 / preferred x-height ratio when mean line candidates tie */
        diagonalAngleTolerance: 2.0, /* 同じ傾きとみなす角度差（度） / angle gap that counts as the same slope */
        diagonalMinAngle: 45,        /* 斜線として扱う角度の下限（度） / lower angle bound of diagonal elements */
        diagonalMaxAngle: 90,        /* 斜線として扱う角度の上限（度） / upper angle bound of diagonal elements */
        diagonalMergeRatio: 0.6      /* 斜線をまとめる間隔の比率 / ratio used to merge diagonal lines */
    };

    // =========================================
    // レイアウト / Layout
    // =========================================

    // UIレイアウト（再利用パーツ） / UI layout (reusable)

    /* ウィンドウ・パネルの余白と間隔 / Window & panel margins and spacing */
    var WINDOW_MARGINS = 16;                 /* ウィンドウ外周の余白 / window margin */
    var WINDOW_SPACING = 12;                 /* ウィンドウ内の要素間隔 / window spacing */
    var PANEL_MARGINS  = [16, 20, 16, 12];   /* パネル余白 [左,上,右,下] / panel margins */
    var PANEL_SPACING  = 12;                 /* パネル内の要素間隔 / panel spacing */
    var COLUMN_SPACING = 12;                 /* 2カラムの間隔 / gap between columns */
    var TAB_MARGINS    = [15, 20, 5, 10];    /* タブ余白 [左,上,右,下] / tab margins */

    /**
     * ウィンドウの共通設定
     * @param {Window} targetWindow - 対象のウィンドウ
     * @param {number} [spacing] - 要素間隔（省略時は WINDOW_SPACING）
     * @returns {void}
     */
    function setupWindow(targetWindow, spacing) {
        targetWindow.orientation = "column";
        targetWindow.alignChildren = "fill";
        targetWindow.margins = WINDOW_MARGINS;
        targetWindow.spacing = (typeof spacing === "number") ? spacing : WINDOW_SPACING;
    }

    /**
     * パネルの共通設定（子は幅いっぱい。ボタンは alignment = "left" で広げない）
     * @param {Panel} targetPanel - 対象のパネル
     * @param {number} [spacing] - 要素間隔（省略時は PANEL_SPACING）
     * @returns {void}
     */
    function setupPanel(targetPanel, spacing) {
        targetPanel.orientation = "column";
        targetPanel.alignChildren = ["fill", "top"];
        targetPanel.alignment = "fill";
        targetPanel.margins = PANEL_MARGINS;
        targetPanel.spacing = (typeof spacing === "number") ? spacing : PANEL_SPACING;
    }

    /**
     * タブの共通設定
     * @param {Tab} targetTab - 対象のタブ
     * @param {number} [spacing] - 要素間隔（省略時は変えない）
     * @returns {void}
     */
    function setupTab(targetTab, spacing) {
        targetTab.orientation = "column";
        targetTab.alignChildren = "fill";
        targetTab.margins = TAB_MARGINS;
        if (typeof spacing === "number") targetTab.spacing = spacing;
    }

    /**
     * 横並びの行グループの共通設定（ボタン列など）。
     * alignment と alignChildren を対で指定し、中のボタンが横に伸びたり天地がずれたりしないようにする
     * @param {Group} rowGroup - 対象のグループ
     * @param {string|string[]} [rowAlignment] - 横方向の alignment（省略時は "left"）。配列ならそのまま使う
     * @param {number} [spacing] - 要素間隔（省略時は PANEL_SPACING）
     * @returns {void}
     */
    function setupRow(rowGroup, rowAlignment, spacing) {
        rowGroup.orientation = "row";
        rowGroup.alignment = (rowAlignment instanceof Array) ? rowAlignment : [rowAlignment || "left", "center"];
        rowGroup.alignChildren = ["left", "center"];
        rowGroup.spacing = (typeof spacing === "number") ? spacing : PANEL_SPACING;
    }

    /**
     * ボタンの高さを指定した px だけ詰める（レイアウトが決まったあとに呼ぶ）
     * @param {Button} targetButton - 対象のボタン
     * @param {number} trimPixels - 詰める量（px）
     * @returns {void}
     */
    function trimButtonHeight(targetButton, trimPixels) {
        /* レイアウト前は size が無い / size is not set until the layout runs */
        if (!targetButton.size) return;
        targetButton.size = [targetButton.size.width, targetButton.size.height - trimPixels];
    }

    // UIレイアウト（再利用パーツ）ここまで / End of the reusable UI layout

    /* 入力欄の幅（文字数） / Width of the input fields, in characters */
    var FIELD_WIDTH = {
        count: 2,        /* 本数・分割数 / counts and divisions */
        strokeWidth: 4,  /* 線幅 / stroke width */
        scale: 6,        /* 伸張率 / scale */
        layerName: 16    /* レイヤー名 / layer name */
    };

    // UI の明暗（再利用パーツ） / UI theme (reusable)

    /**
     * UI がダークテーマかどうかを判定する（Illustrator は uiBrightness、InDesign は uiBrightnessPreference）
     * @returns {boolean} ダークなら true。取得できない環境では false（明るいUI扱い）
     */
    function isDarkUI() {
        try {
            if (app.preferences && app.preferences.getRealPreference) {
                return app.preferences.getRealPreference("uiBrightness") <= 0.5; /* Illustrator */
            }
            return app.generalPreferences.uiBrightnessPreference <= 0.5; /* InDesign */
        } catch (e) {
            return false;
        }
    }

    // UI の明暗（再利用パーツ）ここまで / End of the reusable UI theme

    // ステップボタン（再利用パーツ） / Stepper buttons (reusable)

    // -----------------------------------------
    // ステップボタンの寸法・増減量 / Stepper metrics and steps
    // -----------------------------------------
    var STEPPER_BUTTON_WIDTH   = 20;  /* ∧∨ボタンの幅 / button width */
    var STEPPER_BUTTON_HEIGHT  = 11;  /* ∧∨ボタン1つの高さ（2つ重ねた全体の高さは22） / button height (22 for the pair) */
    var STEPPER_CORNER_RADIUS  = 2;   /* 枠の角丸の半径（ScriptUIは円弧を描けないため短い線分で近似） / corner radius, approximated with segments */
    var STEPPER_FIELD_SPACING  = 3;   /* 項目名と∧∨の間隔 / spacing between the label and the stepper */
    var STEPPER_SIDE_MARGIN    = 3;   /* ∧∨の左に足す余白（右は入力欄に突き合わせる） / extra space left of the stepper */
    var STEPPER_SHIFT_MULTIPLE = 10;  /* shift＋クリックでそろえる倍数 / Shift-click snaps to multiples of this */
    var STEPPER_OPTION_STEP    = 0.1; /* option＋クリックの増減量 / Option-click step */

    /* 単位の換算は UnitValue に任せる（in / ft / yd / mm / cm / m / pt / pc / px ほか、単数形・複数形も可）。
       UnitValue に無い単位だけ、ここで UnitValue の単位に読み替える（値は「1単位＝何 unit か」）。
       「p」は「1p6」（1パイカ6ポイント）の形にも使う
       Units UnitValue lacks, mapped onto UnitValue units (how many of `unit` make one) */
    var STEPPER_UNIT_ALIASES = {
        "q": { unit: "mm", amount: 0.25 }, /* 級 / Q */
        "h": { unit: "mm", amount: 0.25 }, /* 歯 / H */
        "p": { unit: "pc", amount: 1 }     /* パイカ / pica */
    };

    // -----------------------------------------
    // ステップボタンの配色 / Stepper colors
    // -----------------------------------------
    var STEPPER_UI_DARK           = isDarkUI();
    /* UIの明るさは4段階あり、段階ごとに背景色が違う。どの段階でも背景に対する差で見せるよう、黒・白の半透明を重ねる。
       ダーク側は Illustrator 標準のスピナー（［グリッドに分割］）で実測、明るい側は最も明るい段階（背景 約0.94）から逆算
       UI brightness has four levels with different backgrounds, so colors are translucent overlays that follow the
       dialog background. Dark values are measured from Illustrator's own spinner; light values derived for the lightest level */
    var STEPPER_FILL_COLOR        = STEPPER_UI_DARK ? [0, 0, 0, 0.10]  : [1, 1, 1, 0.50];  /* 地 / background */
    var STEPPER_FRAME_COLOR       = STEPPER_UI_DARK ? [1, 1, 1, 0.07]  : [0, 0, 0, 0.10];  /* 枠線 / frame */
    var STEPPER_PRESSED_COLOR     = STEPPER_UI_DARK ? [1, 1, 1, 0.12]  : [0, 0, 0, 0.13];  /* 押下中 / pressed */
    var STEPPER_CHEVRON_COLOR     = STEPPER_UI_DARK ? [1, 1, 1, 1]     : [0, 0, 0, 0.70];  /* 山形の線 / chevron */
    var STEPPER_DIM_FILL_COLOR    = STEPPER_UI_DARK ? [1, 1, 1, 0.035] : [1, 1, 1, 0.30];  /* 無効時の地 / background when disabled */
    var STEPPER_DIM_FRAME_COLOR   = STEPPER_UI_DARK ? [1, 1, 1, 0.035] : [0, 0, 0, 0.05];  /* 無効時の枠線（ダークは地と同じで見せない） / frame when disabled */
    var STEPPER_DIM_CHEVRON_COLOR = STEPPER_UI_DARK ? [1, 1, 1, 0.20]  : [0, 0, 0, 0.25];  /* 無効時の山形 / chevron when disabled */

    // -----------------------------------------
    // 数値欄を作る（外から呼ぶ関数） / Public API
    // -----------------------------------------
    /**
     * 「項目名・∧∨・入力欄」をひと組にした数値欄を追加する。
     * ↑↓キーでも∧∨と同じように増減する。直接入力した値も、フォーカスが外れたときに
     * 整数化・下限・上限・単位（「20 mm」の形）へそろえ、数値でなければ直前の値に戻す。
     * 四則演算（+ - * / と括弧）を入れると、確定時に計算した値にする。欄と違う単位で入れた値は欄の単位へ換算する（mm の欄に「1 in」→「25.4 mm」）
     * @param {Group|Panel} parent - 追加先
     * @param {Object} fieldOptions - label（コロン込みの項目名）/ labelWidth / text / characters /
     *     step / min / max / integer（true で整数のみ）/ unit / onStep
     * @returns {EditText} 入力欄（項目名は .fieldLabel、∧∨は .stepperGroup で参照できる）
     */
    function addSteppedField(parent, fieldOptions) {
        var fieldRowGroup = parent.add("group");
        fieldRowGroup.orientation = "row";
        fieldRowGroup.alignChildren = ["left", "center"];
        fieldRowGroup.spacing = STEPPER_FIELD_SPACING;

        var fieldLabel = fieldRowGroup.add("statictext", undefined, fieldOptions.label || "");
        if (fieldOptions.labelWidth) {
            fieldLabel.preferredSize.width = fieldOptions.labelWidth;
            fieldLabel.justify = "right";
        }

        /* ∧∨と入力欄は隙間0で突き合わせる / butt the stepper against the field */
        var stepperInputGroup = fieldRowGroup.add("group");
        stepperInputGroup.orientation = "row";
        stepperInputGroup.alignChildren = ["left", "center"];
        stepperInputGroup.spacing = 0;
        stepperInputGroup.margins = 0;

        var numberInput;
        var stepperGroup = addStepper(stepperInputGroup, function () { return numberInput; }, fieldOptions);
        numberInput = stepperInputGroup.add("edittext", undefined, fieldOptions.text || "");
        numberInput.characters = fieldOptions.characters || 6;
        numberInput.fieldLabel = fieldLabel;
        numberInput.stepperGroup = stepperGroup;

        /* ↑↓キーも∧∨と同じ処理で増減する（増減量・下限・上限・単位・修飾キーをそろえる） / arrow keys share the stepper's logic */
        bindSteppedArrowKeys(numberInput, stepperGroup);

        /* 項目名のクリックで入力欄にフォーカスを移す / clicking the label focuses the field */
        fieldLabel.addEventListener("click", function () { focusNumberInput(numberInput); });

        /* 直接入力をそろえる。計算式は計算し、数値でなければ直前の値に戻す / normalize typed values; evaluate arithmetic, revert non-numbers */
        numberInput.lastValidText = numberInput.text;
        numberInput.onChange = function () {
            var value = evaluateArithmetic(numberInput.text, fieldOptions.unit);
            if (isNaN(value)) {
                numberInput.text = numberInput.lastValidText;
                return;
            }
            writeSteppedValue(numberInput, value, fieldOptions);
        };
        return numberInput;
    }

    /**
     * 数値欄の有効／無効を、項目名・∧∨ごとまとめて切り替える
     * @param {EditText} numberInput - addSteppedField() で作った入力欄
     * @param {boolean} isEnabled - 有効にするなら true
     * @returns {void}
     */
    function setSteppedFieldEnabled(numberInput, isEnabled) {
        numberInput.enabled = isEnabled;
        numberInput.fieldLabel.enabled = isEnabled;
        numberInput.stepperGroup.enabled = isEnabled;
        /* ∧∨は自作描画なので、描き直してディム表示を切り替える / redraw the custom-drawn buttons to update the dimming */
        for (var i = 0; i < numberInput.stepperGroup.children.length; i++) {
            redrawStepperGroup(numberInput.stepperGroup.children[i]);
        }
    }

    /**
     * 入力欄の値を増減する∧∨ボタンを、隙間なく縦に積んで追加する
     * @param {Group|Panel} parent - 追加先
     * @param {Function} getNumberInput - 対象の入力欄を返す関数（入力欄を∧∨より後に作れるよう、クリック時に引く）
     * @param {Object} stepOptions - step（増減量）/ min / max / integer / unit（例 " mm"）/ onStep(numberInput)
     * @returns {Group} ∧∨をまとめた group（.stepBy(direction) で同じ増減を呼べる）
     */
    function addStepper(parent, getNumberInput, stepOptions) {
        var stepperGroup = parent.add("group");
        stepperGroup.orientation = "column";
        stepperGroup.spacing = 0; /* 2つのボタンをつなげて1つの枠に見せる / join the buttons into one frame */
        stepperGroup.margins = [STEPPER_SIDE_MARGIN, 0, 0, 0]; /* 右は入力欄に突き合わせる / butt against the field on the right */
        stepperGroup.alignment = ["left", "center"];

        /**
         * 入力欄の値を増減する（shift を押しながらなら STEPPER_SHIFT_MULTIPLE の倍数へ、option なら STEPPER_OPTION_STEP ずつ。下限・上限で止める）
         * @param {number} direction - 増やすなら 1、減らすなら -1
         * @returns {void}
         */
        function stepBy(direction) {
            var numberInput = getNumberInput();
            if (!isStepperEnabledInTree(numberInput)) return; /* 入力欄か親が無効の間は動かさない */
            var value = evaluateArithmetic(numberInput.text, stepOptions.unit); /* 確定前の計算式も計算してから増減 / evaluate an uncommitted expression first */
            if (isNaN(value)) value = parseFloat(numberInput.text); /* 計算できなければ従来どおり先頭の数値 / fall back to the leading number */
            if (isNaN(value)) value = 0;
            writeSteppedValue(numberInput, computeSteppedValue(value, direction, stepOptions), stepOptions);
            if (stepOptions.onStep) stepOptions.onStep(numberInput);
        }

        /**
         * ∧∨を離したときに入力欄へフォーカスを移す（mousedown で移しても、離したときに外れる）
         * @param {Group} chevronButton - makeStepperChevronButton() で作ったボタン
         * @returns {Group} 渡したボタン
         */
        function focusInputOnRelease(chevronButton) {
            chevronButton.addEventListener("mouseup", function () {
                var numberInput = getNumberInput();
                if (isStepperEnabledInTree(numberInput)) focusNumberInput(numberInput);
            });
            return chevronButton;
        }

        /* 整数の欄では option＋クリックの0.1刻みが効かないので、説明から外す / integer fields have no 0.1 step */
        var upTooltip = stepOptions.integer ? LABELS.tooltip.stepUpInteger : LABELS.tooltip.stepUp;
        var downTooltip = stepOptions.integer ? LABELS.tooltip.stepDownInteger : LABELS.tooltip.stepDown;
        focusInputOnRelease(makeStepperChevronButton(stepperGroup, "up", function () { stepBy(1); })).helpTip = getLabel(upTooltip);
        focusInputOnRelease(makeStepperChevronButton(stepperGroup, "down", function () { stepBy(-1); })).helpTip = getLabel(downTooltip);
        stepperGroup.stepBy = stepBy; /* ↑↓キーからも同じ処理で増減できるよう公開 / shared with the arrow keys */
        stepperGroup.stepOptions = stepOptions; /* 確定時の計算で欄の単位を引けるよう公開 / lets the commit-time evaluation find the unit */
        return stepperGroup;
    }

    /**
     * 入力欄の↑↓キーを、∧∨と同じ処理で増減させる。ほかのキーは素通し。
     * あわせて、確定時に計算式・単位付きの値を計算して書き戻す（各スクリプトの onChange より先に呼ばれるので、onChange は計算後の値を読む）
     * @param {EditText} numberInput - 対象の入力欄
     * @param {Group} stepperGroup - addStepper() で作った∧∨
     * @returns {void}
     */
    function bindSteppedArrowKeys(numberInput, stepperGroup) {
        numberInput.addEventListener("keydown", function (event) {
            if (event.keyName !== "Up" && event.keyName !== "Down") return;
            stepperGroup.stepBy(event.keyName === "Up" ? 1 : -1);
            event.preventDefault(); /* カーソル移動を止める / keep the caret from moving */
        });
        numberInput.addEventListener("change", function () {
            var fieldUnit = stepperGroup.stepOptions ? stepperGroup.stepOptions.unit : undefined;
            var value = evaluateArithmetic(numberInput.text, fieldUnit);
            if (isNaN(value)) return; /* 計算できなければ各スクリプトの処理に任せる / leave it to the script's own handler */
            /* 式か、換算で値が変わったときだけ書き戻す（ただの数値は書式を崩さない） / rewrite only expressions and converted values */
            var hasOperator = /[*\/()\u00D7\u00F7\uFF0A\uFF0F\uFF08\uFF09]|[\d.\uFF10-\uFF19][^\d.\uFF10-\uFF19]*[+\-\u2212\uFF0B\uFF0D]/.test(numberInput.text);
            if (!hasOperator && value === parseFloat(numberInput.text)) return;
            numberInput.text = formatStepperNumber(value) + (fieldUnit || "");
        });
    }

    // -----------------------------------------
    // 値の計算 / Value helpers
    // -----------------------------------------
    /**
     * 押された修飾キーに応じて、1回分増減した値を返す
     * （shift なら STEPPER_SHIFT_MULTIPLE の倍数へ、option なら STEPPER_OPTION_STEP ずつ、それ以外は step の倍数へ（1.5→2、1.5→1）。
     * 整数の欄では option を無視して step の倍数へ）
     * @param {number} value - 元の値
     * @param {number} direction - 増やすなら 1、減らすなら -1
     * @param {Object} stepOptions - step（通常の増減量。省略時は 1）/ integer
     * @returns {number} 増減した値（下限・上限は未適用）
     */
    function computeSteppedValue(value, direction, stepOptions) {
        var keyState = ScriptUI.environment.keyboardState;
        if (keyState.shiftKey) return snapStepperToNextMultiple(value, STEPPER_SHIFT_MULTIPLE, direction);
        if (keyState.altKey && !stepOptions.integer) return value + direction * STEPPER_OPTION_STEP;
        return snapStepperToNextMultiple(value, stepOptions.step || 1, direction);
    }

    /**
     * 値を、指定した方向にある次の倍数へ移す（230→240、232→240、下げるときは 232→230、230→220）
     * @param {number} value - 元の値
     * @param {number} multiple - 倍数の単位（例 10）
     * @param {number} direction - 上げるなら 1、下げるなら -1
     * @returns {number} 移した値
     */
    function snapStepperToNextMultiple(value, multiple, direction) {
        /* 0.29 / 0.01 = 28.999… のような浮動小数の誤差で同じ値に戻らないよう、商を丸めてから切り捨て・切り上げる
           round the quotient first so float error (0.29 / 0.01 = 28.999…) does not step back to the same value */
        var quotient = Math.round(value / multiple * 1e6) / 1e6;
        if (direction > 0) return Math.round((Math.floor(quotient) + 1) * multiple * 1e6) / 1e6;
        return Math.round((Math.ceil(quotient) - 1) * multiple * 1e6) / 1e6;
    }

    /**
     * 値を下限・上限の範囲に収める
     * @param {number} value - 数値
     * @param {Object} rangeOptions - min / max（どちらも省略可）
     * @returns {number} 範囲に収めた値
     */
    function clampSteppedValue(value, rangeOptions) {
        if (rangeOptions.min !== undefined && value < rangeOptions.min) return rangeOptions.min;
        if (rangeOptions.max !== undefined && value > rangeOptions.max) return rangeOptions.max;
        return value;
    }

    /**
     * 入力欄の文字列を四則演算（+ - * / と括弧）として計算する。eval は使わない。
     * 数値の後ろの単位は UnitValue で欄の単位へ換算する（mm の欄に「1in」→ 25.4、「1p6」は1パイカ6ポイント）。単位のない数値は欄の単位とみなす。
     * 全角の数字・記号と × ÷ は半角に直す
     * @param {string} text - 入力欄の文字列
     * @param {string} [fieldUnit] - 欄の単位（例 " mm"。前後の空白は無視）
     * @returns {number} 欄の単位での計算結果（式として読めない・換算できない単位・0で割ったときは NaN）
     */
    function evaluateArithmetic(text, fieldUnit) {
        var source = String(text)
            .replace(/[！-～]/g, function (ch) { return String.fromCharCode(ch.charCodeAt(0) - 0xFEE0); })
            .replace(/×/g, "*")
            .replace(/÷/g, "/")
            .replace(/[−–—]/g, "-")
            .replace(/\s/g, "");
        if (source === "") return NaN;
        var fieldUnitKey = String(fieldUnit || "").replace(/^\s+|\s+$/g, "").toLowerCase();
        var fieldUnitValue = createStepperUnitValue(1, fieldUnitKey); /* 欄の単位の1単位（換算できない欄は null） / one field unit */
        var position = 0;

        /**
         * 加減算の並び（項 ± 項 …）を読む
         * @returns {number} 値（読めなければ NaN）
         */
        function readSum() {
            var total = readProduct();
            while (position < source.length && (source.charAt(position) === "+" || source.charAt(position) === "-")) {
                var operator = source.charAt(position++);
                var operand = readProduct();
                total = (operator === "+") ? total + operand : total - operand;
            }
            return total;
        }

        /**
         * 乗除算の並び（因子 × 因子 …）を読む
         * @returns {number} 値（読めなければ NaN）
         */
        function readProduct() {
            var total = readFactor();
            while (position < source.length && (source.charAt(position) === "*" || source.charAt(position) === "/")) {
                var operator = source.charAt(position++);
                var operand = readFactor();
                if (operator === "/" && operand === 0) return NaN;
                total = (operator === "*") ? total * operand : total / operand;
            }
            return total;
        }

        /**
         * 符号付きの数値（単位付きなら欄の単位へ換算）か、括弧で囲んだ式を読む
         * @returns {number} 値（読めなければ NaN）
         */
        function readFactor() {
            var ch = source.charAt(position);
            if (ch === "+" || ch === "-") {
                position++;
                var signedValue = readFactor();
                return (ch === "-") ? -signedValue : signedValue;
            }
            if (ch === "(") {
                position++;
                var innerValue = readSum();
                if (source.charAt(position) !== ")") return NaN;
                position++;
                return innerValue;
            }
            var numberMatch = /^(\d+\.?\d*|\.\d+)/.exec(source.substring(position));
            if (!numberMatch) return NaN;
            position += numberMatch[0].length;
            return readUnitSuffix(parseFloat(numberMatch[0]));
        }

        /**
         * 数値の直後の単位を読み、欄の単位へ換算する
         * @param {number} value - 単位の前の数値
         * @returns {number} 欄の単位での値（換算できない単位なら NaN）
         */
        function readUnitSuffix(value) {
            var unitMatch = /^([A-Za-z]+|%|°)/.exec(source.substring(position));
            if (!unitMatch) return value; /* 単位なしは欄の単位 / no unit means the field's unit */
            position += unitMatch[0].length;
            var unitKey = unitMatch[0].toLowerCase();
            if (unitKey === fieldUnitKey) return value;
            var typedValue = createStepperUnitValue(value, unitKey);
            if (!typedValue || !fieldUnitValue) return NaN; /* 知らない単位・単位のない欄 / unknown unit or unitless field */
            var points = typedValue.as("pt");
            /* 「1p6」＝1パイカ6ポイント / pica-point notation */
            if (unitKey === "p") {
                var pointMatch = /^(\d+\.?\d*|\.\d+)/.exec(source.substring(position));
                if (pointMatch) {
                    position += pointMatch[0].length;
                    points += parseFloat(pointMatch[0]);
                }
            }
            return points / fieldUnitValue.as("pt");
        }

        var result = readSum();
        if (position !== source.length || !isFinite(result)) return NaN; /* 読み残しがあれば式として不正 / leftovers mean a malformed expression */
        return result;
    }

    /**
     * 数値と単位から UnitValue を作る。Q・H・p は STEPPER_UNIT_ALIASES で UnitValue の単位に読み替える。
     * %（percent）は基準の長さが無いと換算できないので扱わない
     * @param {number} value - 数値
     * @param {string} unitKey - 単位（小文字。例 "mm"、"inches"、"q"）
     * @returns {UnitValue|null} UnitValue（UnitValue が知らない単位・空・% なら null）
     */
    function createStepperUnitValue(value, unitKey) {
        if (unitKey === "" || unitKey === "%") return null;
        var alias = STEPPER_UNIT_ALIASES[unitKey];
        var unitValue = alias ? new UnitValue(value * alias.amount, alias.unit) : new UnitValue(value, unitKey);
        if (unitValue.type === "?" || unitValue.type === "%") return null; /* 知らない単位は例外にならず "?" になる。"percent" も除く / unknown units become "?" */
        return unitValue;
    }

    /**
     * 値を整数化・下限・上限でそろえ、単位を付けて入力欄に書き込む（直前の正しい値としても控える）
     * @param {EditText} numberInput - 書き込む入力欄
     * @param {number} value - 数値
     * @param {Object} valueOptions - integer / min / max / unit（どれも省略可）
     * @returns {void}
     */
    function writeSteppedValue(numberInput, value, valueOptions) {
        numberInput.text = formatSteppedValue(value, valueOptions);
        numberInput.lastValidText = numberInput.text;
    }

    /**
     * 値を整数化・下限・上限でそろえ、丸めて単位を付けた表示用の文字列にする。
     * 整数化してから下限で止めるので、「整数・下限1」の欄に 0.4 が入っても 1 になる
     * @param {number} value - 数値
     * @param {Object} valueOptions - integer / min / max / unit（どれも省略可）
     * @returns {string} 入力欄に入れる文字列（例 "20 mm"）
     */
    function formatSteppedValue(value, valueOptions) {
        if (valueOptions.integer) value = Math.round(value);
        return formatStepperNumber(clampSteppedValue(value, valueOptions)) + (valueOptions.unit || "");
    }

    /**
     * 小数第2位で丸めた数値を文字列で返す
     * @param {number} value - 数値
     * @returns {string} 表示用の数値文字列
     */
    function formatStepperNumber(value) {
        return String(Math.round(value * 100) / 100);
    }

    // -----------------------------------------
    // ∧∨ボタンの描画 / Drawing
    // -----------------------------------------
    /**
     * 山形（∧／∨）の極小ボタンを作成する。
     * 上下2つを隙間なく積んで1つの枠に見えるよう、枠線は外側の辺だけ描き（上ボタンは上側、下ボタンは下側）、
     * 継ぎ目に線は引かない
     * @param {Group|Panel} parent - 追加先
     * @param {string} direction - "up" または "down"
     * @param {Function} onClickFn - クリック時の処理
     * @returns {Group} ボタンとして使う group
     */
    function makeStepperChevronButton(parent, direction, onClickFn) {
        var buttonWidth = STEPPER_BUTTON_WIDTH;
        var buttonHeight = STEPPER_BUTTON_HEIGHT;
        var isUp = (direction === "up");
        var chevronBox = parent.add("group");
        chevronBox.margins = 0;
        chevronBox.spacing = 0;
        chevronBox.preferredSize = [buttonWidth, buttonHeight];
        chevronBox.minimumSize = [buttonWidth, buttonHeight];
        chevronBox.maximumSize = [buttonWidth, buttonHeight];
        chevronBox.isPressed = false;
        chevronBox.isStepperButton = true; /* redrawSteppersIn() の目印 / marker for redrawSteppersIn() */

        chevronBox.onDraw = function () {
            var boxGraphics = chevronBox.graphics;
            /* 自作描画は自動でディムにならないため、無効なら薄い色で描く。親の無効化は子の enabled に出ないので親も見る
               Custom drawing is not dimmed automatically; the parent's state does not reach the child's enabled */
            var isDimmed = !isStepperEnabledInTree(chevronBox);

            /* 枠線の内側の地（押下中は押下色） / background inside the frame, pressed color while pressed */
            var fillColor = isDimmed ? STEPPER_DIM_FILL_COLOR : (chevronBox.isPressed ? STEPPER_PRESSED_COLOR : STEPPER_FILL_COLOR);
            boxGraphics.newPath();
            boxGraphics.rectPath(1, isUp ? 1 : 0, buttonWidth - 2, buttonHeight - 1);
            boxGraphics.fillPath(boxGraphics.newBrush(boxGraphics.BrushType.SOLID_COLOR, fillColor));

            drawStepperFrame(boxGraphics, buttonWidth, buttonHeight, isUp, isDimmed ? STEPPER_DIM_FRAME_COLOR : STEPPER_FRAME_COLOR);
            drawStepperChevron(boxGraphics, buttonWidth, buttonHeight, isUp, isDimmed ? STEPPER_DIM_CHEVRON_COLOR : STEPPER_CHEVRON_COLOR);
        };

        /**
         * 押下状態を変えて描き直す
         * @param {boolean} isPressed - 押下中なら true
         * @returns {void}
         */
        function repaint(isPressed) {
            if (chevronBox.isPressed === isPressed) return;
            chevronBox.isPressed = isPressed;
            redrawStepperGroup(chevronBox);
        }
        chevronBox.addEventListener("mousedown", function () {
            if (!isStepperEnabledInTree(chevronBox)) return;
            repaint(true);
            if (onClickFn) onClickFn();
        });
        chevronBox.addEventListener("mouseup", function () { repaint(false); });
        /* 押したまま外へ出たときも押下色を残さない / reset when the pointer leaves while pressed */
        chevronBox.addEventListener("mouseout", function () { repaint(false); });
        return chevronBox;
    }

    /**
     * 外側の辺だけの枠を描く（角は丸める）。継ぎ目側は開けておき、上下2つで1つの枠に見せる。
     * ScriptUI は円弧を描けないため、角丸は短い線分で近似する
     * @param {ScriptUIGraphics} boxGraphics - 描画先
     * @param {number} boxWidth - ボタンの幅
     * @param {number} boxHeight - ボタンの高さ
     * @param {boolean} isUp - 上のボタンなら true（上側に枠を描く）
     * @param {number[]} frameColor - [r, g, b, a]
     * @returns {void}
     */
    function drawStepperFrame(boxGraphics, boxWidth, boxHeight, isUp, frameColor) {
        var frameLeft = 0.5;
        var frameRight = boxWidth - 0.5;
        var outerY = isUp ? 0.5 : boxHeight - 0.5;
        var seamY = isUp ? boxHeight : 0;
        var towardSeam = isUp ? 1 : -1; /* 外側の辺から継ぎ目へ向かう向き / direction from the outer edge to the seam */
        var radius = STEPPER_CORNER_RADIUS;
        var arcSteps = 4; /* 角丸1つを何本の線分で近似するか / segments per corner */
        var angle, k;

        boxGraphics.newPath();
        boxGraphics.moveTo(frameLeft, seamY);
        /* 左の角丸 / left corner */
        for (k = 0; k <= arcSteps; k++) {
            angle = (Math.PI / 2) * k / arcSteps;
            boxGraphics.lineTo(frameLeft + radius - radius * Math.cos(angle), outerY + towardSeam * (radius - radius * Math.sin(angle)));
        }
        /* 右の角丸 / right corner */
        for (k = 0; k <= arcSteps; k++) {
            angle = (Math.PI / 2) * k / arcSteps;
            boxGraphics.lineTo(frameRight - radius + radius * Math.sin(angle), outerY + towardSeam * (radius - radius * Math.cos(angle)));
        }
        boxGraphics.lineTo(frameRight, seamY);
        boxGraphics.strokePath(boxGraphics.newPen(boxGraphics.PenType.SOLID_COLOR, frameColor, 1));
    }

    /**
     * 山形（∧／∨）を描く。文字グリフの▲▼は上下で大きさやベースラインが揃わないため、線で描く
     * @param {ScriptUIGraphics} boxGraphics - 描画先
     * @param {number} boxWidth - ボタンの幅
     * @param {number} boxHeight - ボタンの高さ
     * @param {boolean} isUp - ∧なら true、∨なら false
     * @param {number[]} chevronColor - [r, g, b, a]
     * @returns {void}
     */
    function drawStepperChevron(boxGraphics, boxWidth, boxHeight, isUp, chevronColor) {
        var centerX = boxWidth / 2;
        var centerY = isUp ? boxHeight / 2 + 0.5 : boxHeight / 2 - 0.5; /* 継ぎ目から少し離す / nudged away from the seam */
        var halfWidth = 3.6; /* 山形の半幅（高さ1.8に対して開き約127°） / half width of the chevron */
        var tipOffsetY = isUp ? -1.8 : 1.8; /* 頂点の中心からのずれ（上向きは上、下向きは下） */
        boxGraphics.newPath();
        boxGraphics.moveTo(centerX - halfWidth, centerY - tipOffsetY);
        boxGraphics.lineTo(centerX, centerY + tipOffsetY);
        boxGraphics.lineTo(centerX + halfWidth, centerY - tipOffsetY);
        boxGraphics.strokePath(boxGraphics.newPen(boxGraphics.PenType.SOLID_COLOR, chevronColor, 1.2));
    }

    /**
     * 入力欄にフォーカスを移す
     * @param {EditText} numberInput - 対象の入力欄
     * @returns {void}
     */
    function focusNumberInput(numberInput) {
        numberInput.active = false; /* 一度外さないとフォーカスが移らないことがある / reset first or focus may not move */
        numberInput.active = true;
    }

    /**
     * コントロールと、その親をたどってすべて有効かを返す（親の無効化は子の enabled に出ない）
     * @param {Object} control - 対象のコントロール
     * @returns {boolean} すべて有効なら true
     */
    function isStepperEnabledInTree(control) {
        for (var node = control; node; node = node.parent) {
            if (!node.enabled) return false;
        }
        return true;
    }

    /**
     * コンテナ以下にある∧∨ボタンをすべて描き直す。行やパネルの enabled を切り替えたあとに呼ぶ
     * @param {Object} container - 行・グループ・パネルなど
     * @returns {void}
     */
    function redrawSteppersIn(container) {
        if (!container.children) return;
        for (var i = 0; i < container.children.length; i++) {
            var child = container.children[i];
            if (child.isStepperButton) redrawStepperGroup(child);
            else redrawSteppersIn(child);
        }
    }

    /**
     * group の onDraw を呼び直す。group には notify() が無いため、隠して再表示して描き直させる
     * @param {Group} targetGroup - 描き直す group
     * @returns {void}
     */
    function redrawStepperGroup(targetGroup) {
        targetGroup.hide();
        targetGroup.show();
    }

    // ステップボタン（再利用パーツ）ここまで / End of the reusable stepper

    // =========================================
    // ローカライズ / Localization
    // =========================================

    // ローカライズ（再利用パーツ） / Localization (reusable)

    /**
     * UI の言語を返す（"ja" で始まるロケールは日本語、それ以外は英語）
     * @returns {string} "ja" または "en"
     */
    function getCurrentLang() {
        return (String($.locale || "").indexOf("ja") === 0) ? "ja" : "en";
    }

    var uiLang = getCurrentLang();

    /**
     * LABELS から今の UI 言語の文言を取り出す。
     * @param {string|Object} labelRef - "dialog.title" のようなパス、または { ja, en }
     * @param {Object|Array} [placeholderValues] - { name: 値 } なら {name} を、[値, …] なら %1, %2 … を差し込む
     * @returns {string} 文言。パスが見つからなければパスの文字列、{ ja, en } が無ければ空文字
     */
    function getLabel(labelRef, placeholderValues) {
        var labelEntry = labelRef;
        if (typeof labelRef === "string") {
            var labelPathKeys = labelRef.split(".");
            labelEntry = LABELS;
            for (var i = 0; i < labelPathKeys.length && labelEntry != null; i++) {
                labelEntry = labelEntry[labelPathKeys[i]];
            }
        }
        var labelString;
        if (typeof labelEntry === "string") labelString = labelEntry;
        else if (labelEntry != null && labelEntry[uiLang] != null) labelString = labelEntry[uiLang];
        else if (labelEntry != null && labelEntry.en != null) labelString = labelEntry.en;
        else return (typeof labelRef === "string") ? labelRef : "";
        return fillLabelPlaceholders(String(labelString), placeholderValues);
    }

    /**
     * 項目名の文言の末尾にコロンを付ける（日本語は半角スペース＋半角コロン「 :」、英語は「:」。Illustrator の線パネルなどの項目名に合わせる）
     * @param {string|Object} labelRef - getLabel と同じ
     * @param {Object|Array} [placeholderValues] - getLabel と同じ
     * @returns {string} コロン付きの文言
     */
    function labelText(labelRef, placeholderValues) {
        return getLabel(labelRef, placeholderValues) + (uiLang === "ja" ? " :" : ":");
    }

    /**
     * 「項目名 : 値」の1行を返す（日本語は「件数 : 5」、英語は「Count: 5」。どちらもコロンのあとに空白を入れる）
     * @param {string|Object} labelRef - getLabel と同じ
     * @param {string|number} value - コロンのあとに続ける値
     * @returns {string} 項目名と値をつないだ文字列
     */
    function labelValueText(labelRef, value) {
        return labelText(labelRef) + " " + value;
    }

    /**
     * 文言の {name} や %1 に値を差し込む
     * @param {string} labelString - 文言
     * @param {Object|Array} [placeholderValues] - { name: 値 } または [値, …]
     * @returns {string} 差し込んだ文言
     */
    function fillLabelPlaceholders(labelString, placeholderValues) {
        if (placeholderValues == null) return labelString;
        if (placeholderValues instanceof Array) {
            /* 大きい番号から置き換え、%1 が %10 の一部を置き換えないようにする / Replace from the highest index so %1 does not eat into %10 */
            for (var i = placeholderValues.length; i >= 1; i--) {
                labelString = labelString.split("%" + i).join(String(placeholderValues[i - 1]));
            }
            return labelString;
        }
        for (var placeholderKey in placeholderValues) {
            if (!placeholderValues.hasOwnProperty(placeholderKey)) continue;
            labelString = labelString.split("{" + placeholderKey + "}").join(String(placeholderValues[placeholderKey]));
        }
        return labelString;
    }

    // ローカライズ（再利用パーツ）ここまで / End of the reusable localization

    /* UI文言の定義 / UI string definitions */
    var LABELS = {
        dialog: {
            title: { ja: "ロゴグリッドの作成", en: "Logo Grid Maker" }
        },
        panel: {
            common: { ja: "共通設定とクリアスペース", en: "Common Settings & Clear Space" },
            horizontal: { ja: "横線", en: "Horizontal Lines" },
            vertical: { ja: "縦線", en: "Vertical Lines" },
            lineMethod: { ja: "ラインの決め方", en: "Line Generation Method" },
            options: { ja: "オプション", en: "Options" }
        },
        fieldLabel: {
            preset: { ja: "プリセット", en: "Preset" },
            divisions: { ja: "分割数", en: "Divisions" },
            strokeWidth: { ja: "線幅", en: "Stroke Width" },
            targetLayer: { ja: "作成レイヤー", en: "Target Layer" },
            widthScale: { ja: "横伸張率", en: "Width Scale" },
            heightScale: { ja: "縦伸張率", en: "Height Scale" }
        },
        radio: {
            lineNone: { ja: "なし", en: "None" },
            lineAuto: { ja: "自動判定", en: "Auto Detect" },
            lineSegment: { ja: "水平セグメント", en: "Horizontal Segments" },
            lineEven: { ja: "均等分割", en: "Even Divisions" }
        },
        checkbox: {
            extraHorizontal: { ja: "上下に線を追加", en: "Add Top & Bottom Lines" },
            extendLeft: { ja: "左方向に延長", en: "Extend Leftward" },
            outerVertical: { ja: "左右に線を追加", en: "Add Left & Right Lines" },
            columnDiv: { ja: "均等分割", en: "Even Divisions" },
            extendUp: { ja: "上方向に延長", en: "Extend Upward" },
            verticalElements: { ja: "垂直エレメント", en: "Vertical Elements" },
            diagonalElements: { ja: "斜線エレメント", en: "Diagonal Elements" },
            convertToGuides: { ja: "ガイドに変換する", en: "Convert to Guides" },
            emphasizeBounds: { ja: "境界線を強調", en: "Highlight Bounds" },
            clearSpace: { ja: "クリアスペース", en: "Clear Space" },
            groupItems: { ja: "グループ化", en: "Group Items" },
            preview: { ja: "プレビュー", en: "Preview" }
        },
        unit: {
            lines: { ja: "本", en: "lines" }
        },
        button: {
            exportPreset: { ja: "書き出し", en: "Export" },
            cancel: { ja: "キャンセル", en: "Cancel" },
            ok: { ja: "OK", en: "OK" }
        },
        itemName: {
            layer: { ja: "// logo_guide", en: "// logo_guide" },
            guideGroup: { ja: "補助線", en: "Guides" },
            previewGroup: { ja: "補助線_プレビュー", en: "Guides (Preview)" },
            clearSpaceGroup: { ja: "クリアスペース", en: "Clear Space" }
        },
        tooltip: {
            preset: {
                ja: "よく使う設定の組み合わせを一括で反映します。",
                en: "Applies a ready-made combination of settings."
            },
            exportPreset: {
                ja: "現在の設定を、プリセット定義に貼り付けられる形でデスクトップに書き出します。",
                en: "Writes the current settings to the desktop, ready to paste into the preset definitions."
            },
            clearSpace: {
                ja: "選択範囲の外側に、ユニット幅のクリアスペースを作成します。ONのあいだ横線・縦線は作成されません。",
                en: "Draws a clear space one unit wide around the selection. Horizontal and vertical lines are skipped while this is on."
            },
            divisions: {
                ja: "選択範囲の高さを何分割した長さをユニット（1単位）とするかを指定します。",
                en: "Sets the unit size, as the number of parts the height of the selection is divided into."
            },
            strokeWidth: {
                ja: "補助線の線幅。単位は環境設定の［線］に従います。",
                en: "Stroke width of the guide lines, in the unit set under Preferences > Stroke."
            },
            emphasizeBounds: {
                ja: "選択範囲の境界に重なる線だけ、指定した線幅の4倍で描きます。",
                en: "Draws the lines that sit on the bounds of the selection four times heavier."
            },
            convertToGuides: {
                ja: "作成した線をガイドに変換します。ONのあいだグループ化は使えません。",
                en: "Converts the generated lines into guides. Grouping is unavailable while this is on."
            },
            groupItems: {
                ja: "作成した線をひとつのグループにまとめます。OFFならレイヤー直下に置きます。",
                en: "Puts the generated lines into a single group. When off, they are placed directly on the layer."
            },
            targetLayer: {
                ja: "補助線を作成するレイヤー名。同名のレイヤーがなければ新規作成します。",
                en: "Name of the layer the lines are created on. A layer is added when no layer has this name."
            },
            widthScale: {
                ja: "横線の長さ。選択範囲の幅に対する割合で指定します。",
                en: "Length of the horizontal lines, as a percentage of the width of the selection."
            },
            extraHorizontal: {
                ja: "選択範囲の上端・下端の線と、その外側にユニット間隔で指定した本数の線を追加します。",
                en: "Adds lines on the top and bottom bounds, plus the given number of lines outside them, one unit apart."
            },
            extendLeft: {
                ja: "横線の右端を選択範囲の右外に固定し、余った長さを左方向に伸ばします。",
                en: "Pins the right end of the horizontal lines and extends the remaining length leftward."
            },
            lineMethod: {
                ja: "選択範囲の内側に引く横線の決め方。",
                en: "How the horizontal lines inside the selection are placed."
            },
            lineNone: {
                ja: "内側の横線を作成しません。",
                en: "Draws no lines inside the selection."
            },
            lineAuto: {
                ja: "アセンダー・ミーンライン・ベースライン・ディセンダーを推定して引きます。",
                en: "Estimates the ascender, mean line, baseline and descender."
            },
            lineSegment: {
                ja: "パスに含まれる水平セグメントの位置に引きます。",
                en: "Places the lines on the horizontal segments found in the paths."
            },
            lineEven: {
                ja: "上端から下端までを、指定した本数で均等に分割して引きます。",
                en: "Divides the height evenly into the given number of lines."
            },
            heightScale: {
                ja: "縦線の長さ。選択範囲の高さに対する割合で指定します。",
                en: "Length of the vertical lines, as a percentage of the height of the selection."
            },
            outerVertical: {
                ja: "選択範囲の左端・右端の線と、その外側にユニット間隔で指定した本数の線を追加します。",
                en: "Adds lines on the left and right bounds, plus the given number of lines outside them, one unit apart."
            },
            extendUp: {
                ja: "縦線の下端を選択範囲の下（2ユニット）に固定し、余った長さを上方向に伸ばします。",
                en: "Pins the bottom of the vertical lines two units below the selection and extends the rest upward."
            },
            columnDiv: {
                ja: "選択範囲の幅を、指定した数で均等分割する縦線を引きます。",
                en: "Divides the width of the selection evenly with vertical lines."
            },
            verticalElements: {
                ja: "パスに含まれる垂直セグメントの位置に縦線を引きます。",
                en: "Places vertical lines on the vertical segments found in the paths."
            },
            diagonalElements: {
                ja: "斜体などの傾きを検出し、その角度に沿った線を引きます。",
                en: "Detects the dominant slant of the letterforms and draws lines along it."
            },
            preview: {
                ja: "設定の結果をドキュメント上で確認します。",
                en: "Shows the result on the document while you adjust the settings."
            },
            stepUp: {
                ja: "値を増やす（shift＋クリックで10の倍数へ、option＋クリックで0.1ずつ）",
                en: "Increase (Shift-click to snap to 10s, Option-click by 0.1)"
            },
            stepDown: {
                ja: "値を減らす（shift＋クリックで10の倍数へ、option＋クリックで0.1ずつ）",
                en: "Decrease (Shift-click to snap to 10s, Option-click by 0.1)"
            },
            stepUpInteger: { ja: "値を増やす（shift＋クリックで10の倍数へ）", en: "Increase (Shift-click to snap to 10s)" },
            stepDownInteger: { ja: "値を減らす（shift＋クリックで10の倍数へ）", en: "Decrease (Shift-click to snap to 10s)" }
        },
        prompt: {
            presetName: { ja: "プリセット名を入力してください：", en: "Enter preset name:" }
        },
        alert: {
            noDocument: { ja: "ドキュメントが開かれていません。", en: "No document is open." },
            noSelection: { ja: "オブジェクトを選択してください。", en: "Please select an object." },
            noBounds: { ja: "選択範囲の境界を取得できませんでした。", en: "Could not get the bounds of the selection." },
            invalidSize: { ja: "選択オブジェクトのサイズを取得できませんでした。", en: "Could not get the size of the selected object." },
            invalidInput: { ja: "入力値が不正です。数値を正しく入力してください。", en: "Invalid input. Please enter valid numeric values." },
            exported: {
                ja: "書き出しました（配列に貼り付け用）:\n",
                en: "Exported (for array paste):\n"
            },
            exportFailed: {
                ja: "プリセットを書き出せませんでした。",
                en: "Could not export the preset."
            }
        }
    };

    // =========================================
    // 単位 / Units
    // =========================================

    /* 単位コードに対応する表示ラベルと、1単位あたりのポイント数
       Unit code -> display label and points per unit */
    var UNITS = [
        { label: "in",    pointsPerUnit: 72 },                /* 0 */
        { label: "mm",    pointsPerUnit: 72 / 25.4 },         /* 1 */
        { label: "pt",    pointsPerUnit: 1 },                 /* 2 */
        { label: "pica",  pointsPerUnit: 12 },                /* 3 */
        { label: "cm",    pointsPerUnit: 72 / 2.54 },         /* 4 */
        { label: "Q",     pointsPerUnit: 72 / 25.4 * 0.25 },  /* 5 */
        { label: "px",    pointsPerUnit: 1 },                 /* 6 */
        { label: "ft/in", pointsPerUnit: 72 * 12 },           /* 7 */
        { label: "m",     pointsPerUnit: 72 / 25.4 * 1000 },  /* 8 */
        { label: "yd",    pointsPerUnit: 72 * 36 },           /* 9 */
        { label: "ft",    pointsPerUnit: 72 * 12 }            /* 10 */
    ];

    /* 単位コード5を「歯（H）」と表示する環境設定キー。文字サイズ（text/units）だけ「級（Q）」
       Preference keys that show unit code 5 as H; only the type size (text/units) shows Q */
    var HA_UNIT_PREF_KEYS = { "rulerType": true, "strokeUnits": true, "text/asianunits": true };

    /**
     * 環境設定キーの単位を返す
     * @param {string} [prefKey] - "rulerType"（既定）/ "strokeUnits" / "text/units" / "text/asianunits"
     * @returns {{code: number, label: string, pointsPerUnit: number}} 単位の情報
     */
    function getUnitInfo(prefKey) {
        var unitKey = prefKey || "rulerType";
        var unitCode = app.preferences.getIntegerPreference(unitKey);
        /* 未知のコードは pt に寄せる / unknown codes fall back to points */
        var unit = UNITS[unitCode] || UNITS[2];
        /* 級（Q）と歯（H）は同じ長さだが、文字サイズは「Q」、距離は「H」と呼び分ける */
        var label = (unitCode === 5 && HA_UNIT_PREF_KEYS[unitKey]) ? "H" : unit.label;
        return { code: unitCode, label: label, pointsPerUnit: unit.pointsPerUnit };
    }

    /**
     * 単位の値を pt に換算する
     * @param {number} value - 単位の値
     * @param {{pointsPerUnit: number}} unit - getUnitInfo() の戻り値か UNITS[i]
     * @returns {number} pt の値
     */
    function unitToPt(value, unit) {
        return value * unit.pointsPerUnit;
    }

    // =========================================
    // 共通ユーティリティ / Shared utilities
    // =========================================

    /**
     * 2つの座標を同じ位置とみなせるか判定します（吸着結果の微小なズレを吸収）。
     *
     * @param {number} value1 - 比較する座標。
     * @param {number} value2 - 比較する座標。
     * @returns {boolean} 同じ位置とみなせるとき true。
     */
    function isSameCoord(value1, value2) {
        return Math.abs(value1 - value2) < DETECTION.coordTolerance;
    }

    /**
     * 対象サイズからクラスタリングの許容値を求めます。
     *
     * @param {number} size - 対象の幅または高さ（pt）。
     * @returns {number} 同じ線とみなす許容値（pt）。
     */
    function getClusterTolerance(size) {
        return Math.max(DETECTION.clusterMin, Math.min(DETECTION.clusterMax, size * DETECTION.clusterRatio));
    }

    /**
     * 短すぎるセグメントを捨てるためのしきい値を求めます。
     *
     * @param {number} totalLength - セグメント長の合計（pt）。
     * @param {number} count - セグメント数。
     * @returns {number} 採用する最小の長さ（pt）。
     */
    function getMinSegmentLength(totalLength, count) {
        return Math.max(DETECTION.shortSegmentFloor, totalLength * DETECTION.shortSegmentRatio / count);
    }

    /**
     * 並べ替え済みの配列を、値の近さでクラスタに分けます。
     *
     * @param {Array<Object>} sortedItems - 値の順に並べた配列。
     * @param {function(Object):number} getValue - 要素から比較する値を取り出す関数。
     * @param {number} tolerance - 同じクラスタとみなす差。
     * @returns {Array<Array<Object>>} クラスタの配列。
     */
    function clusterByValue(sortedItems, getValue, tolerance) {
        var clusters = [];
        var currentCluster = null;
        var baseValue = 0;
        for (var i = 0; i < sortedItems.length; i++) {
            var value = getValue(sortedItems[i]);
            if (!currentCluster || Math.abs(baseValue - value) > tolerance) {
                currentCluster = [];
                baseValue = value;
                clusters.push(currentCluster);
            }
            currentCluster.push(sortedItems[i]);
        }
        return clusters;
    }

    /**
     * 重み付き平均を求めます。
     *
     * @param {Array<Object>} weightedItems - 対象の配列。
     * @param {function(Object):number} getValue - 平均する値を取り出す関数。
     * @param {function(Object):number} getWeight - 重みを取り出す関数。
     * @returns {number} 重み付き平均（重みの合計が0のときは0）。
     */
    function weightedAverage(weightedItems, getValue, getWeight) {
        var total = 0;
        var sum = 0;
        for (var i = 0; i < weightedItems.length; i++) {
            var weight = getWeight(weightedItems[i]);
            total += weight;
            sum += getValue(weightedItems[i]) * weight;
        }
        return total > 0 ? (sum / total) : 0;
    }

    /**
     * グレー（K）のカラーを作成します。
     *
     * @param {number} tint - 濃度（0〜100）。
     * @returns {GrayColor} 作成したカラー。
     */
    function makeGrayColor(tint) {
        var grayColor = new GrayColor();
        grayColor.gray = tint;
        return grayColor;
    }

    /**
     * シアンのみのCMYKカラーを作成します。
     *
     * @param {number} tint - シアンの濃度（0〜100）。
     * @returns {CMYKColor} 作成したカラー。
     */
    function makeCyanColor(tint) {
        var cyanColor = new CMYKColor();
        cyanColor.cyan = tint;
        cyanColor.magenta = 0;
        cyanColor.yellow = 0;
        cyanColor.black = 0;
        return cyanColor;
    }

    /**
     * 補助線を作成するレイヤーを用意します。新しく作ったレイヤーは控えておきます。
     *
     * @param {Object} gridContext - buildGridContext() が返すコンテキスト。
     * @param {string} layerName - レイヤー名。
     * @returns {Layer} 取得または作成したレイヤー。
     */
    function ensureGuideLayer(gridContext, layerName) {
        for (var i = 0; i < gridContext.doc.layers.length; i++) {
            if (gridContext.doc.layers[i].name === layerName) {
                return gridContext.doc.layers[i];
            }
        }
        var newLayer = gridContext.doc.layers.add();
        newLayer.name = layerName;
        gridContext.createdLayers.push(newLayer);
        return newLayer;
    }

    /**
     * このスクリプトが作ったレイヤーのうち、空のまま残ったものを削除します。
     *
     * @param {Object} gridContext - buildGridContext() が返すコンテキスト。
     * @returns {void}
     */
    function removeEmptyCreatedLayers(gridContext) {
        for (var i = gridContext.createdLayers.length - 1; i >= 0; i--) {
            /* ユーザーが先に削除したレイヤーは参照が無効になる / The layer may already be gone */
            try {
                if (gridContext.createdLayers[i].pageItems.length === 0) {
                    gridContext.createdLayers[i].remove();
                }
            } catch (e) { }
        }
        gridContext.createdLayers = [];
    }

    /**
     * レイヤー名の入力値から改行・タブと前後の空白を取り除きます。
     *
     * @param {string} inputText - 入力された文字列。
     * @returns {string} 整えた文字列。
     */
    function normalizeLayerNameText(inputText) {
        return String(inputText).replace(/[\r\n\t]+/g, " ").replace(/^\s+|\s+$/g, "");
    }

    // 選択の収集と境界（再利用パーツ） / Selection items and bounds (reusable)

    /* 座標を同じと見なす許容値（pt） / Tolerance for treating coordinates as equal, in points */
    var SELECTION_ITEMS_TOLERANCE = 0.001;

    /**
     * 選択やコレクションを、オブジェクトの配列にそろえる
     * TextRange・PathItem は length を持つので、typename で1個か集まりかを見分ける
     * @param {*} source - doc.selection、配列、DOM のコレクション、または単独のオブジェクト
     * @returns {Array} オブジェクトの配列（空なら []）
     */
    function normalizeSelectionItems(source) {
        var items = [];
        if (!source) return items;
        var typeName = "";
        try { typeName = source.typename || ""; } catch (e) { /* 読めない種類 / unreadable kind */ }
        /* 単数形の typename は1個（PageItems などのコレクションは s で終わる）
           A singular typename is one object (collections such as PageItems end in s) */
        if (typeName && !/s$/.test(typeName)) return [source];
        if (typeof source.length !== "number") return items;
        for (var i = 0; i < source.length; i++) items.push(source[i]);
        return items;
    }

    /**
     * 文字カーソルの選択（TextRange）を、それを含むテキストフレームに読み替える
     * @param {TextRange} textRange - 文字の範囲
     * @returns {TextFrame|null} テキストフレーム（たどれなければ null）
     */
    function resolveTextRangeFrame(textRange) {
        var current = textRange;
        /* parent をたどる（深さは念のため制限） / Walk up the parents, with a safety limit */
        for (var depth = 0; depth < 10 && current; depth++) {
            try {
                if (current.typename === "TextFrame") return current;
                current = current.parent;
            } catch (e) {
                break;
            }
        }
        /* ストーリーの先頭フレームで代用する / Fall back to the first frame of the story */
        try {
            var storyFrames = textRange.story.textFrames;
            if (storyFrames.length > 0) return storyFrames[0];
        } catch (e2) { /* ストーリーを持たない / no story */ }
        return null;
    }

    /**
     * 選択から条件に合うオブジェクトを集める（グループ・レイヤーを再帰でたどり、重複は除く）
     * 条件に合ったオブジェクトの中へは進まない
     * @param {*} source - doc.selection、配列、コレクション、または単独のオブジェクト
     * @param {Object} [options] - 収集の設定
     * @param {function(PageItem): boolean} [options.accept] - 集める条件（既定はグループ・レイヤー以外すべて）
     * @param {boolean} [options.enterGroups] - グループの中をたどる（既定 true）
     * @param {boolean} [options.enterClipGroups] - クリップグループの中をたどる（既定は enterGroups と同じ）
     * @param {boolean} [options.enterCompoundPaths] - 複合パスの中のパスをたどる（既定 false）
     * @param {boolean} [options.textRangeToFrame] - 文字の選択をテキストフレームに読み替える（既定 true）
     * @param {boolean} [options.skipLocked] - ロックされたものを中ごと外す（既定 false）
     * @param {boolean} [options.skipHidden] - 非表示のものを中ごと外す（既定 false）
     * @param {boolean} [options.skipClipMasks] - クリッピングマスクを外す（既定 false）
     * @param {boolean} [options.skipGuides] - ガイドを外す（既定 false）
     * @param {boolean} [options.unique] - 同じ参照を1回だけにする（既定 true。数千件で遅ければ false）
     * @returns {Array} 集めたオブジェクト（前面→背面の順）
     */
    function collectSelectionItems(source, options) {
        var opts = options || {};
        var enterGroups = (opts.enterGroups !== false);
        var enterClipGroups = (opts.enterClipGroups === undefined) ? enterGroups : (opts.enterClipGroups === true);
        var accept = opts.accept || function (item) {
            return item.typename !== "GroupItem" && item.typename !== "Layer";
        };
        var collected = [];

        /**
         * 集めた配列に加える（unique のときは同じ参照を足さない）
         * @param {PageItem} item - 加えるオブジェクト
         * @returns {void}
         */
        function pushItem(item) {
            if (opts.unique !== false) {
                for (var k = 0; k < collected.length; k++) {
                    if (collected[k] === item) return;
                }
            }
            collected.push(item);
        }

        /**
         * 設定に従って外すオブジェクトか判定する
         * @param {PageItem} item - 判定するオブジェクト
         * @returns {boolean} 外すなら true
         */
        function isSkipped(item) {
            try {
                if (item.typename === "Layer") {
                    if (opts.skipLocked && item.locked) return true;
                    if (opts.skipHidden && !item.visible) return true;
                    return false;
                }
                if (opts.skipLocked && item.locked) return true;
                if (opts.skipHidden && item.hidden) return true;
                if (opts.skipGuides && item.guides === true) return true;
                if (opts.skipClipMasks && isClipMaskItem(item)) return true;
            } catch (e) {
                /* 読めないプロパティは「外さない」に倒す / Unreadable properties do not exclude */
            }
            return false;
        }

        /**
         * 1件をたどって集める
         * @param {PageItem} item - 対象のオブジェクト
         * @returns {void}
         */
        function visit(item) {
            if (!item) return;
            var typeName = "";
            try { typeName = item.typename; } catch (e) { return; }

            if (typeName === "TextRange" || typeName === "InsertionPoint") {
                if (opts.textRangeToFrame === false) {
                    if (accept(item)) pushItem(item);
                    return;
                }
                visit(resolveTextRangeFrame(item));
                return;
            }
            if (isSkipped(item)) return;
            if (accept(item)) {
                pushItem(item);
                return;
            }

            var children = null;
            if (typeName === "GroupItem") {
                var isClipped = false;
                try { isClipped = (item.clipped === true); } catch (e2) { }
                if (isClipped ? enterClipGroups : enterGroups) children = item.pageItems;
            } else if (typeName === "CompoundPathItem") {
                if (opts.enterCompoundPaths) children = item.pathItems;
            } else if (typeName === "Layer") {
                /* 重なり順はサブレイヤーとページアイテムで別々なので、ページアイテム→サブレイヤーの順にする
                   Page items and sublayers stack separately; visit page items first, then sublayers */
                walk(item.pageItems);
                walk(item.layers);
                return;
            }
            if (children) walk(children);
        }

        /**
         * 集まりの各要素をたどる
         * @param {*} list - 配列またはコレクション
         * @returns {void}
         */
        function walk(list) {
            var listItems = normalizeSelectionItems(list);
            for (var i = 0; i < listItems.length; i++) visit(listItems[i]);
        }

        walk(source);
        return collected;
    }

    /**
     * テキストフレームの種類を "point" / "area" / "path" で返す
     * @param {TextFrame} textFrame - テキストフレーム
     * @returns {string} 種類のキー（判定できなければ ""）
     */
    function getTextFrameKindKey(textFrame) {
        try {
            if (textFrame.kind === TextType.POINTTEXT) return "point";
            if (textFrame.kind === TextType.AREATEXT) return "area";
            if (textFrame.kind === TextType.PATHTEXT) return "path";
        } catch (e) { /* kind を読めない / kind is unreadable */ }
        return "";
    }

    /**
     * 選択からテキストフレームを集める（グループの中・文字カーソルの選択を含む）
     * @param {*} source - doc.selection など
     * @param {Object} [options] - collectSelectionItems と同じ設定に加えて次を受ける
     * @param {string[]} [options.kinds] - 集める種類（"point" / "area" / "path"。既定はすべて）
     * @returns {TextFrame[]} テキストフレーム（前面→背面の順）
     */
    function collectSelectionTextFrames(source, options) {
        var opts = {};
        var sourceOptions = options || {};
        for (var key in sourceOptions) {
            if (sourceOptions.hasOwnProperty(key)) opts[key] = sourceOptions[key];
        }
        var kindFilter = null;
        if (opts.kinds && opts.kinds.length) {
            kindFilter = {};
            for (var i = 0; i < opts.kinds.length; i++) kindFilter[opts.kinds[i]] = true;
        }
        opts.accept = function (item) {
            if (item.typename !== "TextFrame") return false;
            return !kindFilter || kindFilter[getTextFrameKindKey(item)] === true;
        };
        /* 種類で外したテキストは中をたどらない（accept が false でも子は無い） / Text frames have no children to walk */
        return collectSelectionItems(source, opts);
    }

    /**
     * 選択からパスを集める（グループの中を含む）
     * @param {*} source - doc.selection など
     * @param {Object} [options] - collectSelectionItems と同じ設定に加えて次を受ける
     * @param {string} [options.compoundPaths] - 複合パスの扱い。"children"（中のパス、既定）/ "whole"（複合パスごと）/ "skip"（外す）
     * @returns {Array} PathItem（"whole" のときは CompoundPathItem も）の配列
     */
    function collectSelectionPathItems(source, options) {
        var opts = {};
        var sourceOptions = options || {};
        for (var key in sourceOptions) {
            if (sourceOptions.hasOwnProperty(key)) opts[key] = sourceOptions[key];
        }
        var compoundMode = opts.compoundPaths || "children";
        opts.enterCompoundPaths = (compoundMode === "children");
        opts.accept = function (item) {
            if (item.typename === "PathItem") return true;
            return compoundMode === "whole" && item.typename === "CompoundPathItem";
        };
        return collectSelectionItems(source, opts);
    }

    /**
     * クリッピングマスク（クリップグループの型）か判定する
     * パスは clipping、複合パスは中の先頭パスの clipping、テキストは clipping が無いので「クリップグループの先頭」で見る
     * @param {PageItem} item - 判定するオブジェクト
     * @returns {boolean} マスクなら true
     */
    function isClipMaskItem(item) {
        try {
            if (item.typename === "PathItem") return item.clipping === true;
            if (item.typename === "CompoundPathItem") {
                return item.pathItems.length > 0 && item.pathItems[0].clipping === true;
            }
            if (item.typename === "TextFrame") {
                var parentGroup = item.parent;
                return parentGroup.typename === "GroupItem" && parentGroup.clipped === true &&
                    parentGroup.pageItems.length > 0 && parentGroup.pageItems[0] === item;
            }
        } catch (e) { /* 読めない種類はマスクではない / unreadable kinds are not masks */ }
        return false;
    }

    /**
     * クリップグループの型（マスク）を返す
     * フラグで探し、見つからなければ先頭（pageItems[0]）を返す（型は常に最前面。テキストの型はフラグを持たない）
     * @param {GroupItem} groupItem - 対象のグループ
     * @returns {PageItem|null} マスク（クリップグループでなければ null）
     */
    function getClipMaskItem(groupItem) {
        try {
            if (!groupItem || groupItem.typename !== "GroupItem" || groupItem.clipped !== true) return null;
            var groupChildren = groupItem.pageItems;
            if (groupChildren.length === 0) return null;
            for (var i = 0; i < groupChildren.length; i++) {
                var childType = groupChildren[i].typename;
                if ((childType === "PathItem" || childType === "CompoundPathItem") && isClipMaskItem(groupChildren[i])) {
                    return groupChildren[i];
                }
            }
            return groupChildren[0];
        } catch (e) {
            return null;
        }
    }

    /**
     * グループの中（入れ子を含む）にクリップグループがあるか判定する
     * @param {GroupItem} groupItem - 対象のグループ
     * @returns {boolean} あれば true
     */
    function hasClippedDescendant(groupItem) {
        try {
            var groupChildren = groupItem.pageItems;
            for (var i = 0; i < groupChildren.length; i++) {
                if (groupChildren[i].typename !== "GroupItem") continue;
                if (groupChildren[i].clipped === true || hasClippedDescendant(groupChildren[i])) return true;
            }
        } catch (e) { /* 中を読めない / cannot read the children */ }
        return false;
    }

    /**
     * 環境設定の［プレビュー境界を使用］を読む
     * @returns {boolean} オンなら true（読めなければ false）
     */
    function readUsePreviewBoundsPreference() {
        try {
            return app.preferences.getBooleanPreference("includeStrokeInBounds");
        } catch (e) {
            return false;
        }
    }

    /**
     * 見た目どおりの境界を返す。クリップグループはマスクの境界、
     * 中にクリップグループを含むグループは子の境界を合わせたもの（隠れた部分を含めない）
     * @param {PageItem} item - 対象のオブジェクト
     * @param {boolean} [usePreviewBounds] - true で visibleBounds、false で geometricBounds（省略時は環境設定に従う）
     * @returns {number[]|null} [左, 上, 右, 下] の新しい配列（測れなければ null）
     */
    function getClipAwareBounds(item, usePreviewBounds) {
        var usePreview = (usePreviewBounds === undefined || usePreviewBounds === null) ?
            readUsePreviewBoundsPreference() : (usePreviewBounds === true);
        try {
            var measuredItem = item;
            if (item.typename === "GroupItem") {
                var maskItem = getClipMaskItem(item);
                if (maskItem) {
                    measuredItem = maskItem;
                } else if (hasClippedDescendant(item)) {
                    /* グループ自体の効果（影など）の広がりは含まれなくなる
                       This leaves out the reach of effects applied to the group itself (drop shadows etc.) */
                    var childBounds = getClipAwareUnionBounds(filterMeasurableChildren(item.pageItems), usePreview);
                    if (childBounds) return childBounds;
                }
            }
            var bounds = usePreview ? measuredItem.visibleBounds : measuredItem.geometricBounds;
            return [bounds[0], bounds[1], bounds[2], bounds[3]];
        } catch (e) {
            return null;
        }
    }

    /**
     * 境界の計算に入れる子だけを残す（非表示とガイドを外す）
     * @param {*} childList - 子のコレクション
     * @returns {Array} 残した子
     */
    function filterMeasurableChildren(childList) {
        var childItems = normalizeSelectionItems(childList);
        var measurable = [];
        for (var i = 0; i < childItems.length; i++) {
            try {
                if (childItems[i].hidden === true || childItems[i].guides === true) continue;
            } catch (e) { /* 読めなければ残す / keep when unreadable */ }
            measurable.push(childItems[i]);
        }
        return measurable;
    }

    /**
     * 複数のオブジェクトを囲む外接範囲を返す（クリップグループはマスクで測る）
     * @param {*} items - オブジェクトの配列・コレクション・選択
     * @param {boolean} [usePreviewBounds] - true で visibleBounds、false で geometricBounds（省略時は環境設定に従う）
     * @returns {number[]|null} [左, 上, 右, 下]（測れるものが無ければ null）
     */
    function getClipAwareUnionBounds(items, usePreviewBounds) {
        var usePreview = (usePreviewBounds === undefined || usePreviewBounds === null) ?
            readUsePreviewBoundsPreference() : (usePreviewBounds === true);
        var itemList = normalizeSelectionItems(items);
        var unionBounds = null;
        for (var i = 0; i < itemList.length; i++) {
            var itemBounds = getClipAwareBounds(itemList[i], usePreview);
            if (!itemBounds) continue;
            if (!unionBounds) {
                unionBounds = itemBounds;
                continue;
            }
            if (itemBounds[0] < unionBounds[0]) unionBounds[0] = itemBounds[0];
            if (itemBounds[1] > unionBounds[1]) unionBounds[1] = itemBounds[1];
            if (itemBounds[2] > unionBounds[2]) unionBounds[2] = itemBounds[2];
            if (itemBounds[3] < unionBounds[3]) unionBounds[3] = itemBounds[3];
        }
        return unionBounds;
    }

    /**
     * 2つの座標を許容値つきで比べる
     * @param {number} valueA - 座標A（pt）
     * @param {number} valueB - 座標B（pt）
     * @param {number} [tolerance] - 許容値（pt、既定は SELECTION_ITEMS_TOLERANCE）
     * @returns {boolean} 差が許容値以下なら true
     */
    function isNearlySameCoordinate(valueA, valueB, tolerance) {
        var limit = (typeof tolerance === "number") ? tolerance : SELECTION_ITEMS_TOLERANCE;
        return Math.abs(valueA - valueB) <= limit;
    }

    /**
     * 2つの境界を許容値つきで比べる
     * @param {number[]} boundsA - [左, 上, 右, 下]
     * @param {number[]} boundsB - [左, 上, 右, 下]
     * @param {number} [tolerance] - 許容値（pt、既定は SELECTION_ITEMS_TOLERANCE）
     * @returns {boolean} 4辺とも許容値以内なら true
     */
    function areBoundsNearlyEqual(boundsA, boundsB, tolerance) {
        if (!boundsA || !boundsB) return false;
        for (var i = 0; i < 4; i++) {
            if (!isNearlySameCoordinate(boundsA[i], boundsB[i], tolerance)) return false;
        }
        return true;
    }

    // 選択の収集と境界（再利用パーツ）ここまで / End of the reusable selection items and bounds

    // =========================================
    // 選択範囲とジオメトリ / Selection and geometry
    // =========================================

    /**
     * 2つのアンカーポイントのあいだが直線（ハンドルなし）か判定します。
     *
     * @param {PathPoint} startPoint - 始点のアンカーポイント。
     * @param {PathPoint} endPoint - 終点のアンカーポイント。
     * @returns {boolean} 直線のとき true。
     */
    function isStraightSegment(startPoint, endPoint) {
        var tolerance = DETECTION.coordTolerance;
        return Math.abs(startPoint.rightDirection[0] - startPoint.anchor[0]) < tolerance &&
            Math.abs(startPoint.rightDirection[1] - startPoint.anchor[1]) < tolerance &&
            Math.abs(endPoint.leftDirection[0] - endPoint.anchor[0]) < tolerance &&
            Math.abs(endPoint.leftDirection[1] - endPoint.anchor[1]) < tolerance;
    }

    /**
     * 直線セグメントの向きを判定します。
     *
     * @param {Array<number>} startAnchor - 始点の座標 [x, y]。
     * @param {Array<number>} endAnchor - 終点の座標 [x, y]。
     * @returns {string} "HORIZONTAL" / "VERTICAL" / "DIAGONAL"。
     */
    function classifySegmentDirection(startAnchor, endAnchor) {
        if (isSameCoord(startAnchor[1], endAnchor[1])) return "HORIZONTAL";
        if (isSameCoord(startAnchor[0], endAnchor[0])) return "VERTICAL";
        return "DIAGONAL";
    }

    /**
     * 斜線セグメントの情報（角度は0〜180度に正規化）を作成します。
     *
     * @param {Array<number>} startAnchor - 始点の座標 [x, y]。
     * @param {Array<number>} endAnchor - 終点の座標 [x, y]。
     * @returns {{startAnchor: Array<number>, endAnchor: Array<number>, angle: number, length: number}} 斜線セグメント。
     */
    function makeDiagonalSegment(startAnchor, endAnchor) {
        var dx = endAnchor[0] - startAnchor[0];
        var dy = endAnchor[1] - startAnchor[1];
        var angle = Math.atan2(dy, dx) * 180 / Math.PI;
        if (angle < 0) angle += 180;
        if (angle >= 180) angle -= 180;
        return {
            startAnchor: startAnchor,
            endAnchor: endAnchor,
            angle: angle,
            length: Math.sqrt(dx * dx + dy * dy)
        };
    }

    /**
     * パスが属する複合パスの番号を返します（複合パスに属さないときは null）。
     *
     * @param {PathItem} pathItem - 対象のパス。
     * @param {Array<CompoundPathItem>} compoundParents - これまでに見つかった複合パス（見つかるたびに追加）。
     * @returns {number|null} 複合パスの番号。
     */
    function getCompoundId(pathItem, compoundParents) {
        var parentItem = pathItem.parent;
        if (parentItem.typename !== "CompoundPathItem") return null;
        for (var i = 0; i < compoundParents.length; i++) {
            if (compoundParents[i] === parentItem) return i;
        }
        compoundParents.push(parentItem);
        return compoundParents.length - 1;
    }

    /**
     * 選択範囲のアンカーポイントと直線セグメントを、向きごとに集めます。
     *
     * @param {Array<PageItem>} pageItems - 選択中のオブジェクト。
     * @returns {{points: Array<Object>, shapes: Array<Object>, horizontal: Array<Object>, vertical: Array<Object>, diagonal: Array<Object>, top: number, bottom: number}} 解析用のジオメトリ。
     */
    function collectGeometry(pageItems) {
        var compoundParents = [];
        var geometry = {
            points: [],
            shapes: [],
            horizontal: [],
            vertical: [],
            diagonal: [],
            top: -Infinity,
            bottom: Infinity
        };

        /* グループ・複合パスの中のパスもたどる / Walk into groups and compound paths */
        var pathItems = collectSelectionPathItems(pageItems, { unique: false });
        for (var pathIndex = 0; pathIndex < pathItems.length; pathIndex++) {
            var pathItem = pathItems[pathIndex];
            var pathPoints = pathItem.pathPoints;
            var count = pathPoints.length;
            var shapeBounds = pathItem.geometricBounds;
            var shape = {
                left: shapeBounds[0],
                top: shapeBounds[1],
                right: shapeBounds[2],
                bottom: shapeBounds[3],
                compoundId: getCompoundId(pathItem, compoundParents),
                points: []
            };
            geometry.shapes.push(shape);
            for (var i = 0; i < count; i++) {
                var nextIndex = (i + 1) % count;
                var startAnchor = pathPoints[i].anchor;
                var endAnchor = pathPoints[nextIndex].anchor;

                if (startAnchor[1] > geometry.top) geometry.top = startAnchor[1];
                if (startAnchor[1] < geometry.bottom) geometry.bottom = startAnchor[1];

                /* 水平に近い辺の端点は、自動判定で横線の手がかりにする */
                var onHorizontal = Math.abs(startAnchor[1] - endAnchor[1]) < DETECTION.horizontalFlatness &&
                    Math.abs(startAnchor[0] - endAnchor[0]) > DETECTION.horizontalMinRun;
                var anchorPoint = { x: startAnchor[0], y: startAnchor[1], onHorizontal: onHorizontal };
                geometry.points.push(anchorPoint);
                shape.points.push(anchorPoint);

                /* 開いたパスの終端は次の点とつながらない / The last point of an open path has no next segment */
                if (i >= count - 1 && !pathItem.closed) continue;
                if (!isStraightSegment(pathPoints[i], pathPoints[nextIndex])) continue;

                var direction = classifySegmentDirection(startAnchor, endAnchor);
                if (direction === "HORIZONTAL") {
                    geometry.horizontal.push({ position: startAnchor[1], length: Math.abs(startAnchor[0] - endAnchor[0]) });
                } else if (direction === "VERTICAL") {
                    geometry.vertical.push({ position: startAnchor[0], length: Math.abs(startAnchor[1] - endAnchor[1]) });
                } else {
                    geometry.diagonal.push(makeDiagonalSegment(startAnchor, endAnchor));
                }
            }
        }

        return geometry;
    }

    /**
     * 選択範囲の寸法とジオメトリをまとめた、処理用のコンテキストを作成します。
     *
     * @param {Document} targetDoc - 対象のドキュメント。
     * @param {Array<PageItem>} selectedItems - 選択中のオブジェクト。
     * @returns {Object|null} コンテキスト。作成できないときは null。
     */
    function buildGridContext(targetDoc, selectedItems) {
        /* クリップグループはマスクの範囲 / A clip group is measured by its mask */
        var selectionBounds = getClipAwareUnionBounds(selectedItems, true);
        if (!selectionBounds) {
            alert(getLabel(LABELS.alert.noBounds));
            return null;
        }

        var selLeft = selectionBounds[0];
        var selTop = selectionBounds[1];
        var selRight = selectionBounds[2];
        var selBottom = selectionBounds[3];
        var selWidth = selRight - selLeft;
        var selHeight = selTop - selBottom;

        if (selWidth <= 0 || selHeight <= 0) {
            alert(getLabel(LABELS.alert.invalidSize));
            return null;
        }

        return {
            doc: targetDoc,
            items: selectedItems,
            selLeft: selLeft,
            selTop: selTop,
            selRight: selRight,
            selBottom: selBottom,
            selWidth: selWidth,
            selHeight: selHeight,
            centerX: (selLeft + selRight) / 2,
            centerY: (selTop + selBottom) / 2,
            geometry: collectGeometry(selectedItems),
            guideLayer: null,
            createdLayers: []
        };
    }

    // =========================================
    // ライン解析 / Line analysis
    // =========================================

    /**
     * 形状 inner の範囲が、形状 outer の範囲に収まっているか判定します。
     *
     * @param {Object} inner - 判定する形状の範囲。
     * @param {Object} outer - 外側の形状の範囲。
     * @returns {boolean} 収まっているとき true。
     */
    function isShapeInside(inner, outer) {
        return outer.left <= inner.left && outer.right >= inner.right &&
            outer.top >= inner.top && outer.bottom <= inner.bottom;
    }

    /**
     * 基準線の推定に使う字形の本体を選びます。
     * 同じ複合パスの内側にある形状（o や A の穴）と、上半分に浮いている形状（アクセント・点・引用符など）を除きます。
     * すべて除かれてしまうときは、穴を除いた形状を返します。
     *
     * @param {Array<Object>} shapes - collectGeometry() の形状。
     * @returns {Array<Object>} 推定に使う形状。
     */
    function getBodyShapes(shapes) {
        var outerShapes = [];
        var top = -Infinity;
        var bottom = Infinity;
        var i, j;

        for (i = 0; i < shapes.length; i++) {
            var isCounter = false;
            for (j = 0; j < shapes.length && !isCounter; j++) {
                if (j !== i && shapes[i].compoundId !== null && shapes[j].compoundId === shapes[i].compoundId &&
                    isShapeInside(shapes[i], shapes[j])) isCounter = true;
            }
            if (isCounter) continue;
            outerShapes.push(shapes[i]);
            if (shapes[i].top > top) top = shapes[i].top;
            if (shapes[i].bottom < bottom) bottom = shapes[i].bottom;
        }

        var middleY = (top + bottom) / 2;
        var bodyShapes = [];
        for (i = 0; i < outerShapes.length; i++) {
            if (outerShapes[i].bottom <= middleY) bodyShapes.push(outerShapes[i]);
        }
        return bodyShapes.length > 0 ? bodyShapes : outerShapes;
    }

    /**
     * 輪郭の前後のアンカーより低い（または高い）アンカーポイントを集めます。
     * 同じ高さが続く区間は、その前後の点と比べます。
     *
     * @param {Object} shape - collectGeometry() の形状。
     * @param {boolean} findLowest - 低い点を集めるとき true、高い点を集めるとき false。
     * @returns {Array<Object>} 該当するアンカーポイント。
     */
    function collectExtremePoints(shape, findLowest) {
        var points = shape.points;
        var count = points.length;
        var extremePoints = [];

        for (var i = 0; i < count; i++) {
            var y = points[i].y;
            var prevIndex = (i - 1 + count) % count;
            var nextIndex = (i + 1) % count;
            var guard = 0;
            while (isSameCoord(points[prevIndex].y, y) && guard++ < count) prevIndex = (prevIndex - 1 + count) % count;
            guard = 0;
            while (isSameCoord(points[nextIndex].y, y) && guard++ < count) nextIndex = (nextIndex + 1) % count;

            var isExtreme = findLowest ?
                (points[prevIndex].y >= y && points[nextIndex].y >= y) :
                (points[prevIndex].y <= y && points[nextIndex].y <= y);
            if (isExtreme) extremePoints.push(points[i]);
        }
        return extremePoints;
    }

    /**
     * 形状ごとの候補の高さをクラスタに分け、クラスタごとに乗っている形状の数と代表位置をまとめます。
     *
     * @param {Array<Object>} entries - y・shapeIndex・onHorizontal・isBottom を持つ候補。
     * @param {number} tolerance - 同じ線とみなす差（pt）。
     * @returns {Array<Object>} 上から順の候補線（shapeCount・bottomCount・flatY・flatMaxY・minY・maxY）。
     */
    function summarizeShapeLines(entries, tolerance) {
        var sortedEntries = entries.slice().sort(function (a, b) { return b.y - a.y; });
        var clusters = clusterByValue(sortedEntries, function (entry) { return entry.y; }, tolerance);
        var candidateLines = [];

        for (var i = 0; i < clusters.length; i++) {
            var seenShapes = {};
            var seenBottoms = {};
            var flatFrequency = {};
            var candidateLine = { shapeCount: 0, bottomCount: 0, flatY: null, flatMaxY: null, minY: Infinity, maxY: -Infinity };
            var bestFlatCount = 0;

            for (var j = 0; j < clusters[i].length; j++) {
                var entry = clusters[i][j];
                if (!seenShapes[entry.shapeIndex]) {
                    seenShapes[entry.shapeIndex] = true;
                    candidateLine.shapeCount++;
                }
                if (entry.isBottom && !seenBottoms[entry.shapeIndex]) {
                    seenBottoms[entry.shapeIndex] = true;
                    candidateLine.bottomCount++;
                }
                if (entry.y < candidateLine.minY) candidateLine.minY = entry.y;
                if (entry.y > candidateLine.maxY) candidateLine.maxY = entry.y;

                /* 水平な辺の高さを優先して代表位置にする（丸みのはみ出しを避ける） */
                if (entry.onHorizontal) {
                    var yKey = entry.y.toFixed(3);
                    flatFrequency[yKey] = (flatFrequency[yKey] || 0) + 1;
                    if (flatFrequency[yKey] > bestFlatCount) {
                        bestFlatCount = flatFrequency[yKey];
                        candidateLine.flatY = entry.y;
                    }
                    if (candidateLine.flatMaxY === null || entry.y > candidateLine.flatMaxY) candidateLine.flatMaxY = entry.y;
                }
            }
            candidateLines.push(candidateLine);
        }
        return candidateLines;
    }

    /**
     * 字形の下向きの極値から、ベースラインを推定します。
     * 極値に乗る形状がもっとも多い高さを選び、同数なら形状の下端が多い高さを選びます。
     *
     * @param {Array<Object>} bodyShapes - getBodyShapes() の結果。
     * @param {number} tolerance - 同じ線とみなす差（pt）。
     * @returns {number} ベースラインのY座標。
     */
    function detectBaseline(bodyShapes, tolerance) {
        var entries = [];
        for (var i = 0; i < bodyShapes.length; i++) {
            var lowestPoints = collectExtremePoints(bodyShapes[i], true);
            for (var j = 0; j < lowestPoints.length; j++) {
                entries.push({
                    y: lowestPoints[j].y,
                    shapeIndex: i,
                    onHorizontal: lowestPoints[j].onHorizontal,
                    isBottom: Math.abs(lowestPoints[j].y - bodyShapes[i].bottom) <= tolerance
                });
            }
        }

        var candidateLines = summarizeShapeLines(entries, tolerance);
        var baseLine = null;
        var bestScore = -Infinity;
        for (var k = 0; k < candidateLines.length; k++) {
            var score = candidateLines[k].shapeCount * 10 + candidateLines[k].bottomCount;
            if (score > bestScore) {
                bestScore = score;
                baseLine = candidateLines[k];
            }
        }
        return baseLine.flatY !== null ? baseLine.flatY : baseLine.maxY;
    }

    /**
     * 字形の上端をまとめて、上から順の候補線を作ります。
     *
     * @param {Array<Object>} bodyShapes - getBodyShapes() の結果。
     * @param {number} tolerance - 同じ線とみなす差（pt）。
     * @returns {Array<Object>} summarizeShapeLines() の結果。
     */
    function collectTopLines(bodyShapes, tolerance) {
        var entries = [];
        for (var i = 0; i < bodyShapes.length; i++) {
            var shapeTop = bodyShapes[i].top;
            entries.push({ y: shapeTop, shapeIndex: i, onHorizontal: false, isBottom: false });

            /* 上端に水平な辺があれば、その高さも候補に加える */
            var highestPoints = collectExtremePoints(bodyShapes[i], false);
            for (var j = 0; j < highestPoints.length; j++) {
                if (highestPoints[j].onHorizontal && Math.abs(highestPoints[j].y - shapeTop) <= tolerance) {
                    entries.push({ y: highestPoints[j].y, shapeIndex: i, onHorizontal: true, isBottom: false });
                }
            }
        }
        return summarizeShapeLines(entries, tolerance);
    }

    /**
     * 字形の形から、書体の基準線（アセンダー〜ディセンダー）を推定します。
     *
     * @param {Object} geometry - collectGeometry() の結果。
     * @returns {{ascenderY: number, meanY: number, baseY: number, descenderY: number, hasDescender: boolean}} 推定した基準線。
     */
    function detectTypographicLines(geometry) {
        var bodyShapes = getBodyShapes(geometry.shapes);
        var bodyTop = -Infinity;
        var bodyBottom = Infinity;
        var i;
        for (i = 0; i < bodyShapes.length; i++) {
            if (bodyShapes[i].top > bodyTop) bodyTop = bodyShapes[i].top;
            if (bodyShapes[i].bottom < bodyBottom) bodyBottom = bodyShapes[i].bottom;
        }
        /* 小さい文字でも線が混ざらないよう、下限は設けずに高さへ比例させる */
        var tolerance = Math.min(DETECTION.clusterMax, (bodyTop - bodyBottom) * DETECTION.clusterRatio);

        var baseY = detectBaseline(bodyShapes, tolerance);

        var topLines = collectTopLines(bodyShapes, tolerance);
        var ascenderY = topLines[0].flatMaxY !== null ? topLines[0].flatMaxY : topLines[0].minY;
        var height = ascenderY - baseY;

        /* ミーンライン：上端がそろう形状がもっとも多い高さ。同数なら x-height らしい高さを選ぶ */
        var meanY = null;
        var bestScore = -Infinity;
        for (i = 1; i < topLines.length; i++) {
            var lineY = topLines[i].flatY !== null ? topLines[i].flatY : topLines[i].minY;
            if (lineY <= baseY + height * DETECTION.fallbackLineRatio) continue;
            var score = topLines[i].shapeCount * 10 - Math.abs((lineY - baseY) / height - DETECTION.xHeightRatio);
            if (score > bestScore) {
                bestScore = score;
                meanY = lineY;
            }
        }
        if (meanY === null) meanY = ascenderY - height * DETECTION.fallbackLineRatio;

        /* ディセンダー：ベースラインより十分上まで伸びる形状の下端（カンマ・ピリオドは除く） */
        var descenderY = baseY;
        for (i = 0; i < bodyShapes.length; i++) {
            if (bodyShapes[i].top < baseY + height * DETECTION.fallbackLineRatio) continue;
            if (bodyShapes[i].bottom < descenderY) descenderY = bodyShapes[i].bottom;
        }
        var hasDescender = (baseY - descenderY) > (ascenderY - descenderY) * DETECTION.descenderRatio;
        if (!hasDescender) descenderY = baseY;

        return {
            ascenderY: ascenderY,
            meanY: meanY,
            baseY: baseY,
            descenderY: descenderY,
            hasDescender: hasDescender
        };
    }

    /**
     * 直線セグメントをクラスタリングし、長さで加重平均した代表位置を返します。
     *
     * @param {Array<Object>} segments - position と length を持つセグメント。
     * @param {{descending: boolean, dropShort: boolean, span: number}} clusterOptions - 並び順・短いセグメントの扱い・許容値の基準サイズ。
     * @returns {Array<number>} 線の位置。
     */
    function getSegmentLinePositions(segments, clusterOptions) {
        if (segments.length === 0) return [];

        var minPosition = Infinity;
        var maxPosition = -Infinity;
        var totalLength = 0;
        for (var i = 0; i < segments.length; i++) {
            if (segments[i].position < minPosition) minPosition = segments[i].position;
            if (segments[i].position > maxPosition) maxPosition = segments[i].position;
            totalLength += segments[i].length;
        }

        var keptSegments = segments;
        if (clusterOptions.dropShort) {
            var minLength = getMinSegmentLength(totalLength, segments.length);
            keptSegments = [];
            for (var j = 0; j < segments.length; j++) {
                if (segments[j].length >= minLength) keptSegments.push(segments[j]);
            }
            if (keptSegments.length === 0) return [];
        }

        var span = (typeof clusterOptions.span === "number") ? clusterOptions.span : (maxPosition - minPosition);
        var descending = !!clusterOptions.descending;
        var sortedSegments = keptSegments.slice().sort(function (a, b) {
            return descending ? (b.position - a.position) : (a.position - b.position);
        });
        var clusters = clusterByValue(sortedSegments, function (segment) { return segment.position; }, getClusterTolerance(span));

        var positions = [];
        for (var k = 0; k < clusters.length; k++) {
            positions.push(weightedAverage(clusters[k],
                function (segment) { return segment.position; },
                function (segment) { return segment.length; }));
        }

        positions.sort(function (a, b) { return descending ? (b - a) : (a - b); });
        return positions;
    }

    /**
     * ［ラインの決め方］に従って、横線を引くY座標を求めます。
     *
     * @param {Object} geometry - collectGeometry() の結果。
     * @param {string} lineMethod - "none" / "segment" / "even" / "auto"。
     * @param {number} evenLineCount - 均等分割の本数。
     * @returns {Array<number>} 横線のY座標。
     */
    function getHorizontalLineYs(geometry, lineMethod, evenLineCount) {
        if (geometry.points.length === 0 || lineMethod === "none") return [];

        if (lineMethod === "segment") {
            return getSegmentLinePositions(geometry.horizontal, {
                descending: true,
                dropShort: false,
                span: geometry.top - geometry.bottom
            });
        }

        if (lineMethod === "even") {
            var evenLineYs = [geometry.top];
            var step = (geometry.top - geometry.bottom) / (evenLineCount + 1);
            for (var i = 1; i <= evenLineCount; i++) {
                evenLineYs.push(geometry.top - step * i);
            }
            evenLineYs.push(geometry.bottom);
            return evenLineYs;
        }

        var zones = detectTypographicLines(geometry);
        var autoLines = [zones.ascenderY, zones.meanY];
        if (zones.hasDescender) autoLines.push(zones.baseY);
        autoLines.push(zones.descenderY);
        return autoLines;
    }

    /**
     * 垂直エレメント（縦のステム）のX座標を求めます。
     *
     * @param {Object} geometry - collectGeometry() の結果。
     * @returns {Array<number>} 縦線のX座標。
     */
    function getVerticalElementXs(geometry) {
        return getSegmentLinePositions(geometry.vertical, { descending: false, dropShort: true });
    }

    /**
     * 2点を通る直線を、指定した矩形の境界まで伸ばします。
     *
     * @param {Array<number>} startAnchor - 始点の座標 [x, y]。
     * @param {Array<number>} endAnchor - 終点の座標 [x, y]。
     * @param {number} left - 左端。
     * @param {number} top - 上端。
     * @param {number} right - 右端。
     * @param {number} bottom - 下端。
     * @returns {Array<Array<number>>|null} 交点2つ。求まらないときは null。
     */
    function extendLineToBounds(startAnchor, endAnchor, left, top, right, bottom) {
        var x1 = startAnchor[0], y1 = startAnchor[1];
        var x2 = endAnchor[0], y2 = endAnchor[1];
        var tolerance = DETECTION.coordTolerance;
        var intersections = [];

        if (isSameCoord(x1, x2)) {
            intersections.push([x1, top]);
            intersections.push([x1, bottom]);
        } else if (isSameCoord(y1, y2)) {
            intersections.push([left, y1]);
            intersections.push([right, y1]);
        } else {
            var slope = (y2 - y1) / (x2 - x1);
            var intercept = y1 - slope * x1;

            var yAtLeft = slope * left + intercept;
            if (yAtLeft <= top + tolerance && yAtLeft >= bottom - tolerance) intersections.push([left, yAtLeft]);

            var yAtRight = slope * right + intercept;
            if (yAtRight <= top + tolerance && yAtRight >= bottom - tolerance) intersections.push([right, yAtRight]);

            var xAtTop = (top - intercept) / slope;
            if (xAtTop >= left - tolerance && xAtTop <= right + tolerance) intersections.push([xAtTop, top]);

            var xAtBottom = (bottom - intercept) / slope;
            if (xAtBottom >= left - tolerance && xAtBottom <= right + tolerance) intersections.push([xAtBottom, bottom]);
        }

        if (intersections.length < 2) return null;

        /* 同じ点が並ぶことがあるため、離れた2点を選ぶ / Pick two points that are actually apart */
        for (var i = 1; i < intersections.length; i++) {
            var dx = intersections[i][0] - intersections[0][0];
            var dy = intersections[i][1] - intersections[0][1];
            if (Math.sqrt(dx * dx + dy * dy) > tolerance) {
                return [intersections[0], intersections[i]];
            }
        }
        return null;
    }

    /**
     * 1点と角度から、指定した矩形の境界まで伸びる直線を求めます。
     *
     * @param {Array<number>} point - 通過する座標 [x, y]。
     * @param {number} angleRad - 角度（ラジアン）。
     * @param {number} left - 左端。
     * @param {number} top - 上端。
     * @param {number} right - 右端。
     * @param {number} bottom - 下端。
     * @returns {Array<Array<number>>|null} 交点2つ。求まらないときは null。
     */
    function extendPointAtAngle(point, angleRad, left, top, right, bottom) {
        var farDistance = 100000;
        var farPoint = [point[0] + Math.cos(angleRad) * farDistance, point[1] + Math.sin(angleRad) * farDistance];
        return extendLineToBounds(point, farPoint, left, top, right, bottom);
    }

    /**
     * 斜線の重複を判定するためのキーを作ります。
     *
     * @param {Array<Array<number>>} endpoints - 線の両端 [[x, y], [x, y]]。
     * @returns {string} 両端の座標から作ったキー。
     */
    function makeDiagonalLineKey(endpoints) {
        var keyStart = endpoints[0][0].toFixed(1) + "," + endpoints[0][1].toFixed(1);
        var keyEnd = endpoints[1][0].toFixed(1) + "," + endpoints[1][1].toFixed(1);
        return (keyStart < keyEnd) ? (keyStart + "|" + keyEnd) : (keyEnd + "|" + keyStart);
    }

    /**
     * 斜体の傾きとして扱える角度のセグメントだけを取り出します。
     *
     * @param {Array<Object>} segments - 斜線セグメント。
     * @returns {Array<Object>} 角度が範囲内のセグメント。
     */
    function filterDiagonalSegments(segments) {
        var filtered = [];
        for (var i = 0; i < segments.length; i++) {
            if (segments[i].angle > DETECTION.diagonalMinAngle && segments[i].angle < DETECTION.diagonalMaxAngle) {
                filtered.push(segments[i]);
            }
        }
        return filtered;
    }

    /**
     * もっとも多く使われている傾きのセグメント群を選びます。
     *
     * @param {Array<Object>} segments - 斜線セグメント。
     * @returns {Array<Object>|null} 選ばれたセグメント群。見つからないときは null。
     */
    function pickDominantAngleCluster(segments) {
        var sortedSegments = segments.slice().sort(function (a, b) { return a.angle - b.angle; });
        var clusters = clusterByValue(sortedSegments, function (segment) { return segment.angle; }, DETECTION.diagonalAngleTolerance);

        var dominantCluster = null;
        var bestLength = -1;
        for (var i = 0; i < clusters.length; i++) {
            var totalLength = 0;
            for (var j = 0; j < clusters[i].length; j++) {
                totalLength += clusters[i][j].length;
            }
            if (totalLength > bestLength) {
                bestLength = totalLength;
                dominantCluster = clusters[i];
            }
        }
        return dominantCluster;
    }

    /**
     * 斜線セグメントの中点を、傾きに直交する方向でまとめます。
     *
     * @param {Array<Object>} segments - 同じ傾きのセグメント。
     * @param {number} angleRad - 傾き（ラジアン）。
     * @param {number} minLength - 採用する最小の長さ。
     * @returns {Array<Array<number>>} まとめた中点の座標。
     */
    function mergeSegmentMidpoints(segments, angleRad, minLength) {
        var normalX = -Math.sin(angleRad);
        var normalY = Math.cos(angleRad);

        var midpoints = [];
        for (var i = 0; i < segments.length; i++) {
            if (segments[i].length < minLength) continue;
            var x = (segments[i].startAnchor[0] + segments[i].endAnchor[0]) / 2;
            var y = (segments[i].startAnchor[1] + segments[i].endAnchor[1]) / 2;
            midpoints.push({ x: x, y: y, length: segments[i].length, offset: x * normalX + y * normalY });
        }
        if (midpoints.length === 0) return [];

        midpoints.sort(function (a, b) { return a.offset - b.offset; });
        var mergeTolerance = Math.max(DETECTION.shortSegmentFloor, minLength * DETECTION.diagonalMergeRatio);
        var clusters = clusterByValue(midpoints, function (midpoint) { return midpoint.offset; }, mergeTolerance);

        var merged = [];
        for (var j = 0; j < clusters.length; j++) {
            merged.push([
                weightedAverage(clusters[j], function (midpoint) { return midpoint.x; }, function (midpoint) { return midpoint.length; }),
                weightedAverage(clusters[j], function (midpoint) { return midpoint.y; }, function (midpoint) { return midpoint.length; })
            ]);
        }
        return merged;
    }

    /**
     * 斜線エレメント（斜体の傾きに沿った線）を求めます。
     *
     * @param {Object} geometry - collectGeometry() の結果。
     * @param {number} left - 線を伸ばす範囲の左端。
     * @param {number} top - 線を伸ばす範囲の上端。
     * @param {number} right - 線を伸ばす範囲の右端。
     * @param {number} bottom - 線を伸ばす範囲の下端。
     * @returns {Array<Array<Array<number>>>} 線の両端の座標の配列。
     */
    function getDiagonalElementLines(geometry, left, top, right, bottom) {
        var segments = filterDiagonalSegments(geometry.diagonal);
        if (segments.length === 0) return [];

        var dominantCluster = pickDominantAngleCluster(segments);
        if (!dominantCluster) return [];

        var totalLength = 0;
        for (var i = 0; i < dominantCluster.length; i++) {
            totalLength += dominantCluster[i].length;
        }
        var angleRad = weightedAverage(dominantCluster,
            function (segment) { return segment.angle; },
            function (segment) { return segment.length; }) * Math.PI / 180;

        var midpoints = mergeSegmentMidpoints(dominantCluster, angleRad, getMinSegmentLength(totalLength, dominantCluster.length));

        var diagonalLines = [];
        var usedKeys = {};
        for (var j = 0; j < midpoints.length; j++) {
            var diagonalLine = extendPointAtAngle(midpoints[j], angleRad, left, top, right, bottom);
            if (!diagonalLine) continue;
            var lineKey = makeDiagonalLineKey(diagonalLine);
            if (usedKeys[lineKey]) continue;
            usedKeys[lineKey] = true;
            diagonalLines.push(diagonalLine);
        }
        return diagonalLines;
    }

    // =========================================
    // プリセット / Presets
    // =========================================

    /* プリセットの定義（伸張率と本数は入力欄の文字列） / Preset definitions */
    var PRESET_DEFINITIONS = {
        "1x1": {
            widthScale: "140.0", extraHLines: true, extraHLineCount: "1", extendLeft: false,
            lineMethod: "none", evenLineCount: "4",
            heightScale: "200.0", outerVLines: true, outerVLineCount: "1", extendUp: false,
            columnDiv: false, columnDivisions: "2", verticalElements: false, diagonalElements: false,
            emphasizeBounds: false,
            clearSpace: false, clearSpaceDivisions: "4"
        },
        "auto": {
            widthScale: "120.0", extraHLines: true, extraHLineCount: "2", extendLeft: false,
            lineMethod: "auto", evenLineCount: "4",
            heightScale: "200.0", outerVLines: true, outerVLineCount: "2", extendUp: false,
            columnDiv: false, columnDivisions: "2", verticalElements: false, diagonalElements: false,
            emphasizeBounds: true,
            clearSpace: false, clearSpaceDivisions: "4"
        },
        "element": {
            widthScale: "120.0", extraHLines: false, extraHLineCount: "2", extendLeft: false,
            lineMethod: "segment", evenLineCount: "4",
            heightScale: "300.0", outerVLines: false, outerVLineCount: "2", extendUp: false,
            columnDiv: false, columnDivisions: "3", verticalElements: true, diagonalElements: true,
            emphasizeBounds: false,
            clearSpace: false, clearSpaceDivisions: "5"
        },
        "element+": {
            widthScale: "120.0", extraHLines: true, extraHLineCount: "2", extendLeft: false,
            lineMethod: "segment", evenLineCount: "4",
            heightScale: "300.0", outerVLines: true, outerVLineCount: "2", extendUp: false,
            columnDiv: false, columnDivisions: "3", verticalElements: true, diagonalElements: true,
            emphasizeBounds: true,
            clearSpace: false, clearSpaceDivisions: "5"
        },
        "left": {
            widthScale: "150.0", extraHLines: true, extraHLineCount: "2", extendLeft: true,
            lineMethod: "even", evenLineCount: "4",
            heightScale: "200.0", outerVLines: true, outerVLineCount: "2", extendUp: false,
            columnDiv: false, columnDivisions: "2", verticalElements: false, diagonalElements: false,
            emphasizeBounds: true,
            clearSpace: false, clearSpaceDivisions: "5"
        },
        "up-3": {
            widthScale: "120.0", extraHLines: true, extraHLineCount: "2", extendLeft: false,
            lineMethod: "even", evenLineCount: "4",
            heightScale: "300.0", outerVLines: true, outerVLineCount: "2", extendUp: true,
            columnDiv: true, columnDivisions: "3", verticalElements: false, diagonalElements: false,
            emphasizeBounds: true,
            clearSpace: false, clearSpaceDivisions: "5"
        },
        "clear space": {
            widthScale: "140.0", extraHLines: true, extraHLineCount: "1", extendLeft: false,
            lineMethod: "none", evenLineCount: "4",
            heightScale: "200.0", outerVLines: true, outerVLineCount: "1", extendUp: false,
            columnDiv: false, columnDivisions: "2", verticalElements: false, diagonalElements: false,
            emphasizeBounds: false,
            clearSpace: true, clearSpaceDivisions: "4"
        }
    };

    /* プリセットのキーとUIコントロールの対応 / Preset keys and the controls they map to */
    var PRESET_FIELDS = {
        widthScale: { control: "widthScaleInput", kind: "scale" },
        extraHLines: { control: "extraHLinesCheck", kind: "check" },
        extraHLineCount: { control: "extraHLinesInput", kind: "text" },
        extendLeft: { control: "extendLeftCheck", kind: "check" },
        lineMethod: { control: "", kind: "method" },
        evenLineCount: { control: "evenLineCountInput", kind: "text" },
        heightScale: { control: "heightScaleInput", kind: "scale" },
        outerVLines: { control: "outerVLinesCheck", kind: "check" },
        outerVLineCount: { control: "outerVLinesInput", kind: "text" },
        extendUp: { control: "extendUpCheck", kind: "check" },
        columnDiv: { control: "columnDivCheck", kind: "check" },
        columnDivisions: { control: "columnDivInput", kind: "text" },
        verticalElements: { control: "verticalElementsCheck", kind: "check" },
        diagonalElements: { control: "diagonalElementsCheck", kind: "check" },
        emphasizeBounds: { control: "emphasizeBoundsCheck", kind: "check" },
        clearSpace: { control: "clearSpaceCheck", kind: "check" },
        clearSpaceDivisions: { control: "clearSpaceDivInput", kind: "text" }
    };

    /* 書き出し時の行の並び / Key order used when a preset is exported */
    var PRESET_FIELD_ROWS = [
        ["widthScale", "extraHLines", "extraHLineCount", "extendLeft"],
        ["lineMethod", "evenLineCount"],
        ["heightScale", "outerVLines", "outerVLineCount", "extendUp"],
        ["columnDiv", "columnDivisions", "verticalElements", "diagonalElements"],
        ["emphasizeBounds"],
        ["clearSpace", "clearSpaceDivisions"]
    ];

    /**
     * ［ラインの決め方］の選択状態を取得します。
     *
     * @param {Object} dialogUI - buildDialog() が返すUI参照。
     * @returns {string} "none" / "even" / "segment" / "auto"。
     */
    function getLineMethod(dialogUI) {
        if (dialogUI.methodNoneRadio.value) return "none";
        if (dialogUI.methodEvenRadio.value) return "even";
        if (dialogUI.methodSegmentRadio.value) return "segment";
        return "auto";
    }

    /**
     * プリセットの1項目を、現在のUIから読み取ります。
     *
     * @param {Object} dialogUI - buildDialog() が返すUI参照。
     * @param {string} key - プリセットのキー。
     * @returns {string|boolean} 読み取った値。
     */
    function readPresetValue(dialogUI, key) {
        var presetField = PRESET_FIELDS[key];
        if (presetField.kind === "method") return getLineMethod(dialogUI);
        if (presetField.kind === "check") return dialogUI[presetField.control].value;
        return dialogUI[presetField.control].text;
    }

    /**
     * プリセットの1項目を、UIに反映します。
     *
     * @param {Object} dialogUI - buildDialog() が返すUI参照。
     * @param {string} key - プリセットのキー。
     * @param {string|boolean} value - 反映する値。
     * @returns {void}
     */
    function writePresetValue(dialogUI, key, value) {
        var presetField = PRESET_FIELDS[key];
        if (presetField.kind === "method") {
            dialogUI.methodNoneRadio.value = (value === "none");
            dialogUI.methodAutoRadio.value = (value === "auto");
            dialogUI.methodSegmentRadio.value = (value === "segment");
            dialogUI.methodEvenRadio.value = (value === "even");
            return;
        }
        if (presetField.kind === "check") {
            dialogUI[presetField.control].value = !!value;
            return;
        }
        if (presetField.kind === "scale") {
            dialogUI[presetField.control].text = parseFloat(value).toFixed(1);
            return;
        }
        dialogUI[presetField.control].text = String(value);
    }

    /**
     * 選択中のプリセットをUIに反映します。
     *
     * @param {Object} dialogUI - buildDialog() が返すUI参照。
     * @param {Object} gridContext - buildGridContext() が返すコンテキスト。
     * @returns {void}
     */
    function applyPreset(dialogUI, gridContext) {
        if (!dialogUI.presetDropdown.selection) return;
        var presetValues = PRESET_DEFINITIONS[dialogUI.presetDropdown.selection._key];
        if (!presetValues) return;

        for (var key in PRESET_FIELDS) {
            if (PRESET_FIELDS.hasOwnProperty(key)) {
                writePresetValue(dialogUI, key, presetValues[key]);
            }
        }

        updateClearSpaceState(dialogUI);
        refreshPreview(dialogUI, gridContext);
    }

    /**
     * プリセットの値を、定義に貼り付けられる表記にします。
     *
     * @param {string|boolean} value - プリセットの値。
     * @returns {string} 表記した値。
     */
    function formatPresetValue(value) {
        return (typeof value === "string") ? ('"' + value + '"') : String(value);
    }

    /**
     * 現在の設定を、プリセット定義に貼り付けられる形の文字列にします。
     *
     * @param {Object} dialogUI - buildDialog() が返すUI参照。
     * @param {string} presetName - プリセット名。
     * @returns {string} 書き出す文字列。
     */
    function buildPresetSnippet(dialogUI, presetName) {
        var snippetLines = ['                "' + presetName + '": {'];

        for (var i = 0; i < PRESET_FIELD_ROWS.length; i++) {
            var fieldRow = PRESET_FIELD_ROWS[i];
            var rowParts = [];
            for (var j = 0; j < fieldRow.length; j++) {
                rowParts.push(fieldRow[j] + ": " + formatPresetValue(readPresetValue(dialogUI, fieldRow[j])));
            }
            var isLastRow = (i === PRESET_FIELD_ROWS.length - 1);
            snippetLines.push("                    " + rowParts.join(", ") + (isLastRow ? "" : ","));
        }

        snippetLines.push("                },");
        return snippetLines.join("\n");
    }

    /**
     * 現在の設定をプリセットとしてデスクトップに書き出します。
     *
     * @param {Object} dialogUI - buildDialog() が返すUI参照。
     * @returns {void}
     */
    function exportPreset(dialogUI) {
        var presetName = prompt(getLabel(LABELS.prompt.presetName), "");
        if (!presetName) return;

        var fileName = presetName.replace(/[\\\/:*?"<>|]/g, "_") + ".json";
        var presetFile = new File(Folder.desktop + "/" + fileName);
        presetFile.encoding = "UTF-8";
        if (!presetFile.open("w")) {
            alert(getLabel(LABELS.alert.exportFailed));
            return;
        }
        presetFile.write(buildPresetSnippet(dialogUI, presetName));
        presetFile.close();
        alert(getLabel(LABELS.alert.exported) + presetFile.fsName);
    }

    // ダイアログの位置と不透明度（再利用パーツ） / Dialog position and opacity (reusable)

    var DIALOG_OPACITY = 0.98;       /* ダイアログの不透明度 / dialog opacity */
    var DIALOG_AVOID_MARGIN = 60;    /* 選択範囲の推定位置の両側に取る余裕（px）/ margin on each side of the estimated selection (px) */
    var DIALOG_AVOID_MAX_ITEMS = 100; /* 選択範囲を測るオブジェクトの上限 / max items measured for the selection bounds */

    /**
     * ダイアログの不透明度を設定し、前回閉じた位置で開いて、動かした位置を記録するようにする。
     * 開く位置が選択中のオブジェクトに重なりそうなときは、左右の反対側へずらす（Illustrator のみ）。
     * 既存の onShow / onMove / onClose は先に呼んでから、位置の復元・記録を行う。
     * @param {Window} dialog - 対象のダイアログ
     * @param {string} storageKey - 位置を覚えるキー（ふつうは SCRIPT_NAME）
     * @returns {void}
     */
    function prepareDialogWindow(dialog, storageKey) {
        /* 同じダイアログを開き直すときは、選択範囲を測り直すだけにする（ハンドラーを重ねない）
           When the same dialog is shown again, only re-measure the selection (don't stack handlers) */
        if (dialog.dialogWindowState) {
            dialog.dialogWindowState.selectionSpan = getSelectionViewSpan();
            dialog.dialogWindowState.avoidedLocation = null;
            return;
        }
        var locationKey = "__" + storageKey + "_DialogLocation";
        var previousOnShow = dialog.onShow;
        var previousOnMove = dialog.onMove;
        var previousOnClose = dialog.onClose;
        var windowState = {
            selectionSpan: getSelectionViewSpan(), /* 選択範囲は show() の前に測る / measured before show() */
            screenWidth: null,                     /* 最初に開いたときに推定する / estimated on the first show */
            avoidedLocation: null                  /* 避けるためにずらした位置（記録しない）/ location set to avoid the selection (not remembered) */
        };
        dialog.dialogWindowState = windowState;

        dialog.opacity = DIALOG_OPACITY;

        /* 今の位置を記録する / Remember the current location */
        function rememberDialogLocation() {
            var currentLocation = [dialog.location[0], dialog.location[1]];
            var avoidedLocation = windowState.avoidedLocation;
            if (avoidedLocation && currentLocation[0] === avoidedLocation[0] && currentLocation[1] === avoidedLocation[1]) return;
            $.global[locationKey] = currentLocation;
        }

        dialog.onShow = function () {
            /* 最初に開くときの既定の位置は画面の横中央なので、画面の幅を逆算できる。2回目からは前回の位置なので使い回す
               On the first show the default location is centered horizontally, which gives the screen width; reuse it afterwards */
            if (windowState.screenWidth === null) windowState.screenWidth = dialog.location[0] * 2 + dialog.bounds.width;
            if (previousOnShow) previousOnShow.apply(this, arguments);
            /* $.screens は実際の画面の大きさと合わない（Mac で 1280×524 など）ので、画面内かは判定しない
               $.screens does not match the real display (e.g. 1280x524 on a Mac), so no on-screen check */
            var savedLocation = $.global[locationKey];
            if (savedLocation) dialog.location = [savedLocation[0], savedLocation[1]];
            if (windowState.selectionSpan) {
                var avoidLeft = findDialogLeftAvoidingSelection(dialog.location[0], dialog.bounds.width, windowState.screenWidth, windowState.selectionSpan);
                if (avoidLeft !== null) {
                    dialog.location = [avoidLeft, dialog.location[1]];
                    /* 代入後の値で比べる（丸められることがある）/ Compare with the value after assignment, which may be rounded */
                    windowState.avoidedLocation = [dialog.location[0], dialog.location[1]];
                }
            }
        };
        dialog.onMove = function () {
            if (previousOnMove) previousOnMove.apply(this, arguments);
            rememberDialogLocation();
        };
        dialog.onClose = function () {
            rememberDialogLocation();
            /* false を返すと閉じるのを取りやめるので、戻り値は元の onClose のものを返す
               Returning false cancels the close, so pass the original onClose result through */
            if (previousOnClose) return previousOnClose.apply(this, arguments);
        };
    }

    /**
     * 選択中のオブジェクトが、ドキュメントの表示域の左端から画面上で何 px の範囲にあるかを返す。
     * @returns {{left: number, right: number, viewWidth: number}|null} 選択が無い・測れないときは null
     */
    function getSelectionViewSpan() {
        try {
            if (app.name !== "Adobe Illustrator" || !app.documents.length) return null;
            var targetDoc = app.activeDocument;
            var selectedItems = targetDoc.selection;
            /* 文字ツールで文字を選択しているときは TextRange が返り、[0] が無い / Selecting characters with the Type tool returns a TextRange, which has no [0] */
            if (!selectedItems || selectedItems.typename === "TextRange" || !selectedItems.length || !selectedItems[0].visibleBounds) return null;
            var itemCount = Math.min(selectedItems.length, DIALOG_AVOID_MAX_ITEMS);
            var spanLeft = Infinity;
            var spanRight = -Infinity;
            for (var i = 0; i < itemCount; i++) {
                var itemBounds = selectedItems[i].visibleBounds;
                if (itemBounds[0] < spanLeft) spanLeft = itemBounds[0];
                if (itemBounds[2] > spanRight) spanRight = itemBounds[2];
            }
            var activeView = targetDoc.activeView; /* 複数ウィンドウで開いていても今のウィンドウ / the current window even with multiple windows */
            var viewBounds = activeView.bounds;
            var zoom = activeView.zoom;
            var viewWidth = (viewBounds[2] - viewBounds[0]) * zoom;
            /* 表示域の外にはみ出した部分は数えない / Ignore the part outside the view */
            var left = Math.max(0, (spanLeft - viewBounds[0]) * zoom);
            var right = Math.min(viewWidth, (spanRight - viewBounds[0]) * zoom);
            if (right <= left) return null;
            return { left: left, right: right, viewWidth: viewWidth };
        } catch (e) {
            /* テキスト編集中など測れないときは避けない / Do not avoid when it cannot be measured, e.g. while editing text */
            return null;
        }
    }

    /**
     * ダイアログが選択範囲に重なるなら、重ならない左端の位置を返す。
     * 表示域は画面の横中央にあるとみなし、ずれは DIALOG_AVOID_MARGIN で吸収する。
     * @param {number} dialogLeft - 今のダイアログの左端
     * @param {number} dialogWidth - ダイアログの幅
     * @param {number} screenWidth - 画面の幅
     * @param {{left: number, right: number, viewWidth: number}} selectionSpan - getSelectionViewSpan() の結果
     * @returns {number|null} ずらした左端。重ならない・どちらにも収まらないときは null
     */
    function findDialogLeftAvoidingSelection(dialogLeft, dialogWidth, screenWidth, selectionSpan) {
        var viewLeft = (screenWidth - selectionSpan.viewWidth) / 2;
        var avoidLeft = viewLeft + selectionSpan.left - DIALOG_AVOID_MARGIN;
        var avoidRight = viewLeft + selectionSpan.right + DIALOG_AVOID_MARGIN;
        if (dialogLeft + dialogWidth <= avoidLeft || dialogLeft >= avoidRight) return null;

        var leftSideLeft = avoidLeft - dialogWidth;   /* 選択範囲の左に置くとき / placed left of the selection */
        var rightSideLeft = avoidRight;               /* 選択範囲の右に置くとき / placed right of the selection */
        var fitsLeft = leftSideLeft >= 0;
        var fitsRight = rightSideLeft + dialogWidth <= screenWidth;
        /* 選択範囲が画面の右寄りなら左へ、左寄りなら右へ逃がす / Move away from the side the selection leans to */
        var preferLeft = (avoidLeft + avoidRight) / 2 > screenWidth / 2;
        if (preferLeft && fitsLeft) return leftSideLeft;
        if (fitsRight) return rightSideLeft;
        if (fitsLeft) return leftSideLeft;
        return null;
    }

    // ダイアログの位置と不透明度（再利用パーツ）ここまで / End of the reusable dialog position and opacity

    // ボタン行（再利用パーツ） / Button row (reusable)

    var BUTTON_ROW_TOP_MARGIN = 5; /* ボタン行の上の余白 / top margin of the button row */
    var BUTTON_ROW_BOTTOM_MARGIN = 14; /* ボタン行の下の余白。ダイアログの下余白と合わせて約30px（Illustrator 標準のダイアログに合わせる） / bottom margin; with the dialog margin about 30px, like Illustrator's own dialogs */
    var BUTTON_ROW_SPACING = 10;   /* ボタンどうしの間隔 / spacing between buttons */
    var BUTTON_ROW_CENTER_MAX_WIDTH = 240; /* 右のボタンだけの行を中央に置く、ダイアログの内側の最大幅（px、左右の余白を除く）。広いダイアログは右揃え / max inner dialog width (px, margins excluded) that centers a right-only row; wider dialogs keep it right-aligned */

    /**
     * ダイアログ下部のボタン行を作る。
     * 通常は「左のグループ・伸びるスペーサー・右のグループ」、centered なら行そのものを左右中央に置く
     * @param {Window|Group|Panel} parent - 行を足す先（ふつうはダイアログ）
     * @param {Object} [rowOptions] - { centered: true } で左右中央に並べる
     * @returns {{rowGroup: Group, leftGroup: Group|null, rightGroup: Group|null}} 行と左右のグループ（centered のときは左右が null）
     */
    function addButtonRow(parent, rowOptions) {
        var isCentered = !!(rowOptions && rowOptions.centered);
        var btnRowGroup = parent.add("group");
        btnRowGroup.orientation = "row";
        btnRowGroup.margins = [0, BUTTON_ROW_TOP_MARGIN, 0, BUTTON_ROW_BOTTOM_MARGIN];
        btnRowGroup.spacing = BUTTON_ROW_SPACING;

        if (isCentered) {
            btnRowGroup.alignment = ["center", "bottom"];
            btnRowGroup.alignChildren = ["center", "center"];
            return { rowGroup: btnRowGroup, leftGroup: null, rightGroup: null };
        }

        btnRowGroup.alignment = ["fill", "bottom"];

        var btnLeftGroup = btnRowGroup.add("group");
        btnLeftGroup.alignChildren = ["left", "center"];
        btnLeftGroup.spacing = BUTTON_ROW_SPACING;

        /* 余りの幅を吸って、右のグループを右端に寄せる / Absorbs the extra width so the right group sits at the right edge */
        var spacer = btnRowGroup.add("group");
        spacer.alignment = ["fill", "fill"];
        spacer.minimumSize.width = 0;

        var btnRightGroup = btnRowGroup.add("group");
        btnRightGroup.alignChildren = ["right", "center"];
        btnRightGroup.spacing = BUTTON_ROW_SPACING;

        return { rowGroup: btnRowGroup, leftGroup: btnLeftGroup, rightGroup: btnRightGroup };
    }

    /**
     * 左のグループにボタンが無い（右のボタンだけの）行を、ダイアログの幅に合わせて揃える。
     * 内側の幅（左右の余白を除く）が BUTTON_ROW_CENTER_MAX_WIDTH 以下なら左右中央、それより広ければ右揃えのまま。
     * 幅はレイアウトが決まるまで分からないので、ダイアログを表示した時点（show イベント）で判定する。
     * ボタンをすべて足したあと、show() の前に呼ぶ。centered で作った行や、左にボタンがある行はそのまま
     * @param {{rowGroup: Group, leftGroup: Group|null, rightGroup: Group|null}} buttonRow - addButtonRow() の戻り値
     * @returns {void}
     */
    function alignRightOnlyButtonRow(buttonRow) {
        if (!buttonRow.leftGroup || buttonRow.leftGroup.children.length > 0) return;
        var dialogWindow = buttonRow.rowGroup.window;
        dialogWindow.addEventListener("show", function () {
            if (!buttonRow.leftGroup) return;
            var btnRowGroup = buttonRow.rowGroup;
            /* 行の幅＝ダイアログの内側の幅（左右の余白を除く）/ The row spans the dialog's inner width (margins excluded) */
            if (!btnRowGroup.size || btnRowGroup.size.width > BUTTON_ROW_CENTER_MAX_WIDTH) return;
            /* 左のグループとスペーサーを外し、右のグループだけを中央に置く / Drop the left group and the spacer so only the right group remains, centered */
            btnRowGroup.remove(buttonRow.leftGroup);
            btnRowGroup.remove(btnRowGroup.children[0]); /* 左のグループを外すと先頭はスペーサー / the spacer is first once the left group is gone */
            btnRowGroup.alignment = ["center", "bottom"];
            btnRowGroup.alignChildren = ["center", "center"];
            buttonRow.leftGroup = null;
            dialogWindow.layout.layout(true);
        });
    }

    // ボタン行（再利用パーツ）ここまで / End of the reusable button row

    // =========================================
    // ダイアログ / Dialog
    // =========================================

    /**
     * 共通設定のパネルを追加し、子要素の横方向の揃えを指定します。
     *
     * @param {Object} parentGroup - 追加先のコンテナ。
     * @param {Object} titleLabel - パネル名のラベル。
     * @param {string} [horizontalAlign] - 子要素の横方向の揃え（省略時は "left"）。
     * @param {number} [spacing] - 要素間隔（省略時は PANEL_SPACING）。
     * @returns {Panel} 追加したパネル。
     */
    function addDialogPanel(parentGroup, titleLabel, horizontalAlign, spacing) {
        var targetPanel = parentGroup.add("panel", undefined, getLabel(titleLabel));
        setupPanel(targetPanel, spacing);
        targetPanel.alignChildren = [horizontalAlign || "left", "top"];
        return targetPanel;
    }

    /**
     * 行グループを作成します（横並び・左揃え・天地中央）。
     *
     * @param {Object} parentGroup - 追加先のコンテナ。
     * @returns {Group} 作成した行グループ。
     */
    function addRow(parentGroup) {
        var rowGroup = parentGroup.add("group");
        rowGroup.orientation = "row";
        rowGroup.alignment = ["left", "top"];
        rowGroup.alignChildren = ["left", "center"];
        return rowGroup;
    }

    /**
     * 縦並びのカラム用グループを作成します。
     *
     * @param {Group} parentGroup - 追加先のグループ。
     * @param {string} horizontalAlign - 子要素の横方向の揃え。
     * @returns {Group} 作成したカラム。
     */
    function addColumn(parentGroup, horizontalAlign) {
        var columnGroup = parentGroup.add("group");
        columnGroup.orientation = "column";
        columnGroup.alignChildren = [horizontalAlign, "top"];
        return columnGroup;
    }

    /**
     * カラムを横に並べるグループを作成します。
     *
     * @param {Object} parentGroup - 追加先のコンテナ。
     * @returns {Group} 作成したグループ。
     */
    function addColumnsGroup(parentGroup) {
        var columnsGroup = parentGroup.add("group");
        columnsGroup.orientation = "row";
        columnsGroup.alignChildren = ["fill", "top"];
        columnsGroup.spacing = COLUMN_SPACING;
        return columnsGroup;
    }

    /**
     * tooltip 付きのチェックボックスを追加します。
     *
     * @param {Object} parentGroup - 追加先のコンテナ。
     * @param {Object} labelSet - 表示名のラベル。
     * @param {Object} tooltipSet - tooltip のラベル。
     * @param {boolean} initialValue - 初期値。
     * @returns {Checkbox} 追加したチェックボックス。
     */
    function addCheckbox(parentGroup, labelSet, tooltipSet, initialValue) {
        var newCheckbox = parentGroup.add("checkbox", undefined, getLabel(labelSet));
        newCheckbox.value = initialValue;
        newCheckbox.helpTip = getLabel(tooltipSet);
        return newCheckbox;
    }

    /**
     * tooltip 付きのラジオボタンを追加します。
     *
     * @param {Object} parentGroup - 追加先のコンテナ。
     * @param {Object} labelSet - 表示名のラベル。
     * @param {Object} tooltipSet - tooltip のラベル。
     * @returns {RadioButton} 追加したラジオボタン。
     */
    function addRadio(parentGroup, labelSet, tooltipSet) {
        var newRadio = parentGroup.add("radiobutton", undefined, getLabel(labelSet));
        newRadio.helpTip = getLabel(tooltipSet);
        return newRadio;
    }

    /**
     * tooltip 付きの入力欄を追加します。
     *
     * @param {Object} parentGroup - 追加先のコンテナ。
     * @param {string} initialText - 初期値。
     * @param {number} characters - 入力欄の幅（文字数）。
     * @param {Object} tooltipSet - tooltip のラベル。
     * @param {Object} [stepOptions] - 指定すると入力欄の左に∧∨を置く（min / integer など。addStepper() に渡す）。
     *     増減後の処理は、あとから入力欄の onStepped に設定します。
     * @returns {EditText} 追加した入力欄（∧∨は .stepperGroup で参照できます）。
     */
    function addInput(parentGroup, initialText, characters, tooltipSet, stepOptions) {
        if (!stepOptions) {
            var plainInput = parentGroup.add("edittext", undefined, initialText);
            plainInput.characters = characters;
            plainInput.helpTip = getLabel(tooltipSet);
            return plainInput;
        }

        /* ∧∨と入力欄は隙間0で突き合わせる / butt the stepper against the field */
        var stepperInputGroup = parentGroup.add("group");
        stepperInputGroup.orientation = "row";
        stepperInputGroup.alignChildren = ["left", "center"];
        stepperInputGroup.spacing = 0;
        stepperInputGroup.margins = 0;

        var inputField;
        /* 増減後の処理はイベント設定時に onStepped へ入れる / the follow-up is set later as onStepped */
        stepOptions.onStep = function (numberInput) {
            if (numberInput.onStepped) numberInput.onStepped();
        };
        var stepperGroup = addStepper(stepperInputGroup, function () { return inputField; }, stepOptions);
        inputField = stepperInputGroup.add("edittext", undefined, initialText);
        inputField.characters = characters;
        inputField.helpTip = getLabel(tooltipSet);
        inputField.stepperGroup = stepperGroup;
        bindSteppedArrowKeys(inputField, stepperGroup);
        return inputField;
    }

    /**
     * 入力欄の使用可否を、∧∨のディム表示とあわせて切り替えます。
     *
     * @param {EditText} inputField - addInput() で作った入力欄。
     * @param {boolean} isEnabled - 使用可にするとき true。
     * @returns {void}
     */
    function setInputEnabled(inputField, isEnabled) {
        inputField.enabled = isEnabled;
        if (!inputField.stepperGroup) return;
        inputField.stepperGroup.enabled = isEnabled;
        redrawSteppersIn(inputField.stepperGroup);
    }

    /**
     * 「項目名：入力欄［単位］」の行を追加します。
     *
     * @param {Object} parentGroup - 追加先のコンテナ。
     * @param {Object} labelSet - 項目名のラベル。
     * @param {string} initialText - 初期値。
     * @param {number} characters - 入力欄の幅（文字数）。
     * @param {Object} tooltipSet - tooltip のラベル。
     * @param {string} [unitText] - 入力欄の後ろに置く単位。
     * @param {Object} [stepOptions] - ∧∨の設定（addInput() に渡す）。
     * @returns {EditText} 追加した入力欄。
     */
    function addLabeledInput(parentGroup, labelSet, initialText, characters, tooltipSet, unitText, stepOptions) {
        var rowGroup = addRow(parentGroup);
        rowGroup.add("statictext", undefined, labelText(labelSet));
        var inputField = addInput(rowGroup, initialText, characters, tooltipSet, stepOptions);
        if (unitText) rowGroup.add("statictext", undefined, unitText);
        return inputField;
    }

    /**
     * プリセットの選択と書き出しの行を作成します。
     *
     * @param {Window} gridDialog - ダイアログ。
     * @param {Object} dialogUI - コントロールへの参照を書き込む先。
     * @returns {void}
     */
    function addPresetRow(gridDialog, dialogUI) {
        var presetRow = gridDialog.add("group");
        presetRow.orientation = "row";
        presetRow.alignment = ["center", "top"];
        presetRow.alignChildren = ["left", "center"];
        presetRow.add("statictext", undefined, labelText(LABELS.fieldLabel.preset));

        var presetDropdown = presetRow.add("dropdownlist");
        presetDropdown.helpTip = getLabel(LABELS.tooltip.preset);
        var autoIndex = 0;
        for (var presetKey in PRESET_DEFINITIONS) {
            if (!PRESET_DEFINITIONS.hasOwnProperty(presetKey)) continue;
            if (presetKey === "auto") autoIndex = presetDropdown.items.length;
            presetDropdown.add("item", presetKey)._key = presetKey;
        }
        presetDropdown.selection = autoIndex;

        var btnExport = presetRow.add("button", undefined, getLabel(LABELS.button.exportPreset));
        btnExport.helpTip = getLabel(LABELS.tooltip.exportPreset);

        dialogUI.presetDropdown = presetDropdown;
        dialogUI.btnExport = btnExport;
    }

    /**
     * ［共通設定とクリアスペース］パネルを作成します。
     *
     * @param {Window} gridDialog - ダイアログ。
     * @param {Object} dialogUI - コントロールへの参照を書き込む先。
     * @returns {void}
     */
    function addCommonPanel(gridDialog, dialogUI) {
        var commonPanel = addDialogPanel(gridDialog, LABELS.panel.common, "fill");
        var commonColumns = addColumnsGroup(commonPanel);
        var commonLeftColumn = addColumn(commonColumns, "left");
        var commonRightColumn = addColumn(commonColumns, "left");

        /* 左：分割数・クリアスペース・ガイド化 / Left: divisions, clear space, guides */
        dialogUI.clearSpaceDivInput = addLabeledInput(commonLeftColumn, LABELS.fieldLabel.divisions, "4",
            FIELD_WIDTH.count, LABELS.tooltip.divisions, "", { min: 0 });
        dialogUI.clearSpaceCheck = addCheckbox(addRow(commonLeftColumn),
            LABELS.checkbox.clearSpace, LABELS.tooltip.clearSpace, false);
        dialogUI.convertToGuidesCheck = addCheckbox(addRow(commonLeftColumn),
            LABELS.checkbox.convertToGuides, LABELS.tooltip.convertToGuides, false);

        /* 右：線幅・境界線の強調・グループ化 / Right: stroke width, emphasized bounds, grouping */
        dialogUI.strokeWidthInput = addLabeledInput(commonRightColumn, LABELS.fieldLabel.strokeWidth, "0.25",
            FIELD_WIDTH.strokeWidth, LABELS.tooltip.strokeWidth, getUnitInfo("strokeUnits").label, { min: 0 });
        dialogUI.emphasizeBoundsCheck = addCheckbox(addRow(commonRightColumn),
            LABELS.checkbox.emphasizeBounds, LABELS.tooltip.emphasizeBounds, false);
        dialogUI.groupItemsCheck = addCheckbox(addRow(commonRightColumn),
            LABELS.checkbox.groupItems, LABELS.tooltip.groupItems, true);

        dialogUI.layerNameInput = addLabeledInput(commonPanel, LABELS.fieldLabel.targetLayer, getLabel(LABELS.itemName.layer),
            FIELD_WIDTH.layerName, LABELS.tooltip.targetLayer);
    }

    /**
     * ［横線］パネル（［ラインの決め方］を含む）を作成します。
     *
     * @param {Group} parentColumn - 追加先のカラム。
     * @param {Object} dialogUI - コントロールへの参照を書き込む先。
     * @returns {void}
     */
    function addHorizontalPanel(parentColumn, dialogUI) {
        var horizontalPanel = addDialogPanel(parentColumn, LABELS.panel.horizontal, "left", 6);
        dialogUI.horizontalPanel = horizontalPanel;

        dialogUI.widthScaleInput = addLabeledInput(horizontalPanel, LABELS.fieldLabel.widthScale, "140",
            FIELD_WIDTH.scale, LABELS.tooltip.widthScale, "%", { min: 0 });

        var extraHLinesRow = addRow(horizontalPanel);
        dialogUI.extraHLinesCheck = addCheckbox(extraHLinesRow,
            LABELS.checkbox.extraHorizontal, LABELS.tooltip.extraHorizontal, false);
        dialogUI.extraHLinesInput = addInput(extraHLinesRow, "1", FIELD_WIDTH.count, LABELS.tooltip.extraHorizontal, { min: 1, integer: true });

        dialogUI.extendLeftCheck = addCheckbox(addRow(horizontalPanel),
            LABELS.checkbox.extendLeft, LABELS.tooltip.extendLeft, false);

        /* ラインの決め方 / Line generation method */
        var lineMethodPanel = addDialogPanel(horizontalPanel, LABELS.panel.lineMethod, "left", 6);
        lineMethodPanel.helpTip = getLabel(LABELS.tooltip.lineMethod);

        dialogUI.methodNoneRadio = addRadio(lineMethodPanel, LABELS.radio.lineNone, LABELS.tooltip.lineNone);
        dialogUI.methodAutoRadio = addRadio(lineMethodPanel, LABELS.radio.lineAuto, LABELS.tooltip.lineAuto);
        dialogUI.methodAutoRadio.value = true;
        dialogUI.methodSegmentRadio = addRadio(lineMethodPanel, LABELS.radio.lineSegment, LABELS.tooltip.lineSegment);

        var evenLineCountRow = addRow(lineMethodPanel);
        dialogUI.methodEvenRadio = addRadio(evenLineCountRow, LABELS.radio.lineEven, LABELS.tooltip.lineEven);
        dialogUI.evenLineCountInput = addInput(evenLineCountRow, "4", FIELD_WIDTH.count, LABELS.tooltip.lineEven, { min: 1, integer: true });
        evenLineCountRow.add("statictext", undefined, getLabel(LABELS.unit.lines));
    }

    /**
     * ［縦線］パネル（［オプション］を含む）を作成します。
     *
     * @param {Group} parentColumn - 追加先のカラム。
     * @param {Object} dialogUI - コントロールへの参照を書き込む先。
     * @returns {void}
     */
    function addVerticalPanel(parentColumn, dialogUI) {
        var verticalPanel = addDialogPanel(parentColumn, LABELS.panel.vertical, "left", 6);
        dialogUI.verticalPanel = verticalPanel;

        dialogUI.heightScaleInput = addLabeledInput(verticalPanel, LABELS.fieldLabel.heightScale, "200",
            FIELD_WIDTH.scale, LABELS.tooltip.heightScale, "%", { min: 0 });

        var outerVLinesRow = addRow(verticalPanel);
        dialogUI.outerVLinesCheck = addCheckbox(outerVLinesRow,
            LABELS.checkbox.outerVertical, LABELS.tooltip.outerVertical, false);
        dialogUI.outerVLinesInput = addInput(outerVLinesRow, "1", FIELD_WIDTH.count, LABELS.tooltip.outerVertical, { min: 1, integer: true });

        dialogUI.extendUpCheck = addCheckbox(addRow(verticalPanel),
            LABELS.checkbox.extendUp, LABELS.tooltip.extendUp, false);

        /* オプション / Options */
        var verticalOptionsPanel = addDialogPanel(verticalPanel, LABELS.panel.options, "left", 6);

        var columnDivRow = addRow(verticalOptionsPanel);
        dialogUI.columnDivCheck = addCheckbox(columnDivRow, LABELS.checkbox.columnDiv, LABELS.tooltip.columnDiv, false);
        dialogUI.columnDivInput = addInput(columnDivRow, "2", FIELD_WIDTH.count, LABELS.tooltip.columnDiv, { min: 1, integer: true });
        setInputEnabled(dialogUI.columnDivInput, false);

        dialogUI.verticalElementsCheck = addCheckbox(addRow(verticalOptionsPanel),
            LABELS.checkbox.verticalElements, LABELS.tooltip.verticalElements, false);
        dialogUI.diagonalElementsCheck = addCheckbox(addRow(verticalOptionsPanel),
            LABELS.checkbox.diagonalElements, LABELS.tooltip.diagonalElements, false);
    }

    /**
     * 設定用のダイアログを作成します。
     *
     * @returns {Object} ダイアログ（dialog）と各コントロールへの参照。
     */
    function buildDialog() {
        var gridDialog = new Window("dialog", getLabel(LABELS.dialog.title) + " " + SCRIPT_VERSION);
        setupWindow(gridDialog);

        var dialogUI = { dialog: gridDialog };
        addPresetRow(gridDialog, dialogUI);
        addCommonPanel(gridDialog, dialogUI);

        /* 横線・縦線の2カラム / Two columns for the horizontal and vertical lines */
        var panelColumns = addColumnsGroup(gridDialog);
        addHorizontalPanel(addColumn(panelColumns, "fill"), dialogUI);
        addVerticalPanel(addColumn(panelColumns, "fill"), dialogUI);

        /* ボタン行（左：プレビュー／右：キャンセル・OK）/ Button row: preview on the left, Cancel/OK on the right */
        var buttonRow = addButtonRow(gridDialog);
        dialogUI.previewCheck = addCheckbox(buttonRow.leftGroup, LABELS.checkbox.preview, LABELS.tooltip.preview, true);
        var btnCancel = buttonRow.rightGroup.add("button", undefined, getLabel(LABELS.button.cancel), { name: "cancel" });
        var btnOK = buttonRow.rightGroup.add("button", undefined, getLabel(LABELS.button.ok), { name: "ok" });
        dialogUI.btnCancel = btnCancel;
        dialogUI.btnOK = btnOK;
        return dialogUI;
    }

    // =========================================
    // UIの状態 / UI state
    // =========================================

    /**
     * ［グループ化］の使用可否を、［ガイドに変換する］に合わせます。
     *
     * @param {Object} dialogUI - buildDialog() が返すUI参照。
     * @returns {void}
     */
    function updateGroupState(dialogUI) {
        dialogUI.groupItemsCheck.enabled = !dialogUI.convertToGuidesCheck.value;
        if (dialogUI.convertToGuidesCheck.value) dialogUI.groupItemsCheck.value = false;
    }

    /**
     * ［均等分割］の本数入力の使用可否を更新します。
     *
     * @param {Object} dialogUI - buildDialog() が返すUI参照。
     * @returns {void}
     */
    function updateColumnDivField(dialogUI) {
        setInputEnabled(dialogUI.columnDivInput, dialogUI.columnDivCheck.enabled && dialogUI.columnDivCheck.value);
    }

    /**
     * ［分割数］の値と使用可否を、横線の均等分割に合わせます。
     *
     * @param {Object} dialogUI - buildDialog() が返すUI参照。
     * @returns {void}
     */
    function updateClearSpaceDivField(dialogUI) {
        var evenMode = dialogUI.methodEvenRadio.value;
        var evenCount = parseInt(dialogUI.evenLineCountInput.text, 10);

        /* 均等分割の本数＋1がユニット数になる / The unit count follows the even division count */
        if (evenMode && !isNaN(evenCount) && evenCount >= 1) {
            dialogUI.clearSpaceDivInput.text = String(evenCount + 1);
        }
        setInputEnabled(dialogUI.clearSpaceDivInput, dialogUI.clearSpaceCheck.value || !evenMode);
    }

    /**
     * 分割にかかわる入力欄の状態をまとめて更新します。
     *
     * @param {Object} dialogUI - buildDialog() が返すUI参照。
     * @returns {void}
     */
    function syncDivisionFields(dialogUI) {
        updateColumnDivField(dialogUI);
        updateClearSpaceDivField(dialogUI);
    }

    /**
     * ［クリアスペース］の状態に合わせて、横線・縦線パネルなどの使用可否を更新します。
     *
     * @param {Object} dialogUI - buildDialog() が返すUI参照。
     * @returns {void}
     */
    function updateClearSpaceState(dialogUI) {
        var clearSpace = dialogUI.clearSpaceCheck.value;

        /* 横線・縦線はパネルごとディム / Dim the whole horizontal and vertical panels */
        dialogUI.horizontalPanel.enabled = !clearSpace;
        dialogUI.verticalPanel.enabled = !clearSpace;
        redrawSteppersIn(dialogUI.horizontalPanel); /* ∧∨のディム表示を描き直す / redraw the steppers' dimming */
        redrawSteppersIn(dialogUI.verticalPanel);
        setInputEnabled(dialogUI.extraHLinesInput, !clearSpace && dialogUI.extraHLinesCheck.value);
        setInputEnabled(dialogUI.evenLineCountInput, !clearSpace && dialogUI.methodEvenRadio.value);
        setInputEnabled(dialogUI.outerVLinesInput, !clearSpace && dialogUI.outerVLinesCheck.value);
        setInputEnabled(dialogUI.columnDivInput, !clearSpace && dialogUI.columnDivCheck.value);

        /* クリアスペース中は線幅とガイド化を使わず、グループ化はON固定 */
        setInputEnabled(dialogUI.strokeWidthInput, !clearSpace);
        dialogUI.convertToGuidesCheck.enabled = !clearSpace;
        if (clearSpace) {
            dialogUI.convertToGuidesCheck.value = false;
            dialogUI.groupItemsCheck.value = true;
            dialogUI.groupItemsCheck.enabled = false;
        } else {
            updateGroupState(dialogUI);
        }

        syncDivisionFields(dialogUI);
    }

    // =========================================
    // 入力値 / Parameters
    // =========================================

    /**
     * 伸張率の入力欄か判定します（小数第1位で表示する欄）。
     *
     * @param {Object} dialogUI - buildDialog() が返すUI参照。
     * @param {EditText} inputField - 対象の入力欄。
     * @returns {boolean} 伸張率の入力欄のとき true。
     */
    function isScaleField(dialogUI, inputField) {
        return inputField === dialogUI.widthScaleInput || inputField === dialogUI.heightScaleInput;
    }

    /**
     * 正の数として扱える入力か判定します。
     *
     * @param {string} inputText - 入力された文字列。
     * @returns {boolean} 正の数のとき true。
     */
    function isPositiveNumberText(inputText) {
        return /^\d+(?:\.\d+)?$/.test(inputText) && parseFloat(inputText) > 0;
    }

    /**
     * 1以上の整数として扱える入力か判定します。
     *
     * @param {string} inputText - 入力された文字列。
     * @returns {boolean} 1以上の整数のとき true。
     */
    function isCountText(inputText) {
        return /^\d+$/.test(inputText) && parseInt(inputText, 10) >= 1;
    }

    /**
     * ダイアログの入力内容をそのまま読み取ります。
     *
     * @param {Object} dialogUI - buildDialog() が返すUI参照。
     * @returns {Object} 入力内容。
     */
    function readDialogValues(dialogUI) {
        return {
            layerName: normalizeLayerNameText(dialogUI.layerNameInput.text),
            widthScaleText: dialogUI.widthScaleInput.text,
            heightScaleText: dialogUI.heightScaleInput.text,
            strokeWidthText: dialogUI.strokeWidthInput.text,
            lineMethod: getLineMethod(dialogUI),
            evenLineCountText: dialogUI.evenLineCountInput.text,
            extraHLines: dialogUI.extraHLinesCheck.value,
            extraHLineCountText: dialogUI.extraHLinesInput.text,
            extendLeft: dialogUI.extendLeftCheck.value,
            outerVLines: dialogUI.outerVLinesCheck.value,
            outerVLineCountText: dialogUI.outerVLinesInput.text,
            extendUp: dialogUI.extendUpCheck.value,
            columnDiv: dialogUI.columnDivCheck.value,
            columnDivisionsText: dialogUI.columnDivInput.text,
            verticalElements: dialogUI.verticalElementsCheck.value,
            diagonalElements: dialogUI.diagonalElementsCheck.value,
            emphasizeBounds: dialogUI.emphasizeBoundsCheck.value,
            convertToGuides: dialogUI.convertToGuidesCheck.value,
            groupItems: dialogUI.groupItemsCheck.value,
            clearSpace: dialogUI.clearSpaceCheck.value,
            clearSpaceDivisionsText: dialogUI.clearSpaceDivInput.text
        };
    }

    /**
     * 入力内容が処理に使える値か検証します。
     *
     * @param {Object} dialogValues - readDialogValues() の結果。
     * @returns {boolean} すべて正しいとき true。
     */
    function validateDialogValues(dialogValues) {
        if (!dialogValues.layerName) return false;
        if (!isPositiveNumberText(dialogValues.widthScaleText)) return false;
        if (!isPositiveNumberText(dialogValues.heightScaleText)) return false;
        if (!isPositiveNumberText(dialogValues.strokeWidthText)) return false;
        if (!isPositiveNumberText(dialogValues.clearSpaceDivisionsText)) return false;
        if (dialogValues.lineMethod === "even" && !isCountText(dialogValues.evenLineCountText)) return false;
        if (dialogValues.extraHLines && !isCountText(dialogValues.extraHLineCountText)) return false;
        if (dialogValues.outerVLines && !isCountText(dialogValues.outerVLineCountText)) return false;
        if (dialogValues.columnDiv && !isCountText(dialogValues.columnDivisionsText)) return false;
        return true;
    }

    /**
     * 入力内容を、描画で使う単位・型に変換します。
     *
     * @param {Object} dialogValues - readDialogValues() の結果。
     * @returns {Object|null} 変換した設定。線幅を換算できないときは null。
     */
    function toGridParams(dialogValues) {
        var strokeWidth = unitToPt(parseFloat(dialogValues.strokeWidthText), getUnitInfo("strokeUnits"));
        if (!(strokeWidth > 0)) return null;

        return {
            layerName: dialogValues.layerName,
            widthScale: parseFloat(dialogValues.widthScaleText) / 100,
            heightScale: parseFloat(dialogValues.heightScaleText) / 100,
            strokeWidth: strokeWidth,
            lineMethod: dialogValues.lineMethod,
            evenLineCount: (dialogValues.lineMethod === "even") ? parseInt(dialogValues.evenLineCountText, 10) : 0,
            extraHLines: dialogValues.extraHLines,
            extraHLineCount: dialogValues.extraHLines ? parseInt(dialogValues.extraHLineCountText, 10) : 0,
            extendLeft: dialogValues.extendLeft,
            outerVLines: dialogValues.outerVLines,
            outerVLineCount: dialogValues.outerVLines ? parseInt(dialogValues.outerVLineCountText, 10) : 0,
            extendUp: dialogValues.extendUp,
            columnDiv: dialogValues.columnDiv,
            columnDivisions: dialogValues.columnDiv ? parseInt(dialogValues.columnDivisionsText, 10) : 0,
            verticalElements: dialogValues.verticalElements,
            diagonalElements: dialogValues.diagonalElements,
            emphasizeBounds: dialogValues.emphasizeBounds,
            convertToGuides: dialogValues.convertToGuides,
            groupItems: dialogValues.groupItems,
            clearSpace: dialogValues.clearSpace,
            clearSpaceDivisions: parseFloat(dialogValues.clearSpaceDivisionsText)
        };
    }

    /**
     * ダイアログの入力内容を、検証したうえで設定にまとめます。
     *
     * @param {Object} dialogUI - buildDialog() が返すUI参照。
     * @returns {Object|null} 設定。入力値が不正なときは null。
     */
    function getGridParams(dialogUI) {
        var dialogValues = readDialogValues(dialogUI);
        return validateDialogValues(dialogValues) ? toGridParams(dialogValues) : null;
    }

    // =========================================
    // 描画 / Drawing
    // =========================================

    /**
     * 補助線を描く範囲（線の長さとユニットの大きさ）を求めます。
     *
     * @param {Object} gridContext - buildGridContext() が返すコンテキスト。
     * @param {Object} gridParams - getGridParams() が返す設定。
     * @returns {{left: number, right: number, top: number, bottom: number, unitSize: number}} 描画範囲。
     */
    function computeFrame(gridContext, gridParams) {
        var unitSize = gridContext.selHeight / gridParams.clearSpaceDivisions;

        var halfWidth = gridContext.selWidth * gridParams.widthScale / 2;
        var left = gridContext.centerX - halfWidth;
        var right = gridContext.centerX + halfWidth;
        if (gridParams.extendLeft) {
            /* 右端を選択範囲の右外に固定し、余りを左へ伸ばす / Pin the right end and extend leftward */
            var shift = right - (gridContext.selRight + gridContext.selHeight / 2);
            left -= shift;
            right -= shift;
        }

        var lineHeight = gridContext.selHeight * gridParams.heightScale;
        var top, bottom;
        if (gridParams.extendUp) {
            bottom = gridContext.selBottom - unitSize * 2;
            top = bottom + lineHeight;
        } else {
            top = gridContext.centerY + lineHeight / 2;
            bottom = gridContext.centerY - lineHeight / 2;
        }

        if (!gridParams.clearSpace) {
            /* 外側に追加した線とも必ず交差するよう、線の長さを自動で補正する */
            var outerOffset = gridParams.outerVLines ? unitSize * (gridParams.outerVLineCount - 1) : 0;
            var extraOffset = gridParams.extraHLines ? unitSize * (gridParams.extraHLineCount - 1) : 0;
            left = Math.min(left, gridContext.selLeft - outerOffset);
            right = Math.max(right, gridContext.selRight + outerOffset);
            top = Math.max(top, gridContext.selTop + extraOffset);
            bottom = Math.min(bottom, gridContext.selBottom - extraOffset);
        }

        return { left: left, right: right, top: top, bottom: bottom, unitSize: unitSize };
    }

    /**
     * 直線を1本描きます。
     *
     * @param {GroupItem} targetGroup - 追加先のグループ。
     * @param {number} x1 - 始点のX座標。
     * @param {number} y1 - 始点のY座標。
     * @param {number} x2 - 終点のX座標。
     * @param {number} y2 - 終点のY座標。
     * @param {Object} strokeColor - 線のカラー。
     * @param {number} strokeWidth - 線幅（pt）。
     * @returns {PathItem} 作成したパス。
     */
    function drawLine(targetGroup, x1, y1, x2, y2, strokeColor, strokeWidth) {
        var linePath = targetGroup.pathItems.add();
        linePath.setEntirePath([[x1, y1], [x2, y2]]);
        linePath.stroked = true;
        linePath.filled = false;
        linePath.strokeWidth = strokeWidth;
        linePath.strokeColor = strokeColor;
        return linePath;
    }

    /**
     * 横線を1本描きます。
     *
     * @param {GroupItem} targetGroup - 追加先のグループ。
     * @param {Object} frame - computeFrame() が返す描画範囲。
     * @param {number} y - 描くY座標。
     * @param {Object} strokeStyle - 線のカラーと線幅。
     * @param {boolean} onBounds - 選択範囲の境界に重なるか。
     * @returns {void}
     */
    function drawHorizontalLine(targetGroup, frame, y, strokeStyle, onBounds) {
        drawLine(targetGroup, frame.left, y, frame.right, y, strokeStyle.color, onBounds ? strokeStyle.bounds : strokeStyle.normal);
    }

    /**
     * 縦線を1本描きます。
     *
     * @param {GroupItem} targetGroup - 追加先のグループ。
     * @param {Object} frame - computeFrame() が返す描画範囲。
     * @param {number} x - 描くX座標。
     * @param {Object} strokeStyle - 線のカラーと線幅。
     * @param {boolean} onBounds - 選択範囲の境界に重なるか。
     * @returns {void}
     */
    function drawVerticalLine(targetGroup, frame, x, strokeStyle, onBounds) {
        drawLine(targetGroup, x, frame.top, x, frame.bottom, strokeStyle.color, onBounds ? strokeStyle.bounds : strokeStyle.normal);
    }

    /**
     * 横線（境界線・外側の線・ラインの決め方による線）を描きます。
     *
     * @param {GroupItem} linesGroup - 追加先のグループ。
     * @param {Object} gridContext - buildGridContext() が返すコンテキスト。
     * @param {Object} gridParams - getGridParams() が返す設定。
     * @param {Object} frame - computeFrame() が返す描画範囲。
     * @param {Object} strokeStyle - 線のカラーと線幅。
     * @returns {void}
     */
    function drawHorizontalGuides(linesGroup, gridContext, gridParams, frame, strokeStyle) {
        if (gridParams.extraHLines) {
            drawHorizontalLine(linesGroup, frame, gridContext.selTop, strokeStyle, true);
            drawHorizontalLine(linesGroup, frame, gridContext.selBottom, strokeStyle, true);
            for (var i = 1; i < gridParams.extraHLineCount; i++) {
                drawHorizontalLine(linesGroup, frame, gridContext.selTop + frame.unitSize * i, strokeStyle, false);
                drawHorizontalLine(linesGroup, frame, gridContext.selBottom - frame.unitSize * i, strokeStyle, false);
            }
        }

        var lineYs = getHorizontalLineYs(gridContext.geometry, gridParams.lineMethod, gridParams.evenLineCount);
        for (var j = 0; j < lineYs.length; j++) {
            var onBounds = gridParams.emphasizeBounds &&
                (isSameCoord(lineYs[j], gridContext.selTop) || isSameCoord(lineYs[j], gridContext.selBottom));
            drawHorizontalLine(linesGroup, frame, lineYs[j], strokeStyle, onBounds);
        }
    }

    /**
     * 縦線（境界線・外側の線・均等分割・垂直／斜線エレメント）を描きます。
     *
     * @param {GroupItem} linesGroup - 追加先のグループ。
     * @param {Object} gridContext - buildGridContext() が返すコンテキスト。
     * @param {Object} gridParams - getGridParams() が返す設定。
     * @param {Object} frame - computeFrame() が返す描画範囲。
     * @param {Object} strokeStyle - 線のカラーと線幅。
     * @returns {void}
     */
    function drawVerticalGuides(linesGroup, gridContext, gridParams, frame, strokeStyle) {
        if (gridParams.outerVLines) {
            drawVerticalLine(linesGroup, frame, gridContext.selLeft, strokeStyle, true);
            drawVerticalLine(linesGroup, frame, gridContext.selRight, strokeStyle, true);
            for (var i = 1; i < gridParams.outerVLineCount; i++) {
                drawVerticalLine(linesGroup, frame, gridContext.selLeft - frame.unitSize * i, strokeStyle, false);
                drawVerticalLine(linesGroup, frame, gridContext.selRight + frame.unitSize * i, strokeStyle, false);
            }
        }

        if (gridParams.columnDiv && gridParams.columnDivisions > 1) {
            var step = gridContext.selWidth / gridParams.columnDivisions;
            for (var j = 1; j < gridParams.columnDivisions; j++) {
                drawVerticalLine(linesGroup, frame, gridContext.selLeft + step * j, strokeStyle, false);
            }
        }

        if (gridParams.verticalElements) {
            var elementXs = getVerticalElementXs(gridContext.geometry);
            for (var k = 0; k < elementXs.length; k++) {
                var onBounds = gridParams.emphasizeBounds &&
                    (isSameCoord(elementXs[k], gridContext.selLeft) || isSameCoord(elementXs[k], gridContext.selRight));
                drawVerticalLine(linesGroup, frame, elementXs[k], strokeStyle, onBounds);
            }
        }

        if (gridParams.diagonalElements) {
            var diagonalLines = getDiagonalElementLines(gridContext.geometry, frame.left, frame.top, frame.right, frame.bottom);
            for (var lineIndex = 0; lineIndex < diagonalLines.length; lineIndex++) {
                drawLine(linesGroup,
                    diagonalLines[lineIndex][0][0], diagonalLines[lineIndex][0][1],
                    diagonalLines[lineIndex][1][0], diagonalLines[lineIndex][1][1],
                    strokeStyle.color, strokeStyle.normal);
            }
        }
    }

    /**
     * クリアスペースの帯を1つ描きます（塗りと枠線の2枚重ね）。
     *
     * @param {GroupItem} targetGroup - 追加先のグループ。
     * @param {number} left - 左端。
     * @param {number} top - 上端。
     * @param {number} width - 幅。
     * @param {number} height - 高さ。
     * @param {Object} bandColor - 帯のカラー。
     * @returns {void}
     */
    function drawClearSpaceBand(targetGroup, left, top, width, height, bandColor) {
        var fillRect = targetGroup.pathItems.rectangle(top, left, width, height);
        fillRect.filled = true;
        fillRect.fillColor = bandColor;
        fillRect.stroked = false;
        fillRect.opacity = CLEAR_SPACE_STYLE.fillOpacity;

        var outlineRect = targetGroup.pathItems.rectangle(top, left, width, height);
        outlineRect.filled = false;
        outlineRect.stroked = true;
        outlineRect.strokeColor = bandColor;
        outlineRect.strokeWidth = CLEAR_SPACE_STYLE.strokeWidth;
    }

    /**
     * 選択範囲の四方にクリアスペースを描きます。
     *
     * @param {GroupItem} linesGroup - 追加先のグループ。
     * @param {Object} gridContext - buildGridContext() が返すコンテキスト。
     * @param {number} unitSize - ユニット（1単位）の大きさ。
     * @returns {void}
     */
    function drawClearSpace(linesGroup, gridContext, unitSize) {
        var left = gridContext.selLeft - unitSize;
        var right = gridContext.selRight + unitSize;
        var top = gridContext.selTop + unitSize;
        var outerWidth = right - left;
        var outerHeight = top - (gridContext.selBottom - unitSize);
        var bandColor = makeCyanColor(CLEAR_SPACE_STYLE.cyan);

        var clearSpaceGroup = linesGroup.groupItems.add();
        clearSpaceGroup.name = getLabel(LABELS.itemName.clearSpaceGroup);

        drawClearSpaceBand(clearSpaceGroup, left, top, outerWidth, unitSize, bandColor);
        drawClearSpaceBand(clearSpaceGroup, left, gridContext.selBottom, outerWidth, unitSize, bandColor);
        drawClearSpaceBand(clearSpaceGroup, left, top, unitSize, outerHeight, bandColor);
        drawClearSpaceBand(clearSpaceGroup, gridContext.selRight, top, unitSize, outerHeight, bandColor);
    }

    /**
     * 作成した線をガイドに変換し、グループ化しない設定ならレイヤー直下に移します。
     *
     * @param {GroupItem} linesGroup - 作成した線のグループ。
     * @param {Object} gridContext - buildGridContext() が返すコンテキスト。
     * @param {Object} gridParams - getGridParams() が返す設定。
     * @param {boolean} isPreview - プレビューとして作成したか。
     * @returns {GroupItem|null} 残ったグループ。解除したときは null。
     */
    function finalizeLinesGroup(linesGroup, gridContext, gridParams, isPreview) {
        /* プレビューは削除できるようグループのまま残す / Keep previews grouped so they can be removed */
        if (isPreview) return linesGroup;

        if (gridParams.convertToGuides) {
            for (var i = 0; i < linesGroup.pathItems.length; i++) {
                linesGroup.pathItems[i].guides = true;
            }
        }

        if (!gridParams.groupItems && !gridParams.convertToGuides) {
            while (linesGroup.pageItems.length > 0) {
                linesGroup.pageItems[0].move(gridContext.guideLayer, ElementPlacement.PLACEATBEGINNING);
            }
            linesGroup.remove();
            return null;
        }

        return linesGroup;
    }

    /**
     * 設定に従って補助線またはクリアスペースを作成します。
     *
     * @param {Object} gridContext - buildGridContext() が返すコンテキスト。
     * @param {Object} gridParams - getGridParams() が返す設定。
     * @param {boolean} isPreview - プレビューとして作成するか。
     * @returns {GroupItem|null} 作成したグループ。グループ化しないときは null。
     */
    function createGridItems(gridContext, gridParams, isPreview) {
        var frame = computeFrame(gridContext, gridParams);
        var strokeStyle = {
            color: makeGrayColor(LINE_STYLE.grayTint),
            normal: gridParams.strokeWidth,
            bounds: gridParams.emphasizeBounds ? (gridParams.strokeWidth * LINE_STYLE.boundsMultiplier) : gridParams.strokeWidth
        };

        var linesGroup = gridContext.guideLayer.groupItems.add();
        linesGroup.name = getLabel(isPreview ? LABELS.itemName.previewGroup : LABELS.itemName.guideGroup);

        if (gridParams.clearSpace) {
            drawClearSpace(linesGroup, gridContext, frame.unitSize);
        } else {
            drawHorizontalGuides(linesGroup, gridContext, gridParams, frame, strokeStyle);
            drawVerticalGuides(linesGroup, gridContext, gridParams, frame, strokeStyle);
        }

        return finalizeLinesGroup(linesGroup, gridContext, gridParams, isPreview);
    }

    // =========================================
    // プレビュー / Preview
    // =========================================

    var previewGroup = null;

    /**
     * プレビューで作成したオブジェクトを削除します。
     *
     * @returns {void}
     */
    function removePreview() {
        if (!previewGroup) return;
        /* 削除済みのときは参照が無効 / The group may already be gone */
        try {
            previewGroup.remove();
        } catch (e) { }
        previewGroup = null;
        app.redraw();
    }

    /**
     * 現在の設定でプレビューを作り直します。
     *
     * @param {Object} dialogUI - buildDialog() が返すUI参照。
     * @param {Object} gridContext - buildGridContext() が返すコンテキスト。
     * @returns {void}
     */
    function updatePreview(dialogUI, gridContext) {
        removePreview();
        var gridParams = getGridParams(dialogUI);
        if (!gridParams) return;
        gridContext.guideLayer = ensureGuideLayer(gridContext, gridParams.layerName);
        previewGroup = createGridItems(gridContext, gridParams, true);
        app.redraw();
    }

    /**
     * ［プレビュー］がONのときだけ、プレビューを作り直します。
     *
     * @param {Object} dialogUI - buildDialog() が返すUI参照。
     * @param {Object} gridContext - buildGridContext() が返すコンテキスト。
     * @returns {void}
     */
    function refreshPreview(dialogUI, gridContext) {
        if (dialogUI.previewCheck.value) updatePreview(dialogUI, gridContext);
    }

    // =========================================
    // イベント / Events
    // =========================================

    /**
     * ∧∨・↑↓キーで増減したあとの処理を、各入力欄に設定します（伸張率の表記、分割欄の連動、プレビュー更新）。
     *
     * @param {Object} dialogUI - buildDialog() が返すUI参照。
     * @param {Object} gridContext - buildGridContext() が返すコンテキスト。
     * @returns {void}
     */
    function bindStepperHandlers(dialogUI, gridContext) {
        var steppedFields = [
            dialogUI.widthScaleInput, dialogUI.heightScaleInput, dialogUI.strokeWidthInput,
            dialogUI.clearSpaceDivInput, dialogUI.columnDivInput, dialogUI.extraHLinesInput,
            dialogUI.outerVLinesInput, dialogUI.evenLineCountInput
        ];
        for (var i = 0; i < steppedFields.length; i++) {
            steppedFields[i].onStepped = createStepFollowUp(dialogUI, gridContext, steppedFields[i]);
        }
    }

    /**
     * 1つの入力欄について、増減後の処理を作ります。
     *
     * @param {Object} dialogUI - buildDialog() が返すUI参照。
     * @param {Object} gridContext - buildGridContext() が返すコンテキスト。
     * @param {EditText} inputField - 対象の入力欄。
     * @returns {Function} 増減後に呼ぶ関数。
     */
    function createStepFollowUp(dialogUI, gridContext, inputField) {
        return function () {
            /* 伸張率は小数第1位で表示する / Scale fields show one decimal place */
            if (isScaleField(dialogUI, inputField)) inputField.text = parseFloat(inputField.text).toFixed(1);
            if (inputField === dialogUI.evenLineCountInput || inputField === dialogUI.columnDivInput) {
                syncDivisionFields(dialogUI);
            }
            refreshPreview(dialogUI, gridContext);
        };
    }

    /**
     * 伸張率の入力欄を、フォーカスが外れたときに小数第1位の表記にそろえます。
     *
     * @param {EditText} scaleField - 対象の入力欄。
     * @returns {void}
     */
    function bindScaleFieldBlur(scaleField) {
        scaleField.onBlur = function () {
            var value = parseFloat(scaleField.text);
            if (!isNaN(value)) scaleField.text = value.toFixed(1);
        };
    }

    /**
     * ダイアログのイベントハンドラーを設定します。
     *
     * @param {Object} dialogUI - buildDialog() が返すUI参照。
     * @param {Object} gridContext - buildGridContext() が返すコンテキスト。
     * @returns {void}
     */
    function bindEvents(dialogUI, gridContext) {
        dialogUI.presetDropdown.onChange = function () {
            applyPreset(dialogUI, gridContext);
        };

        dialogUI.btnExport.onClick = function () {
            exportPreset(dialogUI);
        };

        dialogUI.previewCheck.onClick = function () {
            if (dialogUI.previewCheck.value) {
                updatePreview(dialogUI, gridContext);
            } else {
                removePreview();
            }
        };

        dialogUI.widthScaleInput.onChanging = dialogUI.heightScaleInput.onChanging =
            dialogUI.strokeWidthInput.onChanging = dialogUI.columnDivInput.onChanging =
            dialogUI.extraHLinesInput.onChanging = dialogUI.outerVLinesInput.onChanging =
            dialogUI.clearSpaceDivInput.onChanging = function () {
                refreshPreview(dialogUI, gridContext);
            };

        dialogUI.evenLineCountInput.onChanging = function () {
            syncDivisionFields(dialogUI);
            refreshPreview(dialogUI, gridContext);
        };

        bindScaleFieldBlur(dialogUI.widthScaleInput);
        bindScaleFieldBlur(dialogUI.heightScaleInput);

        dialogUI.layerNameInput.onBlur = function () {
            dialogUI.layerNameInput.text = normalizeLayerNameText(dialogUI.layerNameInput.text);
        };

        dialogUI.methodNoneRadio.onClick = dialogUI.methodAutoRadio.onClick =
            dialogUI.methodSegmentRadio.onClick = dialogUI.methodEvenRadio.onClick = function () {
                setInputEnabled(dialogUI.evenLineCountInput, dialogUI.methodEvenRadio.value);
                syncDivisionFields(dialogUI);
                refreshPreview(dialogUI, gridContext);
            };

        dialogUI.extraHLinesCheck.onClick = dialogUI.extendLeftCheck.onClick =
            dialogUI.outerVLinesCheck.onClick = dialogUI.columnDivCheck.onClick =
            dialogUI.extendUpCheck.onClick = dialogUI.verticalElementsCheck.onClick =
            dialogUI.diagonalElementsCheck.onClick = dialogUI.groupItemsCheck.onClick = function () {
                setInputEnabled(dialogUI.extraHLinesInput, dialogUI.extraHLinesCheck.enabled && dialogUI.extraHLinesCheck.value);
                setInputEnabled(dialogUI.outerVLinesInput, dialogUI.outerVLinesCheck.enabled && dialogUI.outerVLinesCheck.value);
                syncDivisionFields(dialogUI);
                refreshPreview(dialogUI, gridContext);
            };

        dialogUI.clearSpaceCheck.onClick = function () {
            updateClearSpaceState(dialogUI);
            refreshPreview(dialogUI, gridContext);
        };

        dialogUI.emphasizeBoundsCheck.onClick = function () {
            refreshPreview(dialogUI, gridContext);
        };

        dialogUI.convertToGuidesCheck.onClick = function () {
            updateGroupState(dialogUI);
            refreshPreview(dialogUI, gridContext);
        };

        dialogUI.btnOK.onClick = function () {
            removePreview();
            var gridParams = getGridParams(dialogUI);
            if (!gridParams) {
                alert(getLabel(LABELS.alert.invalidInput));
                return;
            }
            gridContext.guideLayer = ensureGuideLayer(gridContext, gridParams.layerName);
            createGridItems(gridContext, gridParams, false);
            dialogUI.dialog.close(1);
        };

        dialogUI.btnCancel.onClick = function () {
            removePreview();
            dialogUI.dialog.close(2);
        };

        dialogUI.dialog.onClose = function () {
            removePreview();
            removeEmptyCreatedLayers(gridContext);
        };
    }

    // =========================================
    // メイン / Main
    // =========================================

    /**
     * コーナーウィジェットの表示を切り替えます（ドラッグ中の誤操作と表示の乱れを避けるため）。
     *
     * @returns {void}
     */
    function toggleLiveCornerAnnotator() {
        try {
            app.executeMenuCommand('Live Corner Annotator');
        } catch (e) { }
    }

    /**
     * ドキュメントと選択を確認し、ダイアログを表示します。
     *
     * @returns {void}
     */
    function main() {
        if (app.documents.length === 0) {
            alert(getLabel(LABELS.alert.noDocument));
            return;
        }

        var doc = app.activeDocument;
        if (doc.selection.length === 0) {
            alert(getLabel(LABELS.alert.noSelection));
            return;
        }

        var gridContext = buildGridContext(doc, doc.selection);
        if (!gridContext) return;

        previewGroup = null;
        toggleLiveCornerAnnotator();
        try {
            var dialogUI = buildDialog();
            bindStepperHandlers(dialogUI, gridContext);
            bindEvents(dialogUI, gridContext);
            applyPreset(dialogUI, gridContext);
            prepareDialogWindow(dialogUI.dialog, SCRIPT_NAME);
            dialogUI.dialog.show();
        } finally {
            toggleLiveCornerAnnotator();
        }
    }

    main();

})();
