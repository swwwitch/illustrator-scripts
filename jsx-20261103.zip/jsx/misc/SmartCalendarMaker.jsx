#target illustrator
#targetengine "SmartCalendarMaker"
app.preferences.setBooleanPreference('ShowExternalJSXWarning', false);

/*
SCRIPTMETA-BEGIN
Script-ID=com.swwwitch.illustrator.SmartCalendarMaker
Name=基準日から指定月数のカレンダーを作成
Author=Masahiro Takano (@swwwitch)
Target-App=Illustrator
Version=1.4.8
Release-Date=2026-02-15
Description-BEGIN
基準日をもとに、指定した月数ぶんのカレンダー（月曜はじまり）をアートボード中心に作成します。
セル幅・高さや月間隔をダイアログで調整でき、日本の祝日（2020〜2035年、振替休日・国民の休日を含む）に対応します。

Builds calendars — Monday-first — for a number of months from a reference date, centered on the artboard.
Cell size and the spacing between months are set in a dialog, and Japanese public holidays from 2020 to 2035, including substitute and citizens' holidays, are covered.
Description-END
SCRIPTMETA-END
*/

/*

### 概要

基準日をもとに、指定した月数ぶんのカレンダー（月曜はじまり）をアートボード中心に作成します。
セル幅・高さや月間隔をダイアログで調整でき、日本の祝日（2020〜2035年、振替休日・国民の休日を含む）に対応します。

詳細は README を参照してください。
https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/SmartCalendarMaker.md

note記事も参照してください。
https://note.com/dtp_tranist/n/nc54c315c5dc3

### Overview

Builds calendars — Monday-first — for a number of months from a reference date, centered on the artboard.
Cell size and the spacing between months are set in a dialog, and Japanese public holidays from 2020 to 2035, including substitute and citizens' holidays, are covered.

See the README for details.
https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/SmartCalendarMaker.md

*/

// =========================================
// 基本情報 / Basic info
// =========================================
var SCRIPT_NAME     = "SmartCalendarMaker";           /* スクリプト名 / script name */
var SCRIPT_VERSION  = "v1.4.8";                       /* バージョン / version */
var SCRIPT_AUTHOR   = "Masahiro Takano (@swwwitch)";  /* 作者 / author */
var SCRIPT_RELEASED = "2026-02-15";                   /* 最初のリリース日 / first release date */
var SCRIPT_UPDATED  = "2026-10-04";                   /* 更新日 / last updated */

var SCRIPT_DESCRIPTION_JA = "基準日から指定月数のカレンダーを作成"; /* README の見出し / README title (Japanese) */

var SCRIPT_README_JA   = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/SmartCalendarMaker.md"; /* README（日本語） */
var SCRIPT_README_EN   = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/SmartCalendarMaker.md"; /* README (English) */
var SCRIPT_ARTICLE_URL = "https://note.com/dtp_tranist/n/nc54c315c5dc3"; /* 紹介記事 / article URL */
var SCRIPT_SOURCE_URL  = "https://github.com/swwwitch/illustrator-scripts/blob/master/jsx/misc/SmartCalendarMaker.jsx"; /* 最新版のソース / latest source */

// Released under the MIT license
// http://opensource.org/licenses/mit-license.php

(function () {

    var __PREVIEW_DELAY_MS = 450;               /* プレビュー更新の遅延(ms) / Preview debounce delay (ms) */
    var PREVIEW_LAYER_NAME = "__CAL_PREVIEW__"; /* プレビュー用レイヤー名 / Preview layer name */

    // =========================================
    // ローカライズ / Localization
    // =========================================
    // ローカライズ（再利用パーツ） / Localization (reusable)

    /**
     * UI の言語を返す（"ja" で始まるロケールは日本語、それ以外は英語）
     * @returns {string} "ja" または "en"
     */
    function getCurrentLang() {
        return (String($.locale || "").indexOf("ja") === 0) ? "ja" : "en";
    }

    var uiLang = getCurrentLang();

    /**
     * LABELS から今の UI 言語の文言を取り出す。
     * @param {string|Object} labelRef - "dialog.title" のようなパス、または { ja, en }
     * @param {Object|Array} [placeholderValues] - { name: 値 } なら {name} を、[値, …] なら %1, %2 … を差し込む
     * @returns {string} 文言。パスが見つからなければパスの文字列、{ ja, en } が無ければ空文字
     */
    function getLabel(labelRef, placeholderValues) {
        var labelEntry = labelRef;
        if (typeof labelRef === "string") {
            var labelPathKeys = labelRef.split(".");
            labelEntry = LABELS;
            for (var i = 0; i < labelPathKeys.length && labelEntry != null; i++) {
                labelEntry = labelEntry[labelPathKeys[i]];
            }
        }
        var labelString;
        if (typeof labelEntry === "string") labelString = labelEntry;
        else if (labelEntry != null && labelEntry[uiLang] != null) labelString = labelEntry[uiLang];
        else if (labelEntry != null && labelEntry.en != null) labelString = labelEntry.en;
        else return (typeof labelRef === "string") ? labelRef : "";
        return fillLabelPlaceholders(String(labelString), placeholderValues);
    }

    /**
     * 項目名の文言の末尾にコロンを付ける（日本語は半角スペース＋半角コロン「 :」、英語は「:」。Illustrator の線パネルなどの項目名に合わせる）
     * @param {string|Object} labelRef - getLabel と同じ
     * @param {Object|Array} [placeholderValues] - getLabel と同じ
     * @returns {string} コロン付きの文言
     */
    function labelText(labelRef, placeholderValues) {
        return getLabel(labelRef, placeholderValues) + (uiLang === "ja" ? " :" : ":");
    }

    /**
     * 「項目名 : 値」の1行を返す（日本語は「件数 : 5」、英語は「Count: 5」。どちらもコロンのあとに空白を入れる）
     * @param {string|Object} labelRef - getLabel と同じ
     * @param {string|number} value - コロンのあとに続ける値
     * @returns {string} 項目名と値をつないだ文字列
     */
    function labelValueText(labelRef, value) {
        return labelText(labelRef) + " " + value;
    }

    /**
     * 文言の {name} や %1 に値を差し込む
     * @param {string} labelString - 文言
     * @param {Object|Array} [placeholderValues] - { name: 値 } または [値, …]
     * @returns {string} 差し込んだ文言
     */
    function fillLabelPlaceholders(labelString, placeholderValues) {
        if (placeholderValues == null) return labelString;
        if (placeholderValues instanceof Array) {
            /* 大きい番号から置き換え、%1 が %10 の一部を置き換えないようにする / Replace from the highest index so %1 does not eat into %10 */
            for (var i = placeholderValues.length; i >= 1; i--) {
                labelString = labelString.split("%" + i).join(String(placeholderValues[i - 1]));
            }
            return labelString;
        }
        for (var placeholderKey in placeholderValues) {
            if (!placeholderValues.hasOwnProperty(placeholderKey)) continue;
            labelString = labelString.split("{" + placeholderKey + "}").join(String(placeholderValues[placeholderKey]));
        }
        return labelString;
    }

    // ローカライズ（再利用パーツ）ここまで / End of the reusable localization

    // キーボードショートカット（再利用パーツ） / Keyboard shortcuts (reusable)

    /* 入力中はショートカットを止めるコントロールの種類 / Control types that swallow keys while focused */
    var KEY_SHORTCUT_TYPING_TYPES = { edittext: true, dropdownlist: true, listbox: true };

    /* 修飾キーの並び順（キーの表記をそろえる）/ Canonical order of modifiers in a key spec */
    var KEY_SHORTCUT_MODIFIERS = ["SHIFT", "ALT", "CMD"];

    /* 修飾キーの別名 / Aliases accepted for the modifiers */
    var KEY_SHORTCUT_MODIFIER_ALIASES = {
        SHIFT: "SHIFT",
        ALT: "ALT", OPTION: "ALT", OPT: "ALT",
        CMD: "CMD", COMMAND: "CMD", META: "CMD", CTRL: "CMD", CONTROL: "CMD"
    };

    /**
     * キーの指定（"Shift+R" など）を、照合用の表記（"SHIFT+R"）にそろえる
     * @param {string} keySpec - キーの指定。修飾キーは "Shift+" / "Alt+" / "Cmd+" を前に付ける
     * @returns {string} 照合用の表記（大文字、修飾キーは SHIFT → ALT → CMD の順）
     */
    function normalizeKeyShortcutSpec(keySpec) {
        var specParts = String(keySpec).split("+");
        var baseKey = specParts.pop().toUpperCase();
        var modifierFlags = {};
        for (var i = 0; i < specParts.length; i++) {
            var modifierName = KEY_SHORTCUT_MODIFIER_ALIASES[specParts[i].toUpperCase()];
            if (modifierName) modifierFlags[modifierName] = true;
        }
        return buildKeyShortcutSpec(modifierFlags, baseKey);
    }

    /**
     * 修飾キーの状態とキー名から照合用の表記を組み立てる
     * @param {Object} modifierFlags - { SHIFT: true, ALT: true, CMD: true } のうち押されているもの
     * @param {string} baseKey - 大文字のキー名
     * @returns {string} 照合用の表記
     */
    function buildKeyShortcutSpec(modifierFlags, baseKey) {
        var specText = "";
        for (var i = 0; i < KEY_SHORTCUT_MODIFIERS.length; i++) {
            if (modifierFlags[KEY_SHORTCUT_MODIFIERS[i]]) specText += KEY_SHORTCUT_MODIFIERS[i] + "+";
        }
        return specText + baseKey;
    }

    /**
     * keydown イベントから照合用の表記を作る。修飾キーはイベントと keyboardState の両方を見る
     * @param {Object} keyEvent - keydown イベント
     * @returns {string} 照合用の表記。キー名が無いときは空文字
     */
    function readKeyShortcutSpec(keyEvent) {
        if (!keyEvent || !keyEvent.keyName) return "";
        var keyboardState = {};
        try { keyboardState = ScriptUI.environment.keyboardState; } catch (e) { }
        var modifierFlags = {
            SHIFT: !!(keyEvent.shiftKey || keyboardState.shiftKey),
            ALT: !!(keyEvent.altKey || keyboardState.altKey),
            CMD: !!(keyEvent.metaKey || keyEvent.ctrlKey || keyboardState.metaKey || keyboardState.ctrlKey)
        };
        return buildKeyShortcutSpec(modifierFlags, String(keyEvent.keyName).toUpperCase());
    }

    /**
     * コントロールが押せる状態か（自分と親がすべて有効で表示中か）を返す
     * @param {Object} control - コントロール
     * @returns {boolean} 押せるなら true
     */
    function isKeyShortcutControlUsable(control) {
        for (var node = control; node; node = node.parent) {
            if (node.enabled === false || node.visible === false) return false;
        }
        return true;
    }

    /**
     * キーを受けたコントロールが、文字を入力する欄か
     * @param {Object} focusedControl - イベントの発生元
     * @param {Object[]} numericFields - 数値だけの欄（ショートカットを効かせる）
     * @returns {boolean} 入力中としてショートカットを止めるなら true
     */
    function isKeyShortcutTypingTarget(focusedControl, numericFields) {
        if (!focusedControl || !KEY_SHORTCUT_TYPING_TYPES[focusedControl.type]) return false;
        for (var i = 0; i < numericFields.length; i++) {
            if (numericFields[i] === focusedControl) return false;
        }
        return true;
    }

    /**
     * コントロールをクリックしたときと同じ動作をする
     * ラジオは同じ親のラジオを外して選び、チェックボックスは反転してから onClick を呼ぶ
     * @param {Object} control - ラジオボタン・チェックボックス・ボタンなど
     * @returns {void}
     */
    function pressKeyShortcutControl(control) {
        if (control.type === "radiobutton") {
            /* 同じ親の直下だけが排他になるので、クリックと同じく兄弟を外す / Clear siblings like a click would */
            var siblings = control.parent ? control.parent.children : [];
            for (var i = 0; i < siblings.length; i++) {
                if (siblings[i] !== control && siblings[i].type === "radiobutton") siblings[i].value = false;
            }
            control.value = true;
        } else if (control.type === "checkbox") {
            control.value = !control.value;
        }
        if (typeof control.onClick === "function") {
            control.onClick.call(control);
        } else if (control.type === "button" && typeof control.notify === "function") {
            /* onClick の無い OK・キャンセルは notify で既定の動作（閉じる）を起こす / Let default buttons close the dialog */
            control.notify("onClick");
        }
    }

    /**
     * 1つのショートカットを実行する
     * @param {Object|Function} shortcutTarget - コントロール、または関数
     * @param {Object} keyEvent - keydown イベント
     * @returns {boolean} キーを使ったなら true（false なら文字をそのまま通す）
     */
    function runKeyShortcutTarget(shortcutTarget, keyEvent) {
        var targetControl = shortcutTarget;
        if (typeof shortcutTarget === "function") {
            var runResult = shortcutTarget(keyEvent);
            if (runResult === false || runResult === null) return false;
            if (!runResult || typeof runResult !== "object" || !runResult.type) return true;
            targetControl = runResult;
        }
        /* 無効なコントロールのキーも使ったことにして、数値欄へ文字を入れない / Consume the key even when disabled */
        if (isKeyShortcutControlUsable(targetControl)) pressKeyShortcutControl(targetControl);
        return true;
    }

    /**
     * キーの指定に修飾キーの表示名を当てて、ツールチップ用の表記にする
     * @param {string} normalizedSpec - 照合用の表記（"SHIFT+R" など）
     * @returns {string} 表示用の表記（"Shift+R" など）
     */
    function formatKeyShortcutLabel(normalizedSpec) {
        var isMac = ($.os.indexOf("Mac") === 0);
        var displayNames = { SHIFT: "Shift", ALT: isMac ? "Option" : "Alt", CMD: isMac ? "Cmd" : "Ctrl" };
        var specParts = normalizedSpec.split("+");
        var baseKey = specParts.pop();
        var labelText = "";
        for (var i = 0; i < specParts.length; i++) labelText += displayNames[specParts[i]] + "+";
        if (baseKey.length > 1) baseKey = baseKey.charAt(0) + baseKey.substring(1).toLowerCase();
        return labelText + baseKey;
    }

    /**
     * コントロールのツールチップの末尾にキーを足す（すでに書いてあれば足さない）
     * @param {Object} control - コントロール
     * @param {string} normalizedSpec - 照合用の表記
     * @returns {void}
     */
    function appendKeyShortcutToTip(control, normalizedSpec) {
        var keyLabel = formatKeyShortcutLabel(normalizedSpec);
        var currentTip = control.helpTip ? String(control.helpTip) : "";
        if (currentTip.indexOf("（" + keyLabel) >= 0 || currentTip.indexOf("(" + keyLabel) >= 0) return;
        var keySuffix = (uiLang === "ja") ? "（" + keyLabel + "）" : " (" + keyLabel + ")";
        control.helpTip = currentTip ? currentTip + keySuffix : keyLabel;
    }

    /**
     * ダイアログ・パレットに文字キーのショートカットを付ける
     * @param {Window} targetWindow - キーを受けるダイアログ・パレット
     * @param {Object} shortcutMap - { "L": ラジオ, "Shift+R": ボタン, "G": 関数, "Escape": { target: 関数, inFields: true } }
     * @param {Object} [shortcutOptions] - numericFields（数値だけの欄の配列）/ afterKey（キーを使ったあとに呼ぶ関数）/ showInTip（ツールチップにキーを足す）
     * @returns {Object} 照合用の表記 → { target, inFields } の表（テスト・デバッグ用）
     */
    function addKeyShortcuts(targetWindow, shortcutMap, shortcutOptions) {
        var shortcutSettings = shortcutOptions || {};
        var numericFields = shortcutSettings.numericFields || [];
        var bindingTable = {};

        for (var keySpec in shortcutMap) {
            if (!shortcutMap.hasOwnProperty(keySpec)) continue;
            var mapEntry = shortcutMap[keySpec];
            if (!mapEntry) continue;
            var isWrapped = (typeof mapEntry === "object" && !mapEntry.type && mapEntry.target);
            var normalizedSpec = normalizeKeyShortcutSpec(keySpec);
            bindingTable[normalizedSpec] = {
                target: isWrapped ? mapEntry.target : mapEntry,
                inFields: !!(isWrapped && mapEntry.inFields)
            };
            var tipControl = bindingTable[normalizedSpec].target;
            if (shortcutSettings.showInTip && typeof tipControl === "object" && tipControl.type) {
                appendKeyShortcutToTip(tipControl, normalizedSpec);
            }
        }

        /* キャプチャで受けて、数値欄に文字が入る前に止める / Capture phase keeps the letter out of numeric fields */
        targetWindow.addEventListener("keydown", function (keyEvent) {
            var binding = bindingTable[readKeyShortcutSpec(keyEvent)];
            if (!binding) return;
            if (!binding.inFields && isKeyShortcutTypingTarget(keyEvent.target, numericFields)) return;
            if (!runKeyShortcutTarget(binding.target, keyEvent)) return;
            if (keyEvent.preventDefault) keyEvent.preventDefault();
            if (typeof shortcutSettings.afterKey === "function") shortcutSettings.afterKey(keyEvent);
        }, true);

        return bindingTable;
    }

    // キーボードショートカット（再利用パーツ）ここまで / End of the reusable keyboard shortcuts

    /* 日英ラベル定義（カテゴリ別に構造化）/ Japanese-English label definitions (grouped by category) */
    var LABELS = {
        /* ダイアログ / Dialog */
        dialog: {
            title: { ja: "カレンダー作成 " + SCRIPT_VERSION, en: "Calendar Maker " + SCRIPT_VERSION }
        },

        /* 警告メッセージ / Alerts */
        alert: {
            noDoc: {
                ja: "ドキュメントを開いてから実行してください。",
                en: "Please open a document before running."
            }
        },

        /* 罫線の指定 / Stroke options */
        stroke: {
            none:   { ja: "なし", en: "None" },
            all:    { ja: "すべて", en: "All" },
            custom: { ja: "個別", en: "Custom" },
            top:    { ja: "上", en: "Top" },
            bottom: { ja: "下", en: "Bottom" },
            left:   { ja: "左", en: "Left" },
            right:  { ja: "右", en: "Right" }
        },

        /* ツールチップ / Tooltips */
        tooltip: {
            stepUp: {
                ja: "値を増やす（shift＋クリックで10の倍数へ、option＋クリックで0.1ずつ）",
                en: "Increase (Shift-click to snap to 10s, Option-click by 0.1)"
            },
            stepDown: {
                ja: "値を減らす（shift＋クリックで10の倍数へ、option＋クリックで0.1ずつ）",
                en: "Decrease (Shift-click to snap to 10s, Option-click by 0.1)"
            },
            stepUpInteger: { ja: "値を増やす（shift＋クリックで10の倍数へ）", en: "Increase (Shift-click to snap to 10s)" },
            stepDownInteger: { ja: "値を減らす（shift＋クリックで10の倍数へ）", en: "Decrease (Shift-click to snap to 10s)" },
            presetList:   { ja: "保存した設定を読み込みます。", en: "Loads a saved set of settings." },
            baseDate:     { ja: "カレンダーの起点になる年・月・日です。", en: "The year, month and day the calendar starts from." },
            preset1:      { ja: "1か月分だけ作ります。", en: "Builds a single month." },
            preset3:      { ja: "3か月分を作ります。", en: "Builds three months." },
            preset12:     { ja: "12か月分を作ります。", en: "Builds twelve months." },
            startCurrent: { ja: "指定した月から並べ始めます。", en: "Starts from the month you specified." },
            startJan:     { ja: "その年の1月から並べ始めます。", en: "Starts from January of that year." },
            ghost:        { ja: "前後の月からはみ出す日付も、薄い色で表示します。", en: "Shows the spill-over days from the neighbouring months in a lighter color." },
            sundayRed:    { ja: "日曜日の日付を赤にします。", en: "Colors Sundays red." },
            holidayRed:   { ja: "祝日の日付を赤にします。", en: "Colors public holidays red." },
            weekMonday:   { ja: "週の始まりを月曜にします。", en: "Starts each week on Monday." },
            weekSunday:   { ja: "週の始まりを日曜にします。", en: "Starts each week on Sunday." },
            weekdayLabel: { ja: "曜日の表記を選びます。", en: "How the weekday names are written." },
            weekdayBottomMargin: { ja: "曜日の行と日付の行のあいだにあける余白です。", en: "Space left between the weekday row and the dates." },
            monthIncludeYear: { ja: "月の見出しに年も入れます。", en: "Includes the year in the month heading." },
            monthFormat:  { ja: "月の見出しの表記を選びます。", en: "How the month heading is written." },
            monthBottomMargin: { ja: "月の見出しの下にあける余白です。", en: "Space left below the month heading." },
            monthBottomBorder: { ja: "月の見出しの下にケイ線を引きます。", en: "Draws a rule below the month heading." },
            topYear:      { ja: "カレンダー全体の上に年を表示します。", en: "Shows the year above the whole calendar." },
            topYearBottomMargin: { ja: "年の見出しの下にあける余白です。", en: "Space left below the year heading." },
            months:       { ja: "作る月数です。", en: "How many months to build." },
            columns:      { ja: "月を横に何個並べるかです。", en: "How many months to place across." },
            outerMarginX: { ja: "月どうしの横方向の間隔です。", en: "Horizontal spacing between months." },
            outerMarginY: { ja: "月どうしの縦方向の間隔です。", en: "Vertical spacing between months." },
            zoom:         { ja: "プレビューの表示倍率です。書き出す内容は変わりません。", en: "Zoom of the preview only; it does not change the output." },
            pan:          { ja: "プレビューの表示位置をずらします。書き出す内容は変わりません。", en: "Pans the preview only; it does not change the output." },
            cellWidth:    { ja: "日付1マスの幅です。", en: "Width of one date cell." },
            cellHeight:   { ja: "日付1マスの高さです。", en: "Height of one date cell." },
            cellGapX:     { ja: "マスどうしの横の隙間です。", en: "Horizontal gap between cells." },
            cellGapY:     { ja: "マスどうしの縦の隙間です。", en: "Vertical gap between cells." },
            cellPosAdjY:  { ja: "マスの中で日付を上下に動かす量です。", en: "Nudges the date up or down inside its cell." },
            cellFill:     { ja: "マスに背景色を敷きます。", en: "Fills each cell with a background color." },
            strokeNone:   { ja: "マスにケイ線を引きません。", en: "Draws no rules around the cells." },
            strokeAll:    { ja: "マスの四辺すべてにケイ線を引きます。", en: "Draws rules on all four sides of each cell." },
            strokeCustom: { ja: "ケイ線を引く辺を個別に選びます。", en: "Picks which sides get a rule." },
            strokeSide:   { ja: "この辺にケイ線を引きます。", en: "Draws a rule on this side." },
            fontSize:     { ja: "文字サイズです。", en: "Type size." },
            fontName:     { ja: "使用するフォントです。", en: "The font used." },
            favFont:      { ja: "よく使うフォントから選びます。", en: "Picks from the fonts you use often." },
            preview:      { ja: "結果を画面で確認します。キャンセルすると元に戻ります。", en: "Shows the result on the canvas. Cancel restores the original state." }
        },

        /* パネル・タブ見出し / Panel & tab titles */
        panel: {
            base: { ja: "全般", en: "General" },
            view: { ja: "画面表示", en: "View" },
            unit: { ja: "セル", en: "Cells" },
            year: { ja: "年", en: "Year" },
            month: { ja: "月", en: "Month" },
            weekday: { ja: "曜日", en: "Weekday" },
            date: { ja: "日付", en: "Date" },
            layout: { ja: "レイアウト", en: "Layout" },
            cell: { ja: "セル", en: "Cell" },
            formatTab: { ja: "文字", en: "Text" },
            font: { ja: "フォント", en: "Font" },
            option: { ja: "表記", en: "Labels" },
            fontSize: { ja: "フォントサイズ", en: "Font Size" },
            preset: { ja: "プリセット", en: "Preset" },
            notation: { ja: "表記", en: "Notation" }
        },

        /* 基準日フィールド / Base date fields */
        field: {
            year: { ja: "年", en: "Year" },
            month: { ja: "月", en: "Month" },
            day: { ja: "日", en: "Day" }
        },

        /* 月数プリセット・起点 / Month-count presets & base */
        base: {
            monthCount: { ja: "月数", en: "Months" },
            preset1: { ja: "1ヶ月", en: "1 mo" },
            preset3: { ja: "3ヶ月", en: "3 mo" },
            preset12: { ja: "12ヶ月", en: "12 mo" },
            label: { ja: "基準", en: "Base" },
            current: { ja: "当月基準", en: "Current month" },
            jan: { ja: "1月から", en: "From January" },
            ghost: { ja: "ゴースト", en: "Ghost" }
        },

        /* 共通UI / Common UI */
        common: {
            bottomMargin: { ja: "下マージン", en: "Bottom margin" },
            align: { ja: "揃え", en: "Align" },
            left: { ja: "左", en: "Left" },
            center: { ja: "中央", en: "Center" },
            right: { ja: "右", en: "Right" },
            zoom: { ja: "ズーム", en: "Zoom" },
            lr: { ja: "左右", en: "L/R" },
            ud: { ja: "上下", en: "U/D" }
        },

        /* 月タイトル / Month title */
        month: {
            includeYear: { ja: "年を併記", en: "Include year" },
            num: { ja: "数字", en: "Number" },
            pad: { ja: "数字（0埋め）", en: "Zero-padded" },
            en: { ja: "英語", en: "English" },
            ens: { ja: "英語（短縮）", en: "English (short)" },
            bottomBorder: { ja: "下ボーダー", en: "Bottom border" }
        },

        /* 年タイトル / Year title */
        year: {
            show: { ja: "年を表示", en: "Show year" }
        },

        /* 曜日ヘッダ / Weekday header */
        weekday: {
            start: { ja: "週の始まり", en: "Week starts" },
            monday: { ja: "月曜日", en: "Monday" },
            sunday: { ja: "日曜日", en: "Sunday" },
            notation: { ja: "表記", en: "Notation" },
            margin: { ja: "下マージン", en: "Bottom margin" },
            fontSize: { ja: "基本", en: "Basic" }
        },

        /* レイアウト / Layout */
        layout: {
            months: { ja: "月数", en: "Months" },
            cols: { ja: "列数", en: "Columns" },
            width: { ja: "幅", en: "W" },
            height: { ja: "高さ", en: "H" },
            cellFill: { ja: "塗り", en: "Fill" }
        },

        /* 書式（フォント・色）/ Format (font & color) */
        format: {
            font: { ja: "フォント", en: "Font" },
            favorites: { ja: "お気に入り", en: "Favorites" },
            sunday: { ja: "日曜日", en: "Sunday" },
            holiday: { ja: "祝日", en: "Holidays" }
        },

        /* ボタン / Buttons */
        button: {
            preview: { ja: "プレビュー", en: "Preview" },
            cancel: { ja: "キャンセル", en: "Cancel" },
            create: { ja: "作成", en: "OK" }
        },

        /* エラーメッセージ / Error messages */
        error: {
            badDate: {
                ja: "日付形式が正しくありません。例: 2026-02-14",
                en: "Invalid date. e.g. 2026-02-14"
            },
            badFontSize: { ja: "フォントサイズが正しくありません。", en: "Invalid font size." },
            badCellW: { ja: "セル幅が正しくありません。", en: "Invalid cell width." },
            badCellH: { ja: "セル高さが正しくありません。", en: "Invalid cell height." },
            build: {
                ja: "作成中にエラーが発生しました。",
                en: "An error occurred while creating."
            }
        },

        /* 進捗表示 / Loading progress */
        loading: {
            title: { ja: "準備中", en: "Loading" },
            text: { ja: "処理中...", en: "Working..." },
            fontsRead: { ja: "フォント一覧を読み込み中...", en: "Loading fonts..." },
            fontsSet: { ja: "フォント一覧をセット中...", en: "Applying fonts..." },
            ready: { ja: "準備完了", en: "Ready" }
        },

        /* プリセット入出力 / Preset save & load */
        preset: {
            save: { ja: "保存", en: "Save" },
            load: { ja: "読込", en: "Load" },
            saveDialog: { ja: "プリセットを保存", en: "Save preset" },
            loadDialog: { ja: "プリセットを読み込み", en: "Load preset" },
            fileFilter: { ja: "プリセットファイル", en: "Preset file" },
            saveHint: { ja: "（.jsxpreset 推奨）", en: "(recommended .jsxpreset)" },
            saved: { ja: "プリセットを保存しました。", en: "Preset saved." },
            loaded: { ja: "プリセットを読み込みました。", en: "Preset loaded." },
            err: {
                ja: "プリセットの読み込みに失敗しました。",
                en: "Failed to load preset."
            }
        }
    };

    // =========================================
    // 単位 / Units
    // 設定キーの意味：
    // - "rulerType"       ：一般（定規の単位）
    // - "strokeUnits"     ：線
    // - "text/units"      ：文字
    // - "text/asianunits" ：東アジア言語のオプション（日本語・中国語など）
    // =========================================

    /* 単位コードに対応する表示ラベルと、1単位あたりのポイント数
       Unit code -> display label and points per unit */
    var UNITS = [
        { label: "in",    pointsPerUnit: 72 },                /* 0 */
        { label: "mm",    pointsPerUnit: 72 / 25.4 },         /* 1 */
        { label: "pt",    pointsPerUnit: 1 },                 /* 2 */
        { label: "pica",  pointsPerUnit: 12 },                /* 3 */
        { label: "cm",    pointsPerUnit: 72 / 2.54 },         /* 4 */
        { label: "Q",     pointsPerUnit: 72 / 25.4 * 0.25 },  /* 5 */
        { label: "px",    pointsPerUnit: 1 },                 /* 6 */
        { label: "ft/in", pointsPerUnit: 72 * 12 },           /* 7 */
        { label: "m",     pointsPerUnit: 72 / 25.4 * 1000 },  /* 8 */
        { label: "yd",    pointsPerUnit: 72 * 36 },           /* 9 */
        { label: "ft",    pointsPerUnit: 72 * 12 }            /* 10 */
    ];

    /* 単位コード5を「歯（H）」と表示する環境設定キー。文字サイズ（text/units）だけ「級（Q）」
       Preference keys that show unit code 5 as H; only the type size (text/units) shows Q */
    var HA_UNIT_PREF_KEYS = { "rulerType": true, "strokeUnits": true, "text/asianunits": true };

    /**
     * 環境設定キーの単位を返す
     * @param {string} [prefKey] - "rulerType"（既定）/ "strokeUnits" / "text/units" / "text/asianunits"
     * @returns {{code: number, label: string, pointsPerUnit: number}} 単位の情報
     */
    function getUnitInfo(prefKey) {
        var unitKey = prefKey || "rulerType";
        var unitCode = app.preferences.getIntegerPreference(unitKey);
        /* 未知のコードは pt に寄せる / unknown codes fall back to points */
        var unit = UNITS[unitCode] || UNITS[2];
        /* 級（Q）と歯（H）は同じ長さだが、文字サイズは「Q」、距離は「H」と呼び分ける */
        var label = (unitCode === 5 && HA_UNIT_PREF_KEYS[unitKey]) ? "H" : unit.label;
        return { code: unitCode, label: label, pointsPerUnit: unit.pointsPerUnit };
    }

    /**
     * 単位の値を pt に換算する
     * @param {number} value - 単位の値
     * @param {{pointsPerUnit: number}} unit - getUnitInfo() の戻り値か UNITS[i]
     * @returns {number} pt の値
     */
    function unitToPt(value, unit) {
        return value * unit.pointsPerUnit;
    }

    /**
     * pt の値を単位の値に換算する
     * @param {number} ptValue - pt の値
     * @param {{pointsPerUnit: number}} unit - getUnitInfo() の戻り値か UNITS[i]
     * @returns {number} 単位の値
     */
    function ptToUnit(ptValue, unit) {
        return ptValue / unit.pointsPerUnit;
    }

    // 画面上の寸法系はドキュメントの rulerUnits ではなく、Illustrator の一般単位（rulerType）に合わせる
    var unitLabel = getUnitInfo("rulerType").label;
    // 文字系（フォントサイズ等）の単位は text/units を参照
    var textUnitLabel = getUnitInfo("text/units").label;
    /* 数値欄の中に数値の後ろに出す単位 / Units shown after the number inside the fields */
    var lengthUnitSuffix = " " + unitLabel;
    var textUnitSuffix = " " + textUnitLabel;

    /**
     * 入力欄の値（定規の単位）を pt で読む
     * @param {EditText} editText - 入力欄
     * @returns {number} pt の値（読めなければ NaN）
     */
    function readLengthFieldPt(editText) {
        /* 「3 mm」のような単位付きの文字列も先頭の数値で読む / read the leading number of unit-suffixed text such as "3 mm" */
        var value = parseFloat(editText && editText.text);
        if (isNaN(value)) return NaN;
        return unitToPt(value, getUnitInfo("rulerType"));
    }

    /**
     * 数値に入力欄の単位を付けた文字列を返す（単位のない欄は数値のみ）
     * @param {EditText} editText - addStepperInput() で作った入力欄
     * @param {number|string} value - 値
     * @returns {string} 欄に入れる文字列（例「3 mm」）
     */
    function formatInputText(editText, value) {
        var stepOptions = editText && editText.stepperGroup && editText.stepperGroup.stepOptions;
        return String(value) + ((stepOptions && stepOptions.unit) || "");
    }

    // ダイアログの位置と不透明度（再利用パーツ） / Dialog position and opacity (reusable)

    var DIALOG_OPACITY = 0.98;       /* ダイアログの不透明度 / dialog opacity */
    var DIALOG_AVOID_MARGIN = 60;    /* 選択範囲の推定位置の両側に取る余裕（px）/ margin on each side of the estimated selection (px) */
    var DIALOG_AVOID_MAX_ITEMS = 100; /* 選択範囲を測るオブジェクトの上限 / max items measured for the selection bounds */

    /**
     * ダイアログの不透明度を設定し、前回閉じた位置で開いて、動かした位置を記録するようにする。
     * 開く位置が選択中のオブジェクトに重なりそうなときは、左右の反対側へずらす（Illustrator のみ）。
     * 既存の onShow / onMove / onClose は先に呼んでから、位置の復元・記録を行う。
     * @param {Window} dialog - 対象のダイアログ
     * @param {string} storageKey - 位置を覚えるキー（ふつうは SCRIPT_NAME）
     * @returns {void}
     */
    function prepareDialogWindow(dialog, storageKey) {
        /* 同じダイアログを開き直すときは、選択範囲を測り直すだけにする（ハンドラーを重ねない）
           When the same dialog is shown again, only re-measure the selection (don't stack handlers) */
        if (dialog.dialogWindowState) {
            dialog.dialogWindowState.selectionSpan = getSelectionViewSpan();
            dialog.dialogWindowState.avoidedLocation = null;
            return;
        }
        var locationKey = "__" + storageKey + "_DialogLocation";
        var previousOnShow = dialog.onShow;
        var previousOnMove = dialog.onMove;
        var previousOnClose = dialog.onClose;
        var windowState = {
            selectionSpan: getSelectionViewSpan(), /* 選択範囲は show() の前に測る / measured before show() */
            screenWidth: null,                     /* 最初に開いたときに推定する / estimated on the first show */
            avoidedLocation: null                  /* 避けるためにずらした位置（記録しない）/ location set to avoid the selection (not remembered) */
        };
        dialog.dialogWindowState = windowState;

        dialog.opacity = DIALOG_OPACITY;

        /* 今の位置を記録する / Remember the current location */
        function rememberDialogLocation() {
            var currentLocation = [dialog.location[0], dialog.location[1]];
            var avoidedLocation = windowState.avoidedLocation;
            if (avoidedLocation && currentLocation[0] === avoidedLocation[0] && currentLocation[1] === avoidedLocation[1]) return;
            $.global[locationKey] = currentLocation;
        }

        dialog.onShow = function () {
            /* 最初に開くときの既定の位置は画面の横中央なので、画面の幅を逆算できる。2回目からは前回の位置なので使い回す
               On the first show the default location is centered horizontally, which gives the screen width; reuse it afterwards */
            if (windowState.screenWidth === null) windowState.screenWidth = dialog.location[0] * 2 + dialog.bounds.width;
            if (previousOnShow) previousOnShow.apply(this, arguments);
            /* $.screens は実際の画面の大きさと合わない（Mac で 1280×524 など）ので、画面内かは判定しない
               $.screens does not match the real display (e.g. 1280x524 on a Mac), so no on-screen check */
            var savedLocation = $.global[locationKey];
            if (savedLocation) dialog.location = [savedLocation[0], savedLocation[1]];
            if (windowState.selectionSpan) {
                var avoidLeft = findDialogLeftAvoidingSelection(dialog.location[0], dialog.bounds.width, windowState.screenWidth, windowState.selectionSpan);
                if (avoidLeft !== null) {
                    dialog.location = [avoidLeft, dialog.location[1]];
                    /* 代入後の値で比べる（丸められることがある）/ Compare with the value after assignment, which may be rounded */
                    windowState.avoidedLocation = [dialog.location[0], dialog.location[1]];
                }
            }
        };
        dialog.onMove = function () {
            if (previousOnMove) previousOnMove.apply(this, arguments);
            rememberDialogLocation();
        };
        dialog.onClose = function () {
            rememberDialogLocation();
            /* false を返すと閉じるのを取りやめるので、戻り値は元の onClose のものを返す
               Returning false cancels the close, so pass the original onClose result through */
            if (previousOnClose) return previousOnClose.apply(this, arguments);
        };
    }

    /**
     * 選択中のオブジェクトが、ドキュメントの表示域の左端から画面上で何 px の範囲にあるかを返す。
     * @returns {{left: number, right: number, viewWidth: number}|null} 選択が無い・測れないときは null
     */
    function getSelectionViewSpan() {
        try {
            if (app.name !== "Adobe Illustrator" || !app.documents.length) return null;
            var targetDoc = app.activeDocument;
            var selectedItems = targetDoc.selection;
            /* 文字ツールで文字を選択しているときは TextRange が返り、[0] が無い / Selecting characters with the Type tool returns a TextRange, which has no [0] */
            if (!selectedItems || selectedItems.typename === "TextRange" || !selectedItems.length || !selectedItems[0].visibleBounds) return null;
            var itemCount = Math.min(selectedItems.length, DIALOG_AVOID_MAX_ITEMS);
            var spanLeft = Infinity;
            var spanRight = -Infinity;
            for (var i = 0; i < itemCount; i++) {
                var itemBounds = selectedItems[i].visibleBounds;
                if (itemBounds[0] < spanLeft) spanLeft = itemBounds[0];
                if (itemBounds[2] > spanRight) spanRight = itemBounds[2];
            }
            var activeView = targetDoc.activeView; /* 複数ウィンドウで開いていても今のウィンドウ / the current window even with multiple windows */
            var viewBounds = activeView.bounds;
            var zoom = activeView.zoom;
            var viewWidth = (viewBounds[2] - viewBounds[0]) * zoom;
            /* 表示域の外にはみ出した部分は数えない / Ignore the part outside the view */
            var left = Math.max(0, (spanLeft - viewBounds[0]) * zoom);
            var right = Math.min(viewWidth, (spanRight - viewBounds[0]) * zoom);
            if (right <= left) return null;
            return { left: left, right: right, viewWidth: viewWidth };
        } catch (e) {
            /* テキスト編集中など測れないときは避けない / Do not avoid when it cannot be measured, e.g. while editing text */
            return null;
        }
    }

    /**
     * ダイアログが選択範囲に重なるなら、重ならない左端の位置を返す。
     * 表示域は画面の横中央にあるとみなし、ずれは DIALOG_AVOID_MARGIN で吸収する。
     * @param {number} dialogLeft - 今のダイアログの左端
     * @param {number} dialogWidth - ダイアログの幅
     * @param {number} screenWidth - 画面の幅
     * @param {{left: number, right: number, viewWidth: number}} selectionSpan - getSelectionViewSpan() の結果
     * @returns {number|null} ずらした左端。重ならない・どちらにも収まらないときは null
     */
    function findDialogLeftAvoidingSelection(dialogLeft, dialogWidth, screenWidth, selectionSpan) {
        var viewLeft = (screenWidth - selectionSpan.viewWidth) / 2;
        var avoidLeft = viewLeft + selectionSpan.left - DIALOG_AVOID_MARGIN;
        var avoidRight = viewLeft + selectionSpan.right + DIALOG_AVOID_MARGIN;
        if (dialogLeft + dialogWidth <= avoidLeft || dialogLeft >= avoidRight) return null;

        var leftSideLeft = avoidLeft - dialogWidth;   /* 選択範囲の左に置くとき / placed left of the selection */
        var rightSideLeft = avoidRight;               /* 選択範囲の右に置くとき / placed right of the selection */
        var fitsLeft = leftSideLeft >= 0;
        var fitsRight = rightSideLeft + dialogWidth <= screenWidth;
        /* 選択範囲が画面の右寄りなら左へ、左寄りなら右へ逃がす / Move away from the side the selection leans to */
        var preferLeft = (avoidLeft + avoidRight) / 2 > screenWidth / 2;
        if (preferLeft && fitsLeft) return leftSideLeft;
        if (fitsRight) return rightSideLeft;
        if (fitsLeft) return leftSideLeft;
        return null;
    }

    // ダイアログの位置と不透明度（再利用パーツ）ここまで / End of the reusable dialog position and opacity

    // =========================================
    // UIレイアウトの共通設定 / Shared UI layout
    // =========================================

    // UIレイアウト（再利用パーツ） / UI layout (reusable)

    /* ウィンドウ・パネルの余白と間隔 / Window & panel margins and spacing */
    var WINDOW_MARGINS = 16;                 /* ウィンドウ外周の余白 / window margin */
    var WINDOW_SPACING = 12;                 /* ウィンドウ内の要素間隔 / window spacing */
    var PANEL_MARGINS  = [16, 20, 16, 12];   /* パネル余白 [左,上,右,下] / panel margins */
    var PANEL_SPACING  = 12;                 /* パネル内の要素間隔 / panel spacing */
    var COLUMN_SPACING = 12;                 /* 2カラムの間隔 / gap between columns */
    var TAB_MARGINS    = [15, 20, 5, 10];    /* タブ余白 [左,上,右,下] / tab margins */

    /**
     * ウィンドウの共通設定
     * @param {Window} targetWindow - 対象のウィンドウ
     * @param {number} [spacing] - 要素間隔（省略時は WINDOW_SPACING）
     * @returns {void}
     */
    function setupWindow(targetWindow, spacing) {
        targetWindow.orientation = "column";
        targetWindow.alignChildren = "fill";
        targetWindow.margins = WINDOW_MARGINS;
        targetWindow.spacing = (typeof spacing === "number") ? spacing : WINDOW_SPACING;
    }

    /**
     * パネルの共通設定（子は幅いっぱい。ボタンは alignment = "left" で広げない）
     * @param {Panel} targetPanel - 対象のパネル
     * @param {number} [spacing] - 要素間隔（省略時は PANEL_SPACING）
     * @returns {void}
     */
    function setupPanel(targetPanel, spacing) {
        targetPanel.orientation = "column";
        targetPanel.alignChildren = ["fill", "top"];
        targetPanel.alignment = "fill";
        targetPanel.margins = PANEL_MARGINS;
        targetPanel.spacing = (typeof spacing === "number") ? spacing : PANEL_SPACING;
    }

    /**
     * タブの共通設定
     * @param {Tab} targetTab - 対象のタブ
     * @param {number} [spacing] - 要素間隔（省略時は変えない）
     * @returns {void}
     */
    function setupTab(targetTab, spacing) {
        targetTab.orientation = "column";
        targetTab.alignChildren = "fill";
        targetTab.margins = TAB_MARGINS;
        if (typeof spacing === "number") targetTab.spacing = spacing;
    }

    /**
     * 横並びの行グループの共通設定（ボタン列など）。
     * alignment と alignChildren を対で指定し、中のボタンが横に伸びたり天地がずれたりしないようにする
     * @param {Group} rowGroup - 対象のグループ
     * @param {string|string[]} [rowAlignment] - 横方向の alignment（省略時は "left"）。配列ならそのまま使う
     * @param {number} [spacing] - 要素間隔（省略時は PANEL_SPACING）
     * @returns {void}
     */
    function setupRow(rowGroup, rowAlignment, spacing) {
        rowGroup.orientation = "row";
        rowGroup.alignment = (rowAlignment instanceof Array) ? rowAlignment : [rowAlignment || "left", "center"];
        rowGroup.alignChildren = ["left", "center"];
        rowGroup.spacing = (typeof spacing === "number") ? spacing : PANEL_SPACING;
    }

    /**
     * ボタンの高さを指定した px だけ詰める（レイアウトが決まったあとに呼ぶ）
     * @param {Button} targetButton - 対象のボタン
     * @param {number} trimPixels - 詰める量（px）
     * @returns {void}
     */
    function trimButtonHeight(targetButton, trimPixels) {
        /* レイアウト前は size が無い / size is not set until the layout runs */
        if (!targetButton.size) return;
        targetButton.size = [targetButton.size.width, targetButton.size.height - trimPixels];
    }

    // UIレイアウト（再利用パーツ）ここまで / End of the reusable UI layout

    // UI の明暗（再利用パーツ） / UI theme (reusable)

    /**
     * UI がダークテーマかどうかを判定する（Illustrator は uiBrightness、InDesign は uiBrightnessPreference）
     * @returns {boolean} ダークなら true。取得できない環境では false（明るいUI扱い）
     */
    function isDarkUI() {
        try {
            if (app.preferences && app.preferences.getRealPreference) {
                return app.preferences.getRealPreference("uiBrightness") <= 0.5; /* Illustrator */
            }
            return app.generalPreferences.uiBrightnessPreference <= 0.5; /* InDesign */
        } catch (e) {
            return false;
        }
    }

    // UI の明暗（再利用パーツ）ここまで / End of the reusable UI theme

    // ボタン行（再利用パーツ） / Button row (reusable)

    var BUTTON_ROW_TOP_MARGIN = 5; /* ボタン行の上の余白 / top margin of the button row */
    var BUTTON_ROW_BOTTOM_MARGIN = 14; /* ボタン行の下の余白。ダイアログの下余白と合わせて約30px（Illustrator 標準のダイアログに合わせる） / bottom margin; with the dialog margin about 30px, like Illustrator's own dialogs */
    var BUTTON_ROW_SPACING = 10;   /* ボタンどうしの間隔 / spacing between buttons */
    var BUTTON_ROW_CENTER_MAX_WIDTH = 240; /* 右のボタンだけの行を中央に置く、ダイアログの内側の最大幅（px、左右の余白を除く）。広いダイアログは右揃え / max inner dialog width (px, margins excluded) that centers a right-only row; wider dialogs keep it right-aligned */

    /**
     * ダイアログ下部のボタン行を作る。
     * 通常は「左のグループ・伸びるスペーサー・右のグループ」、centered なら行そのものを左右中央に置く
     * @param {Window|Group|Panel} parent - 行を足す先（ふつうはダイアログ）
     * @param {Object} [rowOptions] - { centered: true } で左右中央に並べる
     * @returns {{rowGroup: Group, leftGroup: Group|null, rightGroup: Group|null}} 行と左右のグループ（centered のときは左右が null）
     */
    function addButtonRow(parent, rowOptions) {
        var isCentered = !!(rowOptions && rowOptions.centered);
        var btnRowGroup = parent.add("group");
        btnRowGroup.orientation = "row";
        btnRowGroup.margins = [0, BUTTON_ROW_TOP_MARGIN, 0, BUTTON_ROW_BOTTOM_MARGIN];
        btnRowGroup.spacing = BUTTON_ROW_SPACING;

        if (isCentered) {
            btnRowGroup.alignment = ["center", "bottom"];
            btnRowGroup.alignChildren = ["center", "center"];
            return { rowGroup: btnRowGroup, leftGroup: null, rightGroup: null };
        }

        btnRowGroup.alignment = ["fill", "bottom"];

        var btnLeftGroup = btnRowGroup.add("group");
        btnLeftGroup.alignChildren = ["left", "center"];
        btnLeftGroup.spacing = BUTTON_ROW_SPACING;

        /* 余りの幅を吸って、右のグループを右端に寄せる / Absorbs the extra width so the right group sits at the right edge */
        var spacer = btnRowGroup.add("group");
        spacer.alignment = ["fill", "fill"];
        spacer.minimumSize.width = 0;

        var btnRightGroup = btnRowGroup.add("group");
        btnRightGroup.alignChildren = ["right", "center"];
        btnRightGroup.spacing = BUTTON_ROW_SPACING;

        return { rowGroup: btnRowGroup, leftGroup: btnLeftGroup, rightGroup: btnRightGroup };
    }

    /**
     * 左のグループにボタンが無い（右のボタンだけの）行を、ダイアログの幅に合わせて揃える。
     * 内側の幅（左右の余白を除く）が BUTTON_ROW_CENTER_MAX_WIDTH 以下なら左右中央、それより広ければ右揃えのまま。
     * 幅はレイアウトが決まるまで分からないので、ダイアログを表示した時点（show イベント）で判定する。
     * ボタンをすべて足したあと、show() の前に呼ぶ。centered で作った行や、左にボタンがある行はそのまま
     * @param {{rowGroup: Group, leftGroup: Group|null, rightGroup: Group|null}} buttonRow - addButtonRow() の戻り値
     * @returns {void}
     */
    function alignRightOnlyButtonRow(buttonRow) {
        if (!buttonRow.leftGroup || buttonRow.leftGroup.children.length > 0) return;
        var dialogWindow = buttonRow.rowGroup.window;
        dialogWindow.addEventListener("show", function () {
            if (!buttonRow.leftGroup) return;
            var btnRowGroup = buttonRow.rowGroup;
            /* 行の幅＝ダイアログの内側の幅（左右の余白を除く）/ The row spans the dialog's inner width (margins excluded) */
            if (!btnRowGroup.size || btnRowGroup.size.width > BUTTON_ROW_CENTER_MAX_WIDTH) return;
            /* 左のグループとスペーサーを外し、右のグループだけを中央に置く / Drop the left group and the spacer so only the right group remains, centered */
            btnRowGroup.remove(buttonRow.leftGroup);
            btnRowGroup.remove(btnRowGroup.children[0]); /* 左のグループを外すと先頭はスペーサー / the spacer is first once the left group is gone */
            btnRowGroup.alignment = ["center", "bottom"];
            btnRowGroup.alignChildren = ["center", "center"];
            buttonRow.leftGroup = null;
            dialogWindow.layout.layout(true);
        });
    }

    // ボタン行（再利用パーツ）ここまで / End of the reusable button row

    // ステップボタン（再利用パーツ） / Stepper buttons (reusable)

    // -----------------------------------------
    // ステップボタンの寸法・増減量 / Stepper metrics and steps
    // -----------------------------------------
    var STEPPER_BUTTON_WIDTH   = 20;  /* ∧∨ボタンの幅 / button width */
    var STEPPER_BUTTON_HEIGHT  = 11;  /* ∧∨ボタン1つの高さ（2つ重ねた全体の高さは22） / button height (22 for the pair) */
    var STEPPER_CORNER_RADIUS  = 2;   /* 枠の角丸の半径（ScriptUIは円弧を描けないため短い線分で近似） / corner radius, approximated with segments */
    var STEPPER_FIELD_SPACING  = 3;   /* 項目名と∧∨の間隔 / spacing between the label and the stepper */
    var STEPPER_SIDE_MARGIN    = 3;   /* ∧∨の左に足す余白（右は入力欄に突き合わせる） / extra space left of the stepper */
    var STEPPER_SHIFT_MULTIPLE = 10;  /* shift＋クリックでそろえる倍数 / Shift-click snaps to multiples of this */
    var STEPPER_OPTION_STEP    = 0.1; /* option＋クリックの増減量 / Option-click step */

    /* 単位の換算は UnitValue に任せる（in / ft / yd / mm / cm / m / pt / pc / px ほか、単数形・複数形も可）。
       UnitValue に無い単位だけ、ここで UnitValue の単位に読み替える（値は「1単位＝何 unit か」）。
       「p」は「1p6」（1パイカ6ポイント）の形にも使う
       Units UnitValue lacks, mapped onto UnitValue units (how many of `unit` make one) */
    var STEPPER_UNIT_ALIASES = {
        "q": { unit: "mm", amount: 0.25 }, /* 級 / Q */
        "h": { unit: "mm", amount: 0.25 }, /* 歯 / H */
        "p": { unit: "pc", amount: 1 }     /* パイカ / pica */
    };

    // -----------------------------------------
    // ステップボタンの配色 / Stepper colors
    // -----------------------------------------
    var STEPPER_UI_DARK           = isDarkUI();
    /* UIの明るさは4段階あり、段階ごとに背景色が違う。どの段階でも背景に対する差で見せるよう、黒・白の半透明を重ねる。
       ダーク側は Illustrator 標準のスピナー（［グリッドに分割］）で実測、明るい側は最も明るい段階（背景 約0.94）から逆算
       UI brightness has four levels with different backgrounds, so colors are translucent overlays that follow the
       dialog background. Dark values are measured from Illustrator's own spinner; light values derived for the lightest level */
    var STEPPER_FILL_COLOR        = STEPPER_UI_DARK ? [0, 0, 0, 0.10]  : [1, 1, 1, 0.50];  /* 地 / background */
    var STEPPER_FRAME_COLOR       = STEPPER_UI_DARK ? [1, 1, 1, 0.07]  : [0, 0, 0, 0.10];  /* 枠線 / frame */
    var STEPPER_PRESSED_COLOR     = STEPPER_UI_DARK ? [1, 1, 1, 0.12]  : [0, 0, 0, 0.13];  /* 押下中 / pressed */
    var STEPPER_CHEVRON_COLOR     = STEPPER_UI_DARK ? [1, 1, 1, 1]     : [0, 0, 0, 0.70];  /* 山形の線 / chevron */
    var STEPPER_DIM_FILL_COLOR    = STEPPER_UI_DARK ? [1, 1, 1, 0.035] : [1, 1, 1, 0.30];  /* 無効時の地 / background when disabled */
    var STEPPER_DIM_FRAME_COLOR   = STEPPER_UI_DARK ? [1, 1, 1, 0.035] : [0, 0, 0, 0.05];  /* 無効時の枠線（ダークは地と同じで見せない） / frame when disabled */
    var STEPPER_DIM_CHEVRON_COLOR = STEPPER_UI_DARK ? [1, 1, 1, 0.20]  : [0, 0, 0, 0.25];  /* 無効時の山形 / chevron when disabled */

    // -----------------------------------------
    // 数値欄を作る（外から呼ぶ関数） / Public API
    // -----------------------------------------
    /**
     * 「項目名・∧∨・入力欄」をひと組にした数値欄を追加する。
     * ↑↓キーでも∧∨と同じように増減する。直接入力した値も、フォーカスが外れたときに
     * 整数化・下限・上限・単位（「20 mm」の形）へそろえ、数値でなければ直前の値に戻す。
     * 四則演算（+ - * / と括弧）を入れると、確定時に計算した値にする。欄と違う単位で入れた値は欄の単位へ換算する（mm の欄に「1 in」→「25.4 mm」）
     * @param {Group|Panel} parent - 追加先
     * @param {Object} fieldOptions - label（コロン込みの項目名）/ labelWidth / text / characters /
     *     step / min / max / integer（true で整数のみ）/ unit / onStep
     * @returns {EditText} 入力欄（項目名は .fieldLabel、∧∨は .stepperGroup で参照できる）
     */
    function addSteppedField(parent, fieldOptions) {
        var fieldRowGroup = parent.add("group");
        fieldRowGroup.orientation = "row";
        fieldRowGroup.alignChildren = ["left", "center"];
        fieldRowGroup.spacing = STEPPER_FIELD_SPACING;

        var fieldLabel = fieldRowGroup.add("statictext", undefined, fieldOptions.label || "");
        if (fieldOptions.labelWidth) {
            fieldLabel.preferredSize.width = fieldOptions.labelWidth;
            fieldLabel.justify = "right";
        }

        /* ∧∨と入力欄は隙間0で突き合わせる / butt the stepper against the field */
        var stepperInputGroup = fieldRowGroup.add("group");
        stepperInputGroup.orientation = "row";
        stepperInputGroup.alignChildren = ["left", "center"];
        stepperInputGroup.spacing = 0;
        stepperInputGroup.margins = 0;

        var numberInput;
        var stepperGroup = addStepper(stepperInputGroup, function () { return numberInput; }, fieldOptions);
        numberInput = stepperInputGroup.add("edittext", undefined, fieldOptions.text || "");
        numberInput.characters = fieldOptions.characters || 6;
        numberInput.fieldLabel = fieldLabel;
        numberInput.stepperGroup = stepperGroup;

        /* ↑↓キーも∧∨と同じ処理で増減する（増減量・下限・上限・単位・修飾キーをそろえる） / arrow keys share the stepper's logic */
        bindSteppedArrowKeys(numberInput, stepperGroup);

        /* 項目名のクリックで入力欄にフォーカスを移す / clicking the label focuses the field */
        fieldLabel.addEventListener("click", function () { focusNumberInput(numberInput); });

        /* 直接入力をそろえる。計算式は計算し、数値でなければ直前の値に戻す / normalize typed values; evaluate arithmetic, revert non-numbers */
        numberInput.lastValidText = numberInput.text;
        numberInput.onChange = function () {
            var value = evaluateArithmetic(numberInput.text, fieldOptions.unit);
            if (isNaN(value)) {
                numberInput.text = numberInput.lastValidText;
                return;
            }
            writeSteppedValue(numberInput, value, fieldOptions);
        };
        return numberInput;
    }

    /**
     * 数値欄の有効／無効を、項目名・∧∨ごとまとめて切り替える
     * @param {EditText} numberInput - addSteppedField() で作った入力欄
     * @param {boolean} isEnabled - 有効にするなら true
     * @returns {void}
     */
    function setSteppedFieldEnabled(numberInput, isEnabled) {
        numberInput.enabled = isEnabled;
        numberInput.fieldLabel.enabled = isEnabled;
        numberInput.stepperGroup.enabled = isEnabled;
        /* ∧∨は自作描画なので、描き直してディム表示を切り替える / redraw the custom-drawn buttons to update the dimming */
        for (var i = 0; i < numberInput.stepperGroup.children.length; i++) {
            redrawStepperGroup(numberInput.stepperGroup.children[i]);
        }
    }

    /**
     * 入力欄の値を増減する∧∨ボタンを、隙間なく縦に積んで追加する
     * @param {Group|Panel} parent - 追加先
     * @param {Function} getNumberInput - 対象の入力欄を返す関数（入力欄を∧∨より後に作れるよう、クリック時に引く）
     * @param {Object} stepOptions - step（増減量）/ min / max / integer / unit（例 " mm"）/ onStep(numberInput)
     * @returns {Group} ∧∨をまとめた group（.stepBy(direction) で同じ増減を呼べる）
     */
    function addStepper(parent, getNumberInput, stepOptions) {
        var stepperGroup = parent.add("group");
        stepperGroup.orientation = "column";
        stepperGroup.spacing = 0; /* 2つのボタンをつなげて1つの枠に見せる / join the buttons into one frame */
        stepperGroup.margins = [STEPPER_SIDE_MARGIN, 0, 0, 0]; /* 右は入力欄に突き合わせる / butt against the field on the right */
        stepperGroup.alignment = ["left", "center"];

        /**
         * 入力欄の値を増減する（shift を押しながらなら STEPPER_SHIFT_MULTIPLE の倍数へ、option なら STEPPER_OPTION_STEP ずつ。下限・上限で止める）
         * @param {number} direction - 増やすなら 1、減らすなら -1
         * @returns {void}
         */
        function stepBy(direction) {
            var numberInput = getNumberInput();
            if (!isStepperEnabledInTree(numberInput)) return; /* 入力欄か親が無効の間は動かさない */
            var value = evaluateArithmetic(numberInput.text, stepOptions.unit); /* 確定前の計算式も計算してから増減 / evaluate an uncommitted expression first */
            if (isNaN(value)) value = parseFloat(numberInput.text); /* 計算できなければ従来どおり先頭の数値 / fall back to the leading number */
            if (isNaN(value)) value = 0;
            writeSteppedValue(numberInput, computeSteppedValue(value, direction, stepOptions), stepOptions);
            if (stepOptions.onStep) stepOptions.onStep(numberInput);
        }

        /**
         * ∧∨を離したときに入力欄へフォーカスを移す（mousedown で移しても、離したときに外れる）
         * @param {Group} chevronButton - makeStepperChevronButton() で作ったボタン
         * @returns {Group} 渡したボタン
         */
        function focusInputOnRelease(chevronButton) {
            chevronButton.addEventListener("mouseup", function () {
                var numberInput = getNumberInput();
                if (isStepperEnabledInTree(numberInput)) focusNumberInput(numberInput);
            });
            return chevronButton;
        }

        /* 整数の欄では option＋クリックの0.1刻みが効かないので、説明から外す / integer fields have no 0.1 step */
        var upTooltip = stepOptions.integer ? LABELS.tooltip.stepUpInteger : LABELS.tooltip.stepUp;
        var downTooltip = stepOptions.integer ? LABELS.tooltip.stepDownInteger : LABELS.tooltip.stepDown;
        focusInputOnRelease(makeStepperChevronButton(stepperGroup, "up", function () { stepBy(1); })).helpTip = getLabel(upTooltip);
        focusInputOnRelease(makeStepperChevronButton(stepperGroup, "down", function () { stepBy(-1); })).helpTip = getLabel(downTooltip);
        stepperGroup.stepBy = stepBy; /* ↑↓キーからも同じ処理で増減できるよう公開 / shared with the arrow keys */
        stepperGroup.stepOptions = stepOptions; /* 確定時の計算で欄の単位を引けるよう公開 / lets the commit-time evaluation find the unit */
        return stepperGroup;
    }

    /**
     * 入力欄の↑↓キーを、∧∨と同じ処理で増減させる。ほかのキーは素通し。
     * あわせて、確定時に計算式・単位付きの値を計算して書き戻す（各スクリプトの onChange より先に呼ばれるので、onChange は計算後の値を読む）
     * @param {EditText} numberInput - 対象の入力欄
     * @param {Group} stepperGroup - addStepper() で作った∧∨
     * @returns {void}
     */
    function bindSteppedArrowKeys(numberInput, stepperGroup) {
        numberInput.addEventListener("keydown", function (event) {
            if (event.keyName !== "Up" && event.keyName !== "Down") return;
            stepperGroup.stepBy(event.keyName === "Up" ? 1 : -1);
            event.preventDefault(); /* カーソル移動を止める / keep the caret from moving */
        });
        numberInput.addEventListener("change", function () {
            var fieldUnit = stepperGroup.stepOptions ? stepperGroup.stepOptions.unit : undefined;
            var value = evaluateArithmetic(numberInput.text, fieldUnit);
            if (isNaN(value)) return; /* 計算できなければ各スクリプトの処理に任せる / leave it to the script's own handler */
            /* 式か、換算で値が変わったときだけ書き戻す（ただの数値は書式を崩さない） / rewrite only expressions and converted values */
            var hasOperator = /[*\/()\u00D7\u00F7\uFF0A\uFF0F\uFF08\uFF09]|[\d.\uFF10-\uFF19][^\d.\uFF10-\uFF19]*[+\-\u2212\uFF0B\uFF0D]/.test(numberInput.text);
            if (!hasOperator && value === parseFloat(numberInput.text)) return;
            numberInput.text = formatStepperNumber(value) + (fieldUnit || "");
        });
    }

    // -----------------------------------------
    // 値の計算 / Value helpers
    // -----------------------------------------
    /**
     * 押された修飾キーに応じて、1回分増減した値を返す
     * （shift なら STEPPER_SHIFT_MULTIPLE の倍数へ、option なら STEPPER_OPTION_STEP ずつ、それ以外は step の倍数へ（1.5→2、1.5→1）。
     * 整数の欄では option を無視して step の倍数へ）
     * @param {number} value - 元の値
     * @param {number} direction - 増やすなら 1、減らすなら -1
     * @param {Object} stepOptions - step（通常の増減量。省略時は 1）/ integer
     * @returns {number} 増減した値（下限・上限は未適用）
     */
    function computeSteppedValue(value, direction, stepOptions) {
        var keyState = ScriptUI.environment.keyboardState;
        if (keyState.shiftKey) return snapStepperToNextMultiple(value, STEPPER_SHIFT_MULTIPLE, direction);
        if (keyState.altKey && !stepOptions.integer) return value + direction * STEPPER_OPTION_STEP;
        return snapStepperToNextMultiple(value, stepOptions.step || 1, direction);
    }

    /**
     * 値を、指定した方向にある次の倍数へ移す（230→240、232→240、下げるときは 232→230、230→220）
     * @param {number} value - 元の値
     * @param {number} multiple - 倍数の単位（例 10）
     * @param {number} direction - 上げるなら 1、下げるなら -1
     * @returns {number} 移した値
     */
    function snapStepperToNextMultiple(value, multiple, direction) {
        /* 0.29 / 0.01 = 28.999… のような浮動小数の誤差で同じ値に戻らないよう、商を丸めてから切り捨て・切り上げる
           round the quotient first so float error (0.29 / 0.01 = 28.999…) does not step back to the same value */
        var quotient = Math.round(value / multiple * 1e6) / 1e6;
        if (direction > 0) return Math.round((Math.floor(quotient) + 1) * multiple * 1e6) / 1e6;
        return Math.round((Math.ceil(quotient) - 1) * multiple * 1e6) / 1e6;
    }

    /**
     * 値を下限・上限の範囲に収める
     * @param {number} value - 数値
     * @param {Object} rangeOptions - min / max（どちらも省略可）
     * @returns {number} 範囲に収めた値
     */
    function clampSteppedValue(value, rangeOptions) {
        if (rangeOptions.min !== undefined && value < rangeOptions.min) return rangeOptions.min;
        if (rangeOptions.max !== undefined && value > rangeOptions.max) return rangeOptions.max;
        return value;
    }

    /**
     * 入力欄の文字列を四則演算（+ - * / と括弧）として計算する。eval は使わない。
     * 数値の後ろの単位は UnitValue で欄の単位へ換算する（mm の欄に「1in」→ 25.4、「1p6」は1パイカ6ポイント）。単位のない数値は欄の単位とみなす。
     * 全角の数字・記号と × ÷ は半角に直す
     * @param {string} text - 入力欄の文字列
     * @param {string} [fieldUnit] - 欄の単位（例 " mm"。前後の空白は無視）
     * @returns {number} 欄の単位での計算結果（式として読めない・換算できない単位・0で割ったときは NaN）
     */
    function evaluateArithmetic(text, fieldUnit) {
        var source = String(text)
            .replace(/[！-～]/g, function (ch) { return String.fromCharCode(ch.charCodeAt(0) - 0xFEE0); })
            .replace(/×/g, "*")
            .replace(/÷/g, "/")
            .replace(/[−–—]/g, "-")
            .replace(/\s/g, "");
        if (source === "") return NaN;
        var fieldUnitKey = String(fieldUnit || "").replace(/^\s+|\s+$/g, "").toLowerCase();
        var fieldUnitValue = createStepperUnitValue(1, fieldUnitKey); /* 欄の単位の1単位（換算できない欄は null） / one field unit */
        var position = 0;

        /**
         * 加減算の並び（項 ± 項 …）を読む
         * @returns {number} 値（読めなければ NaN）
         */
        function readSum() {
            var total = readProduct();
            while (position < source.length && (source.charAt(position) === "+" || source.charAt(position) === "-")) {
                var operator = source.charAt(position++);
                var operand = readProduct();
                total = (operator === "+") ? total + operand : total - operand;
            }
            return total;
        }

        /**
         * 乗除算の並び（因子 × 因子 …）を読む
         * @returns {number} 値（読めなければ NaN）
         */
        function readProduct() {
            var total = readFactor();
            while (position < source.length && (source.charAt(position) === "*" || source.charAt(position) === "/")) {
                var operator = source.charAt(position++);
                var operand = readFactor();
                if (operator === "/" && operand === 0) return NaN;
                total = (operator === "*") ? total * operand : total / operand;
            }
            return total;
        }

        /**
         * 符号付きの数値（単位付きなら欄の単位へ換算）か、括弧で囲んだ式を読む
         * @returns {number} 値（読めなければ NaN）
         */
        function readFactor() {
            var ch = source.charAt(position);
            if (ch === "+" || ch === "-") {
                position++;
                var signedValue = readFactor();
                return (ch === "-") ? -signedValue : signedValue;
            }
            if (ch === "(") {
                position++;
                var innerValue = readSum();
                if (source.charAt(position) !== ")") return NaN;
                position++;
                return innerValue;
            }
            var numberMatch = /^(\d+\.?\d*|\.\d+)/.exec(source.substring(position));
            if (!numberMatch) return NaN;
            position += numberMatch[0].length;
            return readUnitSuffix(parseFloat(numberMatch[0]));
        }

        /**
         * 数値の直後の単位を読み、欄の単位へ換算する
         * @param {number} value - 単位の前の数値
         * @returns {number} 欄の単位での値（換算できない単位なら NaN）
         */
        function readUnitSuffix(value) {
            var unitMatch = /^([A-Za-z]+|%|°)/.exec(source.substring(position));
            if (!unitMatch) return value; /* 単位なしは欄の単位 / no unit means the field's unit */
            position += unitMatch[0].length;
            var unitKey = unitMatch[0].toLowerCase();
            if (unitKey === fieldUnitKey) return value;
            var typedValue = createStepperUnitValue(value, unitKey);
            if (!typedValue || !fieldUnitValue) return NaN; /* 知らない単位・単位のない欄 / unknown unit or unitless field */
            var points = typedValue.as("pt");
            /* 「1p6」＝1パイカ6ポイント / pica-point notation */
            if (unitKey === "p") {
                var pointMatch = /^(\d+\.?\d*|\.\d+)/.exec(source.substring(position));
                if (pointMatch) {
                    position += pointMatch[0].length;
                    points += parseFloat(pointMatch[0]);
                }
            }
            return points / fieldUnitValue.as("pt");
        }

        var result = readSum();
        if (position !== source.length || !isFinite(result)) return NaN; /* 読み残しがあれば式として不正 / leftovers mean a malformed expression */
        return result;
    }

    /**
     * 数値と単位から UnitValue を作る。Q・H・p は STEPPER_UNIT_ALIASES で UnitValue の単位に読み替える。
     * %（percent）は基準の長さが無いと換算できないので扱わない
     * @param {number} value - 数値
     * @param {string} unitKey - 単位（小文字。例 "mm"、"inches"、"q"）
     * @returns {UnitValue|null} UnitValue（UnitValue が知らない単位・空・% なら null）
     */
    function createStepperUnitValue(value, unitKey) {
        if (unitKey === "" || unitKey === "%") return null;
        var alias = STEPPER_UNIT_ALIASES[unitKey];
        var unitValue = alias ? new UnitValue(value * alias.amount, alias.unit) : new UnitValue(value, unitKey);
        if (unitValue.type === "?" || unitValue.type === "%") return null; /* 知らない単位は例外にならず "?" になる。"percent" も除く / unknown units become "?" */
        return unitValue;
    }

    /**
     * 値を整数化・下限・上限でそろえ、単位を付けて入力欄に書き込む（直前の正しい値としても控える）
     * @param {EditText} numberInput - 書き込む入力欄
     * @param {number} value - 数値
     * @param {Object} valueOptions - integer / min / max / unit（どれも省略可）
     * @returns {void}
     */
    function writeSteppedValue(numberInput, value, valueOptions) {
        numberInput.text = formatSteppedValue(value, valueOptions);
        numberInput.lastValidText = numberInput.text;
    }

    /**
     * 値を整数化・下限・上限でそろえ、丸めて単位を付けた表示用の文字列にする。
     * 整数化してから下限で止めるので、「整数・下限1」の欄に 0.4 が入っても 1 になる
     * @param {number} value - 数値
     * @param {Object} valueOptions - integer / min / max / unit（どれも省略可）
     * @returns {string} 入力欄に入れる文字列（例 "20 mm"）
     */
    function formatSteppedValue(value, valueOptions) {
        if (valueOptions.integer) value = Math.round(value);
        return formatStepperNumber(clampSteppedValue(value, valueOptions)) + (valueOptions.unit || "");
    }

    /**
     * 小数第2位で丸めた数値を文字列で返す
     * @param {number} value - 数値
     * @returns {string} 表示用の数値文字列
     */
    function formatStepperNumber(value) {
        return String(Math.round(value * 100) / 100);
    }

    // -----------------------------------------
    // ∧∨ボタンの描画 / Drawing
    // -----------------------------------------
    /**
     * 山形（∧／∨）の極小ボタンを作成する。
     * 上下2つを隙間なく積んで1つの枠に見えるよう、枠線は外側の辺だけ描き（上ボタンは上側、下ボタンは下側）、
     * 継ぎ目に線は引かない
     * @param {Group|Panel} parent - 追加先
     * @param {string} direction - "up" または "down"
     * @param {Function} onClickFn - クリック時の処理
     * @returns {Group} ボタンとして使う group
     */
    function makeStepperChevronButton(parent, direction, onClickFn) {
        var buttonWidth = STEPPER_BUTTON_WIDTH;
        var buttonHeight = STEPPER_BUTTON_HEIGHT;
        var isUp = (direction === "up");
        var chevronBox = parent.add("group");
        chevronBox.margins = 0;
        chevronBox.spacing = 0;
        chevronBox.preferredSize = [buttonWidth, buttonHeight];
        chevronBox.minimumSize = [buttonWidth, buttonHeight];
        chevronBox.maximumSize = [buttonWidth, buttonHeight];
        chevronBox.isPressed = false;
        chevronBox.isStepperButton = true; /* redrawSteppersIn() の目印 / marker for redrawSteppersIn() */

        chevronBox.onDraw = function () {
            var boxGraphics = chevronBox.graphics;
            /* 自作描画は自動でディムにならないため、無効なら薄い色で描く。親の無効化は子の enabled に出ないので親も見る
               Custom drawing is not dimmed automatically; the parent's state does not reach the child's enabled */
            var isDimmed = !isStepperEnabledInTree(chevronBox);

            /* 枠線の内側の地（押下中は押下色） / background inside the frame, pressed color while pressed */
            var fillColor = isDimmed ? STEPPER_DIM_FILL_COLOR : (chevronBox.isPressed ? STEPPER_PRESSED_COLOR : STEPPER_FILL_COLOR);
            boxGraphics.newPath();
            boxGraphics.rectPath(1, isUp ? 1 : 0, buttonWidth - 2, buttonHeight - 1);
            boxGraphics.fillPath(boxGraphics.newBrush(boxGraphics.BrushType.SOLID_COLOR, fillColor));

            drawStepperFrame(boxGraphics, buttonWidth, buttonHeight, isUp, isDimmed ? STEPPER_DIM_FRAME_COLOR : STEPPER_FRAME_COLOR);
            drawStepperChevron(boxGraphics, buttonWidth, buttonHeight, isUp, isDimmed ? STEPPER_DIM_CHEVRON_COLOR : STEPPER_CHEVRON_COLOR);
        };

        /**
         * 押下状態を変えて描き直す
         * @param {boolean} isPressed - 押下中なら true
         * @returns {void}
         */
        function repaint(isPressed) {
            if (chevronBox.isPressed === isPressed) return;
            chevronBox.isPressed = isPressed;
            redrawStepperGroup(chevronBox);
        }
        chevronBox.addEventListener("mousedown", function () {
            if (!isStepperEnabledInTree(chevronBox)) return;
            repaint(true);
            if (onClickFn) onClickFn();
        });
        chevronBox.addEventListener("mouseup", function () { repaint(false); });
        /* 押したまま外へ出たときも押下色を残さない / reset when the pointer leaves while pressed */
        chevronBox.addEventListener("mouseout", function () { repaint(false); });
        return chevronBox;
    }

    /**
     * 外側の辺だけの枠を描く（角は丸める）。継ぎ目側は開けておき、上下2つで1つの枠に見せる。
     * ScriptUI は円弧を描けないため、角丸は短い線分で近似する
     * @param {ScriptUIGraphics} boxGraphics - 描画先
     * @param {number} boxWidth - ボタンの幅
     * @param {number} boxHeight - ボタンの高さ
     * @param {boolean} isUp - 上のボタンなら true（上側に枠を描く）
     * @param {number[]} frameColor - [r, g, b, a]
     * @returns {void}
     */
    function drawStepperFrame(boxGraphics, boxWidth, boxHeight, isUp, frameColor) {
        var frameLeft = 0.5;
        var frameRight = boxWidth - 0.5;
        var outerY = isUp ? 0.5 : boxHeight - 0.5;
        var seamY = isUp ? boxHeight : 0;
        var towardSeam = isUp ? 1 : -1; /* 外側の辺から継ぎ目へ向かう向き / direction from the outer edge to the seam */
        var radius = STEPPER_CORNER_RADIUS;
        var arcSteps = 4; /* 角丸1つを何本の線分で近似するか / segments per corner */
        var angle, k;

        boxGraphics.newPath();
        boxGraphics.moveTo(frameLeft, seamY);
        /* 左の角丸 / left corner */
        for (k = 0; k <= arcSteps; k++) {
            angle = (Math.PI / 2) * k / arcSteps;
            boxGraphics.lineTo(frameLeft + radius - radius * Math.cos(angle), outerY + towardSeam * (radius - radius * Math.sin(angle)));
        }
        /* 右の角丸 / right corner */
        for (k = 0; k <= arcSteps; k++) {
            angle = (Math.PI / 2) * k / arcSteps;
            boxGraphics.lineTo(frameRight - radius + radius * Math.sin(angle), outerY + towardSeam * (radius - radius * Math.cos(angle)));
        }
        boxGraphics.lineTo(frameRight, seamY);
        boxGraphics.strokePath(boxGraphics.newPen(boxGraphics.PenType.SOLID_COLOR, frameColor, 1));
    }

    /**
     * 山形（∧／∨）を描く。文字グリフの▲▼は上下で大きさやベースラインが揃わないため、線で描く
     * @param {ScriptUIGraphics} boxGraphics - 描画先
     * @param {number} boxWidth - ボタンの幅
     * @param {number} boxHeight - ボタンの高さ
     * @param {boolean} isUp - ∧なら true、∨なら false
     * @param {number[]} chevronColor - [r, g, b, a]
     * @returns {void}
     */
    function drawStepperChevron(boxGraphics, boxWidth, boxHeight, isUp, chevronColor) {
        var centerX = boxWidth / 2;
        var centerY = isUp ? boxHeight / 2 + 0.5 : boxHeight / 2 - 0.5; /* 継ぎ目から少し離す / nudged away from the seam */
        var halfWidth = 3.6; /* 山形の半幅（高さ1.8に対して開き約127°） / half width of the chevron */
        var tipOffsetY = isUp ? -1.8 : 1.8; /* 頂点の中心からのずれ（上向きは上、下向きは下） */
        boxGraphics.newPath();
        boxGraphics.moveTo(centerX - halfWidth, centerY - tipOffsetY);
        boxGraphics.lineTo(centerX, centerY + tipOffsetY);
        boxGraphics.lineTo(centerX + halfWidth, centerY - tipOffsetY);
        boxGraphics.strokePath(boxGraphics.newPen(boxGraphics.PenType.SOLID_COLOR, chevronColor, 1.2));
    }

    /**
     * 入力欄にフォーカスを移す
     * @param {EditText} numberInput - 対象の入力欄
     * @returns {void}
     */
    function focusNumberInput(numberInput) {
        numberInput.active = false; /* 一度外さないとフォーカスが移らないことがある / reset first or focus may not move */
        numberInput.active = true;
    }

    /**
     * コントロールと、その親をたどってすべて有効かを返す（親の無効化は子の enabled に出ない）
     * @param {Object} control - 対象のコントロール
     * @returns {boolean} すべて有効なら true
     */
    function isStepperEnabledInTree(control) {
        for (var node = control; node; node = node.parent) {
            if (!node.enabled) return false;
        }
        return true;
    }

    /**
     * コンテナ以下にある∧∨ボタンをすべて描き直す。行やパネルの enabled を切り替えたあとに呼ぶ
     * @param {Object} container - 行・グループ・パネルなど
     * @returns {void}
     */
    function redrawSteppersIn(container) {
        if (!container.children) return;
        for (var i = 0; i < container.children.length; i++) {
            var child = container.children[i];
            if (child.isStepperButton) redrawStepperGroup(child);
            else redrawSteppersIn(child);
        }
    }

    /**
     * group の onDraw を呼び直す。group には notify() が無いため、隠して再表示して描き直させる
     * @param {Group} targetGroup - 描き直す group
     * @returns {void}
     */
    function redrawStepperGroup(targetGroup) {
        targetGroup.hide();
        targetGroup.show();
    }

    // ステップボタン（再利用パーツ）ここまで / End of the reusable stepper

    /**
     * 入力欄の直前にある項目名のクリックで、入力欄にフォーカスを移す（addSteppedField() の項目名と同じ挙動。無効の間は移さない）。
     * 単位や「→」に付けないよう、行の先頭にあるか末尾がコロンの statictext だけを項目名とみなす
     * @param {Group} stepperFieldGroup - ∧∨と入力欄をまとめた group（追加した直後で、親の末尾にある）
     * @param {EditText} numberInput - 入力欄
     * @returns {void}
     */
    function focusInputOnPrecedingLabel(stepperFieldGroup, numberInput) {
        var siblings = stepperFieldGroup.parent.children;
        if (siblings.length < 2) return;
        var labelIndex = siblings.length - 2;
        var fieldLabel = siblings[labelIndex];
        if (fieldLabel.type !== "statictext") return;
        if (labelIndex > 0 && !/[:：]\s*$/.test(fieldLabel.text)) return;
        fieldLabel.addEventListener("click", function () {
            if (isStepperEnabledInTree(numberInput)) focusNumberInput(numberInput);
        });
    }

    /**
     * ∧∨付きの数値欄を追加する（∧∨と入力欄は隙間0で突き合わせ、↑↓キーも∧∨と同じ処理で増減する）
     * @param {Group|Panel} parent - 追加先の行
     * @param {string} initialText - 初期値
     * @param {Object} stepOptions - addStepper() に渡す step / min / max / integer / onStep
     * @returns {EditText} 入力欄（∧∨は .stepperGroup で参照できる）
     */
    function addStepperInput(parent, initialText, stepOptions) {
        var stepperInputGroup = parent.add("group");
        stepperInputGroup.orientation = "row";
        stepperInputGroup.alignChildren = ["left", "center"];
        stepperInputGroup.spacing = 0;
        stepperInputGroup.margins = 0;

        var numberInput;
        var stepperGroup = addStepper(stepperInputGroup, function () { return numberInput; }, stepOptions);
        numberInput = stepperInputGroup.add("edittext", undefined, initialText);
        numberInput.stepperGroup = stepperGroup;
        bindSteppedArrowKeys(numberInput, stepperGroup);
        focusInputOnPrecedingLabel(stepperInputGroup, numberInput);
        return numberInput;
    }

    (function () {
        if (app.documents.length === 0) {
            alert(getLabel("alert.noDoc"));
            return;
        }

        var doc = app.activeDocument;

        // ===== Zoom (view) helpers =====
        var __SCM_VIEW = null;
        var __SCM_ORG_ZOOM = null;
        var __SCM_ORG_CENTER = null;

        try {
            __SCM_VIEW = doc.views[0];
            __SCM_ORG_ZOOM = __SCM_VIEW.zoom;
            __SCM_ORG_CENTER = __SCM_VIEW.centerPoint;
        } catch (e) { }

        /* アクティブアートボードの中心座標を返す / Return the center point of the active artboard */
        function __SCM_getActiveArtboardCenterPoint() {
            try {
                var idx = doc.artboards.getActiveArtboardIndex();
                var r = doc.artboards[idx].artboardRect; // [L, T, R, B]
                return [r[0] + (r[2] - r[0]) / 2, r[1] + (r[3] - r[1]) / 2];
            } catch (e) { }
            try { return (__SCM_VIEW && __SCM_VIEW.centerPoint) ? __SCM_VIEW.centerPoint : [0, 0]; } catch (e) { }
            return [0, 0];
        }

        /* ズーム倍率をIllustratorの許容範囲に丸める / Clamp zoom factor to Illustrator's allowed range */
        function __SCM_clampZoomFactor(z) {
            if (z < 0.0313) z = 0.0313;
            if (z > 640.0) z = 640.0;
            return z;
        }

        /* パーセント指定でビューをズーム（パン維持）/ Zoom the view by percent (keeping pan) */
        function __SCM_applyZoomPct(pct) {
            try {
                if (!__SCM_VIEW) return;
                var p = Number(pct);
                if (isNaN(p)) return;
                if (p < 10) p = 10;
                if (p > 1600) p = 1600;
                var z = __SCM_clampZoomFactor(p / 100.0);
                __SCM_VIEW.zoom = z;
                // Keep current pan offsets when zoom changes
                __SCM_applyViewCenterWithPan();
                app.redraw();
            } catch (e) { }
        }

        // ===== Pan (view center) helpers =====
        var __SCM_PAN_X = 0; // pt
        var __SCM_PAN_Y = 0; // pt (positive => down)

        /* アートボードサイズからパンの可動範囲(pt)を求める / Derive pan range (pt) from artboard size */
        function __SCM_getPanRangePt() {
            // Range is based on active artboard size.
            // Use half of width/height (pt) as max, with safety clamps.
            try {
                var idx = doc.artboards.getActiveArtboardIndex();
                var r = doc.artboards[idx].artboardRect; // [L, T, R, B]
                var w = Math.abs(r[2] - r[0]);
                var h = Math.abs(r[1] - r[3]);
                var xMax = Math.round(w / 2);
                var yMax = Math.round(h / 2);
                if (!xMax || xMax < 100) xMax = 100;
                if (!yMax || yMax < 100) yMax = 100;
                // avoid extreme ranges
                if (xMax > 50000) xMax = 50000;
                if (yMax > 50000) yMax = 50000;
                return { xMax: xMax, yMax: yMax };
            } catch (e) { }
            return { xMax: 2000, yMax: 2000 };
        }

        /* パン量を反映してビュー中心を設定 / Set the view center reflecting the current pan offsets */
        function __SCM_applyViewCenterWithPan() {
            try {
                if (!__SCM_VIEW) return;
                var c = __SCM_getActiveArtboardCenterPoint();
                var x = c[0] + Number(__SCM_PAN_X || 0);
                // Illustrator's Y axis increases upward; treat positive panY as "down" for UI.
                var y = c[1] - Number(__SCM_PAN_Y || 0);
                __SCM_VIEW.centerPoint = [x, y];
                app.redraw();
            } catch (e) { }
        }

        /* 左右パンを範囲内に丸めて適用 / Clamp and apply horizontal pan */
        function __SCM_applyPanX(v) {
            try {
                var n = Number(v);
                if (isNaN(n)) n = 0;
                var rg = __SCM_getPanRangePt();
                var mx = rg.xMax;
                if (n < -mx) n = -mx;
                if (n > mx) n = mx;
                __SCM_PAN_X = n;
                __SCM_applyViewCenterWithPan();
            } catch (e) { }
        }

        /* 上下パンを範囲内に丸めて適用 / Clamp and apply vertical pan */
        function __SCM_applyPanY(v) {
            try {
                var n = Number(v);
                if (isNaN(n)) n = 0;
                var rg = __SCM_getPanRangePt();
                var my = rg.yMax;
                if (n < -my) n = -my;
                if (n > my) n = my;
                __SCM_PAN_Y = n;
                __SCM_applyViewCenterWithPan();
            } catch (e) { }
        }

        /* ================================
         * Japan Holidays (2020-2035) built-in
         * - Includes substitute holidays (振替休日) and citizen's holidays (国民の休日)
         * - Handles 2020/2021 Olympic special holiday moves
         * ================================ */
        function __pad2(n) { return (n < 10) ? ("0" + n) : String(n); }
        function __dateKey(y, m1, d) { return y + "-" + __pad2(m1) + "-" + __pad2(d); }
        function __isLeap(y) { return (y % 4 === 0 && y % 100 !== 0) || (y % 400 === 0); }
        /* 指定年月の日数を返す / Return the number of days in a given year/month */
        function __daysInMonth(y, m1) {
            var md = [31, (__isLeap(y) ? 29 : 28), 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
            return md[m1 - 1];
        }
        function __dow(y, m1, d) { return (new Date(y, m1 - 1, d)).getDay(); } // 0=Sun..6
        /* 第n・指定曜日の日を返す / Return the date of the nth given weekday */
        function __nthWeekday(y, m1, weekday0Sun, nth) {
            // weekday0Sun: 0=Sun..6
            var firstDow = __dow(y, m1, 1);
            var offset = (weekday0Sun - firstDow + 7) % 7;
            var day = 1 + offset + (nth - 1) * 7;
            return day;
        }
        /* 春分の日を近似計算(1980-2099) / Approximate the vernal equinox day (1980-2099) */
        function __vernalEquinoxDay(y) {
            // Approximation valid for 1980-2099
            return Math.floor(20.8431 + 0.242194 * (y - 1980) - Math.floor((y - 1980) / 4));
        }
        /* 秋分の日を近似計算(1980-2099) / Approximate the autumn equinox day (1980-2099) */
        function __autumnEquinoxDay(y) {
            // Approximation valid for 1980-2099
            return Math.floor(23.2488 + 0.242194 * (y - 1980) - Math.floor((y - 1980) / 4));
        }
        /* 指定年の祝日マップを生成（振替・国民の休日含む）/ Build the year's holiday map (incl. substitute & citizen's holidays) */
        function __buildHolidaysForYear(y) {
            var map = {};
            function add(m1, d, name) { map[__dateKey(y, m1, d)] = name; }

            // Fixed / rule-based holidays
            add(1, 1, "元日");
            add(1, __nthWeekday(y, 1, 1, 2), "成人の日"); // 2nd Mon
            add(2, 11, "建国記念の日");
            add(2, 23, "天皇誕生日"); // since 2020
            add(3, __vernalEquinoxDay(y), "春分の日");
            add(4, 29, "昭和の日");
            add(5, 3, "憲法記念日");
            add(5, 4, "みどりの日");
            add(5, 5, "こどもの日");

            // Marine / Mountain / Sports (with Olympic special cases)
            if (y === 2020) {
                add(7, 23, "海の日");
                add(7, 24, "スポーツの日");
                add(8, 10, "山の日");
            } else if (y === 2021) {
                add(7, 22, "海の日");
                add(7, 23, "スポーツの日");
                add(8, 8, "山の日"); // substitute handled later
            } else {
                add(7, __nthWeekday(y, 7, 1, 3), "海の日");      // 3rd Mon
                add(8, 11, "山の日");
                add(10, __nthWeekday(y, 10, 1, 2), "スポーツの日"); // 2nd Mon
            }

            add(9, __nthWeekday(y, 9, 1, 3), "敬老の日"); // 3rd Mon
            add(9, __autumnEquinoxDay(y), "秋分の日");
            add(11, 3, "文化の日");
            add(11, 23, "勤労感謝の日");

            // --- Substitute holiday (振替休日): holiday on Sunday -> next non-holiday weekday
            var keys = [];
            for (var k in map) if (map.hasOwnProperty(k)) keys.push(k);
            keys.sort();
            for (var i = 0; i < keys.length; i++) {
                var key = keys[i];
                var parts = key.split("-");
                var m1 = Number(parts[1]);
                var d = Number(parts[2]);
                if (__dow(y, m1, d) === 0) {
                    var dd = d;
                    var mm = m1;
                    while (true) {
                        dd++;
                        var dim = __daysInMonth(y, mm);
                        if (dd > dim) { dd = 1; mm++; }
                        var k2 = __dateKey(y, mm, dd);
                        if (!map[k2]) {
                            map[k2] = "振替休日";
                            break;
                        }
                    }
                }
            }

            // --- Citizen's holiday (国民の休日): a working day between two holidays
            // Iterate through all days in year
            var m;
            for (m = 1; m <= 12; m++) {
                var dim2 = __daysInMonth(y, m);
                for (var day = 1; day <= dim2; day++) {
                    var k0 = __dateKey(y, m, day);
                    if (map[k0]) continue;
                    // prev
                    var py = y, pm = m, pd = day - 1;
                    if (pd < 1) { pm--; if (pm < 1) continue; pd = __daysInMonth(y, pm); }
                    var kyPrev = __dateKey(y, pm, pd);
                    // next
                    var ny = y, nm = m, nd = day + 1;
                    var dim3 = __daysInMonth(y, nm);
                    if (nd > dim3) { nm++; if (nm > 12) continue; nd = 1; }
                    var kyNext = __dateKey(y, nm, nd);
                    if (map[kyPrev] && map[kyNext]) {
                        map[k0] = "国民の休日";
                    }
                }
            }

            return map;
        }
        /* 複数年ぶんの祝日マップを結合 / Merge holiday maps across multiple years */
        function __buildHolidayMap(fromY, toY) {
            var all = {};
            for (var yy = fromY; yy <= toY; yy++) {
                var m = __buildHolidaysForYear(yy);
                for (var k in m) if (m.hasOwnProperty(k)) all[k] = m[k];
            }
            return all;
        }
        var JP_HOLIDAYS_2020_2035 = __buildHolidayMap(2020, 2035);
        /* 指定日の祝日名を返す（無ければ""）/ Return the holiday name for a date ("" if none) */
        function getJPHolidayName(yyyy, m1, d) {
            return JP_HOLIDAYS_2020_2035[__dateKey(yyyy, m1, d)] || "";
        }

        // 既存プレビューが残っていたら消す
        removeLayerIfExists(doc, PREVIEW_LAYER_NAME);

        // ===== ダイアログ =====
        var today = new Date();

        var dlg = new Window("dialog", getLabel("dialog.title"));
        /* 表示したら初回プレビューを起動（位置は prepareDialogWindow に任せる）/ Trigger the first preview on show; the position is left to prepareDialogWindow */
        dlg.onShow = function () {
            try { refreshPreview(); } catch (e) { }
        };
        setupWindow(dlg);

        dlg.preferredSize.width = 320;
        dlg.minimumSize.width = 320;

        // ===== タブ（プリセット / 設定） =====
        var tabs = dlg.add("tabbedpanel");
        tabs.alignment = "fill";
        tabs.alignChildren = "fill";
        // tabs.margins = [15, 20, 15, 10]; // 上に余白を追加

        var tabGeneral = tabs.add("tab", undefined, getLabel("panel.base"));
        setupTab(tabGeneral);

        var tabCell = tabs.add("tab", undefined, getLabel("panel.unit"));
        setupTab(tabCell);

        var tabText = tabs.add("tab", undefined, getLabel("panel.formatTab"));
        setupTab(tabText, 10);

        var tabLabel = tabs.add("tab", undefined, getLabel("panel.option"));
        setupTab(tabLabel);

        // 既定は「基本設定」タブ
        try { tabs.selection = tabGeneral; } catch (e) { }

        // ===== 2カラム =====
        var gCols = tabGeneral.add("group");
        gCols.orientation = "column";
        gCols.alignChildren = "fill";

        var gColL = gCols.add("group");
        gColL.orientation = "column";
        gColL.alignChildren = "fill";

        var gColR = gCols.add("group");
        gColR.orientation = "column";
        gColR.alignChildren = "fill";

        // ===== プリセット（「基本設定」タブ最下部・全幅）/ Preset (bottom of Basics tab, full width) =====
        var pnlPresetTop = tabGeneral.add("panel", undefined, getLabel("panel.preset"));
        setupPanel(pnlPresetTop);

        var gPresetBtns = pnlPresetTop.add("group");
        gPresetBtns.orientation = "row";
        gPresetBtns.alignChildren = ["left", "center"];

        var presetLoadBtn = gPresetBtns.add("button", undefined, getLabel("preset.load"));
        var presetSaveBtn = gPresetBtns.add("button", undefined, getLabel("preset.save"));
        // ボタンはパネル幅いっぱいに広げず左寄せ / Keep buttons at natural width, left-aligned
        presetLoadBtn.alignment = "left";
        presetSaveBtn.alignment = "left";

        // 2行目：プリセット一覧
        var gPresetListRow = pnlPresetTop.add("group");
        gPresetListRow.orientation = "row";
        gPresetListRow.alignChildren = ["left", "center"];
        gPresetListRow.alignment = "fill";

        // プリセット一覧（読み込んだプリセットを追加）
        var stPresetList = gPresetListRow.add("statictext", undefined, " ");
        var ddPresetList = gPresetListRow.add("dropdownlist", undefined, ["-"]);
        ddPresetList.helpTip = getLabel("tooltip.presetList");
        ddPresetList.preferredSize = [220, 22];
        ddPresetList.alignment = "fill";
        try { ddPresetList.selection = 0; } catch (e) { }

        // 読み込んだプリセットを保持（セッション中のみ）
        var __SCM_PRESET_STORE = ($.global.__SCM_CACHE = $.global.__SCM_CACHE || {});
        __SCM_PRESET_STORE.presets = __SCM_PRESET_STORE.presets || {}; // label -> preset object
        __SCM_PRESET_STORE.presetOrder = __SCM_PRESET_STORE.presetOrder || []; // labels

        // ===== 組み込みプリセット（初期登録） =====
        (function () {
            function registerBuiltin(label, obj) {
                try {
                    if (!__SCM_PRESET_STORE.presets[label]) {
                        __SCM_PRESET_STORE.presets[label] = obj;
                        __SCM_PRESET_STORE.presetOrder.push(label);
                    }
                } catch (e) { }
            }

            registerBuiltin("1)EN Month Title", {
                y: 2026, m: 2, d: 14,
                monthCount: 1, colCount: 1,
                startFrom: "current",
                showTopYear: false,
                topYearBottomMargin: 3,
                includeYearInMonthTitle: false,
                monthTitleAlign: "center",
                monthTitleMode: "en",
                monthBottomMargin: 2,
                monthTitleBottomBorder: true,
                weekStart: "mon",
                weekdayLabelMode: "jp",
                weekdayBottomMargin: 2,
                weekdayFontSize: 9,
                cellW: 7,
                cellH: 6.6,
                outerMarginX: 10,
                outerMarginY: 3,
                fontName: "DNPShueiMGoStd-B",
                favFont: "",
                fontSize: 12,
                align: "center",
                sundayRed: true,
                holidayRed: true
            });

            registerBuiltin("2)ENS + Mon Labels", {
                y: 2026, m: 2, d: 14,
                monthCount: 1, colCount: 1,
                startFrom: "current",
                showTopYear: false,
                topYearBottomMargin: 3,
                includeYearInMonthTitle: false,
                monthTitleAlign: "center",
                monthTitleMode: "ens",
                monthBottomMargin: 2,
                monthTitleBottomBorder: true,
                weekStart: "mon",
                weekdayLabelMode: "mon",
                weekdayBottomMargin: 0,
                weekdayFontSize: 8,
                cellW: 8.7,
                cellH: 6.6,
                outerMarginX: 10,
                outerMarginY: 3,
                fontName: "HeganteDisplay-Regular",
                favFont: "Hegante Display Regular",
                fontSize: 12,
                align: "center",
                sundayRed: true,
                holidayRed: true
            });

            registerBuiltin("3)12M Script Layout", {
                y: 2026, m: 2, d: 14,
                monthCount: 12, colCount: 3,
                startFrom: "jan",
                showTopYear: true,
                topYearBottomMargin: 10,
                includeYearInMonthTitle: false,
                monthTitleAlign: "center",
                monthTitleMode: "en",
                monthBottomMargin: 2,
                monthTitleBottomBorder: false,
                weekStart: "mon",
                weekdayLabelMode: "mon",
                weekdayBottomMargin: 0,
                weekdayFontSize: 7,
                cellW: 8.3,
                cellH: 5.1,
                outerMarginX: 10,
                outerMarginY: 6,
                fontName: "CaflischScriptPro-Light",
                favFont: "Caflisch Script Pro Light",
                fontSize: 12,
                align: "center",
                sundayRed: true,
                holidayRed: true
            });

            registerBuiltin("4)3M Bodoni Layout", {
                y: 2026, m: 2, d: 14,
                monthCount: 3, colCount: 3,
                startFrom: "current",
                showTopYear: false,
                topYearBottomMargin: 3,
                includeYearInMonthTitle: false,
                monthTitleAlign: "center",
                monthTitleMode: "pad",
                monthBottomMargin: 2,
                monthTitleBottomBorder: true,
                weekStart: "mon",
                weekdayLabelMode: "mon",
                weekdayBottomMargin: 0,
                weekdayFontSize: 8,
                cellW: 7.3,
                cellH: 6,
                outerMarginX: 10,
                outerMarginY: 3,
                fontName: "BodoniModaRoman-SemiBold",
                favFont: "Bodoni Moda SemiBold",
                fontSize: 12,
                align: "center",
                sundayRed: true,
                holidayRed: true
            });

            registerBuiltin("5)3M DIN Layout", {
                y: 2026, m: 2, d: 14,
                monthCount: 3, colCount: 1,
                startFrom: "current",
                showTopYear: false,
                topYearBottomMargin: 3,
                includeYearInMonthTitle: false,
                monthTitleAlign: "center",
                monthTitleMode: "pad",
                monthBottomMargin: 2,
                monthTitleBottomBorder: true,
                weekStart: "mon",
                weekdayLabelMode: "mtw",
                weekdayBottomMargin: 0,
                weekdayFontSize: 8,
                cellW: 8,
                cellH: 7,
                outerMarginX: 10,
                outerMarginY: 9,
                fontName: "DINCondensedVF-Regular",
                favFont: "DIN Condensed VF Regular",
                fontSize: 20,
                align: "center",
                sundayRed: true,
                holidayRed: true
            });

            // dropdown 初期化
            try {
                ddPresetList.removeAll();
            } catch (e) {
                try { while (ddPresetList.items.length) ddPresetList.items[0].remove(); } catch (__e) { }
            }
            ddPresetList.add("item", "-");
            for (var i = 0; i < __SCM_PRESET_STORE.presetOrder.length; i++) {
                ddPresetList.add("item", __SCM_PRESET_STORE.presetOrder[i]);
            }
            try { ddPresetList.selection = 0; } catch (e) { }
        })();

        /* プリセットを保持しドロップダウンへ追加 / Store a preset and add it to the dropdown */
        function __SCM_addPresetToDropdown(label, obj) {
            try {
                var lb = String(label || "");
                if (!lb || lb === "-") return;
                __SCM_PRESET_STORE.presets[lb] = obj;
                // 既に登録済みなら順序は維持
                var exists = false;
                for (var i = 0; i < __SCM_PRESET_STORE.presetOrder.length; i++) {
                    if (__SCM_PRESET_STORE.presetOrder[i] === lb) { exists = true; break; }
                }
                if (!exists) __SCM_PRESET_STORE.presetOrder.push(lb);

                // dd の items を作り直す（重くない件数想定）
                try {
                    ddPresetList.removeAll();
                } catch (e) {
                    // removeAll が無い環境向け
                    try { while (ddPresetList.items.length) ddPresetList.items[0].remove(); } catch (__e) { }
                }
                ddPresetList.add("item", "-");
                for (var j = 0; j < __SCM_PRESET_STORE.presetOrder.length; j++) {
                    ddPresetList.add("item", __SCM_PRESET_STORE.presetOrder[j]);
                }
                // 追加したものを選択
                for (var k = 0; k < ddPresetList.items.length; k++) {
                    if (ddPresetList.items[k].text === lb) { ddPresetList.selection = k; break; }
                }
            } catch (e) { }
        }

        ddPresetList.onChange = function () {
            try {
                if (!ddPresetList.selection) return;
                var lb = ddPresetList.selection.text;
                if (!lb || lb === "-") return;
                var obj = __SCM_PRESET_STORE.presets[lb];
                if (!obj) return;
                __SCM_applyPreset(obj);
            } catch (e) { }
        };

        // ===== オプションタブ内コンテナ =====
        var gOption = tabLabel.add("group");
        gOption.orientation = "column";
        gOption.alignChildren = "fill";

        // ===== 基本設定パネル =====
        var pnlBaseDate = gColL.add("panel", undefined, getLabel("panel.base"));
        setupPanel(pnlBaseDate);
        pnlBaseDate.alignChildren = "left";

        var gBaseDateRow = pnlBaseDate.add("group");
        gBaseDateRow.add("statictext", undefined, labelText("field.year"));
        var inputY = addStepperInput(gBaseDateRow, String(today.getFullYear()), { integer: true, min: 1, max: 9999, onStep: refreshPreviewOnStep });
        inputY.helpTip = getLabel("tooltip.baseDate");
        inputY.characters = 4;

        gBaseDateRow.add("statictext", undefined, labelText("field.month"));
        var inputM = addStepperInput(gBaseDateRow, String(today.getMonth() + 1), { integer: true, min: 1, max: 12, onStep: refreshPreviewOnStep });
        inputM.helpTip = getLabel("tooltip.baseDate");
        inputM.characters = 2;

        gBaseDateRow.add("statictext", undefined, labelText("field.day"));
        var inputD = addStepperInput(gBaseDateRow, String(today.getDate()), { integer: true, min: 1, max: 31, onStep: refreshPreviewOnStep });
        inputD.helpTip = getLabel("tooltip.baseDate");
        inputD.characters = 2;

        // 月数プリセット（ラジオ）
        var gMonthPreset = pnlBaseDate.add("group");
        gMonthPreset.orientation = "row";
        gMonthPreset.alignChildren = ["left", "center"];

        gMonthPreset.add("statictext", undefined, labelText("base.monthCount"));
        var rbPreset1 = gMonthPreset.add("radiobutton", undefined, getLabel("base.preset1"));
        rbPreset1.helpTip = getLabel("tooltip.preset1");
        var rbPreset3 = gMonthPreset.add("radiobutton", undefined, getLabel("base.preset3"));
        rbPreset3.helpTip = getLabel("tooltip.preset3");
        var rbPreset12 = gMonthPreset.add("radiobutton", undefined, getLabel("base.preset12"));
        rbPreset12.helpTip = getLabel("tooltip.preset12");

        /* 月数プリセット(1/3/12)に合わせUIを一括設定 / Apply a month-count preset (1/3/12) across the UI */
        function applyMonthPreset(months, cols) {
            inputMonths.text = String(months);
            try {
                if (typeof cols === "number" && cols > 0) inputCols.text = String(cols);
            } catch (e) { }
            // 「年」panel: 年表示は 12ヶ月 のときだけON
            try {
                chkTopYear.value = (months === 12);
                chkTopYear.enabled = (months === 12);
                __SCM_syncYearPanelDimToFontSize();
            } catch (e) { }

            gYearMargin.enabled = chkTopYear.value;

            redrawSteppersIn(gYearMargin);

            // 12ヶ月のときは月タイトルの「年を併記」をOFF
            try {
                if (months === 12) chkMonthYear.value = false;
            } catch (e) { }

            // 12ヶ月 は「1月から」を自動選択
            try {
                if (months === 12) {
                    rbStartJan.value = true;
                    rbStartCurrent.value = false;
                }
            } catch (e) { }
            // レイアウトの月数/列数は 1ヶ月 のときディム
            gCount.enabled = (months !== 1);
            redrawSteppersIn(gCount);
            try {
                chkGhost.enabled = (months === 1);
                if (months !== 1) chkGhost.value = false;
            } catch (e) { }
            try { schedulePreviewRefresh(true); } catch (e) { }
        }

        /* 「年」パネルの有効/無効を年表示チェックに同期 / Sync the Year panel enabled-state with the show-year checkbox */
        function __SCM_syncYearPanelDimToFontSize() {
            var en = false;
            try { en = !!(chkTopYear && chkTopYear.enabled); } catch (e) { }
            try {
                if (inputYearFontSize) {
                    inputYearFontSize.enabled = en;
                    inputYearFontSize.stepperGroup.enabled = en;
                    redrawSteppersIn(inputYearFontSize.stepperGroup);
                }
            } catch (e) { }
            try { if (stFSYear) stFSYear.enabled = en; } catch (e) { }
        }

        rbPreset1.onClick = function () { applyMonthPreset(1, 1); };
        rbPreset3.onClick = function () { applyMonthPreset(3, 3); };
        rbPreset12.onClick = function () { applyMonthPreset(12, 3); };

        // 月の起点
        var gMonthStart = pnlBaseDate.add("group");
        gMonthStart.orientation = "row";
        gMonthStart.alignChildren = ["left", "center"];

        gMonthStart.add("statictext", undefined, labelText("base.label"));
        var rbStartCurrent = gMonthStart.add("radiobutton", undefined, getLabel("base.current"));
        rbStartCurrent.helpTip = getLabel("tooltip.startCurrent");
        var rbStartJan = gMonthStart.add("radiobutton", undefined, getLabel("base.jan"));
        rbStartJan.helpTip = getLabel("tooltip.startJan");

        rbStartCurrent.value = true; // デフォルト
        rbStartCurrent.onClick = schedulePreviewRefresh;
        rbStartJan.onClick = schedulePreviewRefresh;

        // ゴースト（ロジックは後で追加）
        var chkGhost = pnlBaseDate.add("checkbox", undefined, getLabel("base.ghost"));
        chkGhost.helpTip = getLabel("tooltip.ghost");
        chkGhost.value = false;
        chkGhost.onClick = schedulePreviewRefresh;

        chkGhost.enabled = true; // 初期値（refreshPreviewで正しく同期される）

        // ===== 日付（panel） =====
        var pnlDate = tabCell.add("panel", undefined, getLabel("panel.date"));
        setupPanel(pnlDate);
        pnlDate.alignChildren = "left";

        // ===== 揃え =====
        var gAlign = pnlDate.add("group");
        gAlign.orientation = "row";
        gAlign.alignChildren = ["left", "center"];

        gAlign.add("statictext", undefined, labelText("common.align"));

        var rbLeft = gAlign.add("radiobutton", undefined, getLabel("common.left"));
        var rbCenter = gAlign.add("radiobutton", undefined, getLabel("common.center"));
        var rbRight = gAlign.add("radiobutton", undefined, getLabel("common.right"));
        rbCenter.value = true; // デフォルト中央
        rbLeft.onClick = schedulePreviewRefresh;
        rbCenter.onClick = schedulePreviewRefresh;
        rbRight.onClick = schedulePreviewRefresh;

        // 日曜日・祝日（横並び）
        var gHoliday = pnlDate.add("group");
        gHoliday.orientation = "row";
        gHoliday.alignChildren = ["left", "center"];

        var chkSundayRed = gHoliday.add("checkbox", undefined, getLabel("format.sunday"));
        chkSundayRed.helpTip = getLabel("tooltip.sundayRed");
        chkSundayRed.value = true;
        chkSundayRed.onClick = schedulePreviewRefresh;

        var chkHolidayRed = gHoliday.add("checkbox", undefined, getLabel("format.holiday"));
        chkHolidayRed.helpTip = getLabel("tooltip.holidayRed");
        chkHolidayRed.value = true;
        chkHolidayRed.onClick = schedulePreviewRefresh;

        // ===== 曜日表記（panel） =====
        var pnlWeekdayLabel = gOption.add("panel", undefined, getLabel("panel.weekday"));
        setupPanel(pnlWeekdayLabel);
        pnlWeekdayLabel.alignChildren = "left";

        // 週の始まり（ラベル + ラジオ）
        var gWeekStart = pnlWeekdayLabel.add("group");
        gWeekStart.orientation = "row";
        gWeekStart.alignChildren = ["left", "center"];

        gWeekStart.add("statictext", undefined, labelText("weekday.start"));
        var rbWeekMon = gWeekStart.add("radiobutton", undefined, getLabel("weekday.monday"));
        rbWeekMon.helpTip = getLabel("tooltip.weekMonday");
        var rbWeekSun = gWeekStart.add("radiobutton", undefined, getLabel("weekday.sunday"));
        rbWeekSun.helpTip = getLabel("tooltip.weekSunday");

        rbWeekMon.value = true; // デフォルト
        rbWeekMon.onClick = schedulePreviewRefresh;
        rbWeekSun.onClick = schedulePreviewRefresh;

        // 曜日ヘッダの表記（ラベル + ラジオ）
        var gWeekdayLabel = pnlWeekdayLabel.add("group");
        gWeekdayLabel.orientation = "row";
        gWeekdayLabel.alignChildren = ["left", "center"];

        gWeekdayLabel.add("statictext", undefined, labelText("weekday.notation"));
        var rbWdJP = gWeekdayLabel.add("radiobutton", undefined, "月");
        rbWdJP.helpTip = getLabel("tooltip.weekdayLabel");
        var rbWdMTW = gWeekdayLabel.add("radiobutton", undefined, "M");
        rbWdMTW.helpTip = getLabel("tooltip.weekdayLabel");
        var rbWdMon = gWeekdayLabel.add("radiobutton", undefined, "Mon");
        rbWdMon.helpTip = getLabel("tooltip.weekdayLabel");

        // 曜日ヘッダ下のマージン（pt）
        var gWeekdayBottomMargin = pnlWeekdayLabel.add("group");
        gWeekdayBottomMargin.orientation = "row";
        gWeekdayBottomMargin.alignChildren = ["left", "center"];
        gWeekdayBottomMargin.add("statictext", undefined, labelText("weekday.margin"));
        var inputWeekdayBottomMargin = addStepperInput(gWeekdayBottomMargin, "2" + lengthUnitSuffix, { min: 0, max: 2000, unit: lengthUnitSuffix, onStep: refreshPreviewOnStep });
        inputWeekdayBottomMargin.helpTip = getLabel("tooltip.weekdayBottomMargin");
        inputWeekdayBottomMargin.characters = 5;
        inputWeekdayBottomMargin.onChanging = schedulePreviewRefresh;

        // 曜日フォントサイズ（未入力時は全体フォントサイズを使用）
        var inputWeekdayFontSize;

        rbWdJP.value = true; // default
        rbWdJP.onClick = schedulePreviewRefresh;
        rbWdMTW.onClick = schedulePreviewRefresh;
        rbWdMon.onClick = schedulePreviewRefresh;

        // ===== 月パネル =====
        var pnlMonth = gOption.add("panel", undefined, getLabel("panel.month"));
        setupPanel(pnlMonth);
        pnlMonth.alignChildren = "left";
        pnlMonth.minimumSize.height = 44;
        pnlMonth.preferredSize.height = 44;
        pnlMonth.visible = true;
        pnlMonth.enabled = true;

        var gMonth = pnlMonth.add("group");
        gMonth.orientation = "row";
        gMonth.alignChildren = ["left", "center"];

        var chkMonthYear = gMonth.add("checkbox", undefined, getLabel("month.includeYear"));
        chkMonthYear.helpTip = getLabel("tooltip.monthIncludeYear");
        chkMonthYear.value = true;
        chkMonthYear.onClick = schedulePreviewRefresh;

        // 月タイトルの揃え
        var gMonthAlign = pnlMonth.add("group");
        gMonthAlign.orientation = "row";
        gMonthAlign.alignChildren = ["left", "center"];
        gMonthAlign.add("statictext", undefined, labelText("common.align"));
        var rbMonthAlignL = gMonthAlign.add("radiobutton", undefined, getLabel("common.left"));
        var rbMonthAlignC = gMonthAlign.add("radiobutton", undefined, getLabel("common.center"));
        var rbMonthAlignR = gMonthAlign.add("radiobutton", undefined, getLabel("common.right"));
        rbMonthAlignC.value = true; // default
        rbMonthAlignL.onClick = schedulePreviewRefresh;
        rbMonthAlignC.onClick = schedulePreviewRefresh;
        rbMonthAlignR.onClick = schedulePreviewRefresh;

        // 月タイトルの表記
        var pnlMonthFmt = pnlMonth.add("panel", undefined, getLabel("panel.notation"));
        setupPanel(pnlMonthFmt);
        pnlMonthFmt.alignChildren = "left";

        var gMonthFmt = pnlMonthFmt.add("group");
        gMonthFmt.orientation = "column";
        gMonthFmt.alignChildren = ["left", "top"];

        var rbMonthNum = gMonthFmt.add("radiobutton", undefined, getLabel("month.num"));
        rbMonthNum.helpTip = getLabel("tooltip.monthFormat");
        var rbMonthPad = gMonthFmt.add("radiobutton", undefined, getLabel("month.pad"));
        rbMonthPad.helpTip = getLabel("tooltip.monthFormat");
        var rbMonthEn = gMonthFmt.add("radiobutton", undefined, getLabel("month.en"));
        rbMonthEn.helpTip = getLabel("tooltip.monthFormat");
        var rbMonthEnS = gMonthFmt.add("radiobutton", undefined, getLabel("month.ens"));
        rbMonthEnS.helpTip = getLabel("tooltip.monthFormat");

        // デフォルトは 0埋め
        rbMonthPad.value = true;

        rbMonthNum.onClick = schedulePreviewRefresh;
        rbMonthPad.onClick = schedulePreviewRefresh;
        rbMonthEn.onClick = schedulePreviewRefresh;
        rbMonthEnS.onClick = schedulePreviewRefresh;

        // 月タイトル下のマージン（pt）
        var gMonthMargin = pnlMonth.add("group");
        gMonthMargin.orientation = "row";
        gMonthMargin.alignChildren = ["left", "center"];
        gMonthMargin.add("statictext", undefined, labelText("common.bottomMargin"));
        var inputMonthBottomMargin = addStepperInput(gMonthMargin, "3" + lengthUnitSuffix, { min: 0, max: 2000, unit: lengthUnitSuffix, onStep: refreshPreviewOnStep });
        inputMonthBottomMargin.helpTip = getLabel("tooltip.monthBottomMargin");
        inputMonthBottomMargin.characters = 5;
        inputMonthBottomMargin.onChanging = schedulePreviewRefresh;

        // 月タイトル行の下ボーダー
        var chkMonthBottomBorder = pnlMonth.add("checkbox", undefined, getLabel("month.bottomBorder"));
        chkMonthBottomBorder.helpTip = getLabel("tooltip.monthBottomBorder");
        chkMonthBottomBorder.value = true; // デフォルトON
        chkMonthBottomBorder.onClick = schedulePreviewRefresh;

        // ===== 年パネル =====
        var pnlYear = gOption.add("panel", undefined, getLabel("panel.year"));
        setupPanel(pnlYear);
        pnlYear.alignChildren = "left";

        var gYear = pnlYear.add("group");
        gYear.orientation = "row";
        gYear.alignChildren = ["left", "center"];

        var chkTopYear = gYear.add("checkbox", undefined, getLabel("year.show"));
        chkTopYear.helpTip = getLabel("tooltip.topYear");
        chkTopYear.value = false;      // 12ヶ月のときだけONにする
        chkTopYear.enabled = false;    // 12ヶ月以外は触れない
        chkTopYear.onClick = function () {
            gYearMargin.enabled = chkTopYear.value;
            redrawSteppersIn(gYearMargin);
            schedulePreviewRefresh(true);
        };

        // 年タイトル下のマージン（pt）
        var gYearMargin = pnlYear.add("group");
        gYearMargin.orientation = "row";
        gYearMargin.alignChildren = ["left", "center"];
        gYearMargin.add("statictext", undefined, labelText("common.bottomMargin"));
        var inputTopYearBottomMargin = addStepperInput(gYearMargin, "3" + lengthUnitSuffix, { min: 0, max: 2000, unit: lengthUnitSuffix, onStep: refreshPreviewOnStep });
        inputTopYearBottomMargin.helpTip = getLabel("tooltip.topYearBottomMargin");
        inputTopYearBottomMargin.characters = 5;
        inputTopYearBottomMargin.onChanging = schedulePreviewRefresh;

        gYearMargin.enabled = chkTopYear.value;

        redrawSteppersIn(gYearMargin);
        /* 選択中の曜日表記モードを返す / Return the selected weekday-label mode */
        function getWeekdayLabelMode() {
            // "jp" | "mtw" | "mon"
            try {
                if (rbWdMon && rbWdMon.value) return "mon";
                if (rbWdMTW && rbWdMTW.value) return "mtw";
            } catch (e) { }
            return "jp";
        }

        /* 選択中の月タイトル表記モードを返す / Return the selected month-title mode */
        function getMonthTitleMode() {
            // "num" | "pad" | "en" | "ens"
            try {
                if (rbMonthEnS && rbMonthEnS.value) return "ens";
                if (rbMonthEn && rbMonthEn.value) return "en";
                if (rbMonthNum && rbMonthNum.value) return "num";
            } catch (e) { }
            return "pad"; // default
        }

        /* 年・月・モードから月タイトル文字列を組み立てる / Build the month-title string from year/month/mode */
        function formatMonthTitle(year, month0, includeYear, mode) {
            var m = month0 + 1;

            if (mode === "en" || mode === "ens") {
                var enFull = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
                var enShort = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                var name = (mode === "ens") ? enShort[month0] : enFull[month0];
                return includeYear ? (String(year) + " " + name) : name;
            }

            var mm = (mode === "num") ? String(m) : pad2(m);
            return includeYear ? (String(year) + "/" + mm) : mm;
        }

        // ===== レイアウトパネル =====
        var pnlLayout = gColL.add("panel", undefined, getLabel("panel.layout"));
        setupPanel(pnlLayout);
        pnlLayout.alignChildren = "left";

        // 月数/列数
        var gCount = pnlLayout.add("group");
        gCount.orientation = "row";
        gCount.alignChildren = ["left", "center"];
        gCount.add("statictext", undefined, labelText("layout.months"));
        var inputMonths = addStepperInput(gCount, "1", { integer: true, min: 1, max: 24, onStep: refreshPreviewOnStep });
        inputMonths.helpTip = getLabel("tooltip.months");
        inputMonths.characters = 3;
        rbPreset1.value = true;
        gCount.add("statictext", undefined, labelText("layout.cols"));
        var inputCols = addStepperInput(gCount, "1", { integer: true, min: 1, max: 12, onStep: refreshPreviewOnStep });
        inputCols.helpTip = getLabel("tooltip.columns");
        inputCols.characters = 3;

        // セル＋月（縦並びコンテナ）
        var gCellMonth = pnlLayout.add("group");
        gCellMonth.orientation = "column";
        gCellMonth.alignChildren = ["fill", "top"];
        gCellMonth.alignment = "fill";

        // 月（ユニット間マージン）panel
        var pnlMonthOuter = gCellMonth.add("panel", undefined, getLabel("panel.month"));
        setupPanel(pnlMonthOuter);
        pnlMonthOuter.alignChildren = "left";
        pnlMonthOuter.enabled = false; // 月数=1 のときはディム（refreshPreviewで同期）

        // 横並びコンテナ
        var gOuterRow = pnlMonthOuter.add("group");
        gOuterRow.orientation = "row";
        gOuterRow.alignChildren = ["left", "center"];

        var gOuterH = gOuterRow.add("group");
        gOuterH.orientation = "row";
        gOuterH.alignChildren = ["left", "center"];
        gOuterH.add("statictext", undefined, labelText("common.lr"));
        var inputOuterMarginX = addStepperInput(gOuterH, "10" + lengthUnitSuffix, { min: 0, max: 5000, unit: lengthUnitSuffix, onStep: refreshPreviewOnStep });
        inputOuterMarginX.helpTip = getLabel("tooltip.outerMarginX");
        inputOuterMarginX.characters = 3;
        inputOuterMarginX.onChanging = schedulePreviewRefresh;

        var gOuterV = gOuterRow.add("group");
        gOuterV.orientation = "row";
        gOuterV.alignChildren = ["left", "center"];
        gOuterV.add("statictext", undefined, labelText("common.ud"));
        var inputOuterMarginY = addStepperInput(gOuterV, "3" + lengthUnitSuffix, { min: 0, max: 5000, unit: lengthUnitSuffix, onStep: refreshPreviewOnStep });
        inputOuterMarginY.helpTip = getLabel("tooltip.outerMarginY");
        inputOuterMarginY.characters = 3;
        inputOuterMarginY.onChanging = schedulePreviewRefresh;

        // Slider fine control: hold Option(Alt) to move at 1/10 speed
        /* Option押下時にスライダーを1/10速度で微調整 / Move a slider at 1/10 speed while Option is held */
        function __SCM_applySliderWithAltFine(slider, st, applyFn) {
            try {
                if (!slider || !st || typeof applyFn !== "function") return;

                var ks = null;
                try { ks = ScriptUI.environment.keyboardState; } catch (e) { ks = null; }
                var alt = false;
                try { alt = !!(ks && ks.altKey); } catch (e) { alt = false; }

                var raw = Number(slider.value);
                if (isNaN(raw)) raw = 0;

                // init
                if (st.raw == null || st.eff == null) {
                    st.raw = raw;
                    st.eff = raw;
                }

                if (alt) {
                    var d = raw - Number(st.raw);
                    var eff = Number(st.eff) + d * 0.1;
                    st.raw = raw;
                    st.eff = eff;
                    slider.value = eff;
                    applyFn(eff);
                } else {
                    st.raw = raw;
                    st.eff = raw;
                    applyFn(raw);
                }
            } catch (e) { }
        }

        // ===== 画面表示（ズーム） =====
        var pnlView = gColL.add("panel", undefined, getLabel("panel.view"));
        setupPanel(pnlView);
        pnlView.alignChildren = "left";

        var gZoom = pnlView.add("group");
        gZoom.orientation = "row";
        gZoom.alignChildren = ["left", "center"];

        var stZoom = gZoom.add("statictext", undefined, labelText("common.zoom"));
        try { stZoom.preferredSize.width = 58; } catch (e) { }

        var __initZoomPct = 100;
        try { if (__SCM_ORG_ZOOM != null) __initZoomPct = Math.round(Number(__SCM_ORG_ZOOM) * 100); } catch (e) { }
        if (!__initZoomPct || __initZoomPct < 10) __initZoomPct = 100;

        var sldZoom = gZoom.add("slider", undefined, __initZoomPct, 10, 1600);
        sldZoom.helpTip = getLabel("tooltip.zoom");
        try { sldZoom.preferredSize.width = 180; } catch (e) { }

        var __stZoom = { raw: null, eff: null };
        sldZoom.onChanging = function () {
            __SCM_applySliderWithAltFine(this, __stZoom, function (v) {
                __SCM_applyZoomPct(Math.round(v));
            });
        };

        // 左右（パン）
        var gPanX = pnlView.add("group");
        gPanX.orientation = "row";
        gPanX.alignChildren = ["left", "center"];

        var stPanX = gPanX.add("statictext", undefined, labelText("common.lr"));
        try { stPanX.preferredSize.width = 58; } catch (e) { }

        var __panRange = __SCM_getPanRangePt();
        var sldPanX = gPanX.add("slider", undefined, 0, -__panRange.xMax, __panRange.xMax);
        sldPanX.helpTip = getLabel("tooltip.pan");
        try { sldPanX.preferredSize.width = 180; } catch (e) { }

        var __stPanX = { raw: null, eff: null };
        sldPanX.onChanging = function () {
            __SCM_applySliderWithAltFine(this, __stPanX, function (v) {
                __SCM_applyPanX(Math.round(v));
            });
        };

        // 上下（パン）
        var gPanY = pnlView.add("group");
        gPanY.orientation = "row";
        gPanY.alignChildren = ["left", "center"];

        var stPanY = gPanY.add("statictext", undefined, labelText("common.ud"));
        try { stPanY.preferredSize.width = 58; } catch (e) { }

        var sldPanY = gPanY.add("slider", undefined, 0, -__panRange.yMax, __panRange.yMax);
        sldPanY.helpTip = getLabel("tooltip.pan");
        try { sldPanY.preferredSize.width = 180; } catch (e) { }

        var __stPanY = { raw: null, eff: null };
        sldPanY.onChanging = function () {
            __SCM_applySliderWithAltFine(this, __stPanY, function (v) {
                __SCM_applyPanY(Math.round(v));
            });
        };

        // ===== セル（panel）をレイアウトから移動してフォントパネルの直前に配置 =====
        // セル（panel）
        var pnlCell = tabCell.add("panel", undefined, getLabel("panel.cell"));
        setupPanel(pnlCell);
        pnlCell.alignChildren = "left";

        // セル上段コンテナ（大きさ／セル間隔 横並び）
        var gCellTopRow = pnlCell.add("group");
        gCellTopRow.orientation = "row";
        gCellTopRow.alignChildren = ["fill", "top"];
        gCellTopRow.alignment = "fill";

        // セル：大きさ（sub panel）
        var pnlCellSize = gCellTopRow.add("panel", undefined, "大きさ");
        setupPanel(pnlCellSize);
        pnlCellSize.alignChildren = "left";

        var gCellW = pnlCellSize.add("group");
        var stCellW = gCellW.add("statictext", undefined, labelText("layout.width"));
        stCellW.justification = "right";
        stCellW.preferredSize.width = 30;
        var __fs0 = 12;
        try {
            if (typeof inputFontSize !== "undefined" && inputFontSize) {
                __fs0 = parseFloat(inputFontSize.text);
            }
        } catch (e) { }
        if (!__fs0 || __fs0 <= 0) __fs0 = 12;
        var __defaultCellW_pt = Math.round(__fs0 * 1.5);
        var __defaultCellW = Math.round(ptToUnit(__defaultCellW_pt, getUnitInfo("rulerType")));
        var inputCellW = addStepperInput(gCellW, __defaultCellW + lengthUnitSuffix, { min: 1, max: 2000, unit: lengthUnitSuffix, onStep: refreshPreviewOnStep });
        inputCellW.helpTip = getLabel("tooltip.cellWidth");
        inputCellW.characters = 4;

        var gCellH = pnlCellSize.add("group");
        var stCellH = gCellH.add("statictext", undefined, labelText("layout.height"));
        stCellH.justification = "right";
        stCellH.preferredSize.width = 30;
        var __defaultCellH_pt = Math.round(__fs0 * 1.3);
        var __defaultCellH = Math.round(ptToUnit(__defaultCellH_pt, getUnitInfo("rulerType")));
        var inputCellH = addStepperInput(gCellH, __defaultCellH + lengthUnitSuffix, { min: 1, max: 2000, unit: lengthUnitSuffix, onStep: refreshPreviewOnStep });
        inputCellH.helpTip = getLabel("tooltip.cellHeight");
        inputCellH.characters = 4;

        // セル：間隔（sub panel）
        var pnlCellGap = gCellTopRow.add("panel", undefined, "セル間隔");
        setupPanel(pnlCellGap);
        pnlCellGap.alignChildren = "left";

        // 縦並び（左右 / 上下）
        var gCellGapRow = pnlCellGap.add("group");
        gCellGapRow.orientation = "column";
        gCellGapRow.alignChildren = ["left", "center"];
        gCellGapRow.spacing = 6;

        var gCellGapX = gCellGapRow.add("group");
        gCellGapX.orientation = "row";
        gCellGapX.alignChildren = ["left", "center"];
        gCellGapX.add("statictext", undefined, labelText("common.lr"));
        var inputCellGapX = addStepperInput(gCellGapX, "0" + lengthUnitSuffix, { min: 0, max: 2000, unit: lengthUnitSuffix, onStep: refreshPreviewOnStep });
        inputCellGapX.helpTip = getLabel("tooltip.cellGapX");
        inputCellGapX.characters = 3;

        var gCellGapY = gCellGapRow.add("group");
        gCellGapY.orientation = "row";
        gCellGapY.alignChildren = ["left", "center"];
        gCellGapY.add("statictext", undefined, labelText("common.ud"));
        var inputCellGapY = addStepperInput(gCellGapY, "0" + lengthUnitSuffix, { min: 0, max: 2000, unit: lengthUnitSuffix, onStep: refreshPreviewOnStep });
        inputCellGapY.helpTip = getLabel("tooltip.cellGapY");
        inputCellGapY.characters = 3;

        inputCellGapX.onChanging = schedulePreviewRefresh;
        inputCellGapY.onChanging = schedulePreviewRefresh;

        // セル位置調整（上下）
        var gCellPosAdj = pnlCell.add("group");
        gCellPosAdj.orientation = "row";
        gCellPosAdj.alignChildren = ["left", "center"];
        gCellPosAdj.add("statictext", undefined, "セル位置調整 :");
        var inputCellPosAdjY = addStepperInput(gCellPosAdj, "0" + lengthUnitSuffix, { min: -2000, max: 2000, unit: lengthUnitSuffix, onStep: refreshPreviewOnStep });
        inputCellPosAdjY.helpTip = getLabel("tooltip.cellPosAdjY");
        inputCellPosAdjY.characters = 5;

        inputCellPosAdjY.onChanging = schedulePreviewRefresh;

        // セル背景の塗り
        var chkCellFill = pnlCell.add("checkbox", undefined, getLabel("layout.cellFill"));
        chkCellFill.helpTip = getLabel("tooltip.cellFill");
        chkCellFill.value = false; // 既定：OFF
        chkCellFill.onClick = schedulePreviewRefresh;

        // 罫線（panel）
        var pnlCellStroke = pnlCell.add("panel", undefined, "罫線");
        setupPanel(pnlCellStroke);
        pnlCellStroke.alignChildren = "left";

        // 罫線モード
        var gStrokeMode = pnlCellStroke.add("group");
        gStrokeMode.orientation = "row";
        gStrokeMode.alignChildren = ["left", "center"];

        var rbStrokeNone = gStrokeMode.add("radiobutton", undefined, getLabel("stroke.none"));
        rbStrokeNone.helpTip = getLabel("tooltip.strokeNone");
        var rbStrokeAll = gStrokeMode.add("radiobutton", undefined, getLabel("stroke.all"));
        rbStrokeAll.helpTip = getLabel("tooltip.strokeAll");
        var rbStrokeCustom = gStrokeMode.add("radiobutton", undefined, getLabel("stroke.custom"));
        rbStrokeCustom.helpTip = getLabel("tooltip.strokeCustom");

        rbStrokeNone.value = true; // default

        var gStrokeAll = pnlCellStroke.add("group");
        gStrokeAll.orientation = "row";
        gStrokeAll.alignChildren = ["left", "center"];

        var chkStrokeTop = gStrokeAll.add("checkbox", undefined, getLabel("stroke.top"));
        chkStrokeTop.helpTip = getLabel("tooltip.strokeSide");
        var chkStrokeBottom = gStrokeAll.add("checkbox", undefined, getLabel("stroke.bottom"));
        chkStrokeBottom.helpTip = getLabel("tooltip.strokeSide");
        var chkStrokeLeft = gStrokeAll.add("checkbox", undefined, getLabel("stroke.left"));
        chkStrokeLeft.helpTip = getLabel("tooltip.strokeSide");
        var chkStrokeRight = gStrokeAll.add("checkbox", undefined, getLabel("stroke.right"));
        chkStrokeRight.helpTip = getLabel("tooltip.strokeSide");

        // デフォルトはすべてON
        chkStrokeTop.value = true;
        chkStrokeBottom.value = true;
        chkStrokeLeft.value = true;
        chkStrokeRight.value = true;

        chkStrokeTop.onClick = schedulePreviewRefresh;
        chkStrokeBottom.onClick = schedulePreviewRefresh;
        chkStrokeLeft.onClick = schedulePreviewRefresh;
        chkStrokeRight.onClick = schedulePreviewRefresh;

        // 罫線モード切替ロジック
        /* 罫線モード（なし/すべて/個別）でチェック状態を切替 / Toggle border checkboxes by stroke mode */
        function updateStrokeMode() {
            if (rbStrokeNone.value) {
                chkStrokeTop.value = false;
                chkStrokeBottom.value = false;
                chkStrokeLeft.value = false;
                chkStrokeRight.value = false;

                chkStrokeTop.enabled = false;
                chkStrokeBottom.enabled = false;
                chkStrokeLeft.enabled = false;
                chkStrokeRight.enabled = false;
            }
            else if (rbStrokeAll.value) {
                chkStrokeTop.value = true;
                chkStrokeBottom.value = true;
                chkStrokeLeft.value = true;
                chkStrokeRight.value = true;

                chkStrokeTop.enabled = false;
                chkStrokeBottom.enabled = false;
                chkStrokeLeft.enabled = false;
                chkStrokeRight.enabled = false;
            }
            else {
                chkStrokeTop.enabled = true;
                chkStrokeBottom.enabled = true;
                chkStrokeLeft.enabled = true;
                chkStrokeRight.enabled = true;
            }
            schedulePreviewRefresh(true);
        }

        rbStrokeNone.onClick = updateStrokeMode;
        rbStrokeAll.onClick = updateStrokeMode;
        rbStrokeCustom.onClick = updateStrokeMode;

        // 初期状態に反映
        updateStrokeMode();

        inputCellW.onChanging = schedulePreviewRefresh;
        inputCellH.onChanging = schedulePreviewRefresh;

        // ===== 書式パネル =====
        var pnlFormat = tabText.add("panel", undefined, getLabel("panel.font"));
        setupPanel(pnlFormat);
        pnlFormat.alignChildren = "left";

        // フォントサイズグリッド用変数宣言
        var inputFontSize;
        var inputMonthFontSize;
        var inputYearFontSize;
        var stFSYear;

        // フォントサイズ（2行4列）
        var pnlFontSize = tabText.add("panel", undefined, getLabel("panel.fontSize"));
        setupPanel(pnlFontSize);
        pnlFontSize.alignChildren = "left";

        // フォントサイズ（2行4列）
        var gFSGrid = pnlFontSize.add("group");
        gFSGrid.orientation = "column";
        gFSGrid.alignChildren = ["fill", "center"];

        var gFSLabels = gFSGrid.add("group");
        gFSLabels.orientation = "row";
        gFSLabels.alignChildren = ["center", "center"];
        gFSLabels.alignment = ["center", "top"];

        var stFSBasic = gFSLabels.add("statictext", undefined, "基本");
        var stFSWeek = gFSLabels.add("statictext", undefined, "曜日");
        var stFSMonth = gFSLabels.add("statictext", undefined, "月");
        stFSYear = gFSLabels.add("statictext", undefined, "年");

        // ラベル幅を揃えて中央寄せ
        /* 入力欄の左に∧∨が付くので、その幅を足して入力欄の列とそろえる / include the stepper width so labels line up with the fields */
        var __fsLabelW = 42 + STEPPER_BUTTON_WIDTH + STEPPER_SIDE_MARGIN;
        stFSBasic.preferredSize.width = __fsLabelW; stFSBasic.justification = "center";
        stFSWeek.preferredSize.width = __fsLabelW; stFSWeek.justification = "center";
        stFSMonth.preferredSize.width = __fsLabelW; stFSMonth.justification = "center";
        stFSYear.preferredSize.width = __fsLabelW; stFSYear.justification = "center";

        var gFSInputs = gFSGrid.add("group");
        gFSInputs.orientation = "row";
        gFSInputs.alignChildren = ["left", "center"];
        gFSInputs.alignment = ["left", "top"];

        inputFontSize = addStepperInput(gFSInputs, "12" + textUnitSuffix, { min: 0.1, max: 9999, unit: textUnitSuffix, onStep: refreshPreviewOnStep });
        inputFontSize.helpTip = getLabel("tooltip.fontSize");
        inputFontSize.characters = 3;
        inputFontSize.onChanging = schedulePreviewRefresh;

        inputWeekdayFontSize = addStepperInput(gFSInputs, "12" + textUnitSuffix, { min: 0.1, max: 9999, unit: textUnitSuffix, onStep: refreshPreviewOnStep });
        inputWeekdayFontSize.helpTip = getLabel("tooltip.fontSize");
        inputWeekdayFontSize.characters = 3;
        inputWeekdayFontSize.onChanging = schedulePreviewRefresh;

        inputMonthFontSize = addStepperInput(gFSInputs, "12" + textUnitSuffix, { min: 0.1, max: 9999, unit: textUnitSuffix, onStep: refreshPreviewOnStep });
        inputMonthFontSize.helpTip = getLabel("tooltip.fontSize");
        inputMonthFontSize.characters = 3;
        inputMonthFontSize.onChanging = schedulePreviewRefresh;

        inputYearFontSize = addStepperInput(gFSInputs, "12" + textUnitSuffix, { min: 0.1, max: 9999, unit: textUnitSuffix, onStep: refreshPreviewOnStep });
        inputYearFontSize.helpTip = getLabel("tooltip.fontSize");
        inputYearFontSize.characters = 3;
        inputYearFontSize.onChanging = schedulePreviewRefresh;

        try { __SCM_syncYearPanelDimToFontSize(); } catch (e) { }

        // フォント（インストール済み）選択
        var gFontName = pnlFormat.add("group");
        var stFontLbl = gFontName.add("statictext", undefined, labelText("format.font"));
        var ddFont = gFontName.add("dropdownlist", undefined, []);
        ddFont.helpTip = getLabel("tooltip.fontName");
        gFontName.alignChildren = ["left", "center"];
        ddFont.minimumSize = [80, 22];
        ddFont.preferredSize = [180, 22];
        ddFont.maximumSize = [180, 22];

        // お気に入り（よく使うフォント）
        var gFontFav = pnlFormat.add("group");
        gFontFav.orientation = "row";
        gFontFav.alignChildren = ["left", "left"];
        var stFavLbl = gFontFav.add("statictext", undefined, labelText("format.favorites"));
        var ddFavFont = gFontFav.add("dropdownlist", undefined, [
            "-",
            "Automate OT Light",
            "Hegante Display Regular",
            "Bodoni Moda SemiBold",
            "DIN Condensed VF Regular",
            "Caflisch Script Pro Light",
            "AgencyFB Regular"
        ]);
        ddFavFont.helpTip = getLabel("tooltip.favFont");
        ddFavFont.minimumSize = [80, 22];
        ddFavFont.preferredSize = [180, 22];
        ddFavFont.maximumSize = [180, 22];
        try { ddFavFont.selection = 0; } catch (e) { }

        // フォント／お気に入りのラベル幅を一定に揃える（プルダウン左端を合わせる）/ Fix font & favorites label widths so the dropdowns align
        var __FONT_LABEL_W = 80;
        stFontLbl.preferredSize.width = __FONT_LABEL_W;
        stFavLbl.preferredSize.width = __FONT_LABEL_W;

        // お気に入りの解決は重いので、初回にだけ辞書化してキャッシュする
        var __SCM_FAV_LABELS = [
            "Automate OT Light",
            "Hegante Display Regular",
            "Bodoni Moda SemiBold",
            "DIN Condensed VF Regular",
            "Caflisch Script Pro Light",
            "AgencyFB Regular"
        ];

        /* お気に入りフォント名→内部名の対応表を一度だけ構築 / Build the favorite-label→internal-name map once */
        function __SCM_buildFavFontMapOnce() {
            try {
                var cache = ($.global.__SCM_CACHE = $.global.__SCM_CACHE || {});
                if (cache.favFontMap && cache.favFontMapBuilt) return cache.favFontMap;

                // lookup set
                var wantSet = {};
                for (var wi = 0; wi < __SCM_FAV_LABELS.length; wi++) {
                    var k = String(__SCM_FAV_LABELS[wi] || "").replace(/\s+/g, " ").replace(/^\s+|\s+$/g, "");
                    if (k) wantSet[k] = true;
                }

                var map = {};
                var len = app.textFonts.length;
                for (var i = 0; i < len; i++) {
                    var f = app.textFonts[i];
                    var disp = "";
                    try {
                        var fam = f.family || "";
                        var sty = f.style || "";
                        disp = (fam + " " + sty).replace(/\s+/g, " ").replace(/^\s+|\s+$/g, "");
                    } catch (e) { }

                    if (disp && wantSet[disp]) {
                        try { map[disp] = f.name; } catch (e) { }
                    }
                }

                cache.favFontMap = map;
                cache.favFontMapBuilt = true;
                return map;
            } catch (e) { }
            return {};
        }

        /* お気に入り表示名から内部フォント名を解決 / Resolve an internal font name from a favorite label */
        function __SCM_resolveFontInternalNameFromLabel(label) {
            try {
                var want = String(label || "").replace(/\s+/g, " ").replace(/^\s+|\s+$/g, "");
                if (!want) return null;

                var map = __SCM_buildFavFontMapOnce();
                if (map && map[want]) return map[want];

                // フォールバック：一致が無い場合は label をそのまま name として扱う
                return want;
            } catch (e) { }
            return null;
        }

        ddFavFont.onChange = function () {
            try {
                if (!ddFont || !ddFont.items || ddFont.items.length === 0) return;
                if (!ddFavFont.selection) return;

                var label = ddFavFont.selection.text;
                if (label === "-") return; // 無指定

                var internalName = __SCM_resolveFontInternalNameFromLabel(label);
                if (!internalName) return;

                // ddFont の items は TextFont.name で構成されている
                var __hit = false;
                for (var i = 0; i < ddFont.items.length; i++) {
                    if (ddFont.items[i].text === internalName) {
                        ddFont.selection = i;
                        __hit = true;
                        break;
                    }
                }

                if (__hit) {
                    try {
                        if (rbWdMTW) rbWdMTW.value = true;
                        if (rbWdJP) rbWdJP.value = false;
                        if (rbWdMon) rbWdMon.value = false;
                    } catch (e) { }
                    schedulePreviewRefresh(true);
                }
            } catch (e) { }
        };

        // ===== フォント一覧（キャッシュ対応）=====
        // 1) targetengine 上のメモリキャッシュ（Illustrator起動中だけ）
        // 2) うまく効かない環境向けに app.putCustomOptions の簡易キャッシュも併用（必要なら自動再構築）
        var __SCM_CACHE = ($.global.__SCM_CACHE = $.global.__SCM_CACHE || {});
        var fontNames = __SCM_CACHE.fontNames;

        // app.putCustomOptions 用キー（将来変更するときはバージョンを変える）
        var __FONT_CACHE_KEY = "SmartCalendarMaker_fontNames_v1";

        /* カスタムオプションからフォント一覧キャッシュを読む / Load the cached font list from custom options */
        function loadFontNamesFromCustomOptions() {
            try {
                var desc = app.getCustomOptions(__FONT_CACHE_KEY);
                if (!desc) return null;
                var s = desc.getString(0);
                if (!s) return null;
                var arr = s.split("\n");
                return (arr && arr.length) ? arr : null;
            } catch (e) { }
            return null;
        }

        /* フォント一覧をカスタムオプションへ保存 / Save the font list to custom options */
        function saveFontNamesToCustomOptions(arr) {
            try {
                var desc = new ActionDescriptor();
                // key 0 の string として保存
                desc.putString(0, arr.join("\n"));
                app.putCustomOptions(__FONT_CACHE_KEY, desc);
            } catch (e) { }
        }

        // engine キャッシュが無い場合は custom options も見る
        if (!fontNames || !fontNames.length) {
            fontNames = loadFontNamesFromCustomOptions();
            if (fontNames && fontNames.length) {
                __SCM_CACHE.fontNames = fontNames;
            }
        }

        // どちらも無ければ列挙して作成
        if (!fontNames || !fontNames.length) {
            // ===== 準備中プログレス（重い処理向け）=====
            function __createLoadingPalette(title, initialText, maxValue) {
                var w = new Window("palette", title || getLabel("loading.title"));
                setupWindow(w);

                var msg = w.add("statictext", undefined, initialText || getLabel("loading.text"));
                var bar = w.add("progressbar", undefined, 0, (typeof maxValue === "number" && maxValue > 0) ? maxValue : 100);
                bar.preferredSize = [260, 14];

                try { w.show(); } catch (e) { }

                return {
                    win: w,
                    msg: msg,
                    bar: bar,
                    setText: function (t) { try { msg.text = t; w.update(); } catch (e) { } },
                    setValue: function (v) { try { bar.value = v; w.update(); } catch (e) { } },
                    setMax: function (m) { try { bar.maxvalue = m; w.update(); } catch (e) { } },
                    close: function () { try { w.close(); } catch (e) { } }
                };
            }

            var __loading = __createLoadingPalette(getLabel("loading.title"), getLabel("loading.fontsRead"), 100);

            // フォント一覧を作成（名前でソート）
            fontNames = [];
            try {
                var __len = app.textFonts.length;
                for (var fi = 0; fi < __len; fi++) {
                    try { fontNames.push(app.textFonts[fi].name); } catch (e) { }
                    // 進捗更新（描画負荷を下げるため間引き）
                    if ((fi % 50) === 0) {
                        try {
                            __loading.setMax(__len);
                            __loading.setValue(fi);
                            __loading.setText(getLabel("loading.fontsRead") + " (" + fi + "/" + __len + ")");
                        } catch (e) { }
                    }
                }
            } catch (e) { }

            try { fontNames.sort(); } catch (e) { }

            // キャッシュに保存（両方）
            __SCM_CACHE.fontNames = fontNames;
            saveFontNamesToCustomOptions(fontNames);

            // 読み込み完了
            try {
                __loading.setMax((fontNames && fontNames.length) ? fontNames.length : 100);
                __loading.setValue((fontNames && fontNames.length) ? fontNames.length : 100);
                __loading.setText(getLabel("loading.ready"));
            } catch (e) { }
            __loading.close();
        }

        // dropdown に投入（毎回 UI は作り直す）
        // キャッシュされていても items 追加が重い環境があるため、必要に応じてプログレスを表示
        var __ddLoading = null;
        try {
            if (fontNames && fontNames.length >= 200) {
                // 既存の列挙用ヘルパーが未定義の可能性があるため、ここでも最小版を用意
                if (typeof __createLoadingPalette !== "function") {
                    var __createLoadingPalette = function (title, initialText, maxValue) {
                        var w = new Window("palette", title || getLabel("loading.title"));
                        setupWindow(w);
                        var msg = w.add("statictext", undefined, initialText || getLabel("loading.text"));
                        var bar = w.add("progressbar", undefined, 0, (typeof maxValue === "number" && maxValue > 0) ? maxValue : 100);
                        bar.preferredSize = [260, 14];
                        try { w.show(); } catch (e) { }
                        return {
                            win: w,
                            msg: msg,
                            bar: bar,
                            setText: function (t) { try { msg.text = t; w.update(); } catch (e) { } },
                            setValue: function (v) { try { bar.value = v; w.update(); } catch (e) { } },
                            setMax: function (m) { try { bar.maxvalue = m; w.update(); } catch (e) { } },
                            close: function () { try { w.close(); } catch (e) { } }
                        };
                    };
                }
                __ddLoading = __createLoadingPalette(getLabel("loading.title"), getLabel("loading.fontsSet"), fontNames.length);
            }
        } catch (e) { }

        for (var iFont = 0; iFont < fontNames.length; iFont++) {
            ddFont.add("item", fontNames[iFont]);
            if (__ddLoading && (iFont % 50) === 0) {
                try {
                    __ddLoading.setValue(iFont);
                    __ddLoading.setText(getLabel("loading.fontsSet") + " (" + iFont + "/" + fontNames.length + ")");
                } catch (e) { }
            }
        }

        if (__ddLoading) {
            try {
                __ddLoading.setValue(fontNames.length);
                __ddLoading.setText(getLabel("loading.ready"));
            } catch (e) { }
            __ddLoading.close();
        }

        // デフォルト: DNPShueiMGoStd-B があれば選択、なければ先頭
        var defaultFontName = "DNPShueiMGoStd-B";
        var foundIndex = -1;
        for (var di = 0; di < ddFont.items.length; di++) {
            if (ddFont.items[di].text === defaultFontName) { foundIndex = di; break; }
        }
        if (ddFont.items.length > 0) {
            ddFont.selection = (foundIndex >= 0) ? foundIndex : 0;
        }

        // ===== 下部コントロール行（左：プレビュー／右：キャンセル・OK）=====
        var buttonRow = addButtonRow(dlg);

        // 左側：プレビュー
        var previewChk = buttonRow.leftGroup.add("checkbox", undefined, getLabel("button.preview"));
        previewChk.helpTip = getLabel("tooltip.preview");
        previewChk.value = true;

        // 右側：ボタン
        var btnCancel = buttonRow.rightGroup.add("button", undefined, getLabel("button.cancel"), { name: "cancel" });
        var btnOK = buttonRow.rightGroup.add("button", undefined, getLabel("button.create"), { name: "ok" });

        // ===== プレビュー更新のデバウンス（入力中の連打を抑制）=====
        // onChanging が連続発火すると「全消去→大量生成」を連打してしまい重くなるため、
        // 最後の入力から少し待って1回だけ描画する。
        var __PREVIEW_TASK_ID = null;

        // scheduleTask から呼ぶため global に置く（#targetengine で Illustrator 起動中だけ保持）
        $.global.__SCM_doRefreshPreview = function () {
            try {
                __PREVIEW_TASK_ID = null;
                refreshPreview();
            } catch (e) { }
        };

        /* ∧∨・↑↓で値を変えたあとのプレビュー更新 / Refresh the preview after a stepper or arrow-key step */
        function refreshPreviewOnStep() {
            schedulePreviewRefresh();
        }

        /* プレビュー更新をデバウンスして予約 / Schedule a debounced preview refresh */
        function schedulePreviewRefresh(immediate) {
            // immediate===true のときは遅延なしで1回だけ実行
            try {
                if (__PREVIEW_TASK_ID) {
                    try { app.cancelTask(__PREVIEW_TASK_ID); } catch (e) { }
                    __PREVIEW_TASK_ID = null;
                }
                var delay = (immediate === true) ? 0 : __PREVIEW_DELAY_MS;
                __PREVIEW_TASK_ID = app.scheduleTask('$.global.__SCM_doRefreshPreview()', delay, false);
            } catch (e) {
                // scheduleTask が使えない/失敗した環境では従来通り即時更新
                try { refreshPreview(); } catch (__e) { }
            }
        }

        // ===== プリセット（書き出し / 読み込み） =====
        /* ラジオ群から選択中のキーを返す / Return the selected key from a radio group */
        function __SCM_getSelectedRadioValue(map) {
            try {
                for (var k in map) {
                    if (map.hasOwnProperty(k) && map[k] && map[k].value) return k;
                }
            } catch (e) { }
            return null;
        }

        /* キー指定でラジオ群を選択 / Select a radio in a group by key */
        function __SCM_setRadioByKey(map, key) {
            try {
                for (var k in map) {
                    if (!map.hasOwnProperty(k) || !map[k]) continue;
                    map[k].value = (k === key);
                }
            } catch (e) { }
        }

        /* ドロップダウンの選択テキストを返す / Return the selected text of a dropdown */
        function __SCM_getDropdownText(dd) {
            try { return (dd && dd.selection) ? (dd.selection.text || "") : ""; } catch (e) { }
            return "";
        }

        /* テキスト一致でドロップダウンを選択 / Select a dropdown item by matching text */
        function __SCM_setDropdownByText(dd, text) {
            try {
                if (!dd || !dd.items || dd.items.length === 0) return false;
                var t = String(text || "");
                for (var i = 0; i < dd.items.length; i++) {
                    if (dd.items[i].text === t) { dd.selection = i; return true; }
                }
            } catch (e) { }
            return false;
        }

        /* 現在のUI状態をプリセットオブジェクトへ直列化 / Serialize the current UI state into a preset object */
        function __SCM_serializePreset() {
            return {
                // date
                y: Number(inputY.text),
                m: Number(inputM.text),
                d: Number(inputD.text),

                // layout counts
                monthCount: Number(inputMonths.text),
                colCount: Number(inputCols.text),

                // base
                startFrom: __SCM_getSelectedRadioValue({ current: rbStartCurrent, jan: rbStartJan }),

                // year
                showTopYear: !!(chkTopYear && chkTopYear.value),
                topYearBottomMargin: parseFloat(inputTopYearBottomMargin.text),

                // month
                includeYearInMonthTitle: !!(chkMonthYear && chkMonthYear.value),
                monthTitleAlign: __SCM_getSelectedRadioValue({ left: rbMonthAlignL, center: rbMonthAlignC, right: rbMonthAlignR }),
                monthTitleMode: __SCM_getSelectedRadioValue({ num: rbMonthNum, pad: rbMonthPad, en: rbMonthEn, ens: rbMonthEnS }),
                monthBottomMargin: parseFloat(inputMonthBottomMargin.text),
                monthTitleBottomBorder: !!(chkMonthBottomBorder && chkMonthBottomBorder.value),

                // weekday
                weekStart: __SCM_getSelectedRadioValue({ mon: rbWeekMon, sun: rbWeekSun }),
                weekdayLabelMode: __SCM_getSelectedRadioValue({ jp: rbWdJP, mtw: rbWdMTW, mon: rbWdMon }),
                weekdayBottomMargin: parseFloat(inputWeekdayBottomMargin.text),
                weekdayFontSize: parseFloat(inputWeekdayFontSize.text),
                monthFontSize: parseFloat(inputMonthFontSize.text),
                yearFontSize: parseFloat(inputYearFontSize.text),

                // layout
                cellW: parseFloat(inputCellW.text),
                cellH: parseFloat(inputCellH.text),
                cellGapX: parseFloat(inputCellGapX.text),
                cellGapY: parseFloat(inputCellGapY.text),
                cellPosAdjY: parseFloat(inputCellPosAdjY.text),
                outerMarginX: parseFloat(inputOuterMarginX.text),
                outerMarginY: parseFloat(inputOuterMarginY.text),

                cellFill: !!(chkCellFill && chkCellFill.value),

                // format
                fontName: __SCM_getDropdownText(ddFont),
                favFont: __SCM_getDropdownText(ddFavFont),
                fontSize: parseFloat(inputFontSize.text),

                align: __SCM_getSelectedRadioValue({ left: rbLeft, center: rbCenter, right: rbRight }),
                sundayRed: !!(chkSundayRed && chkSundayRed.value),
                holidayRed: !!(chkHolidayRed && chkHolidayRed.value)
            };
        }

        /* プリセットオブジェクトをUIへ反映 / Apply a preset object to the UI */
        function __SCM_applyPreset(obj) {
            if (!obj) return;

            function setTextSafe(et, v) { try { if (et && v != null) et.text = formatInputText(et, v); } catch (e) { } }
            function setCheckSafe(chk, v) { try { if (chk && v != null) chk.value = !!v; } catch (e) { } }

            // date
            setTextSafe(inputY, obj.y);
            setTextSafe(inputM, obj.m);
            setTextSafe(inputD, obj.d);

            setTextSafe(inputMonths, obj.monthCount);
            setTextSafe(inputCols, obj.colCount);

            if (obj.startFrom) __SCM_setRadioByKey({ current: rbStartCurrent, jan: rbStartJan }, obj.startFrom);

            // year
            setCheckSafe(chkTopYear, obj.showTopYear);
            setTextSafe(inputTopYearBottomMargin, obj.topYearBottomMargin);
            gYearMargin.enabled = !!(chkTopYear && chkTopYear.value);
            redrawSteppersIn(gYearMargin);

            // month
            setCheckSafe(chkMonthYear, obj.includeYearInMonthTitle);
            if (obj.monthTitleAlign) __SCM_setRadioByKey({ left: rbMonthAlignL, center: rbMonthAlignC, right: rbMonthAlignR }, obj.monthTitleAlign);
            if (obj.monthTitleMode) __SCM_setRadioByKey({ num: rbMonthNum, pad: rbMonthPad, en: rbMonthEn, ens: rbMonthEnS }, obj.monthTitleMode);
            setTextSafe(inputMonthBottomMargin, obj.monthBottomMargin);
            setCheckSafe(chkMonthBottomBorder, obj.monthTitleBottomBorder);

            // weekday
            if (obj.weekStart) __SCM_setRadioByKey({ mon: rbWeekMon, sun: rbWeekSun }, obj.weekStart);
            if (obj.weekdayLabelMode) __SCM_setRadioByKey({ jp: rbWdJP, mtw: rbWdMTW, mon: rbWdMon }, obj.weekdayLabelMode);
            setTextSafe(inputWeekdayBottomMargin, obj.weekdayBottomMargin);
            setTextSafe(inputWeekdayFontSize, obj.weekdayFontSize);
            setTextSafe(inputMonthFontSize, obj.monthFontSize);
            setTextSafe(inputYearFontSize, obj.yearFontSize);

            // layout
            setTextSafe(inputCellW, obj.cellW);
            setTextSafe(inputCellH, obj.cellH);
            setTextSafe(inputCellGapX, (obj.cellGapX != null) ? obj.cellGapX : 0);
            setTextSafe(inputCellGapY, (obj.cellGapY != null) ? obj.cellGapY : 0);
            setTextSafe(inputOuterMarginX, obj.outerMarginX);
            setTextSafe(inputOuterMarginY, obj.outerMarginY);

            setTextSafe(inputCellPosAdjY, (obj.cellPosAdjY != null) ? obj.cellPosAdjY : 0);
            setCheckSafe(chkCellFill, (obj.cellFill != null) ? obj.cellFill : true);

            // format
            setTextSafe(inputFontSize, obj.fontSize);
            if (obj.align) __SCM_setRadioByKey({ left: rbLeft, center: rbCenter, right: rbRight }, obj.align);
            setCheckSafe(chkSundayRed, obj.sundayRed);
            setCheckSafe(chkHolidayRed, obj.holidayRed);

            // dropdowns
            try { if (ddFavFont && obj.favFont != null) __SCM_setDropdownByText(ddFavFont, obj.favFont); } catch (e) { }
            try { if (ddFont && obj.fontName != null) __SCM_setDropdownByText(ddFont, obj.fontName); } catch (e) { }

            // enable sync
            try {
                var mc = Math.round(Number(inputMonths.text));
                pnlMonthOuter.enabled = (mc !== 1);
                redrawSteppersIn(pnlMonthOuter);
            } catch (e) { }

            try { schedulePreviewRefresh(true); } catch (e) { }
        }

        /* プリセットを保存用テキスト(JS/JSON)へ変換 / Convert a preset to savable text (JS/JSON) */
        function __SCM_toJsLiteral(obj) {
            // Human-editable preset format
            // Prefer JSON.stringify when available; otherwise use ExtendScript toSource().
            try {
                if (typeof JSON !== "undefined" && JSON && typeof JSON.stringify === "function") {
                    var json = JSON.stringify(obj, null, 2);
                    return "// SmartCalendarMaker preset\n// " + SCRIPT_VERSION + "\n(" + json + ")\n";
                }
            } catch (e) { }

            // JSON が無い/使えない環境向け（ExtendScript）
            try {
                if (obj && typeof obj.toSource === "function") {
                    // toSource() は既に ({...}) 形式を返すことが多いので、そのまま包む
                    var src = String(obj.toSource());
                    // 念のため式として評価できる形に
                    if (!/^\s*\(.*\)\s*$/.test(src)) src = "(" + src + ")";
                    return "// SmartCalendarMaker preset\n// " + SCRIPT_VERSION + "\n" + src + "\n";
                }
            } catch (e) { }

            // 最終フォールバック：空オブジェクト
            return "// SmartCalendarMaker preset\n// " + SCRIPT_VERSION + "\n({})\n";
        }

        /* 保存テキストからプリセットを復元 / Parse a preset from saved text */
        function __SCM_parsePresetText(text) {
            // Try JSON first, then JS literal (eval)
            var s = String(text || "");
            // strip BOM
            s = s.replace(/^\uFEFF/, "");
            try {
                if (typeof JSON !== "undefined" && JSON && typeof JSON.parse === "function") {
                    return JSON.parse(s);
                }
            } catch (e) { }
            try {
                // allow files saved as: ( { ... } ) or ({...}) or just {...}
                var body = s;
                // Remove leading comments
                body = body.replace(/^\s*\/\/.*$/mg, "");
                body = body.replace(/^\s*\/\*[\s\S]*?\*\//, "");
                // Ensure object literal is evaluated correctly
                var wrapped = body;
                if (!/^\s*\(.*\)\s*$/.test(body)) {
                    wrapped = "(" + body + ")";
                }
                var obj = eval(wrapped);
                return obj;
            } catch (e) {
                return null;
            }
        }

        /* プリセットをファイルへ書き出す / Save a preset to a file */
        function __SCM_savePresetToFile() {
            try {
                var obj = __SCM_serializePreset();
                var txt = __SCM_toJsLiteral(obj);

                var f = File.saveDialog(getLabel("preset.saveDialog") + " " + getLabel("preset.saveHint"), "*.jsxpreset;*.json");
                if (!f) return;

                var nameLower = String(f.name || "").toLowerCase();
                if (!/\.(jsxpreset|json)$/i.test(nameLower)) {
                    // default extension
                    try { f = new File(f.fsName + ".jsxpreset"); } catch (e) { }
                    nameLower = String(f.name || "").toLowerCase();
                }

                // If user explicitly chose .json, save JSON (only if available)
                if (/\.json$/i.test(nameLower)) {
                    if (typeof JSON === "undefined" || !JSON || typeof JSON.stringify !== "function") {
                        alert(getLabel("preset.err") + "\n\n" + "JSON.stringify が利用できないため .json では保存できません。\n拡張子 .jsxpreset を選んでください。\n");
                        return;
                    }
                    txt = JSON.stringify(obj, null, 2);
                }

                f.encoding = "UTF-8";
                if (f.open("w")) {
                    f.write(txt);
                    f.close();
                    alert(getLabel("preset.saved"));
                }
            } catch (e) {
                alert(getLabel("preset.err") + "\n\n" + e);
            }
        }

        /* プリセットをファイルから読み込む / Load a preset from a file */
        function __SCM_loadPresetFromFile() {
            try {
                var f = File.openDialog(getLabel("preset.loadDialog"), "*.json;*.jsxpreset");
                if (!f) return;
                f.encoding = "UTF-8";
                if (!f.open("r")) return;
                var s = f.read();
                f.close();
                var obj = __SCM_parsePresetText(s);
                if (!obj) throw new Error("Preset parse error");

                // 読み込んだプリセットを一覧に追加（ラベルはファイル名）
                try {
                    var label = "";
                    try {
                        label = f.displayName || f.name || "";
                    } catch (e) { }
                    label = String(label || "");
                    label = label.replace(/\.(json|jsxpreset)$/i, "");
                    if (label) __SCM_addPresetToDropdown(label, obj);
                } catch (e) { }

                __SCM_applyPreset(obj);
                alert(getLabel("preset.loaded"));
            } catch (e) {
                alert(getLabel("preset.err") + "\n\n" + e);
            }
        }

        // button handlers
        presetSaveBtn.onClick = function () { __SCM_savePresetToFile(); };
        presetLoadBtn.onClick = function () { __SCM_loadPresetFromFile(); };

        /* 入力値からプレビュー用カレンダーを再生成 / Rebuild the preview calendar from current inputs */
        function refreshPreview() {
            // UI同期（プレビューOFFでも反映）: 月数=1のとき外側マージンをディム
            try {
                var __mc = Math.round(Number(inputMonths.text));
                if (!__mc || __mc < 1) __mc = 1;
                if (__mc > 24) __mc = 24;
                pnlMonthOuter.enabled = (__mc !== 1);
                redrawSteppersIn(pnlMonthOuter);
                // レイアウトの月数/列数は 1ヶ月 のときディム
                gCount.enabled = (__mc !== 1);
                redrawSteppersIn(gCount);
                // ゴーストは 1ヶ月 のときだけ有効
                try {
                    chkGhost.enabled = (__mc === 1);
                    if (__mc !== 1) chkGhost.value = false;
                } catch (e) { }
            } catch (e) { }

            if (!previewChk.value) return;

            // プレビューレイヤーを全削除して作り直す
            removeLayerIfExists(doc, PREVIEW_LAYER_NAME);

            var baseDate = parseYMDFields(inputY.text, inputM.text, inputD.text);
            if (!baseDate) return; // 不正入力はプレビューしない
            var monthCount = Math.round(Number(inputMonths.text));
            if (!monthCount || monthCount < 1) monthCount = 1;
            if (monthCount > 24) monthCount = 24;

            var colCount = Math.round(Number(inputCols.text));
            if (!colCount || colCount < 1) colCount = 1;
            if (colCount > 12) colCount = 12;
            if (colCount > monthCount) colCount = monthCount;

            // 月数プリセット（1/3/12）と同期（列数も含めて判定）
            try {
                var isP1 = (monthCount === 1 && colCount === 1);
                var isP3 = (monthCount === 3 && colCount === 3);
                var isP12 = (monthCount === 12 && colCount === 3);

                rbPreset1.value = isP1;
                rbPreset3.value = isP3;
                rbPreset12.value = isP12;

                if (!isP1 && !isP3 && !isP12) {
                    rbPreset1.value = false;
                    rbPreset3.value = false;
                    rbPreset12.value = false;
                }

                // 「年」panel: 年表示は 12ヶ月 のときだけON（手入力で一致した場合も含む）
                chkTopYear.value = isP12;
                chkTopYear.enabled = isP12;
                __SCM_syncYearPanelDimToFontSize();

                gYearMargin.enabled = chkTopYear.value;

                redrawSteppersIn(gYearMargin);

                // 12ヶ月 プリセット時は「1月から」を強制
                if (isP12) {
                    rbStartJan.value = true;
                    rbStartCurrent.value = false;
                    // 12ヶ月のときは月タイトルの「年を併記」をOFF
                    chkMonthYear.value = false;
                }
            } catch (e) { }

            var fontSize = parseFloat(inputFontSize.text);
            if (!fontSize || fontSize <= 0) return;

            var align = rbLeft.value ? "left" : (rbRight.value ? "right" : "center");
            var monthTitleAlign = rbMonthAlignL.value ? "left" : (rbMonthAlignR.value ? "right" : "center");
            var fontName = (ddFont && ddFont.selection) ? ddFont.selection.text : null;
            var sundayRed = (chkSundayRed && chkSundayRed.value) ? true : false;
            var holidayRed = (chkHolidayRed && chkHolidayRed.value) ? true : false;

            var ghost = (chkGhost && chkGhost.enabled && chkGhost.value) ? true : false;

            var cellFill = !!(chkCellFill && chkCellFill.value);

            // 罫線設定
            var strokeMode = (rbStrokeNone && rbStrokeNone.value) ? "none"
                : ((rbStrokeCustom && rbStrokeCustom.value) ? "custom" : "all");

            var strokeTop = !!(chkStrokeTop && chkStrokeTop.value);
            var strokeBottom = !!(chkStrokeBottom && chkStrokeBottom.value);
            var strokeLeft = !!(chkStrokeLeft && chkStrokeLeft.value);
            var strokeRight = !!(chkStrokeRight && chkStrokeRight.value);

            if (strokeMode === "all") {
                strokeTop = strokeBottom = strokeLeft = strokeRight = true;
            }

            var cellW = readLengthFieldPt(inputCellW);
            var cellH = readLengthFieldPt(inputCellH);
            if (!cellW || isNaN(cellW) || cellW <= 0) return;
            if (!cellH || isNaN(cellH) || cellH <= 0) return;

            var cellGapX = readLengthFieldPt(inputCellGapX);
            var cellGapY = readLengthFieldPt(inputCellGapY);
            if (isNaN(cellGapX) || cellGapX < 0) cellGapX = 0;
            if (cellGapX > 2000) cellGapX = 2000;
            if (isNaN(cellGapY) || cellGapY < 0) cellGapY = 0;
            if (cellGapY > 2000) cellGapY = 2000;

            var cellPosAdjY = readLengthFieldPt(inputCellPosAdjY);
            if (isNaN(cellPosAdjY)) cellPosAdjY = 0;
            if (cellPosAdjY < -2000) cellPosAdjY = -2000;
            if (cellPosAdjY > 2000) cellPosAdjY = 2000;

            var showTopYear = (chkTopYear && chkTopYear.value) ? true : false;
            var includeYearInMonthTitle = (chkMonthYear && chkMonthYear.value) ? true : false;
            var monthTitleBottomBorder = (chkMonthBottomBorder && chkMonthBottomBorder.value) ? true : false;
            var monthTitleMode = getMonthTitleMode();
            var topYearBottomMargin = readLengthFieldPt(inputTopYearBottomMargin);
            if (isNaN(topYearBottomMargin) || topYearBottomMargin < 0) topYearBottomMargin = 0;
            if (topYearBottomMargin > 2000) topYearBottomMargin = 2000;

            var monthBottomMargin = readLengthFieldPt(inputMonthBottomMargin);
            if (isNaN(monthBottomMargin) || monthBottomMargin < 0) monthBottomMargin = 0;
            if (monthBottomMargin > 2000) monthBottomMargin = 2000;

            var weekdayBottomMargin = readLengthFieldPt(inputWeekdayBottomMargin);
            if (isNaN(weekdayBottomMargin) || weekdayBottomMargin < 0) weekdayBottomMargin = 0;
            if (weekdayBottomMargin > 2000) weekdayBottomMargin = 2000;

            var weekdayFontSize = parseFloat(inputWeekdayFontSize.text);
            if (!weekdayFontSize || weekdayFontSize <= 0) weekdayFontSize = fontSize;

            var monthFontSize = parseFloat(inputMonthFontSize.text);
            if (!monthFontSize || monthFontSize <= 0) monthFontSize = fontSize;

            var yearFontSize = parseFloat(inputYearFontSize.text);
            if (!yearFontSize || yearFontSize <= 0) yearFontSize = fontSize;

            var outerMarginX = readLengthFieldPt(inputOuterMarginX);
            if (isNaN(outerMarginX) || outerMarginX < 0) outerMarginX = 0;
            if (outerMarginX > 5000) outerMarginX = 5000;

            var outerMarginY = readLengthFieldPt(inputOuterMarginY);
            if (isNaN(outerMarginY) || outerMarginY < 0) outerMarginY = 0;
            if (outerMarginY > 5000) outerMarginY = 5000;

            var startFromJanuary = false;
            try { startFromJanuary = (rbStartJan && rbStartJan.value) ? true : false; } catch (e) { }

            var weekStartMonday = true;
            try { weekStartMonday = (rbWeekSun && rbWeekSun.value) ? false : true; } catch (e) { }

            var weekdayLabelMode = getWeekdayLabelMode();
            try {
                var options = {
                    fontSize: fontSize,
                    align: align,
                    monthTitleAlign: monthTitleAlign,
                    fontName: fontName,
                    sundayRed: sundayRed,
                    holidayRed: holidayRed,
                    ghost: ghost,
                    cell: {
                        w: cellW,
                        h: cellH,
                        gapX: cellGapX,
                        gapY: cellGapY,
                        bgOffsetY: cellPosAdjY,
                        fill: cellFill,
                        stroke: {
                            mode: strokeMode,
                            top: strokeTop,
                            bottom: strokeBottom,
                            left: strokeLeft,
                            right: strokeRight
                        }
                    },
                    year: {
                        showTop: showTopYear,
                        bottomMargin: topYearBottomMargin,
                        fontSize: yearFontSize
                    },
                    month: {
                        includeYear: includeYearInMonthTitle,
                        titleBottomBorder: monthTitleBottomBorder,
                        titleMode: monthTitleMode,
                        bottomMargin: monthBottomMargin,
                        fontSize: monthFontSize
                    },
                    weekday: {
                        startMonday: weekStartMonday,
                        labelMode: weekdayLabelMode,
                        bottomMargin: weekdayBottomMargin,
                        fontSize: weekdayFontSize
                    },
                    unit: {
                        outerX: outerMarginX,
                        outerY: outerMarginY
                    },
                    layout: {
                        monthCount: monthCount,
                        colCount: colCount,
                        startFromJanuary: startFromJanuary
                    }
                };
                buildCalendarOpt(doc, baseDate, PREVIEW_LAYER_NAME, options);
            } catch (e) {
                try { removeLayerIfExists(doc, PREVIEW_LAYER_NAME); } catch (e) { }
                alert("Preview error:\n\n" + e);
                return;
            }
            app.redraw();
        }

        // ===== buildCalendar: options object wrapper =====
        // 引数ズレを防ぐため、呼び出し側は options だけを組み立てて渡す。
        /* optを正規化してbuildCalendarへ委譲 / Normalize the options object and delegate to buildCalendar */
        function buildCalendarOpt(doc, baseDate, layerName, options) {
            options = options || {};
            options.cell = options.cell || {};
            options.cell.stroke = options.cell.stroke || {};
            options.month = options.month || {};
            options.year = options.year || {};
            options.weekday = options.weekday || {};
            options.unit = options.unit || {};
            options.layout = options.layout || {};

            // normalize
            var fontSize = Number(options.fontSize); if (!fontSize || fontSize <= 0) fontSize = 12;
            var align = options.align || "center";
            var monthTitleAlign = options.monthTitleAlign || align;
            var fontName = options.fontName || null;
            var sundayRed = !!options.sundayRed;
            var holidayRed = !!options.holidayRed;
            var ghost = !!options.ghost;

            var cellW = Number(options.cell.w);
            var cellH = Number(options.cell.h);
            var cellGapX = Number(options.cell.gapX) || 0;
            var cellGapY = Number(options.cell.gapY) || 0;
            var cellPosAdjY = Number(options.cell.bgOffsetY) || 0; // 背景用
            var cellFill = !!options.cell.fill;

            var st = options.cell.stroke;
            var strokeMode = st.mode || "none";
            var strokeTop = !!st.top;
            var strokeBottom = !!st.bottom;
            var strokeLeft = !!st.left;
            var strokeRight = !!st.right;

            var showTopYear = !!options.year.showTop;
            var includeYearInMonthTitle = !!options.month.includeYear;
            var monthTitleBottomBorder = !!options.month.titleBottomBorder;
            var topYearBottomMargin = Number(options.year.bottomMargin) || 0;

            var monthCount = Math.round(Number(options.layout.monthCount));
            if (!monthCount || monthCount < 1) monthCount = 1;
            var colCount = Math.round(Number(options.layout.colCount));
            if (!colCount || colCount < 1) colCount = 1;

            var monthTitleMode = options.month.titleMode || "pad";
            var monthBottomMargin = Number(options.month.bottomMargin) || 0;
            var weekdayBottomMargin = Number(options.weekday.bottomMargin) || 0;

            var outerMarginX = Number(options.unit.outerX) || 0;
            var outerMarginY = Number(options.unit.outerY) || 0;

            var startFromJanuary = !!options.layout.startFromJanuary;
            var weekStartMonday = (options.weekday.startMonday !== false);
            var weekdayLabelMode = options.weekday.labelMode || "jp";

            var weekdayFontSize = Number(options.weekday.fontSize);
            var monthFontSize = Number(options.month.fontSize);
            var yearFontSize = Number(options.year.fontSize);
            if (!weekdayFontSize || weekdayFontSize <= 0) weekdayFontSize = fontSize;
            if (!monthFontSize || monthFontSize <= 0) monthFontSize = fontSize;
            if (!yearFontSize || yearFontSize <= 0) yearFontSize = fontSize;

            // Delegate to the existing implementation (現行buildCalendarは温存)
            buildCalendar(doc, baseDate, layerName, fontSize, align, monthTitleAlign, fontName, sundayRed, holidayRed, ghost,
                cellW, cellH, cellGapX, cellGapY, cellPosAdjY, cellFill,
                strokeMode, strokeTop, strokeBottom, strokeLeft, strokeRight,
                showTopYear, includeYearInMonthTitle, monthTitleBottomBorder, topYearBottomMargin,
                monthCount, colCount, monthTitleMode, monthBottomMargin, weekdayBottomMargin,
                outerMarginX, outerMarginY, startFromJanuary, weekStartMonday, weekdayLabelMode,
                weekdayFontSize, monthFontSize, yearFontSize);
        }

        inputY.onChanging = schedulePreviewRefresh;
        inputM.onChanging = schedulePreviewRefresh;
        inputD.onChanging = schedulePreviewRefresh;
        inputMonths.onChanging = schedulePreviewRefresh;
        inputCols.onChanging = schedulePreviewRefresh;
        previewChk.onClick = function () { schedulePreviewRefresh(true); };
        if (ddFont) ddFont.onChange = function () { schedulePreviewRefresh(true); };

        /* キーボードショートカット：L=左 / C=中央 / R=右（数値欄の入力中も効く）
           Keyboard shortcuts: L = left / C = center / R = right (also while a numeric field has focus) */
        addKeyShortcuts(dlg, {
            "L": rbLeft,
            "C": rbCenter,
            "R": rbRight
        }, {
            numericFields: [
                inputY, inputM, inputD,
                inputWeekdayBottomMargin, inputMonthBottomMargin, inputTopYearBottomMargin,
                inputMonths, inputCols, inputOuterMarginX, inputOuterMarginY,
                inputCellW, inputCellH, inputCellGapX, inputCellGapY, inputCellPosAdjY,
                inputFontSize, inputWeekdayFontSize, inputMonthFontSize, inputYearFontSize
            ]
        });

        btnOK.onClick = function () {
            var baseDate = parseYMDFields(inputY.text, inputM.text, inputD.text);
            if (!baseDate) {
                alert(getLabel("error.badDate"));
                return;
            }
            var monthCount = Math.round(Number(inputMonths.text));
            if (!monthCount || monthCount < 1) monthCount = 1;
            if (monthCount > 24) monthCount = 24;

            var colCount = Math.round(Number(inputCols.text));
            if (!colCount || colCount < 1) colCount = 1;
            if (colCount > 12) colCount = 12;
            if (colCount > monthCount) colCount = monthCount;

            var fontSize = parseFloat(inputFontSize.text);
            if (!fontSize || fontSize <= 0) {
                alert(getLabel("error.badFontSize"));
                return;
            }

            var ghost = (chkGhost && chkGhost.enabled && chkGhost.value) ? true : false;

            // プレビューONで既に描画済みなら、それをそのまま確定（再描画しない）
            var __existingPreview = null;
            try { __existingPreview = getLayerByName(doc, PREVIEW_LAYER_NAME); } catch (e) { }
            var __finalName = "Calendar_" + baseDate.getFullYear() + "_" + pad2(baseDate.getMonth() + 1);
            try {
                if (previewChk && previewChk.value && __existingPreview && __existingPreview.pageItems && __existingPreview.pageItems.length > 0) {
                    __existingPreview.name = __finalName;
                    app.redraw();
                    dlg.close(1);
                    return;
                }
            } catch (e) { }

            // プレビューOFFや未描画の場合は、ここで確定生成
            clearLayerContents(doc, PREVIEW_LAYER_NAME);
            var align = rbLeft.value ? "left" : (rbRight.value ? "right" : "center");
            var monthTitleAlign = rbMonthAlignL.value ? "left" : (rbMonthAlignR.value ? "right" : "center");
            var fontName = (ddFont && ddFont.selection) ? ddFont.selection.text : null;
            var sundayRed = (chkSundayRed && chkSundayRed.value) ? true : false;
            var holidayRed = (chkHolidayRed && chkHolidayRed.value) ? true : false;

            var cellFill = !!(chkCellFill && chkCellFill.value);

            // 罫線設定
            var strokeMode = (rbStrokeNone && rbStrokeNone.value) ? "none"
                : ((rbStrokeCustom && rbStrokeCustom.value) ? "custom" : "all");

            var strokeTop = !!(chkStrokeTop && chkStrokeTop.value);
            var strokeBottom = !!(chkStrokeBottom && chkStrokeBottom.value);
            var strokeLeft = !!(chkStrokeLeft && chkStrokeLeft.value);
            var strokeRight = !!(chkStrokeRight && chkStrokeRight.value);

            if (strokeMode === "all") {
                strokeTop = strokeBottom = strokeLeft = strokeRight = true;
            }

            var cellW = readLengthFieldPt(inputCellW);
            var cellH = readLengthFieldPt(inputCellH);
            if (!cellW || isNaN(cellW) || cellW <= 0) return alert(getLabel("error.badCellW"));
            if (!cellH || isNaN(cellH) || cellH <= 0) return alert(getLabel("error.badCellH"));

            var cellGapX = readLengthFieldPt(inputCellGapX);
            var cellGapY = readLengthFieldPt(inputCellGapY);
            if (isNaN(cellGapX) || cellGapX < 0) cellGapX = 0;
            if (cellGapX > 2000) cellGapX = 2000;
            if (isNaN(cellGapY) || cellGapY < 0) cellGapY = 0;
            if (cellGapY > 2000) cellGapY = 2000;

            var cellPosAdjY = readLengthFieldPt(inputCellPosAdjY);
            if (isNaN(cellPosAdjY)) cellPosAdjY = 0;
            if (cellPosAdjY < -2000) cellPosAdjY = -2000;
            if (cellPosAdjY > 2000) cellPosAdjY = 2000;

            var showTopYear = (chkTopYear && chkTopYear.value) ? true : false;
            var includeYearInMonthTitle = (chkMonthYear && chkMonthYear.value) ? true : false;
            var monthTitleBottomBorder = (chkMonthBottomBorder && chkMonthBottomBorder.value) ? true : false;
            var monthTitleMode = getMonthTitleMode();
            var topYearBottomMargin = readLengthFieldPt(inputTopYearBottomMargin);
            if (isNaN(topYearBottomMargin) || topYearBottomMargin < 0) topYearBottomMargin = 0;
            if (topYearBottomMargin > 2000) topYearBottomMargin = 2000;

            var monthBottomMargin = readLengthFieldPt(inputMonthBottomMargin);
            if (isNaN(monthBottomMargin) || monthBottomMargin < 0) monthBottomMargin = 0;
            if (monthBottomMargin > 2000) monthBottomMargin = 2000;

            var weekdayBottomMargin = readLengthFieldPt(inputWeekdayBottomMargin);
            if (isNaN(weekdayBottomMargin) || weekdayBottomMargin < 0) weekdayBottomMargin = 0;
            if (weekdayBottomMargin > 2000) weekdayBottomMargin = 2000;

            var outerMarginX = readLengthFieldPt(inputOuterMarginX);
            if (isNaN(outerMarginX) || outerMarginX < 0) outerMarginX = 0;
            if (outerMarginX > 5000) outerMarginX = 5000;

            var outerMarginY = readLengthFieldPt(inputOuterMarginY);
            if (isNaN(outerMarginY) || outerMarginY < 0) outerMarginY = 0;
            if (outerMarginY > 5000) outerMarginY = 5000;

            var startFromJanuary = false;
            try { startFromJanuary = (rbStartJan && rbStartJan.value) ? true : false; } catch (e) { }

            var weekStartMonday = true;
            try { weekStartMonday = (rbWeekSun && rbWeekSun.value) ? false : true; } catch (e) { }

            var weekdayLabelMode = getWeekdayLabelMode();

            var weekdayFontSize = parseFloat(inputWeekdayFontSize.text);
            if (!weekdayFontSize || weekdayFontSize <= 0) weekdayFontSize = fontSize;

            var monthFontSize = parseFloat(inputMonthFontSize.text);
            if (!monthFontSize || monthFontSize <= 0) monthFontSize = fontSize;

            var yearFontSize = parseFloat(inputYearFontSize.text);
            if (!yearFontSize || yearFontSize <= 0) yearFontSize = fontSize;

            var options = {
                fontSize: fontSize,
                align: align,
                monthTitleAlign: monthTitleAlign,
                fontName: fontName,
                sundayRed: sundayRed,
                holidayRed: holidayRed,
                ghost: ghost,
                cell: {
                    w: cellW,
                    h: cellH,
                    gapX: cellGapX,
                    gapY: cellGapY,
                    bgOffsetY: cellPosAdjY,
                    fill: cellFill,
                    stroke: {
                        mode: strokeMode,
                        top: strokeTop,
                        bottom: strokeBottom,
                        left: strokeLeft,
                        right: strokeRight
                    }
                },
                year: {
                    showTop: showTopYear,
                    bottomMargin: topYearBottomMargin,
                    fontSize: yearFontSize
                },
                month: {
                    includeYear: includeYearInMonthTitle,
                    titleBottomBorder: monthTitleBottomBorder,
                    titleMode: monthTitleMode,
                    bottomMargin: monthBottomMargin,
                    fontSize: monthFontSize
                },
                weekday: {
                    startMonday: weekStartMonday,
                    labelMode: weekdayLabelMode,
                    bottomMargin: weekdayBottomMargin,
                    fontSize: weekdayFontSize
                },
                unit: {
                    outerX: outerMarginX,
                    outerY: outerMarginY
                },
                layout: {
                    monthCount: monthCount,
                    colCount: colCount,
                    startFromJanuary: startFromJanuary
                }
            };

            buildCalendarOpt(doc, baseDate, PREVIEW_LAYER_NAME, options);

            // 確定：プレビューレイヤー名を変更して残す
            var lyr = getLayerByName(doc, PREVIEW_LAYER_NAME);
            if (lyr) lyr.name = __finalName;

            app.redraw();
            dlg.close(1);
        };

        btnCancel.onClick = function () {
            try {
                if (__SCM_VIEW && __SCM_ORG_ZOOM != null && __SCM_ORG_CENTER != null) {
                    __SCM_VIEW.zoom = __SCM_ORG_ZOOM;
                    __SCM_VIEW.centerPoint = __SCM_ORG_CENTER;
                    app.redraw();
                }
            } catch (e) { }
            removeLayerIfExists(doc, PREVIEW_LAYER_NAME);
            app.redraw();
            dlg.close(0);
        };

        alignRightOnlyButtonRow(buttonRow);
        prepareDialogWindow(dlg, SCRIPT_NAME);
        dlg.show();

        // ====== functions ======
        /* カレンダー本体（年/月/曜日/日付/罫線）を描画 / Draw the calendar body (year/month/weekday/dates/borders) */
        function buildCalendar(
            doc, baseDate, layerName, fontSize, alignMode, monthTitleAlign, fontName,
            sundayRed, holidayRed, ghost,
            cellW, cellH, cellGapX, cellGapY, cellPosAdjY, cellFill,
            strokeMode, strokeTop, strokeBottom, strokeLeft, strokeRight,

            showTopYear, includeYearInMonthTitle, monthTitleBottomBorder, topYearBottomMargin,
            monthCount, colCount, monthTitleMode, monthBottomMargin, weekdayBottomMargin,
            outerMarginX, outerMarginY, startFromJanuary, weekStartMonday, weekdayLabelMode,
            weekdayFontSize, monthFontSize, yearFontSize
        ) {

            // ---- safety aliases (legacy name compatibility) ----
            ghost = !!ghost;
            cellFill = !!cellFill;
            if (!monthTitleMode) monthTitleMode = "pad";
            monthFontSize = Number(monthFontSize);
            if (!monthFontSize || monthFontSize <= 0) monthFontSize = fontSize;

            yearFontSize = Number(yearFontSize);
            if (!yearFontSize || yearFontSize <= 0) yearFontSize = fontSize;

            monthBottomMargin = Number(monthBottomMargin);
            if (isNaN(monthBottomMargin) || monthBottomMargin < 0) monthBottomMargin = 0;
            if (monthBottomMargin > 2000) monthBottomMargin = 2000;
            weekdayBottomMargin = Number(weekdayBottomMargin);
            if (isNaN(weekdayBottomMargin) || weekdayBottomMargin < 0) weekdayBottomMargin = 0;
            if (weekdayBottomMargin > 2000) weekdayBottomMargin = 2000;
            topYearBottomMargin = Number(topYearBottomMargin);
            if (isNaN(topYearBottomMargin) || topYearBottomMargin < 0) topYearBottomMargin = 0;
            if (topYearBottomMargin > 2000) topYearBottomMargin = 2000;
            outerMarginX = Number(outerMarginX);
            if (isNaN(outerMarginX) || outerMarginX < 0) outerMarginX = 0;
            if (outerMarginX > 5000) outerMarginX = 5000;
            outerMarginY = Number(outerMarginY);
            if (isNaN(outerMarginY) || outerMarginY < 0) outerMarginY = 0;
            if (outerMarginY > 5000) outerMarginY = 5000;
            var layer = getOrCreateLayer(doc, layerName);

            layer.locked = false;
            layer.visible = true;

            var abIndex = doc.artboards.getActiveArtboardIndex();
            var abRect = doc.artboards[abIndex].artboardRect; // [L,T,R,B]
            var abCX = (abRect[0] + abRect[2]) / 2;
            var abCY = (abRect[1] + abRect[3]) / 2;

            weekStartMonday = (weekStartMonday !== false); // default true

            strokeMode = String(strokeMode || "none");
            strokeTop = !!strokeTop;
            strokeBottom = !!strokeBottom;
            strokeLeft = !!strokeLeft;
            strokeRight = !!strokeRight;

            if (!weekdayLabelMode) weekdayLabelMode = "jp";

            var headersMon;
            if (weekdayLabelMode === "mtw") {
                headersMon = ["M", "T", "W", "T", "F", "S", "S"]; // Mon..Sun
            } else if (weekdayLabelMode === "mon") {
                headersMon = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]; // Mon..Sun
            } else {
                headersMon = ["月", "火", "水", "木", "金", "土", "日"]; // Mon..Sun
            }

            // order by week start
            var headers = weekStartMonday
                ? headersMon
                : [headersMon[6], headersMon[0], headersMon[1], headersMon[2], headersMon[3], headersMon[4], headersMon[5]];

            var sundayCol = weekStartMonday ? 6 : 0;
            // 年タイトル（最上部）
            var yearTitleH = showTopYear ? (cellH + topYearBottomMargin) : 0; // 1行 + 下マージン

            // ===== セル塗り（仮）: K10 =====
            var __K10 = null;
            try {
                __K10 = new CMYKColor();
                __K10.cyan = 0;
                __K10.magenta = 0;
                __K10.yellow = 0;
                __K10.black = 10; // K10
            } catch (e) { __K10 = null; }

            // ===== ゴースト文字色: K30 =====
            var __K30 = null;
            try {
                __K30 = new CMYKColor();
                __K30.cyan = 0;
                __K30.magenta = 0;
                __K30.yellow = 0;
                __K30.black = 30; // K30
            } catch (e) { __K30 = null; }

            monthCount = Math.round(Number(monthCount));
            if (!monthCount || monthCount < 1) monthCount = 1;
            if (monthCount > 24) monthCount = 24;

            colCount = Math.round(Number(colCount));
            if (!colCount || colCount < 1) colCount = 1;
            if (colCount > 12) colCount = 12;
            if (colCount > monthCount) colCount = monthCount;

            // 月ごとに必要な高さ（週数）を先に計算し、全体をアートボード中心にレイアウト
            var baseYear = baseDate.getFullYear();
            var baseMonth0 = baseDate.getMonth();

            startFromJanuary = (startFromJanuary === true);

            var monthInfos = [];
            cellGapX = Number(cellGapX);
            if (isNaN(cellGapX) || cellGapX < 0) cellGapX = 0;
            if (cellGapX > 2000) cellGapX = 2000;

            cellGapY = Number(cellGapY);
            if (isNaN(cellGapY) || cellGapY < 0) cellGapY = 0;
            if (cellGapY > 2000) cellGapY = 2000;

            var stepX = cellW + cellGapX;
            var totalW = 7 * cellW + 6 * cellGapX;

            var gapX = outerMarginX; // 月ユニット間の左右マージン
            var gapY = outerMarginY; // 月ユニット間の上下マージン

            var maxCellH = 0; // 1つの月ブロックの最大高さ

            var startOffset = -Math.floor((monthCount - 1) / 2);
            for (var mi = 0; mi < monthCount; mi++) {
                var d0;
                if (startFromJanuary) {
                    // 1月から順に
                    d0 = new Date(baseYear, 0 + mi, 1);
                } else {
                    // 当月を中心に前後
                    var mOff = startOffset + mi;
                    d0 = new Date(baseYear, baseMonth0 + mOff, 1);
                }
                var y = d0.getFullYear();
                var m0 = d0.getMonth();
                var first = new Date(y, m0, 1);
                var last = new Date(y, m0 + 1, 0);
                var daysInMonth = last.getDate();

                // 週はじまり列（0=開始曜日..6）
                var startIndex = weekStartMonday ? ((first.getDay() + 6) % 7) : first.getDay();

                // 行数計算
                var dayCells = startIndex + daysInMonth;
                var weeks = Math.ceil(dayCells / 7);
                var rows = 1 + weeks;      // 1=曜日ヘッダ
                var totalH = (rows + 1) * cellH + monthBottomMargin + weekdayBottomMargin; // +1=タイトル行 + タイトル下マージン + 曜日下マージン
                // 日付行は weeks 行なので、間隔は (weeks-1) 回だけ入る
                if (cellGapY > 0 && weeks > 1) totalH += (weeks - 1) * cellGapY;

                if (totalH > maxCellH) maxCellH = totalH;

                monthInfos.push({
                    year: y,
                    month0: m0,
                    daysInMonth: daysInMonth,
                    startIndex: startIndex,
                    weeks: weeks,
                    rows: rows,
                    totalH: totalH
                });
            }

            // グリッド配置（列数指定）
            var rowsCount = Math.ceil(monthCount / colCount);

            // 全体の幅・高さ（アートボード中心に配置）
            var blockW = colCount * totalW + (colCount - 1) * gapX;
            var blockH = rowsCount * maxCellH + (rowsCount - 1) * gapY;
            var blockHWithYear = blockH + yearTitleH;

            var startX0 = abCX - blockW / 2;
            var startY0 = abCY + blockHWithYear / 2;

            // 年タイトル（最上部）
            if (showTopYear) {
                addText(layer, String(baseYear), startX0, startY0, yearFontSize, "center", blockW, fontName, false, null);
            }

            for (var bi = 0; bi < monthInfos.length; bi++) {
                var info = monthInfos[bi];

                // 月ごとのグループ（後から選択/移動しやすくする）
                var monthGroup = null;
                try {
                    monthGroup = layer.groupItems.add();
                    monthGroup.name = "Month_" + info.year + "_" + pad2(info.month0 + 1);
                } catch (e) { monthGroup = null; }

                var colI = bi % colCount;
                var rowI = Math.floor(bi / colCount);

                // 各月の左上（各セルは maxCellH の上揃え）
                var startX = startX0 + colI * (totalW + gapX);
                var startY = (startY0 - yearTitleH) - rowI * (maxCellH + gapY);

                // タイトル
                var titleText = formatMonthTitle(info.year, info.month0, includeYearInMonthTitle, monthTitleMode);
                addText(layer, titleText, startX, startY, monthFontSize, monthTitleAlign || alignMode, totalW, fontName, false, monthGroup);

                // タイトル行の下ボーダー（タイトルと曜日の中間）
                if (monthTitleBottomBorder) {
                    var by = startY - cellH - (monthBottomMargin * 0.5);
                    addHLine(layer, startX, startX + totalW, by, 0.3, monthGroup);
                }

                // 曜日ヘッダ（タイトル下にマージンを入れる）
                var headerY = startY - cellH - monthBottomMargin;
                for (var c = 0; c < 7; c++) {
                    var isSunH = (sundayRed && c === sundayCol);
                    addText(layer, headers[c], startX + c * stepX, headerY, weekdayFontSize || fontSize, alignMode, cellW, fontName, isSunH, monthGroup);
                }

                // 日付（必要なら前後月も表示）
                var totalCells = info.weeks * 7;

                // 前月の日数（ゴースト用）
                var prevDaysInMonth = 0;
                if (ghost) {
                    try {
                        var py = info.year;
                        var pm0 = info.month0 - 1;
                        if (pm0 < 0) { pm0 = 11; py--; }
                        prevDaysInMonth = (new Date(py, pm0 + 1, 0)).getDate();
                    } catch (e) { prevDaysInMonth = 0; }
                }

                for (var idx = 0; idx < totalCells; idx++) {
                    var col = idx % 7;
                    var weekRow = Math.floor(idx / 7);
                    var row = 1 + weekRow; // 1=曜日ヘッダの次の行

                    // 当月の「日」(1..daysInMonth)
                    var day = (idx - info.startIndex) + 1;

                    var isGhostDay = false;
                    var dispDay = day;

                    // ゴーストOFF時は、当月外セル（前月/翌月）は完全にスキップ（罫線も描かない）
                    if (!ghost && (day < 1 || day > info.daysInMonth)) {
                        continue;
                    }

                    // はみ出しは前後月
                    if (day < 1 || day > info.daysInMonth) {
                        if (!ghost) continue; // ゴーストOFFなら描画しない
                        isGhostDay = true;
                        if (day < 1) {
                            dispDay = prevDaysInMonth + day; // 前月
                        } else {
                            dispDay = day - info.daysInMonth; // 翌月
                        }
                    }

                    var x = startX + col * stepX;
                    var yy = headerY - weekdayBottomMargin - row * cellH - (row - 1) * cellGapY;

                    // 背景の位置調整（背景のみ上下調整）
                    var __bgAdjY = Number(cellPosAdjY);
                    if (isNaN(__bgAdjY)) __bgAdjY = 0;

                    // 背景・罫線の基準（背景オフセット込み）
                    var __cellTopY = yy + __bgAdjY;
                    var __cellBotY = __cellTopY - cellH;
                    var __xL = x;
                    var __xR = x + cellW;

                    var __cellRect = null;
                    if (cellFill && __K10) {
                        try {
                            __cellRect = layer.pathItems.rectangle(__cellTopY, x, cellW, cellH);
                            __cellRect.stroked = false;
                            __cellRect.filled = true;
                            __cellRect.fillColor = __K10;
                            if (monthGroup) {
                                try { __cellRect.move(monthGroup, ElementPlacement.PLACEATBEGINNING); } catch (e) { }
                            }
                        } catch (e) { }
                    }

                    // 日曜の赤は当月のみ（ゴーストはK30で上書き）
                    var isSunD = (sundayRed && col === sundayCol);
                    var colorFlag = isSunD && !isGhostDay;

                    var tf = addText(layer, String(dispDay), x, yy, fontSize, alignMode, cellW, fontName, colorFlag, monthGroup);

                    // ===== 罫線（セル背景に連動 / 背景より前面）=====
                    if (strokeMode !== "none") {
                        try {
                            var __strokeW = 0.3; // 固定（必要ならUI化）
                            var __strokeC = null;
                            try {
                                __strokeC = new CMYKColor();
                                __strokeC.cyan = 0; __strokeC.magenta = 0; __strokeC.yellow = 0; __strokeC.black = 100; // K100
                            } catch (e) { __strokeC = null; }

                            function __drawLine(x1, y1, x2, y2) {
                                var ln = layer.pathItems.add();
                                ln.stroked = true;
                                ln.filled = false;
                                ln.strokeWidth = __strokeW;
                                if (__strokeC) ln.strokeColor = __strokeC;
                                ln.setEntirePath([[x1, y1], [x2, y2]]);
                                if (monthGroup) {
                                    try { ln.move(monthGroup, ElementPlacement.PLACEATEND); } catch (e) { }
                                }
                                return ln;
                            }

                            // モードに応じて描画
                            if (strokeMode === "all") {
                                __drawLine(__xL, __cellTopY, __xR, __cellTopY); // 上
                                __drawLine(__xL, __cellBotY, __xR, __cellBotY); // 下
                                __drawLine(__xL, __cellBotY, __xL, __cellTopY); // 左
                                __drawLine(__xR, __cellBotY, __xR, __cellTopY); // 右
                            } else {
                                if (strokeTop) __drawLine(__xL, __cellTopY, __xR, __cellTopY);
                                if (strokeBottom) __drawLine(__xL, __cellBotY, __xR, __cellBotY);
                                if (strokeLeft) __drawLine(__xL, __cellBotY, __xL, __cellTopY);
                                if (strokeRight) __drawLine(__xR, __cellBotY, __xR, __cellTopY);
                            }
                        } catch (e) { }
                    }

                    // 祝日（当月のみ）
                    if (!isGhostDay) {
                        var hname = getJPHolidayName(info.year, info.month0 + 1, day);
                        var isHol = (holidayRed && hname);
                        if (isHol) {
                            try {
                                var oc = new RGBColor();
                                oc.red = 255;
                                oc.green = 140;
                                oc.blue = 0; // orange
                                tf.textRange.characterAttributes.fillColor = oc;
                            } catch (e) { }
                        }
                    }

                    // ゴースト文字色（K30）
                    if (isGhostDay && __K30 && tf) {
                        try { tf.textRange.characterAttributes.fillColor = __K30; } catch (e) { }
                    }

                    // 前後関係を最終確定（背景→最背面、テキスト→最前面）
                    try { if (__cellRect) __cellRect.zOrder(ZOrderMethod.SENDTOBACK); } catch (e) { }
                    try { if (tf) tf.zOrder(ZOrderMethod.BRINGTOFRONT); } catch (e) { }
                }
            }
        }

        /* 水平罫線を1本追加 / Add a single horizontal rule */
        function addHLine(layer, x1, x2, y, strokeW, parentGroup) {
            var p = layer.pathItems.add();
            p.setEntirePath([[x1, y], [x2, y]]);
            p.stroked = true;
            p.filled = false;
            p.strokeWidth = (typeof strokeW === "number" && strokeW > 0) ? strokeW : 0.3;

            try {
                var c = new RGBColor();
                c.red = 0; c.green = 0; c.blue = 0;
                p.strokeColor = c;
            } catch (e) { }

            // 生成後にグループへ移動
            if (parentGroup) {
                try { p.move(parentGroup, ElementPlacement.PLACEATEND); } catch (e) { }
            }
            return p;
        }

        /* 揃え指定でテキストフレームを1つ追加 / Add one text frame with the given alignment */
        function addText(layer, str, xLeft, y, size, alignMode, boxW, fontName, isRed, parentGroup) {
            var tf = layer.textFrames.add();
            tf.contents = str;

            var x = xLeft;
            if (alignMode === "right") x = xLeft + boxW;
            else if (alignMode === "left") x = xLeft;
            else x = xLeft + boxW / 2;

            tf.position = [x, y];
            tf.textRange.size = size;

            // フォント適用（選択されている場合）
            if (fontName) {
                try {
                    tf.textRange.characterAttributes.textFont = app.textFonts.getByName(fontName);
                } catch (e) { }
            }

            // 日曜日カラー（赤）
            if (isRed) {
                try {
                    var rc = new RGBColor();
                    rc.red = 255; rc.green = 0; rc.blue = 0;
                    tf.textRange.characterAttributes.fillColor = rc;
                } catch (e) { }
            }

            if (alignMode === "right") tf.textRange.justification = Justification.RIGHT;
            else if (alignMode === "left") tf.textRange.justification = Justification.LEFT;
            else tf.textRange.justification = Justification.CENTER;

            // 生成後にグループへ移動
            if (parentGroup) {
                try { tf.move(parentGroup, ElementPlacement.PLACEATEND); } catch (e) { }
            }
            return tf;
        }

        /* 数値を2桁ゼロ埋め / Zero-pad a number to 2 digits */
        function pad2(n) {
            return (n < 10) ? ("0" + n) : String(n);
        }

        /* 年月日入力を検証しDateを返す（不正はnull）/ Validate Y/M/D fields and return a Date (null if invalid) */
        function parseYMDFields(yStr, mStr, dStr) {
            var yy = Number(yStr);
            var mm = Number(mStr);
            var dd = Number(dStr);

            if (!yy || !mm || !dd) return null;
            if (mm < 1 || mm > 12) return null;
            if (dd < 1 || dd > 31) return null;

            var d = new Date(yy, mm - 1, dd);
            if (d.getFullYear() !== yy || d.getMonth() !== (mm - 1) || d.getDate() !== dd) return null;

            return d;
        }

        /* 名前でレイヤーを取得 / Get a layer by name */
        function getLayerByName(doc, name) {
            for (var i = 0; i < doc.layers.length; i++) {
                if (doc.layers[i].name === name) return doc.layers[i];
            }
            return null;
        }

        /* レイヤーを取得、無ければ作成 / Get a layer, creating it if missing */
        function getOrCreateLayer(doc, name) {
            var lyr = getLayerByName(doc, name);
            if (lyr) return lyr;
            lyr = doc.layers.add();
            lyr.name = name;
            return lyr;
        }

        /* レイヤーを削除して同名で作り直す / Remove a layer and recreate it under the same name */
        function clearLayerContents(doc, name) {
            var lyr = getLayerByName(doc, name);
            if (!lyr) return;

            try {
                // ロック解除
                lyr.locked = false;
                lyr.visible = true;

                // レイヤーごと削除（中身を1つずつ消すより高速な場合が多い）
                lyr.remove();
            } catch (e) { }

            try {
                // 同名レイヤーを再作成
                var newLyr = doc.layers.add();
                newLyr.name = name;
            } catch (e) { }
        }

        /* 同名レイヤーがあれば削除 / Remove a layer if it exists */
        function removeLayerIfExists(doc, name) {
            var lyr = getLayerByName(doc, name);
            if (!lyr) return;

            // ロック解除して削除
            lyr.locked = false;
            lyr.visible = true;
            lyr.remove();
        }
    })();

})();
