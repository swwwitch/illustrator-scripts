#target illustrator
#targetengine "SmartSelectionFilterEngine"
app.preferences.setBooleanPreference('ShowExternalJSXWarning', false);

/*
SCRIPTMETA-BEGIN
Script-ID=com.swwwitch.illustrator.SmartSelectionFilter
Name=選択オブジェクトを条件で絞り込み再選択
Author=Masahiro Takano (@swwwitch)
Target-App=Illustrator
Version=1.1.4
Release-Date=2026-05-02
Description-BEGIN
選択中のオブジェクトから、条件に合うテキストやパスだけを残して選択し直します。
文字種・行揃え・使用フォント・パスの開閉・塗りや線の状態を条件にでき、変更はダイアログを閉じずにカンバスへ反映されます。

Reselects only the text frames and paths in the current selection that match the conditions you set.
Text kind, justification, font, open/closed paths and fill/stroke state can all be used as conditions, and changes are reflected on the canvas without closing the dialog.
Description-END
SCRIPTMETA-END
*/

/*

### 概要

選択中のオブジェクトから、条件に合うテキストやパスだけを残して選択し直します。
文字種・行揃え・使用フォント・パスの開閉・塗りや線の状態を条件にでき、変更はダイアログを閉じずにカンバスへ反映されます。

詳細は README を参照してください。
https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/SmartSelectionFilter.md

note記事も参照してください。
https://note.com/dtp_tranist/n/n6203a03662d8

### Overview

Reselects only the text frames and paths in the current selection that match the conditions you set.
Text kind, justification, font, open/closed paths and fill/stroke state can all be used as conditions, and changes are reflected on the canvas without closing the dialog.

See the README for details.
https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/SmartSelectionFilter.md

*/

// =========================================
// 基本情報 / Basic info
// =========================================
var SCRIPT_NAME     = "SmartSelectionFilter";         /* スクリプト名 / script name */
var SCRIPT_VERSION  = "v1.1.4";                       /* バージョン / version */
var SCRIPT_AUTHOR   = "Masahiro Takano (@swwwitch)";  /* 作者 / author */
var SCRIPT_RELEASED = "2026-05-02";                   /* 最初のリリース日 / first release date */
var SCRIPT_UPDATED  = "2026-10-04";                   /* 更新日 / last updated */

var SCRIPT_DESCRIPTION_JA = "選択オブジェクトを条件で絞り込み再選択"; /* README の見出し / README title (Japanese) */

var SCRIPT_README_JA   = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/SmartSelectionFilter.md"; /* README（日本語） */
var SCRIPT_README_EN   = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/SmartSelectionFilter.md"; /* README (English) */
var SCRIPT_ARTICLE_URL = "https://note.com/dtp_tranist/n/n6203a03662d8"; /* 紹介記事 / article URL */
var SCRIPT_SOURCE_URL  = "https://github.com/swwwitch/illustrator-scripts/blob/master/jsx/select/SmartSelectionFilter.jsx"; /* 最新版のソース / latest source */

// Released under the MIT license
// http://opensource.org/licenses/mit-license.php

(function () {

    // ローカライズ（再利用パーツ） / Localization (reusable)

    /**
     * UI の言語を返す（"ja" で始まるロケールは日本語、それ以外は英語）
     * @returns {string} "ja" または "en"
     */
    function getCurrentLang() {
        return (String($.locale || "").indexOf("ja") === 0) ? "ja" : "en";
    }

    var uiLang = getCurrentLang();

    /**
     * LABELS から今の UI 言語の文言を取り出す。
     * @param {string|Object} labelRef - "dialog.title" のようなパス、または { ja, en }
     * @param {Object|Array} [placeholderValues] - { name: 値 } なら {name} を、[値, …] なら %1, %2 … を差し込む
     * @returns {string} 文言。パスが見つからなければパスの文字列、{ ja, en } が無ければ空文字
     */
    function getLabel(labelRef, placeholderValues) {
        var labelEntry = labelRef;
        if (typeof labelRef === "string") {
            var labelPathKeys = labelRef.split(".");
            labelEntry = LABELS;
            for (var i = 0; i < labelPathKeys.length && labelEntry != null; i++) {
                labelEntry = labelEntry[labelPathKeys[i]];
            }
        }
        var labelString;
        if (typeof labelEntry === "string") labelString = labelEntry;
        else if (labelEntry != null && labelEntry[uiLang] != null) labelString = labelEntry[uiLang];
        else if (labelEntry != null && labelEntry.en != null) labelString = labelEntry.en;
        else return (typeof labelRef === "string") ? labelRef : "";
        return fillLabelPlaceholders(String(labelString), placeholderValues);
    }

    /**
     * 項目名の文言の末尾にコロンを付ける（日本語は半角スペース＋半角コロン「 :」、英語は「:」。Illustrator の線パネルなどの項目名に合わせる）
     * @param {string|Object} labelRef - getLabel と同じ
     * @param {Object|Array} [placeholderValues] - getLabel と同じ
     * @returns {string} コロン付きの文言
     */
    function labelText(labelRef, placeholderValues) {
        return getLabel(labelRef, placeholderValues) + (uiLang === "ja" ? " :" : ":");
    }

    /**
     * 「項目名 : 値」の1行を返す（日本語は「件数 : 5」、英語は「Count: 5」。どちらもコロンのあとに空白を入れる）
     * @param {string|Object} labelRef - getLabel と同じ
     * @param {string|number} value - コロンのあとに続ける値
     * @returns {string} 項目名と値をつないだ文字列
     */
    function labelValueText(labelRef, value) {
        return labelText(labelRef) + " " + value;
    }

    /**
     * 文言の {name} や %1 に値を差し込む
     * @param {string} labelString - 文言
     * @param {Object|Array} [placeholderValues] - { name: 値 } または [値, …]
     * @returns {string} 差し込んだ文言
     */
    function fillLabelPlaceholders(labelString, placeholderValues) {
        if (placeholderValues == null) return labelString;
        if (placeholderValues instanceof Array) {
            /* 大きい番号から置き換え、%1 が %10 の一部を置き換えないようにする / Replace from the highest index so %1 does not eat into %10 */
            for (var i = placeholderValues.length; i >= 1; i--) {
                labelString = labelString.split("%" + i).join(String(placeholderValues[i - 1]));
            }
            return labelString;
        }
        for (var placeholderKey in placeholderValues) {
            if (!placeholderValues.hasOwnProperty(placeholderKey)) continue;
            labelString = labelString.split("{" + placeholderKey + "}").join(String(placeholderValues[placeholderKey]));
        }
        return labelString;
    }

    // ローカライズ（再利用パーツ）ここまで / End of the reusable localization

    // ボタン行（再利用パーツ） / Button row (reusable)

    var BUTTON_ROW_TOP_MARGIN = 5; /* ボタン行の上の余白 / top margin of the button row */
    var BUTTON_ROW_BOTTOM_MARGIN = 14; /* ボタン行の下の余白。ダイアログの下余白と合わせて約30px（Illustrator 標準のダイアログに合わせる） / bottom margin; with the dialog margin about 30px, like Illustrator's own dialogs */
    var BUTTON_ROW_SPACING = 10;   /* ボタンどうしの間隔 / spacing between buttons */
    var BUTTON_ROW_CENTER_MAX_WIDTH = 240; /* 右のボタンだけの行を中央に置く、ダイアログの内側の最大幅（px、左右の余白を除く）。広いダイアログは右揃え / max inner dialog width (px, margins excluded) that centers a right-only row; wider dialogs keep it right-aligned */

    /**
     * ダイアログ下部のボタン行を作る。
     * 通常は「左のグループ・伸びるスペーサー・右のグループ」、centered なら行そのものを左右中央に置く
     * @param {Window|Group|Panel} parent - 行を足す先（ふつうはダイアログ）
     * @param {Object} [rowOptions] - { centered: true } で左右中央に並べる
     * @returns {{rowGroup: Group, leftGroup: Group|null, rightGroup: Group|null}} 行と左右のグループ（centered のときは左右が null）
     */
    function addButtonRow(parent, rowOptions) {
        var isCentered = !!(rowOptions && rowOptions.centered);
        var btnRowGroup = parent.add("group");
        btnRowGroup.orientation = "row";
        btnRowGroup.margins = [0, BUTTON_ROW_TOP_MARGIN, 0, BUTTON_ROW_BOTTOM_MARGIN];
        btnRowGroup.spacing = BUTTON_ROW_SPACING;

        if (isCentered) {
            btnRowGroup.alignment = ["center", "bottom"];
            btnRowGroup.alignChildren = ["center", "center"];
            return { rowGroup: btnRowGroup, leftGroup: null, rightGroup: null };
        }

        btnRowGroup.alignment = ["fill", "bottom"];

        var btnLeftGroup = btnRowGroup.add("group");
        btnLeftGroup.alignChildren = ["left", "center"];
        btnLeftGroup.spacing = BUTTON_ROW_SPACING;

        /* 余りの幅を吸って、右のグループを右端に寄せる / Absorbs the extra width so the right group sits at the right edge */
        var spacer = btnRowGroup.add("group");
        spacer.alignment = ["fill", "fill"];
        spacer.minimumSize.width = 0;

        var btnRightGroup = btnRowGroup.add("group");
        btnRightGroup.alignChildren = ["right", "center"];
        btnRightGroup.spacing = BUTTON_ROW_SPACING;

        return { rowGroup: btnRowGroup, leftGroup: btnLeftGroup, rightGroup: btnRightGroup };
    }

    /**
     * 左のグループにボタンが無い（右のボタンだけの）行を、ダイアログの幅に合わせて揃える。
     * 内側の幅（左右の余白を除く）が BUTTON_ROW_CENTER_MAX_WIDTH 以下なら左右中央、それより広ければ右揃えのまま。
     * 幅はレイアウトが決まるまで分からないので、ダイアログを表示した時点（show イベント）で判定する。
     * ボタンをすべて足したあと、show() の前に呼ぶ。centered で作った行や、左にボタンがある行はそのまま
     * @param {{rowGroup: Group, leftGroup: Group|null, rightGroup: Group|null}} buttonRow - addButtonRow() の戻り値
     * @returns {void}
     */
    function alignRightOnlyButtonRow(buttonRow) {
        if (!buttonRow.leftGroup || buttonRow.leftGroup.children.length > 0) return;
        var dialogWindow = buttonRow.rowGroup.window;
        dialogWindow.addEventListener("show", function () {
            if (!buttonRow.leftGroup) return;
            var btnRowGroup = buttonRow.rowGroup;
            /* 行の幅＝ダイアログの内側の幅（左右の余白を除く）/ The row spans the dialog's inner width (margins excluded) */
            if (!btnRowGroup.size || btnRowGroup.size.width > BUTTON_ROW_CENTER_MAX_WIDTH) return;
            /* 左のグループとスペーサーを外し、右のグループだけを中央に置く / Drop the left group and the spacer so only the right group remains, centered */
            btnRowGroup.remove(buttonRow.leftGroup);
            btnRowGroup.remove(btnRowGroup.children[0]); /* 左のグループを外すと先頭はスペーサー / the spacer is first once the left group is gone */
            btnRowGroup.alignment = ["center", "bottom"];
            btnRowGroup.alignChildren = ["center", "center"];
            buttonRow.leftGroup = null;
            dialogWindow.layout.layout(true);
        });
    }

    // ボタン行（再利用パーツ）ここまで / End of the reusable button row

    /* UI／エラーメッセージの日英ラベル定義 / Japanese-English UI and error message label definitions */
    var LABELS = {
        dialogTitle: {
            ja: "選択オブジェクトの絞り込み",
            en: "Filter Selected Objects"
        },
        textPanel: {
            ja: "テキスト",
            en: "Text"
        },
        textObject: {
            ja: "ポイント文字",
            en: "Point Text"
        },
        areaText: {
            ja: "エリア内文字",
            en: "Area Text"
        },
        pathText: {
            ja: "パス上文字",
            en: "Path Text"
        },
        alignmentPanel: {
            ja: "行揃え",
            en: "Alignment"
        },
        tipNonSelectedNone: { ja: "絞り込みから外れたオブジェクトは、そのまま表示しておきます。", en: "Leaves the objects that fall outside the filter as they are." },
        tipNonSelectedHide: { ja: "絞り込みから外れたオブジェクトを一時的に隠します。OKで確定、キャンセルで元に戻ります。", en: "Temporarily hides the objects outside the filter. OK keeps it, Cancel restores them." },
        tipNonSelectedOpacity: { ja: "絞り込みから外れたオブジェクトの不透明度を下げて、対象を見分けやすくします。", en: "Dims the objects outside the filter so the matches stand out." },
        tipNonSelectedSlider: { ja: "外れたオブジェクトに使う不透明度（％）です。", en: "Opacity used for the objects outside the filter." },
        tipSimpleText: { ja: "テキストをまとめて選びます（ポイント文字・エリア内文字・パス上文字のすべて）。", en: "Selects all text at once: point, area and path text." },
        tipSimpleStrokeOnly: { ja: "線だけが設定されたパスを選びます（塗りなし）。", en: "Selects paths that have a stroke but no fill." },
        tipSimpleFillOnlyPath: { ja: "塗りだけが設定されたパスを選びます（線なし）。", en: "Selects paths that have a fill but no stroke." },
        tipPreviewButton: { ja: "いまの絞り込み結果を画面で確認します。もう一度押すと元の表示に戻ります。", en: "Shows the current filter result on the canvas. Press again to restore the view." },
        fontPanel: {
            ja: "フォント",
            en: "Font"
        },
        noFontItems: {
            ja: "対象フォントなし",
            en: "No target fonts"
        },
        alignLeft: {
            ja: "左揃え",
            en: "Left"
        },
        alignCenter: {
            ja: "中央揃え",
            en: "Center"
        },
        alignRight: {
            ja: "右揃え",
            en: "Right"
        },
        pathPanel: {
            ja: "パス",
            en: "Path"
        },
        openPath: {
            ja: "オープンパス",
            en: "Open Path"
        },
        horizontalLine: {
            ja: "水平線",
            en: "Horizontal Line"
        },
        verticalLine: {
            ja: "垂直線",
            en: "Vertical Line"
        },
        closedPathPanel: {
            ja: "クローズパス",
            en: "Closed Path"
        },
        closedPathFillOnly: {
            ja: "塗りのみ",
            en: "Fill Only"
        },
        closedPathStrokeOnly: {
            ja: "線のみ",
            en: "Stroke Only"
        },
        closedPathFillAndStroke: {
            ja: "塗りと線",
            en: "Fill and Stroke"
        },
        ok: {
            ja: "OK",
            en: "OK"
        },
        cancel: {
            ja: "キャンセル",
            en: "Cancel"
        },
        btnOutlineOn: {
            ja: "アウトライン表示",
            en: "Outline"
        },
        btnOutlineOff: {
            ja: "プレビュー表示",
            en: "Preview"
        },
        nonSelectedPanel: {
            ja: "対象外オブジェクト",
            en: "Non-target Objects"
        },
        nonSelectedNone: {
            ja: "何もしない",
            en: "Do Nothing"
        },
        nonSelectedHide: {
            ja: "非表示",
            en: "Hide"
        },
        nonSelectedOpacity: {
            ja: "不透明度",
            en: "Opacity"
        },
        simplePanel: {
            ja: "まとめて選択",
            en: "Quick Select"
        },
        simpleText: {
            ja: "テキスト",
            en: "Text"
        },
        simpleStrokeOnly: {
            ja: "ケイのみ",
            en: "Stroke Only"
        },
        simpleFillOnlyPath: {
            ja: "塗りのみ",
            en: "Fill Only"
        },
        scopePanel: { ja: "対象スコープ", en: "Selection Scope" },
        scopeSelectedOnly: { ja: "選択直下のみ", en: "Selected objects only" },
        scopeIncludeGroupItems: { ja: "グループ内も対象に含める", en: "Include objects inside groups" },
        tipScope: { ja: "グループ内のオブジェクトを対象に含めるかを指定します。", en: "Choose whether to include objects inside groups." },
        noDocumentError: {
            ja: "ドキュメントが開かれていません。",
            en: "No document is open."
        },
        noSelectionError: {
            ja: "オブジェクトが選択されていません。",
            en: "No object is selected."
        }
    };

    /* エラー表示ヘルパー / Error display helper */
    function showError(key) {
        alert(getLabel(key));
    }

    /* 件数付きラベル（日本語は全角括弧、英語は半角括弧）/ Label with count (full-width JA parentheses, half-width EN parentheses) */
    function labelWithCount(key, count) {
        if (uiLang === "ja") {
            return getLabel(key) + "（" + count + "）";
        }
        return getLabel(key) + " (" + count + ")";
    }

    /* 値付きラベル（日本語は全角括弧、英語は半角括弧）/ Label with value (full-width JA parentheses, half-width EN parentheses) */
    function labelWithValue(key, valueText) {
        if (uiLang === "ja") {
            return getLabel(key) + "（" + valueText + "）";
        }
        return getLabel(key) + " (" + valueText + ")";
    }

    /* 任意テキストへの値付け（日本語は全角括弧、英語は半角括弧）/ Append value to arbitrary text (full-width JA parentheses, half-width EN parentheses) */
    function appendValueText(baseText, valueText) {
        if (uiLang === "ja") {
            return baseText + "（" + valueText + "）";
        }
        return baseText + " (" + valueText + ")";
    }

    // =========================================
    // レイアウト / Layout
    // =========================================

    // UIレイアウト（再利用パーツ） / UI layout (reusable)

    /* ウィンドウ・パネルの余白と間隔 / Window & panel margins and spacing */
    var WINDOW_MARGINS = 16;                 /* ウィンドウ外周の余白 / window margin */
    var WINDOW_SPACING = 12;                 /* ウィンドウ内の要素間隔 / window spacing */
    var PANEL_MARGINS  = [16, 20, 16, 12];   /* パネル余白 [左,上,右,下] / panel margins */
    var PANEL_SPACING  = 12;                 /* パネル内の要素間隔 / panel spacing */
    var COLUMN_SPACING = 12;                 /* 2カラムの間隔 / gap between columns */
    var TAB_MARGINS    = [15, 20, 5, 10];    /* タブ余白 [左,上,右,下] / tab margins */

    /**
     * ウィンドウの共通設定
     * @param {Window} targetWindow - 対象のウィンドウ
     * @param {number} [spacing] - 要素間隔（省略時は WINDOW_SPACING）
     * @returns {void}
     */
    function setupWindow(targetWindow, spacing) {
        targetWindow.orientation = "column";
        targetWindow.alignChildren = "fill";
        targetWindow.margins = WINDOW_MARGINS;
        targetWindow.spacing = (typeof spacing === "number") ? spacing : WINDOW_SPACING;
    }

    /**
     * パネルの共通設定（子は幅いっぱい。ボタンは alignment = "left" で広げない）
     * @param {Panel} targetPanel - 対象のパネル
     * @param {number} [spacing] - 要素間隔（省略時は PANEL_SPACING）
     * @returns {void}
     */
    function setupPanel(targetPanel, spacing) {
        targetPanel.orientation = "column";
        targetPanel.alignChildren = ["fill", "top"];
        targetPanel.alignment = "fill";
        targetPanel.margins = PANEL_MARGINS;
        targetPanel.spacing = (typeof spacing === "number") ? spacing : PANEL_SPACING;
    }

    /**
     * タブの共通設定
     * @param {Tab} targetTab - 対象のタブ
     * @param {number} [spacing] - 要素間隔（省略時は変えない）
     * @returns {void}
     */
    function setupTab(targetTab, spacing) {
        targetTab.orientation = "column";
        targetTab.alignChildren = "fill";
        targetTab.margins = TAB_MARGINS;
        if (typeof spacing === "number") targetTab.spacing = spacing;
    }

    /**
     * 横並びの行グループの共通設定（ボタン列など）。
     * alignment と alignChildren を対で指定し、中のボタンが横に伸びたり天地がずれたりしないようにする
     * @param {Group} rowGroup - 対象のグループ
     * @param {string|string[]} [rowAlignment] - 横方向の alignment（省略時は "left"）。配列ならそのまま使う
     * @param {number} [spacing] - 要素間隔（省略時は PANEL_SPACING）
     * @returns {void}
     */
    function setupRow(rowGroup, rowAlignment, spacing) {
        rowGroup.orientation = "row";
        rowGroup.alignment = (rowAlignment instanceof Array) ? rowAlignment : [rowAlignment || "left", "center"];
        rowGroup.alignChildren = ["left", "center"];
        rowGroup.spacing = (typeof spacing === "number") ? spacing : PANEL_SPACING;
    }

    /**
     * ボタンの高さを指定した px だけ詰める（レイアウトが決まったあとに呼ぶ）
     * @param {Button} targetButton - 対象のボタン
     * @param {number} trimPixels - 詰める量（px）
     * @returns {void}
     */
    function trimButtonHeight(targetButton, trimPixels) {
        /* レイアウト前は size が無い / size is not set until the layout runs */
        if (!targetButton.size) return;
        targetButton.size = [targetButton.size.width, targetButton.size.height - trimPixels];
    }

    // UIレイアウト（再利用パーツ）ここまで / End of the reusable UI layout

    var LINE_ORIENTATION_EPSILON = 0.01;
    var DEFAULT_NON_SELECTED_OPACITY = 30;

    /* 選択を配列として退避 / Store selection as an array */
    function copySelection(selection) {
        var copiedSelection = [];
        for (var selectionIndex = 0; selectionIndex < selection.length; selectionIndex++) {
            copiedSelection.push(selection[selectionIndex]);
        }
        return copiedSelection;
    }

    /* 退避した選択状態を復元 / Restore stored selection */
    function restoreSelection(items) {
        app.selection = null;
        for (var itemIndex = 0; itemIndex < items.length; itemIndex++) {
            try {
                items[itemIndex].selected = true;
            } catch (e) { }
        }
    }

    /* チェックボックス変更時の処理を設定 / Bind checkbox update handlers */
    function bindCheckboxPreviewUpdates(checkboxes, onUpdate) {
        function bindOneCheckbox(sourceCheckbox) {
            sourceCheckbox._optionClickRequested = false;

            sourceCheckbox.addEventListener("mousedown", function (event) {
                sourceCheckbox._optionClickRequested = event.altKey === true;
            });

            sourceCheckbox.onClick = function () {
                if (sourceCheckbox._optionClickRequested) {
                    for (var checkboxIndex = 0; checkboxIndex < checkboxes.length; checkboxIndex++) {
                        checkboxes[checkboxIndex].value = sourceCheckbox.value;
                        checkboxes[checkboxIndex]._optionClickRequested = false;
                    }
                }

                sourceCheckbox._optionClickRequested = false;
                onUpdate();
            };
        }

        for (var checkboxIndex = 0; checkboxIndex < checkboxes.length; checkboxIndex++) {
            bindOneCheckbox(checkboxes[checkboxIndex]);
        }
    }

    /* ポイント文字かどうかを判定 / Check whether a text frame is point text */
    function isPointTextFrame(textFrame) {
        try {
            return textFrame.kind === TextType.POINTTEXT;
        } catch (e) {
            return false;
        }
    }

    /* エリア内文字かどうかを判定 / Check whether a text frame is area text */
    function isAreaTextFrame(textFrame) {
        try {
            return textFrame.kind === TextType.AREATEXT;
        } catch (e) {
            return false;
        }
    }

    /* パス上文字かどうかを判定 / Check whether a text frame is path text */
    function isPathTextFrame(textFrame) {
        try {
            return textFrame.kind === TextType.PATHTEXT;
        } catch (e) {
            return false;
        }
    }

    /* テキストの行揃えを取得 / Get text alignment */
    function getTextAlignmentType(textFrame) {
        try {
            var justification = textFrame.textRange.paragraphAttributes.justification;
            if (justification === Justification.LEFT) {
                return "left";
            }
            if (justification === Justification.CENTER) {
                return "center";
            }
            if (justification === Justification.RIGHT) {
                return "right";
            }
        } catch (e) { }

        return "other";
    }

    /* テキストのフォント名を取得 / Get text font display name (family + style) */
    function getTextFontName(textFrame) {
        try {
            var font = textFrame.textRange.characterAttributes.textFont;
            var family = "";
            var style = "";
            try { family = font.family || ""; } catch (e1) { }
            try { style = font.style || ""; } catch (e2) { }
            if (family && style) return family + " " + style;
            if (family) return family;
            try { return font.name; } catch (e3) { }
        } catch (e) { }

        return "";
    }

    /* フォント件数を追加 / Add font count */
    function addFontCount(fontCounts, fontName) {
        if (!fontName) {
            return;
        }
        if (!fontCounts[fontName]) {
            fontCounts[fontName] = 0;
        }
        fontCounts[fontName]++;
    }

    /* フォント名をソートして配列化 / Sort font names into an array */
    function getSortedFontNames(fontCounts) {
        var fontNames = [];
        for (var fontName in fontCounts) {
            if (fontCounts.hasOwnProperty(fontName)) {
                fontNames.push(fontName);
            }
        }
        fontNames.sort();
        return fontNames;
    }

    /* オープンパスの線方向を判定 / Detect line orientation of an open path
       - "horizontal": geometricBounds の高さ ≈ 0
       - "vertical":   geometricBounds の幅 ≈ 0
       - "other":      それ以外
    */
    function getOpenPathLineOrientation(pathItem) {
        try {
            var geometricBounds = pathItem.geometricBounds; // [left, top, right, bottom]
            if (!geometricBounds || geometricBounds.length < 4) return "other";
            var width = Math.abs(geometricBounds[2] - geometricBounds[0]);
            var height = Math.abs(geometricBounds[1] - geometricBounds[3]);
            if (height <= LINE_ORIENTATION_EPSILON && width > LINE_ORIENTATION_EPSILON) return "horizontal";
            if (width <= LINE_ORIENTATION_EPSILON && height > LINE_ORIENTATION_EPSILON) return "vertical";
        } catch (e) { }
        return "other";
    }

    /* クローズパスの塗りと線の状態を取得 / Get fill and stroke state of a closed path */
    function getClosedPathPaintType(pathItem) {
        var hasFill = false;
        var hasStroke = false;

        try {
            hasFill = pathItem.filled === true;
        } catch (e1) { }

        try {
            hasStroke = pathItem.stroked === true;
        } catch (e2) { }

        if (hasFill && hasStroke) {
            return "fillAndStroke";
        }
        if (hasFill) {
            return "fillOnly";
        }
        if (hasStroke) {
            return "strokeOnly";
        }

        return "none";
    }

    /**
     * クリップグループのマスク用パスかどうかを判定する
     * @param {PageItem} item - 対象のオブジェクト
     * @returns {boolean} マスク用パスなら true
     */
    function isClippingPathItem(item) {
        try {
            return item.typename === "PathItem" && item.clipping === true;
        } catch (e) {
            return false;
        }
    }

    /* 選択内の各種オブジェクト数をカウント / Count object types in selection */
    function countSelectionItems(selection, includeGroupItems) {
        var counts = {
            text: 0,
            areaText: 0,
            pathText: 0,
            alignLeft: 0,
            alignCenter: 0,
            alignRight: 0,
            fonts: {},
            openPath: 0,
            horizontalLine: 0,
            verticalLine: 0,
            closedPathFillOnly: 0,
            closedPathStrokeOnly: 0,
            closedPathFillAndStroke: 0
        };

        countItemsRecursive(selection, counts, includeGroupItems);
        return counts;
    }

    /* 選択内の子要素も含めて再帰的にカウント / Count selected items recursively including children */
    function countItemsRecursive(items, counts, includeGroupItems) {
        for (var itemIndex = 0; itemIndex < items.length; itemIndex++) {
            var item = items[itemIndex];

            if (isClippingPathItem(item)) {
                continue;
            }

            if (item.typename === "TextFrame") {
                if (isPointTextFrame(item)) {
                    counts.text++;
                } else if (isAreaTextFrame(item)) {
                    counts.areaText++;
                } else if (isPathTextFrame(item)) {
                    counts.pathText++;
                }

                var alignmentType = getTextAlignmentType(item);
                if (alignmentType === "left") {
                    counts.alignLeft++;
                } else if (alignmentType === "center") {
                    counts.alignCenter++;
                } else if (alignmentType === "right") {
                    counts.alignRight++;
                }

                addFontCount(counts.fonts, getTextFontName(item));
            } else if (item.typename === "PathItem") {
                if (item.closed === true) {
                    var paintType = getClosedPathPaintType(item);
                    if (paintType === "fillOnly") {
                        counts.closedPathFillOnly++;
                    } else if (paintType === "strokeOnly") {
                        counts.closedPathStrokeOnly++;
                    } else if (paintType === "fillAndStroke") {
                        counts.closedPathFillAndStroke++;
                    }
                } else {
                    counts.openPath++;
                    var orientation = getOpenPathLineOrientation(item);
                    if (orientation === "horizontal") {
                        counts.horizontalLine++;
                    } else if (orientation === "vertical") {
                        counts.verticalLine++;
                    }
                }
            } else if (item.typename === "GroupItem" && includeGroupItems) {
                countItemsRecursive(item.pageItems, counts, includeGroupItems);
            }
        }
    }

    /* UIから選択条件を取得 / Read filter options from UI */
    function readFilterOptions(dialogUi) {
        return {
            keepText: dialogUi.cbText.value,
            keepAreaText: dialogUi.cbAreaText.value,
            keepPathText: dialogUi.cbPathText.value,
            keepAlignLeft: dialogUi.cbAlignLeft.value,
            keepAlignCenter: dialogUi.cbAlignCenter.value,
            keepAlignRight: dialogUi.cbAlignRight.value,
            selectedFonts: readSelectedFonts(dialogUi.fontCheckboxes),
            keepOpenPath: dialogUi.cbOpenPath.value,
            keepHorizontalLine: dialogUi.cbHorizontalLine.value,
            keepVerticalLine: dialogUi.cbVerticalLine.value,
            keepClosedPathFillOnly: dialogUi.cbClosedPathFillOnly.value,
            keepClosedPathStrokeOnly: dialogUi.cbClosedPathStrokeOnly.value,
            keepClosedPathFillAndStroke: dialogUi.cbClosedPathFillAndStroke.value,
            includeGroupItems: dialogUi.rbScopeIncludeGroupItems.value
        };
    }

    /* チェックされたフォント名を取得 / Read selected font names */
    function readSelectedFonts(fontCheckboxes) {
        var selectedFonts = {};
        for (var fontCheckboxIndex = 0; fontCheckboxIndex < fontCheckboxes.length; fontCheckboxIndex++) {
            if (fontCheckboxes[fontCheckboxIndex].checkbox.value) {
                selectedFonts[fontCheckboxes[fontCheckboxIndex].fontName] = true;
            }
        }
        return selectedFonts;
    }

    /* 1項目が残す対象かどうかを判定 / Check whether an item should remain selected */
    function shouldKeepItem(item, filterOptions) {
        /* マスク用パス自体は選択対象から除外 / Exclude the clipping mask path itself */
        if (isClippingPathItem(item)) {
            return false;
        }

        if (item.typename === "TextFrame") {
            var keepByTextType = false;
            if (isPointTextFrame(item)) {
                keepByTextType = filterOptions.keepText;
            } else if (isAreaTextFrame(item)) {
                keepByTextType = filterOptions.keepAreaText;
            } else if (isPathTextFrame(item)) {
                keepByTextType = filterOptions.keepPathText;
            }

            if (!keepByTextType) {
                return false;
            }

            if (filterOptions.keepAlignLeft || filterOptions.keepAlignCenter || filterOptions.keepAlignRight) {
                var alignmentType = getTextAlignmentType(item);
                if (alignmentType === "left" && !filterOptions.keepAlignLeft) {
                    return false;
                }
                if (alignmentType === "center" && !filterOptions.keepAlignCenter) {
                    return false;
                }
                if (alignmentType === "right" && !filterOptions.keepAlignRight) {
                    return false;
                }
                if (alignmentType !== "left" && alignmentType !== "center" && alignmentType !== "right") {
                    return false;
                }
            }

            if (hasSelectedFonts(filterOptions.selectedFonts)) {
                return filterOptions.selectedFonts[getTextFontName(item)] === true;
            }

            return true;
        }

        if (item.typename === "PathItem") {
            if (item.closed === true) {
                var paintType = getClosedPathPaintType(item);
                if (paintType === "fillOnly") {
                    return filterOptions.keepClosedPathFillOnly;
                }
                if (paintType === "strokeOnly") {
                    return filterOptions.keepClosedPathStrokeOnly;
                }
                if (paintType === "fillAndStroke") {
                    return filterOptions.keepClosedPathFillAndStroke;
                }
                return false;
            }
            var orientation = getOpenPathLineOrientation(item);
            if (orientation === "horizontal") {
                return filterOptions.keepOpenPath || filterOptions.keepHorizontalLine;
            }
            if (orientation === "vertical") {
                return filterOptions.keepOpenPath || filterOptions.keepVerticalLine;
            }
            return filterOptions.keepOpenPath;
        }

        return false;
    }

    /* フォント指定があるかどうかを判定 / Check whether any font is selected */
    function hasSelectedFonts(selectedFonts) {
        for (var fontName in selectedFonts) {
            if (selectedFonts.hasOwnProperty(fontName)) {
                return true;
            }
        }
        return false;
    }

    /* 選択状態を条件に合わせて反映 / Apply filter options to selection */
    function applyFilterToSelection(items, filterOptions) {
        app.selection = null;
        applyFilterToItemsRecursive(items, filterOptions);
    }

    /* 子要素も含めて選択状態を条件に合わせて反映 / Apply filter options recursively including children */
    function applyFilterToItemsRecursive(items, filterOptions) {
        for (var itemIndex = 0; itemIndex < items.length; itemIndex++) {
            var item = items[itemIndex];

            try {
                item.selected = shouldKeepItem(item, filterOptions);
            } catch (e1) { }

            if (item.typename === "GroupItem" && filterOptions.includeGroupItems) {
                try {
                    applyFilterToItemsRecursive(item.pageItems, filterOptions);
                } catch (e2) { }
            }
        }
    }

    /* 行揃え/フォントパネルの有効状態を更新 / Update alignment & font panel enabled state */
    function updateAlignmentPanelEnabled(dialogUi) {
        var hasTextTarget = dialogUi.cbText.value || dialogUi.cbAreaText.value || dialogUi.cbPathText.value;
        dialogUi.alignmentPanel.enabled = hasTextTarget;
        if (dialogUi.fontPanel) dialogUi.fontPanel.enabled = hasTextTarget;
    }

    /* 元の表示状態を退避 / Capture original visibility/opacity for items (recursive) */
    function captureVisualState(items, snapshot) {
        for (var itemIndex = 0; itemIndex < items.length; itemIndex++) {
            var item = items[itemIndex];
            var entry = { item: item };
            try { entry.hidden = item.hidden; } catch (e1) { entry.hidden = false; }
            try { entry.opacity = item.opacity; } catch (e2) { entry.opacity = 100; }
            snapshot.push(entry);
            if (item.typename === "GroupItem") {
                try { captureVisualState(item.pageItems, snapshot); } catch (e3) { }
            }
        }
    }

    /* 退避した表示状態を復元 / Restore captured visibility/opacity */
    function restoreVisualState(snapshot) {
        for (var snapshotIndex = 0; snapshotIndex < snapshot.length; snapshotIndex++) {
            var visualState = snapshot[snapshotIndex];
            try { visualState.item.hidden = visualState.hidden; } catch (e1) { }
            try { visualState.item.opacity = visualState.opacity; } catch (e2) { }
        }
    }

    /* 非選択オブジェクトに挙動を適用 / Apply behavior to non-selected items
       mode: "none" | "hide" | "opacity"
       opacityValue: number (0-100)
    */
    function applyNonSelectedBehavior(items, mode, opacityValue) {
        if (mode === "none") return;
        for (var itemIndex = 0; itemIndex < items.length; itemIndex++) {
            var item = items[itemIndex];
            var isSelected = false;
            try { isSelected = item.selected === true; } catch (e0) { }
            if (!isSelected) {
                try {
                    if (mode === "hide") {
                        item.hidden = true;
                    } else if (mode === "opacity") {
                        item.opacity = opacityValue;
                    }
                } catch (e) { }
            }
            if (item.typename === "GroupItem") {
                try { applyNonSelectedBehavior(item.pageItems, mode, opacityValue); } catch (e2) { }
            }
        }
    }

    // ダイアログの位置と不透明度（再利用パーツ） / Dialog position and opacity (reusable)

    var DIALOG_OPACITY = 0.98;       /* ダイアログの不透明度 / dialog opacity */
    var DIALOG_AVOID_MARGIN = 60;    /* 選択範囲の推定位置の両側に取る余裕（px）/ margin on each side of the estimated selection (px) */
    var DIALOG_AVOID_MAX_ITEMS = 100; /* 選択範囲を測るオブジェクトの上限 / max items measured for the selection bounds */

    /**
     * ダイアログの不透明度を設定し、前回閉じた位置で開いて、動かした位置を記録するようにする。
     * 開く位置が選択中のオブジェクトに重なりそうなときは、左右の反対側へずらす（Illustrator のみ）。
     * 既存の onShow / onMove / onClose は先に呼んでから、位置の復元・記録を行う。
     * @param {Window} dialog - 対象のダイアログ
     * @param {string} storageKey - 位置を覚えるキー（ふつうは SCRIPT_NAME）
     * @returns {void}
     */
    function prepareDialogWindow(dialog, storageKey) {
        /* 同じダイアログを開き直すときは、選択範囲を測り直すだけにする（ハンドラーを重ねない）
           When the same dialog is shown again, only re-measure the selection (don't stack handlers) */
        if (dialog.dialogWindowState) {
            dialog.dialogWindowState.selectionSpan = getSelectionViewSpan();
            dialog.dialogWindowState.avoidedLocation = null;
            return;
        }
        var locationKey = "__" + storageKey + "_DialogLocation";
        var previousOnShow = dialog.onShow;
        var previousOnMove = dialog.onMove;
        var previousOnClose = dialog.onClose;
        var windowState = {
            selectionSpan: getSelectionViewSpan(), /* 選択範囲は show() の前に測る / measured before show() */
            screenWidth: null,                     /* 最初に開いたときに推定する / estimated on the first show */
            avoidedLocation: null                  /* 避けるためにずらした位置（記録しない）/ location set to avoid the selection (not remembered) */
        };
        dialog.dialogWindowState = windowState;

        dialog.opacity = DIALOG_OPACITY;

        /* 今の位置を記録する / Remember the current location */
        function rememberDialogLocation() {
            var currentLocation = [dialog.location[0], dialog.location[1]];
            var avoidedLocation = windowState.avoidedLocation;
            if (avoidedLocation && currentLocation[0] === avoidedLocation[0] && currentLocation[1] === avoidedLocation[1]) return;
            $.global[locationKey] = currentLocation;
        }

        dialog.onShow = function () {
            /* 最初に開くときの既定の位置は画面の横中央なので、画面の幅を逆算できる。2回目からは前回の位置なので使い回す
               On the first show the default location is centered horizontally, which gives the screen width; reuse it afterwards */
            if (windowState.screenWidth === null) windowState.screenWidth = dialog.location[0] * 2 + dialog.bounds.width;
            if (previousOnShow) previousOnShow.apply(this, arguments);
            /* $.screens は実際の画面の大きさと合わない（Mac で 1280×524 など）ので、画面内かは判定しない
               $.screens does not match the real display (e.g. 1280x524 on a Mac), so no on-screen check */
            var savedLocation = $.global[locationKey];
            if (savedLocation) dialog.location = [savedLocation[0], savedLocation[1]];
            if (windowState.selectionSpan) {
                var avoidLeft = findDialogLeftAvoidingSelection(dialog.location[0], dialog.bounds.width, windowState.screenWidth, windowState.selectionSpan);
                if (avoidLeft !== null) {
                    dialog.location = [avoidLeft, dialog.location[1]];
                    /* 代入後の値で比べる（丸められることがある）/ Compare with the value after assignment, which may be rounded */
                    windowState.avoidedLocation = [dialog.location[0], dialog.location[1]];
                }
            }
        };
        dialog.onMove = function () {
            if (previousOnMove) previousOnMove.apply(this, arguments);
            rememberDialogLocation();
        };
        dialog.onClose = function () {
            rememberDialogLocation();
            /* false を返すと閉じるのを取りやめるので、戻り値は元の onClose のものを返す
               Returning false cancels the close, so pass the original onClose result through */
            if (previousOnClose) return previousOnClose.apply(this, arguments);
        };
    }

    /**
     * 選択中のオブジェクトが、ドキュメントの表示域の左端から画面上で何 px の範囲にあるかを返す。
     * @returns {{left: number, right: number, viewWidth: number}|null} 選択が無い・測れないときは null
     */
    function getSelectionViewSpan() {
        try {
            if (app.name !== "Adobe Illustrator" || !app.documents.length) return null;
            var targetDoc = app.activeDocument;
            var selectedItems = targetDoc.selection;
            /* 文字ツールで文字を選択しているときは TextRange が返り、[0] が無い / Selecting characters with the Type tool returns a TextRange, which has no [0] */
            if (!selectedItems || selectedItems.typename === "TextRange" || !selectedItems.length || !selectedItems[0].visibleBounds) return null;
            var itemCount = Math.min(selectedItems.length, DIALOG_AVOID_MAX_ITEMS);
            var spanLeft = Infinity;
            var spanRight = -Infinity;
            for (var i = 0; i < itemCount; i++) {
                var itemBounds = selectedItems[i].visibleBounds;
                if (itemBounds[0] < spanLeft) spanLeft = itemBounds[0];
                if (itemBounds[2] > spanRight) spanRight = itemBounds[2];
            }
            var activeView = targetDoc.activeView; /* 複数ウィンドウで開いていても今のウィンドウ / the current window even with multiple windows */
            var viewBounds = activeView.bounds;
            var zoom = activeView.zoom;
            var viewWidth = (viewBounds[2] - viewBounds[0]) * zoom;
            /* 表示域の外にはみ出した部分は数えない / Ignore the part outside the view */
            var left = Math.max(0, (spanLeft - viewBounds[0]) * zoom);
            var right = Math.min(viewWidth, (spanRight - viewBounds[0]) * zoom);
            if (right <= left) return null;
            return { left: left, right: right, viewWidth: viewWidth };
        } catch (e) {
            /* テキスト編集中など測れないときは避けない / Do not avoid when it cannot be measured, e.g. while editing text */
            return null;
        }
    }

    /**
     * ダイアログが選択範囲に重なるなら、重ならない左端の位置を返す。
     * 表示域は画面の横中央にあるとみなし、ずれは DIALOG_AVOID_MARGIN で吸収する。
     * @param {number} dialogLeft - 今のダイアログの左端
     * @param {number} dialogWidth - ダイアログの幅
     * @param {number} screenWidth - 画面の幅
     * @param {{left: number, right: number, viewWidth: number}} selectionSpan - getSelectionViewSpan() の結果
     * @returns {number|null} ずらした左端。重ならない・どちらにも収まらないときは null
     */
    function findDialogLeftAvoidingSelection(dialogLeft, dialogWidth, screenWidth, selectionSpan) {
        var viewLeft = (screenWidth - selectionSpan.viewWidth) / 2;
        var avoidLeft = viewLeft + selectionSpan.left - DIALOG_AVOID_MARGIN;
        var avoidRight = viewLeft + selectionSpan.right + DIALOG_AVOID_MARGIN;
        if (dialogLeft + dialogWidth <= avoidLeft || dialogLeft >= avoidRight) return null;

        var leftSideLeft = avoidLeft - dialogWidth;   /* 選択範囲の左に置くとき / placed left of the selection */
        var rightSideLeft = avoidRight;               /* 選択範囲の右に置くとき / placed right of the selection */
        var fitsLeft = leftSideLeft >= 0;
        var fitsRight = rightSideLeft + dialogWidth <= screenWidth;
        /* 選択範囲が画面の右寄りなら左へ、左寄りなら右へ逃がす / Move away from the side the selection leans to */
        var preferLeft = (avoidLeft + avoidRight) / 2 > screenWidth / 2;
        if (preferLeft && fitsLeft) return leftSideLeft;
        if (fitsRight) return rightSideLeft;
        if (fitsLeft) return leftSideLeft;
        return null;
    }

    // ダイアログの位置と不透明度（再利用パーツ）ここまで / End of the reusable dialog position and opacity

    function showFilterDialog(originalSelection) {
        var dialog = new Window("dialog", getLabel("dialogTitle") + " " + SCRIPT_VERSION);
        setupWindow(dialog);

        /* フォント一覧はグループ内も含めて作り、件数だけスコープに合わせて書き換える
           Build the font list including group contents; only the counts follow the scope */
        var counts = countSelectionItems(originalSelection, true);

        /* 元の表示状態スナップショット / Snapshot original visual state */
        var visualSnapshot = [];
        captureVisualState(originalSelection, visualSnapshot);

        /* 上部：選択オブジェクト以外の挙動 / Top: behavior for non-selected items */
        var nonSelectedPanel = dialog.add("panel", undefined, getLabel("nonSelectedPanel"));
        setupPanel(nonSelectedPanel, 6);
        nonSelectedPanel.alignChildren = ["left", "center"];

        var nonSelectedRadioGroup = nonSelectedPanel.add("group");
        nonSelectedRadioGroup.orientation = "row";
        nonSelectedRadioGroup.alignChildren = ["left", "center"];
        nonSelectedRadioGroup.spacing = 12;

        var rbNonSelNone = nonSelectedRadioGroup.add("radiobutton", undefined, getLabel("nonSelectedNone"));
        rbNonSelNone.helpTip = getLabel("tipNonSelectedNone");
        var rbNonSelHide = nonSelectedRadioGroup.add("radiobutton", undefined, getLabel("nonSelectedHide"));
        rbNonSelHide.helpTip = getLabel("tipNonSelectedHide");
        var rbNonSelOpacity = nonSelectedRadioGroup.add("radiobutton", undefined, labelWithValue("nonSelectedOpacity", DEFAULT_NON_SELECTED_OPACITY + "%"));
        rbNonSelOpacity.helpTip = getLabel("tipNonSelectedOpacity");

        var nonSelectedOpacitySliderGroup = nonSelectedPanel.add("group");
        nonSelectedOpacitySliderGroup.orientation = "row";
        nonSelectedOpacitySliderGroup.alignChildren = ["center", "center"];
        nonSelectedOpacitySliderGroup.alignment = ["fill", "center"];

        var nonSelectedOpacitySlider = nonSelectedOpacitySliderGroup.add("slider", undefined, DEFAULT_NON_SELECTED_OPACITY, 0, 100);
        nonSelectedOpacitySlider.helpTip = getLabel("tipNonSelectedSlider");
        nonSelectedOpacitySlider.preferredSize.width = 220;
        rbNonSelNone.value = true;

        function getNonSelectedMode() {
            if (rbNonSelHide.value) return "hide";
            if (rbNonSelOpacity.value) return "opacity";
            return "none";
        }

        function getNonSelectedOpacityValue() {
            return Math.max(0, Math.min(100, Math.round(nonSelectedOpacitySlider.value)));
        }

        function updateNonSelectedOpacityDisplay() {
            rbNonSelOpacity.text = labelWithValue("nonSelectedOpacity", getNonSelectedOpacityValue() + "%");
        }

        function updateNonSelectedOpacitySliderEnabled() {
            nonSelectedOpacitySlider.enabled = rbNonSelOpacity.value === true;
        }

        /* 簡易モード：横並びチェックボックス / Quick mode: horizontal checkboxes */
        var simplePanel = dialog.add("panel", undefined, getLabel("simplePanel"));
        setupPanel(simplePanel);
        simplePanel.orientation = "row";
        simplePanel.alignChildren = ["left", "center"];
        var cbSimpleText = simplePanel.add("checkbox", undefined, getLabel("simpleText"));
        cbSimpleText.helpTip = getLabel("tipSimpleText");
        var cbSimpleStrokeOnly = simplePanel.add("checkbox", undefined, getLabel("simpleStrokeOnly"));
        cbSimpleStrokeOnly.helpTip = getLabel("tipSimpleStrokeOnly");
        var cbSimpleFillOnlyPath = simplePanel.add("checkbox", undefined, getLabel("simpleFillOnlyPath"));
        cbSimpleFillOnlyPath.helpTip = getLabel("tipSimpleFillOnlyPath");

        /* 対象スコープ / Selection scope */
        var scopePanel = dialog.add("panel", undefined, getLabel("scopePanel"));
        setupPanel(scopePanel);
        scopePanel.orientation = "row";
        scopePanel.alignChildren = ["left", "center"];
        var rbScopeSelectedOnly = scopePanel.add("radiobutton", undefined, getLabel("scopeSelectedOnly"));
        rbScopeSelectedOnly.helpTip = getLabel("tipScope");
        var rbScopeIncludeGroupItems = scopePanel.add("radiobutton", undefined, getLabel("scopeIncludeGroupItems"));
        rbScopeIncludeGroupItems.helpTip = getLabel("tipScope");
        rbScopeIncludeGroupItems.value = true;

        var columnGroup = dialog.add("group");
        columnGroup.orientation = "row";
        columnGroup.alignChildren = ["fill", "top"];
        columnGroup.alignment = "fill";
        columnGroup.spacing = COLUMN_SPACING;

        var leftColumn = columnGroup.add("group");
        leftColumn.orientation = "column";
        leftColumn.alignChildren = "fill";
        leftColumn.alignment = ["fill", "top"];

        var rightColumn = columnGroup.add("group");
        rightColumn.orientation = "column";
        rightColumn.alignChildren = "fill";
        rightColumn.alignment = ["fill", "top"];

        var textPanel = leftColumn.add("panel", undefined, getLabel("textPanel"));
        setupPanel(textPanel, 6);
        var cbText = textPanel.add("checkbox", undefined, labelWithCount("textObject", counts.text));
        var cbAreaText = textPanel.add("checkbox", undefined, labelWithCount("areaText", counts.areaText));
        var cbPathText = textPanel.add("checkbox", undefined, labelWithCount("pathText", counts.pathText));

        var alignmentPanel = leftColumn.add("panel", undefined, getLabel("alignmentPanel"));
        setupPanel(alignmentPanel, 6);
        var cbAlignLeft = alignmentPanel.add("checkbox", undefined, labelWithCount("alignLeft", counts.alignLeft));
        var cbAlignCenter = alignmentPanel.add("checkbox", undefined, labelWithCount("alignCenter", counts.alignCenter));
        var cbAlignRight = alignmentPanel.add("checkbox", undefined, labelWithCount("alignRight", counts.alignRight));

        var pathPanel = rightColumn.add("panel", undefined, getLabel("pathPanel"));
        setupPanel(pathPanel, 6);
        var cbOpenPath = pathPanel.add("checkbox", undefined, labelWithCount("openPath", counts.openPath));
        var cbHorizontalLine = pathPanel.add("checkbox", undefined, labelWithCount("horizontalLine", counts.horizontalLine));
        var cbVerticalLine = pathPanel.add("checkbox", undefined, labelWithCount("verticalLine", counts.verticalLine));

        var closedPathPanel = rightColumn.add("panel", undefined, getLabel("closedPathPanel"));
        setupPanel(closedPathPanel, 6);
        var cbClosedPathFillOnly = closedPathPanel.add("checkbox", undefined, labelWithCount("closedPathFillOnly", counts.closedPathFillOnly));
        var cbClosedPathStrokeOnly = closedPathPanel.add("checkbox", undefined, labelWithCount("closedPathStrokeOnly", counts.closedPathStrokeOnly));
        var cbClosedPathFillAndStroke = closedPathPanel.add("checkbox", undefined, labelWithCount("closedPathFillAndStroke", counts.closedPathFillAndStroke));

        /* フォントパネル：カラム貫通（全幅） / Font panel spanning across columns */
        var fontPanel = dialog.add("panel", undefined, getLabel("fontPanel"));
        setupPanel(fontPanel, 6);
        var fontCheckboxes = [];
        var fontNames = getSortedFontNames(counts.fonts);
        for (var fontIndex = 0; fontIndex < fontNames.length; fontIndex++) {
            var fontName = fontNames[fontIndex];
            var fontCheckboxLabel = appendValueText(fontName, counts.fonts[fontName]);
            var fontCheckbox = fontPanel.add("checkbox", undefined, fontCheckboxLabel);
            fontCheckboxes.push({
                fontName: fontName,
                checkbox: fontCheckbox
            });
        }

        var dialogUi = {
            cbText: cbText,
            cbAreaText: cbAreaText,
            cbPathText: cbPathText,
            alignmentPanel: alignmentPanel,
            cbAlignLeft: cbAlignLeft,
            cbAlignCenter: cbAlignCenter,
            cbAlignRight: cbAlignRight,
            fontPanel: fontPanel,
            fontCheckboxes: fontCheckboxes,
            cbOpenPath: cbOpenPath,
            cbHorizontalLine: cbHorizontalLine,
            cbVerticalLine: cbVerticalLine,
            cbClosedPathFillOnly: cbClosedPathFillOnly,
            cbClosedPathStrokeOnly: cbClosedPathStrokeOnly,
            cbClosedPathFillAndStroke: cbClosedPathFillAndStroke,
            rbScopeIncludeGroupItems: rbScopeIncludeGroupItems
        };

        var filterCheckboxes = [
            cbText,
            cbAreaText,
            cbPathText,
            cbAlignLeft,
            cbAlignCenter,
            cbAlignRight,
            cbOpenPath,
            cbHorizontalLine,
            cbVerticalLine,
            cbClosedPathFillOnly,
            cbClosedPathStrokeOnly,
            cbClosedPathFillAndStroke
        ];

        for (var fontCheckboxIndex = 0; fontCheckboxIndex < fontCheckboxes.length; fontCheckboxIndex++) {
            filterCheckboxes.push(fontCheckboxes[fontCheckboxIndex].checkbox);
        }

        /* デフォルトでは全てチェックを外す / Uncheck all options by default */
        for (var checkboxIndex = 0; checkboxIndex < filterCheckboxes.length; checkboxIndex++) {
            filterCheckboxes[checkboxIndex].value = false;
        }

        /* テキスト系をまとめてデフォルトON / Enable all text-related options by default */
        cbSimpleText.value = true;
        cbText.value = true;
        cbAreaText.value = true;
        cbPathText.value = true;

        /* スコープに合わせて件数表示を更新 / Update the count labels for the current scope */
        function updateCountLabels() {
            var scopeCounts = countSelectionItems(originalSelection, rbScopeIncludeGroupItems.value);
            cbText.text = labelWithCount("textObject", scopeCounts.text);
            cbAreaText.text = labelWithCount("areaText", scopeCounts.areaText);
            cbPathText.text = labelWithCount("pathText", scopeCounts.pathText);
            cbAlignLeft.text = labelWithCount("alignLeft", scopeCounts.alignLeft);
            cbAlignCenter.text = labelWithCount("alignCenter", scopeCounts.alignCenter);
            cbAlignRight.text = labelWithCount("alignRight", scopeCounts.alignRight);
            cbOpenPath.text = labelWithCount("openPath", scopeCounts.openPath);
            cbHorizontalLine.text = labelWithCount("horizontalLine", scopeCounts.horizontalLine);
            cbVerticalLine.text = labelWithCount("verticalLine", scopeCounts.verticalLine);
            cbClosedPathFillOnly.text = labelWithCount("closedPathFillOnly", scopeCounts.closedPathFillOnly);
            cbClosedPathStrokeOnly.text = labelWithCount("closedPathStrokeOnly", scopeCounts.closedPathStrokeOnly);
            cbClosedPathFillAndStroke.text = labelWithCount("closedPathFillAndStroke", scopeCounts.closedPathFillAndStroke);
            for (var fontLabelIndex = 0; fontLabelIndex < fontCheckboxes.length; fontLabelIndex++) {
                var fontEntry = fontCheckboxes[fontLabelIndex];
                fontEntry.checkbox.text = appendValueText(fontEntry.fontName, scopeCounts.fonts[fontEntry.fontName] || 0);
            }
        }

        function updateSimpleCheckboxesFromDetailedSelection() {
            cbSimpleText.value = cbText.value === true && cbAreaText.value === true && cbPathText.value === true;
            cbSimpleStrokeOnly.value = cbOpenPath.value === true && cbClosedPathStrokeOnly.value === true;
            cbSimpleFillOnlyPath.value = cbClosedPathFillOnly.value === true;
        }

        function updateCanvasSelection() {
            updateAlignmentPanelEnabled(dialogUi);
            updateSimpleCheckboxesFromDetailedSelection();
            restoreVisualState(visualSnapshot);
            applyFilterToSelection(originalSelection, readFilterOptions(dialogUi));
            applyNonSelectedBehavior(originalSelection, getNonSelectedMode(), getNonSelectedOpacityValue());
            app.redraw();
        }

        rbNonSelNone.onClick = function () {
            updateNonSelectedOpacitySliderEnabled();
            updateCanvasSelection();
        };
        rbNonSelHide.onClick = function () {
            updateNonSelectedOpacitySliderEnabled();
            updateCanvasSelection();
        };
        rbNonSelOpacity.onClick = function () {
            updateNonSelectedOpacitySliderEnabled();
            updateCanvasSelection();
        };
        nonSelectedOpacitySlider.onChanging = function () {
            rbNonSelOpacity.value = true;
            updateNonSelectedOpacityDisplay();
            updateNonSelectedOpacitySliderEnabled();
            updateCanvasSelection();
        };
        nonSelectedOpacitySlider.onChange = function () {
            rbNonSelOpacity.value = true;
            updateNonSelectedOpacityDisplay();
            updateNonSelectedOpacitySliderEnabled();
            updateCanvasSelection();
        };

        rbScopeSelectedOnly.onClick = function () {
            updateCountLabels();
            updateCanvasSelection();
        };
        rbScopeIncludeGroupItems.onClick = function () {
            updateCountLabels();
            updateCanvasSelection();
        };

        cbSimpleText.onClick = function () {
            cbText.value = cbSimpleText.value;
            cbAreaText.value = cbSimpleText.value;
            cbPathText.value = cbSimpleText.value;
            updateCanvasSelection();
        };
        cbSimpleStrokeOnly.onClick = function () {
            cbOpenPath.value = cbSimpleStrokeOnly.value;
            cbClosedPathStrokeOnly.value = cbSimpleStrokeOnly.value;
            updateCanvasSelection();
        };
        cbSimpleFillOnlyPath.onClick = function () {
            cbClosedPathFillOnly.value = cbSimpleFillOnlyPath.value;
            updateCanvasSelection();
        };

        bindCheckboxPreviewUpdates(filterCheckboxes, updateCanvasSelection);

        /* ボタン行（左：アウトライン切り替え、右：キャンセル・OK） / Button row (left: outline toggle, right: Cancel and OK) */
        var buttonRow = addButtonRow(dialog);

        var isOutlineMode = false;
        var btnPreview = buttonRow.leftGroup.add("button", undefined, getLabel("btnOutlineOn"));
        btnPreview.helpTip = getLabel("tipPreviewButton");
        btnPreview.onClick = function () {
            try {
                app.executeMenuCommand("preview");
                isOutlineMode = !isOutlineMode;
                btnPreview.text = isOutlineMode ? getLabel("btnOutlineOff") : getLabel("btnOutlineOn");
            } catch (e) { }
        };

        var btnCancel = buttonRow.rightGroup.add("button", undefined, getLabel("cancel"), { name: "cancel" });
        var btnOK = buttonRow.rightGroup.add("button", undefined, getLabel("ok"), { name: "ok" });

        updateNonSelectedOpacitySliderEnabled();
        updateCanvasSelection();

        alignRightOnlyButtonRow(buttonRow);
        prepareDialogWindow(dialog, SCRIPT_NAME);
        var dialogResult = dialog.show();

        if (isOutlineMode) {
            try {
                app.executeMenuCommand("preview");
            } catch (e) { }
        }

        restoreVisualState(visualSnapshot);

        if (dialogResult !== 1) {
            restoreSelection(originalSelection);
            return null;
        }

        return readFilterOptions(dialogUi);
    }

    (function () {
        if (app.documents.length === 0) {
            showError("noDocumentError");
            return;
        }

        var doc = app.activeDocument;
        var originalSelection = copySelection(doc.selection);

        if (originalSelection.length === 0) {
            showError("noSelectionError");
            return;
        }

        showFilterDialog(originalSelection);
    })();

})();
