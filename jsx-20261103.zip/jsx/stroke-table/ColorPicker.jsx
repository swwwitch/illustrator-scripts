#target illustrator
app.preferences.setBooleanPreference('ShowExternalJSXWarning', false);

/*
SCRIPTMETA-BEGIN
Script-ID=com.swwwitch.illustrator.ColorPicker
Name=カラーピッカーの再利用ライブラリ
Author=Masahiro Takano (@swwwitch)
Target-App=Illustrator
Version=1.1.8
Description-BEGIN
他のスクリプトから `#include` して使う、カラーピッカーの再利用ライブラリです。
`ColorPicker.show()` を呼ぶとダイアログを開き、選択された色を返します。

A reusable color-picker library meant to be pulled in from other scripts with `#include`.
Calling `ColorPicker.show()` opens the dialog and returns the chosen color.
Description-END
SCRIPTMETA-END
*/

/*

### 概要

他のスクリプトから `#include` して使う、カラーピッカーの再利用ライブラリです。
`ColorPicker.show()` を呼ぶとダイアログを開き、選択された色を返します。

詳細は README を参照してください。
https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/ColorPicker.md

### Overview

A reusable color-picker library meant to be pulled in from other scripts with `#include`.
Calling `ColorPicker.show()` opens the dialog and returns the chosen color.

See the README for details.
https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/ColorPicker.md

*/

// =========================================
// 基本情報 / Basic info
// =========================================
var SCRIPT_NAME     = "ColorPicker";                  /* スクリプト名 / script name */
var SCRIPT_VERSION  = "v1.1.8";                       /* バージョン / version */
var SCRIPT_AUTHOR   = "Masahiro Takano (@swwwitch)";  /* 作者 / author */
var SCRIPT_RELEASED = "";                             /* 最初のリリース日 / first release date */
var SCRIPT_UPDATED  = "2026-10-16";                   /* 更新日 / last updated */

var SCRIPT_DESCRIPTION_JA = "カラーピッカーの再利用ライブラリ"; /* README の見出し / README title (Japanese) */

var SCRIPT_README_JA  = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/ColorPicker.md"; /* README（日本語） */
var SCRIPT_README_EN  = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/ColorPicker.md"; /* README (English) */
var SCRIPT_SOURCE_URL = "https://github.com/swwwitch/illustrator-scripts/blob/master/jsx/stroke-table/ColorPicker.jsx"; /* 最新版のソース / latest source */

// Released under the MIT license
// http://opensource.org/licenses/mit-license.php

/*
--------------------------------------------------
Reusable Illustrator Color Picker Library
--------------------------------------------------
Usage:

#include "ColorPicker.jsx"

var result = ColorPicker.show({
    value: "FF0000",      // "RRGGBB" or "cmyk:C,M,Y,K"
    title: "Color Picker"
});

if (result !== null) {
    $.writeln(result);
}

Return values:
RGB  -> "RRGGBB"
CMYK -> "cmyk:C,M,Y,K"
--------------------------------------------------
*/

var ColorPicker = (function () {

    // =========================================
    // ユーザー設定 / User Settings
    // =========================================

    /* スウォッチ行に並べる色（RRGGBB） / Colors shown in the swatch row (RRGGBB) */
    var DEFAULT_SWATCHES = [
        "FF0000", "FFCC00", "FFFF00",
        "00CC00", "0066FF",
        "FF99CC", "996633", "666666",
        "999999"
    ];

    // =========================================
    // レイアウト / Layout
    // =========================================

    // UIレイアウト（再利用パーツ） / UI layout (reusable)

    /* ウィンドウ・パネルの余白と間隔 / Window & panel margins and spacing */
    var WINDOW_MARGINS = 16;                 /* ウィンドウ外周の余白 / window margin */
    var WINDOW_SPACING = 12;                 /* ウィンドウ内の要素間隔 / window spacing */
    var PANEL_MARGINS  = [16, 20, 16, 12];   /* パネル余白 [左,上,右,下] / panel margins */
    var PANEL_SPACING  = 12;                 /* パネル内の要素間隔 / panel spacing */
    var COLUMN_SPACING = 12;                 /* 2カラムの間隔 / gap between columns */
    var TAB_MARGINS    = [15, 20, 5, 10];    /* タブ余白 [左,上,右,下] / tab margins */

    /**
     * ウィンドウの共通設定
     * @param {Window} targetWindow - 対象のウィンドウ
     * @param {number} [spacing] - 要素間隔（省略時は WINDOW_SPACING）
     * @returns {void}
     */
    function setupWindow(targetWindow, spacing) {
        targetWindow.orientation = "column";
        targetWindow.alignChildren = "fill";
        targetWindow.margins = WINDOW_MARGINS;
        targetWindow.spacing = (typeof spacing === "number") ? spacing : WINDOW_SPACING;
    }

    /**
     * パネルの共通設定（子は幅いっぱい。ボタンは alignment = "left" で広げない）
     * @param {Panel} targetPanel - 対象のパネル
     * @param {number} [spacing] - 要素間隔（省略時は PANEL_SPACING）
     * @returns {void}
     */
    function setupPanel(targetPanel, spacing) {
        targetPanel.orientation = "column";
        targetPanel.alignChildren = ["fill", "top"];
        targetPanel.alignment = "fill";
        targetPanel.margins = PANEL_MARGINS;
        targetPanel.spacing = (typeof spacing === "number") ? spacing : PANEL_SPACING;
    }

    /**
     * タブの共通設定
     * @param {Tab} targetTab - 対象のタブ
     * @param {number} [spacing] - 要素間隔（省略時は変えない）
     * @returns {void}
     */
    function setupTab(targetTab, spacing) {
        targetTab.orientation = "column";
        targetTab.alignChildren = "fill";
        targetTab.margins = TAB_MARGINS;
        if (typeof spacing === "number") targetTab.spacing = spacing;
    }

    /**
     * 横並びの行グループの共通設定（ボタン列など）。
     * alignment と alignChildren を対で指定し、中のボタンが横に伸びたり天地がずれたりしないようにする
     * @param {Group} rowGroup - 対象のグループ
     * @param {string|string[]} [rowAlignment] - 横方向の alignment（省略時は "left"）。配列ならそのまま使う
     * @param {number} [spacing] - 要素間隔（省略時は PANEL_SPACING）
     * @returns {void}
     */
    function setupRow(rowGroup, rowAlignment, spacing) {
        rowGroup.orientation = "row";
        rowGroup.alignment = (rowAlignment instanceof Array) ? rowAlignment : [rowAlignment || "left", "center"];
        rowGroup.alignChildren = ["left", "center"];
        rowGroup.spacing = (typeof spacing === "number") ? spacing : PANEL_SPACING;
    }

    /**
     * ボタンの高さを指定した px だけ詰める（レイアウトが決まったあとに呼ぶ）
     * @param {Button} targetButton - 対象のボタン
     * @param {number} trimPixels - 詰める量（px）
     * @returns {void}
     */
    function trimButtonHeight(targetButton, trimPixels) {
        /* レイアウト前は size が無い / size is not set until the layout runs */
        if (!targetButton.size) return;
        targetButton.size = [targetButton.size.width, targetButton.size.height - trimPixels];
    }

    // UIレイアウト（再利用パーツ）ここまで / End of the reusable UI layout

    // UI の明暗（再利用パーツ） / UI theme (reusable)

    /**
     * UI がダークテーマかどうかを判定する（Illustrator は uiBrightness、InDesign は uiBrightnessPreference）
     * @returns {boolean} ダークなら true。取得できない環境では false（明るいUI扱い）
     */
    function isDarkUI() {
        try {
            if (app.preferences && app.preferences.getRealPreference) {
                return app.preferences.getRealPreference("uiBrightness") <= 0.5; /* Illustrator */
            }
            return app.generalPreferences.uiBrightnessPreference <= 0.5; /* InDesign */
        } catch (e) {
            return false;
        }
    }

    // UI の明暗（再利用パーツ）ここまで / End of the reusable UI theme

    // ステップボタン（再利用パーツ） / Stepper buttons (reusable)

    // -----------------------------------------
    // ステップボタンの寸法・増減量 / Stepper metrics and steps
    // -----------------------------------------
    var STEPPER_BUTTON_WIDTH   = 20;  /* ∧∨ボタンの幅 / button width */
    var STEPPER_BUTTON_HEIGHT  = 11;  /* ∧∨ボタン1つの高さ（2つ重ねた全体の高さは22） / button height (22 for the pair) */
    var STEPPER_CORNER_RADIUS  = 2;   /* 枠の角丸の半径（ScriptUIは円弧を描けないため短い線分で近似） / corner radius, approximated with segments */
    var STEPPER_FIELD_SPACING  = 3;   /* 項目名と∧∨の間隔 / spacing between the label and the stepper */
    var STEPPER_SIDE_MARGIN    = 3;   /* ∧∨の左に足す余白（右は入力欄に突き合わせる） / extra space left of the stepper */
    var STEPPER_SHIFT_MULTIPLE = 10;  /* shift＋クリックでそろえる倍数 / Shift-click snaps to multiples of this */
    var STEPPER_OPTION_STEP    = 0.1; /* option＋クリックの増減量 / Option-click step */

    /* 単位の換算は UnitValue に任せる（in / ft / yd / mm / cm / m / pt / pc / px ほか、単数形・複数形も可）。
       UnitValue に無い単位だけ、ここで UnitValue の単位に読み替える（値は「1単位＝何 unit か」）。
       「p」は「1p6」（1パイカ6ポイント）の形にも使う
       Units UnitValue lacks, mapped onto UnitValue units (how many of `unit` make one) */
    var STEPPER_UNIT_ALIASES = {
        "q": { unit: "mm", amount: 0.25 }, /* 級 / Q */
        "h": { unit: "mm", amount: 0.25 }, /* 歯 / H */
        "p": { unit: "pc", amount: 1 }     /* パイカ / pica */
    };

    // -----------------------------------------
    // ステップボタンの配色 / Stepper colors
    // -----------------------------------------
    var STEPPER_UI_DARK           = isDarkUI();
    /* UIの明るさは4段階あり、段階ごとに背景色が違う。どの段階でも背景に対する差で見せるよう、黒・白の半透明を重ねる。
       ダーク側は Illustrator 標準のスピナー（［グリッドに分割］）で実測、明るい側は最も明るい段階（背景 約0.94）から逆算
       UI brightness has four levels with different backgrounds, so colors are translucent overlays that follow the
       dialog background. Dark values are measured from Illustrator's own spinner; light values derived for the lightest level */
    var STEPPER_FILL_COLOR        = STEPPER_UI_DARK ? [0, 0, 0, 0.10]  : [1, 1, 1, 0.50];  /* 地 / background */
    var STEPPER_FRAME_COLOR       = STEPPER_UI_DARK ? [1, 1, 1, 0.07]  : [0, 0, 0, 0.10];  /* 枠線 / frame */
    var STEPPER_PRESSED_COLOR     = STEPPER_UI_DARK ? [1, 1, 1, 0.12]  : [0, 0, 0, 0.13];  /* 押下中 / pressed */
    var STEPPER_CHEVRON_COLOR     = STEPPER_UI_DARK ? [1, 1, 1, 1]     : [0, 0, 0, 0.70];  /* 山形の線 / chevron */
    var STEPPER_DIM_FILL_COLOR    = STEPPER_UI_DARK ? [1, 1, 1, 0.035] : [1, 1, 1, 0.30];  /* 無効時の地 / background when disabled */
    var STEPPER_DIM_FRAME_COLOR   = STEPPER_UI_DARK ? [1, 1, 1, 0.035] : [0, 0, 0, 0.05];  /* 無効時の枠線（ダークは地と同じで見せない） / frame when disabled */
    var STEPPER_DIM_CHEVRON_COLOR = STEPPER_UI_DARK ? [1, 1, 1, 0.20]  : [0, 0, 0, 0.25];  /* 無効時の山形 / chevron when disabled */

    // -----------------------------------------
    // 数値欄を作る（外から呼ぶ関数） / Public API
    // -----------------------------------------
    /**
     * 「項目名・∧∨・入力欄」をひと組にした数値欄を追加する。
     * ↑↓キーでも∧∨と同じように増減する。直接入力した値も、フォーカスが外れたときに
     * 整数化・下限・上限・単位（「20 mm」の形）へそろえ、数値でなければ直前の値に戻す。
     * 四則演算（+ - * / と括弧）を入れると、確定時に計算した値にする。欄と違う単位で入れた値は欄の単位へ換算する（mm の欄に「1 in」→「25.4 mm」）
     * @param {Group|Panel} parent - 追加先
     * @param {Object} fieldOptions - label（コロン込みの項目名）/ labelWidth / text / characters /
     *     step / min / max / integer（true で整数のみ）/ unit / onStep
     * @returns {EditText} 入力欄（項目名は .fieldLabel、∧∨は .stepperGroup で参照できる）
     */
    function addSteppedField(parent, fieldOptions) {
        var fieldRowGroup = parent.add("group");
        fieldRowGroup.orientation = "row";
        fieldRowGroup.alignChildren = ["left", "center"];
        fieldRowGroup.spacing = STEPPER_FIELD_SPACING;

        var fieldLabel = fieldRowGroup.add("statictext", undefined, fieldOptions.label || "");
        if (fieldOptions.labelWidth) {
            fieldLabel.preferredSize.width = fieldOptions.labelWidth;
            fieldLabel.justify = "right";
        }

        /* ∧∨と入力欄は隙間0で突き合わせる / butt the stepper against the field */
        var stepperInputGroup = fieldRowGroup.add("group");
        stepperInputGroup.orientation = "row";
        stepperInputGroup.alignChildren = ["left", "center"];
        stepperInputGroup.spacing = 0;
        stepperInputGroup.margins = 0;

        var numberInput;
        var stepperGroup = addStepper(stepperInputGroup, function () { return numberInput; }, fieldOptions);
        numberInput = stepperInputGroup.add("edittext", undefined, fieldOptions.text || "");
        numberInput.characters = fieldOptions.characters || 6;
        numberInput.fieldLabel = fieldLabel;
        numberInput.stepperGroup = stepperGroup;

        /* ↑↓キーも∧∨と同じ処理で増減する（増減量・下限・上限・単位・修飾キーをそろえる） / arrow keys share the stepper's logic */
        bindSteppedArrowKeys(numberInput, stepperGroup);

        /* 項目名のクリックで入力欄にフォーカスを移す / clicking the label focuses the field */
        fieldLabel.addEventListener("click", function () { focusNumberInput(numberInput); });

        /* 直接入力をそろえる。計算式は計算し、数値でなければ直前の値に戻す / normalize typed values; evaluate arithmetic, revert non-numbers */
        numberInput.lastValidText = numberInput.text;
        numberInput.onChange = function () {
            var value = evaluateArithmetic(numberInput.text, fieldOptions.unit);
            if (isNaN(value)) {
                numberInput.text = numberInput.lastValidText;
                return;
            }
            writeSteppedValue(numberInput, value, fieldOptions);
        };
        return numberInput;
    }

    /**
     * 数値欄の有効／無効を、項目名・∧∨ごとまとめて切り替える
     * @param {EditText} numberInput - addSteppedField() で作った入力欄
     * @param {boolean} isEnabled - 有効にするなら true
     * @returns {void}
     */
    function setSteppedFieldEnabled(numberInput, isEnabled) {
        numberInput.enabled = isEnabled;
        numberInput.fieldLabel.enabled = isEnabled;
        numberInput.stepperGroup.enabled = isEnabled;
        /* ∧∨は自作描画なので、描き直してディム表示を切り替える / redraw the custom-drawn buttons to update the dimming */
        for (var i = 0; i < numberInput.stepperGroup.children.length; i++) {
            redrawStepperGroup(numberInput.stepperGroup.children[i]);
        }
    }

    /**
     * 入力欄の値を増減する∧∨ボタンを、隙間なく縦に積んで追加する
     * @param {Group|Panel} parent - 追加先
     * @param {Function} getNumberInput - 対象の入力欄を返す関数（入力欄を∧∨より後に作れるよう、クリック時に引く）
     * @param {Object} stepOptions - step（増減量）/ min / max / integer / unit（例 " mm"）/ onStep(numberInput)
     * @returns {Group} ∧∨をまとめた group（.stepBy(direction) で同じ増減を呼べる）
     */
    function addStepper(parent, getNumberInput, stepOptions) {
        var stepperGroup = parent.add("group");
        stepperGroup.orientation = "column";
        stepperGroup.spacing = 0; /* 2つのボタンをつなげて1つの枠に見せる / join the buttons into one frame */
        stepperGroup.margins = [STEPPER_SIDE_MARGIN, 0, 0, 0]; /* 右は入力欄に突き合わせる / butt against the field on the right */
        stepperGroup.alignment = ["left", "center"];

        /**
         * 入力欄の値を増減する（shift を押しながらなら STEPPER_SHIFT_MULTIPLE の倍数へ、option なら STEPPER_OPTION_STEP ずつ。下限・上限で止める）
         * @param {number} direction - 増やすなら 1、減らすなら -1
         * @returns {void}
         */
        function stepBy(direction) {
            var numberInput = getNumberInput();
            if (!isStepperEnabledInTree(numberInput)) return; /* 入力欄か親が無効の間は動かさない */
            var value = evaluateArithmetic(numberInput.text, stepOptions.unit); /* 確定前の計算式も計算してから増減 / evaluate an uncommitted expression first */
            if (isNaN(value)) value = parseFloat(numberInput.text); /* 計算できなければ従来どおり先頭の数値 / fall back to the leading number */
            if (isNaN(value)) value = 0;
            writeSteppedValue(numberInput, computeSteppedValue(value, direction, stepOptions), stepOptions);
            if (stepOptions.onStep) stepOptions.onStep(numberInput);
        }

        /**
         * ∧∨を離したときに入力欄へフォーカスを移す（mousedown で移しても、離したときに外れる）
         * @param {Group} chevronButton - makeStepperChevronButton() で作ったボタン
         * @returns {Group} 渡したボタン
         */
        function focusInputOnRelease(chevronButton) {
            chevronButton.addEventListener("mouseup", function () {
                var numberInput = getNumberInput();
                if (isStepperEnabledInTree(numberInput)) focusNumberInput(numberInput);
            });
            return chevronButton;
        }

        /* 整数の欄では option＋クリックの0.1刻みが効かないので、説明から外す / integer fields have no 0.1 step */
        var upTooltip = stepOptions.integer ? LABELS.tooltip.stepUpInteger : LABELS.tooltip.stepUp;
        var downTooltip = stepOptions.integer ? LABELS.tooltip.stepDownInteger : LABELS.tooltip.stepDown;
        focusInputOnRelease(makeStepperChevronButton(stepperGroup, "up", function () { stepBy(1); })).helpTip = getLabel(upTooltip);
        focusInputOnRelease(makeStepperChevronButton(stepperGroup, "down", function () { stepBy(-1); })).helpTip = getLabel(downTooltip);
        stepperGroup.stepBy = stepBy; /* ↑↓キーからも同じ処理で増減できるよう公開 / shared with the arrow keys */
        stepperGroup.stepOptions = stepOptions; /* 確定時の計算で欄の単位を引けるよう公開 / lets the commit-time evaluation find the unit */
        return stepperGroup;
    }

    /**
     * 入力欄の↑↓キーを、∧∨と同じ処理で増減させる。ほかのキーは素通し。
     * あわせて、確定時に計算式・単位付きの値を計算して書き戻す（各スクリプトの onChange より先に呼ばれるので、onChange は計算後の値を読む）
     * @param {EditText} numberInput - 対象の入力欄
     * @param {Group} stepperGroup - addStepper() で作った∧∨
     * @returns {void}
     */
    function bindSteppedArrowKeys(numberInput, stepperGroup) {
        numberInput.addEventListener("keydown", function (event) {
            if (event.keyName !== "Up" && event.keyName !== "Down") return;
            stepperGroup.stepBy(event.keyName === "Up" ? 1 : -1);
            event.preventDefault(); /* カーソル移動を止める / keep the caret from moving */
        });
        numberInput.addEventListener("change", function () {
            var fieldUnit = stepperGroup.stepOptions ? stepperGroup.stepOptions.unit : undefined;
            var value = evaluateArithmetic(numberInput.text, fieldUnit);
            if (isNaN(value)) return; /* 計算できなければ各スクリプトの処理に任せる / leave it to the script's own handler */
            /* 式か、換算で値が変わったときだけ書き戻す（ただの数値は書式を崩さない） / rewrite only expressions and converted values */
            var hasOperator = /[*\/()\u00D7\u00F7\uFF0A\uFF0F\uFF08\uFF09]|[\d.\uFF10-\uFF19][^\d.\uFF10-\uFF19]*[+\-\u2212\uFF0B\uFF0D]/.test(numberInput.text);
            if (!hasOperator && value === parseFloat(numberInput.text)) return;
            numberInput.text = formatStepperNumber(value) + (fieldUnit || "");
        });
    }

    // -----------------------------------------
    // 値の計算 / Value helpers
    // -----------------------------------------
    /**
     * 押された修飾キーに応じて、1回分増減した値を返す
     * （shift なら STEPPER_SHIFT_MULTIPLE の倍数へ、option なら STEPPER_OPTION_STEP ずつ、それ以外は step の倍数へ（1.5→2、1.5→1）。
     * 整数の欄では option を無視して step の倍数へ）
     * @param {number} value - 元の値
     * @param {number} direction - 増やすなら 1、減らすなら -1
     * @param {Object} stepOptions - step（通常の増減量。省略時は 1）/ integer
     * @returns {number} 増減した値（下限・上限は未適用）
     */
    function computeSteppedValue(value, direction, stepOptions) {
        var keyState = ScriptUI.environment.keyboardState;
        if (keyState.shiftKey) return snapStepperToNextMultiple(value, STEPPER_SHIFT_MULTIPLE, direction);
        if (keyState.altKey && !stepOptions.integer) return value + direction * STEPPER_OPTION_STEP;
        return snapStepperToNextMultiple(value, stepOptions.step || 1, direction);
    }

    /**
     * 値を、指定した方向にある次の倍数へ移す（230→240、232→240、下げるときは 232→230、230→220）
     * @param {number} value - 元の値
     * @param {number} multiple - 倍数の単位（例 10）
     * @param {number} direction - 上げるなら 1、下げるなら -1
     * @returns {number} 移した値
     */
    function snapStepperToNextMultiple(value, multiple, direction) {
        /* 0.29 / 0.01 = 28.999… のような浮動小数の誤差で同じ値に戻らないよう、商を丸めてから切り捨て・切り上げる
           round the quotient first so float error (0.29 / 0.01 = 28.999…) does not step back to the same value */
        var quotient = Math.round(value / multiple * 1e6) / 1e6;
        if (direction > 0) return Math.round((Math.floor(quotient) + 1) * multiple * 1e6) / 1e6;
        return Math.round((Math.ceil(quotient) - 1) * multiple * 1e6) / 1e6;
    }

    /**
     * 値を下限・上限の範囲に収める
     * @param {number} value - 数値
     * @param {Object} rangeOptions - min / max（どちらも省略可）
     * @returns {number} 範囲に収めた値
     */
    function clampSteppedValue(value, rangeOptions) {
        if (rangeOptions.min !== undefined && value < rangeOptions.min) return rangeOptions.min;
        if (rangeOptions.max !== undefined && value > rangeOptions.max) return rangeOptions.max;
        return value;
    }

    /**
     * 入力欄の文字列を四則演算（+ - * / と括弧）として計算する。eval は使わない。
     * 数値の後ろの単位は UnitValue で欄の単位へ換算する（mm の欄に「1in」→ 25.4、「1p6」は1パイカ6ポイント）。単位のない数値は欄の単位とみなす。
     * 全角の数字・記号と × ÷ は半角に直す
     * @param {string} text - 入力欄の文字列
     * @param {string} [fieldUnit] - 欄の単位（例 " mm"。前後の空白は無視）
     * @returns {number} 欄の単位での計算結果（式として読めない・換算できない単位・0で割ったときは NaN）
     */
    function evaluateArithmetic(text, fieldUnit) {
        var source = String(text)
            .replace(/[！-～]/g, function (ch) { return String.fromCharCode(ch.charCodeAt(0) - 0xFEE0); })
            .replace(/×/g, "*")
            .replace(/÷/g, "/")
            .replace(/[−–—]/g, "-")
            .replace(/\s/g, "");
        if (source === "") return NaN;
        var fieldUnitKey = String(fieldUnit || "").replace(/^\s+|\s+$/g, "").toLowerCase();
        var fieldUnitValue = createStepperUnitValue(1, fieldUnitKey); /* 欄の単位の1単位（換算できない欄は null） / one field unit */
        var position = 0;

        /**
         * 加減算の並び（項 ± 項 …）を読む
         * @returns {number} 値（読めなければ NaN）
         */
        function readSum() {
            var total = readProduct();
            while (position < source.length && (source.charAt(position) === "+" || source.charAt(position) === "-")) {
                var operator = source.charAt(position++);
                var operand = readProduct();
                total = (operator === "+") ? total + operand : total - operand;
            }
            return total;
        }

        /**
         * 乗除算の並び（因子 × 因子 …）を読む
         * @returns {number} 値（読めなければ NaN）
         */
        function readProduct() {
            var total = readFactor();
            while (position < source.length && (source.charAt(position) === "*" || source.charAt(position) === "/")) {
                var operator = source.charAt(position++);
                var operand = readFactor();
                if (operator === "/" && operand === 0) return NaN;
                total = (operator === "*") ? total * operand : total / operand;
            }
            return total;
        }

        /**
         * 符号付きの数値（単位付きなら欄の単位へ換算）か、括弧で囲んだ式を読む
         * @returns {number} 値（読めなければ NaN）
         */
        function readFactor() {
            var ch = source.charAt(position);
            if (ch === "+" || ch === "-") {
                position++;
                var signedValue = readFactor();
                return (ch === "-") ? -signedValue : signedValue;
            }
            if (ch === "(") {
                position++;
                var innerValue = readSum();
                if (source.charAt(position) !== ")") return NaN;
                position++;
                return innerValue;
            }
            var numberMatch = /^(\d+\.?\d*|\.\d+)/.exec(source.substring(position));
            if (!numberMatch) return NaN;
            position += numberMatch[0].length;
            return readUnitSuffix(parseFloat(numberMatch[0]));
        }

        /**
         * 数値の直後の単位を読み、欄の単位へ換算する
         * @param {number} value - 単位の前の数値
         * @returns {number} 欄の単位での値（換算できない単位なら NaN）
         */
        function readUnitSuffix(value) {
            var unitMatch = /^([A-Za-z]+|%|°)/.exec(source.substring(position));
            if (!unitMatch) return value; /* 単位なしは欄の単位 / no unit means the field's unit */
            position += unitMatch[0].length;
            var unitKey = unitMatch[0].toLowerCase();
            if (unitKey === fieldUnitKey) return value;
            var typedValue = createStepperUnitValue(value, unitKey);
            if (!typedValue || !fieldUnitValue) return NaN; /* 知らない単位・単位のない欄 / unknown unit or unitless field */
            var points = typedValue.as("pt");
            /* 「1p6」＝1パイカ6ポイント / pica-point notation */
            if (unitKey === "p") {
                var pointMatch = /^(\d+\.?\d*|\.\d+)/.exec(source.substring(position));
                if (pointMatch) {
                    position += pointMatch[0].length;
                    points += parseFloat(pointMatch[0]);
                }
            }
            return points / fieldUnitValue.as("pt");
        }

        var result = readSum();
        if (position !== source.length || !isFinite(result)) return NaN; /* 読み残しがあれば式として不正 / leftovers mean a malformed expression */
        return result;
    }

    /**
     * 数値と単位から UnitValue を作る。Q・H・p は STEPPER_UNIT_ALIASES で UnitValue の単位に読み替える。
     * %（percent）は基準の長さが無いと換算できないので扱わない
     * @param {number} value - 数値
     * @param {string} unitKey - 単位（小文字。例 "mm"、"inches"、"q"）
     * @returns {UnitValue|null} UnitValue（UnitValue が知らない単位・空・% なら null）
     */
    function createStepperUnitValue(value, unitKey) {
        if (unitKey === "" || unitKey === "%") return null;
        var alias = STEPPER_UNIT_ALIASES[unitKey];
        var unitValue = alias ? new UnitValue(value * alias.amount, alias.unit) : new UnitValue(value, unitKey);
        if (unitValue.type === "?" || unitValue.type === "%") return null; /* 知らない単位は例外にならず "?" になる。"percent" も除く / unknown units become "?" */
        return unitValue;
    }

    /**
     * 値を整数化・下限・上限でそろえ、単位を付けて入力欄に書き込む（直前の正しい値としても控える）
     * @param {EditText} numberInput - 書き込む入力欄
     * @param {number} value - 数値
     * @param {Object} valueOptions - integer / min / max / unit（どれも省略可）
     * @returns {void}
     */
    function writeSteppedValue(numberInput, value, valueOptions) {
        numberInput.text = formatSteppedValue(value, valueOptions);
        numberInput.lastValidText = numberInput.text;
    }

    /**
     * 値を整数化・下限・上限でそろえ、丸めて単位を付けた表示用の文字列にする。
     * 整数化してから下限で止めるので、「整数・下限1」の欄に 0.4 が入っても 1 になる
     * @param {number} value - 数値
     * @param {Object} valueOptions - integer / min / max / unit（どれも省略可）
     * @returns {string} 入力欄に入れる文字列（例 "20 mm"）
     */
    function formatSteppedValue(value, valueOptions) {
        if (valueOptions.integer) value = Math.round(value);
        return formatStepperNumber(clampSteppedValue(value, valueOptions)) + (valueOptions.unit || "");
    }

    /**
     * 小数第2位で丸めた数値を文字列で返す
     * @param {number} value - 数値
     * @returns {string} 表示用の数値文字列
     */
    function formatStepperNumber(value) {
        return String(Math.round(value * 100) / 100);
    }

    // -----------------------------------------
    // ∧∨ボタンの描画 / Drawing
    // -----------------------------------------
    /**
     * 山形（∧／∨）の極小ボタンを作成する。
     * 上下2つを隙間なく積んで1つの枠に見えるよう、枠線は外側の辺だけ描き（上ボタンは上側、下ボタンは下側）、
     * 継ぎ目に線は引かない
     * @param {Group|Panel} parent - 追加先
     * @param {string} direction - "up" または "down"
     * @param {Function} onClickFn - クリック時の処理
     * @returns {Group} ボタンとして使う group
     */
    function makeStepperChevronButton(parent, direction, onClickFn) {
        var buttonWidth = STEPPER_BUTTON_WIDTH;
        var buttonHeight = STEPPER_BUTTON_HEIGHT;
        var isUp = (direction === "up");
        var chevronBox = parent.add("group");
        chevronBox.margins = 0;
        chevronBox.spacing = 0;
        chevronBox.preferredSize = [buttonWidth, buttonHeight];
        chevronBox.minimumSize = [buttonWidth, buttonHeight];
        chevronBox.maximumSize = [buttonWidth, buttonHeight];
        chevronBox.isPressed = false;
        chevronBox.isStepperButton = true; /* redrawSteppersIn() の目印 / marker for redrawSteppersIn() */

        chevronBox.onDraw = function () {
            var boxGraphics = chevronBox.graphics;
            /* 自作描画は自動でディムにならないため、無効なら薄い色で描く。親の無効化は子の enabled に出ないので親も見る
               Custom drawing is not dimmed automatically; the parent's state does not reach the child's enabled */
            var isDimmed = !isStepperEnabledInTree(chevronBox);

            /* 枠線の内側の地（押下中は押下色） / background inside the frame, pressed color while pressed */
            var fillColor = isDimmed ? STEPPER_DIM_FILL_COLOR : (chevronBox.isPressed ? STEPPER_PRESSED_COLOR : STEPPER_FILL_COLOR);
            boxGraphics.newPath();
            boxGraphics.rectPath(1, isUp ? 1 : 0, buttonWidth - 2, buttonHeight - 1);
            boxGraphics.fillPath(boxGraphics.newBrush(boxGraphics.BrushType.SOLID_COLOR, fillColor));

            drawStepperFrame(boxGraphics, buttonWidth, buttonHeight, isUp, isDimmed ? STEPPER_DIM_FRAME_COLOR : STEPPER_FRAME_COLOR);
            drawStepperChevron(boxGraphics, buttonWidth, buttonHeight, isUp, isDimmed ? STEPPER_DIM_CHEVRON_COLOR : STEPPER_CHEVRON_COLOR);
        };

        /**
         * 押下状態を変えて描き直す
         * @param {boolean} isPressed - 押下中なら true
         * @returns {void}
         */
        function repaint(isPressed) {
            if (chevronBox.isPressed === isPressed) return;
            chevronBox.isPressed = isPressed;
            redrawStepperGroup(chevronBox);
        }
        chevronBox.addEventListener("mousedown", function () {
            if (!isStepperEnabledInTree(chevronBox)) return;
            repaint(true);
            if (onClickFn) onClickFn();
        });
        chevronBox.addEventListener("mouseup", function () { repaint(false); });
        /* 押したまま外へ出たときも押下色を残さない / reset when the pointer leaves while pressed */
        chevronBox.addEventListener("mouseout", function () { repaint(false); });
        return chevronBox;
    }

    /**
     * 外側の辺だけの枠を描く（角は丸める）。継ぎ目側は開けておき、上下2つで1つの枠に見せる。
     * ScriptUI は円弧を描けないため、角丸は短い線分で近似する
     * @param {ScriptUIGraphics} boxGraphics - 描画先
     * @param {number} boxWidth - ボタンの幅
     * @param {number} boxHeight - ボタンの高さ
     * @param {boolean} isUp - 上のボタンなら true（上側に枠を描く）
     * @param {number[]} frameColor - [r, g, b, a]
     * @returns {void}
     */
    function drawStepperFrame(boxGraphics, boxWidth, boxHeight, isUp, frameColor) {
        var frameLeft = 0.5;
        var frameRight = boxWidth - 0.5;
        var outerY = isUp ? 0.5 : boxHeight - 0.5;
        var seamY = isUp ? boxHeight : 0;
        var towardSeam = isUp ? 1 : -1; /* 外側の辺から継ぎ目へ向かう向き / direction from the outer edge to the seam */
        var radius = STEPPER_CORNER_RADIUS;
        var arcSteps = 4; /* 角丸1つを何本の線分で近似するか / segments per corner */
        var angle, k;

        boxGraphics.newPath();
        boxGraphics.moveTo(frameLeft, seamY);
        /* 左の角丸 / left corner */
        for (k = 0; k <= arcSteps; k++) {
            angle = (Math.PI / 2) * k / arcSteps;
            boxGraphics.lineTo(frameLeft + radius - radius * Math.cos(angle), outerY + towardSeam * (radius - radius * Math.sin(angle)));
        }
        /* 右の角丸 / right corner */
        for (k = 0; k <= arcSteps; k++) {
            angle = (Math.PI / 2) * k / arcSteps;
            boxGraphics.lineTo(frameRight - radius + radius * Math.sin(angle), outerY + towardSeam * (radius - radius * Math.cos(angle)));
        }
        boxGraphics.lineTo(frameRight, seamY);
        boxGraphics.strokePath(boxGraphics.newPen(boxGraphics.PenType.SOLID_COLOR, frameColor, 1));
    }

    /**
     * 山形（∧／∨）を描く。文字グリフの▲▼は上下で大きさやベースラインが揃わないため、線で描く
     * @param {ScriptUIGraphics} boxGraphics - 描画先
     * @param {number} boxWidth - ボタンの幅
     * @param {number} boxHeight - ボタンの高さ
     * @param {boolean} isUp - ∧なら true、∨なら false
     * @param {number[]} chevronColor - [r, g, b, a]
     * @returns {void}
     */
    function drawStepperChevron(boxGraphics, boxWidth, boxHeight, isUp, chevronColor) {
        var centerX = boxWidth / 2;
        var centerY = isUp ? boxHeight / 2 + 0.5 : boxHeight / 2 - 0.5; /* 継ぎ目から少し離す / nudged away from the seam */
        var halfWidth = 3.6; /* 山形の半幅（高さ1.8に対して開き約127°） / half width of the chevron */
        var tipOffsetY = isUp ? -1.8 : 1.8; /* 頂点の中心からのずれ（上向きは上、下向きは下） */
        boxGraphics.newPath();
        boxGraphics.moveTo(centerX - halfWidth, centerY - tipOffsetY);
        boxGraphics.lineTo(centerX, centerY + tipOffsetY);
        boxGraphics.lineTo(centerX + halfWidth, centerY - tipOffsetY);
        boxGraphics.strokePath(boxGraphics.newPen(boxGraphics.PenType.SOLID_COLOR, chevronColor, 1.2));
    }

    /**
     * 入力欄にフォーカスを移す
     * @param {EditText} numberInput - 対象の入力欄
     * @returns {void}
     */
    function focusNumberInput(numberInput) {
        numberInput.active = false; /* 一度外さないとフォーカスが移らないことがある / reset first or focus may not move */
        numberInput.active = true;
    }

    /**
     * コントロールと、その親をたどってすべて有効かを返す（親の無効化は子の enabled に出ない）
     * @param {Object} control - 対象のコントロール
     * @returns {boolean} すべて有効なら true
     */
    function isStepperEnabledInTree(control) {
        for (var node = control; node; node = node.parent) {
            if (!node.enabled) return false;
        }
        return true;
    }

    /**
     * コンテナ以下にある∧∨ボタンをすべて描き直す。行やパネルの enabled を切り替えたあとに呼ぶ
     * @param {Object} container - 行・グループ・パネルなど
     * @returns {void}
     */
    function redrawSteppersIn(container) {
        if (!container.children) return;
        for (var i = 0; i < container.children.length; i++) {
            var child = container.children[i];
            if (child.isStepperButton) redrawStepperGroup(child);
            else redrawSteppersIn(child);
        }
    }

    /**
     * group の onDraw を呼び直す。group には notify() が無いため、隠して再表示して描き直させる
     * @param {Group} targetGroup - 描き直す group
     * @returns {void}
     */
    function redrawStepperGroup(targetGroup) {
        targetGroup.hide();
        targetGroup.show();
    }

    // ステップボタン（再利用パーツ）ここまで / End of the reusable stepper

    // ダイアログの位置と不透明度（再利用パーツ） / Dialog position and opacity (reusable)

    var DIALOG_OPACITY = 0.98;       /* ダイアログの不透明度 / dialog opacity */
    var DIALOG_AVOID_MARGIN = 60;    /* 選択範囲の推定位置の両側に取る余裕（px）/ margin on each side of the estimated selection (px) */
    var DIALOG_AVOID_MAX_ITEMS = 100; /* 選択範囲を測るオブジェクトの上限 / max items measured for the selection bounds */

    /**
     * ダイアログの不透明度を設定し、前回閉じた位置で開いて、動かした位置を記録するようにする。
     * 開く位置が選択中のオブジェクトに重なりそうなときは、左右の反対側へずらす（Illustrator のみ）。
     * 既存の onShow / onMove / onClose は先に呼んでから、位置の復元・記録を行う。
     * @param {Window} dialog - 対象のダイアログ
     * @param {string} storageKey - 位置を覚えるキー（ふつうは SCRIPT_NAME）
     * @returns {void}
     */
    function prepareDialogWindow(dialog, storageKey) {
        /* 同じダイアログを開き直すときは、選択範囲を測り直すだけにする（ハンドラーを重ねない）
           When the same dialog is shown again, only re-measure the selection (don't stack handlers) */
        if (dialog.dialogWindowState) {
            dialog.dialogWindowState.selectionSpan = getSelectionViewSpan();
            dialog.dialogWindowState.avoidedLocation = null;
            return;
        }
        var locationKey = "__" + storageKey + "_DialogLocation";
        var previousOnShow = dialog.onShow;
        var previousOnMove = dialog.onMove;
        var previousOnClose = dialog.onClose;
        var windowState = {
            selectionSpan: getSelectionViewSpan(), /* 選択範囲は show() の前に測る / measured before show() */
            screenWidth: null,                     /* 最初に開いたときに推定する / estimated on the first show */
            avoidedLocation: null                  /* 避けるためにずらした位置（記録しない）/ location set to avoid the selection (not remembered) */
        };
        dialog.dialogWindowState = windowState;

        dialog.opacity = DIALOG_OPACITY;

        /* 今の位置を記録する / Remember the current location */
        function rememberDialogLocation() {
            var currentLocation = [dialog.location[0], dialog.location[1]];
            var avoidedLocation = windowState.avoidedLocation;
            if (avoidedLocation && currentLocation[0] === avoidedLocation[0] && currentLocation[1] === avoidedLocation[1]) return;
            $.global[locationKey] = currentLocation;
        }

        dialog.onShow = function () {
            /* 最初に開くときの既定の位置は画面の横中央なので、画面の幅を逆算できる。2回目からは前回の位置なので使い回す
               On the first show the default location is centered horizontally, which gives the screen width; reuse it afterwards */
            if (windowState.screenWidth === null) windowState.screenWidth = dialog.location[0] * 2 + dialog.bounds.width;
            if (previousOnShow) previousOnShow.apply(this, arguments);
            /* $.screens は実際の画面の大きさと合わない（Mac で 1280×524 など）ので、画面内かは判定しない
               $.screens does not match the real display (e.g. 1280x524 on a Mac), so no on-screen check */
            var savedLocation = $.global[locationKey];
            if (savedLocation) dialog.location = [savedLocation[0], savedLocation[1]];
            if (windowState.selectionSpan) {
                var avoidLeft = findDialogLeftAvoidingSelection(dialog.location[0], dialog.bounds.width, windowState.screenWidth, windowState.selectionSpan);
                if (avoidLeft !== null) {
                    dialog.location = [avoidLeft, dialog.location[1]];
                    /* 代入後の値で比べる（丸められることがある）/ Compare with the value after assignment, which may be rounded */
                    windowState.avoidedLocation = [dialog.location[0], dialog.location[1]];
                }
            }
        };
        dialog.onMove = function () {
            if (previousOnMove) previousOnMove.apply(this, arguments);
            rememberDialogLocation();
        };
        dialog.onClose = function () {
            rememberDialogLocation();
            /* false を返すと閉じるのを取りやめるので、戻り値は元の onClose のものを返す
               Returning false cancels the close, so pass the original onClose result through */
            if (previousOnClose) return previousOnClose.apply(this, arguments);
        };
    }

    /**
     * 選択中のオブジェクトが、ドキュメントの表示域の左端から画面上で何 px の範囲にあるかを返す。
     * @returns {{left: number, right: number, viewWidth: number}|null} 選択が無い・測れないときは null
     */
    function getSelectionViewSpan() {
        try {
            if (app.name !== "Adobe Illustrator" || !app.documents.length) return null;
            var targetDoc = app.activeDocument;
            var selectedItems = targetDoc.selection;
            /* 文字ツールで文字を選択しているときは TextRange が返り、[0] が無い / Selecting characters with the Type tool returns a TextRange, which has no [0] */
            if (!selectedItems || selectedItems.typename === "TextRange" || !selectedItems.length || !selectedItems[0].visibleBounds) return null;
            var itemCount = Math.min(selectedItems.length, DIALOG_AVOID_MAX_ITEMS);
            var spanLeft = Infinity;
            var spanRight = -Infinity;
            for (var i = 0; i < itemCount; i++) {
                var itemBounds = selectedItems[i].visibleBounds;
                if (itemBounds[0] < spanLeft) spanLeft = itemBounds[0];
                if (itemBounds[2] > spanRight) spanRight = itemBounds[2];
            }
            var activeView = targetDoc.activeView; /* 複数ウィンドウで開いていても今のウィンドウ / the current window even with multiple windows */
            var viewBounds = activeView.bounds;
            var zoom = activeView.zoom;
            var viewWidth = (viewBounds[2] - viewBounds[0]) * zoom;
            /* 表示域の外にはみ出した部分は数えない / Ignore the part outside the view */
            var left = Math.max(0, (spanLeft - viewBounds[0]) * zoom);
            var right = Math.min(viewWidth, (spanRight - viewBounds[0]) * zoom);
            if (right <= left) return null;
            return { left: left, right: right, viewWidth: viewWidth };
        } catch (e) {
            /* テキスト編集中など測れないときは避けない / Do not avoid when it cannot be measured, e.g. while editing text */
            return null;
        }
    }

    /**
     * ダイアログが選択範囲に重なるなら、重ならない左端の位置を返す。
     * 表示域は画面の横中央にあるとみなし、ずれは DIALOG_AVOID_MARGIN で吸収する。
     * @param {number} dialogLeft - 今のダイアログの左端
     * @param {number} dialogWidth - ダイアログの幅
     * @param {number} screenWidth - 画面の幅
     * @param {{left: number, right: number, viewWidth: number}} selectionSpan - getSelectionViewSpan() の結果
     * @returns {number|null} ずらした左端。重ならない・どちらにも収まらないときは null
     */
    function findDialogLeftAvoidingSelection(dialogLeft, dialogWidth, screenWidth, selectionSpan) {
        var viewLeft = (screenWidth - selectionSpan.viewWidth) / 2;
        var avoidLeft = viewLeft + selectionSpan.left - DIALOG_AVOID_MARGIN;
        var avoidRight = viewLeft + selectionSpan.right + DIALOG_AVOID_MARGIN;
        if (dialogLeft + dialogWidth <= avoidLeft || dialogLeft >= avoidRight) return null;

        var leftSideLeft = avoidLeft - dialogWidth;   /* 選択範囲の左に置くとき / placed left of the selection */
        var rightSideLeft = avoidRight;               /* 選択範囲の右に置くとき / placed right of the selection */
        var fitsLeft = leftSideLeft >= 0;
        var fitsRight = rightSideLeft + dialogWidth <= screenWidth;
        /* 選択範囲が画面の右寄りなら左へ、左寄りなら右へ逃がす / Move away from the side the selection leans to */
        var preferLeft = (avoidLeft + avoidRight) / 2 > screenWidth / 2;
        if (preferLeft && fitsLeft) return leftSideLeft;
        if (fitsRight) return rightSideLeft;
        if (fitsLeft) return leftSideLeft;
        return null;
    }

    // ダイアログの位置と不透明度（再利用パーツ）ここまで / End of the reusable dialog position and opacity

    // ボタン行（再利用パーツ） / Button row (reusable)

    var BUTTON_ROW_TOP_MARGIN = 5; /* ボタン行の上の余白 / top margin of the button row */
    var BUTTON_ROW_BOTTOM_MARGIN = 14; /* ボタン行の下の余白。ダイアログの下余白と合わせて約30px（Illustrator 標準のダイアログに合わせる） / bottom margin; with the dialog margin about 30px, like Illustrator's own dialogs */
    var BUTTON_ROW_SPACING = 10;   /* ボタンどうしの間隔 / spacing between buttons */
    var BUTTON_ROW_CENTER_MAX_WIDTH = 240; /* 右のボタンだけの行を中央に置く、ダイアログの内側の最大幅（px、左右の余白を除く）。広いダイアログは右揃え / max inner dialog width (px, margins excluded) that centers a right-only row; wider dialogs keep it right-aligned */

    /**
     * ダイアログ下部のボタン行を作る。
     * 通常は「左のグループ・伸びるスペーサー・右のグループ」、centered なら行そのものを左右中央に置く
     * @param {Window|Group|Panel} parent - 行を足す先（ふつうはダイアログ）
     * @param {Object} [rowOptions] - { centered: true } で左右中央に並べる
     * @returns {{rowGroup: Group, leftGroup: Group|null, rightGroup: Group|null}} 行と左右のグループ（centered のときは左右が null）
     */
    function addButtonRow(parent, rowOptions) {
        var isCentered = !!(rowOptions && rowOptions.centered);
        var btnRowGroup = parent.add("group");
        btnRowGroup.orientation = "row";
        btnRowGroup.margins = [0, BUTTON_ROW_TOP_MARGIN, 0, BUTTON_ROW_BOTTOM_MARGIN];
        btnRowGroup.spacing = BUTTON_ROW_SPACING;

        if (isCentered) {
            btnRowGroup.alignment = ["center", "bottom"];
            btnRowGroup.alignChildren = ["center", "center"];
            return { rowGroup: btnRowGroup, leftGroup: null, rightGroup: null };
        }

        btnRowGroup.alignment = ["fill", "bottom"];

        var btnLeftGroup = btnRowGroup.add("group");
        btnLeftGroup.alignChildren = ["left", "center"];
        btnLeftGroup.spacing = BUTTON_ROW_SPACING;

        /* 余りの幅を吸って、右のグループを右端に寄せる / Absorbs the extra width so the right group sits at the right edge */
        var spacer = btnRowGroup.add("group");
        spacer.alignment = ["fill", "fill"];
        spacer.minimumSize.width = 0;

        var btnRightGroup = btnRowGroup.add("group");
        btnRightGroup.alignChildren = ["right", "center"];
        btnRightGroup.spacing = BUTTON_ROW_SPACING;

        return { rowGroup: btnRowGroup, leftGroup: btnLeftGroup, rightGroup: btnRightGroup };
    }

    /**
     * 左のグループにボタンが無い（右のボタンだけの）行を、ダイアログの幅に合わせて揃える。
     * 内側の幅（左右の余白を除く）が BUTTON_ROW_CENTER_MAX_WIDTH 以下なら左右中央、それより広ければ右揃えのまま。
     * 幅はレイアウトが決まるまで分からないので、ダイアログを表示した時点（show イベント）で判定する。
     * ボタンをすべて足したあと、show() の前に呼ぶ。centered で作った行や、左にボタンがある行はそのまま
     * @param {{rowGroup: Group, leftGroup: Group|null, rightGroup: Group|null}} buttonRow - addButtonRow() の戻り値
     * @returns {void}
     */
    function alignRightOnlyButtonRow(buttonRow) {
        if (!buttonRow.leftGroup || buttonRow.leftGroup.children.length > 0) return;
        var dialogWindow = buttonRow.rowGroup.window;
        dialogWindow.addEventListener("show", function () {
            if (!buttonRow.leftGroup) return;
            var btnRowGroup = buttonRow.rowGroup;
            /* 行の幅＝ダイアログの内側の幅（左右の余白を除く）/ The row spans the dialog's inner width (margins excluded) */
            if (!btnRowGroup.size || btnRowGroup.size.width > BUTTON_ROW_CENTER_MAX_WIDTH) return;
            /* 左のグループとスペーサーを外し、右のグループだけを中央に置く / Drop the left group and the spacer so only the right group remains, centered */
            btnRowGroup.remove(buttonRow.leftGroup);
            btnRowGroup.remove(btnRowGroup.children[0]); /* 左のグループを外すと先頭はスペーサー / the spacer is first once the left group is gone */
            btnRowGroup.alignment = ["center", "bottom"];
            btnRowGroup.alignChildren = ["center", "center"];
            buttonRow.leftGroup = null;
            dialogWindow.layout.layout(true);
        });
    }

    // ボタン行（再利用パーツ）ここまで / End of the reusable button row

    // =========================================
    // ローカライズ / Localization
    // =========================================

    // ローカライズ（再利用パーツ） / Localization (reusable)

    /**
     * UI の言語を返す（"ja" で始まるロケールは日本語、それ以外は英語）
     * @returns {string} "ja" または "en"
     */
    function getCurrentLang() {
        return (String($.locale || "").indexOf("ja") === 0) ? "ja" : "en";
    }

    var uiLang = getCurrentLang();

    /**
     * LABELS から今の UI 言語の文言を取り出す。
     * @param {string|Object} labelRef - "dialog.title" のようなパス、または { ja, en }
     * @param {Object|Array} [placeholderValues] - { name: 値 } なら {name} を、[値, …] なら %1, %2 … を差し込む
     * @returns {string} 文言。パスが見つからなければパスの文字列、{ ja, en } が無ければ空文字
     */
    function getLabel(labelRef, placeholderValues) {
        var labelEntry = labelRef;
        if (typeof labelRef === "string") {
            var labelPathKeys = labelRef.split(".");
            labelEntry = LABELS;
            for (var i = 0; i < labelPathKeys.length && labelEntry != null; i++) {
                labelEntry = labelEntry[labelPathKeys[i]];
            }
        }
        var labelString;
        if (typeof labelEntry === "string") labelString = labelEntry;
        else if (labelEntry != null && labelEntry[uiLang] != null) labelString = labelEntry[uiLang];
        else if (labelEntry != null && labelEntry.en != null) labelString = labelEntry.en;
        else return (typeof labelRef === "string") ? labelRef : "";
        return fillLabelPlaceholders(String(labelString), placeholderValues);
    }

    /**
     * 項目名の文言の末尾にコロンを付ける（日本語は半角スペース＋半角コロン「 :」、英語は「:」。Illustrator の線パネルなどの項目名に合わせる）
     * @param {string|Object} labelRef - getLabel と同じ
     * @param {Object|Array} [placeholderValues] - getLabel と同じ
     * @returns {string} コロン付きの文言
     */
    function labelText(labelRef, placeholderValues) {
        return getLabel(labelRef, placeholderValues) + (uiLang === "ja" ? " :" : ":");
    }

    /**
     * 「項目名 : 値」の1行を返す（日本語は「件数 : 5」、英語は「Count: 5」。どちらもコロンのあとに空白を入れる）
     * @param {string|Object} labelRef - getLabel と同じ
     * @param {string|number} value - コロンのあとに続ける値
     * @returns {string} 項目名と値をつないだ文字列
     */
    function labelValueText(labelRef, value) {
        return labelText(labelRef) + " " + value;
    }

    /**
     * 文言の {name} や %1 に値を差し込む
     * @param {string} labelString - 文言
     * @param {Object|Array} [placeholderValues] - { name: 値 } または [値, …]
     * @returns {string} 差し込んだ文言
     */
    function fillLabelPlaceholders(labelString, placeholderValues) {
        if (placeholderValues == null) return labelString;
        if (placeholderValues instanceof Array) {
            /* 大きい番号から置き換え、%1 が %10 の一部を置き換えないようにする / Replace from the highest index so %1 does not eat into %10 */
            for (var i = placeholderValues.length; i >= 1; i--) {
                labelString = labelString.split("%" + i).join(String(placeholderValues[i - 1]));
            }
            return labelString;
        }
        for (var placeholderKey in placeholderValues) {
            if (!placeholderValues.hasOwnProperty(placeholderKey)) continue;
            labelString = labelString.split("{" + placeholderKey + "}").join(String(placeholderValues[placeholderKey]));
        }
        return labelString;
    }

    // ローカライズ（再利用パーツ）ここまで / End of the reusable localization

    var LABELS = {
        radio: {
            white: { ja: "ホワイト", en: "White" },
            black: { ja: "ブラック", en: "Black" },
            custom: { ja: "カスタム", en: "Custom" }
        },
        checkbox: {
            gray: { ja: "グレー", en: "Gray" }
        },
        button: {
            cancel: { ja: "キャンセル", en: "Cancel" },
            ok: { ja: "OK", en: "OK" }
        },
        tooltip: {
            slider: {
                ja: "この成分の値をドラッグで決めます。右の欄に直接入力もできます。",
                en: "Drag to set this component. You can also type into the field on the right."
            },
            preset: {
                ja: "よく使う色をすぐ選べます。「カスタム」で自由に指定できます。",
                en: "Picks a common color. Custom lets you set any value."
            },
            hex: { ja: "色を16進数で指定します（例: FF0000）。", en: "Color as a hex value, for example FF0000." },
            gray: { ja: "CMYKのK版だけで色を作ります（グレースケール）。", en: "Builds the color from the K plate only, giving a grayscale." },
            swatch: { ja: "クリックすると、この色をRGBで設定します。", en: "Click to set this color as RGB." },
            previewBefore: { ja: "元の色です。", en: "The original color." },
            previewAfter: { ja: "現在指定している色です。", en: "The color currently set." },
            /* ステップボタン用 / for the stepper */
            stepUp: {
                ja: "値を増やす（shift＋クリックで10の倍数へ、option＋クリックで0.1ずつ）",
                en: "Increase (Shift-click to snap to 10s, Option-click by 0.1)"
            },
            stepDown: {
                ja: "値を減らす（shift＋クリックで10の倍数へ、option＋クリックで0.1ずつ）",
                en: "Decrease (Shift-click to snap to 10s, Option-click by 0.1)"
            },
            stepUpInteger: { ja: "値を増やす（shift＋クリックで10の倍数へ）", en: "Increase (Shift-click to snap to 10s)" },
            stepDownInteger: { ja: "値を減らす（shift＋クリックで10の倍数へ）", en: "Decrease (Shift-click to snap to 10s)" }
        }
    };

    // =========================================
    // 色の変換 / Color conversion
    // =========================================

    /**
     * CMYK の色文字列（"cmyk:C,M,Y,K"）かどうかを返す
     * @param {string} colorString - 色文字列
     * @returns {boolean} CMYK の色文字列なら true
     */
    function isCmykString(colorString) {
        return String(colorString).indexOf("cmyk:") === 0;
    }

    /**
     * "cmyk:C,M,Y,K" を成分ごとの数値に分ける（数値でない成分は 0）
     * @param {string} colorString - CMYK の色文字列
     * @returns {{c: number, m: number, y: number, k: number}} CMYK の各成分
     */
    function parseCmykString(colorString) {
        var cmykParts = String(colorString).replace("cmyk:", "").split(",");
        return {
            c: Number(cmykParts[0]) || 0,
            m: Number(cmykParts[1]) || 0,
            y: Number(cmykParts[2]) || 0,
            k: Number(cmykParts[3]) || 0
        };
    }

    /**
     * CMYK の各成分を丸めて "cmyk:C,M,Y,K" にする
     * @param {number} c - シアン（0〜100）
     * @param {number} m - マゼンタ（0〜100）
     * @param {number} y - イエロー（0〜100）
     * @param {number} k - ブラック（0〜100）
     * @returns {string} CMYK の色文字列
     */
    function cmykStringFromValues(c, m, y, k) {
        return "cmyk:" + Math.round(c) + "," + Math.round(m) + "," + Math.round(y) + "," + Math.round(k);
    }

    /**
     * RGB の各成分を "RRGGBB"（大文字の16進数）にする
     * @param {number} r - レッド（0〜255）
     * @param {number} g - グリーン（0〜255）
     * @param {number} b - ブルー（0〜255）
     * @returns {string} 16進数の色文字列
     */
    function rgbToHex(r, g, b) {
        /**
         * 0〜255 の値を2桁の16進数にする
         * @param {number} channelValue - 成分の値
         * @returns {string} 2桁の16進数（大文字）
         */
        function toHexByte(channelValue) {
            var hexText = Math.round(channelValue).toString(16).toUpperCase();
            return hexText.length < 2 ? "0" + hexText : hexText;
        }
        return toHexByte(r) + toHexByte(g) + toHexByte(b);
    }

    /**
     * "RRGGBB"（先頭の # は可）を RGB の各成分にする。6桁でなければ黒
     * @param {string} hex - 16進数の色文字列
     * @returns {{r: number, g: number, b: number}} RGB の各成分
     */
    function hexToRGB(hex) {
        hex = String(hex || "").replace(/^#/, "");
        if (hex.length !== 6) hex = "000000";
        return {
            r: parseInt(hex.substring(0, 2), 16) || 0,
            g: parseInt(hex.substring(2, 4), 16) || 0,
            b: parseInt(hex.substring(4, 6), 16) || 0
        };
    }

    /**
     * CMYK を RGB に簡易変換する（カラープロファイルは使わない）
     * @param {number} c - シアン（0〜100）
     * @param {number} m - マゼンタ（0〜100）
     * @param {number} y - イエロー（0〜100）
     * @param {number} k - ブラック（0〜100）
     * @returns {{r: number, g: number, b: number}} RGB の各成分（整数）
     */
    function cmykToRgbApprox(c, m, y, k) {
        var r = 255 * (1 - c / 100) * (1 - k / 100);
        var g = 255 * (1 - m / 100) * (1 - k / 100);
        var b = 255 * (1 - y / 100) * (1 - k / 100);
        return {
            r: Math.round(r),
            g: Math.round(g),
            b: Math.round(b)
        };
    }

    /**
     * RGB を CMYK に簡易変換する（カラープロファイルは使わない）
     * @param {number} r - レッド（0〜255）
     * @param {number} g - グリーン（0〜255）
     * @param {number} b - ブルー（0〜255）
     * @returns {{c: number, m: number, y: number, k: number}} CMYK の各成分（整数）
     */
    function rgbToCmykApprox(r, g, b) {
        var redRatio = r / 255;
        var greenRatio = g / 255;
        var blueRatio = b / 255;
        var k = 1 - Math.max(redRatio, greenRatio, blueRatio);

        if (k >= 1) {
            return { c: 0, m: 0, y: 0, k: 100 };
        }

        var c = (1 - redRatio - k) / (1 - k) * 100;
        var m = (1 - greenRatio - k) / (1 - k) * 100;
        var y = (1 - blueRatio - k) / (1 - k) * 100;

        return {
            c: Math.round(c),
            m: Math.round(m),
            y: Math.round(y),
            k: Math.round(k * 100)
        };
    }

    /**
     * 値を数値にして範囲内に収める（数値でなければ 0）
     * @param {*} value - 元の値（入力欄の文字列など）
     * @param {number} min - 下限
     * @param {number} max - 上限
     * @returns {number} 範囲内の数値
     */
    function clamp(value, min, max) {
        var clampedValue = Number(value);
        if (isNaN(clampedValue)) clampedValue = 0;
        if (clampedValue < min) clampedValue = min;
        if (clampedValue > max) clampedValue = max;
        return clampedValue;
    }

    // =========================================
    // ピッカーの状態 / Picker state
    // =========================================

    /**
     * 初期値の色文字列からピッカーの状態を作る
     * @param {string} initialValue - "RRGGBB" または "cmyk:C,M,Y,K"
     * @returns {Object} ピッカーの状態（preset / mode / dialogTab / rgb / cmyk / original）
     */
    function createInitialState(initialValue) {
        var state = {
            preset: "custom",   /* white | black | custom */
            mode: "rgb",        /* rgb | cmyk | gray */
            dialogTab: "rgb",   /* rgb | cmyk */
            rgb: { r: 0, g: 0, b: 0 },
            cmyk: { c: 0, m: 0, y: 0, k: 0 },
            original: { r: 0, g: 0, b: 0 }
        };

        if (isCmykString(initialValue)) {
            var cmykValues = parseCmykString(initialValue);
            var convertedRgb = cmykToRgbApprox(cmykValues.c, cmykValues.m, cmykValues.y, cmykValues.k);
            state.cmyk = { c: cmykValues.c, m: cmykValues.m, y: cmykValues.y, k: cmykValues.k };
            state.rgb = { r: convertedRgb.r, g: convertedRgb.g, b: convertedRgb.b };
            state.original = { r: convertedRgb.r, g: convertedRgb.g, b: convertedRgb.b };
            state.dialogTab = "cmyk";
            state.mode = (cmykValues.c === 0 && cmykValues.m === 0 && cmykValues.y === 0 && cmykValues.k > 0) ? "gray" : "cmyk";

            if (cmykValues.c === 0 && cmykValues.m === 0 && cmykValues.y === 0 && cmykValues.k === 0) state.preset = "white";
            else if (cmykValues.c === 0 && cmykValues.m === 0 && cmykValues.y === 0 && cmykValues.k === 100) state.preset = "black";
        } else {
            var initialRgb = hexToRGB(initialValue || "000000");
            state.rgb = { r: initialRgb.r, g: initialRgb.g, b: initialRgb.b };
            state.original = { r: initialRgb.r, g: initialRgb.g, b: initialRgb.b };
            state.cmyk = rgbToCmykApprox(initialRgb.r, initialRgb.g, initialRgb.b);
            state.dialogTab = "rgb";
            state.mode = "rgb";

            if (initialRgb.r === 255 && initialRgb.g === 255 && initialRgb.b === 255) state.preset = "white";
            else if (initialRgb.r === 0 && initialRgb.g === 0 && initialRgb.b === 0) state.preset = "black";
        }

        return state;
    }

    /**
     * RGB の値から CMYK の値を計算し直す
     * @param {Object} state - ピッカーの状態
     * @returns {void}
     */
    function syncCmykFromRgb(state) {
        state.cmyk = rgbToCmykApprox(
            Math.round(state.rgb.r),
            Math.round(state.rgb.g),
            Math.round(state.rgb.b)
        );
    }

    /**
     * CMYK の値から RGB の値を計算し直す
     * @param {Object} state - ピッカーの状態
     * @returns {void}
     */
    function syncRgbFromCmyk(state) {
        var convertedRgb = cmykToRgbApprox(state.cmyk.c, state.cmyk.m, state.cmyk.y, state.cmyk.k);
        state.rgb = { r: convertedRgb.r, g: convertedRgb.g, b: convertedRgb.b };
    }

    /**
     * プレビューに塗る RGB を返す
     * @param {Object} state - ピッカーの状態
     * @returns {{r: number, g: number, b: number}} プレビューの色
     */
    function getPreviewRgb(state) {
        if (state.preset === "white") return { r: 255, g: 255, b: 255 };
        if (state.preset === "black") return { r: 0, g: 0, b: 0 };
        if (state.mode === "cmyk" || state.mode === "gray") {
            return cmykToRgbApprox(state.cmyk.c, state.cmyk.m, state.cmyk.y, state.cmyk.k);
        }
        return { r: state.rgb.r, g: state.rgb.g, b: state.rgb.b };
    }

    /**
     * ピッカーの状態を戻り値の色文字列にする
     * @param {Object} state - ピッカーの状態
     * @returns {string} "RRGGBB" または "cmyk:C,M,Y,K"
     */
    function serializeState(state) {
        if (state.preset === "white") return "FFFFFF";
        if (state.preset === "black") return "000000";
        if (state.mode === "cmyk" || state.mode === "gray") {
            return cmykStringFromValues(state.cmyk.c, state.cmyk.m, state.cmyk.y, state.cmyk.k);
        }
        return rgbToHex(state.rgb.r, state.rgb.g, state.rgb.b);
    }

    // =========================================
    // ダイアログ / Dialog
    // =========================================

    /**
     * コントロール全体を RGB の色で塗る（onDraw の中で呼ぶ）
     * @param {Object} targetControl - 塗るコントロール
     * @param {{r: number, g: number, b: number}} rgb - 塗る色
     * @returns {void}
     */
    function fillControlWithRgb(targetControl, rgb) {
        var controlGraphics = targetControl.graphics;
        var fillBrush = controlGraphics.newBrush(controlGraphics.BrushType.SOLID_COLOR, [rgb.r / 255, rgb.g / 255, rgb.b / 255, 1]);
        controlGraphics.rectPath(0, 0, targetControl.size[0], targetControl.size[1]);
        controlGraphics.fillPath(fillBrush);
    }

    /**
     * ラベル＋スライダー＋数値欄の1行を追加する（連動は bindPickerEvents() で付ける）
     * @param {Group|Tab} parentContainer - 追加先
     * @param {string} channelName - 成分名（"R" など）
     * @param {number} initialValue - 初期値
     * @param {number} maxValue - 上限値
     * @returns {{row: Group, slider: Slider, valueInput: EditText}} 生成した行と部品
     */
    function addChannelRow(parentContainer, channelName, initialValue, maxValue) {
        var channelRow = parentContainer.add("group");
        channelRow.orientation = "row";
        channelRow.alignChildren = ["left", "center"];

        var channelLabel = channelRow.add("statictext", undefined, channelName);
        channelLabel.preferredSize = [18, -1];

        var channelSlider = channelRow.add("slider", undefined, initialValue, 0, maxValue);
        channelSlider.helpTip = getLabel("tooltip.slider");
        /* ∧∨を足した分だけ縮めて、ダイアログの幅を保つ / shortened by the stepper's width to keep the dialog width */
        channelSlider.preferredSize = [117, 20];

        /* ∧∨と入力欄は隙間0で突き合わせる / butt the stepper against the field */
        var stepperInputGroup = channelRow.add("group");
        stepperInputGroup.orientation = "row";
        stepperInputGroup.alignChildren = ["left", "center"];
        stepperInputGroup.spacing = 0;
        stepperInputGroup.margins = 0;

        var valueInput;
        /* 範囲への収め込みとスライダー連動は、手入力と同じ onChange（bindChannelRow() で結線）に任せる
           clamping and slider sync run through the same onChange as typing */
        var stepperGroup = addStepper(stepperInputGroup, function () { return valueInput; }, {
            integer: true,
            onStep: function (numberInput) { if (numberInput.onChange) numberInput.onChange(); }
        });
        valueInput = stepperInputGroup.add("edittext", undefined, String(Math.round(initialValue)));
        valueInput.helpTip = getLabel("tooltip.slider");
        valueInput.characters = 3;
        /* ↑↓キーも∧∨と同じ処理で増減する / arrow keys share the stepper's logic */
        bindSteppedArrowKeys(valueInput, stepperGroup);

        return {
            row: channelRow,
            slider: channelSlider,
            valueInput: valueInput
        };
    }

    /**
     * 元の色と現在の色を並べるプレビュー行を追加する
     * @param {Window} pickerDialog - ダイアログ
     * @param {Object} state - ピッカーの状態
     * @returns {Group} 現在の色のプレビュー（再描画用）
     */
    function addPreviewRow(pickerDialog, state) {
        var previewRow = pickerDialog.add("group");
        previewRow.orientation = "row";
        previewRow.alignment = ["center", "top"];
        previewRow.spacing = 1;

        var previewBefore = previewRow.add("group");
        previewBefore.preferredSize = [90, 40];
        previewBefore.helpTip = getLabel("tooltip.previewBefore");

        var previewAfter = previewRow.add("group");
        previewAfter.preferredSize = [90, 40];
        previewAfter.helpTip = getLabel("tooltip.previewAfter");

        previewBefore.onDraw = function () {
            fillControlWithRgb(this, state.original);
        };

        previewAfter.onDraw = function () {
            fillControlWithRgb(this, getPreviewRgb(state));
        };
        return previewAfter;
    }

    /**
     * よく使う色のスウォッチ行を追加する
     * @param {Window} pickerDialog - ダイアログ
     * @returns {Object[]} スウォッチ（element: Group、hex: 色）の配列
     */
    function addSwatchRow(pickerDialog) {
        var swatchRow = pickerDialog.add("group");
        swatchRow.orientation = "row";
        swatchRow.alignment = ["center", "top"];
        swatchRow.spacing = 2;
        var swatchItems = [];
        for (var i = 0; i < DEFAULT_SWATCHES.length; i++) {
            (function (swatchHex) {
                var swatchRgb = hexToRGB(swatchHex);
                var swatchGroup = swatchRow.add("group");
                swatchGroup.preferredSize = [16, 16];
                swatchGroup.helpTip = getLabel("tooltip.swatch");
                swatchGroup.onDraw = function () {
                    var swatchGraphics = this.graphics;
                    var borderPen = swatchGraphics.newPen(swatchGraphics.PenType.SOLID_COLOR, [0, 0, 0, 1], 1);
                    fillControlWithRgb(this, swatchRgb);
                    swatchGraphics.rectPath(0, 0, this.size[0], this.size[1]);
                    swatchGraphics.strokePath(borderPen);
                };
                swatchItems.push({ element: swatchGroup, hex: swatchHex });
            })(DEFAULT_SWATCHES[i]);
        }
        return swatchItems;
    }

    /**
     * ピッカーのダイアログを組み立てる
     * @param {Object} state - ピッカーの状態
     * @param {string} dialogTitle - ダイアログのタイトル
     * @returns {Object} ダイアログと各コントロールの参照
     */
    function buildPickerDialog(state, dialogTitle) {
        var pickerDialog = new Window("dialog", dialogTitle || "Color Picker");
        setupWindow(pickerDialog);

        var previewAfter = addPreviewRow(pickerDialog, state);

        var presetRow = pickerDialog.add("group");
        presetRow.orientation = "row";
        presetRow.alignment = ["center", "top"];
        presetRow.alignChildren = ["left", "center"];
        var whiteRadio = presetRow.add("radiobutton", undefined, getLabel("radio.white"));
        whiteRadio.helpTip = getLabel("tooltip.preset");
        var blackRadio = presetRow.add("radiobutton", undefined, getLabel("radio.black"));
        blackRadio.helpTip = getLabel("tooltip.preset");
        var customRadio = presetRow.add("radiobutton", undefined, getLabel("radio.custom"));
        customRadio.helpTip = getLabel("tooltip.preset");

        var swatchItems = addSwatchRow(pickerDialog);

        var colorTabs = pickerDialog.add("tabbedpanel");
        colorTabs.alignChildren = ["fill", "top"];

        var tabRGB = colorTabs.add("tab", undefined, "RGB");
        setupTab(tabRGB);

        var tabCMYK = colorTabs.add("tab", undefined, "CMYK");
        setupTab(tabCMYK);

        var redRow = addChannelRow(tabRGB, "R", state.rgb.r, 255);
        var greenRow = addChannelRow(tabRGB, "G", state.rgb.g, 255);
        var blueRow = addChannelRow(tabRGB, "B", state.rgb.b, 255);

        tabRGB.add("panel").preferredSize.height = 10; /* 区切り線 / divider */

        var hexRow = tabRGB.add("group");
        hexRow.orientation = "row";
        hexRow.alignChildren = ["left", "center"];
        hexRow.add("statictext", undefined, "#");
        var hexInput = hexRow.add("edittext", undefined, rgbToHex(state.rgb.r, state.rgb.g, state.rgb.b));
        hexInput.helpTip = getLabel("tooltip.hex");
        hexInput.characters = 6;

        var grayCheckbox = tabCMYK.add("checkbox", undefined, getLabel("checkbox.gray"));
        grayCheckbox.helpTip = getLabel("tooltip.gray");
        var cyanRow = addChannelRow(tabCMYK, "C", state.cmyk.c, 100);
        var magentaRow = addChannelRow(tabCMYK, "M", state.cmyk.m, 100);
        var yellowRow = addChannelRow(tabCMYK, "Y", state.cmyk.y, 100);
        var blackRow = addChannelRow(tabCMYK, "K", state.cmyk.k, 100);

        /* ボタン行（左右中央） / Button row (centered) */
        var buttonRow = addButtonRow(pickerDialog);
        var btnCancel = buttonRow.rightGroup.add("button", undefined, getLabel("button.cancel"), { name: "cancel" });
        var btnOK = buttonRow.rightGroup.add("button", undefined, getLabel("button.ok"), { name: "ok" });
        alignRightOnlyButtonRow(buttonRow);

        return {
            dialog: pickerDialog,
            previewAfter: previewAfter,
            whiteRadio: whiteRadio,
            blackRadio: blackRadio,
            customRadio: customRadio,
            colorTabs: colorTabs,
            tabRGB: tabRGB,
            tabCMYK: tabCMYK,
            grayCheckbox: grayCheckbox,
            redRow: redRow,
            greenRow: greenRow,
            blueRow: blueRow,
            cyanRow: cyanRow,
            magentaRow: magentaRow,
            yellowRow: yellowRow,
            blackRow: blackRow,
            hexInput: hexInput,
            swatchItems: swatchItems
        };
    }

    /**
     * 成分の行のスライダーと数値欄に値を入れる
     * @param {Object} channelRow - addChannelRow() の戻り値
     * @param {number} channelValue - 値
     * @returns {void}
     */
    function setChannelRowValue(channelRow, channelValue) {
        channelRow.slider.value = channelValue;
        channelRow.valueInput.text = String(channelValue);
    }

    /**
     * ピッカーの状態をダイアログに反映する
     * @param {Object} state - ピッカーの状態
     * @param {Object} pickerControls - buildPickerDialog() の戻り値
     * @param {Object} [renderOptions] - suppressTabSelection: true でタブを切り替えない
     * @returns {void}
     */
    function renderPickerState(state, pickerControls, renderOptions) {
        renderOptions = renderOptions || {};
        var suppressTabSelection = !!renderOptions.suppressTabSelection;

        pickerControls.whiteRadio.value = (state.preset === "white");
        pickerControls.blackRadio.value = (state.preset === "black");
        pickerControls.customRadio.value = (state.preset === "custom");

        if (!suppressTabSelection) {
            var targetTab = (state.dialogTab === "cmyk") ? pickerControls.tabCMYK : pickerControls.tabRGB;
            /* タブの切り替えに失敗しても表示の更新は続ける / keep rendering even if the tab switch fails */
            try {
                if (pickerControls.colorTabs.selection !== targetTab) {
                    pickerControls.colorTabs.selection = targetTab;
                }
            } catch (eTab) {}
        }

        pickerControls.grayCheckbox.value = (state.mode === "gray");

        setChannelRowValue(pickerControls.redRow, state.rgb.r);
        setChannelRowValue(pickerControls.greenRow, state.rgb.g);
        setChannelRowValue(pickerControls.blueRow, state.rgb.b);
        pickerControls.hexInput.text = rgbToHex(state.rgb.r, state.rgb.g, state.rgb.b);

        setChannelRowValue(pickerControls.cyanRow, state.cmyk.c);
        setChannelRowValue(pickerControls.magentaRow, state.cmyk.m);
        setChannelRowValue(pickerControls.yellowRow, state.cmyk.y);
        setChannelRowValue(pickerControls.blackRow, state.cmyk.k);

        var customEnabled = (state.preset === "custom");
        var colorChannelsEnabled = customEnabled && state.mode !== "gray";
        /* ∧∨の描き直しは有効／無効が変わったときだけ（スライダーのドラッグ中に毎回描き直さない）
           redraw the steppers only when the enabled state changes, not on every slider move */
        var enabledChanged = (pickerControls.colorTabs.enabled !== customEnabled) ||
            (pickerControls.cyanRow.row.enabled !== colorChannelsEnabled);
        pickerControls.colorTabs.enabled = customEnabled;
        pickerControls.cyanRow.row.enabled = colorChannelsEnabled;
        pickerControls.magentaRow.row.enabled = colorChannelsEnabled;
        pickerControls.yellowRow.row.enabled = colorChannelsEnabled;
        if (enabledChanged) redrawSteppersIn(pickerControls.colorTabs);

        /* 隠して出し直すことでプレビューを再描画させる / hide and show to force a redraw of the preview */
        try { pickerControls.previewAfter.hide(); pickerControls.previewAfter.show(); } catch (ePreview) {}
    }

    /**
     * ダイアログの各コントロールに、状態の更新と再描画のイベントを付ける
     * @param {Object} state - ピッカーの状態
     * @param {Object} pickerControls - buildPickerDialog() の戻り値
     * @returns {void}
     */
    function bindPickerEvents(state, pickerControls) {
        var isRendering = false;

        /**
         * 表示を更新する（更新中に呼ばれた onChange などからの再入は無視する）
         * @param {Object} [renderOptions] - renderPickerState() に渡すオプション
         * @returns {void}
         */
        function safeRender(renderOptions) {
            if (isRendering) return;
            isRendering = true;
            try {
                renderPickerState(state, pickerControls, renderOptions);
            } finally {
                isRendering = false;
            }
        }

        /**
         * ホワイト／ブラック／カスタムを切り替え、色の値をそろえる
         * @param {string} nextPreset - "white" / "black" / "custom"
         * @returns {void}
         */
        function applyPreset(nextPreset) {
            state.preset = nextPreset;

            if (nextPreset === "white") {
                state.rgb = { r: 255, g: 255, b: 255 };
                syncCmykFromRgb(state);
                if (state.dialogTab !== "cmyk") state.mode = "rgb";
            } else if (nextPreset === "black") {
                state.rgb = { r: 0, g: 0, b: 0 };
                syncCmykFromRgb(state);
                if (state.dialogTab !== "cmyk") state.mode = "rgb";
            } else {
                if (state.dialogTab === "cmyk") {
                    if (state.mode !== "gray") state.mode = "cmyk";
                    syncRgbFromCmyk(state);
                } else {
                    state.mode = "rgb";
                    syncCmykFromRgb(state);
                }
            }
        }

        /**
         * RGB の値を設定し、CMYK も計算し直して「カスタム」の RGB 指定にする
         * @param {number} r - レッド（0〜255）
         * @param {number} g - グリーン（0〜255）
         * @param {number} b - ブルー（0〜255）
         * @returns {void}
         */
        function setRgb(r, g, b) {
            state.rgb.r = Math.round(clamp(r, 0, 255));
            state.rgb.g = Math.round(clamp(g, 0, 255));
            state.rgb.b = Math.round(clamp(b, 0, 255));
            syncCmykFromRgb(state);
            state.mode = "rgb";
            state.dialogTab = "rgb";
            state.preset = "custom";
        }

        /**
         * CMYK の値を設定し、RGB も計算し直して「カスタム」の CMYK 指定にする
         * @param {number} c - シアン（0〜100）
         * @param {number} m - マゼンタ（0〜100）
         * @param {number} y - イエロー（0〜100）
         * @param {number} k - ブラック（0〜100）
         * @param {boolean} keepGray - グレー（K のみ）のままにするなら true
         * @returns {void}
         */
        function setCmyk(c, m, y, k, keepGray) {
            state.cmyk.c = Math.round(clamp(c, 0, 100));
            state.cmyk.m = Math.round(clamp(m, 0, 100));
            state.cmyk.y = Math.round(clamp(y, 0, 100));
            state.cmyk.k = Math.round(clamp(k, 0, 100));
            syncRgbFromCmyk(state);
            state.mode = keepGray ? "gray" : "cmyk";
            state.dialogTab = "cmyk";
            state.preset = "custom";
        }

        /**
         * RGB のスライダーの値を状態に入れる
         * @returns {void}
         */
        function applyRgbSliders() {
            setRgb(pickerControls.redRow.slider.value, pickerControls.greenRow.slider.value, pickerControls.blueRow.slider.value);
        }

        /**
         * CMYK のスライダーの値を状態に入れる
         * @returns {void}
         */
        function applyCmykSliders() {
            setCmyk(pickerControls.cyanRow.slider.value, pickerControls.magentaRow.slider.value,
                pickerControls.yellowRow.slider.value, pickerControls.blackRow.slider.value, pickerControls.grayCheckbox.value);
        }

        /**
         * スライダーと数値欄を連動させ、変更のたびに状態を更新する
         * @param {Object} channelRow - addChannelRow() の戻り値
         * @param {number} maxValue - 上限値
         * @param {Function} applyChannelValues - スライダーの値を状態に入れる関数
         * @returns {void}
         */
        function bindChannelRow(channelRow, maxValue, applyChannelValues) {
            channelRow.slider.onChanging = function () {
                channelRow.valueInput.text = String(Math.round(channelRow.slider.value));
                applyChannelValues();
                safeRender();
            };
            channelRow.valueInput.onChange = function () {
                channelRow.slider.value = clamp(channelRow.valueInput.text, 0, maxValue);
                channelRow.valueInput.text = String(Math.round(channelRow.slider.value));
                applyChannelValues();
                safeRender();
            };
        }

        var rgbRows = [pickerControls.redRow, pickerControls.greenRow, pickerControls.blueRow];
        for (var i = 0; i < rgbRows.length; i++) {
            bindChannelRow(rgbRows[i], 255, applyRgbSliders);
        }

        var cmykRows = [pickerControls.cyanRow, pickerControls.magentaRow, pickerControls.yellowRow, pickerControls.blackRow];
        for (var j = 0; j < cmykRows.length; j++) {
            bindChannelRow(cmykRows[j], 100, applyCmykSliders);
        }

        pickerControls.hexInput.onChange = function () {
            var hexText = String(pickerControls.hexInput.text).replace(/^#/, "");
            if (hexText.length !== 6) return;
            var enteredRgb = hexToRGB(hexText);
            setRgb(enteredRgb.r, enteredRgb.g, enteredRgb.b);
            safeRender();
        };

        pickerControls.whiteRadio.onClick = function () {
            applyPreset("white");
            safeRender();
        };

        pickerControls.blackRadio.onClick = function () {
            applyPreset("black");
            safeRender();
        };

        pickerControls.customRadio.onClick = function () {
            applyPreset("custom");
            safeRender();
        };

        pickerControls.colorTabs.onChange = function () {
            if (isRendering) return;
            state.dialogTab = (pickerControls.colorTabs.selection === pickerControls.tabCMYK) ? "cmyk" : "rgb";
            if (state.dialogTab === "rgb") {
                syncRgbFromCmyk(state);
                state.mode = "rgb";
            } else {
                syncCmykFromRgb(state);
                state.mode = pickerControls.grayCheckbox.value ? "gray" : "cmyk";
            }
            safeRender({ suppressTabSelection: true });
        };

        for (var k = 0; k < pickerControls.swatchItems.length; k++) {
            (function (swatchItem) {
                swatchItem.element.addEventListener("click", function () {
                    var swatchRgb = hexToRGB(swatchItem.hex);
                    setRgb(swatchRgb.r, swatchRgb.g, swatchRgb.b);
                    safeRender();
                });
            })(pickerControls.swatchItems[k]);
        }

        pickerControls.grayCheckbox.onClick = function () {
            if (pickerControls.grayCheckbox.value) {
                state.cmyk.c = 0;
                state.cmyk.m = 0;
                state.cmyk.y = 0;
                state.mode = "gray";
            } else {
                state.mode = "cmyk";
            }
            state.dialogTab = "cmyk";
            state.preset = "custom";
            syncRgbFromCmyk(state);
            safeRender();
        };
    }

    // =========================================
    // 公開 API / Public API
    // =========================================

    /**
     * カラーピッカーを開き、選ばれた色を返す
     * @param {Object|string} showArgument - { value, title, lang }、または初期値の色文字列
     * @returns {string|null} "RRGGBB" / "cmyk:C,M,Y,K"。キャンセル時は null
     */
    function show(showArgument) {
        var pickerOptions = (typeof showArgument === "object" && showArgument !== null) ? showArgument : { value: showArgument };
        /* 表示言語は show() の lang オプションで決める（既定は英語） / UI language comes from the lang option of show(), English by default */
        uiLang = pickerOptions.lang || "en";
        var state = createInitialState(pickerOptions.value || "000000");
        var pickerControls = buildPickerDialog(state, pickerOptions.title || "Color Picker");

        bindPickerEvents(state, pickerControls);
        renderPickerState(state, pickerControls);

        /* #include 先の SCRIPT_NAME と混ざらないよう、キーは固定の名前にする / Fixed key so it does not mix with the including script's SCRIPT_NAME */
        prepareDialogWindow(pickerControls.dialog, "ColorPicker");
        var dialogResult = pickerControls.dialog.show();

        if (dialogResult !== 1) return null;
        return serializeState(state);
    }

    return {
        show: show,
        rgbToHex: rgbToHex,
        hexToRGB: hexToRGB,
        rgbToCmykApprox: rgbToCmykApprox,
        cmykToRgbApprox: cmykToRgbApprox,
        isCmykString: isCmykString,
        parseCmykString: parseCmykString
    };

})();
