#target illustrator
#targetengine "SmartTableMakerEngine"
app.preferences.setBooleanPreference('ShowExternalJSXWarning', false);

/*
SCRIPTMETA-BEGIN
Script-ID=com.swwwitch.illustrator.SmartTableMaker
Name=2つのオブジェクトの背面に左右2分割の背景を作成
Author=Masahiro Takano (@swwwitch)
Target-App=Illustrator
Version=1.2.10
Release-Date=2026-01-24
Description-BEGIN
2つのオブジェクト（テキスト、パス、グループなど）を選択して実行すると、各オブジェクトの背面に左右2分割の背景を作成します。
高さ倍率（%）をダイアログで指定でき、閉じる前にプレビューを確認できます。

With two objects selected — text, paths or groups — creates a background behind them, split into a left and a right half.
The height scale (%) is set in a dialog, with a preview before you commit.
Description-END
SCRIPTMETA-END
*/

/*

### 概要

2つのオブジェクト（テキスト、パス、グループなど）を選択して実行すると、各オブジェクトの背面に左右2分割の背景を作成します。
高さ倍率（%）をダイアログで指定でき、閉じる前にプレビューを確認できます。

詳細は README を参照してください。
https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/SmartTableMaker.md

### Overview

With two objects selected — text, paths or groups — creates a background behind them, split into a left and a right half.
The height scale (%) is set in a dialog, with a preview before you commit.

See the README for details.
https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/SmartTableMaker.md

*/

// =========================================
// 基本情報 / Basic info
// =========================================
var SCRIPT_NAME     = "SmartTableMaker";              /* スクリプト名 / script name */
var SCRIPT_VERSION  = "v1.2.10";                      /* バージョン / version */
var SCRIPT_AUTHOR   = "Masahiro Takano (@swwwitch)";  /* 作者 / author */
var SCRIPT_RELEASED = "2026-01-24";                   /* 最初のリリース日 / first release date */
var SCRIPT_UPDATED  = "2026-10-16";                   /* 更新日 / last updated */

var SCRIPT_DESCRIPTION_JA = "2つのオブジェクトの背面に左右2分割の背景を作成"; /* README の見出し / README title (Japanese) */

var SCRIPT_README_JA  = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/SmartTableMaker.md"; /* README（日本語） */
var SCRIPT_README_EN  = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/SmartTableMaker.md"; /* README (English) */
var SCRIPT_SOURCE_URL = "https://github.com/swwwitch/illustrator-scripts/blob/master/jsx/stroke-table/single-function/SmartTableMaker.jsx"; /* 最新版のソース / latest source */

// Released under the MIT license
// http://opensource.org/licenses/mit-license.php

(function () {

    // ローカライズ（再利用パーツ） / Localization (reusable)

    /**
     * UI の言語を返す（"ja" で始まるロケールは日本語、それ以外は英語）
     * @returns {string} "ja" または "en"
     */
    function getCurrentLang() {
        return (String($.locale || "").indexOf("ja") === 0) ? "ja" : "en";
    }

    var uiLang = getCurrentLang();

    /**
     * LABELS から今の UI 言語の文言を取り出す。
     * @param {string|Object} labelRef - "dialog.title" のようなパス、または { ja, en }
     * @param {Object|Array} [placeholderValues] - { name: 値 } なら {name} を、[値, …] なら %1, %2 … を差し込む
     * @returns {string} 文言。パスが見つからなければパスの文字列、{ ja, en } が無ければ空文字
     */
    function getLabel(labelRef, placeholderValues) {
        var labelEntry = labelRef;
        if (typeof labelRef === "string") {
            var labelPathKeys = labelRef.split(".");
            labelEntry = LABELS;
            for (var i = 0; i < labelPathKeys.length && labelEntry != null; i++) {
                labelEntry = labelEntry[labelPathKeys[i]];
            }
        }
        var labelString;
        if (typeof labelEntry === "string") labelString = labelEntry;
        else if (labelEntry != null && labelEntry[uiLang] != null) labelString = labelEntry[uiLang];
        else if (labelEntry != null && labelEntry.en != null) labelString = labelEntry.en;
        else return (typeof labelRef === "string") ? labelRef : "";
        return fillLabelPlaceholders(String(labelString), placeholderValues);
    }

    /**
     * 項目名の文言の末尾にコロンを付ける（日本語は半角スペース＋半角コロン「 :」、英語は「:」。Illustrator の線パネルなどの項目名に合わせる）
     * @param {string|Object} labelRef - getLabel と同じ
     * @param {Object|Array} [placeholderValues] - getLabel と同じ
     * @returns {string} コロン付きの文言
     */
    function labelText(labelRef, placeholderValues) {
        return getLabel(labelRef, placeholderValues) + (uiLang === "ja" ? " :" : ":");
    }

    /**
     * 「項目名 : 値」の1行を返す（日本語は「件数 : 5」、英語は「Count: 5」。どちらもコロンのあとに空白を入れる）
     * @param {string|Object} labelRef - getLabel と同じ
     * @param {string|number} value - コロンのあとに続ける値
     * @returns {string} 項目名と値をつないだ文字列
     */
    function labelValueText(labelRef, value) {
        return labelText(labelRef) + " " + value;
    }

    /**
     * 文言の {name} や %1 に値を差し込む
     * @param {string} labelString - 文言
     * @param {Object|Array} [placeholderValues] - { name: 値 } または [値, …]
     * @returns {string} 差し込んだ文言
     */
    function fillLabelPlaceholders(labelString, placeholderValues) {
        if (placeholderValues == null) return labelString;
        if (placeholderValues instanceof Array) {
            /* 大きい番号から置き換え、%1 が %10 の一部を置き換えないようにする / Replace from the highest index so %1 does not eat into %10 */
            for (var i = placeholderValues.length; i >= 1; i--) {
                labelString = labelString.split("%" + i).join(String(placeholderValues[i - 1]));
            }
            return labelString;
        }
        for (var placeholderKey in placeholderValues) {
            if (!placeholderValues.hasOwnProperty(placeholderKey)) continue;
            labelString = labelString.split("{" + placeholderKey + "}").join(String(placeholderValues[placeholderKey]));
        }
        return labelString;
    }

    // ローカライズ（再利用パーツ）ここまで / End of the reusable localization

    // ボタン行（再利用パーツ） / Button row (reusable)

    var BUTTON_ROW_TOP_MARGIN = 5; /* ボタン行の上の余白 / top margin of the button row */
    var BUTTON_ROW_BOTTOM_MARGIN = 14; /* ボタン行の下の余白。ダイアログの下余白と合わせて約30px（Illustrator 標準のダイアログに合わせる） / bottom margin; with the dialog margin about 30px, like Illustrator's own dialogs */
    var BUTTON_ROW_SPACING = 10;   /* ボタンどうしの間隔 / spacing between buttons */
    var BUTTON_ROW_CENTER_MAX_WIDTH = 240; /* 右のボタンだけの行を中央に置く、ダイアログの内側の最大幅（px、左右の余白を除く）。広いダイアログは右揃え / max inner dialog width (px, margins excluded) that centers a right-only row; wider dialogs keep it right-aligned */

    /**
     * ダイアログ下部のボタン行を作る。
     * 通常は「左のグループ・伸びるスペーサー・右のグループ」、centered なら行そのものを左右中央に置く
     * @param {Window|Group|Panel} parent - 行を足す先（ふつうはダイアログ）
     * @param {Object} [rowOptions] - { centered: true } で左右中央に並べる
     * @returns {{rowGroup: Group, leftGroup: Group|null, rightGroup: Group|null}} 行と左右のグループ（centered のときは左右が null）
     */
    function addButtonRow(parent, rowOptions) {
        var isCentered = !!(rowOptions && rowOptions.centered);
        var btnRowGroup = parent.add("group");
        btnRowGroup.orientation = "row";
        btnRowGroup.margins = [0, BUTTON_ROW_TOP_MARGIN, 0, BUTTON_ROW_BOTTOM_MARGIN];
        btnRowGroup.spacing = BUTTON_ROW_SPACING;

        if (isCentered) {
            btnRowGroup.alignment = ["center", "bottom"];
            btnRowGroup.alignChildren = ["center", "center"];
            return { rowGroup: btnRowGroup, leftGroup: null, rightGroup: null };
        }

        btnRowGroup.alignment = ["fill", "bottom"];

        var btnLeftGroup = btnRowGroup.add("group");
        btnLeftGroup.alignChildren = ["left", "center"];
        btnLeftGroup.spacing = BUTTON_ROW_SPACING;

        /* 余りの幅を吸って、右のグループを右端に寄せる / Absorbs the extra width so the right group sits at the right edge */
        var spacer = btnRowGroup.add("group");
        spacer.alignment = ["fill", "fill"];
        spacer.minimumSize.width = 0;

        var btnRightGroup = btnRowGroup.add("group");
        btnRightGroup.alignChildren = ["right", "center"];
        btnRightGroup.spacing = BUTTON_ROW_SPACING;

        return { rowGroup: btnRowGroup, leftGroup: btnLeftGroup, rightGroup: btnRightGroup };
    }

    /**
     * 左のグループにボタンが無い（右のボタンだけの）行を、ダイアログの幅に合わせて揃える。
     * 内側の幅（左右の余白を除く）が BUTTON_ROW_CENTER_MAX_WIDTH 以下なら左右中央、それより広ければ右揃えのまま。
     * 幅はレイアウトが決まるまで分からないので、ダイアログを表示した時点（show イベント）で判定する。
     * ボタンをすべて足したあと、show() の前に呼ぶ。centered で作った行や、左にボタンがある行はそのまま
     * @param {{rowGroup: Group, leftGroup: Group|null, rightGroup: Group|null}} buttonRow - addButtonRow() の戻り値
     * @returns {void}
     */
    function alignRightOnlyButtonRow(buttonRow) {
        if (!buttonRow.leftGroup || buttonRow.leftGroup.children.length > 0) return;
        var dialogWindow = buttonRow.rowGroup.window;
        dialogWindow.addEventListener("show", function () {
            if (!buttonRow.leftGroup) return;
            var btnRowGroup = buttonRow.rowGroup;
            /* 行の幅＝ダイアログの内側の幅（左右の余白を除く）/ The row spans the dialog's inner width (margins excluded) */
            if (!btnRowGroup.size || btnRowGroup.size.width > BUTTON_ROW_CENTER_MAX_WIDTH) return;
            /* 左のグループとスペーサーを外し、右のグループだけを中央に置く / Drop the left group and the spacer so only the right group remains, centered */
            btnRowGroup.remove(buttonRow.leftGroup);
            btnRowGroup.remove(btnRowGroup.children[0]); /* 左のグループを外すと先頭はスペーサー / the spacer is first once the left group is gone */
            btnRowGroup.alignment = ["center", "bottom"];
            btnRowGroup.alignChildren = ["center", "center"];
            buttonRow.leftGroup = null;
            dialogWindow.layout.layout(true);
        });
    }

    // ボタン行（再利用パーツ）ここまで / End of the reusable button row

    // UIレイアウト（再利用パーツ） / UI layout (reusable)

    /* ウィンドウ・パネルの余白と間隔 / Window & panel margins and spacing */
    var WINDOW_MARGINS = 16;                 /* ウィンドウ外周の余白 / window margin */
    var WINDOW_SPACING = 12;                 /* ウィンドウ内の要素間隔 / window spacing */
    var PANEL_MARGINS  = [16, 20, 16, 12];   /* パネル余白 [左,上,右,下] / panel margins */
    var PANEL_SPACING  = 12;                 /* パネル内の要素間隔 / panel spacing */
    var COLUMN_SPACING = 12;                 /* 2カラムの間隔 / gap between columns */
    var TAB_MARGINS    = [15, 20, 5, 10];    /* タブ余白 [左,上,右,下] / tab margins */

    /**
     * ウィンドウの共通設定
     * @param {Window} targetWindow - 対象のウィンドウ
     * @param {number} [spacing] - 要素間隔（省略時は WINDOW_SPACING）
     * @returns {void}
     */
    function setupWindow(targetWindow, spacing) {
        targetWindow.orientation = "column";
        targetWindow.alignChildren = "fill";
        targetWindow.margins = WINDOW_MARGINS;
        targetWindow.spacing = (typeof spacing === "number") ? spacing : WINDOW_SPACING;
    }

    /**
     * パネルの共通設定（子は幅いっぱい。ボタンは alignment = "left" で広げない）
     * @param {Panel} targetPanel - 対象のパネル
     * @param {number} [spacing] - 要素間隔（省略時は PANEL_SPACING）
     * @returns {void}
     */
    function setupPanel(targetPanel, spacing) {
        targetPanel.orientation = "column";
        targetPanel.alignChildren = ["fill", "top"];
        targetPanel.alignment = "fill";
        targetPanel.margins = PANEL_MARGINS;
        targetPanel.spacing = (typeof spacing === "number") ? spacing : PANEL_SPACING;
    }

    /**
     * タブの共通設定
     * @param {Tab} targetTab - 対象のタブ
     * @param {number} [spacing] - 要素間隔（省略時は変えない）
     * @returns {void}
     */
    function setupTab(targetTab, spacing) {
        targetTab.orientation = "column";
        targetTab.alignChildren = "fill";
        targetTab.margins = TAB_MARGINS;
        if (typeof spacing === "number") targetTab.spacing = spacing;
    }

    /**
     * 横並びの行グループの共通設定（ボタン列など）。
     * alignment と alignChildren を対で指定し、中のボタンが横に伸びたり天地がずれたりしないようにする
     * @param {Group} rowGroup - 対象のグループ
     * @param {string|string[]} [rowAlignment] - 横方向の alignment（省略時は "left"）。配列ならそのまま使う
     * @param {number} [spacing] - 要素間隔（省略時は PANEL_SPACING）
     * @returns {void}
     */
    function setupRow(rowGroup, rowAlignment, spacing) {
        rowGroup.orientation = "row";
        rowGroup.alignment = (rowAlignment instanceof Array) ? rowAlignment : [rowAlignment || "left", "center"];
        rowGroup.alignChildren = ["left", "center"];
        rowGroup.spacing = (typeof spacing === "number") ? spacing : PANEL_SPACING;
    }

    /**
     * ボタンの高さを指定した px だけ詰める（レイアウトが決まったあとに呼ぶ）
     * @param {Button} targetButton - 対象のボタン
     * @param {number} trimPixels - 詰める量（px）
     * @returns {void}
     */
    function trimButtonHeight(targetButton, trimPixels) {
        /* レイアウト前は size が無い / size is not set until the layout runs */
        if (!targetButton.size) return;
        targetButton.size = [targetButton.size.width, targetButton.size.height - trimPixels];
    }

    // UIレイアウト（再利用パーツ）ここまで / End of the reusable UI layout

    /* 日英ラベル定義 / Japanese-English label definitions */
    var LABELS = {
        scriptName: {
            ja: "SplitBackgroundForTwo",
            en: "SplitBackgroundForTwo"
        },
        dialogTitle: {
            ja: "2つのオブジェクトの背景を作成",
            en: "Create Background for Two Objects"
        },
        alertOpenDoc: {
            ja: "ドキュメントを開いてください。",
            en: "Please open a document."
        },
        alertSelectTwoText: {
            ja: "2つのテキストオブジェクトを選択してください。",
            en: "Please select two text objects."
        },
        alertSelectTwoItems: {
            ja: "2つのオブジェクトを選択してください。",
            en: "Please select two objects."
        },
        alertSelectTwoTextFrame: {
            ja: "2つのテキストオブジェクト（TextFrame）を選択してください。",
            en: "Please select two text objects (TextFrame)."
        },
        labelHeight: {
            ja: "高さ",
            en: "Height"
        },
        labelPercent: {
            ja: "%",
            en: "%"
        },
        labelPreview: {
            ja: "プレビュー",
            en: "Preview"
        },
        tipPercent: { ja: "列幅の割合（％）です。", en: "Column width share, in percent." },
        tipFillSide: { ja: "この側に塗りを付けます。", en: "Fills this side." },
        tipOverallFrame: { ja: "表全体を1つの枠線で囲みます。", en: "Draws a single frame around the whole table." },
        tipDivider: { ja: "列の境目にケイ線を引きます。", en: "Draws a rule between the columns." },
        tipStroke: { ja: "ケイ線の太さです。", en: "Weight of the rules." },
        tipCorner: { ja: "角丸の半径です。0 で角のままになります。", en: "Corner radius. 0 leaves the corners square." },
        tipPinNone: { ja: "どちらの幅も固定せず、割合だけで分けます。", en: "Pins neither side; the ratio alone decides the split." },
        tipPinLeft: { ja: "左側の幅を固定し、残りを右側にします。", en: "Pins the left side and gives the rest to the right." },
        tipPinRight: { ja: "右側の幅を固定し、残りを左側にします。", en: "Pins the right side and gives the rest to the left." },
        tipWidth: { ja: "固定する側の幅です。", en: "Width of the pinned side." },
        tipWidthSlider: { ja: "固定する側の幅をドラッグで決めます。", en: "Drag to set the width of the pinned side." },
        tipPreview: { ja: "結果を画面で確認します。キャンセルすると元に戻ります。", en: "Shows the result on the canvas. Cancel restores the original state." },
        tooltip: {
            stepUp: {
                ja: "値を増やす（shift＋クリックで10の倍数へ、option＋クリックで0.1ずつ）",
                en: "Increase (Shift-click to snap to 10s, Option-click by 0.1)"
            },
            stepDown: {
                ja: "値を減らす（shift＋クリックで10の倍数へ、option＋クリックで0.1ずつ）",
                en: "Decrease (Shift-click to snap to 10s, Option-click by 0.1)"
            },
            stepUpInteger: { ja: "値を増やす（shift＋クリックで10の倍数へ）", en: "Increase (Shift-click to snap to 10s)" },
            stepDownInteger: { ja: "値を減らす（shift＋クリックで10の倍数へ）", en: "Decrease (Shift-click to snap to 10s)" }
        },
        labelOverallFrame: {
            ja: "全体の枠",
            en: "Overall frame"
        },
        labelDivider: {
            ja: "区切り線",
            en: "Divider"
        },
        labelFillLeft: {
            ja: "塗り（左）",
            en: "Fill (Left)"
        },
        labelFillRight: {
            ja: "塗り（右）",
            en: "Fill (Right)"
        },
        panelLine: {
            ja: "オプション",
            en: "Options"
        },
        // --- 固定パネルラベル追加 ---
        panelFixed: {
            ja: "バランス",
            en: "Balance"
        },
        fixedNone: {
            ja: "なし",
            en: "None"
        },
        fixedLeft: {
            ja: "左",
            en: "Left"
        },
        fixedRight: {
            ja: "右",
            en: "Right"
        },
        // --- 幅パネルラベル追加 ---
        panelWidth: {
            ja: "幅",
            en: "Width"
        },
        labelWidth: {
            ja: "幅",
            en: "Width"
        },
        labelPercentSign: {
            ja: "%",
            en: "%"
        },
        // ------------------------
        labelStrokeWidth: {
            ja: "線幅",
            en: "Stroke width"
        },
        labelCornerRadius: {
            ja: "角丸",
            en: "Corner radius"
        },
        labelPt: {
            ja: "pt",
            en: "pt"
        },
        labelOK: {
            ja: "OK",
            en: "OK"
        },
        labelCancel: {
            ja: "キャンセル",
            en: "Cancel"
        },
        alertHeightInvalid: {
            ja: "高さ（%）は0より大きい数値を入力してください。",
            en: "Enter a height (%) greater than 0."
        }
    };

    // =========================================
    // 単位 / Units
    // =========================================

    /* 単位コードに対応する表示ラベルと、1単位あたりのポイント数
       Unit code -> display label and points per unit */
    var UNITS = [
        { label: "in",    pointsPerUnit: 72 },                /* 0 */
        { label: "mm",    pointsPerUnit: 72 / 25.4 },         /* 1 */
        { label: "pt",    pointsPerUnit: 1 },                 /* 2 */
        { label: "pica",  pointsPerUnit: 12 },                /* 3 */
        { label: "cm",    pointsPerUnit: 72 / 2.54 },         /* 4 */
        { label: "Q",     pointsPerUnit: 72 / 25.4 * 0.25 },  /* 5 */
        { label: "px",    pointsPerUnit: 1 },                 /* 6 */
        { label: "ft/in", pointsPerUnit: 72 * 12 },           /* 7 */
        { label: "m",     pointsPerUnit: 72 / 25.4 * 1000 },  /* 8 */
        { label: "yd",    pointsPerUnit: 72 * 36 },           /* 9 */
        { label: "ft",    pointsPerUnit: 72 * 12 }            /* 10 */
    ];

    /* 単位コード5を「歯（H）」と表示する環境設定キー。文字サイズ（text/units）だけ「級（Q）」
       Preference keys that show unit code 5 as H; only the type size (text/units) shows Q */
    var HA_UNIT_PREF_KEYS = { "rulerType": true, "strokeUnits": true, "text/asianunits": true };

    /**
     * 環境設定キーの単位を返す
     * @param {string} [prefKey] - "rulerType"（既定）/ "strokeUnits" / "text/units" / "text/asianunits"
     * @returns {{code: number, label: string, pointsPerUnit: number}} 単位の情報
     */
    function getUnitInfo(prefKey) {
        var unitKey = prefKey || "rulerType";
        var unitCode = app.preferences.getIntegerPreference(unitKey);
        /* 未知のコードは pt に寄せる / unknown codes fall back to points */
        var unit = UNITS[unitCode] || UNITS[2];
        /* 級（Q）と歯（H）は同じ長さだが、文字サイズは「Q」、距離は「H」と呼び分ける */
        var label = (unitCode === 5 && HA_UNIT_PREF_KEYS[unitKey]) ? "H" : unit.label;
        return { code: unitCode, label: label, pointsPerUnit: unit.pointsPerUnit };
    }

    /**
     * 単位の値を pt に換算する
     * @param {number} value - 単位の値
     * @param {{pointsPerUnit: number}} unit - getUnitInfo() の戻り値か UNITS[i]
     * @returns {number} pt の値
     */
    function unitToPt(value, unit) {
        return value * unit.pointsPerUnit;
    }

    /**
     * pt の値を単位の値に換算する
     * @param {number} ptValue - pt の値
     * @param {{pointsPerUnit: number}} unit - getUnitInfo() の戻り値か UNITS[i]
     * @returns {number} 単位の値
     */
    function ptToUnit(ptValue, unit) {
        return ptValue / unit.pointsPerUnit;
    }

    function formatUnitValue(v) {
        // UI表示用：小数第1位まで（整数に近い場合は整数表示）
        if (isNaN(v)) return "";
        var r = Math.round(v * 10) / 10;
        if (Math.abs(r - Math.round(r)) < 1e-9) return String(Math.round(r));
        return String(r);
    }

    // ダイアログの位置と不透明度（再利用パーツ） / Dialog position and opacity (reusable)

    var DIALOG_OPACITY = 0.98;       /* ダイアログの不透明度 / dialog opacity */
    var DIALOG_AVOID_MARGIN = 60;    /* 選択範囲の推定位置の両側に取る余裕（px）/ margin on each side of the estimated selection (px) */
    var DIALOG_AVOID_MAX_ITEMS = 100; /* 選択範囲を測るオブジェクトの上限 / max items measured for the selection bounds */

    /**
     * ダイアログの不透明度を設定し、前回閉じた位置で開いて、動かした位置を記録するようにする。
     * 開く位置が選択中のオブジェクトに重なりそうなときは、左右の反対側へずらす（Illustrator のみ）。
     * 既存の onShow / onMove / onClose は先に呼んでから、位置の復元・記録を行う。
     * @param {Window} dialog - 対象のダイアログ
     * @param {string} storageKey - 位置を覚えるキー（ふつうは SCRIPT_NAME）
     * @returns {void}
     */
    function prepareDialogWindow(dialog, storageKey) {
        /* 同じダイアログを開き直すときは、選択範囲を測り直すだけにする（ハンドラーを重ねない）
           When the same dialog is shown again, only re-measure the selection (don't stack handlers) */
        if (dialog.dialogWindowState) {
            dialog.dialogWindowState.selectionSpan = getSelectionViewSpan();
            dialog.dialogWindowState.avoidedLocation = null;
            return;
        }
        var locationKey = "__" + storageKey + "_DialogLocation";
        var previousOnShow = dialog.onShow;
        var previousOnMove = dialog.onMove;
        var previousOnClose = dialog.onClose;
        var windowState = {
            selectionSpan: getSelectionViewSpan(), /* 選択範囲は show() の前に測る / measured before show() */
            screenWidth: null,                     /* 最初に開いたときに推定する / estimated on the first show */
            avoidedLocation: null                  /* 避けるためにずらした位置（記録しない）/ location set to avoid the selection (not remembered) */
        };
        dialog.dialogWindowState = windowState;

        dialog.opacity = DIALOG_OPACITY;

        /* 今の位置を記録する / Remember the current location */
        function rememberDialogLocation() {
            var currentLocation = [dialog.location[0], dialog.location[1]];
            var avoidedLocation = windowState.avoidedLocation;
            if (avoidedLocation && currentLocation[0] === avoidedLocation[0] && currentLocation[1] === avoidedLocation[1]) return;
            $.global[locationKey] = currentLocation;
        }

        dialog.onShow = function () {
            /* 最初に開くときの既定の位置は画面の横中央なので、画面の幅を逆算できる。2回目からは前回の位置なので使い回す
               On the first show the default location is centered horizontally, which gives the screen width; reuse it afterwards */
            if (windowState.screenWidth === null) windowState.screenWidth = dialog.location[0] * 2 + dialog.bounds.width;
            if (previousOnShow) previousOnShow.apply(this, arguments);
            /* $.screens は実際の画面の大きさと合わない（Mac で 1280×524 など）ので、画面内かは判定しない
               $.screens does not match the real display (e.g. 1280x524 on a Mac), so no on-screen check */
            var savedLocation = $.global[locationKey];
            if (savedLocation) dialog.location = [savedLocation[0], savedLocation[1]];
            if (windowState.selectionSpan) {
                var avoidLeft = findDialogLeftAvoidingSelection(dialog.location[0], dialog.bounds.width, windowState.screenWidth, windowState.selectionSpan);
                if (avoidLeft !== null) {
                    dialog.location = [avoidLeft, dialog.location[1]];
                    /* 代入後の値で比べる（丸められることがある）/ Compare with the value after assignment, which may be rounded */
                    windowState.avoidedLocation = [dialog.location[0], dialog.location[1]];
                }
            }
        };
        dialog.onMove = function () {
            if (previousOnMove) previousOnMove.apply(this, arguments);
            rememberDialogLocation();
        };
        dialog.onClose = function () {
            rememberDialogLocation();
            /* false を返すと閉じるのを取りやめるので、戻り値は元の onClose のものを返す
               Returning false cancels the close, so pass the original onClose result through */
            if (previousOnClose) return previousOnClose.apply(this, arguments);
        };
    }

    /**
     * 選択中のオブジェクトが、ドキュメントの表示域の左端から画面上で何 px の範囲にあるかを返す。
     * @returns {{left: number, right: number, viewWidth: number}|null} 選択が無い・測れないときは null
     */
    function getSelectionViewSpan() {
        try {
            if (app.name !== "Adobe Illustrator" || !app.documents.length) return null;
            var targetDoc = app.activeDocument;
            var selectedItems = targetDoc.selection;
            /* 文字ツールで文字を選択しているときは TextRange が返り、[0] が無い / Selecting characters with the Type tool returns a TextRange, which has no [0] */
            if (!selectedItems || selectedItems.typename === "TextRange" || !selectedItems.length || !selectedItems[0].visibleBounds) return null;
            var itemCount = Math.min(selectedItems.length, DIALOG_AVOID_MAX_ITEMS);
            var spanLeft = Infinity;
            var spanRight = -Infinity;
            for (var i = 0; i < itemCount; i++) {
                var itemBounds = selectedItems[i].visibleBounds;
                if (itemBounds[0] < spanLeft) spanLeft = itemBounds[0];
                if (itemBounds[2] > spanRight) spanRight = itemBounds[2];
            }
            var activeView = targetDoc.activeView; /* 複数ウィンドウで開いていても今のウィンドウ / the current window even with multiple windows */
            var viewBounds = activeView.bounds;
            var zoom = activeView.zoom;
            var viewWidth = (viewBounds[2] - viewBounds[0]) * zoom;
            /* 表示域の外にはみ出した部分は数えない / Ignore the part outside the view */
            var left = Math.max(0, (spanLeft - viewBounds[0]) * zoom);
            var right = Math.min(viewWidth, (spanRight - viewBounds[0]) * zoom);
            if (right <= left) return null;
            return { left: left, right: right, viewWidth: viewWidth };
        } catch (e) {
            /* テキスト編集中など測れないときは避けない / Do not avoid when it cannot be measured, e.g. while editing text */
            return null;
        }
    }

    /**
     * ダイアログが選択範囲に重なるなら、重ならない左端の位置を返す。
     * 表示域は画面の横中央にあるとみなし、ずれは DIALOG_AVOID_MARGIN で吸収する。
     * @param {number} dialogLeft - 今のダイアログの左端
     * @param {number} dialogWidth - ダイアログの幅
     * @param {number} screenWidth - 画面の幅
     * @param {{left: number, right: number, viewWidth: number}} selectionSpan - getSelectionViewSpan() の結果
     * @returns {number|null} ずらした左端。重ならない・どちらにも収まらないときは null
     */
    function findDialogLeftAvoidingSelection(dialogLeft, dialogWidth, screenWidth, selectionSpan) {
        var viewLeft = (screenWidth - selectionSpan.viewWidth) / 2;
        var avoidLeft = viewLeft + selectionSpan.left - DIALOG_AVOID_MARGIN;
        var avoidRight = viewLeft + selectionSpan.right + DIALOG_AVOID_MARGIN;
        if (dialogLeft + dialogWidth <= avoidLeft || dialogLeft >= avoidRight) return null;

        var leftSideLeft = avoidLeft - dialogWidth;   /* 選択範囲の左に置くとき / placed left of the selection */
        var rightSideLeft = avoidRight;               /* 選択範囲の右に置くとき / placed right of the selection */
        var fitsLeft = leftSideLeft >= 0;
        var fitsRight = rightSideLeft + dialogWidth <= screenWidth;
        /* 選択範囲が画面の右寄りなら左へ、左寄りなら右へ逃がす / Move away from the side the selection leans to */
        var preferLeft = (avoidLeft + avoidRight) / 2 > screenWidth / 2;
        if (preferLeft && fitsLeft) return leftSideLeft;
        if (fitsRight) return rightSideLeft;
        if (fitsLeft) return leftSideLeft;
        return null;
    }

    // ダイアログの位置と不透明度（再利用パーツ）ここまで / End of the reusable dialog position and opacity

    // UI の明暗（再利用パーツ） / UI theme (reusable)

    /**
     * UI がダークテーマかどうかを判定する（Illustrator は uiBrightness、InDesign は uiBrightnessPreference）
     * @returns {boolean} ダークなら true。取得できない環境では false（明るいUI扱い）
     */
    function isDarkUI() {
        try {
            if (app.preferences && app.preferences.getRealPreference) {
                return app.preferences.getRealPreference("uiBrightness") <= 0.5; /* Illustrator */
            }
            return app.generalPreferences.uiBrightnessPreference <= 0.5; /* InDesign */
        } catch (e) {
            return false;
        }
    }

    // UI の明暗（再利用パーツ）ここまで / End of the reusable UI theme

    // ステップボタン（再利用パーツ） / Stepper buttons (reusable)

    // -----------------------------------------
    // ステップボタンの寸法・増減量 / Stepper metrics and steps
    // -----------------------------------------
    var STEPPER_BUTTON_WIDTH   = 20;  /* ∧∨ボタンの幅 / button width */
    var STEPPER_BUTTON_HEIGHT  = 11;  /* ∧∨ボタン1つの高さ（2つ重ねた全体の高さは22） / button height (22 for the pair) */
    var STEPPER_CORNER_RADIUS  = 2;   /* 枠の角丸の半径（ScriptUIは円弧を描けないため短い線分で近似） / corner radius, approximated with segments */
    var STEPPER_FIELD_SPACING  = 3;   /* 項目名と∧∨の間隔 / spacing between the label and the stepper */
    var STEPPER_SIDE_MARGIN    = 3;   /* ∧∨の左に足す余白（右は入力欄に突き合わせる） / extra space left of the stepper */
    var STEPPER_SHIFT_MULTIPLE = 10;  /* shift＋クリックでそろえる倍数 / Shift-click snaps to multiples of this */
    var STEPPER_OPTION_STEP    = 0.1; /* option＋クリックの増減量 / Option-click step */

    /* 単位の換算は UnitValue に任せる（in / ft / yd / mm / cm / m / pt / pc / px ほか、単数形・複数形も可）。
       UnitValue に無い単位だけ、ここで UnitValue の単位に読み替える（値は「1単位＝何 unit か」）。
       「p」は「1p6」（1パイカ6ポイント）の形にも使う
       Units UnitValue lacks, mapped onto UnitValue units (how many of `unit` make one) */
    var STEPPER_UNIT_ALIASES = {
        "q": { unit: "mm", amount: 0.25 }, /* 級 / Q */
        "h": { unit: "mm", amount: 0.25 }, /* 歯 / H */
        "p": { unit: "pc", amount: 1 }     /* パイカ / pica */
    };

    // -----------------------------------------
    // ステップボタンの配色 / Stepper colors
    // -----------------------------------------
    var STEPPER_UI_DARK           = isDarkUI();
    /* UIの明るさは4段階あり、段階ごとに背景色が違う。どの段階でも背景に対する差で見せるよう、黒・白の半透明を重ねる。
       ダーク側は Illustrator 標準のスピナー（［グリッドに分割］）で実測、明るい側は最も明るい段階（背景 約0.94）から逆算
       UI brightness has four levels with different backgrounds, so colors are translucent overlays that follow the
       dialog background. Dark values are measured from Illustrator's own spinner; light values derived for the lightest level */
    var STEPPER_FILL_COLOR        = STEPPER_UI_DARK ? [0, 0, 0, 0.10]  : [1, 1, 1, 0.50];  /* 地 / background */
    var STEPPER_FRAME_COLOR       = STEPPER_UI_DARK ? [1, 1, 1, 0.07]  : [0, 0, 0, 0.10];  /* 枠線 / frame */
    var STEPPER_PRESSED_COLOR     = STEPPER_UI_DARK ? [1, 1, 1, 0.12]  : [0, 0, 0, 0.13];  /* 押下中 / pressed */
    var STEPPER_CHEVRON_COLOR     = STEPPER_UI_DARK ? [1, 1, 1, 1]     : [0, 0, 0, 0.70];  /* 山形の線 / chevron */
    var STEPPER_DIM_FILL_COLOR    = STEPPER_UI_DARK ? [1, 1, 1, 0.035] : [1, 1, 1, 0.30];  /* 無効時の地 / background when disabled */
    var STEPPER_DIM_FRAME_COLOR   = STEPPER_UI_DARK ? [1, 1, 1, 0.035] : [0, 0, 0, 0.05];  /* 無効時の枠線（ダークは地と同じで見せない） / frame when disabled */
    var STEPPER_DIM_CHEVRON_COLOR = STEPPER_UI_DARK ? [1, 1, 1, 0.20]  : [0, 0, 0, 0.25];  /* 無効時の山形 / chevron when disabled */

    // -----------------------------------------
    // 数値欄を作る（外から呼ぶ関数） / Public API
    // -----------------------------------------
    /**
     * 「項目名・∧∨・入力欄」をひと組にした数値欄を追加する。
     * ↑↓キーでも∧∨と同じように増減する。直接入力した値も、フォーカスが外れたときに
     * 整数化・下限・上限・単位（「20 mm」の形）へそろえ、数値でなければ直前の値に戻す。
     * 四則演算（+ - * / と括弧）を入れると、確定時に計算した値にする。欄と違う単位で入れた値は欄の単位へ換算する（mm の欄に「1 in」→「25.4 mm」）
     * @param {Group|Panel} parent - 追加先
     * @param {Object} fieldOptions - label（コロン込みの項目名）/ labelWidth / text / characters /
     *     step / min / max / integer（true で整数のみ）/ unit / onStep
     * @returns {EditText} 入力欄（項目名は .fieldLabel、∧∨は .stepperGroup で参照できる）
     */
    function addSteppedField(parent, fieldOptions) {
        var fieldRowGroup = parent.add("group");
        fieldRowGroup.orientation = "row";
        fieldRowGroup.alignChildren = ["left", "center"];
        fieldRowGroup.spacing = STEPPER_FIELD_SPACING;

        var fieldLabel = fieldRowGroup.add("statictext", undefined, fieldOptions.label || "");
        if (fieldOptions.labelWidth) {
            fieldLabel.preferredSize.width = fieldOptions.labelWidth;
            fieldLabel.justify = "right";
        }

        /* ∧∨と入力欄は隙間0で突き合わせる / butt the stepper against the field */
        var stepperInputGroup = fieldRowGroup.add("group");
        stepperInputGroup.orientation = "row";
        stepperInputGroup.alignChildren = ["left", "center"];
        stepperInputGroup.spacing = 0;
        stepperInputGroup.margins = 0;

        var numberInput;
        var stepperGroup = addStepper(stepperInputGroup, function () { return numberInput; }, fieldOptions);
        numberInput = stepperInputGroup.add("edittext", undefined, fieldOptions.text || "");
        numberInput.characters = fieldOptions.characters || 6;
        numberInput.fieldLabel = fieldLabel;
        numberInput.stepperGroup = stepperGroup;

        /* ↑↓キーも∧∨と同じ処理で増減する（増減量・下限・上限・単位・修飾キーをそろえる） / arrow keys share the stepper's logic */
        bindSteppedArrowKeys(numberInput, stepperGroup);

        /* 項目名のクリックで入力欄にフォーカスを移す / clicking the label focuses the field */
        fieldLabel.addEventListener("click", function () { focusNumberInput(numberInput); });

        /* 直接入力をそろえる。計算式は計算し、数値でなければ直前の値に戻す / normalize typed values; evaluate arithmetic, revert non-numbers */
        numberInput.lastValidText = numberInput.text;
        numberInput.onChange = function () {
            var value = evaluateArithmetic(numberInput.text, fieldOptions.unit);
            if (isNaN(value)) {
                numberInput.text = numberInput.lastValidText;
                return;
            }
            writeSteppedValue(numberInput, value, fieldOptions);
        };
        return numberInput;
    }

    /**
     * 数値欄の有効／無効を、項目名・∧∨ごとまとめて切り替える
     * @param {EditText} numberInput - addSteppedField() で作った入力欄
     * @param {boolean} isEnabled - 有効にするなら true
     * @returns {void}
     */
    function setSteppedFieldEnabled(numberInput, isEnabled) {
        numberInput.enabled = isEnabled;
        numberInput.fieldLabel.enabled = isEnabled;
        numberInput.stepperGroup.enabled = isEnabled;
        /* ∧∨は自作描画なので、描き直してディム表示を切り替える / redraw the custom-drawn buttons to update the dimming */
        for (var i = 0; i < numberInput.stepperGroup.children.length; i++) {
            redrawStepperGroup(numberInput.stepperGroup.children[i]);
        }
    }

    /**
     * 入力欄の値を増減する∧∨ボタンを、隙間なく縦に積んで追加する
     * @param {Group|Panel} parent - 追加先
     * @param {Function} getNumberInput - 対象の入力欄を返す関数（入力欄を∧∨より後に作れるよう、クリック時に引く）
     * @param {Object} stepOptions - step（増減量）/ min / max / integer / unit（例 " mm"）/ onStep(numberInput)
     * @returns {Group} ∧∨をまとめた group（.stepBy(direction) で同じ増減を呼べる）
     */
    function addStepper(parent, getNumberInput, stepOptions) {
        var stepperGroup = parent.add("group");
        stepperGroup.orientation = "column";
        stepperGroup.spacing = 0; /* 2つのボタンをつなげて1つの枠に見せる / join the buttons into one frame */
        stepperGroup.margins = [STEPPER_SIDE_MARGIN, 0, 0, 0]; /* 右は入力欄に突き合わせる / butt against the field on the right */
        stepperGroup.alignment = ["left", "center"];

        /**
         * 入力欄の値を増減する（shift を押しながらなら STEPPER_SHIFT_MULTIPLE の倍数へ、option なら STEPPER_OPTION_STEP ずつ。下限・上限で止める）
         * @param {number} direction - 増やすなら 1、減らすなら -1
         * @returns {void}
         */
        function stepBy(direction) {
            var numberInput = getNumberInput();
            if (!isStepperEnabledInTree(numberInput)) return; /* 入力欄か親が無効の間は動かさない */
            var value = evaluateArithmetic(numberInput.text, stepOptions.unit); /* 確定前の計算式も計算してから増減 / evaluate an uncommitted expression first */
            if (isNaN(value)) value = parseFloat(numberInput.text); /* 計算できなければ従来どおり先頭の数値 / fall back to the leading number */
            if (isNaN(value)) value = 0;
            writeSteppedValue(numberInput, computeSteppedValue(value, direction, stepOptions), stepOptions);
            if (stepOptions.onStep) stepOptions.onStep(numberInput);
        }

        /**
         * ∧∨を離したときに入力欄へフォーカスを移す（mousedown で移しても、離したときに外れる）
         * @param {Group} chevronButton - makeStepperChevronButton() で作ったボタン
         * @returns {Group} 渡したボタン
         */
        function focusInputOnRelease(chevronButton) {
            chevronButton.addEventListener("mouseup", function () {
                var numberInput = getNumberInput();
                if (isStepperEnabledInTree(numberInput)) focusNumberInput(numberInput);
            });
            return chevronButton;
        }

        /* 整数の欄では option＋クリックの0.1刻みが効かないので、説明から外す / integer fields have no 0.1 step */
        var upTooltip = stepOptions.integer ? LABELS.tooltip.stepUpInteger : LABELS.tooltip.stepUp;
        var downTooltip = stepOptions.integer ? LABELS.tooltip.stepDownInteger : LABELS.tooltip.stepDown;
        focusInputOnRelease(makeStepperChevronButton(stepperGroup, "up", function () { stepBy(1); })).helpTip = getLabel(upTooltip);
        focusInputOnRelease(makeStepperChevronButton(stepperGroup, "down", function () { stepBy(-1); })).helpTip = getLabel(downTooltip);
        stepperGroup.stepBy = stepBy; /* ↑↓キーからも同じ処理で増減できるよう公開 / shared with the arrow keys */
        stepperGroup.stepOptions = stepOptions; /* 確定時の計算で欄の単位を引けるよう公開 / lets the commit-time evaluation find the unit */
        return stepperGroup;
    }

    /**
     * 入力欄の↑↓キーを、∧∨と同じ処理で増減させる。ほかのキーは素通し。
     * あわせて、確定時に計算式・単位付きの値を計算して書き戻す（各スクリプトの onChange より先に呼ばれるので、onChange は計算後の値を読む）
     * @param {EditText} numberInput - 対象の入力欄
     * @param {Group} stepperGroup - addStepper() で作った∧∨
     * @returns {void}
     */
    function bindSteppedArrowKeys(numberInput, stepperGroup) {
        numberInput.addEventListener("keydown", function (event) {
            if (event.keyName !== "Up" && event.keyName !== "Down") return;
            stepperGroup.stepBy(event.keyName === "Up" ? 1 : -1);
            event.preventDefault(); /* カーソル移動を止める / keep the caret from moving */
        });
        numberInput.addEventListener("change", function () {
            var fieldUnit = stepperGroup.stepOptions ? stepperGroup.stepOptions.unit : undefined;
            var value = evaluateArithmetic(numberInput.text, fieldUnit);
            if (isNaN(value)) return; /* 計算できなければ各スクリプトの処理に任せる / leave it to the script's own handler */
            /* 式か、換算で値が変わったときだけ書き戻す（ただの数値は書式を崩さない） / rewrite only expressions and converted values */
            var hasOperator = /[*\/()\u00D7\u00F7\uFF0A\uFF0F\uFF08\uFF09]|[\d.\uFF10-\uFF19][^\d.\uFF10-\uFF19]*[+\-\u2212\uFF0B\uFF0D]/.test(numberInput.text);
            if (!hasOperator && value === parseFloat(numberInput.text)) return;
            numberInput.text = formatStepperNumber(value) + (fieldUnit || "");
        });
    }

    // -----------------------------------------
    // 値の計算 / Value helpers
    // -----------------------------------------
    /**
     * 押された修飾キーに応じて、1回分増減した値を返す
     * （shift なら STEPPER_SHIFT_MULTIPLE の倍数へ、option なら STEPPER_OPTION_STEP ずつ、それ以外は step の倍数へ（1.5→2、1.5→1）。
     * 整数の欄では option を無視して step の倍数へ）
     * @param {number} value - 元の値
     * @param {number} direction - 増やすなら 1、減らすなら -1
     * @param {Object} stepOptions - step（通常の増減量。省略時は 1）/ integer
     * @returns {number} 増減した値（下限・上限は未適用）
     */
    function computeSteppedValue(value, direction, stepOptions) {
        var keyState = ScriptUI.environment.keyboardState;
        if (keyState.shiftKey) return snapStepperToNextMultiple(value, STEPPER_SHIFT_MULTIPLE, direction);
        if (keyState.altKey && !stepOptions.integer) return value + direction * STEPPER_OPTION_STEP;
        return snapStepperToNextMultiple(value, stepOptions.step || 1, direction);
    }

    /**
     * 値を、指定した方向にある次の倍数へ移す（230→240、232→240、下げるときは 232→230、230→220）
     * @param {number} value - 元の値
     * @param {number} multiple - 倍数の単位（例 10）
     * @param {number} direction - 上げるなら 1、下げるなら -1
     * @returns {number} 移した値
     */
    function snapStepperToNextMultiple(value, multiple, direction) {
        /* 0.29 / 0.01 = 28.999… のような浮動小数の誤差で同じ値に戻らないよう、商を丸めてから切り捨て・切り上げる
           round the quotient first so float error (0.29 / 0.01 = 28.999…) does not step back to the same value */
        var quotient = Math.round(value / multiple * 1e6) / 1e6;
        if (direction > 0) return Math.round((Math.floor(quotient) + 1) * multiple * 1e6) / 1e6;
        return Math.round((Math.ceil(quotient) - 1) * multiple * 1e6) / 1e6;
    }

    /**
     * 値を下限・上限の範囲に収める
     * @param {number} value - 数値
     * @param {Object} rangeOptions - min / max（どちらも省略可）
     * @returns {number} 範囲に収めた値
     */
    function clampSteppedValue(value, rangeOptions) {
        if (rangeOptions.min !== undefined && value < rangeOptions.min) return rangeOptions.min;
        if (rangeOptions.max !== undefined && value > rangeOptions.max) return rangeOptions.max;
        return value;
    }

    /**
     * 入力欄の文字列を四則演算（+ - * / と括弧）として計算する。eval は使わない。
     * 数値の後ろの単位は UnitValue で欄の単位へ換算する（mm の欄に「1in」→ 25.4、「1p6」は1パイカ6ポイント）。単位のない数値は欄の単位とみなす。
     * 全角の数字・記号と × ÷ は半角に直す
     * @param {string} text - 入力欄の文字列
     * @param {string} [fieldUnit] - 欄の単位（例 " mm"。前後の空白は無視）
     * @returns {number} 欄の単位での計算結果（式として読めない・換算できない単位・0で割ったときは NaN）
     */
    function evaluateArithmetic(text, fieldUnit) {
        var source = String(text)
            .replace(/[！-～]/g, function (ch) { return String.fromCharCode(ch.charCodeAt(0) - 0xFEE0); })
            .replace(/×/g, "*")
            .replace(/÷/g, "/")
            .replace(/[−–—]/g, "-")
            .replace(/\s/g, "");
        if (source === "") return NaN;
        var fieldUnitKey = String(fieldUnit || "").replace(/^\s+|\s+$/g, "").toLowerCase();
        var fieldUnitValue = createStepperUnitValue(1, fieldUnitKey); /* 欄の単位の1単位（換算できない欄は null） / one field unit */
        var position = 0;

        /**
         * 加減算の並び（項 ± 項 …）を読む
         * @returns {number} 値（読めなければ NaN）
         */
        function readSum() {
            var total = readProduct();
            while (position < source.length && (source.charAt(position) === "+" || source.charAt(position) === "-")) {
                var operator = source.charAt(position++);
                var operand = readProduct();
                total = (operator === "+") ? total + operand : total - operand;
            }
            return total;
        }

        /**
         * 乗除算の並び（因子 × 因子 …）を読む
         * @returns {number} 値（読めなければ NaN）
         */
        function readProduct() {
            var total = readFactor();
            while (position < source.length && (source.charAt(position) === "*" || source.charAt(position) === "/")) {
                var operator = source.charAt(position++);
                var operand = readFactor();
                if (operator === "/" && operand === 0) return NaN;
                total = (operator === "*") ? total * operand : total / operand;
            }
            return total;
        }

        /**
         * 符号付きの数値（単位付きなら欄の単位へ換算）か、括弧で囲んだ式を読む
         * @returns {number} 値（読めなければ NaN）
         */
        function readFactor() {
            var ch = source.charAt(position);
            if (ch === "+" || ch === "-") {
                position++;
                var signedValue = readFactor();
                return (ch === "-") ? -signedValue : signedValue;
            }
            if (ch === "(") {
                position++;
                var innerValue = readSum();
                if (source.charAt(position) !== ")") return NaN;
                position++;
                return innerValue;
            }
            var numberMatch = /^(\d+\.?\d*|\.\d+)/.exec(source.substring(position));
            if (!numberMatch) return NaN;
            position += numberMatch[0].length;
            return readUnitSuffix(parseFloat(numberMatch[0]));
        }

        /**
         * 数値の直後の単位を読み、欄の単位へ換算する
         * @param {number} value - 単位の前の数値
         * @returns {number} 欄の単位での値（換算できない単位なら NaN）
         */
        function readUnitSuffix(value) {
            var unitMatch = /^([A-Za-z]+|%|°)/.exec(source.substring(position));
            if (!unitMatch) return value; /* 単位なしは欄の単位 / no unit means the field's unit */
            position += unitMatch[0].length;
            var unitKey = unitMatch[0].toLowerCase();
            if (unitKey === fieldUnitKey) return value;
            var typedValue = createStepperUnitValue(value, unitKey);
            if (!typedValue || !fieldUnitValue) return NaN; /* 知らない単位・単位のない欄 / unknown unit or unitless field */
            var points = typedValue.as("pt");
            /* 「1p6」＝1パイカ6ポイント / pica-point notation */
            if (unitKey === "p") {
                var pointMatch = /^(\d+\.?\d*|\.\d+)/.exec(source.substring(position));
                if (pointMatch) {
                    position += pointMatch[0].length;
                    points += parseFloat(pointMatch[0]);
                }
            }
            return points / fieldUnitValue.as("pt");
        }

        var result = readSum();
        if (position !== source.length || !isFinite(result)) return NaN; /* 読み残しがあれば式として不正 / leftovers mean a malformed expression */
        return result;
    }

    /**
     * 数値と単位から UnitValue を作る。Q・H・p は STEPPER_UNIT_ALIASES で UnitValue の単位に読み替える。
     * %（percent）は基準の長さが無いと換算できないので扱わない
     * @param {number} value - 数値
     * @param {string} unitKey - 単位（小文字。例 "mm"、"inches"、"q"）
     * @returns {UnitValue|null} UnitValue（UnitValue が知らない単位・空・% なら null）
     */
    function createStepperUnitValue(value, unitKey) {
        if (unitKey === "" || unitKey === "%") return null;
        var alias = STEPPER_UNIT_ALIASES[unitKey];
        var unitValue = alias ? new UnitValue(value * alias.amount, alias.unit) : new UnitValue(value, unitKey);
        if (unitValue.type === "?" || unitValue.type === "%") return null; /* 知らない単位は例外にならず "?" になる。"percent" も除く / unknown units become "?" */
        return unitValue;
    }

    /**
     * 値を整数化・下限・上限でそろえ、単位を付けて入力欄に書き込む（直前の正しい値としても控える）
     * @param {EditText} numberInput - 書き込む入力欄
     * @param {number} value - 数値
     * @param {Object} valueOptions - integer / min / max / unit（どれも省略可）
     * @returns {void}
     */
    function writeSteppedValue(numberInput, value, valueOptions) {
        numberInput.text = formatSteppedValue(value, valueOptions);
        numberInput.lastValidText = numberInput.text;
    }

    /**
     * 値を整数化・下限・上限でそろえ、丸めて単位を付けた表示用の文字列にする。
     * 整数化してから下限で止めるので、「整数・下限1」の欄に 0.4 が入っても 1 になる
     * @param {number} value - 数値
     * @param {Object} valueOptions - integer / min / max / unit（どれも省略可）
     * @returns {string} 入力欄に入れる文字列（例 "20 mm"）
     */
    function formatSteppedValue(value, valueOptions) {
        if (valueOptions.integer) value = Math.round(value);
        return formatStepperNumber(clampSteppedValue(value, valueOptions)) + (valueOptions.unit || "");
    }

    /**
     * 小数第2位で丸めた数値を文字列で返す
     * @param {number} value - 数値
     * @returns {string} 表示用の数値文字列
     */
    function formatStepperNumber(value) {
        return String(Math.round(value * 100) / 100);
    }

    // -----------------------------------------
    // ∧∨ボタンの描画 / Drawing
    // -----------------------------------------
    /**
     * 山形（∧／∨）の極小ボタンを作成する。
     * 上下2つを隙間なく積んで1つの枠に見えるよう、枠線は外側の辺だけ描き（上ボタンは上側、下ボタンは下側）、
     * 継ぎ目に線は引かない
     * @param {Group|Panel} parent - 追加先
     * @param {string} direction - "up" または "down"
     * @param {Function} onClickFn - クリック時の処理
     * @returns {Group} ボタンとして使う group
     */
    function makeStepperChevronButton(parent, direction, onClickFn) {
        var buttonWidth = STEPPER_BUTTON_WIDTH;
        var buttonHeight = STEPPER_BUTTON_HEIGHT;
        var isUp = (direction === "up");
        var chevronBox = parent.add("group");
        chevronBox.margins = 0;
        chevronBox.spacing = 0;
        chevronBox.preferredSize = [buttonWidth, buttonHeight];
        chevronBox.minimumSize = [buttonWidth, buttonHeight];
        chevronBox.maximumSize = [buttonWidth, buttonHeight];
        chevronBox.isPressed = false;
        chevronBox.isStepperButton = true; /* redrawSteppersIn() の目印 / marker for redrawSteppersIn() */

        chevronBox.onDraw = function () {
            var boxGraphics = chevronBox.graphics;
            /* 自作描画は自動でディムにならないため、無効なら薄い色で描く。親の無効化は子の enabled に出ないので親も見る
               Custom drawing is not dimmed automatically; the parent's state does not reach the child's enabled */
            var isDimmed = !isStepperEnabledInTree(chevronBox);

            /* 枠線の内側の地（押下中は押下色） / background inside the frame, pressed color while pressed */
            var fillColor = isDimmed ? STEPPER_DIM_FILL_COLOR : (chevronBox.isPressed ? STEPPER_PRESSED_COLOR : STEPPER_FILL_COLOR);
            boxGraphics.newPath();
            boxGraphics.rectPath(1, isUp ? 1 : 0, buttonWidth - 2, buttonHeight - 1);
            boxGraphics.fillPath(boxGraphics.newBrush(boxGraphics.BrushType.SOLID_COLOR, fillColor));

            drawStepperFrame(boxGraphics, buttonWidth, buttonHeight, isUp, isDimmed ? STEPPER_DIM_FRAME_COLOR : STEPPER_FRAME_COLOR);
            drawStepperChevron(boxGraphics, buttonWidth, buttonHeight, isUp, isDimmed ? STEPPER_DIM_CHEVRON_COLOR : STEPPER_CHEVRON_COLOR);
        };

        /**
         * 押下状態を変えて描き直す
         * @param {boolean} isPressed - 押下中なら true
         * @returns {void}
         */
        function repaint(isPressed) {
            if (chevronBox.isPressed === isPressed) return;
            chevronBox.isPressed = isPressed;
            redrawStepperGroup(chevronBox);
        }
        chevronBox.addEventListener("mousedown", function () {
            if (!isStepperEnabledInTree(chevronBox)) return;
            repaint(true);
            if (onClickFn) onClickFn();
        });
        chevronBox.addEventListener("mouseup", function () { repaint(false); });
        /* 押したまま外へ出たときも押下色を残さない / reset when the pointer leaves while pressed */
        chevronBox.addEventListener("mouseout", function () { repaint(false); });
        return chevronBox;
    }

    /**
     * 外側の辺だけの枠を描く（角は丸める）。継ぎ目側は開けておき、上下2つで1つの枠に見せる。
     * ScriptUI は円弧を描けないため、角丸は短い線分で近似する
     * @param {ScriptUIGraphics} boxGraphics - 描画先
     * @param {number} boxWidth - ボタンの幅
     * @param {number} boxHeight - ボタンの高さ
     * @param {boolean} isUp - 上のボタンなら true（上側に枠を描く）
     * @param {number[]} frameColor - [r, g, b, a]
     * @returns {void}
     */
    function drawStepperFrame(boxGraphics, boxWidth, boxHeight, isUp, frameColor) {
        var frameLeft = 0.5;
        var frameRight = boxWidth - 0.5;
        var outerY = isUp ? 0.5 : boxHeight - 0.5;
        var seamY = isUp ? boxHeight : 0;
        var towardSeam = isUp ? 1 : -1; /* 外側の辺から継ぎ目へ向かう向き / direction from the outer edge to the seam */
        var radius = STEPPER_CORNER_RADIUS;
        var arcSteps = 4; /* 角丸1つを何本の線分で近似するか / segments per corner */
        var angle, k;

        boxGraphics.newPath();
        boxGraphics.moveTo(frameLeft, seamY);
        /* 左の角丸 / left corner */
        for (k = 0; k <= arcSteps; k++) {
            angle = (Math.PI / 2) * k / arcSteps;
            boxGraphics.lineTo(frameLeft + radius - radius * Math.cos(angle), outerY + towardSeam * (radius - radius * Math.sin(angle)));
        }
        /* 右の角丸 / right corner */
        for (k = 0; k <= arcSteps; k++) {
            angle = (Math.PI / 2) * k / arcSteps;
            boxGraphics.lineTo(frameRight - radius + radius * Math.sin(angle), outerY + towardSeam * (radius - radius * Math.cos(angle)));
        }
        boxGraphics.lineTo(frameRight, seamY);
        boxGraphics.strokePath(boxGraphics.newPen(boxGraphics.PenType.SOLID_COLOR, frameColor, 1));
    }

    /**
     * 山形（∧／∨）を描く。文字グリフの▲▼は上下で大きさやベースラインが揃わないため、線で描く
     * @param {ScriptUIGraphics} boxGraphics - 描画先
     * @param {number} boxWidth - ボタンの幅
     * @param {number} boxHeight - ボタンの高さ
     * @param {boolean} isUp - ∧なら true、∨なら false
     * @param {number[]} chevronColor - [r, g, b, a]
     * @returns {void}
     */
    function drawStepperChevron(boxGraphics, boxWidth, boxHeight, isUp, chevronColor) {
        var centerX = boxWidth / 2;
        var centerY = isUp ? boxHeight / 2 + 0.5 : boxHeight / 2 - 0.5; /* 継ぎ目から少し離す / nudged away from the seam */
        var halfWidth = 3.6; /* 山形の半幅（高さ1.8に対して開き約127°） / half width of the chevron */
        var tipOffsetY = isUp ? -1.8 : 1.8; /* 頂点の中心からのずれ（上向きは上、下向きは下） */
        boxGraphics.newPath();
        boxGraphics.moveTo(centerX - halfWidth, centerY - tipOffsetY);
        boxGraphics.lineTo(centerX, centerY + tipOffsetY);
        boxGraphics.lineTo(centerX + halfWidth, centerY - tipOffsetY);
        boxGraphics.strokePath(boxGraphics.newPen(boxGraphics.PenType.SOLID_COLOR, chevronColor, 1.2));
    }

    /**
     * 入力欄にフォーカスを移す
     * @param {EditText} numberInput - 対象の入力欄
     * @returns {void}
     */
    function focusNumberInput(numberInput) {
        numberInput.active = false; /* 一度外さないとフォーカスが移らないことがある / reset first or focus may not move */
        numberInput.active = true;
    }

    /**
     * コントロールと、その親をたどってすべて有効かを返す（親の無効化は子の enabled に出ない）
     * @param {Object} control - 対象のコントロール
     * @returns {boolean} すべて有効なら true
     */
    function isStepperEnabledInTree(control) {
        for (var node = control; node; node = node.parent) {
            if (!node.enabled) return false;
        }
        return true;
    }

    /**
     * コンテナ以下にある∧∨ボタンをすべて描き直す。行やパネルの enabled を切り替えたあとに呼ぶ
     * @param {Object} container - 行・グループ・パネルなど
     * @returns {void}
     */
    function redrawSteppersIn(container) {
        if (!container.children) return;
        for (var i = 0; i < container.children.length; i++) {
            var child = container.children[i];
            if (child.isStepperButton) redrawStepperGroup(child);
            else redrawSteppersIn(child);
        }
    }

    /**
     * group の onDraw を呼び直す。group には notify() が無いため、隠して再表示して描き直させる
     * @param {Group} targetGroup - 描き直す group
     * @returns {void}
     */
    function redrawStepperGroup(targetGroup) {
        targetGroup.hide();
        targetGroup.show();
    }

    // ステップボタン（再利用パーツ）ここまで / End of the reusable stepper

    (function () {
        // ドキュメントが開かれているか確認
        if (app.documents.length === 0) {
            alert(getLabel("alertOpenDoc"));
            return;
        }

        var doc = app.activeDocument;
        var currentSelection = doc.selection;

        // 2つのオブジェクトが選択されているか確認
        if (!currentSelection || currentSelection.length !== 2) {
            alert(getLabel("alertSelectTwoItems"));
            return;
        }

        // --- Temporary marker (cleanup) / 一時生成物マーカー（後片付け） ---
        var TEMP_NOTE = "__SplitBackgroundForTwo_TEMP__";

        // --- Preview marker (cleanup) / プレビューマーカー（後片付け） ---
        var PREVIEW_NOTE = "__SplitBackgroundForTwo_PREVIEW__";

        function markPreview(item) {
            if (!item) return;
            try { item.note = PREVIEW_NOTE; } catch (e0) { }
        }

        function removeMarkedPreviewItems(doc) {
            try {
                for (var i = doc.pageItems.length - 1; i >= 0; i--) {
                    var it = doc.pageItems[i];
                    var isMarked = false;
                    try { isMarked = (it.note === PREVIEW_NOTE); } catch (eNote) { isMarked = false; }
                    if (isMarked) {
                        unlockAndShow(it);
                        try { it.remove(); } catch (eRm) { }
                    }
                }
            } catch (eLoop) { }
        }

        function unlockAndShow(item) {
            if (!item) return;
            try { item.locked = false; } catch (e1) { }
            try { item.hidden = false; } catch (e2) { }
            // Layer / PageItem
            try {
                item.visible = true;
            } catch (e) {}

            // Layer-specific flags (available on Layer)
            try { item.template = false; } catch (e4) { }
            try { item.printable = true; } catch (e5) { }
        }

        function markTemp(item) {
            if (!item) return;
            try { item.note = TEMP_NOTE; } catch (e0) { }

            // Mark children if possible (GroupItem etc.)
            try {
                if (item.pageItems && item.pageItems.length) {
                    for (var i = item.pageItems.length - 1; i >= 0; i--) {
                        markTemp(item.pageItems[i]);
                    }
                }
            } catch (eChildren) { }
        }

        function removeMarkedTempItems(doc) {
            // Remove any pageItems in the document that are marked (even if created outside temp layer)
            try {
                for (var i = doc.pageItems.length - 1; i >= 0; i--) {
                    var it = doc.pageItems[i];
                    var isMarked = false;
                    try { isMarked = (it.note === TEMP_NOTE); } catch (eNote) { isMarked = false; }
                    if (isMarked) {
                        unlockAndShow(it);
                        try { it.remove(); } catch (eRm) { }
                    }
                }
            } catch (eLoop) { }
        }

        /**
         * テキストを「一時グループ」へ複製→アウトライン化し、その外接矩形を返す。
         * 返り値には後片付け用に一時生成物（複製テキスト／アウトライン）も含める。
         * 元のテキストは変更しない。
         * @param {TextFrame} tf
         * @param {GroupItem} tempGroup - 一時生成物を格納するグループ
         * @returns {{bounds:number[], outline:PageItem|null, duplicateText:TextFrame}}
         */
        function getOutlineBoundsFromText(tf, tempGroup) {
            // 一時レイヤーへ複製（元の階層を汚さない）
            var dup = tf.duplicate(tempGroup, ElementPlacement.PLACEATBEGINNING);

            markTemp(dup);
            unlockAndShow(dup);

            // アウトライン化（結果は一時レイヤー内に生成される想定）
            var outlineItem = null;
            try {
                outlineItem = dup.createOutline();
                if (outlineItem) {
                    markTemp(outlineItem);
                    unlockAndShow(outlineItem);
                    // In some environments outline may be created outside; move it into tempLayer when possible
                    try {
                        if (outlineItem.parent !== tempGroup) {
                            outlineItem.move(tempGroup, ElementPlacement.PLACEATBEGINNING);
                        }
                    } catch (eMove) { }
                }
            } catch (eOutline) {
                outlineItem = null;
            }

            if (!outlineItem) {
                // Ensure the duplicate itself is marked
                markTemp(dup);
            }

            // bounds 取得対象：基本はアウトライン化結果、取れない場合は複製テキスト
            var target = outlineItem ? outlineItem : dup;
            var b = target.geometricBounds; // [left, top, right, bottom]

            // ここでは削除しない（呼び出し側で安全に削除する）
            return {
                bounds: [b[0], b[1], b[2], b[3]],
                outline: outlineItem,
                duplicateText: dup
            };
        }

        /**
         * 任意オブジェクトの外接矩形（geometricBounds）を取得する。
         * TextFrame の場合はアウトライン化した複製から取得して精度を上げる。
         * それ以外（パス、グループ等）は複製の geometricBounds を使う。
         * @param {PageItem} item
         * @param {GroupItem} tempGroup
         * @returns {{bounds:number[], outline:PageItem|null, duplicateItem:PageItem}}
         */
        function getBoundsInfo(item, tempGroup) {
            if (!item) {
                return { bounds: [0, 0, 0, 0], outline: null, duplicateItem: null };
            }

            if (item.typename === "TextFrame") {
                var info = getOutlineBoundsFromText(item, tempGroup);
                return {
                    bounds: info.bounds,
                    outline: info.outline,
                    duplicateItem: info.duplicateText
                };
            }

            // Non-text: duplicate and read geometricBounds
            var dup = item.duplicate(tempGroup, ElementPlacement.PLACEATBEGINNING);
            markTemp(dup);
            unlockAndShow(dup);

            var b = dup.geometricBounds;
            return {
                bounds: [b[0], b[1], b[2], b[3]],
                outline: null,
                duplicateItem: dup
            };
        }

        /* 左位置を取得 / Get left position */
        function getItemLeft(item) {
            try {
                if (item && item.geometricBounds && item.geometricBounds.length >= 4) {
                    return item.geometricBounds[0];
                }
            } catch (e) { }
            try { return item.left; } catch (e2) { }
            return 0;
        }

        // 色の定義 (RGB)
        var colorLeft = new RGBColor();
        colorLeft.red = 220; colorLeft.green = 220; colorLeft.blue = 220; // 薄いグレー

        var colorRight = new RGBColor();
        colorRight.red = 128; colorRight.green = 128; colorRight.blue = 128; // 濃いグレー

        // K100 (CMYK) for frame / 枠線用 K100
        var colorK100 = new CMYKColor();
        colorK100.cyan = 0;
        colorK100.magenta = 0;
        colorK100.yellow = 0;
        colorK100.black = 100;

        // Round Corners Live Effect (for Overall Frame only) / 角丸（ライブエフェクト：全体の枠のみ）
        function createRoundCornersEffectXML(radius) {
            var xml = '<LiveEffect name="Adobe Round Corners"><Dict data="R radius #value# "/></LiveEffect>';
            return xml.replace('#value#', radius);
        }

        function applyRoundCornersIfNeeded(item, radius) {
            if (!item) return;
            var r = Number(radius);
            if (isNaN(r) || r <= 0) return;
            try {
                var xml = createRoundCornersEffectXML(r);
                item.applyEffect(xml);
            } catch (e) { }
        }

        // --- Fill corner rounding (Left: LT/LB, Right: RT/RB) / 塗りの角丸（左=左上/左下、右=右上/右下） ---
        function clearAnchorSelection(pathItem) {
            if (!pathItem || !pathItem.pathPoints) return;
            try {
                var pp = pathItem.pathPoints;
                for (var i = 0; i < pp.length; i++) {
                    pp[i].selected = PathPointSelection.NOSELECTION;
                }
            } catch (e) { }
        }

        function selectRightCornersForRectangles(paths) {
            for (var i = 0; i < paths.length; i++) {
                var it = paths[i];
                if (!it || it.typename !== "PathItem" || !it.closed) continue;
                var pp = it.pathPoints;
                if (!pp || pp.length !== 4) continue;

                var currentSelection = 0;
                for (var a = 0; a < 4; a++) if (pp[a].selected === PathPointSelection.ANCHORPOINT) currentSelection++;
                if (currentSelection > 0 && currentSelection < 4) continue; // respect partial anchor selection

                var idx = [0, 1, 2, 3];
                idx.sort(function (x, y) { return pp[x].anchor[0] - pp[y].anchor[0]; });
                var a2 = idx[2], a3 = idx[3];
                var top = (pp[a2].anchor[1] >= pp[a3].anchor[1]) ? a2 : a3;
                var bot = (top === a2) ? a3 : a2;

                for (a = 0; a < 4; a++) pp[a].selected = PathPointSelection.NOSELECTION;
                pp[top].selected = PathPointSelection.ANCHORPOINT;
                pp[bot].selected = PathPointSelection.ANCHORPOINT;
            }
        }

        function applyFillCornerRounding(pathItem, side, radiusPt) {
            if (!pathItem) return;
            var r = Number(radiusPt);
            if (isNaN(r) || r <= 0) return;

            // Use roundAnyCorner algorithm: it rounds only selected corner anchors.
            clearAnchorSelection(pathItem);
            if (side === "left") {
                selectLeftCornersForRectangles([pathItem]);
            } else if (side === "right") {
                selectRightCornersForRectangles([pathItem]);
            } else {
                return;
            }

            try {
                roundAnyCorner([pathItem], { rr: r });
            } catch (e) { }

            // Clean selection on the new rect
            clearAnchorSelection(pathItem);
        }

        // 選択オブジェクトの位置関係を整理（左側にあるものをitem1、右側をitem2とする）
        var item1, item2;
        if (getItemLeft(currentSelection[0]) < getItemLeft(currentSelection[1])) {
            item1 = currentSelection[0];
            item2 = currentSelection[1];
        } else {
            item1 = currentSelection[1];
            item2 = currentSelection[0];
        }

        // --- 背景を置くターゲットレイヤーの決定 ---
        function getLayerIndex(doc, layer) {
            for (var i = 0; i < doc.layers.length; i++) {
                if (doc.layers[i] === layer) return i;
            }
            return -1;
        }

        // レイヤーの前後関係をインデックスで推定する
        // Illustratorのlayers配列は基本的に「上（前面）→下（背面）」順で並ぶ想定。
        // よって、インデックスが大きいほど背面寄りとみなす。
        function getBackmostLayer(doc, layerA, layerB) {
            var ia = getLayerIndex(doc, layerA);
            var ib = getLayerIndex(doc, layerB);
            if (ia < 0) return layerB;
            if (ib < 0) return layerA;
            return (ia > ib) ? layerA : layerB;
        }

        var targetLayerForBackground = getBackmostLayer(doc, item1.layer, item2.layer);

        function safeRedraw() {
            app.redraw();
        }

        // --- プレビュー状態 ---
        var previewRect1 = null;
        var previewRect2 = null;
        var previewFrame = null;
        var previewDivider = null;
        var previewApplied = false;
        var lastPreviewPercent = null;
        var lastOverallFrame = false;
        var lastDivider = false;
        var lastFillLeft = true;
        var lastFillRight = true;
        var lastStrokeWidth = 1;
        var lastCornerRadius = 0;
        var lastBalanceMode = 'none'; // 'none' | 'left' | 'right'
        var lastWidthPercent = 0;     // Width in pt (from rulerType UI)

        // ==============================
        // PreviewManager (Undo-based)
        // プレビュー時にUndo履歴を汚さないための簡易マネージャ
        // - プレビュー更新前に rollback() で元に戻す
        // - OK時は confirm(finalAction) で一度戻してから本番を1回だけ実行
        // ==============================
        function PreviewManager() {
            this.undoDepth = 0;

            function getHistoryLen() {
                try {
                    return app.activeDocument && app.activeDocument.historyStates
                        ? app.activeDocument.historyStates.length
                        : 0;
                } catch (e) {
                    return 0;
                }
            }

            this.addStep = function (func) {
                var beforeLen = getHistoryLen();
                try {
                    func();
                    var afterLen = getHistoryLen();
                    var delta = afterLen - beforeLen;
                    if (delta < 1) delta = 1; // 保険
                    this.undoDepth += delta;
                    safeRedraw();
                } catch (e) {
                    // 失敗時は可能な限り巻き戻す
                    try { this.rollback(); } catch (e2) { }
                    alert("Preview Error: " + e);
                }
            };

            this.rollback = function () {
                while (this.undoDepth > 0) {
                    try { app.undo(); } catch (eU) { break; }
                    this.undoDepth--;
                }
                safeRedraw();
            };

            this.confirm = function (finalAction) {
                if (typeof finalAction === "function") {
                    // 一度プレビューを完全に戻してから、本番を1回だけ実行
                    this.rollback();
                    finalAction();
                    // 本番は「現在の状態」なので depth は 0 のままでOK
                    this.undoDepth = 0;
                    safeRedraw();
                } else {
                    // プレビュー状態をそのまま採用
                    this.undoDepth = 0;
                }
            };
        }

        var previewMgr = new PreviewManager();

        function clearPreviewRects() {
            // Undoベースでまず巻き戻す（履歴を汚さない）
            try { previewMgr.rollback(); } catch (eUndo) { }

            // 念のため、マーク済みプレビュー図形をドキュメント全体から掃除（保険）
            try { removeMarkedPreviewItems(doc); } catch (eMark) { }

            previewRect1 = null;
            previewRect2 = null;
            previewFrame = null;
            previewDivider = null;
            previewApplied = false;
            lastPreviewPercent = null;
            safeRedraw();
        }

        /**
         * アウトライン計算→背景長方形を作成（戻り値で生成物を返す）
         * @param {PageItem} leftText
         * @param {PageItem} rightText
         * @param {number} heightRatioValue
         * @param {boolean} addOverallFrame
         * @param {boolean} addDivider
         * @param {boolean} addFillLeft
         * @param {boolean} addFillRight
         * @param {number} strokeWidthValue
         * @param {number} cornerRadius
         * @returns {{rect1:PathItem|null, rect2:PathItem|null, frame:PathItem|null, divider:PathItem|null}}
         */
        function drawBackgroundRects(leftText, rightText, heightRatioValue, addOverallFrame, addDivider, addFillLeft, addFillRight, strokeWidthValue, cornerRadius, balanceMode, widthPercent) {        // --- 一時グループ（アウトライン生成用）---
            var originalActiveLayer = doc.activeLayer;

            // 一時グループを「既存レイヤー」内に作る（レイヤー残留問題を回避）
            var hostLayer = null;
            try { hostLayer = leftText.layer; } catch (eHL) { hostLayer = null; }
            if (!hostLayer) {
                try { hostLayer = doc.activeLayer; } catch (eHL2) { hostLayer = null; }
            }
            if (!hostLayer) {
                hostLayer = doc.layers[0];
            }

            unlockAndShow(hostLayer);
            var tempGroup = hostLayer.groupItems.add();
            tempGroup.name = "__temp_outline_group__";
            markTemp(tempGroup);
            // 見えにくくする（万一残っても視覚ノイズを下げる）
            try { tempGroup.opacity = 0; } catch (eOp) { }

            // 計算結果（この値だけ持ち帰って、アウトラインはすぐ消す）
            var rectTop, rectHeight;
            var rectLeftStart, gapCenter, rectRightEnd;

            try {
                var outline1Info = getBoundsInfo(leftText, tempGroup);
                var outline2Info = getBoundsInfo(rightText, tempGroup);

                var b1 = outline1Info.bounds;
                var b2 = outline2Info.bounds;

                // --- 計算が済んだら一時生成物を即削除（残留対策）---
                unlockAndShow(outline1Info.outline);
                unlockAndShow(outline1Info.duplicateItem);
                unlockAndShow(outline2Info.outline);
                unlockAndShow(outline2Info.duplicateItem);
                try { if (outline1Info.outline && outline1Info.outline.isValid) outline1Info.outline.remove(); } catch (eA) { }
                try { if (outline1Info.duplicateItem && outline1Info.duplicateItem.isValid) outline1Info.duplicateItem.remove(); } catch (eB) { }
                try { if (outline2Info.outline && outline2Info.outline.isValid) outline2Info.outline.remove(); } catch (eC) { }
                try { if (outline2Info.duplicateItem && outline2Info.duplicateItem.isValid) outline2Info.duplicateItem.remove(); } catch (eD) { }
                removeMarkedTempItems(doc);

                // 1. 高さの計算 (共通)
                var topLimit = Math.max(b1[1], b2[1]);
                var bottomLimit = Math.min(b1[3], b2[3]);

                var contentHeight = topLimit - bottomLimit;
                var centerY = topLimit - (contentHeight / 2);

                rectHeight = contentHeight * heightRatioValue;
                rectTop = centerY + (rectHeight / 2);

                // 2. 幅と隙間の計算（アウトライン bounds ベース）
                var item1Left = b1[0];
                var item1Right = b1[2];
                var item2Left = b2[0];
                var item2Right = b2[2];

                var gapDist = item2Left - item1Right;
                if (gapDist < 0) gapDist = 0;

                // --- Balance / margin control ---
                // widthPercent is treated as an absolute margin in pt.
                function clamp(v, mn, mx) {
                    if (v < mn) return mn;
                    if (v > mx) return mx;
                    return v;
                }

                var wPt = Number(widthPercent);
                if (isNaN(wPt) || wPt < 0) wPt = 0;

                var marginLeft = gapDist / 2;
                var marginRight = gapDist / 2;

                if (balanceMode === 'left') {
                    // 左の左右マージン = スライダー値
                    marginLeft = clamp(wPt, 0, gapDist);
                    // 右の左右マージン = gap - 左
                    marginRight = gapDist - marginLeft;

                } else if (balanceMode === 'right') {
                    // 右の左右マージン = スライダー値
                    marginRight = clamp(wPt, 0, gapDist);
                    // 左の左右マージン = gap - 右
                    marginLeft = gapDist - marginRight;

                } else {
                    // none => centered
                    marginLeft = gapDist / 2;
                    marginRight = gapDist / 2;
                }

                gapCenter = item1Right + marginLeft;
                rectLeftStart = item1Left - marginLeft;
                rectRightEnd = item2Right + marginRight;

            } finally {
                // 一時グループを確実に削除（レイヤー削除ではなくグループ削除で残留を防ぐ）
                try { doc.selection = null; } catch (eSel) { }

                try {
                    if (originalActiveLayer && originalActiveLayer.isValid) {
                        doc.activeLayer = originalActiveLayer;
                    }
                } catch (eRestore) { }

                // グループ内の残骸を掃除してから削除
                try {
                    unlockAndShow(tempGroup);
                    for (var gi = tempGroup.pageItems.length - 1; gi >= 0; gi--) {
                        try {
                            unlockAndShow(tempGroup.pageItems[gi]);
                            tempGroup.pageItems[gi].remove();
                        } catch (eRmPI) { }
                    }
                } catch (eClearG) { }

                try {
                    if (tempGroup && tempGroup.isValid) {
                        tempGroup.remove();
                    }
                } catch (eRemoveG) { }

                // 最終保険：マーク付き残骸をもう一度掃除
                removeMarkedTempItems(doc);
            }

            // --- ここから描画（アウトラインは既に削除済み）---
            // 背景長方形は必ずターゲットレイヤー直下に作成
            var leftLayer = null;
            var rightLayer = null;
            try { leftLayer = leftText.layer; } catch (eLL) { leftLayer = null; }
            try { rightLayer = rightText.layer; } catch (eRL) { rightLayer = null; }

            var rect1 = null;
            var rect2 = null;

            if (addFillLeft) {
                rect1 = (leftLayer ? leftLayer.pathItems : doc.pathItems).rectangle(
                    rectTop,
                    rectLeftStart,
                    gapCenter - rectLeftStart,
                    rectHeight
                );
                rect1.fillColor = colorLeft;
                rect1.stroked = false;
            }

            if (addFillRight) {
                rect2 = (rightLayer ? rightLayer.pathItems : doc.pathItems).rectangle(
                    rectTop,
                    gapCenter,
                    rectRightEnd - gapCenter,
                    rectHeight
                );
                rect2.fillColor = colorRight;
                rect2.stroked = false;
            }

            // 塗りの角丸（左=左上/左下、右=右上/右下） / Fill corner rounding
            if (cornerRadius && Number(cornerRadius) > 0) {
                if (rect1) applyFillCornerRounding(rect1, "left", cornerRadius);
                if (rect2) applyFillCornerRounding(rect2, "right", cornerRadius);
            }

            var frameRect = null;
            if (addOverallFrame) {
                // Create a single stroked rectangle that surrounds both background rectangles
                // 枠線：2つの背景を囲む単一の長方形（strokeWidthValue / K100）
                try {
                    var frameLayer = targetLayerForBackground || leftLayer || rightLayer;
                    frameRect = (frameLayer ? frameLayer.pathItems : doc.pathItems).rectangle(
                        rectTop,
                        rectLeftStart,
                        rectRightEnd - rectLeftStart,
                        rectHeight
                    );
                    frameRect.filled = false;
                    frameRect.stroked = true;
                    frameRect.strokeWidth = strokeWidthValue;
                    frameRect.strokeColor = colorK100;

                    // 角丸（全体の枠のみ） / Corner radius (Overall Frame only)
                    applyRoundCornersIfNeeded(frameRect, cornerRadius);

                    // Ensure frame is above the fill rectangles
                    try { frameRect.zOrder(ZOrderMethod.BRINGTOFRONT); } catch (eFZ) { }
                } catch (eFrame) {
                    frameRect = null;
                }
            }

            var dividerLine = null;
            if (addDivider) {
                // Divider line at the center boundary / 区切り線（中央境界）
                try {
                    var dividerLayer = targetLayerForBackground || leftLayer || rightLayer;
                    dividerLine = (dividerLayer ? dividerLayer.pathItems : doc.pathItems).add();
                    dividerLine.setEntirePath([
                        [gapCenter, rectTop],
                        [gapCenter, rectTop - rectHeight]
                    ]);
                    dividerLine.filled = false;
                    dividerLine.stroked = true;
                    dividerLine.strokeWidth = strokeWidthValue;
                    dividerLine.strokeColor = colorK100;
                    try { dividerLine.zOrder(ZOrderMethod.BRINGTOFRONT); } catch (eDZ) { }
                } catch (eDiv) {
                    dividerLine = null;
                }
            }

            // 背面へ（レイヤー内）
            try { if (rect1) rect1.zOrder(ZOrderMethod.SENDTOBACK); } catch (eZ1) { }
            try { if (rect2) rect2.zOrder(ZOrderMethod.SENDTOBACK); } catch (eZ2) { }

            // テキストを前面へ（同一レイヤー/同一親内での保証）
            try { leftText.zOrder(ZOrderMethod.BRINGTOFRONT); } catch (eT1) { }
            try { rightText.zOrder(ZOrderMethod.BRINGTOFRONT); } catch (eT2) { }

            safeRedraw();
            return { rect1: rect1, rect2: rect2, frame: frameRect, divider: dividerLine };
        }

        /**
         * ∧∨と入力欄を隙間0で突き合わせて並べる group を、行に足す
         * @param {Group} parentRow - 追加先の行
         * @returns {Group} ∧∨と入力欄を入れる group
         */
        function addStepperFieldGroup(parentRow) {
            var stepperFieldGroup = parentRow.add('group');
            stepperFieldGroup.orientation = 'row';
            stepperFieldGroup.alignChildren = ['left', 'center'];
            stepperFieldGroup.spacing = 0;
            stepperFieldGroup.margins = 0;
            return stepperFieldGroup;
        }

        // --- ダイアログ：高さ（%）指定（プレビュー付き）/ Dialog: Height (%) (with preview) ---
        /**
         * 高さ（%）を指定するダイアログ（プレビュー付き）
         * @param {number} defaultPercent
         * @param {Function} previewFn - function(percent:number, enabled:boolean, addOverallFrame:boolean, addDivider:boolean, addFillLeft:boolean, addFillRight:boolean, strokeWidth:number, cornerRadius:number):void
         * @param {Function} clearPreviewFn - function():void
         * @returns {number|null} percent (e.g. 140) or null if cancelled
         */
        function showHeightDialog(defaultPercent, previewFn, clearPreviewFn) {
            var dlg = new Window('dialog', getLabel('dialogTitle') + ' ' + SCRIPT_VERSION);
            setupWindow(dlg);

            var row = dlg.add('group');
            row.orientation = 'row';
            row.alignChildren = ['left', 'center'];
            // 高さ行は左右中央に / Center the height row horizontally
            row.alignment = ['center', 'top'];

            row.add('statictext', undefined, labelText('labelHeight'));

            // ∧∨・↑↓キーで値を増減（負数にはしない）/ Step with the stepper or arrow keys (never negative)
            var etStepperGroup = addStepperFieldGroup(row);
            var et;
            var etStepper = addStepper(etStepperGroup, function () { return et; }, { min: 0, onStep: applyPreview });
            et = etStepperGroup.add('edittext', undefined, String(defaultPercent));
            et.helpTip = getLabel('tipPercent');
            et.characters = 6;
            et.active = true;
            bindSteppedArrowKeys(et, etStepper);

            row.add('statictext', undefined, getLabel('labelPercent'));

            // --- 2カラム：左=描画 / 右=オプション ---
            var columns = dlg.add('group');
            columns.orientation = 'row';
            columns.alignChildren = ['fill', 'top'];
            columns.spacing = COLUMN_SPACING;

            // --- 描画オプション / Drawing options (Left column) ---
            var drawPanel = columns.add('panel', undefined, '描画');
            setupPanel(drawPanel, 6);

            var cbFillLeft = drawPanel.add('checkbox', undefined, getLabel('labelFillLeft'));
            cbFillLeft.helpTip = getLabel('tipFillSide');
            cbFillLeft.value = true;

            var cbFillRight = drawPanel.add('checkbox', undefined, getLabel('labelFillRight'));
            cbFillRight.helpTip = getLabel('tipFillSide');
            cbFillRight.value = true;

            var cbOverallFrame = drawPanel.add('checkbox', undefined, getLabel('labelOverallFrame'));
            cbOverallFrame.helpTip = getLabel('tipOverallFrame');
            cbOverallFrame.value = false;

            var cbDivider = drawPanel.add('checkbox', undefined, getLabel('labelDivider'));
            cbDivider.helpTip = getLabel('tipDivider');
            cbDivider.value = false;

            // --- 線オプション / Stroke options (Right column) ---
            var rightCol = columns.add('group');
            rightCol.orientation = 'column';
            rightCol.alignChildren = ['fill', 'top'];
            rightCol.spacing = 12;

            var linePanel = rightCol.add('panel', undefined, getLabel('panelLine'));
            setupPanel(linePanel);

            var lineRow = linePanel.add('group');
            lineRow.orientation = 'row';
            lineRow.alignChildren = ['left', 'center'];

            lineRow.add('statictext', undefined, getLabel('labelStrokeWidth'));
            // 小数可、∧∨・↑↓キーで増減（option で0.1ずつ）/ Decimals allowed; step with the stepper or arrow keys (0.1 with Option)
            var etStrokeStepperGroup = addStepperFieldGroup(lineRow);
            var etStroke;
            var etStrokeStepper = addStepper(etStrokeStepperGroup, function () { return etStroke; }, { min: 0, onStep: applyPreview });
            etStroke = etStrokeStepperGroup.add('edittext', undefined, formatUnitValue(ptToUnit(1, getUnitInfo("strokeUnits"))));
            etStroke.helpTip = getLabel('tipStroke');
            etStroke.characters = 4;
            bindSteppedArrowKeys(etStroke, etStrokeStepper);
            lineRow.add('statictext', undefined, getUnitInfo("strokeUnits").label);

            // 角丸 / Corner radius（枠のみロジック対応。塗りは追って）
            var cornerRow = linePanel.add('group');
            cornerRow.orientation = 'row';
            cornerRow.alignChildren = ['left', 'center'];

            cornerRow.add('statictext', undefined, getLabel('labelCornerRadius'));
            // ∧∨・↑↓キーで角丸値を増減（負数にはしない）/ Step the corner radius (never negative)
            var etCornerStepperGroup = addStepperFieldGroup(cornerRow);
            var etCorner;
            var etCornerStepper = addStepper(etCornerStepperGroup, function () { return etCorner; }, { min: 0, onStep: applyPreview });
            etCorner = etCornerStepperGroup.add('edittext', undefined, formatUnitValue(ptToUnit(0, getUnitInfo("rulerType"))));
            etCorner.helpTip = getLabel('tipCorner');
            etCorner.characters = 4;
            bindSteppedArrowKeys(etCorner, etCornerStepper);
            cornerRow.add('statictext', undefined, getUnitInfo("rulerType").label);

            // --- Helpers: enable/disable UI rows ---
            function updateStrokeWidthEnabled() {
                var on = !!(cbOverallFrame.value || cbDivider.value);
                // 両方OFFのときは線幅UIをディム表示 / Dim stroke width UI when both are OFF
                lineRow.enabled = on;
                redrawSteppersIn(lineRow);
            }

            function updateCornerEnabled() {
                var on = !!((cbFillLeft.value || cbFillRight.value) || cbOverallFrame.value);
                // 両方OFFのときは角丸UIをディム表示 / Dim corner radius UI when both are OFF
                cornerRow.enabled = on;
                redrawSteppersIn(cornerRow);
            }

            updateStrokeWidthEnabled();
            updateCornerEnabled();

            // --- バランス / Balance (full-width, spanning both columns) ---
            var pinPanel = dlg.add('panel', undefined, getLabel('panelFixed'));
            setupPanel(pinPanel);

            var pinRadioRow = pinPanel.add('group');
            pinRadioRow.orientation = 'row';
            pinRadioRow.alignChildren = ['left', 'center'];

            var rbPinNone = pinRadioRow.add('radiobutton', undefined, getLabel('fixedNone'));
            rbPinNone.helpTip = getLabel('tipPinNone');
            var rbPinLeft = pinRadioRow.add('radiobutton', undefined, getLabel('fixedLeft'));
            rbPinLeft.helpTip = getLabel('tipPinLeft');
            var rbPinRight = pinRadioRow.add('radiobutton', undefined, getLabel('fixedRight'));
            rbPinRight.helpTip = getLabel('tipPinRight');
            rbPinNone.value = true;

            // --- 幅 / Width (inside Balance panel) ---
            var pinWidthCol = pinPanel.add('group');
            pinWidthCol.orientation = 'column';
            pinWidthCol.alignChildren = ['fill', 'top'];
            pinWidthCol.spacing = 6;

            // Value row : 幅 [ value ] unit
            var pinWidthValueRow = pinWidthCol.add('group');
            pinWidthValueRow.orientation = 'row';
            pinWidthValueRow.alignChildren = ['left', 'center'];

            pinWidthValueRow.add('statictext', undefined, getLabel('labelWidth'));

            // ∧∨・↑↓キーで幅を増減し、スライダーを追従させてプレビュー更新（上限はスライダーの最大値）
            // Step the width, keep the slider in sync (capped at its max) and refresh the preview
            var etWidthStepperGroup = addStepperFieldGroup(pinWidthValueRow);
            var etWidth;
            var etWidthStepper = addStepper(etWidthStepperGroup, function () { return etWidth; }, {
                min: 0,
                onStep: function () { syncWidthUIFromEdit(); applyPreview(); }
            });
            etWidth = etWidthStepperGroup.add('edittext', undefined, '0');
            etWidth.helpTip = getLabel('tipWidth');
            etWidth.characters = 6;
            bindSteppedArrowKeys(etWidth, etWidthStepper);

            pinWidthValueRow.add('statictext', undefined, getUnitInfo("rulerType").label);

            // Slider row
            var pinWidthSliderRow = pinWidthCol.add('group');
            pinWidthSliderRow.orientation = 'row';
            pinWidthSliderRow.alignChildren = ['fill', 'center'];

            // Slider: 0 - max (will be set dynamically)
            var slWidth = pinWidthSliderRow.add('slider', undefined, 0, 0, 0); // max will be set dynamically
            slWidth.preferredSize = [220, 20];
            slWidth.helpTip = getLabel('tipWidthSlider');

            // Keep slider and edittext in sync (UI only)
            function clampWidthValue(v, forceInteger) {
                v = Number(v);
                if (isNaN(v)) return 0;
                if (v < 0) v = 0;

                var maxV = 0;
                try { maxV = Number(slWidth.maxvalue); } catch (eMax0) { maxV = 0; }
                if (isNaN(maxV) || maxV < 0) maxV = 0;

                if (v > maxV) v = maxV;

                if (forceInteger) {
                    return Math.round(v); // integer
                }
                return Math.round(v * 10) / 10; // keep 0.1 precision
            }

            function syncWidthUIFromSlider() {
                var kb = ScriptUI.environment.keyboardState;
                var forceInt = !!(kb && kb.altKey);
                var v = clampWidthValue(slWidth.value, forceInt);
                slWidth.value = v;
                etWidth.text = String(v);
            }

            function syncWidthUIFromEdit() {
                var v = clampWidthValue(etWidth.text, false);
                slWidth.value = v;
                etWidth.text = String(v);
            }

            // --- Compute and set the max value for the width slider based on selection ---
            function updateWidthSliderMaxBySelection() {
                // Width max should be the gap distance between the two objects (in rulerType units)
                // Use outline bounds for TextFrame to avoid side-bearing issues (same as main logic)
                var maxUnit = 0;
                var tempGroupForMax = null;
                try {
                    var hostLayer2 = null;
                    try { hostLayer2 = item1.layer; } catch (eHLm) { hostLayer2 = null; }
                    if (!hostLayer2) {
                        try { hostLayer2 = doc.activeLayer; } catch (eHLm2) { hostLayer2 = null; }
                    }
                    if (!hostLayer2) hostLayer2 = doc.layers[0];

                    unlockAndShow(hostLayer2);
                    tempGroupForMax = hostLayer2.groupItems.add();
                    tempGroupForMax.name = "__temp_outline_group_for_max__";
                    markTemp(tempGroupForMax);
                    try { tempGroupForMax.opacity = 0; } catch (eOpM) { }

                    var bi1 = getBoundsInfo(item1, tempGroupForMax);
                    var bi2 = getBoundsInfo(item2, tempGroupForMax);
                    var b1 = bi1.bounds;
                    var b2 = bi2.bounds;

                    // ensure left/right by x
                    var item1Right = b1[2];
                    var item2Left = b2[0];
                    var gapPt = item2Left - item1Right;
                    if (gapPt < 0) gapPt = 0;

                    maxUnit = ptToUnit(gapPt, getUnitInfo("rulerType"));
                    if (isNaN(maxUnit) || maxUnit < 0) maxUnit = 0;
                    // keep 0.1 in UI
                    maxUnit = Math.round(maxUnit * 10) / 10;

                } catch (eMax) {
                    maxUnit = 0;
                } finally {
                    // cleanup temp group
                    try { removeMarkedTempItems(doc); } catch (eRmTmp0) { }
                    try {
                        if (tempGroupForMax && tempGroupForMax.isValid) {
                            unlockAndShow(tempGroupForMax);
                            for (var giM = tempGroupForMax.pageItems.length - 1; giM >= 0; giM--) {
                                try {
                                    unlockAndShow(tempGroupForMax.pageItems[giM]);
                                    tempGroupForMax.pageItems[giM].remove();
                                } catch (eRmPI2) { }
                            }
                            tempGroupForMax.remove();
                        }
                    } catch (eRmTmp1) { }
                    try { removeMarkedTempItems(doc); } catch (eRmTmp2) { }
                }

                try { slWidth.maxvalue = maxUnit; } catch (eSetMax) { }
                // If max becomes 0, keep slider usable but effectively fixed at 0
                try { if (slWidth.maxvalue < 0) slWidth.maxvalue = 0; } catch (eSetMax2) { }

                // Clamp current UI value to new max
                syncWidthUIFromEdit();

                // When "None" is selected, row is disabled anyway; this is just the upper bound.
            }

            slWidth.onChanging = function () {
                syncWidthUIFromSlider();
                applyPreview(); // NOTE: logic will be wired later; keep preview refresh for now
            };

            etWidth.addEventListener('changing', function () {
                syncWidthUIFromEdit();
                applyPreview();
            });

            // --- Helpers: enable/disable width slider by balance selection ---
            function updateWidthEnabled() {
                // Disable width slider when "None" is selected
                pinWidthCol.enabled = !rbPinNone.value;
                redrawSteppersIn(pinWidthCol);
            }

            rbPinNone.onClick = function () { updateWidthEnabled(); applyPreview(); };
            rbPinLeft.onClick = function () { updateWidthEnabled(); applyPreview(); };
            rbPinRight.onClick = function () { updateWidthEnabled(); applyPreview(); };

            // Initial state
            updateWidthEnabled();

            // プレビューは一番下 / Preview at the bottom
            var cbPreview = dlg.add('checkbox', undefined, getLabel('labelPreview'));
            cbPreview.helpTip = getLabel('tipPreview');
            cbPreview.value = true;

            function parsePercent() {
                var v = Number(et.text);
                if (isNaN(v) || v <= 0) return null;
                return v;
            }

            function parseStrokeWidth() {
                var vUnit = Number(etStroke.text);
                if (isNaN(vUnit) || vUnit <= 0) return null;
                // round to 0.1 (UI単位)
                vUnit = Math.round(vUnit * 10) / 10;
                var vPt = unitToPt(vUnit, getUnitInfo("strokeUnits"));
                if (isNaN(vPt) || vPt <= 0) return null;
                // internal pt: keep 0.1pt precision
                vPt = Math.round(vPt * 10) / 10;
                return vPt;
            }

            function parseCornerRadius() {
                var vUnit = Number(etCorner.text);
                if (isNaN(vUnit) || vUnit < 0) return null;
                // round to 0.1 (UI単位)
                vUnit = Math.round(vUnit * 10) / 10;
                var vPt = unitToPt(vUnit, getUnitInfo("rulerType"));
                if (isNaN(vPt) || vPt < 0) return null;
                // internal pt: keep 0.1pt precision
                vPt = Math.round(vPt * 10) / 10;
                return vPt;
            }

            function getBalanceMode() {
                if (rbPinLeft.value) return 'left';
                if (rbPinRight.value) return 'right';
                return 'none';
            }

            function parseWidthPercent() {
                // NOTE: 「幅」は距離（rulerType単位）として扱い、内部はptに変換する
                var vUnit = Number(etWidth.text);
                if (isNaN(vUnit) || vUnit < 0) vUnit = 0;

                // keep 0.1 in UI units
                vUnit = Math.round(vUnit * 10) / 10;

                // keep UI in sync
                slWidth.value = vUnit;
                etWidth.text = String(vUnit);

                var vPt = unitToPt(vUnit, getUnitInfo("rulerType"));
                if (isNaN(vPt) || vPt < 0) vPt = 0;

                // internal pt: keep 0.1pt precision
                vPt = Math.round(vPt * 10) / 10;
                return vPt;
            }

            function applyPreview() {
                var v = parsePercent();
                if (v === null) {
                    // 数値として成立しない間は、プレビューを消すだけ
                    clearPreviewFn();
                    return;
                }
                var sw = parseStrokeWidth();
                if (sw === null) {
                    clearPreviewFn();
                    return;
                }
                var cr = parseCornerRadius();
                if (cr === null) {
                    clearPreviewFn();
                    return;
                }
                var bm = getBalanceMode();
                var wp = parseWidthPercent();
                // 常に「最新のUI値」をキャッシュ（Preview OFFでもOK時に使う）
                lastPreviewPercent = v;
                lastOverallFrame = !!cbOverallFrame.value;
                lastDivider = !!cbDivider.value;
                lastFillLeft = !!cbFillLeft.value;
                lastFillRight = !!cbFillRight.value;
                lastStrokeWidth = sw;
                lastCornerRadius = cr;
                lastBalanceMode = bm || 'none';
                lastWidthPercent = wp;
                previewFn(v, cbPreview.value, lastOverallFrame, lastDivider, lastFillLeft, lastFillRight, lastStrokeWidth, lastCornerRadius, lastBalanceMode, lastWidthPercent);
            }

            // ダイアログ表示直後に初回プレビューを実行 / Run initial preview on dialog show
            (function () {
                var prevOnShow = dlg.onShow;
                dlg.onShow = function () {
                    if (typeof prevOnShow === "function") {
                        try { prevOnShow(); } catch (ePrevShow) { }
                    }
                    try { updateWidthSliderMaxBySelection(); } catch (eMaxInit) { }
                    try { applyPreview(); } catch (eInitPrev) { }
                };
            })();

            // 値変更で即プレビュー
            et.addEventListener('changing', function () {
                applyPreview();
            });
            etStroke.addEventListener('changing', function () {
                applyPreview();
            });
            etCorner.addEventListener('changing', function () {
                applyPreview();
            });

            cbPreview.onClick = function () {
                if (!cbPreview.value) {
                    // Preview OFF: まず確実に巻き戻す
                    try { previewMgr.rollback(); } catch (e0) { }
                    try { removeMarkedPreviewItems(doc); } catch (e1) { }
                    previewApplied = false;
                }
                applyPreview();
            };
            cbOverallFrame.onClick = function () {
                updateStrokeWidthEnabled();
                updateCornerEnabled();
                applyPreview();
            };
            cbDivider.onClick = function () {
                updateStrokeWidthEnabled();
                applyPreview();
            };
            cbFillLeft.onClick = function () {
                updateCornerEnabled();
                applyPreview();
            };
            cbFillRight.onClick = function () {
                updateCornerEnabled();
                applyPreview();
            };

            /* ボタン行（右：キャンセル・OK） / Button row (right: Cancel and OK) */
            var buttonRow = addButtonRow(dlg);
            var btnCancel = buttonRow.rightGroup.add('button', undefined, getLabel('labelCancel'), { name: 'cancel' });
            var btnOK = buttonRow.rightGroup.add('button', undefined, getLabel('labelOK'), { name: 'ok' });

            btnOK.onClick = function () {
                var v = parsePercent();
                if (v === null) {
                    alert(getLabel('alertHeightInvalid'));
                    return;
                }
                // OK：ダイアログを閉じる（確定処理はダイアログ終了後にまとめて行う）
                // プレビューOFFの場合、現時点では何も適用されていないはずなので巻き戻しだけしておく
                if (!cbPreview.value) {
                    try { previewMgr.rollback(); } catch (e0) { }
                    clearPreviewFn();
                }
                dlg.close(1);
            };

            btnCancel.onClick = function () {
                // キャンセル時は必ずロールバックして閉じる
                try { previewMgr.rollback(); } catch (e0) { }
                clearPreviewFn();
                dlg.close(0);
            };

            // Enter / Esc
            dlg.defaultElement = btnOK;
            dlg.cancelElement = btnCancel;

            alignRightOnlyButtonRow(buttonRow);
            prepareDialogWindow(dlg, SCRIPT_NAME);
            var result = dlg.show();
            if (result !== 1) return null;

            var percent = parsePercent();
            if (percent === null) return null;

            return percent;
        }

        var DEFAULT_HEIGHT_PERCENT = 200; // ダイアログ初期値（%）
        var heightRatio = DEFAULT_HEIGHT_PERCENT / 100; // 高さ倍率（内部計算用）

        function previewFn(percent, enabled, addOverallFrame, addDivider, addFillLeft, addFillRight, strokeWidth, cornerRadius, balanceMode, widthPercent) {
            // まず前回プレビューをUndoで巻き戻す
            clearPreviewRects();

            if (!enabled) {
                return;
            }

            // 新しいプレビューを1ステップとして適用
            previewMgr.addStep(function () {
                var hr = percent / 100;
                var result = drawBackgroundRects(item1, item2, hr, addOverallFrame, addDivider, addFillLeft, addFillRight, strokeWidth, cornerRadius, balanceMode, widthPercent);

                previewRect1 = result.rect1;
                previewRect2 = result.rect2;
                previewFrame = result.frame;
                previewDivider = result.divider;

                // プレビュー生成物としてマーク（参照が失われても掃除できるように）
                if (previewRect1) markPreview(previewRect1);
                if (previewRect2) markPreview(previewRect2);
                if (previewFrame) markPreview(previewFrame);
                if (previewDivider) markPreview(previewDivider);

                previewApplied = true;
                lastPreviewPercent = percent;
                lastOverallFrame = !!addOverallFrame;
                lastDivider = !!addDivider;
                lastFillLeft = !!addFillLeft;
                lastFillRight = !!addFillRight;
                lastStrokeWidth = strokeWidth;
                lastCornerRadius = cornerRadius;
                lastBalanceMode = balanceMode || 'none';
                lastWidthPercent = (widthPercent !== undefined && widthPercent !== null) ? widthPercent : 0;
            });
        }

        var heightPercent = showHeightDialog(DEFAULT_HEIGHT_PERCENT, previewFn, clearPreviewRects);
        if (heightPercent === null) {
            return; // キャンセル
        }
        heightRatio = heightPercent / 100;

        // --- 確定処理 ---
        // OK時：Undo履歴を綺麗にするため、プレビューを一度ロールバックしてから本番を1回だけ実行
        // （Ctrl+Z 一回で戻せる状態を狙う）
        previewMgr.confirm(function () {
            var finalHr = heightRatio;
            drawBackgroundRects(item1, item2, finalHr, lastOverallFrame, lastDivider, lastFillLeft, lastFillRight, lastStrokeWidth, lastCornerRadius, lastBalanceMode, lastWidthPercent);
            // 本番生成物にはプレビューマークを付けない
            try { removeMarkedPreviewItems(doc); } catch (eMarkFinal) { }
        });

        // 選択を解除
        doc.selection = null;

        // ==============================
        // Round Any Corner / 角丸アルゴリズム（選択アンカーのみ丸める）
        // Based on: Hiroyuki Sato (MIT) https://github.com/shspage
        // ==============================

        function roundAnyCorner(s, conf) {
            var rr = conf.rr;

            // var tim = new Date();
            var p, op, pnts;
            var skipList, adjRdirAtEnd, redrawFlg;
            var i, nxi, pvi, q, d, ds, r, g, t, qb;
            var anc1, ldir1, rdir1, anc2, ldir2, rdir2;

            var hanLen = 4 * (Math.sqrt(2) - 1) / 3;
            var ptyp = PointType.SMOOTH;

            for (var j = 0; j < s.length; j++) {
                p = s[j].pathPoints;
                if (readjustAnchors(p) < 2) continue; // reduce anchors
                op = !s[j].closed;
                pnts = op ? [getDat(p[0])] : [];
                redrawFlg = false;
                adjRdirAtEnd = 0;

                skipList = [(op || !isSelected(p[0]) || !isCorner(p, 0))];
                for (i = 1; i < p.length; i++) {
                    skipList.push((!isSelected(p[i])
                        || !isCorner(p, i)
                        || (op && i == p.length - 1)));
                }

                for (i = 0; i < p.length; i++) {
                    nxi = parseIdx(p, i + 1);
                    if (nxi < 0) break;

                    pvi = parseIdx(p, i - 1);

                    q = [p[i].anchor, p[i].rightDirection,
                    p[nxi].leftDirection, p[nxi].anchor];

                    ds = dist(q[0], q[3]) / 2;
                    if (arrEq(q[0], q[1]) && arrEq(q[2], q[3])) {  // straight side
                        r = Math.min(ds, rr);
                        g = getRad(q[0], q[3]);
                        anc1 = getPnt(q[0], g, r);
                        ldir1 = getPnt(anc1, g + Math.PI, r * hanLen);

                        if (skipList[nxi]) {
                            if (!skipList[i]) {
                                pnts.push([anc1, anc1, ldir1, ptyp]);
                                redrawFlg = true;
                            }
                            pnts.push(getDat(p[nxi]));
                        } else {
                            if (r < rr) {  // when the length of the side is less than rr * 2
                                pnts.push([anc1,
                                    getPnt(anc1, getRad(ldir1, anc1), r * hanLen),
                                    ldir1,
                                    ptyp]);
                            } else {
                                if (!skipList[i]) pnts.push([anc1, anc1, ldir1, ptyp]);
                                anc2 = getPnt(q[3], g + Math.PI, r);
                                pnts.push([anc2,
                                    getPnt(anc2, g, r * hanLen),
                                    anc2,
                                    ptyp]);
                            }
                            redrawFlg = true;
                        }
                    } else {  // not straight side
                        d = getT4Len(q, 0) / 2;
                        r = Math.min(d, rr);
                        t = getT4Len(q, r);
                        anc1 = bezier(q, t);
                        rdir1 = defHan(t, q, 1);
                        ldir1 = getPnt(anc1, getRad(rdir1, anc1), r * hanLen);

                        if (skipList[nxi]) {
                            if (skipList[i]) {
                                pnts.push(getDat(p[nxi]));
                            } else {
                                pnts.push([anc1, rdir1, ldir1, ptyp]);
                                with (p[nxi]) pnts.push([anchor,
                                    rightDirection,
                                    adjHan(anchor, leftDirection, 1 - t),
                                    ptyp]);
                                redrawFlg = true;
                            }
                        } else { // skipList[nxi] = false
                            if (r < rr) {  // the length of the side is less than rr * 2
                                if (skipList[i]) {
                                    if (!op && i == 0) {
                                        adjRdirAtEnd = t;
                                    } else {
                                        pnts[pnts.length - 1][1] = adjHan(q[0], q[1], t);
                                    }
                                    pnts.push([anc1,
                                        getPnt(anc1, getRad(ldir1, anc1), r * hanLen),
                                        defHan(t, q, 0),
                                        ptyp]);
                                } else {
                                    pnts.push([anc1,
                                        getPnt(anc1, getRad(ldir1, anc1), r * hanLen),
                                        ldir1,
                                        ptyp]);
                                }
                            } else {  // round the corner with the radius rr
                                if (skipList[i]) {
                                    t = getT4Len(q, -r);
                                    anc2 = bezier(q, t);

                                    if (!op && i == 0) {
                                        adjRdirAtEnd = t;
                                    } else {
                                        pnts[pnts.length - 1][1] = adjHan(q[0], q[1], t);
                                    }

                                    ldir2 = defHan(t, q, 0);
                                    rdir2 = getPnt(anc2, getRad(ldir2, anc2), r * hanLen);

                                    pnts.push([anc2, rdir2, ldir2, ptyp]);
                                } else {
                                    qb = [anc1, rdir1, adjHan(q[3], q[2], 1 - t), q[3]];
                                    t = getT4Len(qb, -r);
                                    anc2 = bezier(qb, t);
                                    ldir2 = defHan(t, qb, 0);
                                    rdir2 = getPnt(anc2, getRad(ldir2, anc2), r * hanLen);
                                    rdir1 = adjHan(anc1, rdir1, t);

                                    pnts.push([anc1, rdir1, ldir1, ptyp],
                                        [anc2, rdir2, ldir2, ptyp]);
                                }
                            }
                            redrawFlg = true;
                        }
                    }
                }
                if (adjRdirAtEnd > 0) {
                    pnts[pnts.length - 1][1] = adjHan(p[0].anchor, p[0].rightDirection, adjRdirAtEnd);
                }

                if (redrawFlg) {
                    // redraw
                    for (i = p.length - 1; i > 0; i--) p[i].remove();

                    for (i = 0; i < pnts.length; i++) {
                        pt = i > 0 ? p.add() : p[0];
                        with (pt) {
                            anchor = pnts[i][0];
                            rightDirection = pnts[i][1];
                            leftDirection = pnts[i][2];
                            pointType = pnts[i][3];
                        }
                    }
                }
            }
            app.activeDocument.selection = s;
            // alert(new Date() - tim);
        }

        // ------------------------------------------------
        // return [x,y] of the distance "len" and the angle "rad"(in radian)
        // from "pt"=[x,y]
        function getPnt(pt, rad, len) {
            return [pt[0] + Math.cos(rad) * len,
            pt[1] + Math.sin(rad) * len];
        }

        // ------------------------------------------------
        // return the [x, y] coordinate of the handle of the point on the bezier curve
        // that corresponds to the parameter "t"
        // n=0:leftDir, n=1:rightDir
        function defHan(t, q, n) {
            return [t * (t * (q[n][0] - 2 * q[n + 1][0] + q[n + 2][0]) + 2 * (q[n + 1][0] - q[n][0])) + q[n][0],
            t * (t * (q[n][1] - 2 * q[n + 1][1] + q[n + 2][1]) + 2 * (q[n + 1][1] - q[n][1])) + q[n][1]];
        }

        // -----------------------------------------------
        // return the [x, y] coordinate on the bezier curve
        // that corresponds to the paramter "t"
        function bezier(q, t) {
            var u = 1 - t;
            return [u * u * u * q[0][0] + 3 * u * t * (u * q[1][0] + t * q[2][0]) + t * t * t * q[3][0],
            u * u * u * q[0][1] + 3 * u * t * (u * q[1][1] + t * q[2][1]) + t * t * t * q[3][1]];
        }

        // ------------------------------------------------
        // adjust the length of the handle "dir"
        // by the magnification ratio "m",
        // returns the modified [x, y] coordinate of the handle
        // "anc" is the anchor [x, y]
        function adjHan(anc, dir, m) {
            return [anc[0] + (dir[0] - anc[0]) * m,
            anc[1] + (dir[1] - anc[1]) * m];
        }

        // ------------------------------------------------
        // return true if the pathPoints "p[idx]" is a corner
        function isCorner(p, idx) {
            var pnt0 = getAnglePnt(p, idx, -1);
            var pnt1 = getAnglePnt(p, idx, 1);
            if (!pnt0 || !pnt1) return false;                    // at the end of a open-path
            if (pnt0.length < 1 || pnt1.length < 1) return false;   // anchor is overlapping, so cannot determine the angle
            var rad = getRad2(pnt0, p[idx].anchor, pnt1, true);
            if (rad > Math.PI - 0.1) return false;   // set the angle tolerance here
            return true;
        }
        // ------------------------------------------------
        // "p"=pathPoints, "idx1"=index of pathpoint
        // "dir" = -1, returns previous point [x,y] to get the angle of tangent at pathpoints[idx1]
        // "dir" =  1, returns next ...
        function getAnglePnt(p, idx1, dir) {
            if (!dir) dir = -1;
            var idx2 = parseIdx(p, idx1 + dir);
            if (idx2 < 0) return null;  // at the end of a open-path
            var p2 = p[idx2];
            with (p[idx1]) {
                if (dir < 0) {
                    if (arrEq(leftDirection, anchor)) {
                        if (arrEq(p2.anchor, anchor)) return [];
                        if (arrEq(p2.anchor, p2.rightDirection)
                            || arrEq(p2.rightDirection, anchor)) return p2.anchor;
                        else return p2.rightDirection;
                    } else {
                        return leftDirection;
                    }
                } else {
                    if (arrEq(anchor, rightDirection)) {
                        if (arrEq(anchor, p2.anchor)) return [];
                        if (arrEq(p2.anchor, p2.leftDirection)
                            || arrEq(anchor, p2.leftDirection)) return p2.anchor;
                        else return p2.leftDirection;
                    } else {
                        return rightDirection;
                    }
                }
            }
        }
        // --------------------------------------
        // if the contents of both arrays are equal, return true (lengthes must be same)
        function arrEq(arr1, arr2) {
            for (var i = 0; i < arr1.length; i++) {
                if (arr1[i] != arr2[i]) return false;
            }
            return true;
        }

        // ------------------------------------------------
        // return the distance between p1=[x,y] and p2=[x,y]
        function dist(p1, p2) {
            return Math.sqrt(Math.pow(p1[0] - p2[0], 2)
                + Math.pow(p1[1] - p2[1], 2));
        }
        // ------------------------------------------------
        // return the squared distance between p1=[x,y] and p2=[x,y]
        function dist2(p1, p2) {
            return Math.pow(p1[0] - p2[0], 2)
                + Math.pow(p1[1] - p2[1], 2);
        }
        // --------------------------------------
        // return the angle in radian
        // of the line drawn from p1=[x,y] from p2
        function getRad(p1, p2) {
            return Math.atan2(p2[1] - p1[1],
                p2[0] - p1[0]);
        }

        // --------------------------------------
        // return the angle between two line segments
        // o-p1 and o-p2 ( 0 - Math.PI)
        function getRad2(p1, o, p2) {
            var v1 = normalize(p1, o);
            var v2 = normalize(p2, o);
            return Math.acos(v1[0] * v2[0] + v1[1] * v2[1]);
        }
        // ------------------------------------------------
        function normalize(p, o) {
            var d = dist(p, o);
            return d == 0 ? [0, 0] : [(p[0] - o[0]) / d,
            (p[1] - o[1]) / d];
        }

        // ------------------------------------------------
        // return the bezier curve parameter "t"
        // at the point which the length of the bezier curve segment
        // (from the point start drawing) is "len"
        // when "len" is 0, return the length of whole this segment.
        function getT4Len(q, len) {
            var m = [q[3][0] - q[0][0] + 3 * (q[1][0] - q[2][0]),
            q[0][0] - 2 * q[1][0] + q[2][0],
            q[1][0] - q[0][0]];
            var n = [q[3][1] - q[0][1] + 3 * (q[1][1] - q[2][1]),
            q[0][1] - 2 * q[1][1] + q[2][1],
            q[1][1] - q[0][1]];
            var k = [m[0] * m[0] + n[0] * n[0],
            4 * (m[0] * m[1] + n[0] * n[1]),
            2 * ((m[0] * m[2] + n[0] * n[2]) + 2 * (m[1] * m[1] + n[1] * n[1])),
            4 * (m[1] * m[2] + n[1] * n[2]),
            m[2] * m[2] + n[2] * n[2]];

            var fullLen = getLength(k, 1);

            if (len == 0) {
                return fullLen;

            } else if (len < 0) {
                len += fullLen;
                if (len < 0) return 0;

            } else if (len > fullLen) {
                return 1;
            }

            var t, d;
            var t0 = 0;
            var t1 = 1;
            var torelance = 0.001;

            for (var h = 1; h < 30; h++) {
                t = t0 + (t1 - t0) / 2;
                d = len - getLength(k, t);
                if (Math.abs(d) < torelance) break;
                else if (d < 0) t1 = t;
                else t0 = t;
            }
            return t;
        }

        // ------------------------------------------------
        // return the length of bezier curve segment
        // in range of parameter from 0 to "t"
        function getLength(k, t) {
            var h = t / 128;
            var hh = h * 2;
            var fc = function (t, k) {
                return Math.sqrt(t * (t * (t * (t * k[0] + k[1]) + k[2]) + k[3]) + k[4]) || 0
            };
            var total = (fc(0, k) - fc(t, k)) / 2;
            for (var i = h; i < t; i += hh) total += 2 * fc(i, k) + fc(i + h, k);
            return total * hh;
        }

        // --------------------------------------
        // merge nearly overlapped anchor points
        // return the length of pathpoints after merging
        function readjustAnchors(p) {
            // Settings ==========================

            // merge the anchor points when the distance between
            // 2 points is within ### square root ### of this value (in point)
            var minDist = 0.0025;

            // ===================================
            if (p.length < 2) return 1;
            var i;

            if (p.parent.closed) {
                for (i = p.length - 1; i >= 1; i--) {
                    if (dist2(p[0].anchor, p[i].anchor) < minDist) {
                        p[0].leftDirection = p[i].leftDirection;
                        p[i].remove();
                    } else {
                        break;
                    }
                }
            }

            for (i = p.length - 1; i >= 1; i--) {
                if (dist2(p[i].anchor, p[i - 1].anchor) < minDist) {
                    p[i - 1].rightDirection = p[i].rightDirection;
                    p[i].remove();
                }
            }

            return p.length;
        }
        // -----------------------------------------------
        // return pathpoint's index. when the argument is out of bounds,
        // fixes it if the path is closed (ex. next of last index is 0),
        // or return -1 if the path is not closed.
        function parseIdx(p, n) { // PathPoints, number for index
            var len = p.length;
            if (p.parent.closed) {
                return n >= 0 ? n % len : len - Math.abs(n % len);
            } else {
                return (n < 0 || n > len - 1) ? -1 : n;
            }
        }
        // -----------------------------------------------
        function getDat(p) { // pathPoint
            with (p) return [anchor, rightDirection, leftDirection, pointType];
        }
        // -----------------------------------------------
        function isSelected(p) { // PathPoint
            return p.selected == PathPointSelection.ANCHORPOINT;
        }

        function selectLeftCornersForRectangles(paths) {
            for (var i = 0; i < paths.length; i++) {
                var it = paths[i];
                if (!it || it.typename !== "PathItem" || !it.closed) continue;
                var pp = it.pathPoints;
                if (!pp || pp.length !== 4) continue;

                var currentSelection = 0;
                for (var a = 0; a < 4; a++) if (pp[a].selected === PathPointSelection.ANCHORPOINT) currentSelection++;
                if (currentSelection > 0 && currentSelection < 4) continue; // respect partial anchor selection

                var idx = [0, 1, 2, 3];
                idx.sort(function (x, y) { return pp[x].anchor[0] - pp[y].anchor[0]; });
                var a0 = idx[0], a1 = idx[1];
                var top = (pp[a0].anchor[1] >= pp[a1].anchor[1]) ? a0 : a1;
                var bot = (top === a0) ? a1 : a0;

                for (a = 0; a < 4; a++) pp[a].selected = PathPointSelection.NOSELECTION;
                pp[top].selected = PathPointSelection.ANCHORPOINT;
                pp[bot].selected = PathPointSelection.ANCHORPOINT;
            }
        }

    })();

})();
