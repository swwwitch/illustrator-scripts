#target illustrator
#targetengine "ConvertAreaAndPointTypeEngine"
app.preferences.setBooleanPreference('ShowExternalJSXWarning', false);

/*
SCRIPTMETA-BEGIN
Script-ID=com.swwwitch.illustrator.ConvertAreaAndPointType
Name=ポイント文字・パス上文字とエリア内文字の相互変換
Author=Masahiro Takano (@swwwitch)
Target-App=Illustrator
Version=1.0.9
Release-Date=2026-07-02
Description-BEGIN
選択に応じて、ポイント文字・パス上文字とエリア内文字を相互に変換します。
順変換は見た目を保ったままエリア内文字へ、逆変換は枠サイズを保ったままポイント文字へ変換します。

Converts between point text or text on a path and area text, depending on what is selected.
The forward conversion preserves the appearance, and the reverse keeps the frame size when returning to point text.
Description-END
SCRIPTMETA-END
*/

/*

### 概要

選択に応じて、ポイント文字・パス上文字とエリア内文字を相互に変換します。
順変換は見た目を保ったままエリア内文字へ、逆変換は枠サイズを保ったままポイント文字へ変換します。

詳細は README を参照してください。
https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/ConvertAreaAndPointType.md

### Overview

Converts between point text or text on a path and area text, depending on what is selected.
The forward conversion preserves the appearance, and the reverse keeps the frame size when returning to point text.

See the README for details.
https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/ConvertAreaAndPointType.md

*/

// =========================================
// 基本情報 / Basic info
// =========================================
var SCRIPT_NAME     = "ConvertAreaAndPointType";      /* スクリプト名 / script name */
var SCRIPT_VERSION  = "v1.0.9";                       /* バージョン / version */
var SCRIPT_AUTHOR   = "Masahiro Takano (@swwwitch)";  /* 作者 / author */
var SCRIPT_RELEASED = "2026-07-02";                   /* 最初のリリース日 / first release date */
var SCRIPT_UPDATED  = "2026-10-16";                   /* 更新日 / last updated */

var SCRIPT_DESCRIPTION_JA = "ポイント文字・パス上文字とエリア内文字の相互変換"; /* README の見出し / README title (Japanese) */

var SCRIPT_README_JA  = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/ConvertAreaAndPointType.md"; /* README（日本語） */
var SCRIPT_README_EN  = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/ConvertAreaAndPointType.md"; /* README (English) */
var SCRIPT_SOURCE_URL = "https://github.com/swwwitch/illustrator-scripts/blob/master/jsx/text/ConvertAreaAndPointType.jsx"; /* 最新版のソース / latest source */

// Released under the MIT license
// http://opensource.org/licenses/mit-license.php

(function () {

    // =========================================
    // レイアウト / Layout
    // =========================================

    // UIレイアウト（再利用パーツ） / UI layout (reusable)

    /* ウィンドウ・パネルの余白と間隔 / Window & panel margins and spacing */
    var WINDOW_MARGINS = 16;                 /* ウィンドウ外周の余白 / window margin */
    var WINDOW_SPACING = 12;                 /* ウィンドウ内の要素間隔 / window spacing */
    var PANEL_MARGINS  = [16, 20, 16, 12];   /* パネル余白 [左,上,右,下] / panel margins */
    var PANEL_SPACING  = 12;                 /* パネル内の要素間隔 / panel spacing */
    var COLUMN_SPACING = 12;                 /* 2カラムの間隔 / gap between columns */
    var TAB_MARGINS    = [15, 20, 5, 10];    /* タブ余白 [左,上,右,下] / tab margins */

    /**
     * ウィンドウの共通設定
     * @param {Window} targetWindow - 対象のウィンドウ
     * @param {number} [spacing] - 要素間隔（省略時は WINDOW_SPACING）
     * @returns {void}
     */
    function setupWindow(targetWindow, spacing) {
        targetWindow.orientation = "column";
        targetWindow.alignChildren = "fill";
        targetWindow.margins = WINDOW_MARGINS;
        targetWindow.spacing = (typeof spacing === "number") ? spacing : WINDOW_SPACING;
    }

    /**
     * パネルの共通設定（子は幅いっぱい。ボタンは alignment = "left" で広げない）
     * @param {Panel} targetPanel - 対象のパネル
     * @param {number} [spacing] - 要素間隔（省略時は PANEL_SPACING）
     * @returns {void}
     */
    function setupPanel(targetPanel, spacing) {
        targetPanel.orientation = "column";
        targetPanel.alignChildren = ["fill", "top"];
        targetPanel.alignment = "fill";
        targetPanel.margins = PANEL_MARGINS;
        targetPanel.spacing = (typeof spacing === "number") ? spacing : PANEL_SPACING;
    }

    /**
     * タブの共通設定
     * @param {Tab} targetTab - 対象のタブ
     * @param {number} [spacing] - 要素間隔（省略時は変えない）
     * @returns {void}
     */
    function setupTab(targetTab, spacing) {
        targetTab.orientation = "column";
        targetTab.alignChildren = "fill";
        targetTab.margins = TAB_MARGINS;
        if (typeof spacing === "number") targetTab.spacing = spacing;
    }

    /**
     * 横並びの行グループの共通設定（ボタン列など）。
     * alignment と alignChildren を対で指定し、中のボタンが横に伸びたり天地がずれたりしないようにする
     * @param {Group} rowGroup - 対象のグループ
     * @param {string|string[]} [rowAlignment] - 横方向の alignment（省略時は "left"）。配列ならそのまま使う
     * @param {number} [spacing] - 要素間隔（省略時は PANEL_SPACING）
     * @returns {void}
     */
    function setupRow(rowGroup, rowAlignment, spacing) {
        rowGroup.orientation = "row";
        rowGroup.alignment = (rowAlignment instanceof Array) ? rowAlignment : [rowAlignment || "left", "center"];
        rowGroup.alignChildren = ["left", "center"];
        rowGroup.spacing = (typeof spacing === "number") ? spacing : PANEL_SPACING;
    }

    /**
     * ボタンの高さを指定した px だけ詰める（レイアウトが決まったあとに呼ぶ）
     * @param {Button} targetButton - 対象のボタン
     * @param {number} trimPixels - 詰める量（px）
     * @returns {void}
     */
    function trimButtonHeight(targetButton, trimPixels) {
        /* レイアウト前は size が無い / size is not set until the layout runs */
        if (!targetButton.size) return;
        targetButton.size = [targetButton.size.width, targetButton.size.height - trimPixels];
    }

    // UIレイアウト（再利用パーツ）ここまで / End of the reusable UI layout

    // ダイアログの位置と不透明度（再利用パーツ） / Dialog position and opacity (reusable)

    var DIALOG_OPACITY = 0.98;       /* ダイアログの不透明度 / dialog opacity */
    var DIALOG_AVOID_MARGIN = 60;    /* 選択範囲の推定位置の両側に取る余裕（px）/ margin on each side of the estimated selection (px) */
    var DIALOG_AVOID_MAX_ITEMS = 100; /* 選択範囲を測るオブジェクトの上限 / max items measured for the selection bounds */

    /**
     * ダイアログの不透明度を設定し、前回閉じた位置で開いて、動かした位置を記録するようにする。
     * 開く位置が選択中のオブジェクトに重なりそうなときは、左右の反対側へずらす（Illustrator のみ）。
     * 既存の onShow / onMove / onClose は先に呼んでから、位置の復元・記録を行う。
     * @param {Window} dialog - 対象のダイアログ
     * @param {string} storageKey - 位置を覚えるキー（ふつうは SCRIPT_NAME）
     * @returns {void}
     */
    function prepareDialogWindow(dialog, storageKey) {
        /* 同じダイアログを開き直すときは、選択範囲を測り直すだけにする（ハンドラーを重ねない）
           When the same dialog is shown again, only re-measure the selection (don't stack handlers) */
        if (dialog.dialogWindowState) {
            dialog.dialogWindowState.selectionSpan = getSelectionViewSpan();
            dialog.dialogWindowState.avoidedLocation = null;
            return;
        }
        var locationKey = "__" + storageKey + "_DialogLocation";
        var previousOnShow = dialog.onShow;
        var previousOnMove = dialog.onMove;
        var previousOnClose = dialog.onClose;
        var windowState = {
            selectionSpan: getSelectionViewSpan(), /* 選択範囲は show() の前に測る / measured before show() */
            screenWidth: null,                     /* 最初に開いたときに推定する / estimated on the first show */
            avoidedLocation: null                  /* 避けるためにずらした位置（記録しない）/ location set to avoid the selection (not remembered) */
        };
        dialog.dialogWindowState = windowState;

        dialog.opacity = DIALOG_OPACITY;

        /* 今の位置を記録する / Remember the current location */
        function rememberDialogLocation() {
            var currentLocation = [dialog.location[0], dialog.location[1]];
            var avoidedLocation = windowState.avoidedLocation;
            if (avoidedLocation && currentLocation[0] === avoidedLocation[0] && currentLocation[1] === avoidedLocation[1]) return;
            $.global[locationKey] = currentLocation;
        }

        dialog.onShow = function () {
            /* 最初に開くときの既定の位置は画面の横中央なので、画面の幅を逆算できる。2回目からは前回の位置なので使い回す
               On the first show the default location is centered horizontally, which gives the screen width; reuse it afterwards */
            if (windowState.screenWidth === null) windowState.screenWidth = dialog.location[0] * 2 + dialog.bounds.width;
            if (previousOnShow) previousOnShow.apply(this, arguments);
            /* $.screens は実際の画面の大きさと合わない（Mac で 1280×524 など）ので、画面内かは判定しない
               $.screens does not match the real display (e.g. 1280x524 on a Mac), so no on-screen check */
            var savedLocation = $.global[locationKey];
            if (savedLocation) dialog.location = [savedLocation[0], savedLocation[1]];
            if (windowState.selectionSpan) {
                var avoidLeft = findDialogLeftAvoidingSelection(dialog.location[0], dialog.bounds.width, windowState.screenWidth, windowState.selectionSpan);
                if (avoidLeft !== null) {
                    dialog.location = [avoidLeft, dialog.location[1]];
                    /* 代入後の値で比べる（丸められることがある）/ Compare with the value after assignment, which may be rounded */
                    windowState.avoidedLocation = [dialog.location[0], dialog.location[1]];
                }
            }
        };
        dialog.onMove = function () {
            if (previousOnMove) previousOnMove.apply(this, arguments);
            rememberDialogLocation();
        };
        dialog.onClose = function () {
            rememberDialogLocation();
            /* false を返すと閉じるのを取りやめるので、戻り値は元の onClose のものを返す
               Returning false cancels the close, so pass the original onClose result through */
            if (previousOnClose) return previousOnClose.apply(this, arguments);
        };
    }

    /**
     * 選択中のオブジェクトが、ドキュメントの表示域の左端から画面上で何 px の範囲にあるかを返す。
     * @returns {{left: number, right: number, viewWidth: number}|null} 選択が無い・測れないときは null
     */
    function getSelectionViewSpan() {
        try {
            if (app.name !== "Adobe Illustrator" || !app.documents.length) return null;
            var targetDoc = app.activeDocument;
            var selectedItems = targetDoc.selection;
            /* 文字ツールで文字を選択しているときは TextRange が返り、[0] が無い / Selecting characters with the Type tool returns a TextRange, which has no [0] */
            if (!selectedItems || selectedItems.typename === "TextRange" || !selectedItems.length || !selectedItems[0].visibleBounds) return null;
            var itemCount = Math.min(selectedItems.length, DIALOG_AVOID_MAX_ITEMS);
            var spanLeft = Infinity;
            var spanRight = -Infinity;
            for (var i = 0; i < itemCount; i++) {
                var itemBounds = selectedItems[i].visibleBounds;
                if (itemBounds[0] < spanLeft) spanLeft = itemBounds[0];
                if (itemBounds[2] > spanRight) spanRight = itemBounds[2];
            }
            var activeView = targetDoc.activeView; /* 複数ウィンドウで開いていても今のウィンドウ / the current window even with multiple windows */
            var viewBounds = activeView.bounds;
            var zoom = activeView.zoom;
            var viewWidth = (viewBounds[2] - viewBounds[0]) * zoom;
            /* 表示域の外にはみ出した部分は数えない / Ignore the part outside the view */
            var left = Math.max(0, (spanLeft - viewBounds[0]) * zoom);
            var right = Math.min(viewWidth, (spanRight - viewBounds[0]) * zoom);
            if (right <= left) return null;
            return { left: left, right: right, viewWidth: viewWidth };
        } catch (e) {
            /* テキスト編集中など測れないときは避けない / Do not avoid when it cannot be measured, e.g. while editing text */
            return null;
        }
    }

    /**
     * ダイアログが選択範囲に重なるなら、重ならない左端の位置を返す。
     * 表示域は画面の横中央にあるとみなし、ずれは DIALOG_AVOID_MARGIN で吸収する。
     * @param {number} dialogLeft - 今のダイアログの左端
     * @param {number} dialogWidth - ダイアログの幅
     * @param {number} screenWidth - 画面の幅
     * @param {{left: number, right: number, viewWidth: number}} selectionSpan - getSelectionViewSpan() の結果
     * @returns {number|null} ずらした左端。重ならない・どちらにも収まらないときは null
     */
    function findDialogLeftAvoidingSelection(dialogLeft, dialogWidth, screenWidth, selectionSpan) {
        var viewLeft = (screenWidth - selectionSpan.viewWidth) / 2;
        var avoidLeft = viewLeft + selectionSpan.left - DIALOG_AVOID_MARGIN;
        var avoidRight = viewLeft + selectionSpan.right + DIALOG_AVOID_MARGIN;
        if (dialogLeft + dialogWidth <= avoidLeft || dialogLeft >= avoidRight) return null;

        var leftSideLeft = avoidLeft - dialogWidth;   /* 選択範囲の左に置くとき / placed left of the selection */
        var rightSideLeft = avoidRight;               /* 選択範囲の右に置くとき / placed right of the selection */
        var fitsLeft = leftSideLeft >= 0;
        var fitsRight = rightSideLeft + dialogWidth <= screenWidth;
        /* 選択範囲が画面の右寄りなら左へ、左寄りなら右へ逃がす / Move away from the side the selection leans to */
        var preferLeft = (avoidLeft + avoidRight) / 2 > screenWidth / 2;
        if (preferLeft && fitsLeft) return leftSideLeft;
        if (fitsRight) return rightSideLeft;
        if (fitsLeft) return leftSideLeft;
        return null;
    }

    // ダイアログの位置と不透明度（再利用パーツ）ここまで / End of the reusable dialog position and opacity

    // =========================================
    // ローカライズ / Localization
    // =========================================

    // ローカライズ（再利用パーツ） / Localization (reusable)

    /**
     * UI の言語を返す（"ja" で始まるロケールは日本語、それ以外は英語）
     * @returns {string} "ja" または "en"
     */
    function getCurrentLang() {
        return (String($.locale || "").indexOf("ja") === 0) ? "ja" : "en";
    }

    var uiLang = getCurrentLang();

    /**
     * LABELS から今の UI 言語の文言を取り出す。
     * @param {string|Object} labelRef - "dialog.title" のようなパス、または { ja, en }
     * @param {Object|Array} [placeholderValues] - { name: 値 } なら {name} を、[値, …] なら %1, %2 … を差し込む
     * @returns {string} 文言。パスが見つからなければパスの文字列、{ ja, en } が無ければ空文字
     */
    function getLabel(labelRef, placeholderValues) {
        var labelEntry = labelRef;
        if (typeof labelRef === "string") {
            var labelPathKeys = labelRef.split(".");
            labelEntry = LABELS;
            for (var i = 0; i < labelPathKeys.length && labelEntry != null; i++) {
                labelEntry = labelEntry[labelPathKeys[i]];
            }
        }
        var labelString;
        if (typeof labelEntry === "string") labelString = labelEntry;
        else if (labelEntry != null && labelEntry[uiLang] != null) labelString = labelEntry[uiLang];
        else if (labelEntry != null && labelEntry.en != null) labelString = labelEntry.en;
        else return (typeof labelRef === "string") ? labelRef : "";
        return fillLabelPlaceholders(String(labelString), placeholderValues);
    }

    /**
     * 項目名の文言の末尾にコロンを付ける（日本語は半角スペース＋半角コロン「 :」、英語は「:」。Illustrator の線パネルなどの項目名に合わせる）
     * @param {string|Object} labelRef - getLabel と同じ
     * @param {Object|Array} [placeholderValues] - getLabel と同じ
     * @returns {string} コロン付きの文言
     */
    function labelText(labelRef, placeholderValues) {
        return getLabel(labelRef, placeholderValues) + (uiLang === "ja" ? " :" : ":");
    }

    /**
     * 「項目名 : 値」の1行を返す（日本語は「件数 : 5」、英語は「Count: 5」。どちらもコロンのあとに空白を入れる）
     * @param {string|Object} labelRef - getLabel と同じ
     * @param {string|number} value - コロンのあとに続ける値
     * @returns {string} 項目名と値をつないだ文字列
     */
    function labelValueText(labelRef, value) {
        return labelText(labelRef) + " " + value;
    }

    /**
     * 文言の {name} や %1 に値を差し込む
     * @param {string} labelString - 文言
     * @param {Object|Array} [placeholderValues] - { name: 値 } または [値, …]
     * @returns {string} 差し込んだ文言
     */
    function fillLabelPlaceholders(labelString, placeholderValues) {
        if (placeholderValues == null) return labelString;
        if (placeholderValues instanceof Array) {
            /* 大きい番号から置き換え、%1 が %10 の一部を置き換えないようにする / Replace from the highest index so %1 does not eat into %10 */
            for (var i = placeholderValues.length; i >= 1; i--) {
                labelString = labelString.split("%" + i).join(String(placeholderValues[i - 1]));
            }
            return labelString;
        }
        for (var placeholderKey in placeholderValues) {
            if (!placeholderValues.hasOwnProperty(placeholderKey)) continue;
            labelString = labelString.split("{" + placeholderKey + "}").join(String(placeholderValues[placeholderKey]));
        }
        return labelString;
    }

    // ローカライズ（再利用パーツ）ここまで / End of the reusable localization

    /* 日英ラベル定義（UI パーツ別）/ Japanese-English label definitions (by UI part) */
    var LABELS = {
        dialog: {
            title: { ja: "テキストの変換", en: "Convert Text" }
        },
        panel: {
            selection: { ja: "選択オブジェクト", en: "Selection" },
            style: { ja: "スタイル", en: "Style" }
        },
        radio: {
            keepStyle: { ja: "保持する", en: "Keep" },
            dontKeepStyle: { ja: "保持しない", en: "Don't keep" }
        },
        button: {
            ok: { ja: "OK", en: "OK" },
            cancel: { ja: "キャンセル", en: "Cancel" }
        },
        /* 順/逆で意味が異なるため補足 / Meaning differs per direction */
        tooltip: {
            keepForward: {
                ja: "元テキストの見た目（塗り・線・効果）を引き継いでエリア内文字にします。",
                en: "Carry over the source text's appearance (fill/stroke/effects) into the area type."
            },
            dontKeepForward: {
                ja: "見た目を引き継がず、文字だけをエリア内文字にします。",
                en: "Transfer only the text (no appearance) into the area type."
            },
            keepReverse: {
                ja: "変換後の見た目のまま。追加処理はしません。",
                en: "Leave the converted look as-is; no extra processing."
            },
            dontKeepReverse: {
                ja: "塗りを2枚追加し、元の枠サイズの長方形背景（ボタン風）を付与します。",
                en: "Add two fills + a rectangle background at the original frame size (button-like)."
            }
        },
        /* 選択の内訳に出すテキスト種別 / Text-type names for the selection summary */
        textType: {
            pointText: { ja: "ポイント文字", en: "Point text" },
            areaText: { ja: "エリア内文字", en: "Area type" },
            pathText: { ja: "パス上文字", en: "Path text" },
            other: { ja: "テキスト以外", en: "Non-text" }
        },
        alert: {
            selectText: {
                ja: "ポイント文字・パス上文字、またはエリア内文字を選択してください。",
                en: "Please select point text, path text, or area type."
            },
            noDocument: { ja: "ドキュメントが開かれていません。", en: "No document is open." },
            conversionFailed: { ja: "エリア内文字に変換できませんでした。", en: "Could not convert to area type." },
            reverseFailed: { ja: "ポイント文字に変換できませんでした。", en: "Could not convert to point text." }
        }
    };

    // =========================================
    // テキストの種類 / Text kinds
    // =========================================

    /**
     * テキストフレームの種類を返す
     * @param {PageItem} pageItem - 調べるオブジェクト
     * @returns {TextType|null} テキストの種類。テキストフレーム以外は null
     */
    function getTextKind(pageItem) {
        return (pageItem.typename === "TextFrame") ? pageItem.kind : null;
    }

    /**
     * ポイント文字またはパス上文字かどうか
     * @param {PageItem} pageItem - 調べるオブジェクト
     * @returns {boolean} ポイント文字・パス上文字なら true
     */
    function isPointOrPathText(pageItem) {
        var textKind = getTextKind(pageItem);
        return textKind === TextType.POINTTEXT || textKind === TextType.PATHTEXT;
    }

    // =========================================
    // パス上文字 → ポイント文字（変換前処理）/ Path text → Point text (pre-process)
    // =========================================

    /**
     * 関数を実行し、例外は握りつぶす
     * @param {Function} fn - 実行する関数
     * @returns {*} 関数の戻り値。失敗したら undefined
     */
    function tryQuietly(fn) { try { return fn(); } catch (e) { return undefined; } }

    /**
     * パス上文字の文字ごとの属性を退避する
     * @param {TextFrame} textFrame - パス上文字
     * @returns {Object[]} 文字ごとの属性（font / size / fillColor / strokeColor / strokeWeight / autoLeading / leading）
     */
    function snapshotCharAttrs(textFrame) {
        var charAttrs = [];
        for (var i = 0; i < textFrame.characters.length; i++) {
            var charAttr = textFrame.characters[i].characterAttributes;
            charAttrs.push({
                font: charAttr.textFont,
                size: charAttr.size,
                fillColor: charAttr.fillColor,
                strokeColor: charAttr.strokeColor,
                strokeWeight: charAttr.strokeWeight,
                autoLeading: charAttr.autoLeading,
                leading: charAttr.leading
            });
        }
        return charAttrs;
    }

    /**
     * 退避した文字属性を新しいポイント文字へ戻す（ベースラインシフト・比率は既定に戻す）
     * @param {TextFrame} pointText - 新しいポイント文字
     * @param {Object[]} charAttrs - snapshotCharAttrs() の結果
     * @returns {void}
     */
    function restoreCharAttrs(pointText, charAttrs) {
        var restoreCount = Math.min(pointText.characters.length, charAttrs.length);
        for (var i = 0; i < restoreCount; i++) {
            var targetAttr = pointText.characters[i].characterAttributes;
            var sourceAttr = charAttrs[i];

            tryQuietly(function () { targetAttr.textFont = sourceAttr.font; });
            tryQuietly(function () { targetAttr.size = sourceAttr.size; });
            tryQuietly(function () { targetAttr.fillColor = sourceAttr.fillColor; });
            tryQuietly(function () {
                var sourceStroke = sourceAttr.strokeColor;
                targetAttr.strokeColor = sourceStroke;
                targetAttr.strokeWeight = (sourceStroke && sourceStroke.typename === "NoColor") ? 0 : sourceAttr.strokeWeight;
            });
            tryQuietly(function () { targetAttr.baselineShift = 0; });
            tryQuietly(function () { targetAttr.horizontalScale = 100; });
            tryQuietly(function () { targetAttr.verticalScale = 100; });
            tryQuietly(function () { targetAttr.autoLeading = sourceAttr.autoLeading; });
            if (!sourceAttr.autoLeading) tryQuietly(function () { targetAttr.leading = sourceAttr.leading; });
        }
    }

    /**
     * パス上文字と同じ内容・行揃え・文字属性のポイント文字を、パスの始点に作る
     * @param {Document} doc - 対象のドキュメント
     * @param {TextFrame} pathText - 元のパス上文字
     * @returns {TextFrame|null} 作ったポイント文字。パスを取れなければ null
     */
    function createPointTextFromPathText(doc, pathText) {
        var originalPath = null;
        tryQuietly(function () { originalPath = pathText.textPath; });
        if (!originalPath) return null;

        /* 1) 文字属性・内容・行揃えを退避 / Snapshot char attributes, contents, justification */
        var charAttrs = snapshotCharAttrs(pathText);

        var textContents = "";
        tryQuietly(function () { textContents = pathText.contents; });

        var justification = null;
        tryQuietly(function () {
            if (pathText.paragraphs && pathText.paragraphs.length > 0) {
                justification = pathText.paragraphs[0].paragraphAttributes.justification;
            }
        });

        /* 2) パス始点にポイント文字を新規作成 / Create new point text at path start anchor */
        var pointText = doc.textFrames.add();
        var anchorPoint = null;
        tryQuietly(function () {
            if (originalPath.pathPoints && originalPath.pathPoints.length > 0) {
                anchorPoint = originalPath.pathPoints[0].anchor;
            }
        });
        if (anchorPoint) {
            pointText.position = [anchorPoint[0], anchorPoint[1]];
        }

        pointText.contents = textContents;

        if (justification !== null && pointText.paragraphs && pointText.paragraphs.length > 0) {
            tryQuietly(function () { pointText.paragraphs[0].paragraphAttributes.justification = justification; });
        }

        /* 既定の線を一旦消し、後で文字ごとに復元 / Clear default stroke, restore per-character later */
        tryQuietly(function () {
            var noColor = new NoColor();
            pointText.textRange.characterAttributes.strokeColor = noColor;
            pointText.textRange.characterAttributes.strokeWeight = 0;
        });

        /* 3) 文字属性を復元 / Restore per-character attributes */
        restoreCharAttrs(pointText, charAttrs);
        return pointText;
    }

    /**
     * パス上文字を字形を保ったままポイント文字へ分離する（元のパス上文字は削除）
     * @param {Document} doc - 対象のドキュメント
     * @param {TextFrame[]} pathTextFrames - パス上文字
     * @returns {TextFrame[]} 作ったポイント文字（選択状態）
     */
    function detachPathTextToPointText(doc, pathTextFrames) {
        var createdTexts = [];
        if (!doc || !pathTextFrames || !pathTextFrames.length) return createdTexts;

        /* 新規テキストだけ選べるよう選択を解除 / Clear selection */
        tryQuietly(function () { doc.selection = null; });

        for (var i = pathTextFrames.length - 1; i >= 0; i--) {
            var pathText = pathTextFrames[i];
            if (!pathText || pathText.typename !== "TextFrame" || pathText.kind !== TextType.PATHTEXT) continue;

            var pointText = createPointTextFromPathText(doc, pathText);
            if (!pointText) continue;

            /* 4) 元のパス上文字を削除（パスも一緒に消える）/ Remove original path text */
            tryQuietly(function () { pathText.remove(); });

            /* 5) 新規テキストを選択して返す / Select and return new text */
            tryQuietly(function () { pointText.selected = true; });
            createdTexts.push(pointText);
        }

        return createdTexts;
    }

    /**
     * 選択内のパス上文字をポイント文字へ置き換え、選択し直す
     * @param {Document} doc - 対象のドキュメント
     * @param {PageItem[]} currentSelection - 現在の選択
     * @returns {PageItem[]} 置き換えた選択（パス上文字が無ければ元の選択）
     */
    function preprocessPathTextSelection(doc, currentSelection) {
        if (!doc || !currentSelection || !currentSelection.length) return currentSelection;

        var pathTexts = [];
        for (var i = 0; i < currentSelection.length; i++) {
            var selectedItem = currentSelection[i];
            try {
                if (selectedItem && selectedItem.typename === "TextFrame" && selectedItem.kind === TextType.PATHTEXT) {
                    pathTexts.push(selectedItem);
                }
            } catch (e0) {
                /* 無効オブジェクト（削除済み等）はスキップ / Skip invalid objects */
            }
        }
        if (!pathTexts.length) return currentSelection;

        var newTexts = detachPathTextToPointText(doc, pathTexts);
        if (!newTexts.length) return currentSelection;

        /* パス上文字を新ポイント文字に差し替えた新しい選択配列を構築。削除した旧オブジェクトは参照で例外になるので飛ばす
           Build the replaced selection; the removed originals throw on access and are skipped */
        var replacedSelection = [];
        for (var j = 0; j < currentSelection.length; j++) {
            var keptItem = currentSelection[j];
            try {
                if (keptItem && !(keptItem.typename === "TextFrame" && keptItem.kind === TextType.PATHTEXT)) {
                    replacedSelection.push(keptItem);
                }
            } catch (e1) {
                /* 無効オブジェクトはスキップ / Skip invalid objects */
            }
        }
        for (var k = 0; k < newTexts.length; k++) replacedSelection.push(newTexts[k]);

        try { doc.selection = replacedSelection; app.redraw(); } catch (e) { }

        return replacedSelection;
    }

    // 一時アクション（再利用パーツ） / Temporary action (reusable)

    /**
     * 文字列を UTF-8 のバイト列の16進にする（アクション定義の /name・/localizedName 用）
     * @param {string} sourceText - 変換する文字列
     * @returns {string} 16進の文字列（2文字で1バイト）
     */
    function toActionHex(sourceText) {
        var utf8Text = unescape(encodeURIComponent(String(sourceText)));
        var hexText = "";
        for (var i = 0; i < utf8Text.length; i++) {
            var hexByte = utf8Text.charCodeAt(i).toString(16);
            hexText += (hexByte.length < 2 ? "0" : "") + hexByte;
        }
        return hexText;
    }

    /**
     * アクション定義の「/name [ バイト数 16進 ]」の3行を返す
     * @param {string} indent - 行頭の字下げ（"\t" など）
     * @param {string} nameText - 名前
     * @param {string} [fieldName] - 項目名（既定は "name"。"localizedName" など）
     * @returns {string[]} 3行ぶんの配列
     */
    function buildActionNameLines(indent, nameText, fieldName) {
        var nameHex = toActionHex(nameText);
        return [
            indent + "/" + (fieldName || "name") + " [ " + (nameHex.length / 2),
            indent + "\t" + nameHex,
            indent + "]"
        ];
    }

    /**
     * アクション定義を一時ファイルに書き出してセットを読み込む。読み込んだら一時ファイルは消す
     * （読み込んだ時点で解釈済みなので、以降の失敗でファイルが残らない）
     * @param {string} actionSource - アクション定義のテキスト
     * @param {string} setName - アクションセット名
     * @returns {boolean} 読み込めたら true
     */
    function loadTemporaryActionSet(actionSource, setName) {
        var actionFile = new File(Folder.temp + "/" + setName + "_" + new Date().getTime() + ".aia");
        try {
            actionFile.encoding = "UTF-8";
            if (!actionFile.open("w")) throw new Error("cannot open " + actionFile.fsName);
            actionFile.write(actionSource);
            actionFile.close();
            /* 前回の失敗で同じ名前のセットが残っていれば外す / Remove a same-name set left by an earlier failure */
            unloadTemporaryActionSet(setName);
            app.loadAction(actionFile);
            return true;
        } catch (e) {
            $.writeln("loadTemporaryActionSet: " + e);
            return false;
        } finally {
            try { actionFile.close(); } catch (closeError) { /* 閉じ済み / already closed */ }
            try { actionFile.remove(); } catch (removeError) { /* 消せなくても続ける / keep going */ }
        }
    }

    /**
     * 一時アクションのセットを解除する（読み込まれていなくてもエラーにしない）
     * @param {string} setName - アクションセット名
     * @returns {void}
     */
    function unloadTemporaryActionSet(setName) {
        try {
            app.unloadAction(setName, "");
        } catch (e) {
            /* 読み込まれていない / not loaded */
        }
    }

    /**
     * アクション定義を読み込んで1回実行し、解除する。途中で失敗しても解除は必ず試みる
     * @param {string} actionSource - アクション定義のテキスト
     * @param {string} setName - アクションセット名
     * @param {string} actionName - 実行するアクション名
     * @returns {boolean} 実行できたら true
     */
    function runTemporaryAction(actionSource, setName, actionName) {
        if (!loadTemporaryActionSet(actionSource, setName)) return false;
        try {
            app.doScript(actionName, setName);
            return true;
        } catch (e) {
            $.writeln("runTemporaryAction: " + e);
            return false;
        } finally {
            unloadTemporaryActionSet(setName);
        }
    }

    // 一時アクション（再利用パーツ）ここまで / End of the reusable temporary action

    // ボタン行（再利用パーツ） / Button row (reusable)

    var BUTTON_ROW_TOP_MARGIN = 5; /* ボタン行の上の余白 / top margin of the button row */
    var BUTTON_ROW_BOTTOM_MARGIN = 14; /* ボタン行の下の余白。ダイアログの下余白と合わせて約30px（Illustrator 標準のダイアログに合わせる） / bottom margin; with the dialog margin about 30px, like Illustrator's own dialogs */
    var BUTTON_ROW_SPACING = 10;   /* ボタンどうしの間隔 / spacing between buttons */
    var BUTTON_ROW_CENTER_MAX_WIDTH = 240; /* 右のボタンだけの行を中央に置く、ダイアログの内側の最大幅（px、左右の余白を除く）。広いダイアログは右揃え / max inner dialog width (px, margins excluded) that centers a right-only row; wider dialogs keep it right-aligned */

    /**
     * ダイアログ下部のボタン行を作る。
     * 通常は「左のグループ・伸びるスペーサー・右のグループ」、centered なら行そのものを左右中央に置く
     * @param {Window|Group|Panel} parent - 行を足す先（ふつうはダイアログ）
     * @param {Object} [rowOptions] - { centered: true } で左右中央に並べる
     * @returns {{rowGroup: Group, leftGroup: Group|null, rightGroup: Group|null}} 行と左右のグループ（centered のときは左右が null）
     */
    function addButtonRow(parent, rowOptions) {
        var isCentered = !!(rowOptions && rowOptions.centered);
        var btnRowGroup = parent.add("group");
        btnRowGroup.orientation = "row";
        btnRowGroup.margins = [0, BUTTON_ROW_TOP_MARGIN, 0, BUTTON_ROW_BOTTOM_MARGIN];
        btnRowGroup.spacing = BUTTON_ROW_SPACING;

        if (isCentered) {
            btnRowGroup.alignment = ["center", "bottom"];
            btnRowGroup.alignChildren = ["center", "center"];
            return { rowGroup: btnRowGroup, leftGroup: null, rightGroup: null };
        }

        btnRowGroup.alignment = ["fill", "bottom"];

        var btnLeftGroup = btnRowGroup.add("group");
        btnLeftGroup.alignChildren = ["left", "center"];
        btnLeftGroup.spacing = BUTTON_ROW_SPACING;

        /* 余りの幅を吸って、右のグループを右端に寄せる / Absorbs the extra width so the right group sits at the right edge */
        var spacer = btnRowGroup.add("group");
        spacer.alignment = ["fill", "fill"];
        spacer.minimumSize.width = 0;

        var btnRightGroup = btnRowGroup.add("group");
        btnRightGroup.alignChildren = ["right", "center"];
        btnRightGroup.spacing = BUTTON_ROW_SPACING;

        return { rowGroup: btnRowGroup, leftGroup: btnLeftGroup, rightGroup: btnRightGroup };
    }

    /**
     * 左のグループにボタンが無い（右のボタンだけの）行を、ダイアログの幅に合わせて揃える。
     * 内側の幅（左右の余白を除く）が BUTTON_ROW_CENTER_MAX_WIDTH 以下なら左右中央、それより広ければ右揃えのまま。
     * 幅はレイアウトが決まるまで分からないので、ダイアログを表示した時点（show イベント）で判定する。
     * ボタンをすべて足したあと、show() の前に呼ぶ。centered で作った行や、左にボタンがある行はそのまま
     * @param {{rowGroup: Group, leftGroup: Group|null, rightGroup: Group|null}} buttonRow - addButtonRow() の戻り値
     * @returns {void}
     */
    function alignRightOnlyButtonRow(buttonRow) {
        if (!buttonRow.leftGroup || buttonRow.leftGroup.children.length > 0) return;
        var dialogWindow = buttonRow.rowGroup.window;
        dialogWindow.addEventListener("show", function () {
            if (!buttonRow.leftGroup) return;
            var btnRowGroup = buttonRow.rowGroup;
            /* 行の幅＝ダイアログの内側の幅（左右の余白を除く）/ The row spans the dialog's inner width (margins excluded) */
            if (!btnRowGroup.size || btnRowGroup.size.width > BUTTON_ROW_CENTER_MAX_WIDTH) return;
            /* 左のグループとスペーサーを外し、右のグループだけを中央に置く / Drop the left group and the spacer so only the right group remains, centered */
            btnRowGroup.remove(buttonRow.leftGroup);
            btnRowGroup.remove(btnRowGroup.children[0]); /* 左のグループを外すと先頭はスペーサー / the spacer is first once the left group is gone */
            btnRowGroup.alignment = ["center", "bottom"];
            btnRowGroup.alignChildren = ["center", "center"];
            buttonRow.leftGroup = null;
            dialogWindow.layout.layout(true);
        });
    }

    // ボタン行（再利用パーツ）ここまで / End of the reusable button row

    // =========================================
    // ダイナミックアクション / Dynamic actions
    // =========================================

    /**
     * アクション定義の /name ブロック（ASCII）を作る
     * @param {string} actionName - アクション名またはセット名
     * @returns {string} /name ブロック
     */
    function buildActionNameBlock(actionName) {
        var nameHex = toActionHex(actionName);
        return "/name [ " + (nameHex.length / 2) + " " + nameHex.toUpperCase() + " ]";
    }

    /**
     * アクションセット定義（.aia）の文字列を組み立てる
     * @param {string} setName - アクションセット名
     * @param {string} internalName - イベントの内部名
     * @param {string} localizedNameHex - ローカライズ名（"長さ 16進" 形式。空なら省略）
     * @param {number} parameterKey - パラメーターのキー
     * @param {Object[]} actionDefinitions - { name, value } のアクション定義
     * @returns {string} .aia の文字列
     */
    function buildActionSetAia(setName, internalName, localizedNameHex, parameterKey, actionDefinitions) {
        var aiaString = "/version 3" +
            buildActionNameBlock(setName) +
            "/isOpen 1" +
            "/actionCount " + actionDefinitions.length;

        for (var i = 0; i < actionDefinitions.length; i++) {
            var actionDef = actionDefinitions[i];
            aiaString += "/action-" + (i + 1) + " {" +
                " " + buildActionNameBlock(actionDef.name) +
                " /keyIndex 0" +
                " /colorIndex 0" +
                " /isOpen 1" +
                " /eventCount 1" +
                " /event-1 {" +
                " /useRulersIn1stQuadrant 0" +
                " /internalName (" + internalName + ")" +
                (localizedNameHex ? (" /localizedName [ " + localizedNameHex + " ]") : "") +
                " /isOpen 0" +
                " /isOn 1" +
                " /hasDialog 0" +
                " /parameterCount 1" +
                " /parameter-1 {" +
                " /key " + parameterKey +
                " /showInPalette 4294967295" +
                " /type (integer)" +
                " /value " + actionDef.value +
                " }" +
                " }" +
                "}";
        }
        return aiaString;
    }

    /* フレーム整列アクションセット名 / Frame-alignment action set name */
    var AREA_TEXT_ACTION_SET = "AreaText";

    /**
     * フレーム整列（縦中央）アクションを読み込む（失敗しても縦中央を省くだけで変換は続ける）
     * @returns {void}
     */
    function loadFrameAlignmentAction() {
        var aiaString = buildActionSetAia(
            AREA_TEXT_ACTION_SET,
            "adobe_frameAlignment",
            "39 e382a8e383aae382a2e58685e69687e5ad97e381aee38395e383ace383bce383a0e695b4e58897",
            1717660782,
            [{ name: "AlignCenter", value: 1 }]
        );
        loadTemporaryActionSet(aiaString, AREA_TEXT_ACTION_SET);
    }

    /**
     * フレーム整列アクションを破棄する
     * @returns {void}
     */
    function unloadFrameAlignmentAction() {
        unloadTemporaryActionSet(AREA_TEXT_ACTION_SET);
    }

    /**
     * エリア内文字を縦方向中央に配置する（DOM では不安定なためアクション再生）
     * @param {TextFrame} areaType - 対象のエリア内文字
     * @returns {void}
     */
    function applyVerticalCenter(areaType) {
        try {
            var doc = app.activeDocument;
            doc.selection = null;
            doc.selection = [areaType];
            app.redraw(); /* 選択状態を確定 / Commit the selection */
            app.doScript("AlignCenter", AREA_TEXT_ACTION_SET, false);
        } catch (e) { }
    }

    // =========================================
    // グラフィックスタイル登録 / Graphic style registration
    // =========================================

    /* 一時グラフィックスタイル名とアクション / Temp graphic style name and action */
    var TEMP_STYLE_NAME = "temp_style";
    var TEMP_STYLE_ACTION_SET = "GraphicStyle";
    var TEMP_STYLE_ACTION_NAME = "AddNewWithoutName";

    /* 選択オブジェクトの見た目を無名グラフィックスタイルとして末尾に追加するアクション定義(.aia)
       Dynamic action (.aia) that appends the selection's appearance as an unnamed graphic style */
    var GRAPHIC_STYLE_AIA = '/version 3 /name [ 12 477261706869635374796c65 ] /isOpen 1 /actionCount 1 /action-1 { /name [ 17 4164644e6577576974686f75744e616d65 ] /keyIndex 0 /colorIndex 0 /isOpen 1 /eventCount 1 /event-1 { /useRulersIn1stQuadrant 0 /internalName (ai_plugin_styles) /localizedName [ 30 e382b0e383a9e38395e382a3e38383e382afe382b9e382bfe382a4e383ab ] /isOpen 1 /isOn 1 /hasDialog 1 /showDialog 0 /parameterCount 1 /parameter-1 { /key 1835363957 /showInPalette 4294967295 /type (enumerated) /name [ 36 e696b0e8a68fe382b0e383a9e38395e382a3e38383e382afe382b9e382bfe382a4e383ab ] /value 1 } } }';

    /**
     * テキストフレームの見た目を temp_style として登録する（既存があれば作り直す）
     * @param {TextFrame} textFrame - 見た目の元になるテキストフレーム
     * @returns {string|null} 登録したスタイル名。登録できなければ null
     */
    function registerTextFrameAsTempGraphicStyle(textFrame) {
        if (!textFrame) return null;
        var doc = app.activeDocument;
        var graphicStyles = doc.graphicStyles;

        /* 既存の temp_style を削除 / Remove any existing temp_style */
        removeGraphicStyleByName(TEMP_STYLE_NAME);

        /* 登録用に対象だけを選択 / Select only the target for registration */
        doc.selection = null;
        try { textFrame.selected = true; } catch (selectError) { return null; }

        var countBefore = graphicStyles.length;
        /* 失敗はスタイル数が増えないことで判定する / A failure shows up as no new style */
        runTemporaryAction(GRAPHIC_STYLE_AIA, TEMP_STYLE_ACTION_SET, TEMP_STYLE_ACTION_NAME);

        /* 末尾に増えたスタイルを temp_style に改名 / Rename the newly appended style to temp_style */
        if (graphicStyles.length <= countBefore) return null;
        graphicStyles[graphicStyles.length - 1].name = TEMP_STYLE_NAME;
        return TEMP_STYLE_NAME;
    }

    /**
     * 名前でグラフィックスタイルを適用する
     * @param {string} styleName - グラフィックスタイル名
     * @param {PageItem} targetItem - 適用先
     * @returns {boolean} 適用できたら true
     */
    function applyGraphicStyleByName(styleName, targetItem) {
        if (!styleName || !targetItem) return false;
        try {
            app.activeDocument.graphicStyles.getByName(styleName).applyTo(targetItem);
            return true;
        } catch (e) { return false; }
    }

    /**
     * 名前でグラフィックスタイルを削除する（無ければ何もしない）
     * @param {string} styleName - グラフィックスタイル名
     * @returns {void}
     */
    function removeGraphicStyleByName(styleName) {
        if (!styleName) return;
        try { app.activeDocument.graphicStyles.getByName(styleName).remove(); } catch (e) { }
    }

    // 選択の収集と境界（再利用パーツ） / Selection items and bounds (reusable)

    /* 座標を同じと見なす許容値（pt） / Tolerance for treating coordinates as equal, in points */
    var SELECTION_ITEMS_TOLERANCE = 0.001;

    /**
     * 選択やコレクションを、オブジェクトの配列にそろえる
     * TextRange・PathItem は length を持つので、typename で1個か集まりかを見分ける
     * @param {*} source - doc.selection、配列、DOM のコレクション、または単独のオブジェクト
     * @returns {Array} オブジェクトの配列（空なら []）
     */
    function normalizeSelectionItems(source) {
        var items = [];
        if (!source) return items;
        var typeName = "";
        try { typeName = source.typename || ""; } catch (e) { /* 読めない種類 / unreadable kind */ }
        /* 単数形の typename は1個（PageItems などのコレクションは s で終わる）
           A singular typename is one object (collections such as PageItems end in s) */
        if (typeName && !/s$/.test(typeName)) return [source];
        if (typeof source.length !== "number") return items;
        for (var i = 0; i < source.length; i++) items.push(source[i]);
        return items;
    }

    /**
     * 文字カーソルの選択（TextRange）を、それを含むテキストフレームに読み替える
     * @param {TextRange} textRange - 文字の範囲
     * @returns {TextFrame|null} テキストフレーム（たどれなければ null）
     */
    function resolveTextRangeFrame(textRange) {
        var current = textRange;
        /* parent をたどる（深さは念のため制限） / Walk up the parents, with a safety limit */
        for (var depth = 0; depth < 10 && current; depth++) {
            try {
                if (current.typename === "TextFrame") return current;
                current = current.parent;
            } catch (e) {
                break;
            }
        }
        /* ストーリーの先頭フレームで代用する / Fall back to the first frame of the story */
        try {
            var storyFrames = textRange.story.textFrames;
            if (storyFrames.length > 0) return storyFrames[0];
        } catch (e2) { /* ストーリーを持たない / no story */ }
        return null;
    }

    /**
     * 選択から条件に合うオブジェクトを集める（グループ・レイヤーを再帰でたどり、重複は除く）
     * 条件に合ったオブジェクトの中へは進まない
     * @param {*} source - doc.selection、配列、コレクション、または単独のオブジェクト
     * @param {Object} [options] - 収集の設定
     * @param {function(PageItem): boolean} [options.accept] - 集める条件（既定はグループ・レイヤー以外すべて）
     * @param {boolean} [options.enterGroups] - グループの中をたどる（既定 true）
     * @param {boolean} [options.enterClipGroups] - クリップグループの中をたどる（既定は enterGroups と同じ）
     * @param {boolean} [options.enterCompoundPaths] - 複合パスの中のパスをたどる（既定 false）
     * @param {boolean} [options.textRangeToFrame] - 文字の選択をテキストフレームに読み替える（既定 true）
     * @param {boolean} [options.skipLocked] - ロックされたものを中ごと外す（既定 false）
     * @param {boolean} [options.skipHidden] - 非表示のものを中ごと外す（既定 false）
     * @param {boolean} [options.skipClipMasks] - クリッピングマスクを外す（既定 false）
     * @param {boolean} [options.skipGuides] - ガイドを外す（既定 false）
     * @param {boolean} [options.unique] - 同じ参照を1回だけにする（既定 true。数千件で遅ければ false）
     * @returns {Array} 集めたオブジェクト（前面→背面の順）
     */
    function collectSelectionItems(source, options) {
        var opts = options || {};
        var enterGroups = (opts.enterGroups !== false);
        var enterClipGroups = (opts.enterClipGroups === undefined) ? enterGroups : (opts.enterClipGroups === true);
        var accept = opts.accept || function (item) {
            return item.typename !== "GroupItem" && item.typename !== "Layer";
        };
        var collected = [];

        /**
         * 集めた配列に加える（unique のときは同じ参照を足さない）
         * @param {PageItem} item - 加えるオブジェクト
         * @returns {void}
         */
        function pushItem(item) {
            if (opts.unique !== false) {
                for (var k = 0; k < collected.length; k++) {
                    if (collected[k] === item) return;
                }
            }
            collected.push(item);
        }

        /**
         * 設定に従って外すオブジェクトか判定する
         * @param {PageItem} item - 判定するオブジェクト
         * @returns {boolean} 外すなら true
         */
        function isSkipped(item) {
            try {
                if (item.typename === "Layer") {
                    if (opts.skipLocked && item.locked) return true;
                    if (opts.skipHidden && !item.visible) return true;
                    return false;
                }
                if (opts.skipLocked && item.locked) return true;
                if (opts.skipHidden && item.hidden) return true;
                if (opts.skipGuides && item.guides === true) return true;
                if (opts.skipClipMasks && isClipMaskItem(item)) return true;
            } catch (e) {
                /* 読めないプロパティは「外さない」に倒す / Unreadable properties do not exclude */
            }
            return false;
        }

        /**
         * 1件をたどって集める
         * @param {PageItem} item - 対象のオブジェクト
         * @returns {void}
         */
        function visit(item) {
            if (!item) return;
            var typeName = "";
            try { typeName = item.typename; } catch (e) { return; }

            if (typeName === "TextRange" || typeName === "InsertionPoint") {
                if (opts.textRangeToFrame === false) {
                    if (accept(item)) pushItem(item);
                    return;
                }
                visit(resolveTextRangeFrame(item));
                return;
            }
            if (isSkipped(item)) return;
            if (accept(item)) {
                pushItem(item);
                return;
            }

            var children = null;
            if (typeName === "GroupItem") {
                var isClipped = false;
                try { isClipped = (item.clipped === true); } catch (e2) { }
                if (isClipped ? enterClipGroups : enterGroups) children = item.pageItems;
            } else if (typeName === "CompoundPathItem") {
                if (opts.enterCompoundPaths) children = item.pathItems;
            } else if (typeName === "Layer") {
                /* 重なり順はサブレイヤーとページアイテムで別々なので、ページアイテム→サブレイヤーの順にする
                   Page items and sublayers stack separately; visit page items first, then sublayers */
                walk(item.pageItems);
                walk(item.layers);
                return;
            }
            if (children) walk(children);
        }

        /**
         * 集まりの各要素をたどる
         * @param {*} list - 配列またはコレクション
         * @returns {void}
         */
        function walk(list) {
            var listItems = normalizeSelectionItems(list);
            for (var i = 0; i < listItems.length; i++) visit(listItems[i]);
        }

        walk(source);
        return collected;
    }

    /**
     * テキストフレームの種類を "point" / "area" / "path" で返す
     * @param {TextFrame} textFrame - テキストフレーム
     * @returns {string} 種類のキー（判定できなければ ""）
     */
    function getTextFrameKindKey(textFrame) {
        try {
            if (textFrame.kind === TextType.POINTTEXT) return "point";
            if (textFrame.kind === TextType.AREATEXT) return "area";
            if (textFrame.kind === TextType.PATHTEXT) return "path";
        } catch (e) { /* kind を読めない / kind is unreadable */ }
        return "";
    }

    /**
     * 選択からテキストフレームを集める（グループの中・文字カーソルの選択を含む）
     * @param {*} source - doc.selection など
     * @param {Object} [options] - collectSelectionItems と同じ設定に加えて次を受ける
     * @param {string[]} [options.kinds] - 集める種類（"point" / "area" / "path"。既定はすべて）
     * @returns {TextFrame[]} テキストフレーム（前面→背面の順）
     */
    function collectSelectionTextFrames(source, options) {
        var opts = {};
        var sourceOptions = options || {};
        for (var key in sourceOptions) {
            if (sourceOptions.hasOwnProperty(key)) opts[key] = sourceOptions[key];
        }
        var kindFilter = null;
        if (opts.kinds && opts.kinds.length) {
            kindFilter = {};
            for (var i = 0; i < opts.kinds.length; i++) kindFilter[opts.kinds[i]] = true;
        }
        opts.accept = function (item) {
            if (item.typename !== "TextFrame") return false;
            return !kindFilter || kindFilter[getTextFrameKindKey(item)] === true;
        };
        /* 種類で外したテキストは中をたどらない（accept が false でも子は無い） / Text frames have no children to walk */
        return collectSelectionItems(source, opts);
    }

    /**
     * 選択からパスを集める（グループの中を含む）
     * @param {*} source - doc.selection など
     * @param {Object} [options] - collectSelectionItems と同じ設定に加えて次を受ける
     * @param {string} [options.compoundPaths] - 複合パスの扱い。"children"（中のパス、既定）/ "whole"（複合パスごと）/ "skip"（外す）
     * @returns {Array} PathItem（"whole" のときは CompoundPathItem も）の配列
     */
    function collectSelectionPathItems(source, options) {
        var opts = {};
        var sourceOptions = options || {};
        for (var key in sourceOptions) {
            if (sourceOptions.hasOwnProperty(key)) opts[key] = sourceOptions[key];
        }
        var compoundMode = opts.compoundPaths || "children";
        opts.enterCompoundPaths = (compoundMode === "children");
        opts.accept = function (item) {
            if (item.typename === "PathItem") return true;
            return compoundMode === "whole" && item.typename === "CompoundPathItem";
        };
        return collectSelectionItems(source, opts);
    }

    /**
     * クリッピングマスク（クリップグループの型）か判定する
     * パスは clipping、複合パスは中の先頭パスの clipping、テキストは clipping が無いので「クリップグループの先頭」で見る
     * @param {PageItem} item - 判定するオブジェクト
     * @returns {boolean} マスクなら true
     */
    function isClipMaskItem(item) {
        try {
            if (item.typename === "PathItem") return item.clipping === true;
            if (item.typename === "CompoundPathItem") {
                return item.pathItems.length > 0 && item.pathItems[0].clipping === true;
            }
            if (item.typename === "TextFrame") {
                var parentGroup = item.parent;
                return parentGroup.typename === "GroupItem" && parentGroup.clipped === true &&
                    parentGroup.pageItems.length > 0 && parentGroup.pageItems[0] === item;
            }
        } catch (e) { /* 読めない種類はマスクではない / unreadable kinds are not masks */ }
        return false;
    }

    /**
     * クリップグループの型（マスク）を返す
     * フラグで探し、見つからなければ先頭（pageItems[0]）を返す（型は常に最前面。テキストの型はフラグを持たない）
     * @param {GroupItem} groupItem - 対象のグループ
     * @returns {PageItem|null} マスク（クリップグループでなければ null）
     */
    function getClipMaskItem(groupItem) {
        try {
            if (!groupItem || groupItem.typename !== "GroupItem" || groupItem.clipped !== true) return null;
            var groupChildren = groupItem.pageItems;
            if (groupChildren.length === 0) return null;
            for (var i = 0; i < groupChildren.length; i++) {
                var childType = groupChildren[i].typename;
                if ((childType === "PathItem" || childType === "CompoundPathItem") && isClipMaskItem(groupChildren[i])) {
                    return groupChildren[i];
                }
            }
            return groupChildren[0];
        } catch (e) {
            return null;
        }
    }

    /**
     * グループの中（入れ子を含む）にクリップグループがあるか判定する
     * @param {GroupItem} groupItem - 対象のグループ
     * @returns {boolean} あれば true
     */
    function hasClippedDescendant(groupItem) {
        try {
            var groupChildren = groupItem.pageItems;
            for (var i = 0; i < groupChildren.length; i++) {
                if (groupChildren[i].typename !== "GroupItem") continue;
                if (groupChildren[i].clipped === true || hasClippedDescendant(groupChildren[i])) return true;
            }
        } catch (e) { /* 中を読めない / cannot read the children */ }
        return false;
    }

    /**
     * 環境設定の［プレビュー境界を使用］を読む
     * @returns {boolean} オンなら true（読めなければ false）
     */
    function readUsePreviewBoundsPreference() {
        try {
            return app.preferences.getBooleanPreference("includeStrokeInBounds");
        } catch (e) {
            return false;
        }
    }

    /**
     * 見た目どおりの境界を返す。クリップグループはマスクの境界、
     * 中にクリップグループを含むグループは子の境界を合わせたもの（隠れた部分を含めない）
     * @param {PageItem} item - 対象のオブジェクト
     * @param {boolean} [usePreviewBounds] - true で visibleBounds、false で geometricBounds（省略時は環境設定に従う）
     * @returns {number[]|null} [左, 上, 右, 下] の新しい配列（測れなければ null）
     */
    function getClipAwareBounds(item, usePreviewBounds) {
        var usePreview = (usePreviewBounds === undefined || usePreviewBounds === null) ?
            readUsePreviewBoundsPreference() : (usePreviewBounds === true);
        try {
            var measuredItem = item;
            if (item.typename === "GroupItem") {
                var maskItem = getClipMaskItem(item);
                if (maskItem) {
                    measuredItem = maskItem;
                } else if (hasClippedDescendant(item)) {
                    /* グループ自体の効果（影など）の広がりは含まれなくなる
                       This leaves out the reach of effects applied to the group itself (drop shadows etc.) */
                    var childBounds = getClipAwareUnionBounds(filterMeasurableChildren(item.pageItems), usePreview);
                    if (childBounds) return childBounds;
                }
            }
            var bounds = usePreview ? measuredItem.visibleBounds : measuredItem.geometricBounds;
            return [bounds[0], bounds[1], bounds[2], bounds[3]];
        } catch (e) {
            return null;
        }
    }

    /**
     * 境界の計算に入れる子だけを残す（非表示とガイドを外す）
     * @param {*} childList - 子のコレクション
     * @returns {Array} 残した子
     */
    function filterMeasurableChildren(childList) {
        var childItems = normalizeSelectionItems(childList);
        var measurable = [];
        for (var i = 0; i < childItems.length; i++) {
            try {
                if (childItems[i].hidden === true || childItems[i].guides === true) continue;
            } catch (e) { /* 読めなければ残す / keep when unreadable */ }
            measurable.push(childItems[i]);
        }
        return measurable;
    }

    /**
     * 複数のオブジェクトを囲む外接範囲を返す（クリップグループはマスクで測る）
     * @param {*} items - オブジェクトの配列・コレクション・選択
     * @param {boolean} [usePreviewBounds] - true で visibleBounds、false で geometricBounds（省略時は環境設定に従う）
     * @returns {number[]|null} [左, 上, 右, 下]（測れるものが無ければ null）
     */
    function getClipAwareUnionBounds(items, usePreviewBounds) {
        var usePreview = (usePreviewBounds === undefined || usePreviewBounds === null) ?
            readUsePreviewBoundsPreference() : (usePreviewBounds === true);
        var itemList = normalizeSelectionItems(items);
        var unionBounds = null;
        for (var i = 0; i < itemList.length; i++) {
            var itemBounds = getClipAwareBounds(itemList[i], usePreview);
            if (!itemBounds) continue;
            if (!unionBounds) {
                unionBounds = itemBounds;
                continue;
            }
            if (itemBounds[0] < unionBounds[0]) unionBounds[0] = itemBounds[0];
            if (itemBounds[1] > unionBounds[1]) unionBounds[1] = itemBounds[1];
            if (itemBounds[2] > unionBounds[2]) unionBounds[2] = itemBounds[2];
            if (itemBounds[3] < unionBounds[3]) unionBounds[3] = itemBounds[3];
        }
        return unionBounds;
    }

    /**
     * 2つの座標を許容値つきで比べる
     * @param {number} valueA - 座標A（pt）
     * @param {number} valueB - 座標B（pt）
     * @param {number} [tolerance] - 許容値（pt、既定は SELECTION_ITEMS_TOLERANCE）
     * @returns {boolean} 差が許容値以下なら true
     */
    function isNearlySameCoordinate(valueA, valueB, tolerance) {
        var limit = (typeof tolerance === "number") ? tolerance : SELECTION_ITEMS_TOLERANCE;
        return Math.abs(valueA - valueB) <= limit;
    }

    /**
     * 2つの境界を許容値つきで比べる
     * @param {number[]} boundsA - [左, 上, 右, 下]
     * @param {number[]} boundsB - [左, 上, 右, 下]
     * @param {number} [tolerance] - 許容値（pt、既定は SELECTION_ITEMS_TOLERANCE）
     * @returns {boolean} 4辺とも許容値以内なら true
     */
    function areBoundsNearlyEqual(boundsA, boundsB, tolerance) {
        if (!boundsA || !boundsB) return false;
        for (var i = 0; i < 4; i++) {
            if (!isNearlySameCoordinate(boundsA[i], boundsB[i], tolerance)) return false;
        }
        return true;
    }

    // 選択の収集と境界（再利用パーツ）ここまで / End of the reusable selection items and bounds

    // =========================================
    // 正確なサイズ計測 / Accurate size measurement
    // =========================================

    /**
     * 複製 → アピアランス分割 → アウトラインで正確な可視サイズを測り、複製を破棄する
     * @param {PageItem} sourceItem - 測るオブジェクト
     * @returns {Object|null} { left, top, right, bottom, width, height }。測れなければ null
     */
    function measureAccurateBounds(sourceItem) {
        var doc = app.activeDocument;
        var savedSelection = doc.selection;
        var measuredBounds = null;
        var duplicatedItem = null;
        try {
            duplicatedItem = sourceItem.duplicate();
            doc.selection = null;
            duplicatedItem.selected = true;
            app.redraw();

            /* アピアランスを分割 / Expand appearance */
            try { app.executeMenuCommand('expandStyle'); } catch (e) { }
            /* テキストのアウトライン / Create outlines */
            try { app.executeMenuCommand('outline'); } catch (e) { }
            app.redraw();

            /* 分割・アウトライン後の選択全体のサイズを計測 / Measure bounds of the resulting selection */
            var expandedItems = doc.selection;
            var bounds = getClipAwareUnionBounds(expandedItems, true);
            if (bounds) {
                measuredBounds = { left: bounds[0], top: bounds[1], right: bounds[2], bottom: bounds[3], width: bounds[2] - bounds[0], height: bounds[1] - bounds[3] };
            }

            /* 複製（分割・アウトライン結果）を削除 / Remove the duplicate (expanded/outlined result) */
            for (var i = expandedItems.length - 1; i >= 0; i--) {
                try { expandedItems[i].remove(); } catch (e2) { }
            }
        } catch (e0) {
            if (duplicatedItem) { try { duplicatedItem.remove(); } catch (e3) { } }
        }

        try { doc.selection = savedSelection; } catch (e4) { }
        return measuredBounds;
    }

    // =========================================
    // シェイプ効果 / Shape effect
    // =========================================

    /**
     * ［形状に変換：長方形］固定モードのライブエフェクト定義を組み立てる
     * @param {number} width - 幅（pt）
     * @param {number} height - 高さ（pt）
     * @returns {string} ライブエフェクトの XML
     */
    function buildRectangleShapeEffectXML(width, height) {
        return '<LiveEffect name="Adobe Shape Effects" isPre="1"><Dict data="U DisplayString Rectangle I Shape 0 R RelWidth 0 R RelHeight 0 R AbsWidth ' + width + ' R AbsHeight ' + height + ' R Absolute 1 R CornerRadius 9 "/></LiveEffect>';
    }

    /**
     * 対象だけを選択し直す
     * @param {PageItem} targetItem - 選択するオブジェクト
     * @returns {void}
     */
    function reselectOnly(targetItem) {
        app.activeDocument.selection = null;
        targetItem.selected = true;
        app.redraw();
    }

    /**
     * 対象を選択し直してから New Fill を1枚追加する（毎回選択し直さないと2枚目が効かない）
     * @param {PageItem} targetItem - 塗りを足すオブジェクト
     * @returns {void}
     */
    function addNewFill(targetItem) {
        reselectOnly(targetItem);
        app.executeMenuCommand('Adobe New Fill Shortcut');
        app.redraw();
    }

    /**
     * 塗りを2枚追加し、固定サイズ（幅×高さ）の長方形シェイプ効果でボタン状の背景にする（塗り色は設定しない）
     * エリア→ポイント変換直後のテキストは最初の New Fill が吸収されるため、1回“空打ち”してから2枚追加する（計3回）
     * @param {PageItem} targetItem - 背景を付けるオブジェクト
     * @param {number} width - 背景の幅（pt）
     * @param {number} height - 背景の高さ（pt）
     * @returns {void}
     */
    function applyButtonBackgroundSized(targetItem, width, height) {
        try {
            addNewFill(targetItem); /* 空打ち（吸収される）/ primer (gets absorbed) */
            addNewFill(targetItem); /* 塗り1 / fill 1 */
            addNewFill(targetItem); /* 塗り2 / fill 2 */
            reselectOnly(targetItem);
            targetItem.applyEffect(buildRectangleShapeEffectXML(width, height));
        } catch (e) { }
    }

    // =========================================
    // 変換 / Conversion
    // =========================================

    /**
     * geometricBounds を { left, top, width, height } で返す
     * @param {PageItem} pageItem - 対象のオブジェクト
     * @returns {Object} { left, top, width, height }
     */
    function geometricBoundsOf(pageItem) {
        var bounds = pageItem.geometricBounds;
        return { left: bounds[0], top: bounds[1], width: bounds[2] - bounds[0], height: bounds[1] - bounds[3] };
    }

    /**
     * 元テキストの自動カーニングと文字組みアキ量設定を取得する
     * @param {TextFrame} sourceText - 元テキスト
     * @returns {Object} { kerningMethod, mojikumi }（取れなければ null）
     */
    function readKerningAndMojikumi(sourceText) {
        var snapshot = { kerningMethod: null, mojikumi: null };
        try { snapshot.kerningMethod = sourceText.textRange.characterAttributes.kerningMethod; } catch (e) { }
        /* 文字組みアキ量設定「なし」は読むと例外 / Reading mojikumi "None" throws */
        try {
            if (sourceText.paragraphs.length > 0) {
                snapshot.mojikumi = sourceText.paragraphs[0].paragraphAttributes.mojikumi;
            }
        } catch (e2) { }
        return snapshot;
    }

    /**
     * 自動カーニングと文字組みアキ量設定をエリア内文字へ適用する
     * @param {TextFrame} areaType - 適用先のエリア内文字
     * @param {Object} snapshot - readKerningAndMojikumi() の結果
     * @returns {void}
     */
    function applyKerningAndMojikumi(areaType, snapshot) {
        if (snapshot.kerningMethod !== null) {
            try { areaType.textRange.characterAttributes.kerningMethod = snapshot.kerningMethod; } catch (e) { }
        }
        if (snapshot.mojikumi !== null && snapshot.mojikumi !== undefined) {
            var paragraphs = areaType.paragraphs;
            for (var i = 0; i < paragraphs.length; i++) {
                try { paragraphs[i].paragraphAttributes.mojikumi = snapshot.mojikumi; } catch (e2) { }
            }
        }
    }

    /**
     * 図形パスをエリア内文字にして、元テキストの内容・フォント・カーニング・文字組み・グラフィックスタイルを移す
     * @param {Document} doc - 対象のドキュメント
     * @param {PathItem} framePath - 枠にするパス
     * @param {TextFrame} sourceText - 元テキスト
     * @param {string|null} graphicStyleName - 適用するグラフィックスタイル名（null なら適用しない）
     * @returns {TextFrame} 作ったエリア内文字
     */
    function fillAreaTypeFromSourceText(doc, framePath, sourceText, graphicStyleName) {
        var sourceFont = null, sourceSize = 0;
        try {
            var sourceAttributes = sourceText.textRange.characterAttributes;
            sourceFont = sourceAttributes.textFont;
            sourceSize = sourceAttributes.size;
        } catch (e) { }
        var typeSnapshot = readKerningAndMojikumi(sourceText);

        var areaType = doc.textFrames.areaText(framePath);
        areaType.contents = sourceText.contents;
        try {
            if (sourceFont) areaType.textRange.characterAttributes.textFont = sourceFont;
            if (sourceSize > 0) areaType.textRange.characterAttributes.size = sourceSize;
        } catch (e2) { }
        applyKerningAndMojikumi(areaType, typeSnapshot);

        /* 登録したグラフィックスタイルを適用（削除は呼び出し側が finally で行う）
           Apply the registered graphic style (the caller removes it in a finally block) */
        if (graphicStyleName) { applyGraphicStyleByName(graphicStyleName, areaType); }
        return areaType;
    }

    /**
     * エリア内文字の内容を水平・垂直とも中央にする
     * @param {TextFrame} areaType - 対象のエリア内文字
     * @returns {void}
     */
    function centerAreaTypeContents(areaType) {
        try { areaType.textRange.paragraphAttributes.justification = Justification.CENTER; } catch (e) { }
        applyVerticalCenter(areaType); /* 縦位置は中央（アクション再生）/ Vertical center (via action) */
    }

    /* 変換中に握り潰した最後の例外（0件時にアラートで理由を添える）/ Last swallowed exception during conversion (surfaced on a 0-result alert) */
    var lastConversionError = null;

    /**
     * 変換結果を選択する。0件なら理由を添えてアラートを出す
     * @param {TextFrame[]} convertedItems - 変換で作ったテキスト
     * @param {string} alertKey - 0件のときのアラートの LABELS パス
     * @returns {void}
     */
    function finishConversion(convertedItems, alertKey) {
        if (convertedItems.length > 0) {
            try { app.activeDocument.selection = convertedItems; app.redraw(); } catch (e) { }
        } else {
            /* 1件も変換できなかった＝内部で例外を握り潰している。無言終了せず理由を伝える
               Nothing converted = an exception was swallowed internally. Surface it instead of exiting silently */
            var failMessage = getLabel(alertKey);
            if (lastConversionError) { failMessage += "\n" + lastConversionError; }
            alert(failMessage);
        }
    }

    /**
     * 選択内のテキストをエリア内文字へ変換する（パス上文字は先にポイント文字へ分離）
     * @param {Document} doc - 対象のドキュメント
     * @param {PageItem[]} currentSelection - 現在の選択
     * @param {Object} styleOptions - ダイアログの結果 { keepStyle }
     * @returns {void}
     */
    function convertSelectionToAreaType(doc, currentSelection, styleOptions) {
        lastConversionError = null;
        preprocessPathTextSelection(doc, currentSelection);

        /* 前処理で選択が差し替わるので取り直す / The pre-process replaces the selection, so read it again */
        var refreshedSelection = doc.selection;
        if (!refreshedSelection || refreshedSelection.length === 0) { return; }

        /* 変換元テキストの有無を判定 / Detect source text */
        var hasSourceText = false;
        for (var i = 0; i < refreshedSelection.length; i++) {
            if (isPointOrPathText(refreshedSelection[i])) hasSourceText = true;
        }
        if (!hasSourceText) { return; }

        /* 計測した実寸でフレーム化してエリア内文字へ / Frame at the measured real size, then convert to area type */
        finishConversion(convertPointTextToMeasuredArea(doc, refreshedSelection, styleOptions), "alert.conversionFailed");
    }

    /**
     * 計測した実寸でフレームを作り、テキストを流し込んで中央配置する（元のポイント文字は削除）
     * @param {Document} doc - 対象のドキュメント
     * @param {PageItem[]} targetItems - 対象（ポイント文字だけを変換）
     * @param {Object} styleOptions - ダイアログの結果 { keepStyle }
     * @returns {TextFrame[]} 作ったエリア内文字
     */
    function convertPointTextToMeasuredArea(doc, targetItems, styleOptions) {
        var createdAreaTypes = [];

        /* スタイル「保持する」なら見た目を一時スタイルで引き継ぐ（既定）/ Keep appearance via a temp style when "Keep" (default) */
        var keepStyle = !styleOptions || styleOptions.keepStyle !== false;

        for (var i = targetItems.length - 1; i >= 0; i--) {
            var sourceText = targetItems[i];
            if (getTextKind(sourceText) !== TextType.POINTTEXT) continue;
            /* 「保持する」のときだけ、元テキストの見た目を一時グラフィックスタイルとして登録
               Register the source text's appearance as a temp graphic style only when "Keep" */
            var tempStyleName = keepStyle ? registerTextFrameAsTempGraphicStyle(sourceText) : null;
            try {
                /* 複製→アピアランス分割→アウトラインで正確な可視サイズを計測（保持する/しない共通）
                   Measure accurate visible size via expand appearance → outline (same for keep / don't keep) */
                var measuredBounds = measureAccurateBounds(sourceText) || geometricBoundsOf(sourceText);
                /* 計測した実寸そのままの長方形をフレームに / Frame at the measured size as-is */
                var framePath = doc.pathItems.rectangle(measuredBounds.top, measuredBounds.left, measuredBounds.width, measuredBounds.height);
                framePath.filled = false; framePath.stroked = false;
                var areaType = fillAreaTypeFromSourceText(doc, framePath, sourceText, tempStyleName);
                centerAreaTypeContents(areaType);
                createdAreaTypes.push(areaType);
                sourceText.remove();
            } catch (e) {
                lastConversionError = e; /* 失敗理由を保持（0件時にアラートで表示）/ Keep the reason (shown on a 0-result alert) */
            } finally {
                /* アピアランスを引き継いだら一時グラフィックスタイルは削除 / Remove the temp style once its appearance is carried over */
                removeGraphicStyleByName(tempStyleName);
            }
        }

        return createdAreaTypes;
    }

    // =========================================
    // 逆変換：エリア内文字 → ポイント文字 / Reverse: area type → point text
    // =========================================

    /**
     * エリア内文字をポイント文字へ変換し、変換後のポイント文字を返す
     * convertAreaObjectToPointObject() は「その場変換・戻り値 null」で、変換後は元のラッパー（areaType や選択）が
     * stale になり kind を AREATEXT のまま報告することがある。そこで変換前に一時的な名前（マーカー）を付け、
     * 変換後に doc.textFrames を新規走査してその名前で確実に回収する
     * @param {Document} doc - 対象のドキュメント
     * @param {TextFrame} areaType - 変換するエリア内文字
     * @returns {TextFrame|null} 変換後のポイント文字。回収できなければ null
     */
    function convertAreaObjectToPointText(doc, areaType) {
        var MARKER_NAME = "__AreaTypeToPointText_marker__";
        var previousName = "";
        try { previousName = areaType.name; } catch (eName) { }

        try {
            try { areaType.name = MARKER_NAME; } catch (eSet) { }
            /* 対象だけを選択してから変換 / Select only the target, then convert */
            doc.selection = null;
            areaType.selected = true;
            app.redraw();
            areaType.convertAreaObjectToPointObject();
        } catch (e) {
            lastConversionError = e; /* 例外後も変換済みの場合があるので下で回収を試みる / May have converted anyway; try to recover below */
        }

        /* マーカー名で新規走査して回収（stale ラッパーに依存しない）/ Recover by marker name via a fresh scan (no stale wrappers) */
        var pointText = null;
        var textFrames = doc.textFrames;
        for (var i = 0; i < textFrames.length; i++) {
            var frameName = "";
            try { frameName = textFrames[i].name; } catch (eGet) { continue; }
            if (frameName === MARKER_NAME) { pointText = textFrames[i]; break; }
        }

        if (pointText) {
            try { pointText.name = previousName; } catch (eRestore) { } /* 元の名前へ戻す / Restore the original name */
            return pointText;
        }
        return null;
    }

    /**
     * 選択中のエリア内文字をポイント文字へ変換する（保持しないときは元の枠サイズ A×B のボタン背景を付ける）
     * @param {Document} doc - 対象のドキュメント
     * @param {PageItem[]} currentSelection - 現在の選択
     * @param {Object} styleOptions - ダイアログの結果 { keepStyle }
     * @returns {TextFrame[]} 変換後のポイント文字
     */
    function convertAreaTypeToPointText(doc, currentSelection, styleOptions) {
        var createdPointTexts = [];

        /* スタイル「保持する」なら変換のみ、「保持しない」なら塗り＋長方形背景を付与 / "Keep" = convert only; "Don't keep" = add fill + rectangle background */
        var keepStyle = !styleOptions || styleOptions.keepStyle !== false;

        /* 変換で選択が変わるため、対象のエリア内文字を先に確保 / Collect targets first (conversion changes the selection) */
        var areaTexts = [];
        for (var i = 0; i < currentSelection.length; i++) {
            if (getTextKind(currentSelection[i]) === TextType.AREATEXT) areaTexts.push(currentSelection[i]);
        }

        for (var j = areaTexts.length - 1; j >= 0; j--) {
            var areaType = areaTexts[j];
            try {
                /* 1) 元のエリア枠の実寸 A×B（「保持しない」の背景サイズに使う）/ Original frame size A×B (used for the "Don't keep" background) */
                var frameBounds = geometricBoundsOf(areaType);

                /* 2) ポイント文字へ変換（変換後の参照を取り直す）/ Convert to point text (re-acquire the reference) */
                var pointText = convertAreaObjectToPointText(doc, areaType);
                if (!pointText) continue;

                /* 3) 「保持しない」→ 塗り2枚＋固定サイズ（A×B）の長方形でボタン背景を付与。「保持する」→ 変換後の見た目のまま
                   "Don't keep" → add two fills + an absolute A×B rectangle background; "Keep" → leave as-is */
                if (!keepStyle) {
                    applyButtonBackgroundSized(pointText, frameBounds.width, frameBounds.height);
                }

                createdPointTexts.push(pointText);
            } catch (e) {
                lastConversionError = e; /* 失敗理由を保持（0件時にアラートで表示）/ Keep the reason (shown on a 0-result alert) */
            }
        }

        return createdPointTexts;
    }

    /**
     * 選択（エリア内文字）をポイント文字へ変換して結果を選択する
     * @param {Document} doc - 対象のドキュメント
     * @param {PageItem[]} currentSelection - 現在の選択
     * @param {Object} styleOptions - ダイアログの結果 { keepStyle }
     * @returns {void}
     */
    function convertSelectionToPointText(doc, currentSelection, styleOptions) {
        lastConversionError = null;
        finishConversion(convertAreaTypeToPointText(doc, currentSelection, styleOptions), "alert.reverseFailed");
    }

    // =========================================
    // ダイアログ / Dialog
    // =========================================

    /**
     * テキストフレームの種類の表示名を返す
     * @param {PageItem} pageItem - 調べるオブジェクト
     * @returns {string|null} 種類の表示名。テキスト以外は null
     */
    function describeTextType(pageItem) {
        try {
            var textKind = getTextKind(pageItem);
            if (textKind === TextType.POINTTEXT) return getLabel("textType.pointText");
            if (textKind === TextType.AREATEXT) return getLabel("textType.areaText");
            if (textKind === TextType.PATHTEXT) return getLabel("textType.pathText");
        } catch (e) { }
        return null;
    }

    /**
     * 選択の内訳を「種類 ×個数」で要約する（出てきた順）
     * @param {PageItem[]} currentSelection - 現在の選択
     * @returns {string} 内訳の文字列
     */
    function summarizeSelection(currentSelection) {
        var typeCounts = {}, typeOrder = [];
        for (var i = 0; i < currentSelection.length; i++) {
            var typeLabel = describeTextType(currentSelection[i]) || getLabel("textType.other");
            if (!typeCounts.hasOwnProperty(typeLabel)) { typeCounts[typeLabel] = 0; typeOrder.push(typeLabel); }
            typeCounts[typeLabel]++;
        }
        var summaryParts = [];
        for (var k = 0; k < typeOrder.length; k++) { summaryParts.push(typeOrder[k] + " ×" + typeCounts[typeOrder[k]]); }
        return summaryParts.join("、");
    }

    /**
     * テキスト変換のオプションダイアログ（選択の内訳＋スタイル：保持する/保持しない）を表示する
     * @param {PageItem[]} currentSelection - 現在の選択
     * @param {boolean} isReverse - 逆変換（エリア内文字 → ポイント文字）なら true。ツールチップを切り替える
     * @returns {Object|null} OK なら { keepStyle }、キャンセルなら null
     */
    function showStyleDialog(currentSelection, isReverse) {
        var styleDialog = new Window("dialog", getLabel("dialog.title") + " " + SCRIPT_VERSION);
        setupWindow(styleDialog);

        /* 現在の選択オブジェクトの内訳を表示 / Show a summary of the current selection */
        var selectionPanel = styleDialog.add("panel", undefined, getLabel("panel.selection"));
        setupPanel(selectionPanel, 6);
        selectionPanel.add("statictext", undefined, summarizeSelection(currentSelection));

        /* スタイル：アピアランス（見た目）を保持するか / Style: keep the appearance or not */
        var stylePanel = styleDialog.add("panel", undefined, getLabel("panel.style"));
        setupPanel(stylePanel, 6);
        var styleChoiceGroup = stylePanel.add("group");
        var styleKeepRadio = styleChoiceGroup.add("radiobutton", undefined, getLabel("radio.keepStyle"));
        var styleDontKeepRadio = styleChoiceGroup.add("radiobutton", undefined, getLabel("radio.dontKeepStyle"));
        styleKeepRadio.value = true; /* 既定は「保持する」/ Default: keep */
        /* 順/逆で意味が異なるためツールチップで補足 / Tooltips clarify the per-direction meaning */
        styleKeepRadio.helpTip = getLabel(isReverse ? "tooltip.keepReverse" : "tooltip.keepForward");
        styleDontKeepRadio.helpTip = getLabel(isReverse ? "tooltip.dontKeepReverse" : "tooltip.dontKeepForward");

        /* ボタン（左右中央、Mac規約：キャンセル → OK）/ Buttons (centered; Mac order: Cancel → OK) */
        var buttonRow = addButtonRow(styleDialog);
        var btnCancel = buttonRow.rightGroup.add("button", undefined, getLabel("button.cancel"), { name: "cancel" });
        var btnOK = buttonRow.rightGroup.add("button", undefined, getLabel("button.ok"), { name: "ok" });
        alignRightOnlyButtonRow(buttonRow);

        var dialogResult = null;
        btnOK.onClick = function () {
            dialogResult = { keepStyle: styleKeepRadio.value };
            styleDialog.close();
        };
        btnCancel.onClick = function () { dialogResult = null; styleDialog.close(); };

        /* 表示直後にレイアウトを再計算して描画欠けを防ぐ / Recalculate layout on show to avoid partial rendering */
        styleDialog.onShow = function () {
            styleDialog.layout.layout(true);
            styleDialog.layout.resize();
        };

        prepareDialogWindow(styleDialog, SCRIPT_NAME);
        styleDialog.show();
        return dialogResult;
    }

    // =========================================
    // メイン処理 / Main
    // =========================================

    /**
     * 選択にエリア内文字、ポイント文字・パス上文字が含まれるかを調べる
     * @param {PageItem[]} currentSelection - 現在の選択
     * @returns {{hasAreaText: boolean, hasPointOrPathText: boolean}} 含まれる種類
     */
    function detectSelectionKinds(currentSelection) {
        var selectionKinds = { hasAreaText: false, hasPointOrPathText: false };
        for (var i = 0; i < currentSelection.length; i++) {
            var textKind = getTextKind(currentSelection[i]);
            if (textKind === TextType.AREATEXT) selectionKinds.hasAreaText = true;
            else if (textKind === TextType.POINTTEXT || textKind === TextType.PATHTEXT) selectionKinds.hasPointOrPathText = true;
        }
        return selectionKinds;
    }

    /**
     * 選択に応じて、エリア内文字なら逆変換、ポイント文字・パス上文字なら順変換する
     * @returns {void}
     */
    function main() {
        if (app.documents.length === 0) {
            alert(getLabel("alert.noDocument"));
            return;
        }
        var doc = app.activeDocument;
        var currentSelection = doc.selection;
        if (!currentSelection || currentSelection.length === 0) {
            alert(getLabel("alert.selectText"));
            return;
        }

        var selectionKinds = detectSelectionKinds(currentSelection);
        if (selectionKinds.hasAreaText) {
            /* 逆変換：ダイアログ（選択表示＋保持する/保持しない）→ ポイント文字へ変換
               Reverse: dialog (selection summary + keep / don't keep) → convert to point text */
            var reverseOptions = showStyleDialog(currentSelection, true);
            if (reverseOptions) {
                convertSelectionToPointText(doc, currentSelection, reverseOptions);
            }
        } else if (selectionKinds.hasPointOrPathText) {
            /* 順変換：ダイアログを表示（キャンセルで中止）/ Forward: show the dialog (Cancel aborts) */
            var forwardOptions = showStyleDialog(currentSelection, false);
            if (!forwardOptions) return;
            /* フレーム整列アクションを読み込み、終了時に破棄 / Load the frame-alignment action, unload on exit */
            loadFrameAlignmentAction();
            try {
                convertSelectionToAreaType(doc, currentSelection, forwardOptions);
            } finally {
                unloadFrameAlignmentAction();
            }
        } else {
            alert(getLabel("alert.selectText"));
        }
    }

    main();

})();
