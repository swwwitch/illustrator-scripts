#target illustrator
#targetengine "SmartTextFindReplaceEngine"
app.preferences.setBooleanPreference('ShowExternalJSXWarning', false);

/*
SCRIPTMETA-BEGIN
Script-ID=com.swwwitch.illustrator.SmartTextFindReplace
Name=テキストの検索・置換・整形
Author=Masahiro Takano (@swwwitch)
Target-App=Illustrator
Version=1.5.6
Release-Date=2026-09-26
Description-BEGIN
テキストから文字列をまとめて検索・削除・置換し（5つまで、正規表現も可）、一致した文字をカンバス上で選択することもできます。
英字の大文字・小文字の変換や、スペース・記号・かな・数字の整形も行い、残った文字の書式は変わりません。

Finds, removes or replaces up to five strings in text (regular expressions allowed), and can select the matching characters on the canvas.
It also changes letter case and tidies spaces, symbols, kana and digits, keeping the formatting of the remaining text.
Description-END
SCRIPTMETA-END
*/

/*

### 概要

テキストから文字列をまとめて検索・削除・置換し（5つまで、正規表現も可）、一致した文字をカンバス上で選択することもできます。
英字の大文字・小文字の変換や、スペース・記号・かな・数字の整形も行い、残った文字の書式は変わりません。

詳細は README を参照してください。
https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/SmartTextFindReplace.md

note記事も参照してください。
https://note.com/dtp_tranist/n/nec5dfffce709

### Overview

Finds, removes or replaces up to five strings in text (regular expressions allowed), and can select the matching characters on the canvas.
It also changes letter case and tidies spaces, symbols, kana and digits, keeping the formatting of the remaining text.

See the README for details.
https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/SmartTextFindReplace.md

*/

// =========================================
// 基本情報 / Basic info
// =========================================
var SCRIPT_NAME     = "SmartTextFindReplace";         /* スクリプト名 / script name */
var SCRIPT_VERSION  = "v1.5.6";                       /* バージョン / version */
var SCRIPT_AUTHOR   = "Masahiro Takano (@swwwitch)";  /* 作者 / author */
var SCRIPT_RELEASED = "2026-09-26";                   /* 最初のリリース日 / first release date */
var SCRIPT_UPDATED  = "2026-10-16";                   /* 更新日 / last updated */

var SCRIPT_DESCRIPTION_JA = "テキストの検索・置換・整形"; /* README の見出し / README title (Japanese) */

var SCRIPT_README_JA   = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/SmartTextFindReplace.md"; /* README（日本語） */
var SCRIPT_README_EN   = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/SmartTextFindReplace.md"; /* README (English) */
var SCRIPT_ARTICLE_URL = "https://note.com/dtp_tranist/n/nec5dfffce709"; /* 紹介記事 / article URL */
var SCRIPT_SOURCE_URL  = "https://github.com/swwwitch/illustrator-scripts/blob/master/jsx/text/SmartTextFindReplace.jsx"; /* 最新版のソース / latest source */

// Released under the MIT license
// http://opensource.org/licenses/mit-license.php

(function () {

    // =========================================
    // ユーザー設定 / User Settings
    // =========================================
    var SEARCH_FIELD_COUNT = 5;             /* 削除・置換する文字列の入力欄の数 / number of search fields */
    var DEFAULT_USE_REGEX = false;          /* 正規表現（初期値）/ regular expression (initial value) */
    var DEFAULT_MATCH_CASE = true;          /* 大文字と小文字を区別（初期値）/ match case (initial value) */
    var DEFAULT_DELETE_EMPTY_LINES = true;  /* 空になった行を削除（初期値）/ delete emptied lines (initial value) */
    var DEFAULT_DELETE_EMPTY_FRAMES = true; /* 空になったフレームを削除（初期値）/ delete emptied frames (initial value) */
    var DEFAULT_INCLUDE_HIDDEN = false;     /* 非表示のレイヤーを検索（初期値）/ search hidden layers (initial value) */
    var DEFAULT_INCLUDE_LOCKED = false;     /* ロックされたレイヤーを検索（初期値）/ search locked layers (initial value) */
    var DEFAULT_INCLUDE_SYMBOLS = true;     /* シンボルも検索（初期値）/ search symbols too (initial value) */
    var DEFAULT_ZOOM_TO_MATCH = true;       /* 選択時に拡大表示（初期値）/ zoom on select (initial value) */
    var MATCH_ZOOM_FILL_RATIO = 0.8;        /* 大きく表示するとき、テキストが画面に占める割合 / share of the window the zoomed text fills */
    var MATCH_ZOOM_MAX = 4;                 /* 大きく表示するときの最大の表示倍率（4 = 400%）/ maximum zoom when zooming to the text (4 = 400%) */

    // =========================================
    // 改行の記号 / Break tokens
    // =========================================
    /* 1行の入力欄では改行を打てないので、記号で書いて処理の直前に文字へ置き換える
       Single-line fields cannot hold breaks, so they are written as tokens and converted before processing */
    var PARAGRAPH_BREAK_TOKEN = "\\n";      /* 改行（段落の区切り \r）/ paragraph break (\r) */
    var LINE_BREAK_TOKEN = "@#";            /* 強制改行（\x03）/ forced line break (\x03) */

    // =========================================
    // 前回の設定 / Saved settings
    // =========================================

    // 設定の保存（再利用パーツ） / Settings store (reusable)

    var SETTINGS_STORE_FOLDER_NAME = "illustrator-scripts"; /* Folder.userData の下に作るフォルダー / folder created under Folder.userData */
    var SETTINGS_STORE_MAX_DEPTH = 32;                                /* 入れ子の上限（循環参照よけ）/ nesting limit (guards against cycles) */

    /**
     * 設定の保存先を作る。寿命は "session"（Illustrator の終了まで）か "persistent"（ファイルに保存）
     * @param {string} storeName - 保存名（ふつうは SCRIPT_NAME）。ファイル名と $.global のキーに使う
     * @param {string} lifetime - "session" または "persistent"
     * @param {Object} [storeOptions] - { legacy: function () → 旧形式の保存値のオブジェクト|null }
     * @returns {{load: Function, save: Function, clear: Function}} 読み込み・保存・消去の関数
     */
    function createSettingsStore(storeName, lifetime, storeOptions) {
        var isPersistent = (lifetime === "persistent");
        var legacyReader = (storeOptions && typeof storeOptions.legacy === "function") ? storeOptions.legacy : null;
        var safeStoreName = String(storeName).replace(/[\\\/:*?"<>|]/g, "_");
        var sessionKey = "__" + safeStoreName + "_Settings";
        var settingsFile = isPersistent
            ? new File(Folder.userData + "/" + SETTINGS_STORE_FOLDER_NAME + "/" + safeStoreName + ".json")
            : null;

        /**
         * 保存してある文字列を返す
         * @returns {string|null} 保存文字列。1度も保存していなければ null
         */
        function readStoredText() {
            if (!isPersistent) {
                return (typeof $.global[sessionKey] === "string") ? $.global[sessionKey] : null;
            }
            return settingsStoreReadTextFile(settingsFile);
        }

        /**
         * 文字列を保存する
         * @param {string} storedText - 保存する文字列
         * @returns {boolean} 保存できたら true
         */
        function writeStoredText(storedText) {
            if (!isPersistent) {
                $.global[sessionKey] = storedText;
                return true;
            }
            return settingsStoreWriteTextFile(settingsFile, storedText);
        }

        /**
         * 保存値を読み込み、既定値と突き合わせて返す（型の合わない値・知らない項目は捨てる）
         * @param {Object} defaultSettings - 既定値
         * @returns {Object} 設定（毎回新しいオブジェクト）
         */
        function load(defaultSettings) {
            var savedSettings = null;
            try {
                var storedText = readStoredText();
                if (storedText !== null) {
                    savedSettings = settingsStoreParse(storedText);
                } else if (legacyReader) {
                    savedSettings = legacyReader();
                }
            } catch (e) {
                $.writeln("SettingsStore.load(" + storeName + "): " + e);
                savedSettings = null;
            }
            return settingsStoreMerge(defaultSettings, savedSettings);
        }

        /**
         * 設定を保存する
         * @param {Object} settingValues - 保存する値
         * @returns {boolean} 保存できたら true
         */
        function save(settingValues) {
            try {
                return writeStoredText(settingsStoreSerialize(settingValues, "", 0));
            } catch (e) {
                $.writeln("SettingsStore.save(" + storeName + "): " + e);
                return false;
            }
        }

        /**
         * 保存を消す。旧形式を読み継ぐストアでは空の保存を書き、旧設定が戻らないようにする
         * @returns {boolean} 消せたら true
         */
        function clear() {
            if (legacyReader) return writeStoredText("{}");
            if (!isPersistent) {
                try { delete $.global[sessionKey]; } catch (e) { $.global[sessionKey] = undefined; }
                return true;
            }
            try {
                return settingsFile.exists ? settingsFile.remove() : true;
            } catch (e) {
                $.writeln("SettingsStore.clear(" + storeName + "): " + e);
                return false;
            }
        }

        return { load: load, save: save, clear: clear };
    }

    /**
     * 旧形式の設定ファイルを読む（key=value の行 / toSource / JSON を自動判別。eval は使わない）
     * @param {File|string} legacyFileOrPath - 旧ファイルかそのパス
     * @returns {Object|null} 読み込んだ値（key=value は値がすべて文字列）。無い・読めないときは null
     */
    function readSettingsLegacyFile(legacyFileOrPath) {
        try {
            var legacyFile = (legacyFileOrPath instanceof File) ? legacyFileOrPath : new File(legacyFileOrPath);
            var legacyText = settingsStoreReadTextFile(legacyFile);
            return (legacyText === null) ? null : settingsStoreParseLegacyText(legacyText);
        } catch (e) {
            $.writeln("readSettingsLegacyFile: " + e);
            return null;
        }
    }

    /**
     * app.preferences に文字列で保存していた旧設定を読む（形式は readSettingsLegacyFile と同じく自動判別）
     * @param {string} preferenceKey - 環境設定のキー
     * @returns {Object|null} 読み込んだ値。無い・読めないときは null
     */
    function readSettingsLegacyPreference(preferenceKey) {
        try {
            var legacyText = app.preferences.getStringPreference(preferenceKey);
            if (!legacyText) return null;
            return settingsStoreParseLegacyText(String(legacyText));
        } catch (e) {
            $.writeln("readSettingsLegacyPreference: " + e);
            return null;
        }
    }

    /**
     * テキストファイルを UTF-8 で読む
     * @param {File} textFile - 読むファイル
     * @returns {string|null} 中身。ファイルが無ければ null
     */
    function settingsStoreReadTextFile(textFile) {
        if (!textFile.exists) return null;
        textFile.encoding = "UTF-8";
        if (!textFile.open("r")) throw new Error("cannot open " + textFile.fsName);
        try {
            return textFile.read().replace(/^\uFEFF/, "");
        } finally {
            textFile.close();
        }
    }

    /**
     * テキストファイルを UTF-8 で書く（フォルダーが無ければ作る）
     * @param {File} textFile - 書くファイル
     * @param {string} fileText - 中身
     * @returns {boolean} 書けたら true
     */
    function settingsStoreWriteTextFile(textFile, fileText) {
        try {
            var parentFolder = textFile.parent;
            if (!parentFolder.exists && !parentFolder.create()) throw new Error("cannot create " + parentFolder.fsName);
            textFile.encoding = "UTF-8";
            textFile.lineFeed = "Unix";
            if (!textFile.open("w")) throw new Error("cannot open " + textFile.fsName);
            try {
                textFile.write(fileText);
            } finally {
                textFile.close();
            }
            return true;
        } catch (e) {
            $.writeln("SettingsStore write: " + e);
            return false;
        }
    }

    /**
     * 値が配列か
     * @param {*} checkedValue - 調べる値
     * @returns {boolean} 配列なら true
     */
    function settingsStoreIsArray(checkedValue) {
        return Object.prototype.toString.call(checkedValue) === "[object Array]";
    }

    /**
     * 値が素のオブジェクト（{ } で作ったもの）か
     * @param {*} checkedValue - 調べる値
     * @returns {boolean} 素のオブジェクトなら true
     */
    function settingsStoreIsPlainObject(checkedValue) {
        return checkedValue !== null && typeof checkedValue === "object"
            && Object.prototype.toString.call(checkedValue) === "[object Object]"
            && checkedValue.constructor === Object;
    }

    /**
     * 文字列を JSON の文字列リテラルにする（ASCII 以外は \uXXXX にして、文字コードの取り違えに強くする）
     * @param {string} sourceText - 文字列
     * @returns {string} 引用符つきの文字列
     */
    function settingsStoreQuote(sourceText) {
        var quotedText = "\"";
        for (var i = 0; i < sourceText.length; i++) {
            var charCode = sourceText.charCodeAt(i);
            var oneChar = sourceText.charAt(i);
            if (oneChar === "\"" || oneChar === "\\") quotedText += "\\" + oneChar;
            else if (oneChar === "\n") quotedText += "\\n";
            else if (oneChar === "\r") quotedText += "\\r";
            else if (oneChar === "\t") quotedText += "\\t";
            else if (charCode < 0x20 || charCode > 0x7E) quotedText += "\\u" + ("0000" + charCode.toString(16)).slice(-4);
            else quotedText += oneChar;
        }
        return quotedText + "\"";
    }

    /**
     * 値を JSON の文字列にする（オブジェクトは1項目1行、中身が値だけの配列は1行）。
     * undefined・関数・DOM オブジェクトは項目ごと省き、配列の中では null にする。有限でない数値は null
     * @param {*} sourceValue - 値
     * @param {string} indentText - 今の字下げ
     * @param {number} depth - 入れ子の深さ
     * @returns {string|undefined} JSON の文字列。書けない値は undefined
     */
    function settingsStoreSerialize(sourceValue, indentText, depth) {
        if (depth > SETTINGS_STORE_MAX_DEPTH) throw new Error("settings are nested too deeply");
        if (sourceValue === null) return "null";
        var valueType = typeof sourceValue;
        if (valueType === "boolean") return sourceValue ? "true" : "false";
        if (valueType === "number") return isFinite(sourceValue) ? String(sourceValue) : "null";
        if (valueType === "string") return settingsStoreQuote(sourceValue);
        var innerIndent = indentText + "  ";
        var itemTexts = [];
        var i;
        if (settingsStoreIsArray(sourceValue)) {
            var hasNested = false;
            for (i = 0; i < sourceValue.length; i++) {
                var itemText = settingsStoreSerialize(sourceValue[i], innerIndent, depth + 1);
                itemTexts.push(itemText === undefined ? "null" : itemText);
                if (sourceValue[i] !== null && typeof sourceValue[i] === "object") hasNested = true;
            }
            if (!itemTexts.length) return "[]";
            if (!hasNested) return "[" + itemTexts.join(", ") + "]";
            return "[\n" + innerIndent + itemTexts.join(",\n" + innerIndent) + "\n" + indentText + "]";
        }
        if (settingsStoreIsPlainObject(sourceValue)) {
            for (var key in sourceValue) {
                if (!sourceValue.hasOwnProperty(key)) continue;
                var memberText = settingsStoreSerialize(sourceValue[key], innerIndent, depth + 1);
                if (memberText !== undefined) itemTexts.push(settingsStoreQuote(key) + ": " + memberText);
            }
            if (!itemTexts.length) return "{}";
            return "{\n" + innerIndent + itemTexts.join(",\n" + innerIndent) + "\n" + indentText + "}";
        }
        return undefined; /* 関数・DOM オブジェクトなど / functions, DOM objects, etc. */
    }

    /**
     * JSON（と toSource の出力）を読む。eval は使わない。
     * キーの引用符なし・'…' の文字列・全体の ( ) ・末尾のカンマ・(void 0) も受け付ける
     * @param {string} sourceText - 読む文字列
     * @returns {*} 読み込んだ値
     */
    function settingsStoreParse(sourceText) {
        var readPos = 0;
        var textLength = sourceText.length;

        /**
         * 読み取り位置で失敗を知らせる
         * @param {string} reasonText - 理由
         * @returns {void}
         */
        function fail(reasonText) {
            throw new Error("settings parse error at " + readPos + ": " + reasonText);
        }

        /**
         * 空白を読み飛ばす
         * @returns {void}
         */
        function skipSpaces() {
            while (readPos < textLength && /\s/.test(sourceText.charAt(readPos))) readPos++;
        }

        /**
         * 識別子（英数字・_・$）を読む
         * @returns {string} 識別子。無ければ空文字
         */
        function readWord() {
            var startPos = readPos;
            while (readPos < textLength && /[\w$]/.test(sourceText.charAt(readPos))) readPos++;
            return sourceText.substring(startPos, readPos);
        }

        /**
         * 引用符で囲んだ文字列を読む（" と ' のどちらでも）
         * @returns {string} 文字列
         */
        function readString() {
            var quoteChar = sourceText.charAt(readPos++);
            var resultText = "";
            while (readPos < textLength) {
                var oneChar = sourceText.charAt(readPos++);
                if (oneChar === quoteChar) return resultText;
                if (oneChar !== "\\") { resultText += oneChar; continue; }
                var escapeChar = sourceText.charAt(readPos++);
                if (escapeChar === "n") resultText += "\n";
                else if (escapeChar === "r") resultText += "\r";
                else if (escapeChar === "t") resultText += "\t";
                else if (escapeChar === "b") resultText += "\b";
                else if (escapeChar === "f") resultText += "\f";
                else if (escapeChar === "v") resultText += "\v";
                else if (escapeChar === "0") resultText += "\0";
                else if (escapeChar === "u" || escapeChar === "x") {
                    var hexLength = (escapeChar === "u") ? 4 : 2;
                    var hexText = sourceText.substr(readPos, hexLength);
                    if (!new RegExp("^[0-9A-Fa-f]{" + hexLength + "}$").test(hexText)) fail("bad escape");
                    resultText += String.fromCharCode(parseInt(hexText, 16));
                    readPos += hexLength;
                } else resultText += escapeChar;
            }
            fail("unterminated string");
        }

        /**
         * 値を1つ読む
         * @param {number} depth - 入れ子の深さ
         * @returns {*} 値
         */
        function readValue(depth) {
            if (depth > SETTINGS_STORE_MAX_DEPTH) fail("nested too deeply");
            skipSpaces();
            var oneChar = sourceText.charAt(readPos);
            if (oneChar === "{") return readObject(depth);
            if (oneChar === "[") return readArray(depth);
            if (oneChar === "\"" || oneChar === "'") return readString();
            if (oneChar === "(") {
                readPos++;
                var innerValue = readValue(depth + 1);
                skipSpaces();
                if (sourceText.charAt(readPos) !== ")") fail("expected )");
                readPos++;
                return innerValue;
            }
            var numberMatch = /^-?(\d+\.?\d*|\.\d+)([eE][+\-]?\d+)?/.exec(sourceText.substring(readPos, readPos + 64));
            if (numberMatch) {
                readPos += numberMatch[0].length;
                return Number(numberMatch[0]);
            }
            var wordText = readWord();
            if (wordText === "true") return true;
            if (wordText === "false") return false;
            if (wordText === "null") return null;
            if (wordText === "NaN") return NaN;
            if (wordText === "Infinity") return Infinity;
            if (wordText === "void") { readValue(depth + 1); return undefined; } /* toSource の (void 0) */
            fail("unexpected " + (wordText || oneChar || "end of text"));
        }

        /**
         * 配列を読む
         * @param {number} depth - 入れ子の深さ
         * @returns {Array} 配列
         */
        function readArray(depth) {
            var resultArray = [];
            readPos++;
            skipSpaces();
            while (sourceText.charAt(readPos) !== "]") {
                resultArray.push(readValue(depth + 1));
                skipSpaces();
                if (sourceText.charAt(readPos) === ",") { readPos++; skipSpaces(); continue; }
                if (sourceText.charAt(readPos) !== "]") fail("expected , or ]");
            }
            readPos++;
            return resultArray;
        }

        /**
         * オブジェクトを読む（__proto__ のキーは捨てる）
         * @param {number} depth - 入れ子の深さ
         * @returns {Object} オブジェクト
         */
        function readObject(depth) {
            var resultObject = {};
            readPos++;
            skipSpaces();
            while (sourceText.charAt(readPos) !== "}") {
                var keyChar = sourceText.charAt(readPos);
                var memberKey = (keyChar === "\"" || keyChar === "'") ? readString() : readWord();
                if (memberKey === "") fail("expected a key");
                skipSpaces();
                if (sourceText.charAt(readPos) !== ":") fail("expected :");
                readPos++;
                var memberValue = readValue(depth + 1);
                if (memberKey !== "__proto__") resultObject[memberKey] = memberValue;
                skipSpaces();
                if (sourceText.charAt(readPos) === ",") { readPos++; skipSpaces(); continue; }
                if (sourceText.charAt(readPos) !== "}") fail("expected , or }");
            }
            readPos++;
            return resultObject;
        }

        var parsedValue = readValue(0);
        skipSpaces();
        if (readPos < textLength) fail("unexpected text after the value");
        return parsedValue;
    }

    /**
     * 旧形式の文字列を読む。{ [ ( で始まれば JSON / toSource、それ以外は key=value の行とみなす
     * @param {string} legacyText - 旧形式の文字列
     * @returns {Object|null} 読み込んだ値
     */
    function settingsStoreParseLegacyText(legacyText) {
        var trimmedText = legacyText.replace(/^\uFEFF/, "").replace(/^\s+|\s+$/g, "");
        if (trimmedText === "") return null;
        if (/^[\{\[\(]/.test(trimmedText)) return settingsStoreParse(trimmedText);
        var keyValues = {};
        var textLines = trimmedText.split(/\r\n|\r|\n/);
        for (var i = 0; i < textLines.length; i++) {
            var separatorIndex = textLines[i].indexOf("=");
            if (separatorIndex < 1) continue;
            var lineKey = textLines[i].substring(0, separatorIndex).replace(/^\s+|\s+$/g, "");
            if (lineKey !== "" && lineKey !== "__proto__") keyValues[lineKey] = textLines[i].substring(separatorIndex + 1);
        }
        return keyValues;
    }

    /**
     * 値を深くコピーする（素のデータだけ。関数・DOM オブジェクトは null）
     * @param {*} sourceValue - コピー元
     * @returns {*} コピー
     */
    function settingsStoreClone(sourceValue) {
        if (sourceValue === null || typeof sourceValue !== "object") {
            return (typeof sourceValue === "function" || sourceValue === undefined) ? null : sourceValue;
        }
        var i;
        if (settingsStoreIsArray(sourceValue)) {
            var arrayCopy = [];
            for (i = 0; i < sourceValue.length; i++) arrayCopy.push(settingsStoreClone(sourceValue[i]));
            return arrayCopy;
        }
        if (!settingsStoreIsPlainObject(sourceValue)) return null;
        var objectCopy = {};
        for (var key in sourceValue) {
            if (sourceValue.hasOwnProperty(key)) objectCopy[key] = settingsStoreClone(sourceValue[key]);
        }
        return objectCopy;
    }

    /**
     * 保存値を既定値と突き合わせる。型は既定値に合わせ、合わなければ既定値を使う。
     * 既定値が {} か null なら中身を問わず受け取り、配列は配列なら受け取る。既定値に無い項目は捨てる
     * @param {*} defaultValue - 既定値
     * @param {*} savedValue - 保存値
     * @returns {*} 突き合わせた値（新しいオブジェクト）
     */
    function settingsStoreMerge(defaultValue, savedValue) {
        if (defaultValue === null || defaultValue === undefined) {
            return (savedValue === undefined) ? null : settingsStoreClone(savedValue);
        }
        var defaultType = typeof defaultValue;
        var savedType = typeof savedValue;
        if (defaultType === "boolean") {
            if (savedType === "boolean") return savedValue;
            if (savedValue === 1 || savedValue === "1" || savedValue === "true") return true;
            if (savedValue === 0 || savedValue === "0" || savedValue === "false") return false;
            return defaultValue;
        }
        if (defaultType === "number") {
            if (savedType === "number" && isFinite(savedValue)) return savedValue;
            if (savedType === "string" && /\S/.test(savedValue)) {
                var parsedNumber = Number(savedValue);
                if (isFinite(parsedNumber)) return parsedNumber;
            }
            return defaultValue;
        }
        if (defaultType === "string") {
            if (savedType === "string") return savedValue;
            if (savedType === "number" && isFinite(savedValue)) return String(savedValue);
            if (savedType === "boolean") return String(savedValue);
            return defaultValue;
        }
        if (settingsStoreIsArray(defaultValue)) {
            return settingsStoreClone(settingsStoreIsArray(savedValue) ? savedValue : defaultValue);
        }
        if (defaultType === "object") {
            var savedIsObject = settingsStoreIsPlainObject(savedValue);
            var hasDefaultKeys = false;
            var mergedObject = {};
            for (var key in defaultValue) {
                if (!defaultValue.hasOwnProperty(key)) continue;
                hasDefaultKeys = true;
                mergedObject[key] = settingsStoreMerge(defaultValue[key], savedIsObject ? savedValue[key] : undefined);
            }
            /* 既定値が {} なら自由な入れ物として中身ごと受け取る / an empty default {} is a free-form map */
            if (!hasDefaultKeys && savedIsObject) return settingsStoreClone(savedValue);
            return mergedObject;
        }
        return defaultValue;
    }

    // 設定の保存（再利用パーツ）ここまで / End of the reusable settings store

    /* 前回の設定の保存先（Folder.userData/illustrator-scripts/SmartTextFindReplace.json）。再起動しても残る。
       以前は Illustrator の環境設定に toSource の文字列で保存していたので、新しい保存が無いときだけそこから読み継ぐ
       Saved-settings store (survives a restart); the toSource string formerly in Illustrator's preferences is read only until the first save */
    var LEGACY_SETTINGS_PREF_KEY = "SmartTextFindReplace/settings"; /* 以前の環境設定のキー / former preference key */
    var settingsStore = createSettingsStore(SCRIPT_NAME, "persistent", {
        legacy: function () {
            var legacySettings = readSettingsLegacyPreference(LEGACY_SETTINGS_PREF_KEY);
            /* v1.2.1 より前は「大文字と小文字を区別しない」（ignoreCase）で保存していたので、反転して読み替える
               Before v1.2.1 the setting was saved as ignoreCase, so read it inverted */
            if (legacySettings && typeof legacySettings.matchCase !== "boolean" && typeof legacySettings.ignoreCase === "boolean") {
                legacySettings.matchCase = !legacySettings.ignoreCase;
            }
            return legacySettings;
        }
    });

    /* 保存する設定の既定値（scope の空文字は「保存なし」）/ Defaults of the saved settings ("" scope means nothing saved) */
    var DEFAULT_SETTINGS = {
        searchTexts: [],
        replaceTexts: [],
        scope: "",
        useRegex: DEFAULT_USE_REGEX,
        matchCase: DEFAULT_MATCH_CASE,
        deleteEmptyLines: DEFAULT_DELETE_EMPTY_LINES,
        deleteEmptyFrames: DEFAULT_DELETE_EMPTY_FRAMES,
        zoomToMatch: DEFAULT_ZOOM_TO_MATCH,
        includeHidden: DEFAULT_INCLUDE_HIDDEN,
        includeLocked: DEFAULT_INCLUDE_LOCKED,
        includeSymbols: DEFAULT_INCLUDE_SYMBOLS
    };

    /**
     * 前回［すべてを置換］したとき・閉じたときの設定を読み込む
     * @returns {Object} 保存した設定（無い項目は既定値）
     */
    function loadSettings() {
        return settingsStore.load(DEFAULT_SETTINGS);
    }

    /**
     * 設定を保存する（Illustrator を再起動しても残る）
     * @param {Object} settingsToSave - 保存する設定
     * @returns {void}
     */
    function saveSettings(settingsToSave) {
        settingsStore.save(settingsToSave);
    }

    // =========================================
    // レイアウト / Layout
    // =========================================

    // UIレイアウト（再利用パーツ） / UI layout (reusable)

    /* ウィンドウ・パネルの余白と間隔 / Window & panel margins and spacing */
    var WINDOW_MARGINS = 16;                 /* ウィンドウ外周の余白 / window margin */
    var WINDOW_SPACING = 12;                 /* ウィンドウ内の要素間隔 / window spacing */
    var PANEL_MARGINS  = [16, 20, 16, 12];   /* パネル余白 [左,上,右,下] / panel margins */
    var PANEL_SPACING  = 12;                 /* パネル内の要素間隔 / panel spacing */
    var COLUMN_SPACING = 12;                 /* 2カラムの間隔 / gap between columns */
    var TAB_MARGINS    = [15, 20, 5, 10];    /* タブ余白 [左,上,右,下] / tab margins */

    /**
     * ウィンドウの共通設定
     * @param {Window} targetWindow - 対象のウィンドウ
     * @param {number} [spacing] - 要素間隔（省略時は WINDOW_SPACING）
     * @returns {void}
     */
    function setupWindow(targetWindow, spacing) {
        targetWindow.orientation = "column";
        targetWindow.alignChildren = "fill";
        targetWindow.margins = WINDOW_MARGINS;
        targetWindow.spacing = (typeof spacing === "number") ? spacing : WINDOW_SPACING;
    }

    /**
     * パネルの共通設定（子は幅いっぱい。ボタンは alignment = "left" で広げない）
     * @param {Panel} targetPanel - 対象のパネル
     * @param {number} [spacing] - 要素間隔（省略時は PANEL_SPACING）
     * @returns {void}
     */
    function setupPanel(targetPanel, spacing) {
        targetPanel.orientation = "column";
        targetPanel.alignChildren = ["fill", "top"];
        targetPanel.alignment = "fill";
        targetPanel.margins = PANEL_MARGINS;
        targetPanel.spacing = (typeof spacing === "number") ? spacing : PANEL_SPACING;
    }

    /**
     * タブの共通設定
     * @param {Tab} targetTab - 対象のタブ
     * @param {number} [spacing] - 要素間隔（省略時は変えない）
     * @returns {void}
     */
    function setupTab(targetTab, spacing) {
        targetTab.orientation = "column";
        targetTab.alignChildren = "fill";
        targetTab.margins = TAB_MARGINS;
        if (typeof spacing === "number") targetTab.spacing = spacing;
    }

    /**
     * 横並びの行グループの共通設定（ボタン列など）。
     * alignment と alignChildren を対で指定し、中のボタンが横に伸びたり天地がずれたりしないようにする
     * @param {Group} rowGroup - 対象のグループ
     * @param {string|string[]} [rowAlignment] - 横方向の alignment（省略時は "left"）。配列ならそのまま使う
     * @param {number} [spacing] - 要素間隔（省略時は PANEL_SPACING）
     * @returns {void}
     */
    function setupRow(rowGroup, rowAlignment, spacing) {
        rowGroup.orientation = "row";
        rowGroup.alignment = (rowAlignment instanceof Array) ? rowAlignment : [rowAlignment || "left", "center"];
        rowGroup.alignChildren = ["left", "center"];
        rowGroup.spacing = (typeof spacing === "number") ? spacing : PANEL_SPACING;
    }

    /**
     * ボタンの高さを指定した px だけ詰める（レイアウトが決まったあとに呼ぶ）
     * @param {Button} targetButton - 対象のボタン
     * @param {number} trimPixels - 詰める量（px）
     * @returns {void}
     */
    function trimButtonHeight(targetButton, trimPixels) {
        /* レイアウト前は size が無い / size is not set until the layout runs */
        if (!targetButton.size) return;
        targetButton.size = [targetButton.size.width, targetButton.size.height - trimPixels];
    }

    // UIレイアウト（再利用パーツ）ここまで / End of the reusable UI layout

    var OPTION_ROW_SPACING = 6;             /* 検索オプションのチェックボックスの間隔 / spacing between the search option checkboxes */
    var CLEANUP_PANEL_MARGINS = [10, 20, 10, 10]; /* 「整形」タブのパネルの内側余白（左右を詰める）/ margins of the Cleanup tab panels, narrower left and right */
    var INPUT_CHARACTERS = 18;              /* 入力欄の幅（文字数）/ input width in characters */
    var REPLACE_INPUT_CHARACTERS = 12;      /* 置換欄の幅（文字数）/ replace field width in characters */
    var MATCH_COUNT_WIDTH = 24;             /* 一致数の表示幅（2桁ほど）/ width of the match count, about two digits */
    var ROW_MARKER_TEXT = "\u25B6";          /* 目印の文字（▶）/ marker character */
    var SEARCH_OPTIONS_ROW_TOP_MARGIN = 10; /* チェックボックスとボタンの行の上余白 / top margin above the row of checkboxes and buttons */
    var SEARCH_OPTIONS_TOP_MARGIN = 5;      /* 正規表現などの上余白 / top margin above the search options */
    var INSERT_BUTTON_HEIGHT = 20;          /* 挿入ボタンの高さ / height of the insert buttons */
    var INSERT_BUTTON_FONT_SHRINK = 2;      /* 挿入ボタンの文字を小さくする量（pt）/ how much smaller the insert button font is (pt) */
    var INSERT_BUTTON_TOP_MARGIN = 2;       /* 挿入ボタンの上余白 / top margin of the insert buttons */
    var INSERT_BUTTON_LINE_SPACING = 4;     /* 挿入ボタンの行間 / spacing between rows of insert buttons */
    var CONVERSION_BUTTON_SIZE = [130, 24]; /* 変換ボタンのサイズ / size of the conversion buttons */
    var CONVERSION_SAMPLE_SIZE = [90, 24];  /* 変換結果の見本の最小サイズ（パネル幅まで伸びる）/ minimum size of the conversion samples, stretched to the panel width */
    var CONVERSION_SAMPLE_MAX_CHARS = 60;   /* 変換結果の見本に表示する最大文字数 / maximum characters in a conversion sample */

    // =========================================
    // ローカライズ / Localization
    // =========================================

    // ローカライズ（再利用パーツ） / Localization (reusable)

    /**
     * UI の言語を返す（"ja" で始まるロケールは日本語、それ以外は英語）
     * @returns {string} "ja" または "en"
     */
    function getCurrentLang() {
        return (String($.locale || "").indexOf("ja") === 0) ? "ja" : "en";
    }

    var uiLang = getCurrentLang();

    /**
     * LABELS から今の UI 言語の文言を取り出す。
     * @param {string|Object} labelRef - "dialog.title" のようなパス、または { ja, en }
     * @param {Object|Array} [placeholderValues] - { name: 値 } なら {name} を、[値, …] なら %1, %2 … を差し込む
     * @returns {string} 文言。パスが見つからなければパスの文字列、{ ja, en } が無ければ空文字
     */
    function getLabel(labelRef, placeholderValues) {
        var labelEntry = labelRef;
        if (typeof labelRef === "string") {
            var labelPathKeys = labelRef.split(".");
            labelEntry = LABELS;
            for (var i = 0; i < labelPathKeys.length && labelEntry != null; i++) {
                labelEntry = labelEntry[labelPathKeys[i]];
            }
        }
        var labelString;
        if (typeof labelEntry === "string") labelString = labelEntry;
        else if (labelEntry != null && labelEntry[uiLang] != null) labelString = labelEntry[uiLang];
        else if (labelEntry != null && labelEntry.en != null) labelString = labelEntry.en;
        else return (typeof labelRef === "string") ? labelRef : "";
        return fillLabelPlaceholders(String(labelString), placeholderValues);
    }

    /**
     * 項目名の文言の末尾にコロンを付ける（日本語は半角スペース＋半角コロン「 :」、英語は「:」。Illustrator の線パネルなどの項目名に合わせる）
     * @param {string|Object} labelRef - getLabel と同じ
     * @param {Object|Array} [placeholderValues] - getLabel と同じ
     * @returns {string} コロン付きの文言
     */
    function labelText(labelRef, placeholderValues) {
        return getLabel(labelRef, placeholderValues) + (uiLang === "ja" ? " :" : ":");
    }

    /**
     * 「項目名 : 値」の1行を返す（日本語は「件数 : 5」、英語は「Count: 5」。どちらもコロンのあとに空白を入れる）
     * @param {string|Object} labelRef - getLabel と同じ
     * @param {string|number} value - コロンのあとに続ける値
     * @returns {string} 項目名と値をつないだ文字列
     */
    function labelValueText(labelRef, value) {
        return labelText(labelRef) + " " + value;
    }

    /**
     * 文言の {name} や %1 に値を差し込む
     * @param {string} labelString - 文言
     * @param {Object|Array} [placeholderValues] - { name: 値 } または [値, …]
     * @returns {string} 差し込んだ文言
     */
    function fillLabelPlaceholders(labelString, placeholderValues) {
        if (placeholderValues == null) return labelString;
        if (placeholderValues instanceof Array) {
            /* 大きい番号から置き換え、%1 が %10 の一部を置き換えないようにする / Replace from the highest index so %1 does not eat into %10 */
            for (var i = placeholderValues.length; i >= 1; i--) {
                labelString = labelString.split("%" + i).join(String(placeholderValues[i - 1]));
            }
            return labelString;
        }
        for (var placeholderKey in placeholderValues) {
            if (!placeholderValues.hasOwnProperty(placeholderKey)) continue;
            labelString = labelString.split("{" + placeholderKey + "}").join(String(placeholderValues[placeholderKey]));
        }
        return labelString;
    }

    // ローカライズ（再利用パーツ）ここまで / End of the reusable localization

    var LABELS = {
        dialog: {
            title: { ja: "テキストの検索・置換・整形", en: "Find, Replace & Clean Up Text" }
        },
        tab: {
            findReplace: { ja: "検索・置換", en: "Find / Replace" },
            englishText: { ja: "英文", en: "English" },
            cleanup: { ja: "整形", en: "Cleanup" }
        },
        panel: {
            findReplace: { ja: "検索・置換する文字列", en: "Text to Find / Replace" },
            scope: { ja: "対象", en: "Scope" },
            options: { ja: "オプション", en: "Options" },
            letterCase: { ja: "大文字・小文字", en: "Letter Case" },
            kanaDigitConversion: { ja: "かな・数字の変換", en: "Kana & Digits" },
            tabCharacter: { ja: "タブ", en: "Tabs" },
            removeSpace: { ja: "スペースの削除", en: "Remove Spaces" },
            addSpace: { ja: "スペースの追加", en: "Add Spaces" },
            symbolConversion: { ja: "スペースや記号の変換", en: "Convert Spaces & Symbols" },
            symbolBefore: { ja: "変換前", en: "Before" },
            symbolAfter: { ja: "変換後", en: "After" },
            removeList: { ja: "リストの除去", en: "Remove List Markers" }
        },
        checkbox: {
            preview: { ja: "プレビュー", en: "Preview" },
            useRegex: { ja: "正規表現", en: "Regular expression" },
            matchCase: { ja: "大文字と小文字を区別", en: "Match case" },
            deleteEmptyLines: { ja: "空になった行を削除", en: "Delete emptied lines" },
            deleteEmptyFrames: { ja: "空になったテキストを削除", en: "Delete emptied text" },
            includeHidden: { ja: "非表示のレイヤーを検索", en: "Check hidden layers" },
            includeLocked: { ja: "ロックされたレイヤーを検索", en: "Check locked layers" },
            includeSymbols: { ja: "シンボルを検索", en: "Check symbols" },
            zoomToMatch: { ja: "選択時に拡大表示", en: "Zoom on select" }
        },
        radio: {
            selection: { ja: "選択中のオブジェクト", en: "Selected objects" },
            artboard: { ja: "現在のアートボード", en: "Current artboard" },
            wholeDocument: { ja: "ドキュメント全体", en: "Entire document" },
            space: { ja: "スペース", en: "Space" },
            underscore: { ja: "アンダースコア", en: "Underscore" },
            hyphen: { ja: "ハイフン", en: "Hyphen" }
        },
        tooltip: {
            searchText: {
                ja: "検索する文字列。右の欄が空なら［すべてを置換］で削除、入力すると置換します。［次を選択］［すべてを選択］にも使います。空欄は無視し、上の欄から順に処理します。入力内容は次回に引き継がれます",
                en: "Text to find. Replace All removes each match when the field on the right is empty, or replaces it with that text. Select Next and Select All use it too. Empty fields are ignored; fields are processed from top to bottom. Entries are kept for the next run"
            },
            replaceText: {
                ja: "一致した部分をこの文字列に置き換えます。空欄なら削除します。正規表現のときは $1・\\1 や $&・\\0 で一致した部分を参照できます",
                en: "Replaces each match with this text. Leave empty to remove. With regular expressions, $1 / \\1 and $& / \\0 refer to the match"
            },
            matchCount: {
                ja: "対象の範囲で見つかった数（ほかの欄による削除・置換は考慮しない）。「!」は正規表現の誤り",
                en: "Matches found in the scope (ignoring removals and replacements by other fields). \"!\" means an invalid regular expression"
            },
            paragraphBreak: {
                ja: "カーソルの位置に改行（\\n）を入れます（command／Ctrl＋Enter）",
                en: "Inserts a paragraph break (\\n) at the cursor (Command/Ctrl+Enter)"
            },
            lineBreak: {
                ja: "カーソルの位置に強制改行（@#）を入れます（Shift＋Enter）",
                en: "Inserts a forced line break (@#) at the cursor (Shift+Enter)"
            },
            wholeMatch: {
                ja: "カーソルの位置に \\0（一致した部分全体）を入れます（option／Alt＋0）。正規表現のときだけ使えます",
                en: "Inserts \\0 (the whole match) at the cursor (Option/Alt+0). Available with regular expressions only"
            },
            group1: {
                ja: "カーソルの位置に \\1（1つ目の ( ) に一致した部分）を入れます（option／Alt＋1）。正規表現のときだけ使えます",
                en: "Inserts \\1 (the text matched by the first group) at the cursor (Option/Alt+1). Available with regular expressions only"
            },
            group2: {
                ja: "カーソルの位置に \\2（2つ目の ( ) に一致した部分）を入れます（option／Alt＋2）。正規表現のときだけ使えます",
                en: "Inserts \\2 (the text matched by the second group) at the cursor (Option/Alt+2). Available with regular expressions only"
            },
            useRegex: {
                ja: "入力を JavaScript の正規表現として扱います。^ と $ は段落の先頭・末尾に一致します",
                en: "Treats the input as JavaScript regular expressions. ^ and $ match the start and end of each paragraph"
            },
            selection: { ja: "グループ内のテキストも対象になります", en: "Includes text inside groups" },
            artboard: { ja: "アートボードに一部でも重なるテキストが対象になります", en: "Includes text that partly overlaps the artboard" },
            deleteEmptyLines: {
                ja: "削除で段落が空になったら、その改行も削除して空行を残しません。元から空の行は残します",
                en: "When removing leaves a paragraph empty, also removes its break so no blank line is left. Lines that were already empty are kept"
            },
            deleteEmptyFrames: {
                ja: "今回の削除で空になったテキストだけを削除します。元から空のテキストと、スレッドテキスト（連結）は残します",
                en: "Deletes only text emptied by this run. Text that was already empty and threaded text are kept"
            },
            includeHidden: {
                ja: "非表示のレイヤー・オブジェクト内のテキストも対象にします。処理のあいだだけ表示し、終わったら元に戻します",
                en: "Includes text in hidden layers and objects. They are shown only while processing, then hidden again"
            },
            includeLocked: {
                ja: "ロックされたレイヤー・オブジェクト内のテキストも対象にします。処理のあいだだけロックを解除し、終わったら元に戻します",
                en: "Includes text in locked layers and objects. They are unlocked only while processing, then locked again"
            },
            includeSymbols: {
                ja: "対象範囲にあるシンボルの定義を書き換えます。範囲外にある同じシンボルのインスタンスも変わり、基準点などのシンボルオプションは初期値になります",
                en: "Rewrites the definitions of symbols in the scope. Instances outside the scope change too, and symbol options such as the registration point are reset"
            },
            selectionUnavailable: { ja: "オブジェクトが選択されていないため選べません", en: "Unavailable because nothing is selected" },
            rowMarker: {
                ja: "［次を選択］［すべてを選択］は、▶ の行の文字列で選択します",
                en: "Select Next and Select All use the text in the row marked ▶"
            },
            selectNext: {
                ja: "カーソルのある行の文字列に次に一致する文字を選択します。最後まで行くと最初に戻ります。非表示・ロックされたテキストとシンボル内は飛ばします",
                en: "Selects the next characters matching the row with the cursor, wrapping around at the end. Hidden or locked text and text in symbols are skipped"
            },
            zoomToMatch: {
                ja: "［次を選択］で選んだ文字を含むテキストが画面に大きく収まるように、表示倍率と位置を変えます",
                en: "Changes the zoom and position so the text containing the characters picked by Select Next fills the window"
            },
            selectAll: {
                ja: "カーソルのある行の文字列に一致する文字を含むテキストオブジェクトを、すべて選択します。非表示・ロックされたテキストとシンボル内は選択しません",
                en: "Selects every text object containing a match for the row with the cursor. Hidden or locked text and text in symbols are not selected"
            },
            reset: {
                ja: "入力欄を空にし、対象とオプションを初期値に戻します（プレビューの ON／OFF はそのまま）",
                en: "Clears the fields and restores the scope and options to their defaults (the preview setting is kept)"
            },
            replaceAll: {
                ja: "対象の範囲で一致する部分をすべて置換します。置換欄が空なら削除します（Enter）。ダイアログは閉じないので、続けて別の文字列を処理できます",
                en: "Replaces every match in the scope, or removes it when the replacement is empty (Enter). The dialog stays open so you can continue with other text"
            },
            caseWord: { ja: "単語ごとに先頭を大文字、残りを小文字にします", en: "Capitalizes the first letter of each word and lowercases the rest" },
            caseSentence: { ja: "文の先頭だけを大文字にし、残りを小文字にします", en: "Capitalizes only the first letter of each sentence" },
            caseTitle: {
                ja: "冠詞・前置詞・接続詞などを除き、単語の先頭を大文字にします",
                en: "Capitalizes each word except articles, prepositions and conjunctions"
            },
            toHiragana: { ja: "カタカナ（半角カナを含む）をひらがなにします", en: "Converts katakana, including halfwidth kana, to hiragana" },
            toKatakana: { ja: "ひらがなと半角カナを全角カタカナにします", en: "Converts hiragana and halfwidth kana to fullwidth katakana" },
            toHalfKana: { ja: "ひらがなとカタカナを半角カナにします", en: "Converts hiragana and katakana to halfwidth kana" },
            toHalfDigit: { ja: "全角数字と漢数字を半角数字にします", en: "Converts fullwidth digits and kanji numerals to halfwidth digits" },
            toFullDigit: { ja: "半角数字と漢数字を全角数字にします", en: "Converts halfwidth digits and kanji numerals to fullwidth digits" },
            removeTabs: { ja: "タブをすべて削除します", en: "Removes all tabs" },
            tabsToSpaces: { ja: "タブを半角スペースに置き換えます", en: "Replaces tabs with spaces" },
            trimSpaces: { ja: "各行の行頭・行末のスペースを削除します", en: "Removes leading and trailing spaces on each line" },
            cjkLatinSpaces: {
                ja: "和文と欧文の間のスペースを削除します（欧文単語間は保持）",
                en: "Removes spaces between CJK and Latin text (spaces between Latin words are kept)"
            },
            collapseSpaces: { ja: "連続したスペースを1つにまとめます", en: "Collapses consecutive spaces into one" },
            cleanupSpaces: {
                ja: "行頭・行末、連続、和欧間のスペースをまとめて処理します",
                en: "Applies Leading/Trailing, Consecutive and Between CJK and Latin in one step"
            },
            spaceAfterPunct: { ja: "半角ピリオド・カンマの直後にスペースを挿入します", en: "Inserts a space right after a period or comma" },
            convertSymbol: {
                ja: "変換前の記号を変換後の記号に置き換えます（スペースは半角・全角の両方）",
                en: "Replaces the Before symbol with the After symbol (spaces include fullwidth spaces)"
            },
            bulletList: {
                ja: "行頭の箇条書き記号（・ ･ · • ◦ ● ○ ◎ □ ■ ▪ ◆ ◇ ✓ – - *）を削除します。Illustrator の箇条書き機能は［テキストに変換］してから取り除きます",
                en: "Removes leading bullet markers (・ ･ · • ◦ ● ○ ◎ □ ■ ▪ ◆ ◇ ✓ – - *). Illustrator bullet lists are converted to text first, then removed"
            },
            numberList: {
                ja: "行頭の番号（1. ① a. 一. など）を削除します。Illustrator の番号付きリストは［テキストに変換］してから取り除きます",
                en: "Removes leading numbers (1. ① a. etc.). Illustrator numbered lists are converted to text first, then removed"
            },
            preview: {
                ja: "正規表現のときだけ使えます。ダイアログを閉じずに結果を表示し、入力や対象の変更に合わせて更新します。シンボル内・非表示・ロック中・スレッドテキスト（連結）のテキストは表示しません",
                en: "Available with regular expressions only. Shows the result without closing the dialog, updating as the input or scope changes. Text in symbols, hidden, locked or threaded text is not previewed"
            }
        },
        button: {
            paragraphBreak: { ja: "改行", en: "Paragraph Break" },
            lineBreak: { ja: "強制改行", en: "Forced Line Break" },
            wholeMatch: { ja: "検索結果すべて", en: "Whole Match" },
            group1: { ja: "検索結果1", en: "Group 1" },
            group2: { ja: "検索結果2", en: "Group 2" },
            caseUpper: { ja: "すべて大文字に", en: "UPPERCASE" },
            caseLower: { ja: "すべて小文字に", en: "lowercase" },
            caseWord: { ja: "単語の先頭を大文字", en: "Capitalize Words" },
            caseSentence: { ja: "文頭のみ大文字", en: "Sentence case" },
            caseTitle: { ja: "英語タイトル形式", en: "Title Case" },
            toHiragana: { ja: "ひらがな", en: "Hiragana" },
            toKatakana: { ja: "カタカナ", en: "Katakana" },
            toHalfKana: { ja: "半角カナ", en: "Halfwidth Kana" },
            toHalfDigit: { ja: "半角数字", en: "Halfwidth Digits" },
            toFullDigit: { ja: "全角数字", en: "Fullwidth Digits" },
            removeTabs: { ja: "削除", en: "Remove" },
            tabsToSpaces: { ja: "スペースに", en: "To Spaces" },
            trimSpaces: { ja: "行頭・行末", en: "Leading/Trailing" },
            cjkLatinSpaces: { ja: "和欧間", en: "Between CJK and Latin" },
            collapseSpaces: { ja: "連続", en: "Consecutive" },
            cleanupSpaces: { ja: "まとめて", en: "All at Once" },
            spaceAfterPunct: { ja: ".と,の後", en: "After . and ," },
            convertSymbol: { ja: "変換", en: "Convert" },
            bulletList: { ja: "箇条書き", en: "Bullets" },
            numberList: { ja: "番号リスト", en: "Numbers" },
            reset: { ja: "条件をリセット", en: "Reset Criteria" },
            selectNext: { ja: "次を選択", en: "Select Next" },
            selectAll: { ja: "すべてを選択", en: "Select All" },
            replaceAll: { ja: "すべてを置換", en: "Replace All" },
            close: { ja: "閉じる", en: "Close" }
        },
        alert: {
            noDocument: { ja: "ドキュメントを開いてください。", en: "Please open a document." }
        }
    };

    // ダイアログの位置と不透明度（再利用パーツ） / Dialog position and opacity (reusable)

    var DIALOG_OPACITY = 0.98;       /* ダイアログの不透明度 / dialog opacity */
    var DIALOG_AVOID_MARGIN = 60;    /* 選択範囲の推定位置の両側に取る余裕（px）/ margin on each side of the estimated selection (px) */
    var DIALOG_AVOID_MAX_ITEMS = 100; /* 選択範囲を測るオブジェクトの上限 / max items measured for the selection bounds */

    /**
     * ダイアログの不透明度を設定し、前回閉じた位置で開いて、動かした位置を記録するようにする。
     * 開く位置が選択中のオブジェクトに重なりそうなときは、左右の反対側へずらす（Illustrator のみ）。
     * 既存の onShow / onMove / onClose は先に呼んでから、位置の復元・記録を行う。
     * @param {Window} dialog - 対象のダイアログ
     * @param {string} storageKey - 位置を覚えるキー（ふつうは SCRIPT_NAME）
     * @returns {void}
     */
    function prepareDialogWindow(dialog, storageKey) {
        /* 同じダイアログを開き直すときは、選択範囲を測り直すだけにする（ハンドラーを重ねない）
           When the same dialog is shown again, only re-measure the selection (don't stack handlers) */
        if (dialog.dialogWindowState) {
            dialog.dialogWindowState.selectionSpan = getSelectionViewSpan();
            dialog.dialogWindowState.avoidedLocation = null;
            return;
        }
        var locationKey = "__" + storageKey + "_DialogLocation";
        var previousOnShow = dialog.onShow;
        var previousOnMove = dialog.onMove;
        var previousOnClose = dialog.onClose;
        var windowState = {
            selectionSpan: getSelectionViewSpan(), /* 選択範囲は show() の前に測る / measured before show() */
            screenWidth: null,                     /* 最初に開いたときに推定する / estimated on the first show */
            avoidedLocation: null                  /* 避けるためにずらした位置（記録しない）/ location set to avoid the selection (not remembered) */
        };
        dialog.dialogWindowState = windowState;

        dialog.opacity = DIALOG_OPACITY;

        /* 今の位置を記録する / Remember the current location */
        function rememberDialogLocation() {
            var currentLocation = [dialog.location[0], dialog.location[1]];
            var avoidedLocation = windowState.avoidedLocation;
            if (avoidedLocation && currentLocation[0] === avoidedLocation[0] && currentLocation[1] === avoidedLocation[1]) return;
            $.global[locationKey] = currentLocation;
        }

        dialog.onShow = function () {
            /* 最初に開くときの既定の位置は画面の横中央なので、画面の幅を逆算できる。2回目からは前回の位置なので使い回す
               On the first show the default location is centered horizontally, which gives the screen width; reuse it afterwards */
            if (windowState.screenWidth === null) windowState.screenWidth = dialog.location[0] * 2 + dialog.bounds.width;
            if (previousOnShow) previousOnShow.apply(this, arguments);
            /* $.screens は実際の画面の大きさと合わない（Mac で 1280×524 など）ので、画面内かは判定しない
               $.screens does not match the real display (e.g. 1280x524 on a Mac), so no on-screen check */
            var savedLocation = $.global[locationKey];
            if (savedLocation) dialog.location = [savedLocation[0], savedLocation[1]];
            if (windowState.selectionSpan) {
                var avoidLeft = findDialogLeftAvoidingSelection(dialog.location[0], dialog.bounds.width, windowState.screenWidth, windowState.selectionSpan);
                if (avoidLeft !== null) {
                    dialog.location = [avoidLeft, dialog.location[1]];
                    /* 代入後の値で比べる（丸められることがある）/ Compare with the value after assignment, which may be rounded */
                    windowState.avoidedLocation = [dialog.location[0], dialog.location[1]];
                }
            }
        };
        dialog.onMove = function () {
            if (previousOnMove) previousOnMove.apply(this, arguments);
            rememberDialogLocation();
        };
        dialog.onClose = function () {
            rememberDialogLocation();
            /* false を返すと閉じるのを取りやめるので、戻り値は元の onClose のものを返す
               Returning false cancels the close, so pass the original onClose result through */
            if (previousOnClose) return previousOnClose.apply(this, arguments);
        };
    }

    /**
     * 選択中のオブジェクトが、ドキュメントの表示域の左端から画面上で何 px の範囲にあるかを返す。
     * @returns {{left: number, right: number, viewWidth: number}|null} 選択が無い・測れないときは null
     */
    function getSelectionViewSpan() {
        try {
            if (app.name !== "Adobe Illustrator" || !app.documents.length) return null;
            var targetDoc = app.activeDocument;
            var selectedItems = targetDoc.selection;
            /* 文字ツールで文字を選択しているときは TextRange が返り、[0] が無い / Selecting characters with the Type tool returns a TextRange, which has no [0] */
            if (!selectedItems || selectedItems.typename === "TextRange" || !selectedItems.length || !selectedItems[0].visibleBounds) return null;
            var itemCount = Math.min(selectedItems.length, DIALOG_AVOID_MAX_ITEMS);
            var spanLeft = Infinity;
            var spanRight = -Infinity;
            for (var i = 0; i < itemCount; i++) {
                var itemBounds = selectedItems[i].visibleBounds;
                if (itemBounds[0] < spanLeft) spanLeft = itemBounds[0];
                if (itemBounds[2] > spanRight) spanRight = itemBounds[2];
            }
            var activeView = targetDoc.activeView; /* 複数ウィンドウで開いていても今のウィンドウ / the current window even with multiple windows */
            var viewBounds = activeView.bounds;
            var zoom = activeView.zoom;
            var viewWidth = (viewBounds[2] - viewBounds[0]) * zoom;
            /* 表示域の外にはみ出した部分は数えない / Ignore the part outside the view */
            var left = Math.max(0, (spanLeft - viewBounds[0]) * zoom);
            var right = Math.min(viewWidth, (spanRight - viewBounds[0]) * zoom);
            if (right <= left) return null;
            return { left: left, right: right, viewWidth: viewWidth };
        } catch (e) {
            /* テキスト編集中など測れないときは避けない / Do not avoid when it cannot be measured, e.g. while editing text */
            return null;
        }
    }

    /**
     * ダイアログが選択範囲に重なるなら、重ならない左端の位置を返す。
     * 表示域は画面の横中央にあるとみなし、ずれは DIALOG_AVOID_MARGIN で吸収する。
     * @param {number} dialogLeft - 今のダイアログの左端
     * @param {number} dialogWidth - ダイアログの幅
     * @param {number} screenWidth - 画面の幅
     * @param {{left: number, right: number, viewWidth: number}} selectionSpan - getSelectionViewSpan() の結果
     * @returns {number|null} ずらした左端。重ならない・どちらにも収まらないときは null
     */
    function findDialogLeftAvoidingSelection(dialogLeft, dialogWidth, screenWidth, selectionSpan) {
        var viewLeft = (screenWidth - selectionSpan.viewWidth) / 2;
        var avoidLeft = viewLeft + selectionSpan.left - DIALOG_AVOID_MARGIN;
        var avoidRight = viewLeft + selectionSpan.right + DIALOG_AVOID_MARGIN;
        if (dialogLeft + dialogWidth <= avoidLeft || dialogLeft >= avoidRight) return null;

        var leftSideLeft = avoidLeft - dialogWidth;   /* 選択範囲の左に置くとき / placed left of the selection */
        var rightSideLeft = avoidRight;               /* 選択範囲の右に置くとき / placed right of the selection */
        var fitsLeft = leftSideLeft >= 0;
        var fitsRight = rightSideLeft + dialogWidth <= screenWidth;
        /* 選択範囲が画面の右寄りなら左へ、左寄りなら右へ逃がす / Move away from the side the selection leans to */
        var preferLeft = (avoidLeft + avoidRight) / 2 > screenWidth / 2;
        if (preferLeft && fitsLeft) return leftSideLeft;
        if (fitsRight) return rightSideLeft;
        if (fitsLeft) return leftSideLeft;
        return null;
    }

    // ダイアログの位置と不透明度（再利用パーツ）ここまで / End of the reusable dialog position and opacity

    // =========================================
    // メイン処理 / Main
    // =========================================

    /**
     * メイン処理
     * @returns {void}
     */
    function main() {
        if (app.documents.length === 0) {
            alert(getLabel(LABELS.alert.noDocument));
            return;
        }
        var doc = app.activeDocument;
        /* シンボルのリンク解除で選択が変わるので、最初に控えておく / Keep the selection now, as breaking symbol links changes it */
        var selectedItems = toItemArray(doc.selection);

        showFindReplaceDialog(doc, selectedItems);
    }

    /**
     * 選択をアイテムの配列にする。文字ツールで文字を選択しているときは、その文字を含むストーリーのテキストフレームにする
     * @param {Object} currentSelection - doc.selection
     * @returns {PageItem[]} アイテムの配列。選択が無ければ空
     */
    function toItemArray(currentSelection) {
        var itemArray = [];
        if (!currentSelection) return itemArray;
        /* TextRange の length は文字数で、[i] は undefined になる / A TextRange's length is its character count, and [i] is undefined */
        var sourceItems = (currentSelection.typename === "TextRange") ? currentSelection.story.textFrames : currentSelection;
        for (var i = 0; i < sourceItems.length; i++) {
            itemArray.push(sourceItems[i]);
        }
        return itemArray;
    }

    /**
     * ダイアログを表示する。削除・置換も英文・整形の変換も、ボタンを押した時点でダイアログを閉じずに実行する
     * @param {Document} doc - 対象ドキュメント
     * @param {PageItem[]} selectedItems - 実行時に選択していたアイテム（空になって削除したフレームは取り除く）
     * @returns {void}
     */
    function showFindReplaceDialog(doc, selectedItems) {
        /* 前回の設定があれば初期値にする / Start from the saved settings when present */
        var savedSettings = loadSettings() || {};
        var hasSelection = selectedItems.length > 0;
        /* チェックボックスと対象の現在値。show() 前は checkbox.value を読み戻せないので、ここに持つ
           Current values of the checkboxes and scope, kept here as checkbox.value cannot be read back before show() */
        var dialogState = {
            values: {},
            settingControls: [],
            scope: getInitialScope(savedSettings.scope, hasSelection),
            onSettingChange: null
        };
        /* 文字ツールで選択した文字（見本に使う）。シンボルの展開で選択が変わる前に控える
           Characters selected with the Type tool, used for the samples; kept before expanding symbols changes the selection */
        var selectedTextRange = (doc.selection && doc.selection.typename === "TextRange") ? doc.selection : null;

        var dialogControls = buildMainDialog(savedSettings, dialogState, hasSelection, runConversion);
        var findReplaceControls = dialogControls.findReplaceControls;
        var conversionPanelBuilder = dialogControls.conversionPanelBuilder;

        var searchInputs = findReplaceControls.searchInputs;
        var replaceInputs = findReplaceControls.replaceInputs;
        /* 対象範囲ごとのテキスト内容（範囲やレイヤーの扱いを切り替えたときだけ集め直す）/ Contents cached per scope and layer options */
        var contentsCache = {};
        /* 表示中のプレビュー（createPreview() の記録）/ Records of the preview on screen */
        var previewRecords = [];
        /* 元を隠すと選択が外れるので、一度でもプレビューしたら閉じたあとに選択を戻す
           Hiding the originals deselects them, so restore the selection after closing once a preview was shown */
        var hasShownPreview = false;
        /* 箇条書きの変換で選択を使ったか / Whether converting list styles changed the selection */
        var hasChangedSelection = false;
        /* ［次を選択］［すべてを選択］の処理 / Select Next and Select All */
        var matchSelector = createMatchSelector(doc, collectRowMatches);
        var isPreviewOn = false;
        /* 入力が有効か（有効なパターンがあり、誤った正規表現が無い）/ Whether the input is valid */
        var isInputValid = false;

        /* 非表示・ロックの扱い / How hidden and locked layers are handled */
        function getLayerOptions() {
            return { includeHidden: dialogState.values.includeHidden, includeLocked: dialogState.values.includeLocked };
        }

        /* 入力欄から検索エントリーを作る / Build the search entries from the fields */
        function readSearchEntries() {
            return getSearchEntries(readInputTexts(searchInputs), readInputTexts(replaceInputs), dialogState.values.useRegex, dialogState.values.matchCase, dialogState.values.deleteEmptyLines);
        }

        /* プレビューを消して元に戻す / Remove the preview and restore the originals */
        function clearPreview() {
            if (previewRecords.length === 0) return;
            removePreview(previewRecords);
            previewRecords = [];
        }

        /* プレビューを作り直す（OFF か入力が無効なら消すだけ）/ Rebuild the preview; only clear it when off or the input is invalid */
        function updatePreview() {
            clearPreview();
            if (!isPreviewOn || !isInputValid) return;
            previewRecords = createPreview(collectTargetFrames(doc, dialogState.scope, getLayerOptions(), selectedItems), readSearchEntries());
            if (previewRecords.length > 0) hasShownPreview = true;
        }

        /* 対象範囲のテキスト内容（シンボル内を含む）/ Text contents in the scope, including symbols */
        function getScopeContents() {
            var layerOptions = getLayerOptions();
            var includeSymbols = dialogState.values.includeSymbols;
            var cacheKey = [dialogState.scope, layerOptions.includeHidden, layerOptions.includeLocked, includeSymbols].join(":");
            if (!contentsCache[cacheKey]) {
                var textContents = getFrameContents(collectTargetFrames(doc, dialogState.scope, layerOptions, selectedItems));
                if (includeSymbols) {
                    textContents = textContents.concat(getSymbolTextContents(doc, collectTargetSymbols(doc, dialogState.scope, layerOptions, selectedItems)));
                }
                contentsCache[cacheKey] = textContents;
            }
            return contentsCache[cacheKey];
        }

        /* 行の検索文字列に一致する、選択できるテキストと一致箇所を集める / Collect the selectable matches for a row */
        function collectRowMatches(rowIndex) {
            var searchPattern = createSearchPattern(searchInputs[rowIndex].text, dialogState.values.useRegex, dialogState.values.matchCase);
            if (!searchPattern) return [];
            /* プレビューの複製を拾わないよう、先に消す / Clear the preview first so its duplicates are not picked */
            clearPreview();
            return findSelectableMatches(collectTargetFrames(doc, dialogState.scope, getLayerOptions(), selectedItems), searchPattern);
        }

        /* 対象範囲のテキストフレームとシンボル（シンボルは［シンボルを検索］が ON のときだけ）/ Text frames and symbols in the scope; symbols only with Check symbols on */
        function collectEditTargets() {
            var layerOptions = getLayerOptions();
            return {
                textFrames: collectTargetFrames(doc, dialogState.scope, layerOptions, selectedItems),
                symbols: dialogState.values.includeSymbols ? collectTargetSymbols(doc, dialogState.scope, layerOptions, selectedItems) : []
            };
        }

        /* 内容が変わったので、集め直して一致数を数え直す / The contents changed, so collect and count again */
        function refreshAfterEdit() {
            contentsCache = {};
            app.redraw();
            refreshDialogState();
        }

        /* 入力欄をすべて空にする / Clear all fields */
        function clearAllInputs() {
            for (var i = 0; i < searchInputs.length; i++) {
                searchInputs[i].text = "";
                replaceInputs[i].text = "";
            }
        }

        /* 一致数と［すべてを置換］の可否、プレビューを更新（有効なパターンが無いか、誤った正規表現がある間は押せない）
           Update match counts, Replace All and the preview; disable Replace All when no pattern is given or a regular expression is invalid */
        function refreshDialogState() {
            /* プレビューの複製が数に入らないよう、先に消す / Clear the preview first so its duplicates are not counted */
            clearPreview();
            var scopeContents = getScopeContents();
            /* 見本は選択した文字・テキストを優先し、無ければ対象範囲の最初のテキスト / Samples prefer the selection, then the first text in the scope */
            conversionPanelBuilder.updateSamples(getSelectedSampleText(selectedTextRange, selectedItems) || getFirstNonEmptyText(scopeContents));
            var hasPattern = false;
            var hasInvalidPattern = false;
            for (var i = 0; i < searchInputs.length; i++) {
                var searchPattern = createSearchPattern(searchInputs[i].text, dialogState.values.useRegex, dialogState.values.matchCase);
                var matchCountText = "";
                if (searchPattern === false) {
                    matchCountText = "!";
                    hasInvalidPattern = true;
                } else if (searchPattern) {
                    matchCountText = String(countMatches(scopeContents, searchPattern));
                    hasPattern = true;
                }
                findReplaceControls.matchCountLabels[i].text = matchCountText;
            }
            isInputValid = hasPattern && !hasInvalidPattern;
            findReplaceControls.btnReplaceAll.enabled = isInputValid;
            /* 選択は有効な行だけで働くので、誤った正規表現があっても押せる / Selecting works per row, so an invalid row elsewhere does not block it */
            findReplaceControls.btnSelectNext.enabled = hasPattern;
            findReplaceControls.btnSelectAll.enabled = hasPattern;
            matchSelector.resetCursor();
            findReplaceControls.referenceButtonGroup.enabled = dialogState.values.useRegex;
            /* プレビューは正規表現のときだけ使える。OFF にしたら外す / Preview works only with regular expressions; turning them off turns it off */
            findReplaceControls.previewCheckbox.enabled = dialogState.values.useRegex;
            if (!dialogState.values.useRegex) {
                findReplaceControls.previewCheckbox.value = false;
                isPreviewOn = false;
            }
            updatePreview();
        }

        /* 対象範囲のテキストをすぐに変換する（ダイアログは閉じない）/ Convert the text in the scope right away, keeping the dialog open */
        function runConversion(convertText, conversionKey) {
            /* プレビューの複製ではなく元を変換する / Convert the originals, not the preview duplicates */
            clearPreview();
            var editTargets = collectEditTargets();
            var prepareFrame = null;
            if (conversionKey === "bulletList" || conversionKey === "numberList") {
                /* 箇条書き機能の記号を本文にしてから取り除く（選択を使うので、閉じたあとに選択を戻す）
                   Turn list markers into text first; this uses the selection, so restore it after closing */
                hasChangedSelection = true;
                prepareFrame = function (textFrame) {
                    convertListStyleToText(doc, textFrame);
                };
            }
            convertTextInFrames(editTargets.textFrames, convertText, prepareFrame);
            convertTextInSymbols(doc, editTargets.symbols, convertText, prepareFrame);
            refreshAfterEdit();
        }

        /* 対象範囲のテキストを削除・置換する（ダイアログは閉じない）/ Remove or replace in the scope, keeping the dialog open */
        function runReplace() {
            /* Enter は表示中のタブにかかわらず既定のボタンを押すので、検索・置換タブのときだけ実行する
               Enter presses the default button on any tab, so run only on the Find / Replace tab */
            if (dialogControls.modeTabbedPanel.selection !== dialogControls.findReplaceTab || !isInputValid) return;
            /* プレビューの複製ではなく元を処理する / Process the originals, not the preview duplicates */
            clearPreview();
            var searchTexts = readInputTexts(searchInputs);
            var replaceTexts = readInputTexts(replaceInputs);
            saveDialogSettings(searchTexts, replaceTexts, dialogState);
            var searchEntries = getSearchEntries(searchTexts, replaceTexts, dialogState.values.useRegex, dialogState.values.matchCase, dialogState.values.deleteEmptyLines);
            /* 空になったフレームを削除すると selectedItems に無効な参照が残るので、シンボルも先に集める
               Collect symbols up front too, as deleting emptied frames leaves invalid references in selectedItems */
            var editTargets = collectEditTargets();
            var replaceResult = replaceTextInFrames(editTargets.textFrames, searchEntries, dialogState.values.deleteEmptyFrames);
            replaceTextInSymbols(doc, editTargets.symbols, searchEntries, replaceResult.processedCounts);
            /* 次の実行や閉じたあとの選択の復元で使わないよう、削除したフレームを取り除く
               Drop the deleted frames so later runs and the selection restore do not touch them */
            for (var i = selectedItems.length - 1; i >= 0; i--) {
                if (indexOfItem(replaceResult.deletedFrames, selectedItems[i]) !== -1) selectedItems.splice(i, 1);
            }
            refreshAfterEdit();
        }

        /* 入力欄を空にし、対象とオプションを初期値に戻す（プレビューの ON/OFF はそのまま）
           Clear the fields and restore the scope and options to their defaults, keeping the preview setting */
        function resetDialog() {
            clearAllInputs();
            for (var j = 0; j < dialogState.settingControls.length; j++) {
                var settingControl = dialogState.settingControls[j];
                settingControl.checkbox.value = settingControl.defaultValue;
                dialogState.values[settingControl.settingKey] = settingControl.defaultValue;
            }
            dialogState.scope = getInitialScope(null, hasSelection);
            dialogControls.scopeRadios[dialogState.scope].value = true;
            findReplaceControls.focusFirstInput();
            refreshDialogState();
        }

        for (var i = 0; i < searchInputs.length; i++) {
            searchInputs[i].onChanging = refreshDialogState;
            replaceInputs[i].onChanging = updatePreview;
        }
        /* 選択している文字列を1行目の検索する文字列にする（ほかの欄は空にする）
           The selected text becomes the first text to find; the other fields are cleared */
        var selectedQueryText = getSelectedQueryText(selectedTextRange, selectedItems);
        if (selectedQueryText !== "") {
            clearAllInputs();
            searchInputs[0].text = convertTextToQuery(selectedQueryText, dialogState.values.useRegex);
        }

        dialogState.onSettingChange = refreshDialogState;
        findReplaceControls.btnSelectNext.onClick = function () {
            matchSelector.selectNext(findReplaceControls.getActiveRowIndex(), dialogState.values.zoomToMatch);
        };
        findReplaceControls.btnSelectAll.onClick = function () {
            matchSelector.selectAllFrames(findReplaceControls.getActiveRowIndex());
        };
        findReplaceControls.btnReset.onClick = resetDialog;
        findReplaceControls.btnReplaceAll.onClick = runReplace;
        findReplaceControls.previewCheckbox.onClick = function () {
            isPreviewOn = this.value;
            updatePreview();
        };

        refreshDialogState();

        /* show() 前に入れた値は効かないことがあるので、表示してからもプレビューを OFF にする
           A value set before show() may not stick, so turn Preview off again once shown */
        dialogControls.mainDialog.onShow = function () {
            findReplaceControls.previewCheckbox.value = false;
            isPreviewOn = false;
        };
        prepareDialogWindow(dialogControls.mainDialog, SCRIPT_NAME);
        dialogControls.mainDialog.show();
        clearPreview();
        /* ［次を選択］［すべてを選択］で選択したときは、その選択を残す / Keep the selection made by Select Next or Select All */
        if ((hasShownPreview || hasChangedSelection) && !matchSelector.hasSelected()) {
            /* 戻せない選択（ロック・非表示になったものなど）は例外になるので無視する / Ignore a selection that can no longer be restored */
            try {
                doc.selection = (selectedItems.length > 0) ? selectedItems : null;
            } catch (e) {}
        }
        /* 閉じたときの入力内容と設定も次回に引き継ぐ / Keep the entries and settings at closing for the next run */
        saveDialogSettings(readInputTexts(searchInputs), readInputTexts(replaceInputs), dialogState);
    }

    /**
     * ［次を選択］［すべてを選択］の処理を用意する（次に選ぶ一致の位置を行ごとに持つ）
     * @param {Document} doc - 対象ドキュメント
     * @param {Function} collectRowMatches - (rowIndex) を受け取り、findSelectableMatches() の結果を返す処理
     * @returns {Object} { selectNext: Function, selectAllFrames: Function, resetCursor: Function, hasSelected: Function }
     *   selectNext(rowIndex, shouldZoom) で次の一致を選択し、selectAllFrames(rowIndex) で一致を含むテキストをすべて選択する
     */
    function createMatchSelector(doc, collectRowMatches) {
        /* 次に選ぶ一致の番号と、その行（行や検索の条件が変わったら最初に戻す）/ Index of the next match and its row; reset when the row or the search changes */
        var nextMatchIndex = 0;
        var nextMatchRowIndex = -1;
        /* 選択したか（閉じたあとも選択を残す）/ Whether anything was selected; that selection is kept after closing */
        var hasSelectedMatch = false;

        return {
            selectNext: function (rowIndex, shouldZoom) {
                if (rowIndex !== nextMatchRowIndex) {
                    nextMatchIndex = 0;
                    nextMatchRowIndex = rowIndex;
                }
                var matchRecords = collectRowMatches(rowIndex);
                if (matchRecords.length === 0) return;
                if (nextMatchIndex >= matchRecords.length) nextMatchIndex = 0;
                var matchRecord = matchRecords[nextMatchIndex];
                /* select() は今の選択に足されるので、先に解除して一致した文字だけを選択する
                   select() adds to the current selection, so clear it first to select only the match */
                doc.selection = null;
                selectTextSpan(matchRecord.textFrame, matchRecord.start, matchRecord.length);
                if (shouldZoom) zoomToItem(doc, matchRecord.textFrame);
                hasSelectedMatch = true;
                nextMatchIndex++;
                app.redraw();
            },
            selectAllFrames: function (rowIndex) {
                var matchRecords = collectRowMatches(rowIndex);
                var matchingFrames = [];
                for (var i = 0; i < matchRecords.length; i++) {
                    if (indexOfItem(matchingFrames, matchRecords[i].textFrame) === -1) matchingFrames.push(matchRecords[i].textFrame);
                }
                doc.selection = (matchingFrames.length > 0) ? matchingFrames : null;
                hasSelectedMatch = true;
                nextMatchIndex = 0;
                app.redraw();
            },
            resetCursor: function () {
                nextMatchIndex = 0;
            },
            hasSelected: function () {
                return hasSelectedMatch;
            }
        };
    }

    /**
     * 選択できるテキスト（表示中でロックされていないもの）から、一致箇所を集める
     * @param {TextFrame[]} targetFrames - 対象のテキストフレーム
     * @param {RegExp} searchPattern - g フラグ付きの検索パターン
     * @returns {Object[]} { textFrame: TextFrame, start: number, length: number } の配列（フレーム順・位置順）
     */
    function findSelectableMatches(targetFrames, searchPattern) {
        var visibleOnly = { includeHidden: false, includeLocked: false };
        var matchRecords = [];
        for (var i = 0; i < targetFrames.length; i++) {
            if (!isSearchableItem(targetFrames[i], visibleOnly)) continue;
            var frameMatches = findMatches(targetFrames[i].contents, searchPattern);
            for (var j = 0; j < frameMatches.length; j++) {
                matchRecords.push({ textFrame: targetFrames[i], start: frameMatches[j].start, length: frameMatches[j].length });
            }
        }
        return matchRecords;
    }

    /**
     * ダイアログを組み立てる（タブ・対象とオプション・ボタン行）
     * @param {Object} savedSettings - loadSettings() の結果
     * @param {Object} dialogState - showFindReplaceDialog() の状態
     * @param {boolean} hasSelection - 選択があるか
     * @param {Function} onConvert - 英文・整形タブのボタンを押したときに (convertText, conversionKey) を受け取る処理
     * @returns {Object} { mainDialog: Window, modeTabbedPanel: TabbedPanel, findReplaceTab: Tab, findReplaceControls: Object, conversionPanelBuilder: Object, scopeRadios: Object }
     */
    function buildMainDialog(savedSettings, dialogState, hasSelection, onConvert) {
        var mainDialog = new Window("dialog", getLabel(LABELS.dialog.title) + " " + SCRIPT_VERSION);
        setupWindow(mainDialog);

        /* 「検索・置換」「英文」「整形」をタブで切り替える / Switch between the find/replace, English and cleanup tabs */
        var modeTabbedPanel = mainDialog.add("tabbedpanel");
        modeTabbedPanel.alignChildren = ["fill", "top"];
        var findReplaceTab = addDialogTab(modeTabbedPanel, LABELS.tab.findReplace);
        var englishTab = addDialogTab(modeTabbedPanel, LABELS.tab.englishText);
        var cleanupTab = addDialogTab(modeTabbedPanel, LABELS.tab.cleanup);
        modeTabbedPanel.selection = findReplaceTab;

        var findReplaceControls = buildFindReplacePanel(findReplaceTab, savedSettings, dialogState);
        var conversionPanelBuilder = createConversionPanelBuilder(onConvert);
        conversionPanelBuilder.addConversionPanel(englishTab, LABELS.panel.letterCase, ["caseUpper", "caseLower", "caseWord", "caseSentence", "caseTitle"]);
        buildCleanupPanels(cleanupTab, onConvert);

        /* 対象とオプションを2カラムに並べる / Place the scope and options panels in two columns */
        var scopeOptionsGroup = mainDialog.add("group");
        scopeOptionsGroup.orientation = "row";
        scopeOptionsGroup.alignChildren = ["fill", "fill"];
        var scopeRadios = buildScopePanel(scopeOptionsGroup, dialogState, hasSelection);
        buildOptionsPanel(scopeOptionsGroup, savedSettings, dialogState);

        /* ボタン行（右に閉じる。どのタブのボタンも押した時点で実行するので OK・キャンセルは置かない）
           Button row: Close on the right; every tab's buttons run on click, so there is no OK/Cancel */
        var buttonRow = addButtonRow(mainDialog);
        /* name を cancel にして Esc でも閉じる / Named cancel so Esc also closes */
        var btnClose = buttonRow.rightGroup.add("button", undefined, getLabel(LABELS.button.close), { name: "cancel" });
        alignRightOnlyButtonRow(buttonRow);
        /* Enter で［すべてを置換］を押す（検索・置換タブ以外では runReplace() が何もしない）/ Enter presses Replace All; runReplace() ignores it on other tabs */
        mainDialog.defaultElement = findReplaceControls.btnReplaceAll;

        return {
            mainDialog: mainDialog,
            modeTabbedPanel: modeTabbedPanel,
            findReplaceTab: findReplaceTab,
            findReplaceControls: findReplaceControls,
            conversionPanelBuilder: conversionPanelBuilder,
            scopeRadios: scopeRadios
        };
    }

    /**
     * 入力内容とチェックボックス・対象の設定を保存する
     * @param {string[]} searchTexts - 検索欄の文字列
     * @param {string[]} replaceTexts - 置換欄の文字列
     * @param {Object} dialogState - showFindReplaceDialog() の状態
     * @returns {void}
     */
    function saveDialogSettings(searchTexts, replaceTexts, dialogState) {
        var settingsToSave = { searchTexts: searchTexts, replaceTexts: replaceTexts, scope: dialogState.scope };
        for (var i = 0; i < dialogState.settingControls.length; i++) {
            var settingKey = dialogState.settingControls[i].settingKey;
            settingsToSave[settingKey] = dialogState.values[settingKey];
        }
        saveSettings(settingsToSave);
    }

    /**
     * 最初に選ぶ対象範囲を決める（何も選択していなければ「選択中のオブジェクト」は選べない）
     * @param {string|null} savedScope - 前回の対象範囲
     * @param {boolean} hasSelection - 選択があるか
     * @returns {string} "selection" / "artboard" / "document"
     */
    function getInitialScope(savedScope, hasSelection) {
        if (savedScope === "artboard") return "artboard";
        if (savedScope === "document" || !hasSelection) return "document";
        return "selection";
    }

    /**
     * 入力欄の文字列を配列にする
     * @param {EditText[]} inputFields - 入力欄
     * @returns {string[]} 各欄の文字列
     */
    function readInputTexts(inputFields) {
        var inputTexts = [];
        for (var i = 0; i < inputFields.length; i++) {
            inputTexts.push(inputFields[i].text);
        }
        return inputTexts;
    }

    /**
     * 設定を保存するチェックボックスを追加する（前回の値か初期値で始め、リセットと保存のために記録する）
     * @param {Object} parentGroup - 追加先のパネルかグループ
     * @param {string} settingKey - LABELS.checkbox・LABELS.tooltip・保存する設定に共通のキー
     * @param {boolean} defaultValue - 初期値
     * @param {Object} savedSettings - loadSettings() の結果
     * @param {Object} dialogState - showFindReplaceDialog() の状態
     * @returns {Checkbox} 追加したチェックボックス
     */
    function addSettingCheckbox(parentGroup, settingKey, defaultValue, savedSettings, dialogState) {
        var settingCheckbox = parentGroup.add("checkbox", undefined, getLabel(LABELS.checkbox[settingKey]));
        var initialValue = (typeof savedSettings[settingKey] === "boolean") ? savedSettings[settingKey] : defaultValue;
        settingCheckbox.value = initialValue;
        setOptionalHelpTip(settingCheckbox, settingKey);
        dialogState.values[settingKey] = initialValue;
        dialogState.settingControls.push({ settingKey: settingKey, checkbox: settingCheckbox, defaultValue: defaultValue });
        settingCheckbox.onClick = function () {
            dialogState.values[settingKey] = this.value;
            if (dialogState.onSettingChange) dialogState.onSettingChange();
        };
        return settingCheckbox;
    }

    /**
     * LABELS.tooltip にキーがあれば、そのツールチップを付ける
     * @param {Object} control - 対象のコントロール
     * @param {string} tooltipKey - LABELS.tooltip のキー
     * @returns {void}
     */
    function setOptionalHelpTip(control, tooltipKey) {
        if (LABELS.tooltip[tooltipKey]) control.helpTip = getLabel(LABELS.tooltip[tooltipKey]);
    }

    /**
     * タブを追加する
     * @param {TabbedPanel} tabbedPanel - 追加先のタブパネル
     * @param {Object} labelSet - { ja, en } を持つタブ名
     * @returns {Tab} 追加したタブ
     */
    function addDialogTab(tabbedPanel, labelSet) {
        var dialogTab = tabbedPanel.add("tab", undefined, getLabel(labelSet));
        setupTab(dialogTab);
        return dialogTab;
    }

    /**
     * 「検索・置換する文字列」パネルを作る（入力欄の行・挿入ボタンの行・チェックボックスとボタンの行）
     * @param {Tab} parentTab - 追加先のタブ
     * @param {Object} savedSettings - loadSettings() の結果
     * @param {Object} dialogState - showFindReplaceDialog() の状態
     * @returns {Object} { searchInputs: EditText[], replaceInputs: EditText[], matchCountLabels: StaticText[], referenceButtonGroup: Group, previewCheckbox: Checkbox, btnSelectNext: Button, btnSelectAll: Button, btnReset: Button, btnReplaceAll: Button, focusFirstInput: Function, getActiveRowIndex: Function }
     */
    function buildFindReplacePanel(parentTab, savedSettings, dialogState) {
        var findReplacePanel = parentTab.add("panel", undefined, getLabel(LABELS.panel.findReplace));
        setupPanel(findReplacePanel, 6);
        var fieldRows = addSearchFieldRows(findReplacePanel, savedSettings, dialogState);
        var referenceButtonGroup = addInsertButtonRow(findReplacePanel, fieldRows.getLastActiveInput);
        var searchOptionsControls = addSearchOptionsRow(findReplacePanel, savedSettings, dialogState);
        return {
            searchInputs: fieldRows.searchInputs,
            replaceInputs: fieldRows.replaceInputs,
            matchCountLabels: fieldRows.matchCountLabels,
            referenceButtonGroup: referenceButtonGroup,
            previewCheckbox: searchOptionsControls.previewCheckbox,
            btnSelectNext: searchOptionsControls.btnSelectNext,
            btnSelectAll: searchOptionsControls.btnSelectAll,
            btnReset: searchOptionsControls.btnReset,
            btnReplaceAll: searchOptionsControls.btnReplaceAll,
            focusFirstInput: fieldRows.focusFirstInput,
            getActiveRowIndex: fieldRows.getActiveRowIndex
        };
    }

    /**
     * 検索・置換の入力欄を行ごとに並べる（行頭の目印・検索欄・置換欄・一致数）。カーソルのある欄を記録し、その行に目印を出す
     * @param {Panel} findReplacePanel - 追加先のパネル
     * @param {Object} savedSettings - loadSettings() の結果
     * @param {Object} dialogState - showFindReplaceDialog() の状態
     * @returns {Object} { searchInputs: EditText[], replaceInputs: EditText[], matchCountLabels: StaticText[], focusFirstInput: Function, getActiveRowIndex: Function, getLastActiveInput: Function }
     */
    function addSearchFieldRows(findReplacePanel, savedSettings, dialogState) {
        var savedSearchTexts = savedSettings.searchTexts || [];
        var savedReplaceTexts = savedSettings.replaceTexts || [];
        var searchInputs = [];
        var replaceInputs = [];
        var matchCountLabels = [];
        var rowMarkers = [];
        /* 最後にカーソルがあった入力欄（挿入ボタンの挿入先・選択の対象の行）/ Field that last had the cursor: where insert buttons insert, and the row selecting uses */
        var lastActiveInput = null;

        /* 入力欄に、挿入先の記録とショートカットを付ける / Track the cursor field and add the shortcuts */
        function setupShortcutInput(targetInput) {
            targetInput.onActivate = function () {
                lastActiveInput = this;
                updateRowMarkers();
            };
            targetInput.addEventListener("keydown", function (keyEvent) {
                var insertedToken = getShortcutToken(keyEvent.keyName, ScriptUI.environment.keyboardState, dialogState.values.useRegex);
                if (!insertedToken) return;
                /* Enter で［すべてを置換］が押されたり、option＋数字で記号が入ったりしないよう止める
                   Keep Enter from pressing Replace All and option+digit from typing a symbol */
                keyEvent.preventDefault();
                this.textselection = insertedToken;
                if (this.onChanging) this.onChanging();
            });
        }

        /* カーソルのある行の番号（置換欄にあるときもその行）/ Row index of the field with the cursor, including the replace fields */
        function getActiveRowIndex() {
            for (var i = 0; i < searchInputs.length; i++) {
                if (lastActiveInput === searchInputs[i] || lastActiveInput === replaceInputs[i]) return i;
            }
            return 0;
        }

        /* カーソルのある行にだけ目印を出す / Show the marker only on the row with the cursor */
        function updateRowMarkers() {
            var activeRowIndex = getActiveRowIndex();
            for (var i = 0; i < rowMarkers.length; i++) {
                rowMarkers[i].visible = (i === activeRowIndex);
            }
        }

        /* 先頭の入力欄にカーソルを置く / Put the cursor in the first field */
        function focusFirstInput() {
            lastActiveInput = searchInputs[0];
            searchInputs[0].active = true;
            updateRowMarkers();
        }

        for (var i = 0; i < SEARCH_FIELD_COUNT; i++) {
            var fieldRowGroup = findReplacePanel.add("group");
            fieldRowGroup.orientation = "row";
            fieldRowGroup.alignChildren = ["left", "center"];
            /* ［次を選択］などの対象になる行の目印 / Marker of the row Select Next and Select All work on */
            /* 空にすると表示前の配置で幅が縮んで欄がずれるので、記号は入れたまま visible で出し分ける
               Emptying it shrinks the width before layout and shifts the fields, so keep the marker and toggle visible */
            var rowMarker = fieldRowGroup.add("statictext", undefined, ROW_MARKER_TEXT);
            rowMarker.helpTip = getLabel(LABELS.tooltip.rowMarker);
            var searchInput = fieldRowGroup.add("edittext", undefined, savedSearchTexts[i] || "");
            searchInput.characters = INPUT_CHARACTERS;
            searchInput.helpTip = getLabel(LABELS.tooltip.searchText);
            setupShortcutInput(searchInput);
            fieldRowGroup.add("statictext", undefined, "→");
            var replaceInput = fieldRowGroup.add("edittext", undefined, savedReplaceTexts[i] || "");
            replaceInput.characters = REPLACE_INPUT_CHARACTERS;
            replaceInput.helpTip = getLabel(LABELS.tooltip.replaceText);
            setupShortcutInput(replaceInput);
            var matchCountLabel = fieldRowGroup.add("statictext", undefined, "");
            matchCountLabel.preferredSize.width = MATCH_COUNT_WIDTH;
            matchCountLabel.justify = "right";
            matchCountLabel.helpTip = getLabel(LABELS.tooltip.matchCount);
            rowMarkers.push(rowMarker);
            searchInputs.push(searchInput);
            replaceInputs.push(replaceInput);
            matchCountLabels.push(matchCountLabel);
        }
        focusFirstInput();

        return {
            searchInputs: searchInputs,
            replaceInputs: replaceInputs,
            matchCountLabels: matchCountLabels,
            focusFirstInput: focusFirstInput,
            getActiveRowIndex: getActiveRowIndex,
            getLastActiveInput: function () {
                return lastActiveInput;
            }
        };
    }

    /**
     * 挿入ボタンの行を作る（左に改行、右に正規表現の検索結果の参照）
     * @param {Panel} findReplacePanel - 追加先のパネル
     * @param {Function} getLastActiveInput - 挿入先の入力欄を返す処理
     * @returns {Group} 検索結果の参照ボタンのグループ（正規表現のときだけ使えるようにする）
     */
    function addInsertButtonRow(findReplacePanel, getLastActiveInput) {
        /* ボタンを押すと入力欄のカーソルが失われるので、押し下げた時点の位置を控える / Clicking a button loses the caret, so keep its position from the mouse down */
        var savedCaret = null;
        var insertButtonRowGroup = findReplacePanel.add("group");
        insertButtonRowGroup.orientation = "row";
        insertButtonRowGroup.alignment = ["fill", "top"];
        insertButtonRowGroup.alignChildren = ["left", "top"];
        insertButtonRowGroup.margins = [0, INSERT_BUTTON_TOP_MARGIN, 0, 0];

        /* 押すとカーソルの位置に記号を入れるボタンを作る / Create a button that inserts a token at the cursor */
        function addInsertButton(parentGroup, labelKey, insertedToken) {
            var insertButton = addSmallButton(parentGroup, labelKey);
            /* クリックが確定する前（押し下げた時点）にカーソル位置を読む / Read the caret on mouse down, before the click completes */
            insertButton.addEventListener("mousedown", function () {
                savedCaret = captureCaret(getLastActiveInput());
            });
            insertButton.onClick = function () {
                var targetInput = getLastActiveInput();
                insertTokenAtCaret(targetInput, insertedToken, savedCaret);
                if (targetInput.onChanging) targetInput.onChanging();
            };
        }

        /* 左：改行 / Left: breaks */
        var breakButtonGroup = addButtonRowGroup(insertButtonRowGroup);
        addInsertButton(breakButtonGroup, "paragraphBreak", PARAGRAPH_BREAK_TOKEN);
        addInsertButton(breakButtonGroup, "lineBreak", LINE_BREAK_TOKEN);

        /* 中央：スペーサー（伸縮）/ Center: spacer (stretchable) */
        addStretchSpacer(insertButtonRowGroup);

        /* 右：検索結果の参照（正規表現のときだけ使える）。1行目に「検索結果すべて」、2行目に「検索結果1」「検索結果2」
           Right: match references, available with regular expressions only. Whole match on the first line, groups 1 and 2 on the second */
        var referenceButtonGroup = insertButtonRowGroup.add("group");
        referenceButtonGroup.orientation = "column";
        referenceButtonGroup.alignment = ["right", "top"];
        referenceButtonGroup.alignChildren = ["left", "top"];
        referenceButtonGroup.spacing = INSERT_BUTTON_LINE_SPACING;
        var wholeMatchButtonGroup = addButtonRowGroup(referenceButtonGroup);
        addInsertButton(wholeMatchButtonGroup, "wholeMatch", "\\0");
        var groupReferenceButtonGroup = addButtonRowGroup(referenceButtonGroup);
        addInsertButton(groupReferenceButtonGroup, "group1", "\\1");
        addInsertButton(groupReferenceButtonGroup, "group2", "\\2");
        return referenceButtonGroup;
    }

    /**
     * チェックボックスとボタンの行を作る（左に正規表現などのチェックボックスとプレビュー、右下に選択・リセット・すべてを置換）
     * @param {Panel} findReplacePanel - 追加先のパネル
     * @param {Object} savedSettings - loadSettings() の結果
     * @param {Object} dialogState - showFindReplaceDialog() の状態
     * @returns {Object} { previewCheckbox: Checkbox, btnSelectNext: Button, btnSelectAll: Button, btnReset: Button, btnReplaceAll: Button }
     */
    function addSearchOptionsRow(findReplacePanel, savedSettings, dialogState) {
        var searchOptionsRowGroup = findReplacePanel.add("group");
        searchOptionsRowGroup.orientation = "row";
        searchOptionsRowGroup.alignment = ["fill", "top"];
        searchOptionsRowGroup.alignChildren = ["left", "bottom"];
        searchOptionsRowGroup.margins = [0, SEARCH_OPTIONS_ROW_TOP_MARGIN, 0, 0];
        var searchOptionsGroup = searchOptionsRowGroup.add("group");
        searchOptionsGroup.orientation = "column";
        searchOptionsGroup.alignChildren = ["left", "top"];
        searchOptionsGroup.margins = [0, SEARCH_OPTIONS_TOP_MARGIN, 0, 0];
        searchOptionsGroup.spacing = OPTION_ROW_SPACING;
        addSettingCheckbox(searchOptionsGroup, "useRegex", DEFAULT_USE_REGEX, savedSettings, dialogState);
        /* プレビューは正規表現のときだけ使うので、そのすぐ下に置く。保存せず、開くときは常に OFF
           Preview is for regular expressions only, so it sits right below; not saved, and always starts off */
        var previewCheckbox = searchOptionsGroup.add("checkbox", undefined, getLabel(LABELS.checkbox.preview));
        previewCheckbox.value = false;
        previewCheckbox.helpTip = getLabel(LABELS.tooltip.preview);
        addSettingCheckbox(searchOptionsGroup, "matchCase", DEFAULT_MATCH_CASE, savedSettings, dialogState);
        addSettingCheckbox(searchOptionsGroup, "deleteEmptyLines", DEFAULT_DELETE_EMPTY_LINES, savedSettings, dialogState);
        addSettingCheckbox(searchOptionsGroup, "deleteEmptyFrames", DEFAULT_DELETE_EMPTY_FRAMES, savedSettings, dialogState);
        addSettingCheckbox(searchOptionsGroup, "zoomToMatch", DEFAULT_ZOOM_TO_MATCH, savedSettings, dialogState);
        addStretchSpacer(searchOptionsRowGroup);
        var actionButtonGroup = searchOptionsRowGroup.add("group");
        actionButtonGroup.orientation = "column";
        actionButtonGroup.alignment = ["right", "bottom"];
        actionButtonGroup.alignChildren = ["fill", "top"];

        /* ツールチップ付きのボタンを追加する / Add a button with its tooltip */
        function addActionButton(labelKey) {
            var actionButton = actionButtonGroup.add("button", undefined, getLabel(LABELS.button[labelKey]));
            actionButton.helpTip = getLabel(LABELS.tooltip[labelKey]);
            return actionButton;
        }

        return {
            previewCheckbox: previewCheckbox,
            btnSelectNext: addActionButton("selectNext"),
            btnSelectAll: addActionButton("selectAll"),
            btnReset: addActionButton("reset"),
            btnReplaceAll: addActionButton("replaceAll")
        };
    }

    /**
     * 行の中で伸び縮みするスペーサーを追加する（左右のコントロールを両端に寄せる）
     * @param {Group} rowGroup - 追加先の行
     * @returns {Group} 追加したスペーサー
     */
    function addStretchSpacer(rowGroup) {
        var spacerGroup = rowGroup.add("group");
        spacerGroup.alignment = ["fill", "fill"];
        spacerGroup.minimumSize.width = 0;
        return spacerGroup;
    }

    /**
     * 変換ボタンと変換結果の見本を1行ずつ並べるパネルの作り手を用意する（見本はまとめて更新する）
     * @param {Function} onConvert - ボタンを押したときに (convertText, conversionKey) を受け取る処理
     * @returns {Object} { addConversionPanel: Function, updateSamples: Function }
     *   addConversionPanel(parentGroup, labelSet, conversionKeys) でパネルを追加し、updateSamples(sampleText) で見本を更新する
     */
    function createConversionPanelBuilder(onConvert) {
        /* 見本の一覧 / Sample rows */
        var sampleRows = [];

        /* ボタンを押したら変換関数を渡す / Pass the converter when the button is clicked */
        function setConvertHandler(conversionButton, conversionKey) {
            conversionButton.onClick = function () {
                onConvert(getTextConverter(conversionKey), conversionKey);
            };
        }

        return {
            addConversionPanel: function (parentGroup, labelSet, conversionKeys) {
                var conversionPanel = parentGroup.add("panel", undefined, getLabel(labelSet));
                setupPanel(conversionPanel, 6);
                /* 見本をパネルの幅いっぱいに伸ばす / Stretch the samples to the panel width */
                conversionPanel.alignChildren = ["fill", "top"];
                for (var i = 0; i < conversionKeys.length; i++) {
                    var conversionRowGroup = addButtonRowGroup(conversionPanel);
                    var conversionButton = conversionRowGroup.add("button", undefined, getLabel(LABELS.button[conversionKeys[i]]));
                    conversionButton.preferredSize = CONVERSION_BUTTON_SIZE;
                    setOptionalHelpTip(conversionButton, conversionKeys[i]);
                    setConvertHandler(conversionButton, conversionKeys[i]);
                    var sampleLabel = conversionRowGroup.add("statictext", undefined, "");
                    sampleLabel.preferredSize = CONVERSION_SAMPLE_SIZE;
                    sampleLabel.alignment = ["fill", "center"];
                    sampleRows.push({ sampleLabel: sampleLabel, convertText: getTextConverter(conversionKeys[i]) });
                }
            },
            updateSamples: function (sampleText) {
                var shortSample = shortenSampleText(sampleText);
                for (var i = 0; i < sampleRows.length; i++) {
                    sampleRows[i].sampleLabel.text = shortenSampleText(sampleRows[i].convertText(shortSample));
                }
            }
        };
    }

    /**
     * 「整形」タブの縦のカラムを作る
     * @param {Group} parentGroup - 追加先のグループ
     * @returns {Group} 作ったカラム
     */
    function addCleanupColumn(parentGroup) {
        var cleanupColumnGroup = parentGroup.add("group");
        cleanupColumnGroup.orientation = "column";
        cleanupColumnGroup.alignment = ["fill", "top"];
        cleanupColumnGroup.alignChildren = ["fill", "top"];
        return cleanupColumnGroup;
    }

    /**
     * 「整形」タブの中身を作る（左にタブ・スペース、右に記号の変換・かな・数字の変換・リストの除去）
     * @param {Tab} parentTab - 追加先のタブ
     * @param {Function} onConvert - ボタンを押したときに (convertText, conversionKey) を受け取る処理
     * @returns {void}
     */
    function buildCleanupPanels(parentTab, onConvert) {
        var cleanupColumnsGroup = parentTab.add("group");
        cleanupColumnsGroup.orientation = "row";
        cleanupColumnsGroup.alignChildren = ["fill", "top"];
        var leftColumnGroup = addCleanupColumn(cleanupColumnsGroup);
        var rightColumnGroup = addCleanupColumn(cleanupColumnsGroup);

        /* 押すと変換を実行するボタンを作る / Create a button that runs a conversion */
        function addCleanupButton(parentGroup, labelKey) {
            var cleanupButton = parentGroup.add("button", undefined, getLabel(LABELS.button[labelKey]));
            setOptionalHelpTip(cleanupButton, labelKey);
            cleanupButton.onClick = function () {
                onConvert(getTextConverter(labelKey), labelKey);
            };
        }

        /* ボタンを縦に並べたパネルを作る / Create a panel of stacked buttons */
        function addCleanupPanel(parentColumn, labelSet, labelKeys) {
            var cleanupPanel = parentColumn.add("panel", undefined, getLabel(labelSet));
            setupPanel(cleanupPanel, 6);
            cleanupPanel.margins = CLEANUP_PANEL_MARGINS;
            cleanupPanel.alignChildren = ["fill", "top"];
            for (var i = 0; i < labelKeys.length; i++) {
                addCleanupButton(cleanupPanel, labelKeys[i]);
            }
            return cleanupPanel;
        }

        addCleanupPanel(leftColumnGroup, LABELS.panel.tabCharacter, ["removeTabs", "tabsToSpaces"]);
        addCleanupPanel(leftColumnGroup, LABELS.panel.removeSpace, ["trimSpaces", "cjkLatinSpaces", "collapseSpaces", "cleanupSpaces"]);
        addCleanupPanel(leftColumnGroup, LABELS.panel.addSpace, ["spaceAfterPunct"]);

        buildSymbolConversionPanel(rightColumnGroup, onConvert);
        /* かなと数字の変換は1つのパネルに2行で並べる / Put kana and digit conversions in one panel, on two rows */
        var kanaDigitPanel = addCleanupPanel(rightColumnGroup, LABELS.panel.kanaDigitConversion, []);
        kanaDigitPanel.alignChildren = ["left", "top"];
        var kanaButtonRowGroup = addButtonRowGroup(kanaDigitPanel);
        addCleanupButton(kanaButtonRowGroup, "toHiragana");
        addCleanupButton(kanaButtonRowGroup, "toKatakana");
        addCleanupButton(kanaButtonRowGroup, "toHalfKana");
        var digitButtonRowGroup = addButtonRowGroup(kanaDigitPanel);
        addCleanupButton(digitButtonRowGroup, "toHalfDigit");
        addCleanupButton(digitButtonRowGroup, "toFullDigit");

        /* リストの除去はボタンを横に並べ、伸ばさない / List removal buttons in a row, at their natural width */
        var removeListPanel = addCleanupPanel(rightColumnGroup, LABELS.panel.removeList, ["bulletList", "numberList"]);
        removeListPanel.orientation = "row";
        removeListPanel.alignChildren = ["left", "center"];
    }

    /**
     * 「スペースや記号の変換」パネルを作る（変換前・変換後をラジオで選び、［変換］で置き換える。変換前と同じ記号は変換後で選べない）
     * @param {Group} parentColumn - 追加先のカラム
     * @param {Function} onConvert - ［変換］を押したときに (convertText, conversionKey) を受け取る処理
     * @returns {void}
     */
    function buildSymbolConversionPanel(parentColumn, onConvert) {
        var symbolConversionPanel = parentColumn.add("panel", undefined, getLabel(LABELS.panel.symbolConversion));
        setupPanel(symbolConversionPanel, 6);
        symbolConversionPanel.margins = CLEANUP_PANEL_MARGINS;
        symbolConversionPanel.alignChildren = ["fill", "top"];
        /* 選んでいる記号。show() 前はラジオの value を読み戻せないので、ここに持つ
           Chosen symbols, kept here as radio values cannot be read back before show() */
        var symbolChoice = { before: "space", after: "underscore" };
        var afterRadios;

        /* 変換前で選んだ記号を変換後ではディムにし、重なったら変換後を空いている記号に移す
           Dim the Before symbol on the After side, and move After to a free symbol when they collide */
        function syncAfterRadios() {
            if (symbolChoice.after === symbolChoice.before) {
                symbolChoice.after = (symbolChoice.before === "space") ? "underscore" : "space";
            }
            for (var symbolKind in afterRadios) {
                afterRadios[symbolKind].enabled = (symbolKind !== symbolChoice.before);
                afterRadios[symbolKind].value = (symbolKind === symbolChoice.after);
            }
        }

        /* 変換前と変換後を2カラムに並べる / Place Before and After in two columns */
        var symbolColumnsGroup = symbolConversionPanel.add("group");
        symbolColumnsGroup.orientation = "row";
        symbolColumnsGroup.alignChildren = ["fill", "top"];
        addSymbolRadioPanel(symbolColumnsGroup, LABELS.panel.symbolBefore, symbolChoice, "before", syncAfterRadios);
        afterRadios = addSymbolRadioPanel(symbolColumnsGroup, LABELS.panel.symbolAfter, symbolChoice, "after", null);
        syncAfterRadios();

        var btnConvertSymbol = symbolConversionPanel.add("button", undefined, getLabel(LABELS.button.convertSymbol));
        btnConvertSymbol.alignment = ["center", "top"];
        setOptionalHelpTip(btnConvertSymbol, "convertSymbol");
        btnConvertSymbol.onClick = function () {
            onConvert(createSymbolConverter(symbolChoice.before, symbolChoice.after), "convertSymbol");
        };
    }

    /**
     * 記号（スペース・アンダースコア・ハイフン）を選ぶラジオのパネルを作る
     * @param {Group} parentGroup - 追加先のグループ
     * @param {Object} labelSet - { ja, en } を持つパネル名
     * @param {Object} symbolChoice - 選んでいる記号を持つオブジェクト
     * @param {string} choiceKey - symbolChoice のキー（"before" / "after"）
     * @param {Function|null} onChoose - 選び直したときの処理（無ければ null）
     * @returns {Object} 記号の名前をキーにしたラジオボタン { space, underscore, hyphen }
     */
    function addSymbolRadioPanel(parentGroup, labelSet, symbolChoice, choiceKey, onChoose) {
        var symbolRadioPanel = parentGroup.add("panel", undefined, getLabel(labelSet));
        setupPanel(symbolRadioPanel, 6);
        symbolRadioPanel.margins = CLEANUP_PANEL_MARGINS;
        var symbolKinds = ["space", "underscore", "hyphen"];
        var symbolRadios = {};

        /* クリックした記号を控える / Keep the clicked symbol */
        function addSymbolRadio(symbolKind) {
            var symbolRadio = symbolRadioPanel.add("radiobutton", undefined, getLabel(LABELS.radio[symbolKind]));
            symbolRadio.value = (symbolChoice[choiceKey] === symbolKind);
            symbolRadio.onClick = function () {
                symbolChoice[choiceKey] = symbolKind;
                if (onChoose) onChoose();
            };
            symbolRadios[symbolKind] = symbolRadio;
        }
        for (var i = 0; i < symbolKinds.length; i++) {
            addSymbolRadio(symbolKinds[i]);
        }
        return symbolRadios;
    }

    /**
     * 見本に表示するよう、改行や連続する空白を詰めて短くする
     * @param {string} text - 元の文字列
     * @returns {string} 1行に詰めた文字列（長ければ末尾を「…」に）
     */
    function shortenSampleText(text) {
        var sampleText = String(text).replace(/[\r\n\x03]+/g, " ").replace(/[ 　\t]+/g, " ").replace(/^\s+|\s+$/g, "");
        if (sampleText.length > CONVERSION_SAMPLE_MAX_CHARS) sampleText = sampleText.substring(0, CONVERSION_SAMPLE_MAX_CHARS) + "...";
        return sampleText;
    }

    /**
     * 選択している文字列を返す（変換結果の見本用）。文字ツールで選択した文字、無ければ選択したテキストの内容
     * @param {TextRange|null} selectedTextRange - 文字ツールで選択した文字
     * @param {PageItem[]} selectedItems - 実行時に選択していたアイテム
     * @returns {string} 選択している文字列。無ければ空文字列
     */
    function getSelectedSampleText(selectedTextRange, selectedItems) {
        if (selectedTextRange) {
            /* 変換で文字が消えると範囲が無効になり例外になる / The range throws once conversions remove its characters */
            try {
                if (selectedTextRange.contents !== "") return selectedTextRange.contents;
            } catch (e) {}
        }
        var selectedFrames = [];
        for (var i = 0; i < selectedItems.length; i++) {
            if (selectedItems[i]) collectItemsOfType(selectedItems[i], "TextFrame", selectedFrames);
        }
        return getFirstNonEmptyText(getFrameContents(selectedFrames));
    }

    /**
     * 検索する文字列に入れる、選択している文字列を返す
     * 文字ツールで選択した文字、無ければ選択ツールで1つだけ選んだテキストオブジェクトの1行目（複数選んでいるときは入れない）
     * @param {TextRange|null} selectedTextRange - 文字ツールで選択した文字（まだ何も変換していないので読める）
     * @param {PageItem[]} selectedItems - 実行時に選択していたアイテム
     * @returns {string} 選択している文字列。無ければ空文字列
     */
    function getSelectedQueryText(selectedTextRange, selectedItems) {
        if (selectedTextRange) return selectedTextRange.contents;
        /* 最初の改行・強制改行までを1行目とする / The first line runs up to the first paragraph or forced line break */
        if (selectedItems.length === 1 && selectedItems[0].typename === "TextFrame") return selectedItems[0].contents.split(/[\r\x03]/)[0];
        return "";
    }

    /**
     * 文字列を検索欄に入れる形にする（改行は記号に、正規表現のときは記号の意味を消す）
     * @param {string} text - 元の文字列
     * @param {boolean} useRegex - 正規表現として扱うか
     * @returns {string} 検索欄に入れる文字列
     */
    function convertTextToQuery(text, useRegex) {
        var queryText = useRegex ? text.replace(/[.*+?^${}()|[\]\\\/]/g, "\\$&") : text;
        return queryText.split("\r").join(PARAGRAPH_BREAK_TOKEN).split("\x03").join(LINE_BREAK_TOKEN);
    }

    /**
     * 空でない最初の文字列を返す（変換結果の見本用）
     * @param {string[]} textContents - テキストの内容
     * @returns {string} 見つからなければ空文字列
     */
    function getFirstNonEmptyText(textContents) {
        for (var i = 0; i < textContents.length; i++) {
            if (textContents[i] !== "") return textContents[i];
        }
        return "";
    }

    /**
     * ボタンを横に並べるグループを作る
     * @param {Object} parentGroup - 追加先のグループ
     * @returns {Group} 作ったグループ
     */
    function addButtonRowGroup(parentGroup) {
        var buttonRowGroup = parentGroup.add("group");
        buttonRowGroup.orientation = "row";
        buttonRowGroup.alignChildren = ["left", "center"];
        return buttonRowGroup;
    }

    /**
     * ほかのボタンよりひとまわり小さいボタンを作る
     * @param {Object} parentGroup - 追加先のグループ
     * @param {string} labelKey - LABELS.button と LABELS.tooltip のキー
     * @returns {Button} 作ったボタン
     */
    function addSmallButton(parentGroup, labelKey) {
        var smallButton = parentGroup.add("button", undefined, getLabel(LABELS.button[labelKey]));
        smallButton.helpTip = getLabel(LABELS.tooltip[labelKey]);
        var buttonFont = smallButton.graphics.font;
        smallButton.graphics.font = ScriptUI.newFont(buttonFont.name, buttonFont.style, buttonFont.size - INSERT_BUTTON_FONT_SHRINK);
        smallButton.preferredSize.height = INSERT_BUTTON_HEIGHT;
        return smallButton;
    }

    /**
     * 「対象」パネルを作る
     * @param {Object} parentGroup - 追加先のグループ
     * @param {Object} dialogState - showFindReplaceDialog() の状態（scope を読み書きする）
     * @param {boolean} hasSelection - 選択があるか
     * @returns {Object} 対象範囲の名前をキーにしたラジオボタン { selection, artboard, document }
     */
    function buildScopePanel(parentGroup, dialogState, hasSelection) {
        var scopePanel = parentGroup.add("panel", undefined, getLabel(LABELS.panel.scope));
        setupPanel(scopePanel, 6);
        var scopeRadios = {
            selection: scopePanel.add("radiobutton", undefined, getLabel(LABELS.radio.selection)),
            artboard: scopePanel.add("radiobutton", undefined, getLabel(LABELS.radio.artboard)),
            document: scopePanel.add("radiobutton", undefined, getLabel(LABELS.radio.wholeDocument))
        };
        scopeRadios.selection.helpTip = getLabel(LABELS.tooltip.selection);
        scopeRadios.artboard.helpTip = getLabel(LABELS.tooltip.artboard);
        if (!hasSelection) {
            scopeRadios.selection.enabled = false;
            scopeRadios.selection.helpTip = getLabel(LABELS.tooltip.selectionUnavailable);
        }
        scopeRadios[dialogState.scope].value = true;

        /* クリックした範囲を控えて更新する / Keep the clicked scope and refresh */
        function selectScopeOnClick(scopeName) {
            scopeRadios[scopeName].onClick = function () {
                dialogState.scope = scopeName;
                if (dialogState.onSettingChange) dialogState.onSettingChange();
            };
        }
        for (var scopeName in scopeRadios) {
            selectScopeOnClick(scopeName);
        }
        return scopeRadios;
    }

    /**
     * 「オプション」パネルを作る
     * @param {Object} parentGroup - 追加先のグループ
     * @param {Object} savedSettings - loadSettings() の結果
     * @param {Object} dialogState - showFindReplaceDialog() の状態
     * @returns {void}
     */
    function buildOptionsPanel(parentGroup, savedSettings, dialogState) {
        var optionsPanel = parentGroup.add("panel", undefined, getLabel(LABELS.panel.options));
        setupPanel(optionsPanel, 6);
        addSettingCheckbox(optionsPanel, "includeHidden", DEFAULT_INCLUDE_HIDDEN, savedSettings, dialogState);
        addSettingCheckbox(optionsPanel, "includeLocked", DEFAULT_INCLUDE_LOCKED, savedSettings, dialogState);
        addSettingCheckbox(optionsPanel, "includeSymbols", DEFAULT_INCLUDE_SYMBOLS, savedSettings, dialogState);
    }

    // ボタン行（再利用パーツ） / Button row (reusable)

    var BUTTON_ROW_TOP_MARGIN = 5; /* ボタン行の上の余白 / top margin of the button row */
    var BUTTON_ROW_BOTTOM_MARGIN = 14; /* ボタン行の下の余白。ダイアログの下余白と合わせて約30px（Illustrator 標準のダイアログに合わせる） / bottom margin; with the dialog margin about 30px, like Illustrator's own dialogs */
    var BUTTON_ROW_SPACING = 10;   /* ボタンどうしの間隔 / spacing between buttons */
    var BUTTON_ROW_CENTER_MAX_WIDTH = 240; /* 右のボタンだけの行を中央に置く、ダイアログの内側の最大幅（px、左右の余白を除く）。広いダイアログは右揃え / max inner dialog width (px, margins excluded) that centers a right-only row; wider dialogs keep it right-aligned */

    /**
     * ダイアログ下部のボタン行を作る。
     * 通常は「左のグループ・伸びるスペーサー・右のグループ」、centered なら行そのものを左右中央に置く
     * @param {Window|Group|Panel} parent - 行を足す先（ふつうはダイアログ）
     * @param {Object} [rowOptions] - { centered: true } で左右中央に並べる
     * @returns {{rowGroup: Group, leftGroup: Group|null, rightGroup: Group|null}} 行と左右のグループ（centered のときは左右が null）
     */
    function addButtonRow(parent, rowOptions) {
        var isCentered = !!(rowOptions && rowOptions.centered);
        var btnRowGroup = parent.add("group");
        btnRowGroup.orientation = "row";
        btnRowGroup.margins = [0, BUTTON_ROW_TOP_MARGIN, 0, BUTTON_ROW_BOTTOM_MARGIN];
        btnRowGroup.spacing = BUTTON_ROW_SPACING;

        if (isCentered) {
            btnRowGroup.alignment = ["center", "bottom"];
            btnRowGroup.alignChildren = ["center", "center"];
            return { rowGroup: btnRowGroup, leftGroup: null, rightGroup: null };
        }

        btnRowGroup.alignment = ["fill", "bottom"];

        var btnLeftGroup = btnRowGroup.add("group");
        btnLeftGroup.alignChildren = ["left", "center"];
        btnLeftGroup.spacing = BUTTON_ROW_SPACING;

        /* 余りの幅を吸って、右のグループを右端に寄せる / Absorbs the extra width so the right group sits at the right edge */
        var spacer = btnRowGroup.add("group");
        spacer.alignment = ["fill", "fill"];
        spacer.minimumSize.width = 0;

        var btnRightGroup = btnRowGroup.add("group");
        btnRightGroup.alignChildren = ["right", "center"];
        btnRightGroup.spacing = BUTTON_ROW_SPACING;

        return { rowGroup: btnRowGroup, leftGroup: btnLeftGroup, rightGroup: btnRightGroup };
    }

    /**
     * 左のグループにボタンが無い（右のボタンだけの）行を、ダイアログの幅に合わせて揃える。
     * 内側の幅（左右の余白を除く）が BUTTON_ROW_CENTER_MAX_WIDTH 以下なら左右中央、それより広ければ右揃えのまま。
     * 幅はレイアウトが決まるまで分からないので、ダイアログを表示した時点（show イベント）で判定する。
     * ボタンをすべて足したあと、show() の前に呼ぶ。centered で作った行や、左にボタンがある行はそのまま
     * @param {{rowGroup: Group, leftGroup: Group|null, rightGroup: Group|null}} buttonRow - addButtonRow() の戻り値
     * @returns {void}
     */
    function alignRightOnlyButtonRow(buttonRow) {
        if (!buttonRow.leftGroup || buttonRow.leftGroup.children.length > 0) return;
        var dialogWindow = buttonRow.rowGroup.window;
        dialogWindow.addEventListener("show", function () {
            if (!buttonRow.leftGroup) return;
            var btnRowGroup = buttonRow.rowGroup;
            /* 行の幅＝ダイアログの内側の幅（左右の余白を除く）/ The row spans the dialog's inner width (margins excluded) */
            if (!btnRowGroup.size || btnRowGroup.size.width > BUTTON_ROW_CENTER_MAX_WIDTH) return;
            /* 左のグループとスペーサーを外し、右のグループだけを中央に置く / Drop the left group and the spacer so only the right group remains, centered */
            btnRowGroup.remove(buttonRow.leftGroup);
            btnRowGroup.remove(btnRowGroup.children[0]); /* 左のグループを外すと先頭はスペーサー / the spacer is first once the left group is gone */
            btnRowGroup.alignment = ["center", "bottom"];
            btnRowGroup.alignChildren = ["center", "center"];
            buttonRow.leftGroup = null;
            dialogWindow.layout.layout(true);
        });
    }

    // ボタン行（再利用パーツ）ここまで / End of the reusable button row

    /**
     * ショートカットに対応する記号を返す
     * command（Ctrl）＋Enter：改行、Shift＋Enter：強制改行、option（Alt）＋0〜2：検索結果（正規表現のときだけ）
     * @param {string} keyName - 押されたキー
     * @param {Object} keyboardState - ScriptUI.environment.keyboardState
     * @param {boolean} useRegex - 正規表現が ON か
     * @returns {string|null} 入れる記号。該当しなければ null
     */
    function getShortcutToken(keyName, keyboardState, useRegex) {
        if (keyName === "Enter") {
            if (keyboardState.metaKey || keyboardState.ctrlKey) return PARAGRAPH_BREAK_TOKEN;
            if (keyboardState.shiftKey) return LINE_BREAK_TOKEN;
            return null;
        }
        if (keyboardState.altKey && useRegex && (keyName === "0" || keyName === "1" || keyName === "2")) {
            return "\\" + keyName;
        }
        return null;
    }

    /**
     * 控えたカーソルの位置に記号を入れる（ボタン用）。位置が取れていなければ末尾に足す
     * @param {EditText} targetInput - 入れる先の入力欄
     * @param {string} insertedToken - 入れる記号
     * @param {Object|null} caretPosition - captureCaret() の結果
     * @returns {void}
     */
    function insertTokenAtCaret(targetInput, insertedToken, caretPosition) {
        var currentText = targetInput.text;
        if (caretPosition && caretPosition.input === targetInput && caretPosition.start + caretPosition.length <= currentText.length) {
            targetInput.text = currentText.substring(0, caretPosition.start) + insertedToken + currentText.substring(caretPosition.start + caretPosition.length);
        } else {
            targetInput.text = currentText + insertedToken;
        }
    }

    /**
     * 入力欄のカーソル位置を読む。目印の文字を選択範囲に差し込んで位置を測り、元の文字列に戻す
     * （ScriptUI にはカーソル位置を返すプロパティが無いため）
     * @param {EditText} targetInput - 対象の入力欄（カーソルがあるうちに呼ぶ）
     * @returns {Object|null} { input: EditText, start: number, length: number }。読めなければ null
     */
    function captureCaret(targetInput) {
        var CARET_MARKER = "\u0001";
        var originalText = targetInput.text;
        var selectedLength = targetInput.textselection.length;
        targetInput.textselection = CARET_MARKER;
        var markerIndex = targetInput.text.indexOf(CARET_MARKER);
        targetInput.text = originalText;
        /* カーソルを失った入力欄では目印が先頭に入るので、先頭は信用しない（末尾に足す側に倒す）
           A field that lost its caret puts the marker at the start, so treat the start as unknown */
        if (markerIndex < 0 || (markerIndex === 0 && originalText.length > 0)) return null;
        return { input: targetInput, start: markerIndex, length: selectedLength };
    }

    /**
     * 対象のテキストフレームを複製して削除・置換し、元を一時的に隠す（プレビュー用）
     * 表示中でロックされていない独立フレームのうち、一致があるものだけを扱う
     * @param {TextFrame[]} targetFrames - 対象のテキストフレーム
     * @param {Object[]} searchEntries - getSearchEntries() の結果
     * @returns {Object[]} { originalFrame: TextFrame, previewFrame: TextFrame, isOriginalHidden: boolean } の配列
     */
    function createPreview(targetFrames, searchEntries) {
        var previewRecords = [];
        var visibleOnly = { includeHidden: false, includeLocked: false };
        var ignoredCounts = createZeroCounts(searchEntries.length);
        for (var i = 0; i < targetFrames.length; i++) {
            var textFrame = targetFrames[i];
            if (!isSearchableItem(textFrame, visibleOnly) || !isStandaloneFrame(textFrame)) continue;
            if (!hasAnyMatch(textFrame.contents, searchEntries)) continue;
            /* 編集できないテキストは例外になるのでスキップ / Skip text that throws because it cannot be edited */
            try {
                /* 複製は元を隠す前に作る（hidden を引き継ぐため）/ Duplicate before hiding, as duplicates inherit hidden */
                var previewRecord = { originalFrame: textFrame, previewFrame: textFrame.duplicate(textFrame, ElementPlacement.PLACEBEFORE), isOriginalHidden: false };
                previewRecords.push(previewRecord);
                textFrame.hidden = true;
                previewRecord.isOriginalHidden = true;
                replacePatternsInFrame(previewRecord.previewFrame, searchEntries, ignoredCounts);
            } catch (e) {}
        }
        app.redraw();
        return previewRecords;
    }

    /**
     * プレビューの複製を消し、隠した元のフレームを表示に戻す
     * @param {Object[]} previewRecords - createPreview() の結果
     * @returns {void}
     */
    function removePreview(previewRecords) {
        for (var i = previewRecords.length - 1; i >= 0; i--) {
            previewRecords[i].previewFrame.remove();
            if (previewRecords[i].isOriginalHidden) previewRecords[i].originalFrame.hidden = false;
        }
        app.redraw();
    }

    /**
     * 文字列にいずれかのパターンが一致するか判定する
     * @param {string} text - 検索する文字列
     * @param {Object[]} searchEntries - getSearchEntries() の結果
     * @returns {boolean} 1つでも一致すれば true
     */
    function hasAnyMatch(text, searchEntries) {
        for (var i = 0; i < searchEntries.length; i++) {
            if (findMatches(text, searchEntries[i].pattern).length > 0) return true;
        }
        return false;
    }

    /**
     * 入力から検索パターンを作る
     * @param {string} searchText - 入力された文字列
     * @param {boolean} useRegex - 正規表現として扱うか
     * @param {boolean} matchCase - 大文字と小文字を区別するか
     * @returns {RegExp|null|boolean} パターン。空欄なら null、正規表現が誤っていれば false
     */
    function createSearchPattern(searchText, useRegex, matchCase) {
        if (searchText === "") return null;
        var patternSource = useRegex ? convertBreakTokensInRegex(searchText) : expandBreakTokens(searchText).replace(/[.*+?^${}()|[\]\\\/]/g, "\\$&");
        /* 誤った正規表現は new RegExp() が例外を出す / new RegExp() throws on an invalid pattern */
        try {
            return new RegExp(patternSource, matchCase ? "gm" : "gmi");
        } catch (e) {
            return false;
        }
    }

    /**
     * 改行の記号を文字に置き換える（\n は改行 \r、@# は強制改行 \x03）
     * @param {string} text - 入力された文字列
     * @returns {string} 置き換えた文字列
     */
    function expandBreakTokens(text) {
        return text.split(PARAGRAPH_BREAK_TOKEN).join("\r").split(LINE_BREAK_TOKEN).join("\x03");
    }

    /**
     * 正規表現の中の改行の記号を、Illustrator の改行文字に一致する書き方にする（\\ はそのまま）
     * @param {string} regexSource - 入力された正規表現
     * @returns {string} 置き換えた正規表現
     */
    function convertBreakTokensInRegex(regexSource) {
        return regexSource.replace(/\\\\|\\n|@#/g, function (token) {
            if (token === PARAGRAPH_BREAK_TOKEN) return "\\r";
            if (token === LINE_BREAK_TOKEN) return "\\x03";
            return token;
        });
    }

    /**
     * 入力から有効な検索パターンを上から順に集める
     * @param {string[]} searchTexts - 入力欄の文字列
     * @param {string[]} replaceTexts - 置換欄の文字列（空欄は削除）
     * @param {boolean} useRegex - 正規表現として扱うか
     * @param {boolean} matchCase - 大文字と小文字を区別するか
     * @param {boolean} deleteEmptyLines - 削除で空になった段落の改行も削除するか
     * @returns {Object[]} { text: string, pattern: RegExp, replaceText: string, useRegex: boolean, deleteEmptyLines: boolean } の配列
     */
    function getSearchEntries(searchTexts, replaceTexts, useRegex, matchCase, deleteEmptyLines) {
        var searchEntries = [];
        for (var i = 0; i < searchTexts.length; i++) {
            var searchPattern = createSearchPattern(searchTexts[i], useRegex, matchCase);
            if (searchPattern) {
                /* 正規表現の置換欄は getReplacementText() で改行の記号を展開する / Regex replacements expand the break tokens in getReplacementText() */
                var replaceText = replaceTexts[i] || "";
                searchEntries.push({ text: searchTexts[i], pattern: searchPattern, replaceText: useRegex ? replaceText : expandBreakTokens(replaceText), useRegex: useRegex, deleteEmptyLines: deleteEmptyLines });
            }
        }
        return searchEntries;
    }

    /**
     * テキストフレームの内容を配列にする
     * @param {TextFrame[]} textFrames - 対象のテキストフレーム
     * @returns {string[]} 各フレームの contents
     */
    function getFrameContents(textFrames) {
        var frameContents = [];
        for (var i = 0; i < textFrames.length; i++) {
            frameContents.push(textFrames[i].contents);
        }
        return frameContents;
    }

    /**
     * 文字列の配列に含まれる一致数の合計を返す
     * @param {string[]} frameContents - 各フレームの contents
     * @param {RegExp} searchPattern - 検索パターン
     * @returns {number} 一致数の合計
     */
    function countMatches(frameContents, searchPattern) {
        var matchCount = 0;
        for (var i = 0; i < frameContents.length; i++) {
            matchCount += findMatches(frameContents[i], searchPattern).length;
        }
        return matchCount;
    }

    /**
     * 対象範囲のテキストフレームを集める
     * @param {Document} doc - 対象ドキュメント
     * @param {string} scope - "selection" / "artboard" / "document"
     * @param {Object} layerOptions - { includeHidden: boolean, includeLocked: boolean }
     * @param {PageItem[]} selectedItems - 実行時に選択していたアイテム
     * @returns {TextFrame[]} テキストフレームの配列
     */
    function collectTargetFrames(doc, scope, layerOptions, selectedItems) {
        return collectScopedItems(doc.textFrames, "TextFrame", doc, scope, layerOptions, selectedItems);
    }

    /**
     * 対象範囲にあるアイテムを、指定した型だけ集める
     * @param {Object} documentItems - ドキュメント全体のコレクション（doc.textFrames / doc.symbolItems）
     * @param {string} typename - 集める型名
     * @param {Document} doc - 対象ドキュメント
     * @param {string} scope - "selection" / "artboard" / "document"
     * @param {Object} layerOptions - { includeHidden: boolean, includeLocked: boolean }
     * @param {PageItem[]} selectedItems - 実行時に選択していたアイテム
     * @returns {PageItem[]} アイテムの配列
     */
    function collectScopedItems(documentItems, typename, doc, scope, layerOptions, selectedItems) {
        var candidateItems = [];
        var i;

        if (scope === "selection") {
            for (i = 0; i < selectedItems.length; i++) {
                collectItemsOfType(selectedItems[i], typename, candidateItems);
            }
        } else {
            var artboardRect = null;
            if (scope === "artboard") {
                artboardRect = doc.artboards[doc.artboards.getActiveArtboardIndex()].artboardRect;
            }
            for (i = 0; i < documentItems.length; i++) {
                if (!artboardRect || overlapsArtboard(documentItems[i], artboardRect)) {
                    candidateItems.push(documentItems[i]);
                }
            }
        }

        var scopedItems = [];
        for (i = 0; i < candidateItems.length; i++) {
            if (isSearchableItem(candidateItems[i], layerOptions)) scopedItems.push(candidateItems[i]);
        }
        return scopedItems;
    }

    /**
     * 非表示・ロックの扱いに照らして、検索対象にできるか判定する（自身と親のグループ・レイヤーを見る）
     * @param {PageItem} item - 判定するアイテム
     * @param {Object} layerOptions - { includeHidden: boolean, includeLocked: boolean }
     * @returns {boolean} 対象にできれば true
     */
    function isSearchableItem(item, layerOptions) {
        for (var ancestorNode = item; ancestorNode && ancestorNode.typename !== "Document"; ancestorNode = ancestorNode.parent) {
            var isHidden = (ancestorNode.typename === "Layer") ? !ancestorNode.visible : ancestorNode.hidden;
            if (isHidden && !layerOptions.includeHidden) return false;
            if (ancestorNode.locked && !layerOptions.includeLocked) return false;
        }
        return true;
    }

    /**
     * 自身と親の非表示・ロックを一時的に解除し、元に戻すための記録を追加する
     * @param {PageItem} item - 対象のアイテム
     * @param {Object[]} stateRecords - { target, propertyName, originalValue } の追加先
     * @returns {void}
     */
    function unlockAndRevealAncestors(item, stateRecords) {
        for (var ancestorNode = item; ancestorNode && ancestorNode.typename !== "Document"; ancestorNode = ancestorNode.parent) {
            /* ロック中は表示を切り替えられないことがあるので、先にロックを外す / Unlock first, as a locked item may refuse to change visibility */
            if (ancestorNode.locked) {
                stateRecords.push({ target: ancestorNode, propertyName: "locked", originalValue: true });
                ancestorNode.locked = false;
            }
            if (ancestorNode.typename === "Layer") {
                if (!ancestorNode.visible) {
                    stateRecords.push({ target: ancestorNode, propertyName: "visible", originalValue: false });
                    ancestorNode.visible = true;
                }
            } else if (ancestorNode.hidden) {
                stateRecords.push({ target: ancestorNode, propertyName: "hidden", originalValue: true });
                ancestorNode.hidden = false;
            }
        }
    }

    /**
     * 一時的に変えた非表示・ロックを元に戻す（変えたときと逆の順に）
     * @param {Object[]} stateRecords - unlockAndRevealAncestors() の記録
     * @returns {void}
     */
    function restoreItemStates(stateRecords) {
        for (var i = stateRecords.length - 1; i >= 0; i--) {
            stateRecords[i].target[stateRecords[i].propertyName] = stateRecords[i].originalValue;
        }
    }

    /**
     * 自身と親の非表示・ロックを一時的に解除して編集し、終わったら元に戻す
     * 編集できないテキスト（テンプレートレイヤーなど）は例外になるので、そのアイテムは飛ばす
     * @param {PageItem} item - 対象のアイテム
     * @param {Function} editItem - (stateRecords) を受け取る編集処理。消したアイテムの記録は stateRecords から除く
     * @returns {*} editItem の戻り値。例外のときは false
     */
    function editWithAncestorsReleased(item, editItem) {
        var stateRecords = [];
        try {
            unlockAndRevealAncestors(item, stateRecords);
            return editItem(stateRecords);
        } catch (e) {
            return false;
        } finally {
            restoreItemStates(stateRecords);
        }
    }

    /**
     * アイテム内から指定した型のアイテムを再帰的に集める（グループ内も含む）
     * @param {PageItem} item - 調べるアイテム
     * @param {string} typename - 集める型名
     * @param {PageItem[]} foundItems - 見つかったアイテムの追加先
     * @returns {void}
     */
    function collectItemsOfType(item, typename, foundItems) {
        if (item.typename === typename) {
            foundItems.push(item);
        } else if (item.typename === "GroupItem") {
            for (var i = 0; i < item.pageItems.length; i++) {
                collectItemsOfType(item.pageItems[i], typename, foundItems);
            }
        }
    }

    /**
     * アイテムがアートボードに重なっているか判定する
     * @param {PageItem} item - 判定するアイテム
     * @param {number[]} artboardRect - アートボードの [左, 上, 右, 下]
     * @returns {boolean} 一部でも重なっていれば true
     */
    function overlapsArtboard(item, artboardRect) {
        var itemBounds = item.visibleBounds;
        return itemBounds[2] > artboardRect[0] &&
            itemBounds[0] < artboardRect[2] &&
            itemBounds[3] < artboardRect[1] &&
            itemBounds[1] > artboardRect[3];
    }

    /**
     * テキストフレームの一致箇所をすべて削除・置換する（パターンは配列の順に処理）
     * @param {TextFrame[]} targetFrames - 対象のテキストフレーム
     * @param {Object[]} searchEntries - getSearchEntries() の結果
     * @param {boolean} deleteEmptyFrames - 削除で空になった独立フレームを削除するか
     * @returns {Object} { processedCounts: number[]（欄ごとの削除・置換数）, changedCount: number, deletedFrameCount: number, deletedFrames: TextFrame[]（削除したフレームの参照） }
     */
    function replaceTextInFrames(targetFrames, searchEntries, deleteEmptyFrames) {
        var replaceResult = { processedCounts: createZeroCounts(searchEntries.length), changedCount: 0, deletedFrameCount: 0, deletedFrames: [] };
        for (var i = 0; i < targetFrames.length; i++) {
            editWithAncestorsReleased(targetFrames[i], function (stateRecords) {
                var textFrame = targetFrames[i];
                if (!replacePatternsInFrame(textFrame, searchEntries, replaceResult.processedCounts)) return;
                replaceResult.changedCount++;
                if (deleteEmptyFrames && textFrame.contents === "" && isStandaloneFrame(textFrame)) {
                    /* 消したフレーム自身は状態を戻さない / Do not restore the deleted frame itself */
                    removeRecordsFor(stateRecords, textFrame);
                    replaceResult.deletedFrames.push(textFrame);
                    textFrame.remove();
                    replaceResult.deletedFrameCount++;
                }
            });
        }
        return replaceResult;
    }

    /**
     * 欄ごとの数を数えるための、0 を並べた配列を作る
     * @param {number} length - 欄の数
     * @returns {number[]} 0 の配列
     */
    function createZeroCounts(length) {
        var zeroCounts = [];
        for (var i = 0; i < length; i++) zeroCounts.push(0);
        return zeroCounts;
    }

    /**
     * 1つのテキストフレームで、パターンを配列の順にすべて削除・置換する
     * @param {TextFrame} textFrame - 対象のテキストフレーム
     * @param {Object[]} searchEntries - getSearchEntries() の結果
     * @param {number[]} processedCounts - 欄ごとの削除・置換数（加算していく）
     * @returns {boolean} 1か所でも削除・置換したら true
     */
    function replacePatternsInFrame(textFrame, searchEntries, processedCounts) {
        var isChanged = false;
        for (var i = 0; i < searchEntries.length; i++) {
            /* 前の削除・置換で内容が変わるので、毎回 contents から探し直す / Search again each time, as earlier edits change the contents */
            var matches = findMatches(textFrame.contents, searchEntries[i].pattern);
            if (matches.length === 0) continue;
            replaceMatchesKeepingFormat(textFrame, matches, searchEntries[i]);
            processedCounts[i] += matches.length;
            isChanged = true;
        }
        return isChanged;
    }

    /**
     * スレッドテキスト（連結）に属さない独立したフレームか判定する
     * @param {TextFrame} textFrame - 判定するテキストフレーム
     * @returns {boolean} 独立したフレームなら true
     */
    function isStandaloneFrame(textFrame) {
        if (textFrame.kind === TextType.POINTTEXT) return true;
        return !textFrame.nextFrame && !textFrame.previousFrame;
    }

    /**
     * 指定したオブジェクトの記録を取り除く（配列そのものを書き換える）
     * @param {Object[]} stateRecords - unlockAndRevealAncestors() の記録
     * @param {PageItem} removedItem - 記録を除くオブジェクト
     * @returns {void}
     */
    function removeRecordsFor(stateRecords, removedItem) {
        for (var i = stateRecords.length - 1; i >= 0; i--) {
            if (stateRecords[i].target === removedItem) stateRecords.splice(i, 1);
        }
    }

    /**
     * 文字列中の一致箇所を左から集める（長さ0の一致は除く）
     * @param {string} text - 検索する文字列
     * @param {RegExp} searchPattern - g フラグ付きの検索パターン
     * @returns {Object[]} { start: number, length: number, captures: Array } の配列（昇順）
     */
    function findMatches(text, searchPattern) {
        var matches = [];
        var regexMatch;
        searchPattern.lastIndex = 0;
        while ((regexMatch = searchPattern.exec(text)) !== null) {
            if (regexMatch[0].length === 0) {
                /* 長さ0の一致で止まらないよう1文字進める / Step past empty matches to avoid an endless loop */
                searchPattern.lastIndex++;
                continue;
            }
            matches.push({ start: regexMatch.index, length: regexMatch[0].length, captures: regexMatch });
        }
        return matches;
    }

    /**
     * 一致箇所を右から削除・置換する（contents を書き戻さないので文字ごとの書式が残る）
     * 置換は先頭の1文字だけ残して contents を差し替えるので、置換後の文字はその文字の書式になる
     * 空になった行の削除が有効なら、削除で空になった段落の改行もあわせて削除する
     * @param {TextFrame} textFrame - 対象のテキストフレーム
     * @param {Object[]} matches - findMatches() の結果（昇順）
     * @param {Object} searchEntry - getSearchEntries() の要素
     * @returns {void}
     */
    function replaceMatchesKeepingFormat(textFrame, matches, searchEntry) {
        var frameCharacters = textFrame.characters;
        var newTexts = [];
        for (var i = 0; i < matches.length; i++) {
            newTexts.push(getReplacementText(searchEntry, matches[i].captures));
        }
        /* 削除する改行（降順）。一致箇所とは重ならない / Breaks to remove, in descending order; they never overlap a match */
        var breakIndices = searchEntry.deleteEmptyLines ? findEmptiedLineBreaks(textFrame.contents, matches, newTexts) : [];
        var breakCursor = 0;
        for (var k = matches.length - 1; k >= 0; k--) {
            /* 右から処理するので、この一致より後ろの改行を先に消す / Working from the right, remove the breaks after this match first */
            while (breakCursor < breakIndices.length && breakIndices[breakCursor] > matches[k].start) {
                frameCharacters[breakIndices[breakCursor]].remove();
                breakCursor++;
            }
            var keptCount = (newTexts[k] === "") ? 0 : 1;
            for (var j = matches[k].start + matches[k].length - 1; j >= matches[k].start + keptCount; j--) {
                frameCharacters[j].remove();
            }
            if (keptCount > 0) frameCharacters[matches[k].start].contents = newTexts[k];
        }
        for (; breakCursor < breakIndices.length; breakCursor++) {
            frameCharacters[breakIndices[breakCursor]].remove();
        }
    }

    /**
     * テキストフレームの指定した範囲の文字を選択する
     * @param {TextFrame} textFrame - 対象のテキストフレーム
     * @param {number} start - 先頭の文字の番号（contents と1対1）
     * @param {number} length - 文字数
     * @returns {void}
     */
    function selectTextSpan(textFrame, start, length) {
        /* characterOffset への代入は範囲が崩れるので、先頭の1文字から length を伸ばす（実測済み）
           Assigning characterOffset breaks the range, so extend the length from the first character (tested) */
        var textSpan = textFrame.characters[start];
        textSpan.length = length;
        textSpan.select();
    }

    /**
     * アイテムが画面に大きく収まるように、表示倍率と中心を変える（MATCH_ZOOM_MAX を超えては拡大しない）
     * @param {Document} doc - 対象ドキュメント
     * @param {PageItem} item - 表示するアイテム
     * @returns {void}
     */
    function zoomToItem(doc, item) {
        var activeView = doc.activeView;
        var itemBounds = item.visibleBounds;
        var itemWidth = Math.max(itemBounds[2] - itemBounds[0], 1);
        var itemHeight = Math.max(itemBounds[1] - itemBounds[3], 1);
        /* 画面の大きさ（画面上の長さ）は、見えている範囲に今の倍率を掛けて求める / The window size in screen units is the visible area times the current zoom */
        var viewBounds = activeView.bounds;
        var windowWidth = (viewBounds[2] - viewBounds[0]) * activeView.zoom;
        var windowHeight = (viewBounds[1] - viewBounds[3]) * activeView.zoom;
        var fitZoom = Math.min(windowWidth / itemWidth, windowHeight / itemHeight) * MATCH_ZOOM_FILL_RATIO;
        activeView.zoom = Math.min(fitZoom, MATCH_ZOOM_MAX);
        activeView.centerPoint = [(itemBounds[0] + itemBounds[2]) / 2, (itemBounds[1] + itemBounds[3]) / 2];
    }

    /**
     * 削除で空になる段落を探し、あわせて消す改行の位置を返す
     * 空になった段落は後ろの改行を消す。末尾から続けて空になった段落は、後ろに改行が無いので前の改行を消す
     * 元から空の段落は対象にしない
     * @param {string} text - 削除・置換する前の contents
     * @param {Object[]} matches - findMatches() の結果（昇順）
     * @param {string[]} newTexts - 一致箇所ごとの置換後の文字列（空なら削除）
     * @returns {number[]} 消す改行の位置（降順）
     */
    function findEmptiedLineBreaks(text, matches, newTexts) {
        /* 文字ごとに、一致箇所に含まれるか / Whether each character is inside a match */
        var isMatched = [];
        /* 置換で文字が入る位置 / Positions where a replacement puts text */
        var hasNewText = [];
        for (var i = 0; i < matches.length; i++) {
            for (var j = matches[i].start; j < matches[i].start + matches[i].length; j++) isMatched[j] = true;
            if (newTexts[i] !== "") hasNewText[matches[i].start] = true;
        }
        /* 残る改行で区切った段落ごとに、元の文字があったか・結果が空か / Per paragraph split by the surviving breaks: had text, and ends up empty */
        var lineRecords = [];
        var currentLine = { previousBreak: -1, nextBreak: -1, hadText: false, isEmptied: true };
        for (var k = 0; k < text.length; k++) {
            if (text.charAt(k) === "\r" && !isMatched[k]) {
                currentLine.nextBreak = k;
                lineRecords.push(currentLine);
                currentLine = { previousBreak: k, nextBreak: -1, hadText: false, isEmptied: true };
                continue;
            }
            currentLine.hadText = true;
            if (!isMatched[k] || hasNewText[k]) currentLine.isEmptied = false;
        }
        lineRecords.push(currentLine);

        var breakIndices = [];
        /* 末尾から続く空になった段落か / Whether the paragraphs so far, from the end, were all emptied */
        var isTrailing = true;
        for (var lineIndex = lineRecords.length - 1; lineIndex >= 0; lineIndex--) {
            var lineRecord = lineRecords[lineIndex];
            if (!lineRecord.hadText || !lineRecord.isEmptied) {
                isTrailing = false;
                continue;
            }
            var breakIndex = isTrailing ? lineRecord.previousBreak : lineRecord.nextBreak;
            if (breakIndex >= 0) breakIndices.push(breakIndex);
        }
        return breakIndices;
    }

    /**
     * 一致箇所の置換後の文字列を返す（正規表現のときは $$ / $& / $1〜$99 と \\ / \0〜\9 / \n / @# を展開する）
     * @param {Object} searchEntry - getSearchEntries() の要素
     * @param {Array} captures - exec() の結果
     * @returns {string} 置換後の文字列。空なら削除
     */
    function getReplacementText(searchEntry, captures) {
        if (!searchEntry.useRegex) return searchEntry.replaceText;
        return searchEntry.replaceText.replace(/\$(\$|&|\d\d?)|\\([\\\dn])|@#/g, function (token, dollarName, backslashName) {
            if (token === LINE_BREAK_TOKEN) return "\x03";
            /* \\ は \ そのもの、\n は改行、\0 は一致全体、\1〜\9 はグループ / \\ is a backslash, \n a paragraph break, \0 the whole match, \1-\9 the groups */
            if (backslashName) {
                if (backslashName === "\\") return "\\";
                if (backslashName === "n") return "\r";
                var backslashIndex = parseInt(backslashName, 10);
                if (backslashIndex >= captures.length) return token;
                return captures[backslashIndex] || "";
            }
            if (dollarName === "$") return "$";
            if (dollarName === "&") return captures[0];
            var groupIndex = parseInt(dollarName, 10);
            /* $12 でグループが足りなければ $1 と「2」として扱う / Read $12 as $1 followed by "2" when there are fewer groups */
            if (dollarName.length === 2 && groupIndex >= captures.length) {
                groupIndex = parseInt(dollarName.charAt(0), 10);
                if (groupIndex === 0 || groupIndex >= captures.length) return token;
                return (captures[groupIndex] || "") + dollarName.charAt(1);
            }
            if (groupIndex === 0 || groupIndex >= captures.length) return token;
            return captures[groupIndex] || "";
        });
    }

    // =========================================
    // 変換と整形 / Conversions and cleanup
    // =========================================
    /* 変換関数は TextProcessingPalette.jsx から移植 / Converters ported from TextProcessingPalette.jsx */

    /**
     * 変換の名前に対応する変換関数を返す
     * @param {string} conversionKey - LABELS.button のキー（caseUpper・removeTabs など）
     * @returns {Function|null} 文字列を受け取り、変換した文字列を返す関数。該当しなければ null
     */
    function getTextConverter(conversionKey) {
        switch (conversionKey) {
            case "caseUpper": return function (text) { return text.toUpperCase(); };
            case "caseLower": return function (text) { return text.toLowerCase(); };
            case "caseWord": return capitalizeEachWord;
            case "caseSentence": return toSentenceCase;
            case "caseTitle": return toTitleCase;
            /* かな変換は半角カナも受け付けるため、いったん全角カナへ寄せてから変換する / Kana conversions accept halfwidth kana, so normalize to fullwidth first */
            case "toHiragana": return function (text) { return toHiraganaText(toFullWidthKanaText(text)); };
            case "toKatakana": return function (text) { return toKatakanaText(toFullWidthKanaText(text)); };
            case "toHalfKana": return function (text) { return toHalfWidthKanaText(toKatakanaText(text)); };
            /* 数字変換は漢数字も受け付けるため、いったん算用数字へ寄せてから変換する / Digit conversions accept kanji numerals, so normalize to Arabic first */
            case "toHalfDigit": return function (text) { return toHalfWidthDigitText(toArabicNumeralText(text)); };
            case "toFullDigit": return function (text) { return toFullWidthDigitText(toArabicNumeralText(text)); };
            /* 整形 / Cleanup */
            case "removeTabs": return function (text) { return text.replace(/\t/g, ""); };
            case "tabsToSpaces": return function (text) { return text.replace(/\t/g, " "); };
            case "trimSpaces": return trimLineSpacesText;
            case "cjkLatinSpaces": return removeCjkLatinSpacesText;
            case "collapseSpaces": return collapseSpacesText;
            /* 先に連続を1つにまとめる（和欧間は前後の文字で判断するので、連続したままだと英単語間も消える）
               Collapse first; removing CJK/Latin spaces looks at neighbors, so runs of spaces would vanish between Latin words */
            case "cleanupSpaces": return function (text) { return removeCjkLatinSpacesText(collapseSpacesText(trimLineSpacesText(text))); };
            case "spaceAfterPunct": return function (text) { return text.replace(/([.,])(?=[^\s\d.,])/g, "$1 "); };
            case "bulletList": return removeBulletMarkersText;
            case "numberList": return removeNumberMarkersText;
        }
        return null;
    }

    /**
     * 単語の先頭のみ大文字。事前に小文字化しているので、すべて大文字の語も Negotiable のようになる
     * @param {string} text - 変換する文字列
     * @returns {string} 変換した文字列
     */
    function capitalizeEachWord(text) {
        return String(text).toLowerCase().replace(/\b([a-z])/g, function (matched, initial) {
            return initial.toUpperCase();
        });
    }

    /**
     * 文頭のみ大文字。文区切りが無い（英単語が1つだけの）場合も先頭を大文字化する
     * @param {string} text - 変換する文字列
     * @returns {string} 変換した文字列
     */
    function toSentenceCase(text) {
        return String(text).toLowerCase().replace(/(^|[\.\!\?]\s+|[\r\n]+)([a-z])/g,
            function (matched, prefix, initial) { return prefix + initial.toUpperCase(); });
    }

    /**
     * 英語タイトル形式（冠詞・前置詞などは小文字 / John Gruber の Title Caps 移植）
     * @param {string} text - 変換する文字列
     * @returns {string} 変換した文字列
     */
    function toTitleCase(text) {
        var smallWords = "(a|abaft|aboard|about|above|absent|across|afore|after|against|along|alongside|amid|amidst|among|amongst|an|and|apropos|around|as|aside|astride|at|athwart|atop|barring|before|behind|below|beneath|beside|besides|between|betwixt|beyond|but|by|circa|concerning|despite|down|during|except|excluding|failing|following|for|from|given|in|including|inside|into|lest|like|mid|midst|minus|modulo|near|next|nor|notwithstanding|of|off|on|onto|opposite|or|out|outside|over|pace|per|plus|pro|qua|regarding|round|sans|save|than|that|the|through|throughout|till|times|to|toward|towards|under|underneath|unlike|until|unto|up|upon|versus|via|vice|with|within|without|worth|v[.]?|via|vs[.]?)";
        var punctuation = "([!\"#$%&'()*+,./:;<=>?@[\\\\\\]^_`{|}~-]*)";

        function toLowerWord(word) { return word.toLowerCase(); }
        function capitalizeWord(word) { return word.substr(0, 1).toUpperCase() + word.substr(1); }

        var titleText = String(text);
        var sentenceSplitter = /[:.;?!] |(?: |^)[\"Ò]/g;
        var segments = [];
        var segmentStart = 0;
        while (true) {
            var splitMatch = sentenceSplitter.exec(titleText);
            segments.push(
                titleText.substring(segmentStart, splitMatch ? splitMatch.index : titleText.length)
                    .replace(/\b([A-Za-z][a-z.'Õ]*)\b/g, function (matched) {
                        return /[A-Za-z]\.[A-Za-z]/.test(matched) ? matched : capitalizeWord(matched);
                    })
                    .replace(RegExp("\\b" + smallWords + "\\b", "ig"), toLowerWord)
                    .replace(RegExp("^" + punctuation + smallWords + "\\b", "ig"), function (matched, leadingPunct, word) {
                        return leadingPunct + capitalizeWord(word);
                    })
                    .replace(RegExp("\\b" + smallWords + punctuation + "$", "ig"), capitalizeWord)
            );
            segmentStart = sentenceSplitter.lastIndex;
            if (!splitMatch) break;
            segments.push(splitMatch[0]);
        }
        return segments.join("")
            .replace(/ V(s?)\. /ig, " v$1. ")
            .replace(/(['Õ])S\b/ig, "$1s")
            .replace(/\b(AT&T|Q&A)\b/ig, function (matched) { return matched.toUpperCase(); });
    }

    /**
     * 半角カナを全角カナへ変換した文字列を返す（濁点・半濁点の合成と約物も対象）
     * @param {string} text - 変換する文字列
     * @returns {string} 変換した文字列
     */
    function toFullWidthKanaText(text) {
        var halfKana = "ｦｧｨｩｪｫｬｭｮｯｰｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾅﾆﾇﾈﾉﾊﾋﾌﾍﾎﾏﾐﾑﾒﾓﾔﾕﾖﾗﾘﾙﾚﾛﾜﾝ";
        var fullKana = "ヲァィゥェォャュョッーアイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレロワン";
        /* 濁点・半濁点の合成対応表 / Voiced and semi-voiced combinations */
        var dakutenBase = "ｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾊﾋﾌﾍﾎｳ";
        var dakutenFull = "ガギグゲゴザジズゼゾダヂヅデドバビブベボヴ";
        var handakutenBase = "ﾊﾋﾌﾍﾎ";
        var handakutenFull = "パピプペポ";
        /* 単独で置き換える約物（濁点・半濁点・句読点・カギ括弧・中黒）/ Punctuation replaced on its own */
        var halfPunct = "ﾞﾟ｡｢｣､･";
        var fullPunct = "゛゜。「」、・";

        var convertedText = "";
        for (var i = 0; i < text.length; i++) {
            var currentChar = text.charAt(i);
            var nextChar = text.charAt(i + 1);

            /* 直後が濁点・半濁点なら合成して1文字にする / Combine with a following voiced or semi-voiced mark */
            var isDakuten = (nextChar === "ﾞ");
            var comboIndex = -1;
            if (isDakuten) comboIndex = dakutenBase.indexOf(currentChar);
            else if (nextChar === "ﾟ") comboIndex = handakutenBase.indexOf(currentChar);
            if (comboIndex >= 0) {
                convertedText += isDakuten ? dakutenFull.charAt(comboIndex) : handakutenFull.charAt(comboIndex);
                i++;
                continue;
            }

            var kanaIndex = halfKana.indexOf(currentChar);
            var punctIndex = halfPunct.indexOf(currentChar);
            if (kanaIndex >= 0) {
                convertedText += fullKana.charAt(kanaIndex);
            } else if (punctIndex >= 0) {
                convertedText += fullPunct.charAt(punctIndex);
            } else {
                convertedText += currentChar;
            }
        }
        return convertedText;
    }

    /**
     * 全角カタカナをひらがなへ変換した文字列を返す（長音記号「ー」はそのまま）
     * ァ〜ヴと踊り字ヽヾは 0x60 引くとひらがなになる。ヵヶは「ヶ月」などの用例を壊すため対象外
     * @param {string} text - 変換する文字列
     * @returns {string} 変換した文字列
     */
    function toHiraganaText(text) {
        return text.replace(/[ァ-ヴヽヾ]/g, function (katakanaChar) {
            return String.fromCharCode(katakanaChar.charCodeAt(0) - 0x60);
        });
    }

    /**
     * ひらがなを全角カタカナへ変換した文字列を返す（長音記号「ー」はそのまま）
     * ぁ〜ゖと踊り字ゝゞは 0x60 足すとカタカナになる
     * @param {string} text - 変換する文字列
     * @returns {string} 変換した文字列
     */
    function toKatakanaText(text) {
        return text.replace(/[ぁ-ゖゝゞ]/g, function (hiraganaChar) {
            return String.fromCharCode(hiraganaChar.charCodeAt(0) + 0x60);
        });
    }

    /**
     * 全角カタカナを半角カナへ変換した文字列を返す（濁点・半濁点は2文字に分解、約物も対象）
     * @param {string} text - 変換する文字列
     * @returns {string} 変換した文字列
     */
    function toHalfWidthKanaText(text) {
        var fullKana = "ヲァィゥェォャュョッーアイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレロワン";
        var halfKana = "ｦｧｨｩｪｫｬｭｮｯｰｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾅﾆﾇﾈﾉﾊﾋﾌﾍﾎﾏﾐﾑﾒﾓﾔﾕﾖﾗﾘﾙﾚﾛﾜﾝ";
        /* 濁点・半濁点つきの文字を「素の半角カナ＋濁点」へ分解する対応表 / Split voiced characters into base kana and mark */
        var dakutenFull = "ガギグゲゴザジズゼゾダヂヅデドバビブベボヴ";
        var dakutenBase = "ｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾊﾋﾌﾍﾎｳ";
        var handakutenFull = "パピプペポ";
        var handakutenBase = "ﾊﾋﾌﾍﾎ";
        /* 単独で置き換える約物（濁点・半濁点・句読点・カギ括弧・中黒）/ Punctuation replaced on its own */
        var fullPunct = "゛゜。「」、・";
        var halfPunct = "ﾞﾟ｡｢｣､･";

        var convertedText = "";
        for (var i = 0; i < text.length; i++) {
            var currentChar = text.charAt(i);
            var dakutenIndex = dakutenFull.indexOf(currentChar);
            var handakutenIndex = handakutenFull.indexOf(currentChar);
            var kanaIndex = fullKana.indexOf(currentChar);
            var punctIndex = fullPunct.indexOf(currentChar);

            if (dakutenIndex >= 0) {
                convertedText += dakutenBase.charAt(dakutenIndex) + "ﾞ";
            } else if (handakutenIndex >= 0) {
                convertedText += handakutenBase.charAt(handakutenIndex) + "ﾟ";
            } else if (kanaIndex >= 0) {
                convertedText += halfKana.charAt(kanaIndex);
            } else if (punctIndex >= 0) {
                convertedText += halfPunct.charAt(punctIndex);
            } else {
                convertedText += currentChar;
            }
        }
        return convertedText;
    }

    /**
     * 全角数字を半角数字へ変換した文字列を返す
     * @param {string} text - 変換する文字列
     * @returns {string} 変換した文字列
     */
    function toHalfWidthDigitText(text) {
        return text.replace(/[０-９]/g, function (digitChar) {
            return String.fromCharCode(digitChar.charCodeAt(0) - 0xFEE0);
        });
    }

    /**
     * 半角数字を全角数字へ変換した文字列を返す
     * @param {string} text - 変換する文字列
     * @returns {string} 変換した文字列
     */
    function toFullWidthDigitText(text) {
        return text.replace(/[0-9]/g, function (digitChar) {
            return String.fromCharCode(digitChar.charCodeAt(0) + 0xFEE0);
        });
    }

    /**
     * 漢数字を算用数字（半角）へ変換した文字列を返す。位取りなしの表記（二〇二六）と、位取りありの表記（三十一・千二百三十四）の両方に対応する
     * @param {string} text - 変換する文字列
     * @returns {string} 変換した文字列
     */
    function toArabicNumeralText(text) {
        var kanjiDigits = "〇一二三四五六七八九";
        return text.replace(/[〇零一二三四五六七八九十百千万億]+/g, function (kanjiRun) {
            /* 単位の文字を含まないときは1文字ずつ置き換える（二〇二六 → 2026）/ Without unit characters, replace digit by digit */
            if (!/[十百千万億]/.test(kanjiRun)) {
                return kanjiRun.replace(/./g, function (kanjiChar) {
                    return (kanjiChar === "零") ? "0" : String(kanjiDigits.indexOf(kanjiChar));
                });
            }

            /* 位取りありは、万・億でいったん確定させながら積み上げる（二万五千 → 25000）/ Accumulate, settling at 万 and 億 */
            var smallUnitValues = { "十": 10, "百": 100, "千": 1000 };
            var largeUnitValues = { "万": 10000, "億": 100000000 };
            var totalValue = 0;
            var sectionValue = 0;
            var currentDigit = 0;
            for (var i = 0; i < kanjiRun.length; i++) {
                var kanjiChar = kanjiRun.charAt(i);
                if (smallUnitValues[kanjiChar]) {
                    sectionValue += (currentDigit || 1) * smallUnitValues[kanjiChar];
                    currentDigit = 0;
                } else if (largeUnitValues[kanjiChar]) {
                    totalValue += (sectionValue + currentDigit) * largeUnitValues[kanjiChar];
                    sectionValue = 0;
                    currentDigit = 0;
                } else {
                    /* 零は 0、それ以外は漢数字の値 / 零 is 0, others are their digit values */
                    currentDigit = (kanjiChar === "零") ? 0 : kanjiDigits.indexOf(kanjiChar);
                }
            }
            return String(totalValue + sectionValue + currentDigit);
        });
    }

    /**
     * 記号（スペース・アンダースコア・ハイフン）を別の記号に置き換える変換関数を作る
     * @param {string} beforeSymbol - 変換前（"space" / "underscore" / "hyphen"）。スペースは半角・全角の両方
     * @param {string} afterSymbol - 変換後（"space" / "underscore" / "hyphen"）
     * @returns {Function} 文字列を受け取り、変換した文字列を返す関数
     */
    function createSymbolConverter(beforeSymbol, afterSymbol) {
        var symbolPatterns = { space: /[ 　]/g, underscore: /_/g, hyphen: /-/g };
        var symbolTexts = { space: " ", underscore: "_", hyphen: "-" };
        return function (text) {
            return text.replace(symbolPatterns[beforeSymbol], symbolTexts[afterSymbol]);
        };
    }

    /**
     * 各段落の行頭・行末のスペースとタブを削除する
     * @param {string} text - 変換する文字列
     * @returns {string} 変換した文字列
     */
    function trimLineSpacesText(text) {
        var lines = text.split("\r");
        for (var i = 0; i < lines.length; i++) {
            lines[i] = lines[i].replace(/^[ \t　]+/, "").replace(/[ \t　]+$/, "");
        }
        return lines.join("\r");
    }

    /**
     * 連続する半角スペース・全角スペースを1つにまとめる
     * @param {string} text - 変換する文字列
     * @returns {string} 変換した文字列
     */
    function collapseSpacesText(text) {
        return text.replace(/ {2,}/g, " ").replace(/　{2,}/g, "　");
    }

    /**
     * 和欧間のスペースを削除する（前後がどちらも英数字のスペースは残す）
     * @param {string} text - 変換する文字列
     * @returns {string} 変換した文字列
     */
    function removeCjkLatinSpacesText(text) {
        return text.replace(/[ 　]/g, function (spaceChar, spaceIndex) {
            return (isLatinLetterOrDigit(text.charAt(spaceIndex - 1)) && isLatinLetterOrDigit(text.charAt(spaceIndex + 1))) ? spaceChar : "";
        });
    }

    /**
     * 半角の英字か数字か判定する
     * @param {string} character - 判定する1文字（空文字列なら false）
     * @returns {boolean} 半角の英数字なら true
     */
    function isLatinLetterOrDigit(character) {
        return /^[A-Za-z0-9]$/.test(character);
    }

    /**
     * 各段落の行頭から、最初に一致したパターンを1つだけ取り除く
     * @param {string} text - 変換する文字列
     * @param {RegExp[]} prefixPatterns - 行頭に一致させるパターン（先に書いたものを優先）
     * @returns {string} 変換した文字列
     */
    function removeLinePrefixText(text, prefixPatterns) {
        var lines = text.split("\r");
        for (var i = 0; i < lines.length; i++) {
            for (var j = 0; j < prefixPatterns.length; j++) {
                if (!prefixPatterns[j].test(lines[i])) continue;
                lines[i] = lines[i].replace(prefixPatterns[j], "");
                break;
            }
        }
        return lines.join("\r");
    }

    /**
     * 行頭の箇条書き記号を取り除く（「タブ＋記号＋タブ」の形と手入力の両方。「-」「*」は直後が空白のときだけ）
     * @param {string} text - 変換する文字列
     * @returns {string} 変換した文字列
     */
    function removeBulletMarkersText(text) {
        return removeLinePrefixText(text, [
            /^\t[・･·•◦●○◎□■▪◆◇✓–—\-\*]\t/,
            /^[\t 　]*(?:[・･·•◦●○◎□■▪◆◇✓]|[–—\-\*](?=[\t 　]))[\t 　]*/
        ]);
    }

    /**
     * 行頭の番号を取り除く（数字・全角数字・丸数字・英字・漢数字。区切りは . ． : ： |）
     * 「12.5」のように区切りの直後が数字なら本文とみなして残す
     * @param {string} text - 変換する文字列
     * @returns {string} 変換した文字列
     */
    function removeNumberMarkersText(text) {
        return removeLinePrefixText(text, [
            /^\t(?:[①-⑳❶-❿⓫-⓴]|[A-Za-z]+|[〇一二三四五六七八九十百千]+|[0-9０-９]+)[.．:：|]?\t/,
            /^[\t 　]*[①-⑳❶-❿⓫-⓴][\t 　]*/,
            /^[\t 　]*(?:[A-Za-z]+|[〇一二三四五六七八九十百千]+|[0-9０-９]+)[.．:：|][\t 　]+/,
            /^[\t 　]*[0-9０-９]+[.．](?![0-9０-９])[\t 　]*/
        ]);
    }

    /**
     * テキストフレームを変換する（非表示・ロックは処理のあいだだけ解除する）
     * @param {TextFrame[]} targetFrames - 対象のテキストフレーム
     * @param {Function} convertText - getTextConverter() の結果
     * @param {Function|null} prepareFrame - 変換の前に (textFrame) を受け取って行う処理（箇条書きのテキスト化など）。無ければ null
     * @returns {number} 変更したテキストフレームの数
     */
    function convertTextInFrames(targetFrames, convertText, prepareFrame) {
        var changedCount = 0;
        for (var i = 0; i < targetFrames.length; i++) {
            var isChanged = editWithAncestorsReleased(targetFrames[i], function () {
                if (prepareFrame) prepareFrame(targetFrames[i]);
                return convertFrameKeepingFormat(targetFrames[i], convertText);
            });
            if (isChanged) changedCount++;
        }
        return changedCount;
    }

    /**
     * テキストフレームの内容を変換し、変わった文字だけを書き換える（contents を書き戻さないので文字ごとの書式が残る）
     * 長さが変わらない変換は1文字ずつ、文字を削るだけ・足すだけの変換（スペースの削除・追加など）は変わる文字だけ、
     * それ以外（濁点の合成・漢数字など）は空白や改行で区切った語ごとに差し替える
     * @param {TextFrame} textFrame - 対象のテキストフレーム
     * @param {Function} convertText - getTextConverter() の結果
     * @returns {boolean} 書き換えたら true
     */
    function convertFrameKeepingFormat(textFrame, convertText) {
        var originalText = textFrame.contents;
        var convertedText = convertText(originalText);
        if (convertedText === originalText || originalText === "") return false;
        var frameCharacters = textFrame.characters;
        if (convertedText.length === originalText.length) {
            replaceDifferingPart(frameCharacters, 0, originalText, convertedText);
            return true;
        }
        var isShortened = convertedText.length < originalText.length;
        var matchedIndexes = isShortened ? matchSubsequence(convertedText, originalText) : matchSubsequence(originalText, convertedText);
        if (matchedIndexes) {
            if (isShortened) {
                removeUnkeptCharacters(frameCharacters, originalText.length, matchedIndexes);
            } else {
                insertAddedText(frameCharacters, originalText, convertedText, matchedIndexes);
            }
            return true;
        }
        /* 長さが変わる変換は前後の文字に左右されないので、語ごとに変換して右から差し替える
           Length-changing conversions do not depend on context, so convert word by word from the right */
        var wordMatches = findMatches(originalText, /[^\s\x03]+/g);
        for (var i = wordMatches.length - 1; i >= 0; i--) {
            var originalWord = wordMatches[i].captures[0];
            var convertedWord = convertText(originalWord);
            if (convertedWord !== originalWord) replaceDifferingPart(frameCharacters, wordMatches[i].start, originalWord, convertedWord);
        }
        return true;
    }

    /**
     * 短い文字列の各文字が、長い文字列のどこに対応するかを左から探す（長い文字列から文字を抜くだけで短い文字列になるか）
     * @param {string} shortText - 短い文字列
     * @param {string} longText - 長い文字列
     * @returns {number[]|null} shortText の各文字に対応する longText の位置。抜くだけでは作れなければ null
     */
    function matchSubsequence(shortText, longText) {
        var matchedIndexes = [];
        var longIndex = 0;
        for (var i = 0; i < shortText.length; i++) {
            while (longIndex < longText.length && longText.charAt(longIndex) !== shortText.charAt(i)) longIndex++;
            if (longIndex >= longText.length) return null;
            matchedIndexes.push(longIndex);
            longIndex++;
        }
        return matchedIndexes;
    }

    /**
     * 残す文字以外を右から削除する
     * @param {TextFrameItem[]} frameCharacters - textFrame.characters
     * @param {number} originalLength - 変換前の文字数
     * @param {number[]} keptIndexes - 残す文字の位置（昇順）
     * @returns {void}
     */
    function removeUnkeptCharacters(frameCharacters, originalLength, keptIndexes) {
        var keptIndex = keptIndexes.length - 1;
        for (var i = originalLength - 1; i >= 0; i--) {
            if (keptIndex >= 0 && keptIndexes[keptIndex] === i) {
                keptIndex--;
                continue;
            }
            frameCharacters[i].remove();
        }
    }

    /**
     * 増えた文字を、右から隣の文字に足して入れる（足した文字はその隣の文字の書式になる）
     * @param {TextFrameItem[]} frameCharacters - textFrame.characters
     * @param {string} originalText - 変換前の文字列（空でないこと）
     * @param {string} convertedText - 変換後の文字列
     * @param {number[]} originalIndexes - 変換前の各文字に対応する変換後の位置
     * @returns {void}
     */
    function insertAddedText(frameCharacters, originalText, convertedText, originalIndexes) {
        for (var i = originalText.length - 1; i >= 0; i--) {
            var nextIndex = (i + 1 < originalText.length) ? originalIndexes[i + 1] : convertedText.length;
            var addedAfter = convertedText.substring(originalIndexes[i] + 1, nextIndex);
            var addedBefore = (i === 0) ? convertedText.substring(0, originalIndexes[0]) : "";
            if (addedAfter !== "" || addedBefore !== "") frameCharacters[i].contents = addedBefore + originalText.charAt(i) + addedAfter;
        }
    }

    /**
     * 変換前と変換後で異なる部分だけを書き換える
     * 長さが同じなら異なる文字を1文字ずつ、違えば前後の一致部分を除いた範囲を差し替える（差し替えた文字はその範囲の先頭の文字の書式になる）
     * @param {TextFrameItem[]} frameCharacters - textFrame.characters
     * @param {number} offset - 書き換える範囲の開始位置
     * @param {string} originalText - 変換前の文字列
     * @param {string} convertedText - 変換後の文字列
     * @returns {void}
     */
    function replaceDifferingPart(frameCharacters, offset, originalText, convertedText) {
        var i;
        if (convertedText.length === originalText.length) {
            for (i = originalText.length - 1; i >= 0; i--) {
                if (convertedText.charAt(i) !== originalText.charAt(i)) frameCharacters[offset + i].contents = convertedText.charAt(i);
            }
            return;
        }
        var shorterLength = Math.min(originalText.length, convertedText.length);
        var prefixLength = 0;
        while (prefixLength < shorterLength && originalText.charAt(prefixLength) === convertedText.charAt(prefixLength)) prefixLength++;
        var suffixLength = 0;
        while (suffixLength < shorterLength - prefixLength &&
            originalText.charAt(originalText.length - 1 - suffixLength) === convertedText.charAt(convertedText.length - 1 - suffixLength)) suffixLength++;

        var replaceStart = offset + prefixLength;
        var replaceEnd = offset + originalText.length - suffixLength;
        var middleText = convertedText.substring(prefixLength, convertedText.length - suffixLength);
        if (replaceStart === replaceEnd) {
            /* 文字が増えるだけのときは、隣の文字に足す / When characters are only added, attach them to a neighbor */
            if (prefixLength > 0) {
                frameCharacters[replaceStart - 1].contents = originalText.charAt(prefixLength - 1) + middleText;
            } else {
                frameCharacters[replaceStart].contents = middleText + originalText.charAt(prefixLength);
            }
            return;
        }
        var keptCount = (middleText === "") ? 0 : 1;
        for (i = replaceEnd - 1; i >= replaceStart + keptCount; i--) {
            frameCharacters[i].remove();
        }
        if (keptCount > 0) frameCharacters[replaceStart].contents = middleText;
    }

    /**
     * テキストの箇条書き・番号付きリストを［テキストに変換］で本文の記号にする（行頭が「•＋タブ」などになる）
     * listStyle はスクリプトから読めず「なし」も書けないので、選択してメニューのコマンドを実行する
     * @param {Document} doc - 対象ドキュメント
     * @param {TextFrame} textFrame - 対象のテキストフレーム
     * @returns {void}
     */
    function convertListStyleToText(doc, textFrame) {
        doc.selection = null;
        textFrame.selected = true;
        /* 選択を変えた直後は古い選択のままコマンドが走ることがあるので、先に再描画する
           Redraw first, as a command right after changing the selection may still see the old one */
        app.redraw();
        app.executeMenuCommand("convert list style to text");
    }

    // =========================================
    // シンボル内のテキスト / Text in symbols
    // =========================================

    /**
     * 対象範囲にあるシンボルインスタンスから、元のシンボルを重複なく集める
     * @param {Document} doc - 対象ドキュメント
     * @param {string} scope - "selection" / "artboard" / "document"
     * @param {Object} layerOptions - { includeHidden: boolean, includeLocked: boolean }
     * @param {PageItem[]} selectedItems - 実行時に選択していたアイテム
     * @returns {Symbol[]} シンボルの配列
     */
    function collectTargetSymbols(doc, scope, layerOptions, selectedItems) {
        var symbolItems = collectScopedItems(doc.symbolItems, "SymbolItem", doc, scope, layerOptions, selectedItems);
        var targetSymbols = [];
        for (var i = 0; i < symbolItems.length; i++) {
            var sourceSymbol = symbolItems[i].symbol;
            if (indexOfItem(targetSymbols, sourceSymbol) === -1) targetSymbols.push(sourceSymbol);
        }
        return targetSymbols;
    }

    /**
     * 配列の中でのオブジェクトの位置を返す（DOM の参照は === で比べられる）
     * @param {Object[]} itemList - 探す配列
     * @param {Object} searchedItem - 探すオブジェクト
     * @returns {number} 位置。無ければ -1
     */
    function indexOfItem(itemList, searchedItem) {
        for (var i = 0; i < itemList.length; i++) {
            if (itemList[i] === searchedItem) return i;
        }
        return -1;
    }

    /**
     * 作業レイヤーを作って処理を実行し、終わったら作業レイヤーを消して選択とアクティブレイヤーを戻す
     * @param {Document} doc - 対象ドキュメント
     * @param {Function} workCallback - (workLayer) を受け取る処理
     * @returns {void}
     */
    function withSymbolWorkLayer(doc, workCallback) {
        /* 文字ツールで選択した文字は、フレームではなく文字の範囲として戻す / Restore characters selected with the Type tool as a text range, not as frames */
        var savedTextRange = (doc.selection && doc.selection.typename === "TextRange") ? doc.selection : null;
        var savedSelection = savedTextRange ? [] : toItemArray(doc.selection);
        var savedActiveLayer = doc.activeLayer;
        var workLayer = doc.layers.add();
        try {
            workCallback(workLayer);
        } finally {
            workLayer.remove();
            doc.activeLayer = savedActiveLayer;
            doc.selection = (savedSelection.length > 0) ? savedSelection : null;
            if (savedTextRange) savedTextRange.select();
        }
    }

    /**
     * シンボルの中身を作業レイヤーに展開し、1つのグループにまとめて返す
     * @param {Document} doc - 対象ドキュメント
     * @param {Symbol} symbol - 展開するシンボル
     * @param {Layer} workLayer - 作業レイヤー（空であること）
     * @returns {GroupItem} シンボルの中身をまとめたグループ
     */
    function expandSymbolToGroup(doc, symbol, workLayer) {
        doc.activeLayer = workLayer;
        var workInstance = doc.symbolItems.add(symbol);
        doc.selection = null;
        workInstance.selected = true;
        workInstance.breakLink();

        /* 解除の生成物はページアイテムかサブレイヤーのどちらかで出るので、作業レイヤーの中身を全部まとめる
           breakLink yields page items or a sublayer, so gather everything on the work layer */
        var contentGroup = workLayer.groupItems.add();
        var i;
        for (i = workLayer.pageItems.length - 1; i >= 0; i--) {
            if (workLayer.pageItems[i] !== contentGroup) workLayer.pageItems[i].move(contentGroup, ElementPlacement.PLACEATEND);
        }
        for (i = workLayer.layers.length - 1; i >= 0; i--) {
            var subLayer = workLayer.layers[i];
            while (subLayer.pageItems.length > 0) {
                subLayer.pageItems[0].move(contentGroup, ElementPlacement.PLACEATEND);
            }
            subLayer.remove();
        }
        return contentGroup;
    }

    /**
     * シンボル内のテキストの内容を集める（一致数の表示用。ドキュメントは変えない）
     * @param {Document} doc - 対象ドキュメント
     * @param {Symbol[]} targetSymbols - 対象のシンボル
     * @returns {string[]} テキストの内容
     */
    function getSymbolTextContents(doc, targetSymbols) {
        var textContents = [];
        forEachSymbolContent(doc, targetSymbols, function (targetSymbol, contentGroup, symbolFrames) {
            textContents = textContents.concat(getFrameContents(symbolFrames));
        });
        return textContents;
    }

    /**
     * シンボルを1つずつ作業レイヤーに展開して処理し、展開したアートは処理のあとに消す
     * @param {Document} doc - 対象ドキュメント
     * @param {Symbol[]} targetSymbols - 対象のシンボル
     * @param {Function} handleSymbol - (targetSymbol, contentGroup, symbolFrames) を受け取る処理
     * @returns {void}
     */
    function forEachSymbolContent(doc, targetSymbols, handleSymbol) {
        if (targetSymbols.length === 0) return;
        withSymbolWorkLayer(doc, function (workLayer) {
            for (var i = 0; i < targetSymbols.length; i++) {
                var contentGroup = expandSymbolToGroup(doc, targetSymbols[i], workLayer);
                var symbolFrames = [];
                collectItemsOfType(contentGroup, "TextFrame", symbolFrames);
                handleSymbol(targetSymbols[i], contentGroup, symbolFrames);
                contentGroup.remove();
            }
        });
    }

    /**
     * シンボル内のテキストを書き換え、変わったシンボルだけ定義を差し替える
     * @param {Document} doc - 対象ドキュメント
     * @param {Symbol[]} targetSymbols - 対象のシンボル
     * @param {Function} editSymbolFrames - (symbolFrames) を受け取って書き換え、変えたら差し替えの成功後に呼ぶ関数を、変えなければ null を返す
     * @returns {number} 書き換えたシンボルの数
     */
    function rewriteSymbols(doc, targetSymbols, editSymbolFrames) {
        var updatedSymbolCount = 0;
        forEachSymbolContent(doc, targetSymbols, function (targetSymbol, contentGroup, symbolFrames) {
            var onSymbolReplaced = editSymbolFrames(symbolFrames);
            if (onSymbolReplaced && replaceSymbolDefinition(doc, targetSymbol, contentGroup)) {
                updatedSymbolCount++;
                onSymbolReplaced();
            }
        });
        return updatedSymbolCount;
    }

    /**
     * シンボル内のテキストの一致箇所を削除・置換し、書き換えたシンボルで定義を差し替える
     * @param {Document} doc - 対象ドキュメント
     * @param {Symbol[]} targetSymbols - 対象のシンボル
     * @param {Object[]} searchEntries - getSearchEntries() の結果
     * @param {number[]} processedCounts - 欄ごとの削除・置換数（加算していく）
     * @returns {number} 書き換えたシンボルの数
     */
    function replaceTextInSymbols(doc, targetSymbols, searchEntries, processedCounts) {
        return rewriteSymbols(doc, targetSymbols, function (symbolFrames) {
            /* 差し替えに失敗したら数えないよう、シンボルごとに数えてから足す / Count per symbol, and add only when the swap succeeds */
            var symbolProcessedCounts = createZeroCounts(searchEntries.length);
            var isChanged = false;
            for (var j = 0; j < symbolFrames.length; j++) {
                if (replacePatternsInFrame(symbolFrames[j], searchEntries, symbolProcessedCounts)) isChanged = true;
            }
            if (!isChanged) return null;
            return function () {
                for (var k = 0; k < searchEntries.length; k++) processedCounts[k] += symbolProcessedCounts[k];
            };
        });
    }

    /**
     * シンボル内のテキストを変換し、書き換えたシンボルで定義を差し替える
     * @param {Document} doc - 対象ドキュメント
     * @param {Symbol[]} targetSymbols - 対象のシンボル
     * @param {Function} convertText - getTextConverter() の結果
     * @param {Function|null} prepareFrame - 変換の前に (textFrame) を受け取って行う処理。無ければ null
     * @returns {number} 書き換えたシンボルの数
     */
    function convertTextInSymbols(doc, targetSymbols, convertText, prepareFrame) {
        return rewriteSymbols(doc, targetSymbols, function (symbolFrames) {
            var isChanged = false;
            for (var j = 0; j < symbolFrames.length; j++) {
                if (prepareFrame) prepareFrame(symbolFrames[j]);
                if (convertFrameKeepingFormat(symbolFrames[j], convertText)) isChanged = true;
            }
            /* 変換では数えるものが無いので、差し替え後の処理は空 / Nothing to count after a conversion */
            return isChanged ? function () {} : null;
        });
    }

    /**
     * 新しいシンボルを作り、元のシンボルのインスタンスをすべて差し替えて、元のシンボルと入れ替える
     * （差し替えてもインスタンスの位置は変わらない。実測済み）
     * @param {Document} doc - 対象ドキュメント
     * @param {Symbol} oldSymbol - 元のシンボル
     * @param {GroupItem} contentGroup - 新しい定義にするアート
     * @returns {boolean} 差し替えられたら true
     */
    function replaceSymbolDefinition(doc, oldSymbol, contentGroup) {
        var newSymbol = doc.symbols.add(contentGroup);
        var swappedItems = [];
        /* 編集できないインスタンスがあれば、差し替えた分を戻して新しいシンボルを消す / If an instance cannot be edited, undo the swaps and drop the new symbol */
        try {
            for (var i = 0; i < doc.symbolItems.length; i++) {
                var symbolItem = doc.symbolItems[i];
                if (symbolItem.symbol !== oldSymbol) continue;
                var stateRecords = [];
                try {
                    unlockAndRevealAncestors(symbolItem, stateRecords);
                    symbolItem.symbol = newSymbol;
                    swappedItems.push(symbolItem);
                } finally {
                    restoreItemStates(stateRecords);
                }
            }
        } catch (e) {
            for (var j = 0; j < swappedItems.length; j++) swappedItems[j].symbol = oldSymbol;
            newSymbol.remove();
            return false;
        }

        var symbolName = oldSymbol.name;
        /* 別のシンボルの中から使われていると消せないので、そのときは元のシンボルを残す / An old symbol used inside another symbol cannot be removed, so keep it */
        try {
            oldSymbol.remove();
            newSymbol.name = symbolName;
        } catch (e) {}
        return true;
    }

    main();

})();
