#target illustrator
#targetengine "SwapTextSpecialEngine"
app.preferences.setBooleanPreference('ShowExternalJSXWarning', false);

/*
SCRIPTMETA-BEGIN
Script-ID=com.swwwitch.illustrator.SwapTextSpecial
Name=2つのテキストの内容を入れ替える
Author=Masahiro Takano (@swwwitch)
Target-App=Illustrator
Version=1.1.1
Release-Date=2026-06-10
Description-BEGIN
選択中の2つのテキストオブジェクトの内容を入れ替えます。
入れ替える対象（文字列／スタイル／座標）はダイアログで選べます。

Swaps the contents of two selected text objects.
A dialog picks what is swapped: the contents, the style, or the position.
Description-END
SCRIPTMETA-END
*/

/*

### 概要

選択中の2つのテキストオブジェクトの内容を入れ替えます。
入れ替える対象（文字列／スタイル／座標）はダイアログで選べます。

詳細は README を参照してください。
https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/SwapTextSpecial.md

note記事も参照してください。
https://note.com/dtp_tranist/n/n071e09af28a7

### Overview

Swaps the contents of two selected text objects.
A dialog picks what is swapped: the contents, the style, or the position.

See the README for details.
https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/SwapTextSpecial.md

*/

// =========================================
// 基本情報 / Basic info
// =========================================
var SCRIPT_NAME     = "SwapTextSpecial";              /* スクリプト名 / script name */
var SCRIPT_VERSION  = "v1.1.1";                       /* バージョン / version */
var SCRIPT_AUTHOR   = "Masahiro Takano (@swwwitch)";  /* 作者 / author */
var SCRIPT_RELEASED = "2026-06-10";                   /* 最初のリリース日 / first release date */
var SCRIPT_UPDATED  = "2026-10-09";                   /* 更新日 / last updated */

var SCRIPT_DESCRIPTION_JA = "2つのテキストの内容を入れ替える"; /* README の見出し / README title (Japanese) */

var SCRIPT_README_JA   = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/SwapTextSpecial.md"; /* README（日本語） */
var SCRIPT_README_EN   = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/SwapTextSpecial.md"; /* README (English) */
var SCRIPT_ARTICLE_URL = "https://note.com/dtp_tranist/n/n071e09af28a7"; /* 紹介記事 / article URL */
var SCRIPT_SOURCE_URL  = "https://github.com/swwwitch/illustrator-scripts/blob/master/jsx/text/SwapTextSpecial.jsx"; /* 最新版のソース / latest source */

// Released under the MIT license
// http://opensource.org/licenses/mit-license.php

(function () {

    // =========================================
    // レイアウト / Layout
    // =========================================

    // UIレイアウト（再利用パーツ） / UI layout (reusable)

    /* ウィンドウ・パネルの余白と間隔 / Window & panel margins and spacing */
    var WINDOW_MARGINS = 16;                 /* ウィンドウ外周の余白 / window margin */
    var WINDOW_SPACING = 12;                 /* ウィンドウ内の要素間隔 / window spacing */
    var PANEL_MARGINS  = [16, 20, 16, 12];   /* パネル余白 [左,上,右,下] / panel margins */
    var PANEL_SPACING  = 12;                 /* パネル内の要素間隔 / panel spacing */
    var COLUMN_SPACING = 12;                 /* 2カラムの間隔 / gap between columns */
    var TAB_MARGINS    = [15, 20, 5, 10];    /* タブ余白 [左,上,右,下] / tab margins */

    /**
     * ウィンドウの共通設定
     * @param {Window} targetWindow - 対象のウィンドウ
     * @param {number} [spacing] - 要素間隔（省略時は WINDOW_SPACING）
     * @returns {void}
     */
    function setupWindow(targetWindow, spacing) {
        targetWindow.orientation = "column";
        targetWindow.alignChildren = "fill";
        targetWindow.margins = WINDOW_MARGINS;
        targetWindow.spacing = (typeof spacing === "number") ? spacing : WINDOW_SPACING;
    }

    /**
     * パネルの共通設定（子は幅いっぱい。ボタンは alignment = "left" で広げない）
     * @param {Panel} targetPanel - 対象のパネル
     * @param {number} [spacing] - 要素間隔（省略時は PANEL_SPACING）
     * @returns {void}
     */
    function setupPanel(targetPanel, spacing) {
        targetPanel.orientation = "column";
        targetPanel.alignChildren = ["fill", "top"];
        targetPanel.alignment = "fill";
        targetPanel.margins = PANEL_MARGINS;
        targetPanel.spacing = (typeof spacing === "number") ? spacing : PANEL_SPACING;
    }

    /**
     * タブの共通設定
     * @param {Tab} targetTab - 対象のタブ
     * @param {number} [spacing] - 要素間隔（省略時は変えない）
     * @returns {void}
     */
    function setupTab(targetTab, spacing) {
        targetTab.orientation = "column";
        targetTab.alignChildren = "fill";
        targetTab.margins = TAB_MARGINS;
        if (typeof spacing === "number") targetTab.spacing = spacing;
    }

    /**
     * 横並びの行グループの共通設定（ボタン列など）。
     * alignment と alignChildren を対で指定し、中のボタンが横に伸びたり天地がずれたりしないようにする
     * @param {Group} rowGroup - 対象のグループ
     * @param {string|string[]} [rowAlignment] - 横方向の alignment（省略時は "left"）。配列ならそのまま使う
     * @param {number} [spacing] - 要素間隔（省略時は PANEL_SPACING）
     * @returns {void}
     */
    function setupRow(rowGroup, rowAlignment, spacing) {
        rowGroup.orientation = "row";
        rowGroup.alignment = (rowAlignment instanceof Array) ? rowAlignment : [rowAlignment || "left", "center"];
        rowGroup.alignChildren = ["left", "center"];
        rowGroup.spacing = (typeof spacing === "number") ? spacing : PANEL_SPACING;
    }

    /**
     * ボタンの高さを指定した px だけ詰める（レイアウトが決まったあとに呼ぶ）
     * @param {Button} targetButton - 対象のボタン
     * @param {number} trimPixels - 詰める量（px）
     * @returns {void}
     */
    function trimButtonHeight(targetButton, trimPixels) {
        /* レイアウト前は size が無い / size is not set until the layout runs */
        if (!targetButton.size) return;
        targetButton.size = [targetButton.size.width, targetButton.size.height - trimPixels];
    }

    // UIレイアウト（再利用パーツ）ここまで / End of the reusable UI layout

    var POSITION_BASIS_INDENT = 20; /* ［座標］の下の基準のラジオの字下げ（px）/ indent of the basis radios under Position (px) */

    // =========================================
    // ローカライズ / Localization
    // =========================================

    // ローカライズ（再利用パーツ） / Localization (reusable)

    /**
     * UI の言語を返す（"ja" で始まるロケールは日本語、それ以外は英語）
     * @returns {string} "ja" または "en"
     */
    function getCurrentLang() {
        return (String($.locale || "").indexOf("ja") === 0) ? "ja" : "en";
    }

    var uiLang = getCurrentLang();

    /**
     * LABELS から今の UI 言語の文言を取り出す。
     * @param {string|Object} labelRef - "dialog.title" のようなパス、または { ja, en }
     * @param {Object|Array} [placeholderValues] - { name: 値 } なら {name} を、[値, …] なら %1, %2 … を差し込む
     * @returns {string} 文言。パスが見つからなければパスの文字列、{ ja, en } が無ければ空文字
     */
    function getLabel(labelRef, placeholderValues) {
        var labelEntry = labelRef;
        if (typeof labelRef === "string") {
            var labelPathKeys = labelRef.split(".");
            labelEntry = LABELS;
            for (var i = 0; i < labelPathKeys.length && labelEntry != null; i++) {
                labelEntry = labelEntry[labelPathKeys[i]];
            }
        }
        var labelString;
        if (typeof labelEntry === "string") labelString = labelEntry;
        else if (labelEntry != null && labelEntry[uiLang] != null) labelString = labelEntry[uiLang];
        else if (labelEntry != null && labelEntry.en != null) labelString = labelEntry.en;
        else return (typeof labelRef === "string") ? labelRef : "";
        return fillLabelPlaceholders(String(labelString), placeholderValues);
    }

    /**
     * 項目名の文言の末尾にコロンを付ける（日本語は半角スペース＋半角コロン「 :」、英語は「:」。Illustrator の線パネルなどの項目名に合わせる）
     * @param {string|Object} labelRef - getLabel と同じ
     * @param {Object|Array} [placeholderValues] - getLabel と同じ
     * @returns {string} コロン付きの文言
     */
    function labelText(labelRef, placeholderValues) {
        return getLabel(labelRef, placeholderValues) + (uiLang === "ja" ? " :" : ":");
    }

    /**
     * 「項目名 : 値」の1行を返す（日本語は「件数 : 5」、英語は「Count: 5」。どちらもコロンのあとに空白を入れる）
     * @param {string|Object} labelRef - getLabel と同じ
     * @param {string|number} value - コロンのあとに続ける値
     * @returns {string} 項目名と値をつないだ文字列
     */
    function labelValueText(labelRef, value) {
        return labelText(labelRef) + " " + value;
    }

    /**
     * 文言の {name} や %1 に値を差し込む
     * @param {string} labelString - 文言
     * @param {Object|Array} [placeholderValues] - { name: 値 } または [値, …]
     * @returns {string} 差し込んだ文言
     */
    function fillLabelPlaceholders(labelString, placeholderValues) {
        if (placeholderValues == null) return labelString;
        if (placeholderValues instanceof Array) {
            /* 大きい番号から置き換え、%1 が %10 の一部を置き換えないようにする / Replace from the highest index so %1 does not eat into %10 */
            for (var i = placeholderValues.length; i >= 1; i--) {
                labelString = labelString.split("%" + i).join(String(placeholderValues[i - 1]));
            }
            return labelString;
        }
        for (var placeholderKey in placeholderValues) {
            if (!placeholderValues.hasOwnProperty(placeholderKey)) continue;
            labelString = labelString.split("{" + placeholderKey + "}").join(String(placeholderValues[placeholderKey]));
        }
        return labelString;
    }

    // ローカライズ（再利用パーツ）ここまで / End of the reusable localization

    var LABELS = {
        dialog: {
            title: { ja: "テキストの入れ替え", en: "Swap Text" }
        },
        panel: {
            target: { ja: "入れ替える対象", en: "Swap target" }
        },
        radio: {
            contents: { ja: "文字列", en: "String" },
            format: { ja: "書式", en: "Format" },
            position: { ja: "座標", en: "Position" },
            topLeft: { ja: "左上", en: "Top left" },
            anchorPoint: { ja: "基点", en: "Anchor point" }
        },
        button: {
            cancel: { ja: "キャンセル", en: "Cancel" },
            ok: { ja: "OK", en: "OK" }
        },
        alert: {
            noDocument: { ja: "ドキュメントが開かれていません。", en: "No document is open." },
            needTwo: { ja: "テキストオブジェクトを2つ選択してください。", en: "Please select two text objects." },
            needText: {
                ja: "選択した2つは両方ともテキストオブジェクトである必要があります。",
                en: "Both selected objects must be text objects."
            }
        },
        tooltip: {
            contents: {
                ja: "2つのテキストの文字列だけを入れ替えます。書式と位置はそのままです。",
                en: "Swaps only the strings. The formatting and positions stay put."
            },
            format: {
                ja: "フォント・サイズ・色などの書式だけを入れ替えます。文字列と位置はそのままです。",
                en: "Swaps only the formatting, such as font, size, and colour. The strings and positions stay put."
            },
            position: {
                ja: "2つのテキストの位置だけを入れ替えます。中身はそのままです。",
                en: "Swaps only the positions. The contents stay put."
            },
            topLeft: {
                ja: "テキストの外枠の左上をそろえて入れ替えます。",
                en: "Lines up the top-left corners of the text bounds."
            },
            anchorPoint: {
                ja: "テキストの基点（ベースライン上の行揃えの位置）をそろえて入れ替えます。",
                en: "Lines up the text anchor points (on the baseline, at the alignment point)."
            }
        }
    };

    // ダイアログの位置と不透明度（再利用パーツ） / Dialog position and opacity (reusable)

    var DIALOG_OPACITY = 0.98;       /* ダイアログの不透明度 / dialog opacity */
    var DIALOG_AVOID_MARGIN = 60;    /* 選択範囲の推定位置の両側に取る余裕（px）/ margin on each side of the estimated selection (px) */
    var DIALOG_AVOID_MAX_ITEMS = 100; /* 選択範囲を測るオブジェクトの上限 / max items measured for the selection bounds */

    /**
     * ダイアログの不透明度を設定し、前回閉じた位置で開いて、動かした位置を記録するようにする。
     * 開く位置が選択中のオブジェクトに重なりそうなときは、左右の反対側へずらす（Illustrator のみ）。
     * 既存の onShow / onMove / onClose は先に呼んでから、位置の復元・記録を行う。
     * @param {Window} dialog - 対象のダイアログ
     * @param {string} storageKey - 位置を覚えるキー（ふつうは SCRIPT_NAME）
     * @returns {void}
     */
    function prepareDialogWindow(dialog, storageKey) {
        /* 同じダイアログを開き直すときは、選択範囲を測り直すだけにする（ハンドラーを重ねない）
           When the same dialog is shown again, only re-measure the selection (don't stack handlers) */
        if (dialog.dialogWindowState) {
            dialog.dialogWindowState.selectionSpan = getSelectionViewSpan();
            dialog.dialogWindowState.avoidedLocation = null;
            return;
        }
        var locationKey = "__" + storageKey + "_DialogLocation";
        var previousOnShow = dialog.onShow;
        var previousOnMove = dialog.onMove;
        var previousOnClose = dialog.onClose;
        var windowState = {
            selectionSpan: getSelectionViewSpan(), /* 選択範囲は show() の前に測る / measured before show() */
            screenWidth: null,                     /* 最初に開いたときに推定する / estimated on the first show */
            avoidedLocation: null                  /* 避けるためにずらした位置（記録しない）/ location set to avoid the selection (not remembered) */
        };
        dialog.dialogWindowState = windowState;

        dialog.opacity = DIALOG_OPACITY;

        /* 今の位置を記録する / Remember the current location */
        function rememberDialogLocation() {
            var currentLocation = [dialog.location[0], dialog.location[1]];
            var avoidedLocation = windowState.avoidedLocation;
            if (avoidedLocation && currentLocation[0] === avoidedLocation[0] && currentLocation[1] === avoidedLocation[1]) return;
            $.global[locationKey] = currentLocation;
        }

        dialog.onShow = function () {
            /* 最初に開くときの既定の位置は画面の横中央なので、画面の幅を逆算できる。2回目からは前回の位置なので使い回す
               On the first show the default location is centered horizontally, which gives the screen width; reuse it afterwards */
            if (windowState.screenWidth === null) windowState.screenWidth = dialog.location[0] * 2 + dialog.bounds.width;
            if (previousOnShow) previousOnShow.apply(this, arguments);
            /* $.screens は実際の画面の大きさと合わない（Mac で 1280×524 など）ので、画面内かは判定しない
               $.screens does not match the real display (e.g. 1280x524 on a Mac), so no on-screen check */
            var savedLocation = $.global[locationKey];
            if (savedLocation) dialog.location = [savedLocation[0], savedLocation[1]];
            if (windowState.selectionSpan) {
                var avoidLeft = findDialogLeftAvoidingSelection(dialog.location[0], dialog.bounds.width, windowState.screenWidth, windowState.selectionSpan);
                if (avoidLeft !== null) {
                    dialog.location = [avoidLeft, dialog.location[1]];
                    /* 代入後の値で比べる（丸められることがある）/ Compare with the value after assignment, which may be rounded */
                    windowState.avoidedLocation = [dialog.location[0], dialog.location[1]];
                }
            }
        };
        dialog.onMove = function () {
            if (previousOnMove) previousOnMove.apply(this, arguments);
            rememberDialogLocation();
        };
        dialog.onClose = function () {
            rememberDialogLocation();
            /* false を返すと閉じるのを取りやめるので、戻り値は元の onClose のものを返す
               Returning false cancels the close, so pass the original onClose result through */
            if (previousOnClose) return previousOnClose.apply(this, arguments);
        };
    }

    /**
     * 選択中のオブジェクトが、ドキュメントの表示域の左端から画面上で何 px の範囲にあるかを返す。
     * @returns {{left: number, right: number, viewWidth: number}|null} 選択が無い・測れないときは null
     */
    function getSelectionViewSpan() {
        try {
            if (app.name !== "Adobe Illustrator" || !app.documents.length) return null;
            var targetDoc = app.activeDocument;
            var selectedItems = targetDoc.selection;
            /* 文字ツールで文字を選択しているときは TextRange が返り、[0] が無い / Selecting characters with the Type tool returns a TextRange, which has no [0] */
            if (!selectedItems || selectedItems.typename === "TextRange" || !selectedItems.length || !selectedItems[0].visibleBounds) return null;
            var itemCount = Math.min(selectedItems.length, DIALOG_AVOID_MAX_ITEMS);
            var spanLeft = Infinity;
            var spanRight = -Infinity;
            for (var i = 0; i < itemCount; i++) {
                var itemBounds = selectedItems[i].visibleBounds;
                if (itemBounds[0] < spanLeft) spanLeft = itemBounds[0];
                if (itemBounds[2] > spanRight) spanRight = itemBounds[2];
            }
            var activeView = targetDoc.activeView; /* 複数ウィンドウで開いていても今のウィンドウ / the current window even with multiple windows */
            var viewBounds = activeView.bounds;
            var zoom = activeView.zoom;
            var viewWidth = (viewBounds[2] - viewBounds[0]) * zoom;
            /* 表示域の外にはみ出した部分は数えない / Ignore the part outside the view */
            var left = Math.max(0, (spanLeft - viewBounds[0]) * zoom);
            var right = Math.min(viewWidth, (spanRight - viewBounds[0]) * zoom);
            if (right <= left) return null;
            return { left: left, right: right, viewWidth: viewWidth };
        } catch (e) {
            /* テキスト編集中など測れないときは避けない / Do not avoid when it cannot be measured, e.g. while editing text */
            return null;
        }
    }

    /**
     * ダイアログが選択範囲に重なるなら、重ならない左端の位置を返す。
     * 表示域は画面の横中央にあるとみなし、ずれは DIALOG_AVOID_MARGIN で吸収する。
     * @param {number} dialogLeft - 今のダイアログの左端
     * @param {number} dialogWidth - ダイアログの幅
     * @param {number} screenWidth - 画面の幅
     * @param {{left: number, right: number, viewWidth: number}} selectionSpan - getSelectionViewSpan() の結果
     * @returns {number|null} ずらした左端。重ならない・どちらにも収まらないときは null
     */
    function findDialogLeftAvoidingSelection(dialogLeft, dialogWidth, screenWidth, selectionSpan) {
        var viewLeft = (screenWidth - selectionSpan.viewWidth) / 2;
        var avoidLeft = viewLeft + selectionSpan.left - DIALOG_AVOID_MARGIN;
        var avoidRight = viewLeft + selectionSpan.right + DIALOG_AVOID_MARGIN;
        if (dialogLeft + dialogWidth <= avoidLeft || dialogLeft >= avoidRight) return null;

        var leftSideLeft = avoidLeft - dialogWidth;   /* 選択範囲の左に置くとき / placed left of the selection */
        var rightSideLeft = avoidRight;               /* 選択範囲の右に置くとき / placed right of the selection */
        var fitsLeft = leftSideLeft >= 0;
        var fitsRight = rightSideLeft + dialogWidth <= screenWidth;
        /* 選択範囲が画面の右寄りなら左へ、左寄りなら右へ逃がす / Move away from the side the selection leans to */
        var preferLeft = (avoidLeft + avoidRight) / 2 > screenWidth / 2;
        if (preferLeft && fitsLeft) return leftSideLeft;
        if (fitsRight) return rightSideLeft;
        if (fitsLeft) return leftSideLeft;
        return null;
    }

    // ダイアログの位置と不透明度（再利用パーツ）ここまで / End of the reusable dialog position and opacity

    // =============================================================
    // ダイアログ / Dialog
    // =============================================================

    /**
     * 入れ替え対象のラジオボタンを tooltip 付きで追加する
     * @param {Panel|Group} parentPanel - 追加先のパネルまたはグループ
     * @param {string} modeKey - LABELS.radio と LABELS.tooltip のキー（"contents" / "format" / "position" / "topLeft" / "anchorPoint"）
     * @returns {RadioButton} 追加したラジオボタン
     */
    function addModeRadio(parentPanel, modeKey) {
        var modeRadio = parentPanel.add("radiobutton", undefined, getLabel(LABELS.radio[modeKey]));
        modeRadio.helpTip = getLabel(LABELS.tooltip[modeKey]);
        return modeRadio;
    }

    // ボタン行（再利用パーツ） / Button row (reusable)

    var BUTTON_ROW_TOP_MARGIN = 5; /* ボタン行の上の余白 / top margin of the button row */
    var BUTTON_ROW_BOTTOM_MARGIN = 14; /* ボタン行の下の余白。ダイアログの下余白と合わせて約30px（Illustrator 標準のダイアログに合わせる） / bottom margin; with the dialog margin about 30px, like Illustrator's own dialogs */
    var BUTTON_ROW_SPACING = 10;   /* ボタンどうしの間隔 / spacing between buttons */
    var BUTTON_ROW_CENTER_MAX_WIDTH = 240; /* 右のボタンだけの行を中央に置く、ダイアログの内側の最大幅（px、左右の余白を除く）。広いダイアログは右揃え / max inner dialog width (px, margins excluded) that centers a right-only row; wider dialogs keep it right-aligned */

    /**
     * ダイアログ下部のボタン行を作る。
     * 通常は「左のグループ・伸びるスペーサー・右のグループ」、centered なら行そのものを左右中央に置く
     * @param {Window|Group|Panel} parent - 行を足す先（ふつうはダイアログ）
     * @param {Object} [rowOptions] - { centered: true } で左右中央に並べる
     * @returns {{rowGroup: Group, leftGroup: Group|null, rightGroup: Group|null}} 行と左右のグループ（centered のときは左右が null）
     */
    function addButtonRow(parent, rowOptions) {
        var isCentered = !!(rowOptions && rowOptions.centered);
        var btnRowGroup = parent.add("group");
        btnRowGroup.orientation = "row";
        btnRowGroup.margins = [0, BUTTON_ROW_TOP_MARGIN, 0, BUTTON_ROW_BOTTOM_MARGIN];
        btnRowGroup.spacing = BUTTON_ROW_SPACING;

        if (isCentered) {
            btnRowGroup.alignment = ["center", "bottom"];
            btnRowGroup.alignChildren = ["center", "center"];
            return { rowGroup: btnRowGroup, leftGroup: null, rightGroup: null };
        }

        btnRowGroup.alignment = ["fill", "bottom"];

        var btnLeftGroup = btnRowGroup.add("group");
        btnLeftGroup.alignChildren = ["left", "center"];
        btnLeftGroup.spacing = BUTTON_ROW_SPACING;

        /* 余りの幅を吸って、右のグループを右端に寄せる / Absorbs the extra width so the right group sits at the right edge */
        var spacer = btnRowGroup.add("group");
        spacer.alignment = ["fill", "fill"];
        spacer.minimumSize.width = 0;

        var btnRightGroup = btnRowGroup.add("group");
        btnRightGroup.alignChildren = ["right", "center"];
        btnRightGroup.spacing = BUTTON_ROW_SPACING;

        return { rowGroup: btnRowGroup, leftGroup: btnLeftGroup, rightGroup: btnRightGroup };
    }

    /**
     * 左のグループにボタンが無い（右のボタンだけの）行を、ダイアログの幅に合わせて揃える。
     * 内側の幅（左右の余白を除く）が BUTTON_ROW_CENTER_MAX_WIDTH 以下なら左右中央、それより広ければ右揃えのまま。
     * 幅はレイアウトが決まるまで分からないので、ダイアログを表示した時点（show イベント）で判定する。
     * ボタンをすべて足したあと、show() の前に呼ぶ。centered で作った行や、左にボタンがある行はそのまま
     * @param {{rowGroup: Group, leftGroup: Group|null, rightGroup: Group|null}} buttonRow - addButtonRow() の戻り値
     * @returns {void}
     */
    function alignRightOnlyButtonRow(buttonRow) {
        if (!buttonRow.leftGroup || buttonRow.leftGroup.children.length > 0) return;
        var dialogWindow = buttonRow.rowGroup.window;
        dialogWindow.addEventListener("show", function () {
            if (!buttonRow.leftGroup) return;
            var btnRowGroup = buttonRow.rowGroup;
            /* 行の幅＝ダイアログの内側の幅（左右の余白を除く）/ The row spans the dialog's inner width (margins excluded) */
            if (!btnRowGroup.size || btnRowGroup.size.width > BUTTON_ROW_CENTER_MAX_WIDTH) return;
            /* 左のグループとスペーサーを外し、右のグループだけを中央に置く / Drop the left group and the spacer so only the right group remains, centered */
            btnRowGroup.remove(buttonRow.leftGroup);
            btnRowGroup.remove(btnRowGroup.children[0]); /* 左のグループを外すと先頭はスペーサー / the spacer is first once the left group is gone */
            btnRowGroup.alignment = ["center", "bottom"];
            btnRowGroup.alignChildren = ["center", "center"];
            buttonRow.leftGroup = null;
            dialogWindow.layout.layout(true);
        });
    }

    // ボタン行（再利用パーツ）ここまで / End of the reusable button row

    /**
     * 入れ替える対象を選ぶダイアログを表示する
     * @returns {{swapMode: string, positionBasis: string}|null} swapMode は "contents" / "format" / "position"、positionBasis は "topLeft" / "anchorPoint"（キャンセル時は null）
     */
    function showSwapDialog() {
        var swapDialog = new Window("dialog", getLabel(LABELS.dialog.title) + " " + SCRIPT_VERSION);
        setupWindow(swapDialog);

        var targetPanel = swapDialog.add("panel", undefined, getLabel(LABELS.panel.target));
        setupPanel(targetPanel, 6);

        var radioContents = addModeRadio(targetPanel, "contents");
        var radioFormat = addModeRadio(targetPanel, "format");
        var radioPosition = addModeRadio(targetPanel, "position");

        /* 座標の基準。別のグループなので［座標］たちとは排他にならない / Position basis; a separate group, so not exclusive with the modes above */
        var positionBasisGroup = targetPanel.add("group");
        setupRow(positionBasisGroup);
        positionBasisGroup.margins = [POSITION_BASIS_INDENT, 0, 0, 0];
        var radioTopLeft = addModeRadio(positionBasisGroup, "topLeft");
        var radioAnchorPoint = addModeRadio(positionBasisGroup, "anchorPoint");
        radioTopLeft.value = true;

        /* 基準は［座標］を選んだときだけ使える / The basis applies only to Position */
        function updatePositionBasisEnabled() {
            positionBasisGroup.enabled = radioPosition.value;
        }
        radioContents.onClick = updatePositionBasisEnabled;
        radioFormat.onClick = updatePositionBasisEnabled;
        radioPosition.onClick = updatePositionBasisEnabled;

        radioContents.value = true;
        updatePositionBasisEnabled();

        /* ボタン行は左右中央に置く / Center the button row */
        var buttonRow = addButtonRow(swapDialog, { centered: true });
        var btnCancel = buttonRow.rowGroup.add("button", undefined, getLabel(LABELS.button.cancel), { name: "cancel" });
        var btnOK = buttonRow.rowGroup.add("button", undefined, getLabel(LABELS.button.ok), { name: "ok" });

        prepareDialogWindow(swapDialog, SCRIPT_NAME);
        if (swapDialog.show() !== 1) {
            return null;
        }

        var swapMode = "contents";
        if (radioFormat.value) swapMode = "format";
        else if (radioPosition.value) swapMode = "position";
        return { swapMode: swapMode, positionBasis: radioAnchorPoint.value ? "anchorPoint" : "topLeft" };
    }

    // =============================================================
    // 入れ替え処理 / Swap operations
    // =============================================================

    /**
     * 2つのテキストの文字列を入れ替える
     * @param {TextFrame} firstTextFrame - 1つ目のテキスト
     * @param {TextFrame} secondTextFrame - 2つ目のテキスト
     * @returns {void}
     */
    function swapContents(firstTextFrame, secondTextFrame) {
        var firstContents = firstTextFrame.contents;
        firstTextFrame.contents = secondTextFrame.contents;
        secondTextFrame.contents = firstContents;
    }

    /*
       入れ替える書式（characterAttributes）の一覧。
       List of character attributes to swap. textFont はフォント＋スタイルを兼ねる。
    */
    var FORMAT_ATTRIBUTE_KEYS = [
        "textFont",        /* フォント＋スタイル / font family + style */
        "size",            /* サイズ / size */
        "fillColor",       /* 文字カラー / text color */
        "strokeWeight",    /* 線幅（線カラーより先に書く）/ stroke weight (written before the stroke color) */
        "strokeColor",     /* 線カラー / stroke color */
        "tracking",        /* トラッキング / tracking */
        "leading",         /* 行送り / leading */
        "autoLeading",     /* 自動行送り / auto leading */
        "horizontalScale", /* 水平比率 / horizontal scale */
        "verticalScale",   /* 垂直比率 / vertical scale */
        "baselineShift",   /* ベースラインシフト / baseline shift */
        "capitalization"   /* 大文字小文字 / capitalization */
    ];

    /**
     * テキスト全体の書式を控える
     * @param {TextFrame} textFrame - 対象のテキスト
     * @returns {Object} 属性名と値の組（読み取れなかった属性は含まない）
     */
    function captureFormatAttributes(textFrame) {
        var charAttributes = textFrame.textRange.characterAttributes;
        var capturedAttributes = {};
        for (var i = 0; i < FORMAT_ATTRIBUTE_KEYS.length; i++) {
            var attributeKey = FORMAT_ATTRIBUTE_KEYS[i];
            /* 属性によっては読み取りで例外になる / some attributes throw on read */
            try {
                capturedAttributes[attributeKey] = charAttributes[attributeKey];
            } catch (e) {}
        }
        return capturedAttributes;
    }

    /**
     * 控えた書式の線カラーが「なし」か
     * @param {Object} capturedAttributes - captureFormatAttributes() の戻り値
     * @returns {boolean} 線カラーが NoColor なら true
     */
    function hasNoStroke(capturedAttributes) {
        var strokeColor = capturedAttributes.strokeColor;
        return !!strokeColor && strokeColor.typename === "NoColor";
    }

    /**
     * 控えた書式をテキスト全体に適用する
     * @param {TextFrame} textFrame - 対象のテキスト
     * @param {Object} capturedAttributes - captureFormatAttributes() の戻り値
     * @returns {void}
     */
    function applyFormatAttributes(textFrame, capturedAttributes) {
        var charAttributes = textFrame.textRange.characterAttributes;
        for (var i = 0; i < FORMAT_ATTRIBUTE_KEYS.length; i++) {
            var attributeKey = FORMAT_ATTRIBUTE_KEYS[i];
            if (!capturedAttributes.hasOwnProperty(attributeKey)) continue;
            /* 線が無いのに線幅を書くと線が付くので飛ばす / Writing a weight onto text without a stroke adds a stroke, so skip it */
            if (attributeKey === "strokeWeight" && hasNoStroke(capturedAttributes)) continue;
            /* 書き込めない値（未定義の色など）は飛ばす / skip values that cannot be written */
            try {
                charAttributes[attributeKey] = capturedAttributes[attributeKey];
            } catch (e) {}
        }
    }

    /**
     * 2つのテキストの書式を入れ替える
     * @param {TextFrame} firstTextFrame - 1つ目のテキスト
     * @param {TextFrame} secondTextFrame - 2つ目のテキスト
     * @returns {void}
     */
    function swapFormat(firstTextFrame, secondTextFrame) {
        /* 両方の書式を先に取得してから入れ替える / Capture both before applying */
        var firstAttributes = captureFormatAttributes(firstTextFrame);
        var secondAttributes = captureFormatAttributes(secondTextFrame);
        applyFormatAttributes(firstTextFrame, secondAttributes);
        applyFormatAttributes(secondTextFrame, firstAttributes);
    }

    /**
     * 2つのテキストの位置を入れ替える
     * @param {TextFrame} firstTextFrame - 1つ目のテキスト
     * @param {TextFrame} secondTextFrame - 2つ目のテキスト
     * @param {string} positionBasis - "topLeft"（外枠の左上）/ "anchorPoint"（テキストの基点）
     * @returns {void}
     */
    function swapPosition(firstTextFrame, secondTextFrame, positionBasis) {
        app.redraw(); // bounds が更新されない環境対策 / refresh stale bounds

        var deltaX, deltaY;
        if (positionBasis === "anchorPoint") {
            /* anchor = [x, y]。ベースライン上の行揃えの位置 / anchor = [x, y], on the baseline at the alignment point */
            var firstAnchor = firstTextFrame.anchor;
            var secondAnchor = secondTextFrame.anchor;
            deltaX = secondAnchor[0] - firstAnchor[0];
            deltaY = secondAnchor[1] - firstAnchor[1];
        } else {
            /*
               position はベースライン基準で上端/左端が崩れるため geometricBounds を使う。
               Use geometricBounds (not position) because TextFrame.position is baseline-based.
               geometricBounds = [left, top, right, bottom]
            */
            var firstBounds = firstTextFrame.geometricBounds;
            var secondBounds = secondTextFrame.geometricBounds;
            deltaX = secondBounds[0] - firstBounds[0];
            deltaY = secondBounds[1] - firstBounds[1];
        }

        firstTextFrame.translate(deltaX, deltaY);
        secondTextFrame.translate(-deltaX, -deltaY);
    }

    // =============================================================
    // メイン / Main
    // =============================================================

    /**
     * 選択を確かめ、ダイアログで選んだ対象を入れ替える
     * @returns {void}
     */
    function main() {
        if (app.documents.length === 0) {
            alert(getLabel(LABELS.alert.noDocument));
            return;
        }

        var doc = app.activeDocument;
        var selectedItems = doc.selection;

        /* 文字ツールで文字を選択しているときは TextRange が返り、length は文字数になる / Selecting characters with the Type tool returns a TextRange whose length is the character count */
        if (!selectedItems || selectedItems.typename === "TextRange" || selectedItems.length !== 2) {
            alert(getLabel(LABELS.alert.needTwo));
            return;
        }
        if (selectedItems[0].typename !== "TextFrame" || selectedItems[1].typename !== "TextFrame") {
            alert(getLabel(LABELS.alert.needText));
            return;
        }

        var swapChoice = showSwapDialog();
        if (swapChoice === null) {
            return;
        }
        var swapMode = swapChoice.swapMode;

        var firstTextFrame = selectedItems[0];
        var secondTextFrame = selectedItems[1];

        if (swapMode === "format") {
            swapFormat(firstTextFrame, secondTextFrame);
        } else if (swapMode === "position") {
            swapPosition(firstTextFrame, secondTextFrame, swapChoice.positionBasis);
        } else {
            swapContents(firstTextFrame, secondTextFrame);
        }
    }

    main();

})();
