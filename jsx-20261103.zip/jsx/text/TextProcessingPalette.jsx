#targetengine "SwwwitchPalettes"
#target illustrator
app.preferences.setBooleanPreference('ShowExternalJSXWarning', false);

/*
SCRIPTMETA-BEGIN
Script-ID=com.swwwitch.illustrator.TextProcessingPalette
Name=テキスト処理
Author=Masahiro Takano (@swwwitch)
Target-App=Illustrator
Version=1.11.0
Release-Date=2026-03-18
Description-BEGIN
改行・分割・連結・整形に加えて、行の入れ替えや英字のケース変換、かな変換までを1つのパレットに集約し、選択中のテキストへ即時に適用します。
選択状態に応じて、実行できる処理のボタンだけを有効化します。

A palette that gathers breaking, splitting, joining and tidying — plus reordering lines, changing letter case and converting kana — and applies them to the current selection immediately.
Only the buttons that make sense for the current selection stay enabled.
Description-END
SCRIPTMETA-END
*/

/*

### 概要

改行・分割・連結・整形に加えて、行の入れ替えや英字のケース変換、かな変換までを1つのパレットに集約し、選択中のテキストへ即時に適用します。
選択状態に応じて、実行できる処理のボタンだけを有効化します。

詳細は README を参照してください。
https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/TextProcessingPalette.md

note記事も参照してください。
https://note.com/dtp_tranist/n/nf6f34559ba46

### Overview

A palette that gathers breaking, splitting, joining and tidying — plus reordering lines, changing letter case and converting kana — and applies them to the current selection immediately.
Only the buttons that make sense for the current selection stay enabled.

See the README for details.
https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/TextProcessingPalette.md

*/

// =========================================
// 基本情報 / Basic info
// =========================================
var SCRIPT_NAME     = "TextProcessingPalette";        /* スクリプト名 / script name */
var SCRIPT_VERSION  = "v1.11.0";                      /* バージョン / version */
var SCRIPT_AUTHOR   = "Masahiro Takano (@swwwitch)";  /* 作者 / author */
var SCRIPT_RELEASED = "2026-03-18";                   /* 最初のリリース日 / first release date */
var SCRIPT_UPDATED  = "2026-10-27";                   /* 更新日 / last updated */

var SCRIPT_DESCRIPTION_JA = "テキスト処理"; /* README の見出し / README title (Japanese) */

var SCRIPT_README_JA   = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/TextProcessingPalette.md"; /* README（日本語） */
var SCRIPT_README_EN   = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/TextProcessingPalette.md"; /* README (English) */
var SCRIPT_ARTICLE_URL = "https://note.com/dtp_tranist/n/nf6f34559ba46"; /* 紹介記事 / article URL */
var SCRIPT_SOURCE_URL  = "https://github.com/swwwitch/illustrator-scripts/blob/master/jsx/text/TextProcessingPalette.jsx"; /* 最新版のソース / latest source */

// Released under the MIT license
// http://opensource.org/licenses/mit-license.php

(function () {

    /* 「指定文字で改行」の初期値 / Default characters for "break at specified characters" */
    var DEFAULT_BREAK_CHARS = "、。，．｡､,.!?！？";

    /* 「指定文字で改行」で直前に改行を入れる文字の初期値 / Default characters to break before */
    var DEFAULT_BREAK_BEFORE_CHARS = "・•→";

    /* 「指定文字数で改行」の初期値 / Default character count for "break at character count" */
    var DEFAULT_BREAK_COUNT = "35";

    /* 変換プレビューに表示する最大文字数 / Maximum characters shown in the conversion preview */
    var PREVIEW_MAX_CHARS = 40;

    /* 選択ステータスを取り直す最小間隔（ミリ秒）/ Minimum interval between selection status polls */
    var STATUS_POLL_INTERVAL_MS = 400;

    // =========================================
    // 処理パラメーター / Processing parameters
    // （メインエンジンでも同じ値を参照する。__WORKER_CONSTANTS 参照）
    // =========================================

    var LINE_Y_THRESHOLD     = 5;    /* 横連結で同じ行と見なすY座標差（pt）*/
    var AUTO_LEADING_RATIO   = 1.2;  /* 行送りが取得できないときのフォントサイズ比 */
    var MIN_LEADING_RATIO    = 1.2;  /* 連結後の行送りの下限（フォントサイズ比）*/
    var DEFAULT_FONT_SIZE_PT = 12;   /* 文字サイズが取得できないときの既定値（pt）*/
    var BOX_FIT_STEPS        = 16;   /* 枠を1行の幅に詰めるときの二分探索の上限回数 */
    var BOX_FIT_TOLERANCE    = 0.5;  /* 枠を1行の幅に詰めるときの精度（pt）*/

    // =========================================
    // レイアウト / Layout
    // =========================================

    // UIレイアウト（再利用パーツ） / UI layout (reusable)

    /* ウィンドウ・パネルの余白と間隔 / Window & panel margins and spacing */
    var WINDOW_MARGINS = 16;                 /* ウィンドウ外周の余白 / window margin */
    var WINDOW_SPACING = 12;                 /* ウィンドウ内の要素間隔 / window spacing */
    var PANEL_MARGINS  = [16, 20, 16, 12];   /* パネル余白 [左,上,右,下] / panel margins */
    var PANEL_SPACING  = 12;                 /* パネル内の要素間隔 / panel spacing */
    var COLUMN_SPACING = 12;                 /* 2カラムの間隔 / gap between columns */
    var TAB_MARGINS    = [15, 20, 5, 10];    /* タブ余白 [左,上,右,下] / tab margins */

    /**
     * ウィンドウの共通設定
     * @param {Window} targetWindow - 対象のウィンドウ
     * @param {number} [spacing] - 要素間隔（省略時は WINDOW_SPACING）
     * @returns {void}
     */
    function setupWindow(targetWindow, spacing) {
        targetWindow.orientation = "column";
        targetWindow.alignChildren = "fill";
        targetWindow.margins = WINDOW_MARGINS;
        targetWindow.spacing = (typeof spacing === "number") ? spacing : WINDOW_SPACING;
    }

    /**
     * パネルの共通設定（子は幅いっぱい。ボタンは alignment = "left" で広げない）
     * @param {Panel} targetPanel - 対象のパネル
     * @param {number} [spacing] - 要素間隔（省略時は PANEL_SPACING）
     * @returns {void}
     */
    function setupPanel(targetPanel, spacing) {
        targetPanel.orientation = "column";
        targetPanel.alignChildren = ["fill", "top"];
        targetPanel.alignment = "fill";
        targetPanel.margins = PANEL_MARGINS;
        targetPanel.spacing = (typeof spacing === "number") ? spacing : PANEL_SPACING;
    }

    /**
     * タブの共通設定
     * @param {Tab} targetTab - 対象のタブ
     * @param {number} [spacing] - 要素間隔（省略時は変えない）
     * @returns {void}
     */
    function setupTab(targetTab, spacing) {
        targetTab.orientation = "column";
        targetTab.alignChildren = "fill";
        targetTab.margins = TAB_MARGINS;
        if (typeof spacing === "number") targetTab.spacing = spacing;
    }

    /**
     * 横並びの行グループの共通設定（ボタン列など）。
     * alignment と alignChildren を対で指定し、中のボタンが横に伸びたり天地がずれたりしないようにする
     * @param {Group} rowGroup - 対象のグループ
     * @param {string|string[]} [rowAlignment] - 横方向の alignment（省略時は "left"）。配列ならそのまま使う
     * @param {number} [spacing] - 要素間隔（省略時は PANEL_SPACING）
     * @returns {void}
     */
    function setupRow(rowGroup, rowAlignment, spacing) {
        rowGroup.orientation = "row";
        rowGroup.alignment = (rowAlignment instanceof Array) ? rowAlignment : [rowAlignment || "left", "center"];
        rowGroup.alignChildren = ["left", "center"];
        rowGroup.spacing = (typeof spacing === "number") ? spacing : PANEL_SPACING;
    }

    /**
     * ボタンの高さを指定した px だけ詰める（レイアウトが決まったあとに呼ぶ）
     * @param {Button} targetButton - 対象のボタン
     * @param {number} trimPixels - 詰める量（px）
     * @returns {void}
     */
    function trimButtonHeight(targetButton, trimPixels) {
        /* レイアウト前は size が無い / size is not set until the layout runs */
        if (!targetButton.size) return;
        targetButton.size = [targetButton.size.width, targetButton.size.height - trimPixels];
    }

    // UIレイアウト（再利用パーツ）ここまで / End of the reusable UI layout

    /* パレット固有の寸法 / Palette-specific sizes */
    var STATUS_MARGINS      = [50, 18, 50, 8];   /* ステータスパネル余白 */
    var TAB_SPACING         = 15;                /* タブ内の要素間隔 */
    var FOOTER_MARGINS      = [10, 10, 10, 0];   /* フッター余白 */
    var BUTTON_ROW_MARGINS  = [10, 0, 10, 8];    /* パネル内ボタン列の余白 */
    var STATUS_ROW_SPACING  = 16;                /* ステータス2カラムの間隔 */
    var STATUS_LABEL_WIDTH  = 72;                /* ステータス右カラムのラベル幅 */
    var LINE_LIST_SIZE      = [200, 460];        /* 行リストボックスのサイズ */
    var LINE_LIST_FONT_SIZE = 18;                /* 行リストボックスの文字サイズ */
    var CONVERT_BUTTON_SIZE    = [150, 24];         /* 変換ボタンのサイズ */
    var CONVERT_PREVIEW_SIZE   = [120, 24];         /* 変換プレビューのサイズ */

    /**
     * ラベル付きパネルを生成し、共通レイアウトを適用する
     * @param {Window|Panel|Group} parent - 追加先のコンテナ
     * @param {string} titleText - パネルのタイトル
     * @param {Array<string>} alignChildren - 子要素の整列指定（省略時は ["fill", "center"]）
     * @returns {Panel} 生成したパネル
     */
    function addPanel(parent, titleText, alignChildren) {
        var panel = parent.add("panel", undefined, titleText);
        setupPanel(panel);
        panel.alignment = ["fill", "top"];
        panel.alignChildren = alignChildren || ["fill", "center"];
        return panel;
    }

    /**
     * パネル内の項目を区切る横線を追加する
     * @param {Panel|Group} parent - 追加先のコンテナ
     * @returns {Panel} 生成した線
     */
    function addDivider(parent) {
        var divider = parent.add("panel", undefined, undefined);
        divider.alignment = ["fill", "center"];
        divider.preferredSize.height = 1;
        return divider;
    }

    /**
     * 縦積みのカラムグループを生成する
     * @param {Window|Panel|Group} parent - 追加先のコンテナ
     * @returns {Group} 生成したグループ
     */
    function addColumnGroup(parent) {
        var columnGroup = parent.add("group");
        columnGroup.orientation = "column";
        columnGroup.alignment = ["fill", "top"];
        columnGroup.alignChildren = ["fill", "top"];
        return columnGroup;
    }

    /**
     * タブへパレット用のレイアウトを適用する（余白は setupTab()、並びの向きと揃えはタブごと）
     * @param {Object} tab - 対象タブ
     * @param {string} orientation - "row" または "column"
     * @param {Array<string>} alignment - タブ自身の整列指定（省略時は ["fill", "top"]）
     * @returns {void}
     */
    function setupPaletteTab(tab, orientation, alignment) {
        setupTab(tab, TAB_SPACING);
        tab.orientation = orientation;
        tab.alignment = alignment || ["fill", "top"];
        tab.alignChildren = ["fill", "top"];
    }

    // UI の明暗（再利用パーツ） / UI theme (reusable)

    /**
     * UI がダークテーマかどうかを判定する（Illustrator は uiBrightness、InDesign は uiBrightnessPreference）
     * @returns {boolean} ダークなら true。取得できない環境では false（明るいUI扱い）
     */
    function isDarkUI() {
        try {
            if (app.preferences && app.preferences.getRealPreference) {
                return app.preferences.getRealPreference("uiBrightness") <= 0.5; /* Illustrator */
            }
            return app.generalPreferences.uiBrightnessPreference <= 0.5; /* InDesign */
        } catch (e) {
            return false;
        }
    }

    // UI の明暗（再利用パーツ）ここまで / End of the reusable UI theme

    // ステップボタン（再利用パーツ） / Stepper buttons (reusable)

    // -----------------------------------------
    // ステップボタンの寸法・増減量 / Stepper metrics and steps
    // -----------------------------------------
    var STEPPER_BUTTON_WIDTH   = 20;  /* ∧∨ボタンの幅 / button width */
    var STEPPER_BUTTON_HEIGHT  = 11;  /* ∧∨ボタン1つの高さ（2つ重ねた全体の高さは22） / button height (22 for the pair) */
    var STEPPER_CORNER_RADIUS  = 2;   /* 枠の角丸の半径（ScriptUIは円弧を描けないため短い線分で近似） / corner radius, approximated with segments */
    var STEPPER_FIELD_SPACING  = 3;   /* 項目名と∧∨の間隔 / spacing between the label and the stepper */
    var STEPPER_SIDE_MARGIN    = 3;   /* ∧∨の左に足す余白（右は入力欄に突き合わせる） / extra space left of the stepper */
    var STEPPER_SHIFT_MULTIPLE = 10;  /* shift＋クリックでそろえる倍数 / Shift-click snaps to multiples of this */
    var STEPPER_OPTION_STEP    = 0.1; /* option＋クリックの増減量 / Option-click step */

    /* 単位の換算は UnitValue に任せる（in / ft / yd / mm / cm / m / pt / pc / px ほか、単数形・複数形も可）。
       UnitValue に無い単位だけ、ここで UnitValue の単位に読み替える（値は「1単位＝何 unit か」）。
       「p」は「1p6」（1パイカ6ポイント）の形にも使う
       Units UnitValue lacks, mapped onto UnitValue units (how many of `unit` make one) */
    var STEPPER_UNIT_ALIASES = {
        "q": { unit: "mm", amount: 0.25 }, /* 級 / Q */
        "h": { unit: "mm", amount: 0.25 }, /* 歯 / H */
        "p": { unit: "pc", amount: 1 }     /* パイカ / pica */
    };

    // -----------------------------------------
    // ステップボタンの配色 / Stepper colors
    // -----------------------------------------
    var STEPPER_UI_DARK           = isDarkUI();
    /* UIの明るさは4段階あり、段階ごとに背景色が違う。どの段階でも背景に対する差で見せるよう、黒・白の半透明を重ねる。
       ダーク側は Illustrator 標準のスピナー（［グリッドに分割］）で実測、明るい側は最も明るい段階（背景 約0.94）から逆算
       UI brightness has four levels with different backgrounds, so colors are translucent overlays that follow the
       dialog background. Dark values are measured from Illustrator's own spinner; light values derived for the lightest level */
    var STEPPER_FILL_COLOR        = STEPPER_UI_DARK ? [0, 0, 0, 0.10]  : [1, 1, 1, 0.50];  /* 地 / background */
    var STEPPER_FRAME_COLOR       = STEPPER_UI_DARK ? [1, 1, 1, 0.07]  : [0, 0, 0, 0.10];  /* 枠線 / frame */
    var STEPPER_PRESSED_COLOR     = STEPPER_UI_DARK ? [1, 1, 1, 0.12]  : [0, 0, 0, 0.13];  /* 押下中 / pressed */
    var STEPPER_CHEVRON_COLOR     = STEPPER_UI_DARK ? [1, 1, 1, 1]     : [0, 0, 0, 0.70];  /* 山形の線 / chevron */
    var STEPPER_DIM_FILL_COLOR    = STEPPER_UI_DARK ? [1, 1, 1, 0.035] : [1, 1, 1, 0.30];  /* 無効時の地 / background when disabled */
    var STEPPER_DIM_FRAME_COLOR   = STEPPER_UI_DARK ? [1, 1, 1, 0.035] : [0, 0, 0, 0.05];  /* 無効時の枠線（ダークは地と同じで見せない） / frame when disabled */
    var STEPPER_DIM_CHEVRON_COLOR = STEPPER_UI_DARK ? [1, 1, 1, 0.20]  : [0, 0, 0, 0.25];  /* 無効時の山形 / chevron when disabled */

    // -----------------------------------------
    // 数値欄を作る（外から呼ぶ関数） / Public API
    // -----------------------------------------
    /**
     * 「項目名・∧∨・入力欄」をひと組にした数値欄を追加する。
     * ↑↓キーでも∧∨と同じように増減する。直接入力した値も、フォーカスが外れたときに
     * 整数化・下限・上限・単位（「20 mm」の形）へそろえ、数値でなければ直前の値に戻す。
     * 四則演算（+ - * / と括弧）を入れると、確定時に計算した値にする。欄と違う単位で入れた値は欄の単位へ換算する（mm の欄に「1 in」→「25.4 mm」）
     * @param {Group|Panel} parent - 追加先
     * @param {Object} fieldOptions - label（コロン込みの項目名）/ labelWidth / text / characters /
     *     step / min / max / integer（true で整数のみ）/ unit / onStep
     * @returns {EditText} 入力欄（項目名は .fieldLabel、∧∨は .stepperGroup で参照できる）
     */
    function addSteppedField(parent, fieldOptions) {
        var fieldRowGroup = parent.add("group");
        fieldRowGroup.orientation = "row";
        fieldRowGroup.alignChildren = ["left", "center"];
        fieldRowGroup.spacing = STEPPER_FIELD_SPACING;

        var fieldLabel = fieldRowGroup.add("statictext", undefined, fieldOptions.label || "");
        if (fieldOptions.labelWidth) {
            fieldLabel.preferredSize.width = fieldOptions.labelWidth;
            fieldLabel.justify = "right";
        }

        /* ∧∨と入力欄は隙間0で突き合わせる / butt the stepper against the field */
        var stepperInputGroup = fieldRowGroup.add("group");
        stepperInputGroup.orientation = "row";
        stepperInputGroup.alignChildren = ["left", "center"];
        stepperInputGroup.spacing = 0;
        stepperInputGroup.margins = 0;

        var numberInput;
        var stepperGroup = addStepper(stepperInputGroup, function () { return numberInput; }, fieldOptions);
        numberInput = stepperInputGroup.add("edittext", undefined, fieldOptions.text || "");
        numberInput.characters = fieldOptions.characters || 6;
        numberInput.fieldLabel = fieldLabel;
        numberInput.stepperGroup = stepperGroup;

        /* ↑↓キーも∧∨と同じ処理で増減する（増減量・下限・上限・単位・修飾キーをそろえる） / arrow keys share the stepper's logic */
        bindSteppedArrowKeys(numberInput, stepperGroup);

        /* 項目名のクリックで入力欄にフォーカスを移す / clicking the label focuses the field */
        fieldLabel.addEventListener("click", function () { focusNumberInput(numberInput); });

        /* 直接入力をそろえる。計算式は計算し、数値でなければ直前の値に戻す / normalize typed values; evaluate arithmetic, revert non-numbers */
        numberInput.lastValidText = numberInput.text;
        numberInput.onChange = function () {
            var value = evaluateArithmetic(numberInput.text, fieldOptions.unit);
            if (isNaN(value)) {
                numberInput.text = numberInput.lastValidText;
                return;
            }
            writeSteppedValue(numberInput, value, fieldOptions);
        };
        return numberInput;
    }

    /**
     * 数値欄の有効／無効を、項目名・∧∨ごとまとめて切り替える
     * @param {EditText} numberInput - addSteppedField() で作った入力欄
     * @param {boolean} isEnabled - 有効にするなら true
     * @returns {void}
     */
    function setSteppedFieldEnabled(numberInput, isEnabled) {
        numberInput.enabled = isEnabled;
        numberInput.fieldLabel.enabled = isEnabled;
        numberInput.stepperGroup.enabled = isEnabled;
        /* ∧∨は自作描画なので、描き直してディム表示を切り替える / redraw the custom-drawn buttons to update the dimming */
        for (var i = 0; i < numberInput.stepperGroup.children.length; i++) {
            redrawStepperGroup(numberInput.stepperGroup.children[i]);
        }
    }

    /**
     * 入力欄の値を増減する∧∨ボタンを、隙間なく縦に積んで追加する
     * @param {Group|Panel} parent - 追加先
     * @param {Function} getNumberInput - 対象の入力欄を返す関数（入力欄を∧∨より後に作れるよう、クリック時に引く）
     * @param {Object} stepOptions - step（増減量）/ min / max / integer / unit（例 " mm"）/ onStep(numberInput)
     * @returns {Group} ∧∨をまとめた group（.stepBy(direction) で同じ増減を呼べる）
     */
    function addStepper(parent, getNumberInput, stepOptions) {
        var stepperGroup = parent.add("group");
        stepperGroup.orientation = "column";
        stepperGroup.spacing = 0; /* 2つのボタンをつなげて1つの枠に見せる / join the buttons into one frame */
        stepperGroup.margins = [STEPPER_SIDE_MARGIN, 0, 0, 0]; /* 右は入力欄に突き合わせる / butt against the field on the right */
        stepperGroup.alignment = ["left", "center"];

        /**
         * 入力欄の値を増減する（shift を押しながらなら STEPPER_SHIFT_MULTIPLE の倍数へ、option なら STEPPER_OPTION_STEP ずつ。下限・上限で止める）
         * @param {number} direction - 増やすなら 1、減らすなら -1
         * @returns {void}
         */
        function stepBy(direction) {
            var numberInput = getNumberInput();
            if (!isStepperEnabledInTree(numberInput)) return; /* 入力欄か親が無効の間は動かさない */
            var value = evaluateArithmetic(numberInput.text, stepOptions.unit); /* 確定前の計算式も計算してから増減 / evaluate an uncommitted expression first */
            if (isNaN(value)) value = parseFloat(numberInput.text); /* 計算できなければ従来どおり先頭の数値 / fall back to the leading number */
            if (isNaN(value)) value = 0;
            writeSteppedValue(numberInput, computeSteppedValue(value, direction, stepOptions), stepOptions);
            if (stepOptions.onStep) stepOptions.onStep(numberInput);
        }

        /**
         * ∧∨を離したときに入力欄へフォーカスを移す（mousedown で移しても、離したときに外れる）
         * @param {Group} chevronButton - makeStepperChevronButton() で作ったボタン
         * @returns {Group} 渡したボタン
         */
        function focusInputOnRelease(chevronButton) {
            chevronButton.addEventListener("mouseup", function () {
                var numberInput = getNumberInput();
                if (isStepperEnabledInTree(numberInput)) focusNumberInput(numberInput);
            });
            return chevronButton;
        }

        /* 整数の欄では option＋クリックの0.1刻みが効かないので、説明から外す / integer fields have no 0.1 step */
        var upTooltip = stepOptions.integer ? LABELS.tooltip.stepUpInteger : LABELS.tooltip.stepUp;
        var downTooltip = stepOptions.integer ? LABELS.tooltip.stepDownInteger : LABELS.tooltip.stepDown;
        focusInputOnRelease(makeStepperChevronButton(stepperGroup, "up", function () { stepBy(1); })).helpTip = getLabel(upTooltip);
        focusInputOnRelease(makeStepperChevronButton(stepperGroup, "down", function () { stepBy(-1); })).helpTip = getLabel(downTooltip);
        stepperGroup.stepBy = stepBy; /* ↑↓キーからも同じ処理で増減できるよう公開 / shared with the arrow keys */
        stepperGroup.stepOptions = stepOptions; /* 確定時の計算で欄の単位を引けるよう公開 / lets the commit-time evaluation find the unit */
        return stepperGroup;
    }

    /**
     * 入力欄の↑↓キーを、∧∨と同じ処理で増減させる。ほかのキーは素通し。
     * あわせて、確定時に計算式・単位付きの値を計算して書き戻す（各スクリプトの onChange より先に呼ばれるので、onChange は計算後の値を読む）
     * @param {EditText} numberInput - 対象の入力欄
     * @param {Group} stepperGroup - addStepper() で作った∧∨
     * @returns {void}
     */
    function bindSteppedArrowKeys(numberInput, stepperGroup) {
        numberInput.addEventListener("keydown", function (event) {
            if (event.keyName !== "Up" && event.keyName !== "Down") return;
            stepperGroup.stepBy(event.keyName === "Up" ? 1 : -1);
            event.preventDefault(); /* カーソル移動を止める / keep the caret from moving */
        });
        numberInput.addEventListener("change", function () {
            var fieldUnit = stepperGroup.stepOptions ? stepperGroup.stepOptions.unit : undefined;
            var value = evaluateArithmetic(numberInput.text, fieldUnit);
            if (isNaN(value)) return; /* 計算できなければ各スクリプトの処理に任せる / leave it to the script's own handler */
            /* 式か、換算で値が変わったときだけ書き戻す（ただの数値は書式を崩さない） / rewrite only expressions and converted values */
            var hasOperator = /[*\/()\u00D7\u00F7\uFF0A\uFF0F\uFF08\uFF09]|[\d.\uFF10-\uFF19][^\d.\uFF10-\uFF19]*[+\-\u2212\uFF0B\uFF0D]/.test(numberInput.text);
            if (!hasOperator && value === parseFloat(numberInput.text)) return;
            numberInput.text = formatStepperNumber(value) + (fieldUnit || "");
        });
    }

    // -----------------------------------------
    // 値の計算 / Value helpers
    // -----------------------------------------
    /**
     * 押された修飾キーに応じて、1回分増減した値を返す
     * （shift なら STEPPER_SHIFT_MULTIPLE の倍数へ、option なら STEPPER_OPTION_STEP ずつ、それ以外は step の倍数へ（1.5→2、1.5→1）。
     * 整数の欄では option を無視して step の倍数へ）
     * @param {number} value - 元の値
     * @param {number} direction - 増やすなら 1、減らすなら -1
     * @param {Object} stepOptions - step（通常の増減量。省略時は 1）/ integer
     * @returns {number} 増減した値（下限・上限は未適用）
     */
    function computeSteppedValue(value, direction, stepOptions) {
        var keyState = ScriptUI.environment.keyboardState;
        if (keyState.shiftKey) return snapStepperToNextMultiple(value, STEPPER_SHIFT_MULTIPLE, direction);
        if (keyState.altKey && !stepOptions.integer) return value + direction * STEPPER_OPTION_STEP;
        return snapStepperToNextMultiple(value, stepOptions.step || 1, direction);
    }

    /**
     * 値を、指定した方向にある次の倍数へ移す（230→240、232→240、下げるときは 232→230、230→220）
     * @param {number} value - 元の値
     * @param {number} multiple - 倍数の単位（例 10）
     * @param {number} direction - 上げるなら 1、下げるなら -1
     * @returns {number} 移した値
     */
    function snapStepperToNextMultiple(value, multiple, direction) {
        /* 0.29 / 0.01 = 28.999… のような浮動小数の誤差で同じ値に戻らないよう、商を丸めてから切り捨て・切り上げる
           round the quotient first so float error (0.29 / 0.01 = 28.999…) does not step back to the same value */
        var quotient = Math.round(value / multiple * 1e6) / 1e6;
        if (direction > 0) return Math.round((Math.floor(quotient) + 1) * multiple * 1e6) / 1e6;
        return Math.round((Math.ceil(quotient) - 1) * multiple * 1e6) / 1e6;
    }

    /**
     * 値を下限・上限の範囲に収める
     * @param {number} value - 数値
     * @param {Object} rangeOptions - min / max（どちらも省略可）
     * @returns {number} 範囲に収めた値
     */
    function clampSteppedValue(value, rangeOptions) {
        if (rangeOptions.min !== undefined && value < rangeOptions.min) return rangeOptions.min;
        if (rangeOptions.max !== undefined && value > rangeOptions.max) return rangeOptions.max;
        return value;
    }

    /**
     * 入力欄の文字列を四則演算（+ - * / と括弧）として計算する。eval は使わない。
     * 数値の後ろの単位は UnitValue で欄の単位へ換算する（mm の欄に「1in」→ 25.4、「1p6」は1パイカ6ポイント）。単位のない数値は欄の単位とみなす。
     * 全角の数字・記号と × ÷ は半角に直す
     * @param {string} text - 入力欄の文字列
     * @param {string} [fieldUnit] - 欄の単位（例 " mm"。前後の空白は無視）
     * @returns {number} 欄の単位での計算結果（式として読めない・換算できない単位・0で割ったときは NaN）
     */
    function evaluateArithmetic(text, fieldUnit) {
        var source = String(text)
            .replace(/[！-～]/g, function (ch) { return String.fromCharCode(ch.charCodeAt(0) - 0xFEE0); })
            .replace(/×/g, "*")
            .replace(/÷/g, "/")
            .replace(/[−–—]/g, "-")
            .replace(/\s/g, "");
        if (source === "") return NaN;
        var fieldUnitKey = String(fieldUnit || "").replace(/^\s+|\s+$/g, "").toLowerCase();
        var fieldUnitValue = createStepperUnitValue(1, fieldUnitKey); /* 欄の単位の1単位（換算できない欄は null） / one field unit */
        var position = 0;

        /**
         * 加減算の並び（項 ± 項 …）を読む
         * @returns {number} 値（読めなければ NaN）
         */
        function readSum() {
            var total = readProduct();
            while (position < source.length && (source.charAt(position) === "+" || source.charAt(position) === "-")) {
                var operator = source.charAt(position++);
                var operand = readProduct();
                total = (operator === "+") ? total + operand : total - operand;
            }
            return total;
        }

        /**
         * 乗除算の並び（因子 × 因子 …）を読む
         * @returns {number} 値（読めなければ NaN）
         */
        function readProduct() {
            var total = readFactor();
            while (position < source.length && (source.charAt(position) === "*" || source.charAt(position) === "/")) {
                var operator = source.charAt(position++);
                var operand = readFactor();
                if (operator === "/" && operand === 0) return NaN;
                total = (operator === "*") ? total * operand : total / operand;
            }
            return total;
        }

        /**
         * 符号付きの数値（単位付きなら欄の単位へ換算）か、括弧で囲んだ式を読む
         * @returns {number} 値（読めなければ NaN）
         */
        function readFactor() {
            var ch = source.charAt(position);
            if (ch === "+" || ch === "-") {
                position++;
                var signedValue = readFactor();
                return (ch === "-") ? -signedValue : signedValue;
            }
            if (ch === "(") {
                position++;
                var innerValue = readSum();
                if (source.charAt(position) !== ")") return NaN;
                position++;
                return innerValue;
            }
            var numberMatch = /^(\d+\.?\d*|\.\d+)/.exec(source.substring(position));
            if (!numberMatch) return NaN;
            position += numberMatch[0].length;
            return readUnitSuffix(parseFloat(numberMatch[0]));
        }

        /**
         * 数値の直後の単位を読み、欄の単位へ換算する
         * @param {number} value - 単位の前の数値
         * @returns {number} 欄の単位での値（換算できない単位なら NaN）
         */
        function readUnitSuffix(value) {
            var unitMatch = /^([A-Za-z]+|%|°)/.exec(source.substring(position));
            if (!unitMatch) return value; /* 単位なしは欄の単位 / no unit means the field's unit */
            position += unitMatch[0].length;
            var unitKey = unitMatch[0].toLowerCase();
            if (unitKey === fieldUnitKey) return value;
            var typedValue = createStepperUnitValue(value, unitKey);
            if (!typedValue || !fieldUnitValue) return NaN; /* 知らない単位・単位のない欄 / unknown unit or unitless field */
            var points = typedValue.as("pt");
            /* 「1p6」＝1パイカ6ポイント / pica-point notation */
            if (unitKey === "p") {
                var pointMatch = /^(\d+\.?\d*|\.\d+)/.exec(source.substring(position));
                if (pointMatch) {
                    position += pointMatch[0].length;
                    points += parseFloat(pointMatch[0]);
                }
            }
            return points / fieldUnitValue.as("pt");
        }

        var result = readSum();
        if (position !== source.length || !isFinite(result)) return NaN; /* 読み残しがあれば式として不正 / leftovers mean a malformed expression */
        return result;
    }

    /**
     * 数値と単位から UnitValue を作る。Q・H・p は STEPPER_UNIT_ALIASES で UnitValue の単位に読み替える。
     * %（percent）は基準の長さが無いと換算できないので扱わない
     * @param {number} value - 数値
     * @param {string} unitKey - 単位（小文字。例 "mm"、"inches"、"q"）
     * @returns {UnitValue|null} UnitValue（UnitValue が知らない単位・空・% なら null）
     */
    function createStepperUnitValue(value, unitKey) {
        if (unitKey === "" || unitKey === "%") return null;
        var alias = STEPPER_UNIT_ALIASES[unitKey];
        var unitValue = alias ? new UnitValue(value * alias.amount, alias.unit) : new UnitValue(value, unitKey);
        if (unitValue.type === "?" || unitValue.type === "%") return null; /* 知らない単位は例外にならず "?" になる。"percent" も除く / unknown units become "?" */
        return unitValue;
    }

    /**
     * 値を整数化・下限・上限でそろえ、単位を付けて入力欄に書き込む（直前の正しい値としても控える）
     * @param {EditText} numberInput - 書き込む入力欄
     * @param {number} value - 数値
     * @param {Object} valueOptions - integer / min / max / unit（どれも省略可）
     * @returns {void}
     */
    function writeSteppedValue(numberInput, value, valueOptions) {
        numberInput.text = formatSteppedValue(value, valueOptions);
        numberInput.lastValidText = numberInput.text;
    }

    /**
     * 値を整数化・下限・上限でそろえ、丸めて単位を付けた表示用の文字列にする。
     * 整数化してから下限で止めるので、「整数・下限1」の欄に 0.4 が入っても 1 になる
     * @param {number} value - 数値
     * @param {Object} valueOptions - integer / min / max / unit（どれも省略可）
     * @returns {string} 入力欄に入れる文字列（例 "20 mm"）
     */
    function formatSteppedValue(value, valueOptions) {
        if (valueOptions.integer) value = Math.round(value);
        return formatStepperNumber(clampSteppedValue(value, valueOptions)) + (valueOptions.unit || "");
    }

    /**
     * 小数第2位で丸めた数値を文字列で返す
     * @param {number} value - 数値
     * @returns {string} 表示用の数値文字列
     */
    function formatStepperNumber(value) {
        return String(Math.round(value * 100) / 100);
    }

    // -----------------------------------------
    // ∧∨ボタンの描画 / Drawing
    // -----------------------------------------
    /**
     * 山形（∧／∨）の極小ボタンを作成する。
     * 上下2つを隙間なく積んで1つの枠に見えるよう、枠線は外側の辺だけ描き（上ボタンは上側、下ボタンは下側）、
     * 継ぎ目に線は引かない
     * @param {Group|Panel} parent - 追加先
     * @param {string} direction - "up" または "down"
     * @param {Function} onClickFn - クリック時の処理
     * @returns {Group} ボタンとして使う group
     */
    function makeStepperChevronButton(parent, direction, onClickFn) {
        var buttonWidth = STEPPER_BUTTON_WIDTH;
        var buttonHeight = STEPPER_BUTTON_HEIGHT;
        var isUp = (direction === "up");
        var chevronBox = parent.add("group");
        chevronBox.margins = 0;
        chevronBox.spacing = 0;
        chevronBox.preferredSize = [buttonWidth, buttonHeight];
        chevronBox.minimumSize = [buttonWidth, buttonHeight];
        chevronBox.maximumSize = [buttonWidth, buttonHeight];
        chevronBox.isPressed = false;
        chevronBox.isStepperButton = true; /* redrawSteppersIn() の目印 / marker for redrawSteppersIn() */

        chevronBox.onDraw = function () {
            var boxGraphics = chevronBox.graphics;
            /* 自作描画は自動でディムにならないため、無効なら薄い色で描く。親の無効化は子の enabled に出ないので親も見る
               Custom drawing is not dimmed automatically; the parent's state does not reach the child's enabled */
            var isDimmed = !isStepperEnabledInTree(chevronBox);

            /* 枠線の内側の地（押下中は押下色） / background inside the frame, pressed color while pressed */
            var fillColor = isDimmed ? STEPPER_DIM_FILL_COLOR : (chevronBox.isPressed ? STEPPER_PRESSED_COLOR : STEPPER_FILL_COLOR);
            boxGraphics.newPath();
            boxGraphics.rectPath(1, isUp ? 1 : 0, buttonWidth - 2, buttonHeight - 1);
            boxGraphics.fillPath(boxGraphics.newBrush(boxGraphics.BrushType.SOLID_COLOR, fillColor));

            drawStepperFrame(boxGraphics, buttonWidth, buttonHeight, isUp, isDimmed ? STEPPER_DIM_FRAME_COLOR : STEPPER_FRAME_COLOR);
            drawStepperChevron(boxGraphics, buttonWidth, buttonHeight, isUp, isDimmed ? STEPPER_DIM_CHEVRON_COLOR : STEPPER_CHEVRON_COLOR);
        };

        /**
         * 押下状態を変えて描き直す
         * @param {boolean} isPressed - 押下中なら true
         * @returns {void}
         */
        function repaint(isPressed) {
            if (chevronBox.isPressed === isPressed) return;
            chevronBox.isPressed = isPressed;
            redrawStepperGroup(chevronBox);
        }
        chevronBox.addEventListener("mousedown", function () {
            if (!isStepperEnabledInTree(chevronBox)) return;
            repaint(true);
            if (onClickFn) onClickFn();
        });
        chevronBox.addEventListener("mouseup", function () { repaint(false); });
        /* 押したまま外へ出たときも押下色を残さない / reset when the pointer leaves while pressed */
        chevronBox.addEventListener("mouseout", function () { repaint(false); });
        return chevronBox;
    }

    /**
     * 外側の辺だけの枠を描く（角は丸める）。継ぎ目側は開けておき、上下2つで1つの枠に見せる。
     * ScriptUI は円弧を描けないため、角丸は短い線分で近似する
     * @param {ScriptUIGraphics} boxGraphics - 描画先
     * @param {number} boxWidth - ボタンの幅
     * @param {number} boxHeight - ボタンの高さ
     * @param {boolean} isUp - 上のボタンなら true（上側に枠を描く）
     * @param {number[]} frameColor - [r, g, b, a]
     * @returns {void}
     */
    function drawStepperFrame(boxGraphics, boxWidth, boxHeight, isUp, frameColor) {
        var frameLeft = 0.5;
        var frameRight = boxWidth - 0.5;
        var outerY = isUp ? 0.5 : boxHeight - 0.5;
        var seamY = isUp ? boxHeight : 0;
        var towardSeam = isUp ? 1 : -1; /* 外側の辺から継ぎ目へ向かう向き / direction from the outer edge to the seam */
        var radius = STEPPER_CORNER_RADIUS;
        var arcSteps = 4; /* 角丸1つを何本の線分で近似するか / segments per corner */
        var angle, k;

        boxGraphics.newPath();
        boxGraphics.moveTo(frameLeft, seamY);
        /* 左の角丸 / left corner */
        for (k = 0; k <= arcSteps; k++) {
            angle = (Math.PI / 2) * k / arcSteps;
            boxGraphics.lineTo(frameLeft + radius - radius * Math.cos(angle), outerY + towardSeam * (radius - radius * Math.sin(angle)));
        }
        /* 右の角丸 / right corner */
        for (k = 0; k <= arcSteps; k++) {
            angle = (Math.PI / 2) * k / arcSteps;
            boxGraphics.lineTo(frameRight - radius + radius * Math.sin(angle), outerY + towardSeam * (radius - radius * Math.cos(angle)));
        }
        boxGraphics.lineTo(frameRight, seamY);
        boxGraphics.strokePath(boxGraphics.newPen(boxGraphics.PenType.SOLID_COLOR, frameColor, 1));
    }

    /**
     * 山形（∧／∨）を描く。文字グリフの▲▼は上下で大きさやベースラインが揃わないため、線で描く
     * @param {ScriptUIGraphics} boxGraphics - 描画先
     * @param {number} boxWidth - ボタンの幅
     * @param {number} boxHeight - ボタンの高さ
     * @param {boolean} isUp - ∧なら true、∨なら false
     * @param {number[]} chevronColor - [r, g, b, a]
     * @returns {void}
     */
    function drawStepperChevron(boxGraphics, boxWidth, boxHeight, isUp, chevronColor) {
        var centerX = boxWidth / 2;
        var centerY = isUp ? boxHeight / 2 + 0.5 : boxHeight / 2 - 0.5; /* 継ぎ目から少し離す / nudged away from the seam */
        var halfWidth = 3.6; /* 山形の半幅（高さ1.8に対して開き約127°） / half width of the chevron */
        var tipOffsetY = isUp ? -1.8 : 1.8; /* 頂点の中心からのずれ（上向きは上、下向きは下） */
        boxGraphics.newPath();
        boxGraphics.moveTo(centerX - halfWidth, centerY - tipOffsetY);
        boxGraphics.lineTo(centerX, centerY + tipOffsetY);
        boxGraphics.lineTo(centerX + halfWidth, centerY - tipOffsetY);
        boxGraphics.strokePath(boxGraphics.newPen(boxGraphics.PenType.SOLID_COLOR, chevronColor, 1.2));
    }

    /**
     * 入力欄にフォーカスを移す
     * @param {EditText} numberInput - 対象の入力欄
     * @returns {void}
     */
    function focusNumberInput(numberInput) {
        numberInput.active = false; /* 一度外さないとフォーカスが移らないことがある / reset first or focus may not move */
        numberInput.active = true;
    }

    /**
     * コントロールと、その親をたどってすべて有効かを返す（親の無効化は子の enabled に出ない）
     * @param {Object} control - 対象のコントロール
     * @returns {boolean} すべて有効なら true
     */
    function isStepperEnabledInTree(control) {
        for (var node = control; node; node = node.parent) {
            if (!node.enabled) return false;
        }
        return true;
    }

    /**
     * コンテナ以下にある∧∨ボタンをすべて描き直す。行やパネルの enabled を切り替えたあとに呼ぶ
     * @param {Object} container - 行・グループ・パネルなど
     * @returns {void}
     */
    function redrawSteppersIn(container) {
        if (!container.children) return;
        for (var i = 0; i < container.children.length; i++) {
            var child = container.children[i];
            if (child.isStepperButton) redrawStepperGroup(child);
            else redrawSteppersIn(child);
        }
    }

    /**
     * group の onDraw を呼び直す。group には notify() が無いため、隠して再表示して描き直させる
     * @param {Group} targetGroup - 描き直す group
     * @returns {void}
     */
    function redrawStepperGroup(targetGroup) {
        targetGroup.hide();
        targetGroup.show();
    }

    // ステップボタン（再利用パーツ）ここまで / End of the reusable stepper

    // =========================================
    // ローカライズ / Localization
    // =========================================

    // ローカライズ（再利用パーツ） / Localization (reusable)

    /**
     * UI の言語を返す（"ja" で始まるロケールは日本語、それ以外は英語）
     * @returns {string} "ja" または "en"
     */
    function getCurrentLang() {
        return (String($.locale || "").indexOf("ja") === 0) ? "ja" : "en";
    }

    var uiLang = getCurrentLang();

    /**
     * LABELS から今の UI 言語の文言を取り出す。
     * @param {string|Object} labelRef - "dialog.title" のようなパス、または { ja, en }
     * @param {Object|Array} [placeholderValues] - { name: 値 } なら {name} を、[値, …] なら %1, %2 … を差し込む
     * @returns {string} 文言。パスが見つからなければパスの文字列、{ ja, en } が無ければ空文字
     */
    function getLabel(labelRef, placeholderValues) {
        var labelEntry = labelRef;
        if (typeof labelRef === "string") {
            var labelPathKeys = labelRef.split(".");
            labelEntry = LABELS;
            for (var i = 0; i < labelPathKeys.length && labelEntry != null; i++) {
                labelEntry = labelEntry[labelPathKeys[i]];
            }
        }
        var labelString;
        if (typeof labelEntry === "string") labelString = labelEntry;
        else if (labelEntry != null && labelEntry[uiLang] != null) labelString = labelEntry[uiLang];
        else if (labelEntry != null && labelEntry.en != null) labelString = labelEntry.en;
        else return (typeof labelRef === "string") ? labelRef : "";
        return fillLabelPlaceholders(String(labelString), placeholderValues);
    }

    /**
     * 項目名の文言の末尾にコロンを付ける（日本語は半角スペース＋半角コロン「 :」、英語は「:」。Illustrator の線パネルなどの項目名に合わせる）
     * @param {string|Object} labelRef - getLabel と同じ
     * @param {Object|Array} [placeholderValues] - getLabel と同じ
     * @returns {string} コロン付きの文言
     */
    function labelText(labelRef, placeholderValues) {
        return getLabel(labelRef, placeholderValues) + (uiLang === "ja" ? " :" : ":");
    }

    /**
     * 「項目名 : 値」の1行を返す（日本語は「件数 : 5」、英語は「Count: 5」。どちらもコロンのあとに空白を入れる）
     * @param {string|Object} labelRef - getLabel と同じ
     * @param {string|number} value - コロンのあとに続ける値
     * @returns {string} 項目名と値をつないだ文字列
     */
    function labelValueText(labelRef, value) {
        return labelText(labelRef) + " " + value;
    }

    /**
     * 文言の {name} や %1 に値を差し込む
     * @param {string} labelString - 文言
     * @param {Object|Array} [placeholderValues] - { name: 値 } または [値, …]
     * @returns {string} 差し込んだ文言
     */
    function fillLabelPlaceholders(labelString, placeholderValues) {
        if (placeholderValues == null) return labelString;
        if (placeholderValues instanceof Array) {
            /* 大きい番号から置き換え、%1 が %10 の一部を置き換えないようにする / Replace from the highest index so %1 does not eat into %10 */
            for (var i = placeholderValues.length; i >= 1; i--) {
                labelString = labelString.split("%" + i).join(String(placeholderValues[i - 1]));
            }
            return labelString;
        }
        for (var placeholderKey in placeholderValues) {
            if (!placeholderValues.hasOwnProperty(placeholderKey)) continue;
            labelString = labelString.split("{" + placeholderKey + "}").join(String(placeholderValues[placeholderKey]));
        }
        return labelString;
    }

    // ローカライズ（再利用パーツ）ここまで / End of the reusable localization

    /* 日英ラベル定義 / Bilingual labels */
    var LABELS = {
        dialog: {
            title: { ja: "テキスト処理", en: "Text Processing" }
        },
        tab: {
            basic: { ja: "基本", en: "Basic" },
            cleanup: { ja: "整形", en: "Cleanup" },
            lineArrange: { ja: "行の編集", en: "Line Edit" },
            convert: { ja: "変換", en: "Convert" }
        },
        panel: {
            breakGroup: { ja: "改行", en: "Breaks" },
            removeBreak: { ja: "削除", en: "Remove" },
            insertBreak: { ja: "挿入", en: "Insert" },
            convertBreak: { ja: "切り換え", en: "Convert" },
            splitGroup: { ja: "分割", en: "Split" },
            splitByBreak: { ja: "改行で分割", en: "Split by Line Breaks" },
            splitByChar: { ja: "文字・単語で分割", en: "Split by Character / Word" },
            sort: { ja: "ソート", en: "Sort" },
            lineEdit: { ja: "編集", en: "Edit" },
            lineDelete: { ja: "行削除", en: "Delete Lines" },
            convert: { ja: "変換", en: "Convert" },
            list: { ja: "リストの除去", en: "Remove List" },
            concat: { ja: "連結", en: "Concatenate" },
            tab: { ja: "タブ", en: "Tab" },
            space: { ja: "スペース削除", en: "Remove Spaces" },
            status: { ja: "ステータス", en: "Status" },
            letterCase: { ja: "大文字/小文字", en: "Letter Case" },
            kanaConvert: { ja: "かな変換", en: "Kana Conversion" },
            digitConvert: { ja: "英数字", en: "Alphanumeric" },
            symbolConvert: { ja: "スペースや記号の変換", en: "Spaces & Symbols" },
            symbolBefore: { ja: "変換前", en: "Before" },
            symbolAfter: { ja: "変換後", en: "After" },
            addSpace: { ja: "スペース追加", en: "Add Space" }
        },
        radio: {
            space: { ja: "スペース", en: "Space" },
            underscore: { ja: "アンダースコア", en: "Underscore" },
            hyphen: { ja: "ハイフン", en: "Hyphen" }
        },
        button: {
            flattenToOneLine: { ja: "すべて1行に", en: "Merge All into One Line" },
            removeLineBreaks: { ja: "改行のみ", en: "Line Breaks Only" },
            addLineBreaks: { ja: "1文字ごとに改行", en: "Insert Line Break After Each Character" },
            breakAtChars: { ja: "指定文字で改行", en: "At Specified Characters" },
            breakAtCount: { ja: "指定文字数で改行", en: "At Character Count" },
            convertBreaks: { ja: "強制改行→改行", en: "Forced Breaks to Paragraph Breaks" },
            convertToForcedBreaks: { ja: "改行→強制改行", en: "Paragraph Breaks to Forced Breaks" },
            splitByLine: { ja: "テキストばらし", en: "Split by Line Breaks" },
            splitByLineKeepStyle: { ja: "〃（書式保持）", en: "Split by Line Breaks (Keep Style)" },
            splitByVisualLine: { ja: "見かけの改行で分割", en: "Split by Visual Lines" },
            splitByTab: { ja: "タブで分割", en: "Split by Tabs" },
            splitKeepStyle: { ja: "書式を保持", en: "Keep Style" },
            splitIgnoreStyle: { ja: "書式を無視", en: "Ignore Style" },
            splitByWord: { ja: "単語で分割", en: "Split by Word" },
            concatV: { ja: "縦方向に連結", en: "Vertical" },
            concatHOnly: { ja: "横連結（行維持）", en: "Merge Horizontally (Keep Rows)" },
            concatH: { ja: "横連結（行統合）", en: "Merge Horizontally (Merge Rows)" },
            concatToArea: { ja: "PDFテキスト整形", en: "Format PDF Text" },
            removeTabs: { ja: "タブを削除", en: "Remove Tabs" },
            tabsToSpaces: { ja: "タブ→スペース", en: "Tabs to Spaces" },
            trimSpaces: { ja: "行頭行末", en: "Leading/Trailing Spaces" },
            cjkLatinSpaces: { ja: "和欧間", en: "Remove Spaces Between CJK and Latin" },
            collapseSpaces: { ja: "連続", en: "Collapse Spaces" },
            cleanupSpaces: { ja: "まとめて", en: "All at Once" },
            removeAllSpaces: { ja: "すべて", en: "Remove All" },
            fullToHalfAlnum: { ja: "全角英数字→半角", en: "Fullwidth to Halfwidth" },
            halfToFullKana: { ja: "半角カナ→全角", en: "Halfwidth Kana to Fullwidth" },
            bulletList: { ja: "箇条書き", en: "Bullet List" },
            numberList: { ja: "番号リスト", en: "Number List" },
            lineUp: { ja: "上へ", en: "Up" },
            lineDown: { ja: "下へ", en: "Down" },
            lineAdd: { ja: "追加", en: "Add" },
            lineEdit: { ja: "編集", en: "Edit" },
            lineDelete: { ja: "削除", en: "Delete" },
            sortByCharCode: { ja: "ソート", en: "Sort" },
            sortByLength: { ja: "文字数順", en: "Sort (Length)" },
            reverseOrder: { ja: "反転", en: "Reverse Order" },
            removeDuplicateLines: { ja: "重複行", en: "Remove Duplicates" },
            removeEmptyLines: { ja: "空行", en: "Remove Empty Lines" },
            caseUpper: { ja: "すべて大文字に", en: "UPPERCASE" },
            caseLower: { ja: "すべて小文字に", en: "lowercase" },
            caseWord: { ja: "単語の先頭を大文字", en: "Capitalize Words" },
            caseSentence: { ja: "文頭のみ大文字", en: "Sentence case" },
            caseTitle: { ja: "英語タイトル形式", en: "Title Case" },
            toHiragana: { ja: "ひらがなに", en: "Hiragana" },
            toKatakana: { ja: "カタカナに", en: "Katakana" },
            toHalfKana: { ja: "半角カナに", en: "Halfwidth Kana" },
            toHalfDigit: { ja: "半角数字に", en: "Halfwidth Digits" },
            toFullDigit: { ja: "全角数字に", en: "Fullwidth Digits" },
            singleDigitFull: { ja: "1桁は全角", en: "Fullwidth if Single Digit" },
            toKanjiNumeral: { ja: "漢数字に", en: "Kanji Numerals" },
            toKanjiPositional: { ja: "漢数字（位取り）", en: "Kanji (Positional)" },
            convertSymbol: { ja: "変換", en: "Convert" },
            spaceAfterPunct: { ja: ".と,の後", en: "Space After . and ," },
            showHiddenChar: { ja: "制御文字の表示/非表示", en: "Show/Hide Hidden Characters" }
        },
        checkbox: {
            includeForcedBreaks: { ja: "強制改行を含む", en: "Include Forced Breaks" },
            forcedBreak: { ja: "強制改行", en: "Forced Break" },
            mergeAreaText: { ja: "エリア内文字を連結", en: "Merge Area Text" }
        },
        tooltip: {
            concatV: { ja: "上→下に連結", en: "Merge top to bottom" },
            concatHOnly: {
                ja: "行ごとに横連結して、行は維持します",
                en: "Merge horizontally within each row and keep the rows separate"
            },
            concatH: {
                ja: "横方向に連結した後、複数行を1つのテキストに統合します",
                en: "Merge horizontally and then combine multiple rows into a single text"
            },
            concatToArea: {
                ja: "横方向に連結し、エリア内文字として整形します",
                en: "Merge horizontally and format the result as area text"
            },
            breakAtChars: {
                ja: "下の欄の文字で改行します\nOption+クリックで［すべて1行に］を実行してから改行",
                en: "Insert line breaks at the characters below\nOption-click to run \"Merge All into One Line\" first"
            },
            breakAtCount: {
                ja: "指定文字数ごとに改行します\nOption+クリックで［すべて1行に］を実行してから改行",
                en: "Insert a line break every N characters\nOption-click to run \"Merge All into One Line\" first"
            },
            breakChars: {
                ja: "この欄の文字の後ろで改行します",
                en: "Insert a line break after each of these characters"
            },
            breakBeforeChars: {
                ja: "この欄の文字の直前で改行します（テキスト内に1つしか無い文字は無視）",
                en: "Insert a line break before each of these characters (ignored when a character appears only once in the text)"
            },
            removeLineBreaks: {
                ja: "段落改行を削除します（「強制改行を含む」ON で強制改行も対象）",
                en: "Remove paragraph breaks (also forced breaks when \"Include Forced Breaks\" is on)"
            },
            optionGroup: { ja: "Option+クリックでグループ化", en: "Option-click to group the results" },
            splitByLine: {
                ja: "改行ごとに別々のテキストフレームへ分割します",
                en: "Split into separate text frames at each line break"
            },
            splitByVisualLine: {
                ja: "エリア内文字の折り返し位置（見かけの改行）で分割します",
                en: "Split area text at each wrapped line (visual line break)"
            },
            splitByTab: {
                ja: "タブ位置で分割します",
                en: "Split at tab positions"
            },
            splitByLineKeepStyle: {
                ja: "改行ごとに分割し、文字書式と位置を保持します",
                en: "Split at each line break while keeping character formatting and position"
            },
            splitKeepStyle: {
                ja: "1文字ずつ別フレームに分割し、書式を保持します",
                en: "Split into one frame per character, keeping formatting"
            },
            splitIgnoreStyle: {
                ja: "1文字ずつ別フレームに分割し、書式をリセットします",
                en: "Split into one frame per character, resetting formatting"
            },
            splitByWord: {
                ja: "スペース・タブ・改行で区切った単語ごとに別フレームに分割し、書式を保持します（単語間のスペースは削除）",
                en: "Split into one frame per word (separated by spaces, tabs or line breaks), keeping formatting; the spaces between words are removed"
            },
            mergeAreaText: {
                ja: "分割した文字・単語をエリア内文字にして、元の順にスレッドでつなげます",
                en: "Converts the split characters or words to area type and threads them in the original order"
            },
            trimSpaces: {
                ja: "各行の行頭・行末のスペースを削除します",
                en: "Remove leading and trailing spaces on each line"
            },
            cjkLatinSpaces: {
                ja: "和文と欧文の間のスペースを削除します（欧文単語間は保持）",
                en: "Remove spaces between CJK and Latin (spaces within Latin words are kept)"
            },
            collapseSpaces: {
                ja: "連続したスペースを1つにまとめます",
                en: "Collapse consecutive spaces into a single space"
            },
            cleanupSpaces: {
                ja: "行頭行末・和欧間・連続スペースをまとめて処理します",
                en: "Apply trim, CJK/Latin, and collapse in one step"
            },
            removeAllSpaces: {
                ja: "すべてのスペース（半角・全角）を削除します",
                en: "Remove all spaces (half-width and full-width)"
            },
            spaceAfterPunct: {
                ja: "半角ピリオド・カンマの直後にスペースを挿入します",
                en: "Insert a space right after a period or comma"
            },
            bulletList: {
                ja: "行頭の箇条書き記号（・ ･ · • ◦ ● ○ ◎ □ ■ ◆ ◇ ✓ - *）を削除します",
                en: "Remove leading bullet markers (・ ･ · • ◦ ● ○ ◎ □ ■ ◆ ◇ ✓ - *)"
            },
            numberList: {
                ja: "行頭の番号（1. ① a. 一. など）を削除します",
                en: "Remove leading numbering (1. ① a. etc.)"
            },
            stepUp: {
                ja: "値を増やす（shift＋クリックで10の倍数へ、option＋クリックで0.1ずつ）",
                en: "Increase (Shift-click to snap to 10s, Option-click by 0.1)"
            },
            stepDown: {
                ja: "値を減らす（shift＋クリックで10の倍数へ、option＋クリックで0.1ずつ）",
                en: "Decrease (Shift-click to snap to 10s, Option-click by 0.1)"
            },
            stepUpInteger: { ja: "値を増やす（shift＋クリックで10の倍数へ）", en: "Increase (Shift-click to snap to 10s)" },
            stepDownInteger: { ja: "値を減らす（shift＋クリックで10の倍数へ）", en: "Decrease (Shift-click to snap to 10s)" }
        },
        prompt: {
            addLine: { ja: "追加する行を入力してください", en: "Enter the line to add" },
            editLine: { ja: "行を編集してください", en: "Edit the line" }
        },
        confirm: {
            deleteLine: { ja: "選択した行を削除しますか？", en: "Delete the selected line?" }
        },
        message: {
            processFailed: {
                ja: "処理中にエラーが発生しました。",
                en: "An error occurred while processing."
            },
            noDocument: { ja: "ドキュメントが開かれていません。", en: "No document is open." },
            noSelection: {
                ja: "テキストフレーム、またはテキストを含むグループを選択してください。",
                en: "Please select a text frame or a group containing text."
            },
            noTextFrames: {
                ja: "選択内に対象のテキストフレームが見つかりません。テキストフレーム、またはテキストを含むグループを選択してください。",
                en: "No target text frames were found in the selection. Please select a text frame or a group containing text."
            }
        },
        info: {
            targetCount: { ja: "対象テキスト", en: "Target Texts" },
            pointCount: { ja: "ポイント文字", en: "Point Type" },
            areaCount: { ja: "エリア内文字", en: "Area Text" },
            paragraphBreak: { ja: "改行", en: "Paragraph Breaks" },
            forcedBreak: { ja: "強制改行", en: "Forced Breaks" },
            tab: { ja: "タブ", en: "Tabs" }
        }
    };

    /**
     * 分割ボタン用のツールチップを返す（Option+クリックの説明を添える）
     * @param {Object} labelNode - LABELS.tooltip 内の { ja, en } ノード
     * @returns {string} 説明文
     */
    function getSplitTooltip(labelNode) {
        return getLabel(labelNode) + "\n" + getLabel(LABELS.tooltip.optionGroup);
    }

    /**
     * 処理エラーをアラートで通知する
     * @param {Error|Object} err - 例外オブジェクト、または message を持つオブジェクト
     * @returns {void}
     */
    function showError(err) {
        var errorMessage = (err && err.message) ? err.message : String(err);
        alert(getLabel(LABELS.message.processFailed) + "\n\n" + errorMessage);
    }

    // =========================================
    // テキスト処理ユーティリティ / Text utilities
    // =========================================
    /* ここから下の関数群は BridgeTalk でメインエンジンへ委譲される（__LIB_FUNCS 参照）。
       toString() の出力が壊れるため、JSDoc と // 形式のコメントは使わない。 */

    function debugLog(context, err) {
        var logMessage = "[TextProcessing] " + context;
        if (err) logMessage += " :: " + (err.message ? err.message : String(err));
        try {
            $.writeln(logMessage);
        } catch (e) { }
    }

    /* 段落改行の表記ゆれ（CRLF）だけを CR に揃える。
       強制改行（U+0003 / LF / U+2028）は行の途中の文字として保持し、段落改行に化けさせない */
    function normalizeParagraphBreaks(txt) {
        return String(txt || "").replace(/\r\n/g, "\r");
    }

    function splitParagraphLines(txt) {
        return normalizeParagraphBreaks(txt).split("\r");
    }

    function trimLineSpaces(txt) {
        return String(txt || "").replace(/^[ \t　]+/, "").replace(/[ \t　]+$/, "");
    }

    function isBlankLine(txt) {
        return trimLineSpaces(txt) === "";
    }

    function stripTrailingBreaks(txt) {
        var result = String(txt || "");
        while (result.length > 0 && isAnyBreak(result.charAt(result.length - 1))) {
            result = result.substring(0, result.length - 1);
        }
        return result;
    }

    function isLatinLetterOrDigit(c) {
        if (!c) return false;
        var code = c.charCodeAt(0);
        if (code >= 0x41 && code <= 0x5A) return true;
        if (code >= 0x61 && code <= 0x7A) return true;
        if (code >= 0x30 && code <= 0x39) return true;
        return false;
    }

    function isAsciiTextOnly(txt) {
        return /^[\x00-\x7F]+$/.test(String(txt || ""));
    }

    function isSentenceEndingJP(txt) {
        return /[。！？]$/.test(String(txt || ""));
    }

    function isSentenceEndingEN(txt) {
        return /[.!?]$/.test(String(txt || ""));
    }

    function shouldInsertParagraphBreakBetweenLines(currentText) {
        var compact = String(currentText || "").replace(/[\s\r\n]/g, "");
        return isSentenceEndingJP(currentText) || (isSentenceEndingEN(currentText) && !isAsciiTextOnly(compact));
    }

    function getCharCodeSafe(ch) {
        if (ch == null || ch === "") return -1;
        return String(ch).charCodeAt(0);
    }

    function isParagraphBreak(codeOrChar) {
        var code = (typeof codeOrChar === "number") ? codeOrChar : getCharCodeSafe(codeOrChar);
        return code === 13;
    }

    /* 強制改行は contents の取り方によって U+0003 / LF / U+2028 のいずれかで現れる */
    function isForcedBreak(codeOrChar) {
        var code = (typeof codeOrChar === "number") ? codeOrChar : getCharCodeSafe(codeOrChar);
        return code === 3 || code === 10 || code === 8232;
    }

    function isAnyBreak(codeOrChar) {
        return isParagraphBreak(codeOrChar) || isForcedBreak(codeOrChar);
    }

    function isTabChar(codeOrChar) {
        var code = (typeof codeOrChar === "number") ? codeOrChar : getCharCodeSafe(codeOrChar);
        return code === 9;
    }

    /* 改行・タブ以外の文字が残っている最後の位置を返す（無ければ -1）*/
    function findLastVisibleIndex(txt) {
        var text = String(txt || "");
        for (var i = text.length - 1; i >= 0; i--) {
            var currentChar = text.charAt(i);
            if (!isAnyBreak(currentChar) && !isTabChar(currentChar)) return i;
        }
        return -1;
    }

    /* 英字ケース変換（純粋な文字列関数 / TextNormalize.jsx より移植）。
       プレビュー（パレット側）と適用（メインエンジン側）の両方で使う。 */

    /* 単語の先頭のみ大文字。事前に小文字化しているので、すべて大文字の語も Negotiable のようになる */
    function toWordCap(text) {
        return String(text).toLowerCase().replace(/\b([a-z])/g, function (matched, initial) {
            return initial.toUpperCase();
        });
    }

    /* 文頭のみ大文字。文区切りが無い（英単語が1つだけの）場合も先頭を大文字化する */
    function toSentenceCase(text) {
        return String(text).toLowerCase().replace(/(^|[\.\!\?]\s+|[\r\n]+)([a-z])/g,
            function (matched, prefix, initial) { return prefix + initial.toUpperCase(); });
    }

    /* 英語タイトル形式（冠詞・前置詞などは小文字 / John Gruber の Title Caps 移植）*/
    function toTitleCase(text) {
        var smallWords = "(a|abaft|aboard|about|above|absent|across|afore|after|against|along|alongside|amid|amidst|among|amongst|an|and|apropos|around|as|aside|astride|at|athwart|atop|barring|before|behind|below|beneath|beside|besides|between|betwixt|beyond|but|by|circa|concerning|despite|down|during|except|excluding|failing|following|for|from|given|in|including|inside|into|lest|like|mid|midst|minus|modulo|near|next|nor|notwithstanding|of|off|on|onto|opposite|or|out|outside|over|pace|per|plus|pro|qua|regarding|round|sans|save|than|that|the|through|throughout|till|times|to|toward|towards|under|underneath|unlike|until|unto|up|upon|versus|via|vice|with|within|without|worth|v[.]?|via|vs[.]?)";
        var punctuation = "([!\"#$%&'()*+,./:;<=>?@[\\\\\\]^_`{|}~-]*)";

        function toLowerWord(word) { return word.toLowerCase(); }
        function capitalizeWord(word) { return word.substr(0, 1).toUpperCase() + word.substr(1); }

        var title = String(text);
        var sentenceSplitter = /[:.;?!] |(?: |^)[\"Ò]/g;
        var segments = [];
        var segmentStart = 0;
        while (true) {
            var splitMatch = sentenceSplitter.exec(title);
            segments.push(
                title.substring(segmentStart, splitMatch ? splitMatch.index : title.length)
                    .replace(/\b([A-Za-z][a-z.'Õ]*)\b/g, function (matched) {
                        return /[A-Za-z]\.[A-Za-z]/.test(matched) ? matched : capitalizeWord(matched);
                    })
                    .replace(RegExp("\\b" + smallWords + "\\b", "ig"), toLowerWord)
                    .replace(RegExp("^" + punctuation + smallWords + "\\b", "ig"), function (matched, leadingPunct, word) {
                        return leadingPunct + capitalizeWord(word);
                    })
                    .replace(RegExp("\\b" + smallWords + punctuation + "$", "ig"), capitalizeWord)
            );
            segmentStart = sentenceSplitter.lastIndex;
            if (!splitMatch) break;
            segments.push(splitMatch[0]);
        }
        return segments.join("")
            .replace(/ V(s?)\. /ig, " v$1. ")
            .replace(/(['Õ])S\b/ig, "$1s")
            .replace(/\b(AT&T|Q&A)\b/ig, function (matched) { return matched.toUpperCase(); });
    }

    (function () {
        /* 重複起動ガード：既にパレットが開いていれば前面化して終了（二重起動を防ぐ）
           閉じると onClose で参照が null に戻るため、非 null＝表示中とみなす */
        try {
            var existingPalette = $.global.__TextBreakSplitMergePalette;
            if (existingPalette) {
                try { existingPalette.show(); } catch (e) { }
                try { existingPalette.active = true; } catch (e) { }
                return;
            }
        } catch (e) { }

        /* ドキュメントが開かれていない場合は処理を終了 / Abort when no document is open */
        if (app.documents.length === 0) {
            alert(getLabel(LABELS.message.noDocument));
            return;
        }

        /* 選択オブジェクトを取得 / Get the current selection */
        var selectedObjects = app.selection;
        if (!selectedObjects || !selectedObjects.length) {
            alert(getLabel(LABELS.message.noSelection));
            return;
        }

        /* 初期選択からテキストフレームを解決 / Resolve text frames from the initial selection */
        selectedObjects = getTextFrames(selectedObjects);
        if (selectedObjects.length === 0) {
            alert(getLabel(LABELS.message.noTextFrames));
            return;
        }

        /* 選択・テキストフレーム操作（メインエンジンへ委譲される関数群）*/

        /* テキストフレームのみ抽出（グループと TextRange も再帰的にたどる）*/
        function getTextFrames(objects) {
            var frames = [];

            function pushUnique(frame) {
                for (var i = 0; i < frames.length; i++) {
                    if (frames[i] === frame) return;
                }
                frames.push(frame);
            }

            function collect(item) {
                if (!item) return;

                var typeName, textRangeOwner = null;
                try {
                    if (item.isValid === false) return;
                    typeName = item.typename || "";
                    /* Illustrator ではテキスト選択が TextRange として返ることがある */
                    if (typeName === "TextRange" && item.parent && item.parent.typename === "TextFrame") {
                        textRangeOwner = item.parent;
                    }
                } catch (e) { debugLog("getTextFrames: inspect item", e); return; }

                if (typeName === "TextFrame") {
                    pushUnique(item);
                } else if (textRangeOwner) {
                    pushUnique(textRangeOwner);
                } else if (typeName === "GroupItem") {
                    try {
                        for (var i = 0; i < item.pageItems.length; i++) collect(item.pageItems[i]);
                    } catch (e) { debugLog("getTextFrames: walk group", e); }
                }
            }

            if (!objects) return frames;
            if (typeof objects.length === "number" && !objects.typename) {
                for (var k = 0; k < objects.length; k++) collect(objects[k]);
            } else {
                collect(objects);
            }
            return frames;
        }

        /* ポイント文字／エリア内文字の件数を集計（frames は解決済みのテキストフレーム配列）*/
        function countTextFrameTypes(frames) {
            var pointCount = 0;
            var areaCount = 0;

            for (var i = 0; i < frames.length; i++) {
                if (frames[i].kind === TextType.AREATEXT) {
                    areaCount++;
                } else if (frames[i].kind === TextType.POINTTEXT) {
                    pointCount++;
                }
            }

            return { total: frames.length, point: pointCount, area: areaCount };
        }

        /* テキストタイプ判定（混在は "mixed"）。frames は解決済みのテキストフレーム配列 */
        function detectTextFrameType(frames) {
            var counts = countTextFrameTypes(frames);
            if (counts.point > 0 && counts.area > 0) return "mixed";
            return (counts.area > 0) ? "area" : "point";
        }

        /* 改行数とタブ数を集計（frames は解決済みのテキストフレーム配列）。
           1文字ずつDOM経由で読むと選択が大きいときに待たされるため、contents を1回だけ読んで数える */
        function countBreakTypes(frames) {
            var paragraphBreakCount = 0;
            var forcedBreakCount = 0;
            var tabCount = 0;

            for (var i = 0; i < frames.length; i++) {
                var txt = String(frames[i].contents || "");
                for (var j = 0; j < txt.length; j++) {
                    var code = txt.charCodeAt(j);
                    if (isParagraphBreak(code)) {
                        paragraphBreakCount++;
                    } else if (isForcedBreak(code)) {
                        forcedBreakCount++;
                    } else if (isTabChar(code)) {
                        tabCount++;
                    }
                }
            }

            return { paragraph: paragraphBreakCount, forced: forcedBreakCount, tab: tabCount };
        }

        /* 選択状態の集計ヘルパー（__dispatch / __stateDispatch / showPalette で共用）*/

        /* 2行以上（段落改行あり）のフレームが1つでもあるか */
        function hasMultipleLines(frames) {
            for (var i = 0; i < frames.length; i++) {
                if (splitParagraphLines(frames[i].contents).length >= 2) return true;
            }
            return false;
        }

        /* 半角/タブ/全角スペースを含むフレームが1つでもあるか */
        function hasSpacesOrTabs(frames) {
            for (var i = 0; i < frames.length; i++) {
                if (/[ \t　]/.test(frames[i].contents)) return true;
            }
            return false;
        }

        /* 選択状態をまとめたオブジェクトを返す（UI 反映用）。
           集計ごとに選択をたどり直すと遅いので、テキストフレームは一度だけ解決して使い回す */
        function computeSelectionState(objects) {
            var frames = getTextFrames(objects);
            var counts = countTextFrameTypes(frames);
            var breaks = countBreakTypes(frames);
            return {
                total: counts.total, point: counts.point, area: counts.area,
                para: breaks.paragraph, forced: breaks.forced, tab: breaks.tab,
                multiLines: hasMultipleLines(frames),
                multiFrames: frames.length >= 2,
                hasSpTab: hasSpacesOrTabs(frames)
            };
        }

        /* 選択状態を "|" 区切り文字列へエンコード（BridgeTalk の戻り値用）*/
        function encodeSelectionState(objects) {
            var state = computeSelectionState(objects);
            return [state.total, state.point, state.area, state.para, state.forced, state.tab,
            state.multiLines ? 1 : 0, state.multiFrames ? 1 : 0, state.hasSpTab ? 1 : 0].join("|");
        }

        /* 各テキストフレームのcontentsを変換する共通処理。
           contents の再設定は書式を初期化するため、変化がないときは書き戻さない */
        function transformContents(objects, transformFunc) {
            var frames = getTextFrames(objects);
            for (var i = 0; i < frames.length; i++) {
                var original = frames[i].contents;
                var transformed = transformFunc(original);
                if (transformed !== original) frames[i].contents = transformed;
            }
        }

        /* transformContents と同じだが、変わった文字だけを書き換えて文字ごとの書式を残す（SmartTextFindReplace.jsx と同じ方式）。
           文字の置き換え・削除・追加で済む変換に使う。行の並べ替えのように文字の位置が入れ替わる変換には使わない */
        function transformContentsKeepingFormat(objects, transformFunc) {
            var frames = getTextFrames(objects);
            for (var i = 0; i < frames.length; i++) {
                rewriteFrameKeepingFormat(frames[i], transformFunc);
            }
        }

        /* 長さが同じなら1文字ずつ、削るだけ・足すだけなら変わる文字だけ、語ごとに変換して同じ結果になるなら語ごとに書き換える。
           どれにも当てはまらなければ、従来どおり contents をまとめて書き戻す */
        function rewriteFrameKeepingFormat(frame, transformFunc) {
            var originalText = frame.contents;
            var convertedText = transformFunc(originalText);
            if (convertedText === originalText) return;
            if (originalText === "") { frame.contents = convertedText; return; }
            var frameCharacters = frame.characters;
            if (convertedText.length === originalText.length) {
                replaceDifferingPart(frameCharacters, 0, originalText, convertedText);
                return;
            }
            var isShortened = convertedText.length < originalText.length;
            var matchedIndexes = isShortened ? matchSubsequence(convertedText, originalText) : matchSubsequence(originalText, convertedText);
            if (matchedIndexes) {
                if (isShortened) removeUnkeptCharacters(frameCharacters, originalText.length, matchedIndexes);
                else insertAddedText(frameCharacters, originalText, convertedText, matchedIndexes);
                return;
            }
            /* 語ごとの変換は前後の文字に左右されない変換でしか使えないので、全体の結果と一致するときだけ使う */
            var wordPattern = /[^\s\x03]+/g;
            var wordMatches = [];
            var wordMatch;
            var rebuiltText = "";
            var lastEnd = 0;
            while ((wordMatch = wordPattern.exec(originalText)) !== null) {
                var convertedWord = transformFunc(wordMatch[0]);
                wordMatches.push({ start: wordMatch.index, originalWord: wordMatch[0], convertedWord: convertedWord });
                rebuiltText += originalText.substring(lastEnd, wordMatch.index) + convertedWord;
                lastEnd = wordMatch.index + wordMatch[0].length;
            }
            rebuiltText += originalText.substring(lastEnd);
            if (rebuiltText !== convertedText) { frame.contents = convertedText; return; }
            for (var w = wordMatches.length - 1; w >= 0; w--) {
                if (wordMatches[w].convertedWord !== wordMatches[w].originalWord) {
                    replaceDifferingPart(frameCharacters, wordMatches[w].start, wordMatches[w].originalWord, wordMatches[w].convertedWord);
                }
            }
        }

        /* 短い文字列の各文字が長い文字列のどこに対応するかを左から探す。文字を抜くだけで作れなければ null */
        function matchSubsequence(shortText, longText) {
            var matchedIndexes = [];
            var longIndex = 0;
            for (var i = 0; i < shortText.length; i++) {
                while (longIndex < longText.length && longText.charAt(longIndex) !== shortText.charAt(i)) longIndex++;
                if (longIndex >= longText.length) return null;
                matchedIndexes.push(longIndex);
                longIndex++;
            }
            return matchedIndexes;
        }

        /* 残す文字以外を右から削除する */
        function removeUnkeptCharacters(frameCharacters, originalLength, keptIndexes) {
            var keptIndex = keptIndexes.length - 1;
            for (var i = originalLength - 1; i >= 0; i--) {
                if (keptIndex >= 0 && keptIndexes[keptIndex] === i) { keptIndex--; continue; }
                frameCharacters[i].remove();
            }
        }

        /* 増えた文字を右から隣の文字に足す（足した文字はその隣の文字の書式になる）*/
        function insertAddedText(frameCharacters, originalText, convertedText, originalIndexes) {
            for (var i = originalText.length - 1; i >= 0; i--) {
                var nextIndex = (i + 1 < originalText.length) ? originalIndexes[i + 1] : convertedText.length;
                var addedAfter = convertedText.substring(originalIndexes[i] + 1, nextIndex);
                var addedBefore = (i === 0) ? convertedText.substring(0, originalIndexes[0]) : "";
                if (addedAfter !== "" || addedBefore !== "") frameCharacters[i].contents = addedBefore + originalText.charAt(i) + addedAfter;
            }
        }

        /* 変換前と変換後で異なる部分だけを書き換える。長さが同じなら1文字ずつ、違えば前後の一致部分を除いた範囲を差し替える */
        function replaceDifferingPart(frameCharacters, offset, originalText, convertedText) {
            var i;
            if (convertedText.length === originalText.length) {
                for (i = originalText.length - 1; i >= 0; i--) {
                    if (convertedText.charAt(i) !== originalText.charAt(i)) frameCharacters[offset + i].contents = convertedText.charAt(i);
                }
                return;
            }
            var shorterLength = Math.min(originalText.length, convertedText.length);
            var prefixLength = 0;
            while (prefixLength < shorterLength && originalText.charAt(prefixLength) === convertedText.charAt(prefixLength)) prefixLength++;
            var suffixLength = 0;
            while (suffixLength < shorterLength - prefixLength &&
                originalText.charAt(originalText.length - 1 - suffixLength) === convertedText.charAt(convertedText.length - 1 - suffixLength)) suffixLength++;
            var replaceStart = offset + prefixLength;
            var replaceEnd = offset + originalText.length - suffixLength;
            var middleText = convertedText.substring(prefixLength, convertedText.length - suffixLength);
            if (replaceStart === replaceEnd) {
                if (prefixLength > 0) frameCharacters[replaceStart - 1].contents = originalText.charAt(prefixLength - 1) + middleText;
                else frameCharacters[replaceStart].contents = middleText + originalText.charAt(prefixLength);
                return;
            }
            var keptCount = (middleText === "") ? 0 : 1;
            for (i = replaceEnd - 1; i >= replaceStart + keptCount; i--) {
                frameCharacters[i].remove();
            }
            if (keptCount > 0) frameCharacters[replaceStart].contents = middleText;
        }

        /* 各テキストフレームの文字を末尾から走査し、matchesCharCode が真の文字を処理する共通ヘルパー。
           replacement が null なら削除、文字列なら差し替える（末尾走査なので remove でも index がずれない）*/
        function mutateMatchingChars(objects, matchesCharCode, replacement) {
            var frames = getTextFrames(objects);
            for (var i = 0; i < frames.length; i++) {
                var chars = frames[i].characters;
                for (var charIndex = chars.length - 1; charIndex >= 0; charIndex--) {
                    if (!matchesCharCode(chars[charIndex].contents.charCodeAt(0))) continue;
                    if (replacement === null) {
                        chars[charIndex].remove();
                    } else {
                        chars[charIndex].contents = replacement;
                    }
                }
            }
        }

        /* 強制改行（charCode 3 または 10）を削除する共通処理 */
        function removeForcedLineBreaks(objects) {
            mutateMatchingChars(objects, isForcedBreak, null);
        }

        /* 元配列を変更せずに並べ替えた配列を返す */
        function sortedCopy(items, comparator) {
            var sorted = items.slice(0);
            sorted.sort(comparator);
            return sorted;
        }

        /* 上から順にソート（Y降順、同じYならX昇順） */
        function sortByPosition(items) {
            return sortedCopy(items, function (a, b) {
                if (b.position[1] !== a.position[1]) return b.position[1] - a.position[1];
                return a.position[0] - b.position[0];
            });
        }

        /* Y座標で降順ソート */
        function sortByY(items) {
            return sortedCopy(items, function (a, b) { return b.position[1] - a.position[1]; });
        }

        /* X座標で昇順ソート */
        function sortByX(items) {
            return sortedCopy(items, function (a, b) { return a.position[0] - b.position[0]; });
        }

        /* Y位置で行グループ化 */
        function groupByLineY(sortedItems, threshold) {
            var lines = [];
            for (var i = 0; i < sortedItems.length; i++) {
                var y = sortedItems[i].position[1];
                var found = false;
                for (var j = 0; j < lines.length; j++) {
                    if (Math.abs(lines[j][0].position[1] - y) <= threshold) {
                        lines[j].push(sortedItems[i]);
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    lines.push([sortedItems[i]]);
                }
            }
            return lines;
        }

        /* 複数アイテムを内包するバウンディングボックス [左, 上, 右, 下] を返す */
        function getUnionBounds(items) {
            var left = items[0].visibleBounds[0];
            var top = items[0].visibleBounds[1];
            var right = items[0].visibleBounds[2];
            var bottom = items[0].visibleBounds[3];
            for (var i = 1; i < items.length; i++) {
                var bounds = items[i].visibleBounds;
                if (bounds[0] < left) left = bounds[0];
                if (bounds[1] > top) top = bounds[1];
                if (bounds[2] > right) right = bounds[2];
                if (bounds[3] < bottom) bottom = bounds[3];
            }
            return [left, top, right, bottom];
        }

        /* テキストフレームを1つのグループにまとめる */
        function groupTextFrames(frames, targetLayer) {
            var validFrames = getTextFrames(frames);
            if (validFrames.length === 0) return [];

            var targetGroup = (targetLayer || app.activeDocument.activeLayer).groupItems.add();
            for (var i = 0; i < validFrames.length; i++) {
                try {
                    validFrames[i].move(targetGroup, ElementPlacement.PLACEATEND);
                } catch (e) { debugLog("groupTextFrames: move to group", e); }
            }
            return [targetGroup];
        }

        /* 分割結果をまとめるかどうかの分岐（Option+クリック時だけグループ化する）*/
        function applySplitGrouping(frames, shouldGroup) {
            if (!shouldGroup) return frames;
            return groupTextFrames(frames, app.activeDocument.activeLayer);
        }

        /* 改行系の関数 */

        /* 改行文字を削除する関数 */
        function removeLineBreaks(objects) {
            mutateMatchingChars(objects, isParagraphBreak, null);
        }

        /* 強制改行と改行を削除する関数 */
        function removeAllBreaks(objects) {
            mutateMatchingChars(objects, isAnyBreak, null);
        }

        /* 改行と強制改行を取り除いて1行にする関数。
           改行をはさんで欧文どうしが並んでいた場合は、語がくっつかないようスペースに置き換える */
        function joinBreaksToOneLine(objects) {
            transformContents(objects, function (txt) {
                var result = "";
                for (var i = 0; i < txt.length; i++) {
                    var currentChar = txt.charAt(i);
                    if (!isAnyBreak(currentChar)) {
                        result += currentChar;
                        continue;
                    }

                    /* 改行が続く場合はまとめて1か所として扱う */
                    var nextIndex = i + 1;
                    while (nextIndex < txt.length && isAnyBreak(txt.charAt(nextIndex))) nextIndex++;

                    var prevChar = (result.length > 0) ? result.charAt(result.length - 1) : "";
                    var nextChar = (nextIndex < txt.length) ? txt.charAt(nextIndex) : "";
                    if (isLatinLetterOrDigit(prevChar) && isLatinLetterOrDigit(nextChar)) result += " ";
                    i = nextIndex - 1;
                }
                return result;
            });
        }

        /* 複数フレームを連結し、改行を取り除いて1行に統合する関数 */
        function flattenToOneLine(objects) {
            var frames = getTextFrames(objects);
            if (frames.length < 2) {
                removeEmptyLines(frames);
                joinBreaksToOneLine(frames);
                return frames;
            }
            var result = concatVertical(objects);
            var targets = result && result.length ? result : frames;
            removeEmptyLines(targets);
            joinBreaksToOneLine(targets);
            return result;
        }

        /* 空行を削除する関数 */
        function removeEmptyLines(objects) {
            transformContents(objects, function (txt) {
                var lines = splitParagraphLines(txt);
                var kept = [];
                for (var i = 0; i < lines.length; i++) {
                    if (!isBlankLine(lines[i])) {
                        kept.push(lines[i]);
                    }
                }
                return kept.join("\r");
            });
        }

        /* タブを削除する関数 */
        function removeTabs(objects) {
            mutateMatchingChars(objects, isTabChar, null);
        }

        /* タブをスペースに変換する関数 */
        function tabsToSpaces(objects) {
            transformContentsKeepingFormat(objects, function (txt) {
                return txt.replace(/\t/g, " ");
            });
        }

        /* 行頭行末のスペースを削除する関数 */
        function trimSpaces(objects) {
            transformContentsKeepingFormat(objects, function (txt) {
                var lines = splitParagraphLines(txt);
                for (var i = 0; i < lines.length; i++) {
                    lines[i] = trimLineSpaces(lines[i]);
                }
                return lines.join("\r");
            });
        }

        /* 連続スペースを1つにまとめる関数 */
        function collapseSpaces(objects) {
            transformContentsKeepingFormat(objects, function (txt) {
                /* 半角スペース連続 → 半角スペース1つ  */
                var result = txt.replace(/ {2,}/g, " ");
                /* 全角スペース連続 → 全角スペース1つ  */
                result = result.replace(/\u3000{2,}/g, "\u3000");
                return result;
            });
        }

        /* 各行の行頭を正規表現で除去する共通処理。
           prefixPatterns は配列で渡し、行ごとに最初に一致したものだけを適用する */
        function removeLinePrefix(objects, prefixPatterns) {
            transformContentsKeepingFormat(objects, function (txt) {
                var lines = splitParagraphLines(txt);
                for (var i = 0; i < lines.length; i++) {
                    for (var j = 0; j < prefixPatterns.length; j++) {
                        if (!prefixPatterns[j].test(lines[i])) continue;
                        lines[i] = lines[i].replace(prefixPatterns[j], "");
                        break;
                    }
                }
                return lines.join("\r");
            });
        }

        /* 全角英数字を半角へ変換した文字列を返す
           対象は ０-９ (0xFF10-0xFF19) / Ａ-Ｚ (0xFF21-0xFF3A) / ａ-ｚ (0xFF41-0xFF5A) */
        function toHalfWidthAlnumText(txt) {
            var result = "";
            for (var i = 0; i < txt.length; i++) {
                var code = txt.charCodeAt(i);
                if (code >= 0xFF10 && code <= 0xFF19) {
                    result += String.fromCharCode(code - 0xFF10 + 0x30);
                } else if (code >= 0xFF21 && code <= 0xFF3A) {
                    result += String.fromCharCode(code - 0xFF21 + 0x41);
                } else if (code >= 0xFF41 && code <= 0xFF5A) {
                    result += String.fromCharCode(code - 0xFF41 + 0x61);
                } else {
                    result += txt.charAt(i);
                }
            }
            return result;
        }

        /* 半角カナを全角カナへ変換した文字列を返す（濁点・半濁点の合成と約物も対象）*/
        function toFullWidthKanaText(txt) {
            var halfKana = "ｦｧｨｩｪｫｬｭｮｯｰｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾅﾆﾇﾈﾉﾊﾋﾌﾍﾎﾏﾐﾑﾒﾓﾔﾕﾖﾗﾘﾙﾚﾛﾜﾝ";
            var fullKana = "ヲァィゥェォャュョッーアイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレロワン";
            /* 濁点・半濁点の合成対応表 */
            var dakutenBase = "ｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾊﾋﾌﾍﾎｳ";
            var dakutenFull = "ガギグゲゴザジズゼゾダヂヅデドバビブベボヴ";
            var handakutenBase = "ﾊﾋﾌﾍﾎ";
            var handakutenFull = "パピプペポ";
            /* 単独で置き換える約物（濁点・半濁点・句読点・カギ括弧・中黒）*/
            var halfPunct = "ﾞﾟ｡｢｣､･";
            var fullPunct = "゛゜。「」、・";

            var result = "";
            for (var i = 0; i < txt.length; i++) {
                var currentChar = txt.charAt(i);
                var nextChar = (i + 1 < txt.length) ? txt.charAt(i + 1) : "";

                /* 直後が濁点・半濁点なら合成して1文字にする */
                var isDakuten = (nextChar === "ﾞ");
                var comboIndex = -1;
                if (isDakuten) comboIndex = dakutenBase.indexOf(currentChar);
                else if (nextChar === "ﾟ") comboIndex = handakutenBase.indexOf(currentChar);
                if (comboIndex >= 0) {
                    result += isDakuten ? dakutenFull.charAt(comboIndex) : handakutenFull.charAt(comboIndex);
                    i++;
                    continue;
                }

                var kanaIndex = halfKana.indexOf(currentChar);
                var punctIndex = halfPunct.indexOf(currentChar);
                if (kanaIndex >= 0) {
                    result += fullKana.charAt(kanaIndex);
                } else if (punctIndex >= 0) {
                    result += fullPunct.charAt(punctIndex);
                } else {
                    result += currentChar;
                }
            }
            return result;
        }

        /* 全角カタカナをひらがなへ変換した文字列を返す（長音記号「ー」はそのまま）*/
        function toHiraganaText(txt) {
            var result = "";
            for (var i = 0; i < txt.length; i++) {
                var code = txt.charCodeAt(i);
                /* ァ(0x30A1)〜ヴ(0x30F4) と 踊り字 ヽヾ(0x30FD-0x30FE) は 0x60 引くとひらがなになる。
                   ヵヶ(0x30F5-0x30F6) は「ヶ月」などの用例を壊すため対象外 */
                if ((code >= 0x30A1 && code <= 0x30F4) || (code >= 0x30FD && code <= 0x30FE)) {
                    result += String.fromCharCode(code - 0x60);
                } else {
                    result += txt.charAt(i);
                }
            }
            return result;
        }

        /* ひらがなを全角カタカナへ変換した文字列を返す（長音記号「ー」はそのまま）*/
        function toKatakanaText(txt) {
            var result = "";
            for (var i = 0; i < txt.length; i++) {
                var code = txt.charCodeAt(i);
                /* ぁ(0x3041)〜ゖ(0x3096) と 踊り字 ゝゞ(0x309D-0x309E) は 0x60 足すとカタカナになる */
                if ((code >= 0x3041 && code <= 0x3096) || (code >= 0x309D && code <= 0x309E)) {
                    result += String.fromCharCode(code + 0x60);
                } else {
                    result += txt.charAt(i);
                }
            }
            return result;
        }

        /* 全角カタカナを半角カナへ変換した文字列を返す（濁点・半濁点は2文字に分解、約物も対象）*/
        function toHalfWidthKanaText(txt) {
            var fullKana = "ヲァィゥェォャュョッーアイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレロワン";
            var halfKana = "ｦｧｨｩｪｫｬｭｮｯｰｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾅﾆﾇﾈﾉﾊﾋﾌﾍﾎﾏﾐﾑﾒﾓﾔﾕﾖﾗﾘﾙﾚﾛﾜﾝ";
            /* 濁点・半濁点つきの文字を「素の半角カナ＋濁点」へ分解する対応表 */
            var dakutenFull = "ガギグゲゴザジズゼゾダヂヅデドバビブベボヴ";
            var dakutenBase = "ｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾊﾋﾌﾍﾎｳ";
            var handakutenFull = "パピプペポ";
            var handakutenBase = "ﾊﾋﾌﾍﾎ";
            /* 単独で置き換える約物（濁点・半濁点・句読点・カギ括弧・中黒）*/
            var fullPunct = "゛゜。「」、・";
            var halfPunct = "ﾞﾟ｡｢｣､･";

            var result = "";
            for (var i = 0; i < txt.length; i++) {
                var currentChar = txt.charAt(i);
                var dakutenIndex = dakutenFull.indexOf(currentChar);
                var handakutenIndex = handakutenFull.indexOf(currentChar);
                var kanaIndex = fullKana.indexOf(currentChar);
                var punctIndex = fullPunct.indexOf(currentChar);

                if (dakutenIndex >= 0) {
                    result += dakutenBase.charAt(dakutenIndex) + "ﾞ";
                } else if (handakutenIndex >= 0) {
                    result += handakutenBase.charAt(handakutenIndex) + "ﾟ";
                } else if (kanaIndex >= 0) {
                    result += halfKana.charAt(kanaIndex);
                } else if (punctIndex >= 0) {
                    result += halfPunct.charAt(punctIndex);
                } else {
                    result += currentChar;
                }
            }
            return result;
        }

        /* 全角数字を半角数字へ変換した文字列を返す */
        function toHalfWidthDigitText(txt) {
            var result = "";
            for (var i = 0; i < txt.length; i++) {
                var code = txt.charCodeAt(i);
                /* ０(0xFF10)〜９(0xFF19) */
                result += (code >= 0xFF10 && code <= 0xFF19) ? String.fromCharCode(code - 0xFF10 + 0x30) : txt.charAt(i);
            }
            return result;
        }

        /* 半角数字を全角数字へ変換した文字列を返す */
        function toFullWidthDigitText(txt) {
            var result = "";
            for (var i = 0; i < txt.length; i++) {
                var code = txt.charCodeAt(i);
                /* 0(0x30)〜9(0x39) */
                result += (code >= 0x30 && code <= 0x39) ? String.fromCharCode(code - 0x30 + 0xFF10) : txt.charAt(i);
            }
            return result;
        }

        /* 1桁の数字だけを全角、2桁以上を半角に揃えた文字列を返す（縦組み向け）*/
        function toSingleDigitFullWidthText(txt) {
            return txt.replace(/[0-9０-９]+/g, function (run) {
                return (run.length === 1) ? toFullWidthDigitText(run) : toHalfWidthDigitText(run);
            });
        }

        /* 漢数字を算用数字（半角）へ変換した文字列を返す。
           位取りなしの表記（二〇二六）と、位取りありの表記（三十一・千二百三十四）の両方に対応する */
        function toArabicNumeralText(txt) {
            var kanjiDigits = "〇一二三四五六七八九";
            var kanjiUnits = "十百千万億";
            return txt.replace(/[〇零一二三四五六七八九十百千万億]+/g, function (run) {
                /* 単位の文字を含まないときは1文字ずつ置き換える（二〇二六 → 2026）*/
                var hasUnit = false;
                for (var i = 0; i < run.length; i++) {
                    if (kanjiUnits.indexOf(run.charAt(i)) >= 0) { hasUnit = true; break; }
                }
                if (!hasUnit) {
                    var plain = "";
                    for (var j = 0; j < run.length; j++) {
                        var plainChar = run.charAt(j);
                        plain += (plainChar === "零") ? "0" : String(kanjiDigits.indexOf(plainChar));
                    }
                    return plain;
                }

                /* 位取りありは、万・億でいったん確定させながら積み上げる（二万五千 → 25000）*/
                var total = 0;
                var section = 0;
                var current = 0;
                for (var k = 0; k < run.length; k++) {
                    var unitChar = run.charAt(k);
                    var digitIndex = kanjiDigits.indexOf(unitChar);
                    if (unitChar === "零") { current = 0; }
                    else if (digitIndex >= 0) { current = digitIndex; }
                    else if (unitChar === "十") { section += (current || 1) * 10; current = 0; }
                    else if (unitChar === "百") { section += (current || 1) * 100; current = 0; }
                    else if (unitChar === "千") { section += (current || 1) * 1000; current = 0; }
                    else if (unitChar === "万") { total += (section + current) * 10000; section = 0; current = 0; }
                    else if (unitChar === "億") { total += (section + current) * 100000000; section = 0; current = 0; }
                }
                return String(total + section + current);
            });
        }

        /* 算用数字を漢数字へ1文字ずつ置き換えた文字列を返す（位取りは付けない）*/
        function toKanjiNumeralText(txt) {
            var kanjiDigits = "〇一二三四五六七八九";
            return toHalfWidthDigitText(txt).replace(/[0-9]/g, function (digit) {
                return kanjiDigits.charAt(Number(digit));
            });
        }

        /* 算用数字を位取りありの漢数字へ変換した文字列を返す（31 → 三十一、1234 → 千二百三十四）*/
        function toKanjiPositionalText(txt) {
            var kanjiDigits = "〇一二三四五六七八九";
            var smallUnits = ["", "十", "百", "千"];
            var bigUnits = ["", "万", "億", "兆", "京"];
            return toHalfWidthDigitText(txt).replace(/[0-9]+/g, function (run) {
                /* 先頭の0は落とす（"0" 自体は残す）*/
                var digits = run.replace(/^0+(?=[0-9])/, "");
                if (digits === "0") return "〇";
                /* 京を超える桁は表記できないのでそのまま返す */
                if (digits.length > 20) return run;

                var result = "";
                var sectionCount = Math.ceil(digits.length / 4);
                for (var section = 0; section < sectionCount; section++) {
                    var end = digits.length - section * 4;
                    var sectionDigits = digits.substring(Math.max(0, end - 4), end);
                    var sectionText = "";
                    for (var i = 0; i < sectionDigits.length; i++) {
                        var digit = Number(sectionDigits.charAt(i));
                        if (digit === 0) continue;
                        var unit = smallUnits[sectionDigits.length - 1 - i];
                        /* 十・百・千の位が1のときは「一」を書かない（一十 → 十）*/
                        sectionText += ((digit === 1 && unit !== "") ? "" : kanjiDigits.charAt(digit)) + unit;
                    }
                    if (sectionText !== "") result = sectionText + bigUnits[section] + result;
                }
                return result;
            });
        }

        /* 文字変換系アクション（ケース・かな・数字）のテキスト変換関数を返す。
           パレットのプレビューとメインエンジンの実処理で同じものを使うため1か所にまとめている。
           該当しないアクションIDでは null を返す */
        function getTextConverter(actionName) {
            switch (actionName) {
                case "caseUpper": return function (txt) { return txt.toUpperCase(); };
                case "caseLower": return function (txt) { return txt.toLowerCase(); };
                case "caseWord": return toWordCap;
                case "caseSentence": return toSentenceCase;
                case "caseTitle": return toTitleCase;
                /* かな変換は半角カナも受け付けるため、いったん全角カナへ寄せてから変換する */
                case "toHiragana": return function (txt) { return toHiraganaText(toFullWidthKanaText(txt)); };
                case "toKatakana": return function (txt) { return toKatakanaText(toFullWidthKanaText(txt)); };
                case "toHalfKana": return function (txt) { return toHalfWidthKanaText(toKatakanaText(txt)); };
                /* 数字変換は漢数字も受け付けるため、いったん算用数字へ寄せてから変換する */
                case "toHalfDigit": return function (txt) { return toHalfWidthDigitText(toArabicNumeralText(txt)); };
                case "toFullDigit": return function (txt) { return toFullWidthDigitText(toArabicNumeralText(txt)); };
                case "singleDigitFull": return function (txt) { return toSingleDigitFullWidthText(toArabicNumeralText(txt)); };
                case "toKanjiNumeral": return function (txt) { return toKanjiNumeralText(toArabicNumeralText(txt)); };
                case "toKanjiPositional": return function (txt) { return toKanjiPositionalText(toArabicNumeralText(txt)); };
            }
            return null;
        }

        /* 全角英数字を半角に変換する関数 */
        function fullToHalfAlnum(objects) {
            transformContentsKeepingFormat(objects, toHalfWidthAlnumText);
        }

        /* 半角カナを全角カナに変換する関数 */
        function halfToFullKana(objects) {
            transformContentsKeepingFormat(objects, toFullWidthKanaText);
        }

        /* 行頭の箇条書き記号を除去する関数。
           AddBulletsAndNumbers.jsx が付ける「タブ + 記号 + タブ」形式と手入力の両方に対応する。
           中黒は異体字（・ ･ ·）も対象。「-」「*」は直後が空白のときだけ除去する（-5℃ のような本文を守る）*/
        function removeBulletMarkers(objects) {
            removeLinePrefix(objects, [
                /^\t[・･·•◦●○◎□■◆◇✓\-\*]\t/,
                /^[\t 　]*(?:[・･·•◦●○◎□■◆◇✓]|[\-\*](?=[\t 　]))[\t 　]*/
            ]);
        }

        /* 行頭の番号を除去する関数。
           数字・全角数字・丸数字・ABC/abc・漢数字に対応し、区切りは . ． : ： | を認める。
           「12.5」のように区切りの直後が数字の場合は本文とみなして残す */
        function removeNumberMarkers(objects) {
            removeLinePrefix(objects, [
                /^\t(?:[①-⑳❶-❿⓫-⓴]|[A-Za-z]+|[〇一二三四五六七八九十百千]+|[0-9０-９]+)[.．:：|]?\t/,
                /^[\t 　]*[①-⑳❶-❿⓫-⓴][\t 　]*/,
                /^[\t 　]*(?:[A-Za-z]+|[〇一二三四五六七八九十百千]+|[0-9０-９]+)[.．:：|][\t 　]+/,
                /^[\t 　]*[0-9０-９]+[.．](?![0-9０-９])[\t 　]*/
            ]);
        }

        /* Illustrator標準の「箇条書きと番号付きリスト」を解除する関数。
           contents を入れ直すとリスト書式が外れるが、同時に文字書式・段落書式も初期化されるため、
           控えてから戻す（文字数・段落数は変わらないので先頭から順に対応づけられる）*/
        function clearListFormatting(objects) {
            var frames = getTextFrames(objects);
            for (var i = 0; i < frames.length; i++) {
                var snapshot = captureTextStyles(frames[i]);
                if (snapshot.contents === null) continue;
                try {
                    frames[i].contents = snapshot.contents;
                } catch (e) {
                    /* 入れ直せなければ書式も戻さない */
                    debugLog("clearListFormatting: reassign contents", e);
                    continue;
                }
                restoreTextStyles(frames[i], snapshot);
            }
        }

        /* 控える文字属性の名前。行送りは自動行送りより先に戻す必要があるため、この並び順のまま使う */
        function getCharStyleProps() {
            return ["textFont", "size", "horizontalScale", "verticalScale", "baselineShift",
                "tracking", "leading", "autoLeading", "fillColor"];
        }

        /* 控える段落属性の名前（タブストップは TabStopInfo の作り直しが必要なため別扱い）*/
        function getParagraphStyleProps() {
            return ["justification", "spaceBefore", "spaceAfter", "leftIndent", "rightIndent", "firstLineIndent"];
        }

        /* テキストと、文字ごと・段落ごとの書式を控える */
        function captureTextStyles(frame) {
            var snapshot = { contents: null, chars: [], paras: [] };
            try { snapshot.contents = frame.contents; } catch (e) { return snapshot; }

            var charProps = getCharStyleProps();
            try {
                var characters = frame.textRange.characters;
                for (var i = 0; i < characters.length; i++) {
                    snapshot.chars.push(snapshotAttributes(characters[i].characterAttributes, charProps));
                }
            } catch (eChar) { debugLog("captureTextStyles: characters", eChar); }

            var paraProps = getParagraphStyleProps();
            try {
                var paragraphs = frame.paragraphs;
                for (var p = 0; p < paragraphs.length; p++) {
                    var paraAttrs = paragraphs[p].paragraphAttributes;
                    var paraSnapshot = snapshotAttributes(paraAttrs, paraProps);
                    paraSnapshot.tabStops = snapshotTabStops(paraAttrs);
                    snapshot.paras.push(paraSnapshot);
                }
            } catch (ePara) { debugLog("captureTextStyles: paragraphs", ePara); }

            return snapshot;
        }

        /* 控えた書式をフレームへ戻す */
        function restoreTextStyles(frame, snapshot) {
            var charProps = getCharStyleProps();
            try {
                var characters = frame.textRange.characters;
                for (var i = 0; i < characters.length && i < snapshot.chars.length; i++) {
                    restoreAttributes(characters[i].characterAttributes, snapshot.chars[i], charProps);
                }
            } catch (eChar) { debugLog("restoreTextStyles: characters", eChar); }

            var paraProps = getParagraphStyleProps();
            try {
                var paragraphs = frame.paragraphs;
                for (var p = 0; p < paragraphs.length && p < snapshot.paras.length; p++) {
                    var paraAttrs = paragraphs[p].paragraphAttributes;
                    restoreAttributes(paraAttrs, snapshot.paras[p], paraProps);
                    restoreTabStops(paraAttrs, snapshot.paras[p].tabStops);
                }
            } catch (ePara) { debugLog("restoreTextStyles: paragraphs", ePara); }
        }

        /* 指定した名前の属性値を控える（読めなかった属性は控えない）*/
        function snapshotAttributes(attrs, propertyNames) {
            var snapshot = {};
            for (var i = 0; i < propertyNames.length; i++) {
                try { snapshot[propertyNames[i]] = attrs[propertyNames[i]]; } catch (e) { }
            }
            return snapshot;
        }

        /* 控えた属性値を戻す（1つ失敗しても残りは戻す）*/
        function restoreAttributes(attrs, snapshot, propertyNames) {
            if (!snapshot) return;
            for (var i = 0; i < propertyNames.length; i++) {
                var propertyName = propertyNames[i];
                if (snapshot[propertyName] == null) continue;
                safeSet(attrs, propertyName, snapshot[propertyName]);
            }
        }

        /* 段落のタブストップを位置と揃えだけの配列として控える（取得できなければ null）*/
        function snapshotTabStops(paraAttrs) {
            var stops = [];
            try {
                var tabStops = paraAttrs.tabStops;
                for (var i = 0; i < tabStops.length; i++) {
                    stops.push({ position: tabStops[i].position, alignment: tabStops[i].alignment });
                }
            } catch (e) {
                return null;
            }
            return stops;
        }

        /* 控えたタブストップを TabStopInfo として作り直して戻す */
        function restoreTabStops(paraAttrs, stops) {
            if (!stops) return;
            try {
                var tabs = [];
                for (var i = 0; i < stops.length; i++) {
                    var tab = new TabStopInfo();
                    tab.alignment = stops[i].alignment;
                    tab.position = stops[i].position;
                    tabs.push(tab);
                }
                paraAttrs.tabStops = tabs;
            } catch (e) { debugLog("restoreTabStops", e); }
        }

        /* テキストフレームの順序を反転する関数 */
        /* テキストフレーム内の行の順序を反転する */
        function reverseOrder(objects) {
            transformContents(objects, function (txt) {
                var lines = splitParagraphLines(txt);
                lines.reverse();
                return lines.join("\r");
            });
        }

        /* 重複行を削除する関数 */
        function removeDuplicateLines(objects) {
            transformContents(objects, function (txt) {
                var lines = splitParagraphLines(txt);
                var seen = {};
                var kept = [];
                for (var i = 0; i < lines.length; i++) {
                    /* "toString" などの組み込みプロパティ名と衝突しないよう接頭辞を付ける */
                    var seenKey = "#" + lines[i];
                    if (!seen[seenKey]) {
                        seen[seenKey] = true;
                        kept.push(lines[i]);
                    }
                }
                return kept.join("\r");
            });
        }

        /* テキストフレーム内の行を文字コード順で並べ替える */
        function sortByCharCode(objects) {
            transformContents(objects, function (txt) {
                var lines = splitParagraphLines(txt);
                lines.sort();
                return lines.join("\r");
            });
        }

        /* テキストフレーム内の行を文字数順で並べ替える */
        function sortByLength(objects) {
            transformContents(objects, function (txt) {
                var lines = splitParagraphLines(txt);
                lines.sort(function (a, b) { return a.length - b.length; });
                return lines.join("\r");
            });
        }

        /* 和欧間のスペースを削除する関数
         * 欧文同士（英単語間）のスペースは残し、それ以外のスペースを削除する */

        function removeCjkLatinSpaces(objects) {
            transformContentsKeepingFormat(objects, function (txt) {
                var result = "";
                for (var i = 0; i < txt.length; i++) {
                    var c = txt.charAt(i);
                    if (c === " " || c === "\u3000") {
                        var prev = (i > 0) ? txt.charAt(i - 1) : "";
                        var next = (i < txt.length - 1) ? txt.charAt(i + 1) : "";
                        if (isLatinLetterOrDigit(prev) && isLatinLetterOrDigit(next)) {
                            result += c;
                        }
                        /* それ以外のスペースは削除（何も追加しない）  */
                    } else {
                        result += c;
                    }
                }
                return result;
            });
        }

        /* 1文字ごとに改行を挿入する関数 */
        function addLineBreakPerChar(objects) {
            transformContents(objects, function (txt) {
                var result = "";
                for (var i = 0; i < txt.length; i++) {
                    var currentChar = txt.charAt(i);
                    result += currentChar;
                    if (isAnyBreak(currentChar) || i >= txt.length - 1) continue;
                    if (!isAnyBreak(txt.charAt(i + 1))) result += "\r";
                }
                return result;
            });
        }

        /* 指定文字数ごとに改行を挿入する関数。
           折り返しだけを breakChar でつなぎ、元からあった段落改行はそのまま残す */
        function addLineBreakAtCount(objects, count, useForcedBreak) {
            var maxChars = parseInt(count, 10);
            if (!maxChars || maxChars <= 0) maxChars = parseInt(DEFAULT_BREAK_COUNT, 10);
            var breakChar = useForcedBreak ? String.fromCharCode(3) : "\r";
            transformContents(objects, function (txt) {
                var lines = splitParagraphLines(txt);
                var wrappedLines = [];
                for (var i = 0; i < lines.length; i++) {
                    var line = lines[i];
                    var segments = [];
                    while (line.length > maxChars) {
                        segments.push(line.substring(0, maxChars));
                        line = line.substring(maxChars);
                    }
                    segments.push(line);
                    wrappedLines.push(segments.join(breakChar));
                }
                return wrappedLines.join("\r");
            });
        }

        /* 強制改行を通常の改行に変換する関数 */
        function convertForcedLineBreaks(objects) {
            mutateMatchingChars(objects, isForcedBreak, String.fromCharCode(13));
        }

        /* 改行を強制改行に変換する関数 */
        function convertToForcedBreaks(objects) {
            mutateMatchingChars(objects, isParagraphBreak, String.fromCharCode(3));
        }

        /* 指定した記号の後に改行を挿入し、beforeChars の文字は直前で改行する関数
           （既定は和文・欧文の句読点と終止記号の後で改行。直前の改行は指定時のみ）*/
        function addLineBreakAtPunctuation(objects, punctuationChars, beforeChars) {
            var punctuation = punctuationChars || DEFAULT_BREAK_CHARS;
            var breakBefore = beforeChars || "";
            transformContents(objects, function (txt) {
                /* 1つしか無い文字は箇条の区切りではないとみなし、直前で改行しない */
                var activeBreakBefore = keepRepeatedChars(txt, breakBefore);
                /* 「後ろに実体のある文字が残っているか」は末尾位置を1回求めれば足りる */
                var lastVisibleIndex = findLastVisibleIndex(txt);
                var result = "";
                for (var i = 0; i < txt.length; i++) {
                    var currentChar = txt.charAt(i);
                    /* 行頭（先頭・改行の直後）にあるときは直前に改行を入れない */
                    if (activeBreakBefore.indexOf(currentChar) !== -1 && result !== "" && !isAnyBreak(result.charAt(result.length - 1))) {
                        result += "\r";
                    }
                    result += currentChar;
                    if (punctuation.indexOf(currentChar) === -1 || i >= lastVisibleIndex) continue;
                    if (!isAnyBreak(txt.charAt(i + 1))) result += "\r";
                }
                return result;
            });
        }

        /* chars のうち、txt に2つ以上ある文字だけを返す */
        function keepRepeatedChars(txt, chars) {
            var kept = "";
            for (var i = 0; i < chars.length; i++) {
                var targetChar = chars.charAt(i);
                var firstIndex = txt.indexOf(targetChar);
                if (firstIndex !== -1 && txt.indexOf(targetChar, firstIndex + 1) !== -1) kept += targetChar;
            }
            return kept;
        }

        /* 各テキストフレームの段落を上から順に走査し、段落ごとに
           makeFrames(sourceFrame, paragraph, originX, originY, fontSize) が返したフレームを集める。
           beginFrame が渡されていれば、各フレームの走査前に1回だけ呼ぶ（実測などの下準備用）。
           走査後に元フレームを削除し、生成したフレームをグループ化せずに返す */
        function splitFramesByParagraph(objects, makeFrames, beginFrame) {
            var sourceFrames = getTextFrames(objects);
            var resultFrames = [];

            for (var i = 0; i < sourceFrames.length; i++) {
                var sourceFrame = sourceFrames[i];
                if (beginFrame) beginFrame(sourceFrame);
                var originX = sourceFrame.position[0];
                var originY = sourceFrame.position[1];
                var paragraphCount = sourceFrame.paragraphs.length;

                for (var j = 0; j < paragraphCount; j++) {
                    var paragraph = sourceFrame.paragraphs[j];
                    var metrics = getParagraphMetrics(paragraph, sourceFrame);
                    var madeFrames = makeFrames(sourceFrame, paragraph, originX, originY, metrics.size, j);
                    for (var k = 0; k < madeFrames.length; k++) resultFrames.push(madeFrames[k]);
                    originY -= metrics.leading;
                }
                sourceFrame.remove();
            }

            return resultFrames;
        }

        /* 段落の文字サイズと行送りを返す。
           TextRange 自体に size / leading は無いので characterAttributes から読み、
           取得できないときはフレーム全体の書式、それも駄目なら既定値へ落とす */
        function getParagraphMetrics(paragraph, sourceFrame) {
            var fontSize = 0;
            var leading = 0;
            try {
                var attrs = paragraph.characterAttributes;
                fontSize = attrs.size;
                leading = attrs.leading;
            } catch (e) { debugLog("getParagraphMetrics: paragraph attributes", e); }

            if (!fontSize) {
                try { fontSize = sourceFrame.textRange.characterAttributes.size; } catch (e) { debugLog("getParagraphMetrics: frame attributes", e); }
            }
            if (!fontSize) fontSize = DEFAULT_FONT_SIZE_PT;
            if (!leading) leading = fontSize * AUTO_LEADING_RATIO;

            return { size: fontSize, leading: leading };
        }

        /* 分割対象になる文字（改行・タブ・スペース以外）の数を数える */
        function countSplittableChars(txt) {
            var text = String(txt || "");
            var count = 0;
            for (var i = 0; i < text.length; i++) {
                if (!isNonSplittableChar(text.charAt(i))) count++;
            }
            return count;
        }

        /* タブ直後の文字が、その段落の先頭文字からどれだけ右にあるかを段落ごとに返す。
           TextRange には座標が無いため、複製をアウトライン化してグリフの実測値から求める。
           戻り値は段落インデックスをキーにした配列（求められない段落は空配列）*/
        function collectTabOffsetsByParagraph(sourceFrame) {
            var offsetsByParagraph = [[]];

            var outlineInfo = null;
            try { outlineInfo = buildOutlineCharBounds(sourceFrame); } catch (e) { debugLog("collectTabOffsetsByParagraph: outline bounds", e); }
            if (outlineInfo && outlineInfo.outlinedRoot) removeItems([outlineInfo.outlinedRoot]);
            if (!outlineInfo || !outlineInfo.ok) return offsetsByParagraph;

            var boundsList = outlineInfo.boundsList;
            var txt = String(sourceFrame.contents || "");

            /* グリフ数と文字数がずれると対応が取れないので、その場合は呼び出し側の概算に任せる */
            if (countSplittableChars(txt) !== boundsList.length) {
                debugLog("collectTabOffsetsByParagraph: glyph count mismatch");
                return offsetsByParagraph;
            }

            var paragraphIndex = 0;
            var paragraphOriginX = null;
            var glyphIndex = 0;
            var afterTab = false;

            for (var i = 0; i < txt.length; i++) {
                var currentChar = txt.charAt(i);
                if (isParagraphBreak(currentChar)) {
                    paragraphIndex++;
                    offsetsByParagraph[paragraphIndex] = [];
                    paragraphOriginX = null;
                    afterTab = false;
                    continue;
                }
                if (isTabChar(currentChar)) {
                    afterTab = true;
                    continue;
                }
                if (isNonSplittableChar(currentChar)) continue;

                var glyphLeft = boundsList[glyphIndex][0];
                if (paragraphOriginX === null) paragraphOriginX = glyphLeft;
                if (afterTab) {
                    offsetsByParagraph[paragraphIndex].push(glyphLeft - paragraphOriginX);
                    afterTab = false;
                }
                glyphIndex++;
            }
            return offsetsByParagraph;
        }

        /* タブで分解する関数（元のタブ位置に合わせて横へ並べ直す）*/
        function splitByTab(objects) {
            var targetLayer = app.activeDocument.activeLayer;
            var tabOffsets = [];

            return splitFramesByParagraph(objects, function (sourceFrame, paragraph, originX, originY, fontSize, paragraphIndex) {
                var offsetsX = tabOffsets[paragraphIndex] || [];
                var segments = stripTrailingBreaks(paragraph.contents).split("\t");
                var madeFrames = [];
                var prevFrame = null;

                for (var i = 0; i < segments.length; i++) {
                    var segmentFrame = sourceFrame.duplicate(targetLayer);
                    segmentFrame.contents = segments[i];

                    var segmentX = originX;
                    if (i > 0) {
                        if ((i - 1) < offsetsX.length) {
                            segmentX = originX + offsetsX[i - 1];
                        } else if (prevFrame) {
                            /* タブ位置が取れない分は直前フレームの右端から半角分あける */
                            segmentX = prevFrame.visibleBounds[2] + (fontSize * 0.5);
                        } else {
                            segmentX = originX + (fontSize * i);
                        }
                    }
                    segmentFrame.position = [segmentX, originY];
                    prevFrame = segmentFrame;
                    madeFrames.push(segmentFrame);
                }
                return madeFrames;
            }, function (sourceFrame) {
                /* タブ位置の実測はフレーム単位で1回だけ行う */
                tabOffsets = collectTabOffsetsByParagraph(sourceFrame);
            });
        }

        /* 改行で分割する関数（段落ごとに別フレームへ）*/
        function splitByLineBreak(objects) {
            var targetLayer = app.activeDocument.activeLayer;
            return splitFramesByParagraph(objects, function (sourceFrame, paragraph, originX, originY) {
                var paragraphText = stripTrailingBreaks(paragraph.contents);
                if (paragraphText === "") return [];

                var lineFrame = sourceFrame.duplicate(targetLayer);
                lineFrame.contents = paragraphText;
                lineFrame.position = [originX, originY];
                return [lineFrame];
            });
        }

        /* 組まれた行が1行に収まっているか（折り返しも文字あふれも false）*/
        function fitsInOneLine(frame) {
            try {
                if (frame.lines.length !== 1) return false;
                return frame.lines[0].characters.length >= frame.characters.length;
            } catch (e) { debugLog("fitsInOneLine", e); return false; }
        }

        /* 枠を詰めたときに文字が動かないよう、残す辺の位置を比率で返す（0=行頭側, 0.5=中央, 1=行末側）。
           均等配置（最終行も均等）は行の自然な幅が決まらないので null を返し、詰める対象から外す */
        function getLineAnchorRatio(frame) {
            try {
                var justification = frame.paragraphs[0].paragraphAttributes.justification;
                if (justification === Justification.FULLJUSTIFY) return null;
                if (justification === Justification.CENTER || justification === Justification.FULLJUSTIFYLASTLINECENTER) return 0.5;
                if (justification === Justification.RIGHT || justification === Justification.FULLJUSTIFYLASTLINERIGHT) return 1;
            } catch (e) { debugLog("getLineAnchorRatio", e); }
            return 0;
        }

        /* 枠の組み方向のサイズと行頭側の辺の位置を返す（縦組みは上下を反転した軸で扱う）*/
        function getBoxExtent(textPath, isHorizontal) {
            var bounds = null;
            try { bounds = textPath.geometricBounds; } catch (e) { debugLog("getBoxExtent", e); }
            if (!bounds) return null;
            return isHorizontal
                ? { start: bounds[0], size: bounds[2] - bounds[0] }
                : { start: -bounds[1], size: bounds[1] - bounds[3] };
        }

        /* 枠のサイズを組み方向に合わせて設定する（横組みは幅、縦組みは高さ）*/
        function setBoxExtent(textPath, isHorizontal, size) {
            if (!(size > 0)) return false;
            try {
                if (isHorizontal) textPath.width = size;
                else textPath.height = size;
            } catch (e) { debugLog("setBoxExtent", e); return false; }
            return true;
        }

        /* エリア内文字の枠を、その行が折り返さない最小の幅（縦組みは高さ）まで詰める。
           行の自然な幅を読む方法が無いので、折り返すかどうかを見ながら二分探索する。
           詰めると行揃えに応じて文字が動くため、最後に元の文字位置へ戻す */
        function fitAreaBoxToLine(frame) {
            var textPath = null;
            try {
                if (frame.kind !== TextType.AREATEXT) return;
                textPath = frame.textPath;
            } catch (e) { debugLog("fitAreaBoxToLine: textPath", e); return; }
            if (!textPath || !fitsInOneLine(frame)) return;

            var anchorRatio = getLineAnchorRatio(frame);
            if (anchorRatio === null) return;

            var isHorizontal = (frame.orientation === TextOrientation.HORIZONTAL);
            var box = getBoxExtent(textPath, isHorizontal);
            if (!box || !(box.size > 0)) return;

            /* 収まらない幅（tooSmall）と収まる幅（fitted）で挟み込む */
            var tooSmall = 0;
            var fitted = box.size;
            for (var i = 0; i < BOX_FIT_STEPS && (fitted - tooSmall) > BOX_FIT_TOLERANCE; i++) {
                var candidate = (tooSmall + fitted) / 2;
                if (setBoxExtent(textPath, isHorizontal, candidate) && fitsInOneLine(frame)) fitted = candidate;
                else tooSmall = candidate;
            }
            if (!setBoxExtent(textPath, isHorizontal, fitted)) return;

            /* サイズ変更で残る辺は行揃えと無関係なので、比率で決めた位置へ戻す */
            var fittedBox = getBoxExtent(textPath, isHorizontal);
            if (!fittedBox) return;
            var delta = (box.start + anchorRatio * (box.size - fitted)) - fittedBox.start;
            if (!delta) return;
            try {
                frame.translate(isHorizontal ? delta : 0, isHorizontal ? 0 : -delta);
            } catch (e) { debugLog("fitAreaBoxToLine: translate", e); }
        }

        /* 組まれている行の文字列と行送りをまとめて読み出す。
           フレームを作り始めると lines を取り直せなくなるので、分割前に読み切っておく */
        function collectVisualLines(frame) {
            var lines = [];
            var lineCount = 0;
            try { lineCount = frame.lines.length; } catch (e) { debugLog("collectVisualLines: read lines", e); return lines; }

            for (var i = 0; i < lineCount; i++) {
                var line = null;
                try { line = frame.lines[i]; } catch (e) { debugLog("collectVisualLines: line " + i, e); }
                if (!line) break;

                var lineText = "";
                try { lineText = stripTrailingBreaks(line.contents); } catch (e) { debugLog("collectVisualLines: contents", e); }
                lines.push({ text: lineText, leading: getParagraphMetrics(line, frame).leading });
            }
            return lines;
        }

        /* 見かけの改行（折り返し位置）で分割する関数。
           lines は組まれた状態の行を返すので、エリア内文字の自動折り返しも1行として扱える。
           複製したフレームを行送り分ずつ送って置くことで、元の行位置へ揃える */
        function splitByVisualLine(objects) {
            var targetLayer = app.activeDocument.activeLayer;
            var sourceFrames = getTextFrames(objects);
            var resultFrames = [];

            for (var i = 0; i < sourceFrames.length; i++) {
                var sourceFrame = sourceFrames[i];
                var isHorizontal = (sourceFrame.orientation === TextOrientation.HORIZONTAL);
                var originX = sourceFrame.position[0];
                var originY = sourceFrame.position[1];
                var lines = collectVisualLines(sourceFrame);

                for (var j = 0; j < lines.length; j++) {
                    /* 2行目以降は、その行の行送り分だけ次の行の位置へ送る（縦組みは左方向）*/
                    if (j > 0) {
                        if (isHorizontal) originY -= lines[j].leading;
                        else originX -= lines[j].leading;
                    }
                    if (lines[j].text === "") continue;

                    var lineFrame = sourceFrame.duplicate(targetLayer);
                    lineFrame.contents = lines[j].text;
                    lineFrame.position = [originX, originY];
                    fitAreaBoxToLine(lineFrame);
                    resultFrames.push(lineFrame);
                }
                sourceFrame.remove();
            }

            return resultFrames;
        }

        /* フレーム末尾の改行文字（\r \n 強制改行）を除去し、除去数を返す。
           除去後に中身が空になったらフレームごと削除し Infinity を返す（呼び出し側で index を打ち切る）*/
        function trimTrailingBreaks(frame) {
            var removed = 0;
            for (var ci = frame.characters.length - 1; ci >= 0; ci--) {
                if (isAnyBreak(frame.characters[ci].contents)) {
                    frame.characters[ci].remove();
                    removed++;
                } else {
                    break;
                }
            }
            if (/^\s*$/.test(frame.contents)) {
                frame.remove();
                return Infinity;
            }
            return removed;
        }

        /* 組み方向から、分割時に基準とする軸と geometricBounds の末尾側 index を返す。
           横組み → Y方向に伸びるので tail = bottom(3)、縦組み → X方向(左)に伸びるので tail = left(0) */
        function getTailAxis(frame) {
            var isHorizontal = (frame.orientation === TextOrientation.HORIZONTAL);
            return {
                axisIndex: isHorizontal ? 1 : 0,
                boundsIndex: isHorizontal ? 3 : 0
            };
        }

        /* 1フレームを段落ごとに分割し、書式と位置を保ったフレーム配列を返す。
           TextRange.duplicate で書式を維持し、geometricBounds の tail 座標で位置を合わせる。
           参考: Split Rows for Ai.jsx の splitRowsPoint 方式 */
        function splitFrameKeepStyle(sourceFrame) {
            var tail = getTailAxis(sourceFrame);

            /* 末尾改行を事前に除去。空になったフレームは trimTrailingBreaks 側で削除済み */
            if (trimTrailingBreaks(sourceFrame) === Infinity) return [];

            var paragraphs = sourceFrame.paragraphs;
            if (paragraphs.length <= 1) return [sourceFrame];

            var splitFrames = [];

            /* 後ろの段落から順に処理（参考スクリプトと同じ方式）*/
            for (var i = paragraphs.length - 1; i >= 1; i--) {
                var currentParagraph = paragraphs[i];

                /* 空行またはホワイトスペースのみの行は消して次へ */
                if (/^\s*$/.test(currentParagraph.contents)) {
                    currentParagraph.remove();
                    continue;
                }

                /* 分割前の tail 座標＝この段落があるべき位置の基準 */
                var oldTail = sourceFrame.geometricBounds[tail.boundsIndex];

                var newFrame = sourceFrame.duplicate(sourceFrame, ElementPlacement.PLACEAFTER);
                newFrame.contents = "";
                currentParagraph.duplicate(newFrame, ElementPlacement.INSIDE);
                trimTrailingBreaks(newFrame);

                /* 新フレームの tail を元フレームの旧 tail に揃えて元の位置へ戻す */
                var delta = [0, 0];
                delta[tail.axisIndex] = oldTail - newFrame.geometricBounds[tail.boundsIndex];
                newFrame.translate(delta[0], delta[1]);
                splitFrames.unshift(newFrame);

                currentParagraph.remove();

                /* 元フレームの末尾改行を除去し、除去した行数分 index を飛ばす。
                   空になって削除された場合は元フレームを触れないのでここで打ち切る */
                var trimmedCount = trimTrailingBreaks(sourceFrame);
                if (trimmedCount === Infinity) return splitFrames;
                i -= trimmedCount;
            }

            /* 先頭段落が残った元フレームを先頭へ戻す */
            if (splitFrames.length > 0 && !/^\s*$/.test(sourceFrame.contents)) {
                sourceFrame.move(splitFrames[0], ElementPlacement.PLACEBEFORE);
                splitFrames.unshift(sourceFrame);
            }
            return splitFrames;
        }

        /* 改行で分割（書式保持）*/
        function splitByLineBreakKeepStyle(objects) {
            var sourceFrames = getTextFrames(objects);
            var resultFrames = [];

            for (var i = 0; i < sourceFrames.length; i++) {
                var sourceFrame = sourceFrames[i];

                /* 空フレームはスキップ */
                if (/^\s*$/.test(sourceFrame.contents)) {
                    sourceFrame.remove();
                    continue;
                }

                var splitFrames = splitFrameKeepStyle(sourceFrame);
                for (var j = 0; j < splitFrames.length; j++) resultFrames.push(splitFrames[j]);
            }

            return resultFrames;
        }

        /* =========================================
         * 1文字ごとにテキストフレームを分割（書式保持）
         * ========================================= */
        function splitByCharKeepStyle(objects, mergeAreaText) {
            return splitByChar(objects, true, mergeAreaText);
        }

        /* =========================================
         * 1文字ごとにテキストフレームを分割（書式無視）
         * =========================================  */
        function splitByCharIgnoreStyle(objects, mergeAreaText) {
            return splitByChar(objects, false, mergeAreaText);
        }

        /* 1文字分割の共通処理。keepStyle=false のときは先頭フォント以外の書式をリセットしてから分割 */
        function splitByChar(objects, keepStyle, mergeAreaText) {
            return splitEachFrame(objects, function (textFrame) {
                if (!keepStyle) stripStyleKeepFirstFont(textFrame);
                return splitCharHighPrecision(textFrame, keepStyle);
            }, mergeAreaText);
        }

        /* =========================================
         * 単語ごとにテキストフレームを分割（書式保持）
         * スペース・タブ・改行で区切った並びを1語とし、区切りの文字は捨てる
         * ========================================= */
        function splitByWord(objects, mergeAreaText) {
            return splitEachFrame(objects, splitWordHighPrecision, mergeAreaText);
        }

        /* フレームごとに splitFrame で分割して結果をまとめる。
           mergeAreaText=true のときは元のフレームごとにエリア内文字へ変換してスレッドでつなぐ */
        function splitEachFrame(objects, splitFrame, mergeAreaText) {
            var frames = getTextFrames(objects);
            var resultFrames = [];
            for (var i = 0; i < frames.length; i++) {
                var made = splitFrame(frames[i]);
                if (mergeAreaText) made = threadAreaTextFrames(convertTextFramesToAreaText(made));
                for (var j = 0; j < made.length; j++) resultFrames.push(made[j]);
            }
            return resultFrames;
        }

        /* 区切り（スペース・タブ・改行）を除いた語の範囲を返す。
           start / end は contents 上の位置（end は含まない）、glyphStart はアウトラインのグリフ番号 */
        function collectWordRanges(txt) {
            var text = String(txt || "");
            var ranges = [];
            var currentRange = null;
            var glyphIndex = 0;
            for (var i = 0; i < text.length; i++) {
                if (isNonSplittableChar(text.charAt(i))) {
                    currentRange = null;
                    continue;
                }
                if (currentRange) currentRange.end = i + 1;
                else {
                    currentRange = { start: i, end: i + 1, glyphStart: glyphIndex };
                    ranges.push(currentRange);
                }
                glyphIndex++;
            }
            return ranges;
        }

        /* boundsList の start から count 個を合わせた範囲を返す */
        function unionBoundsRange(boundsList, start, count) {
            var first = boundsList[start];
            var merged = [first[0], first[1], first[2], first[3]];
            for (var i = start + 1; i < start + count; i++) {
                var bounds = boundsList[i];
                if (bounds[0] < merged[0]) merged[0] = bounds[0];
                if (bounds[1] > merged[1]) merged[1] = bounds[1];
                if (bounds[2] > merged[2]) merged[2] = bounds[2];
                if (bounds[3] < merged[3]) merged[3] = bounds[3];
            }
            return merged;
        }

        /* 単語ごとに別フレームへ分割する（書式は1文字ずつ写す）。
           位置はアウトライン化したグリフの範囲に合わせ、グリフ数が文字数と合わなければ文字幅の積算で並べる */
        function splitWordHighPrecision(textFrame) {
            if (!textFrame || textFrame.typename !== "TextFrame") return [];

            var txt, chars, targetLayer;
            try {
                txt = String(textFrame.contents || "");
                chars = textFrame.textRange.characters;
                targetLayer = textFrame.layer;
            } catch (e) { debugLog("splitWordHighPrecision: read frame", e); return []; }

            var wordRanges = collectWordRanges(txt);
            if (wordRanges.length === 0) return [];

            var outlineInfo = null;
            try { outlineInfo = buildOutlineCharBounds(textFrame); } catch (e) { debugLog("splitWordHighPrecision: outline bounds", e); }
            if (outlineInfo && outlineInfo.outlinedRoot) removeItems([outlineInfo.outlinedRoot]);
            var boundsList = (outlineInfo && outlineInfo.ok && countSplittableChars(txt) === outlineInfo.boundsList.length)
                ? outlineInfo.boundsList : null;

            /* フォールバック：回転しているフレームでも並びが崩れないよう、回転角に沿ってオフセットを掛ける */
            var offsetsX = null;
            var angleRad = 0;
            if (!boundsList) {
                debugLog("splitWordHighPrecision: glyph count mismatch");
                offsetsX = measureCharOffsetsX(textFrame, targetLayer);
                try { angleRad = Math.atan2(textFrame.matrix.mValueB, textFrame.matrix.mValueA); } catch (e) { }
            }

            var madeFrames = [];
            for (var i = 0; i < wordRanges.length; i++) {
                var range = wordRanges[i];
                var newFrame = null;
                try {
                    newFrame = targetLayer.textFrames.add();
                    newFrame.contents = txt.substring(range.start, range.end);
                } catch (e) {
                    debugLog("splitWordHighPrecision: add frame", e);
                    removeItems([newFrame]);
                    continue;
                }

                /* 書式と変形の引き継ぎは失敗しても続行する */
                var newChars = newFrame.textRange.characters;
                for (var k = range.start; k < range.end; k++) {
                    try { copyCharacterAttributes(newChars[k - range.start], chars[k]); } catch (e) { }
                }
                try {
                    newFrame.matrix = textFrame.matrix;
                    newFrame.left = textFrame.left;
                    newFrame.top = textFrame.top;
                } catch (e) { debugLog("splitWordHighPrecision: copy transform", e); }

                try {
                    if (boundsList) {
                        moveFrameToMatchBounds(newFrame, unionBoundsRange(boundsList, range.glyphStart, range.end - range.start));
                    } else {
                        var offsetX = offsetsX[range.start] || 0;
                        newFrame.left = textFrame.left + offsetX * Math.cos(angleRad);
                        newFrame.top = textFrame.top - offsetX * Math.sin(angleRad);
                    }
                } catch (e) { debugLog("splitWordHighPrecision: place frame", e); }

                madeFrames.push(newFrame);
            }

            removeItems([textFrame]);
            return madeFrames;
        }

        /* エリア内文字かを返す（種類が読めなければ false）*/
        function isAreaTextSafely(textFrame) {
            try { return textFrame.kind === TextType.AREATEXT; } catch (e) { return false; }
        }

        /* ポイント文字の bounds を枠にしてエリア内文字を作り、内容と主な属性を移す（元は削除。作れなければ元を返す）*/
        function rebuildAsAreaText(sourceFrame) {
            try {
                var frameBounds = sourceFrame.geometricBounds;
                var frameWidth = frameBounds[2] - frameBounds[0];
                var frameHeight = frameBounds[1] - frameBounds[3];
                if (frameWidth <= 0 || frameHeight <= 0) return sourceFrame;

                var sourceLayer = sourceFrame.layer;
                var frameRect = sourceLayer.pathItems.rectangle(frameBounds[1], frameBounds[0], frameWidth, frameHeight);
                frameRect.stroked = false;
                frameRect.filled = false;

                var areaFrame = null;
                try { areaFrame = sourceLayer.textFrames.areaText(frameRect); } catch (e) { areaFrame = null; }
                if (!areaFrame) {
                    removeItems([frameRect]);
                    return sourceFrame;
                }

                safeSet(areaFrame, "contents", sourceFrame.contents);
                copyCharacterAttributes(areaFrame.textRange, sourceFrame.textRange);
                removeItems([sourceFrame]);
                return areaFrame;
            } catch (e) {
                debugLog("rebuildAsAreaText", e);
                return sourceFrame;
            }
        }

        /* テキストフレームをエリア内文字に変換する（ネイティブAPI → メニューコマンド → bounds から作り直し の順に試す）。
           並び順は保ち、変換できなかったものは元のまま返す */
        function convertTextFramesToAreaText(textFrames) {
            if (!textFrames || textFrames.length === 0) return textFrames;

            var doc = app.activeDocument;
            var previousSelection = doc.selection;
            var convertedFrames = [];

            for (var i = 0; i < textFrames.length; i++) {
                var textFrame = textFrames[i];
                if (!textFrame || textFrame.typename !== "TextFrame") continue;

                if (!isAreaTextSafely(textFrame)) {
                    try {
                        if (textFrame.kind === TextType.POINTTEXT && textFrame.convertPointObjectToAreaObject) {
                            textFrame.convertPointObjectToAreaObject();
                        }
                    } catch (e) { }
                }
                if (isAreaTextSafely(textFrame)) {
                    convertedFrames.push(textFrame);
                    continue;
                }

                /* メニューコマンドは見た目を最も保てる（名前は環境によって違う）*/
                var menuConvertedFrame = null;
                try {
                    doc.selection = [textFrame];
                    try { app.executeMenuCommand("ConvertToAreaType"); } catch (e) {
                        try { app.executeMenuCommand("ConvertToAreaText"); } catch (err) { }
                    }
                    if (doc.selection.length === 1 && doc.selection[0].typename === "TextFrame" && isAreaTextSafely(doc.selection[0])) {
                        menuConvertedFrame = doc.selection[0];
                    }
                } catch (e) { debugLog("convertTextFramesToAreaText: menu command", e); }

                convertedFrames.push(menuConvertedFrame || rebuildAsAreaText(textFrame));
            }

            try { doc.selection = previousSelection; } catch (e) { }
            return convertedFrames;
        }

        /* エリア内文字を渡された順にスレッドでつなぐ（つないだ後も参照はそのまま使える）*/
        function threadAreaTextFrames(textFrames) {
            if (!textFrames || textFrames.length < 2) return textFrames;

            var areaFrames = [];
            for (var i = 0; i < textFrames.length; i++) {
                if (textFrames[i] && textFrames[i].typename === "TextFrame" && isAreaTextSafely(textFrames[i])) areaFrames.push(textFrames[i]);
            }
            if (areaFrames.length < 2) return textFrames;

            var doc = app.activeDocument;
            var previousSelection = doc.selection;
            try {
                doc.selection = areaFrames;
                app.executeMenuCommand("threadTextCreate");
            } catch (e) { debugLog("threadAreaTextFrames", e); }
            try { doc.selection = previousSelection; } catch (e) { }
            return areaFrames;
        }

        /* 配列内のアイテムをまとめて削除（失敗は無視）*/
        function removeItems(items) {
            for (var i = 0; i < items.length; i++) {
                try { if (items[i]) items[i].remove(); } catch (e) { }
            }
        }

        /* 属性へ try 付きで代入（設定が失敗しても続行）*/
        function safeSet(target, propertyName, value) { try { target[propertyName] = value; } catch (e) { } }

        /* srcAttrs の1属性を dstAttrs へコピー（読み書きとも try で保護）*/
        function copyAttr(dstAttrs, srcAttrs, propertyName) { try { dstAttrs[propertyName] = srcAttrs[propertyName]; } catch (e) { } }

        /* characterAttributes を初期化（フォント・サイズは保持、色は黒・各種は既定へ）*/
        function applyResetStyle(charAttrs, keepFont, keepSize, blackColor) {
            if (keepFont) safeSet(charAttrs, "textFont", keepFont);
            if (keepSize != null) safeSet(charAttrs, "size", keepSize);
            safeSet(charAttrs, "fillColor", blackColor);
            safeSet(charAttrs, "baselineShift", 0);
            safeSet(charAttrs, "horizontalScale", 100);
            safeSet(charAttrs, "verticalScale", 100);
            safeSet(charAttrs, "rotation", 0);
            safeSet(charAttrs, "tracking", 0);
            safeSet(charAttrs, "kerningMethod", KerningMethod.METRICS);
            safeSet(charAttrs, "autoLeading", true);
        }

        /* 書式リセット（先頭文字のフォント情報のみ保持）*/
        function stripStyleKeepFirstFont(textFrame) {
            if (!textFrame || textFrame.typename !== "TextFrame") return;

            var textRange, chars, keepFont = null, keepSize = null;
            try {
                textRange = textFrame.textRange;
                chars = textRange.characters;
                if (!chars || chars.length < 1) return;
                keepFont = chars[0].characterAttributes.textFont;
                keepSize = chars[0].characterAttributes.size;
            } catch (e) { debugLog("stripStyleKeepFirstFont: read attributes", e); }
            if (!chars || chars.length < 1) return;

            var blackColor = new GrayColor();
            blackColor.gray = 100;

            try { applyResetStyle(textRange.characterAttributes, keepFont, keepSize, blackColor); } catch (e) { return; }
            for (var i = 0; i < chars.length; i++) {
                try { applyResetStyle(chars[i].characterAttributes, keepFont, keepSize, blackColor); } catch (e) { }
            }
        }

        /* 分割対象にならない文字（改行・タブ・スペース）か */
        function isNonSplittableChar(content) {
            return content === "" || content === " " || content === "　" ||
                isAnyBreak(content) || isTabChar(content);
        }

        /* 高精度分割（アウトライン化したグリフのバウンディングボックスに合わせて1文字ずつ配置）*/
        function splitCharHighPrecision(textFrame, keepStyle) {
            if (!textFrame || textFrame.typename !== "TextFrame") return [];

            var chars, charCount;
            try {
                chars = textFrame.textRange.characters;
                charCount = chars.length;
            } catch (e) { debugLog("splitCharHighPrecision: read characters", e); return []; }
            if (!charCount) return [];

            var outlineInfo = null;
            try { outlineInfo = buildOutlineCharBounds(textFrame); } catch (e) { debugLog("splitCharHighPrecision: outline bounds", e); }
            if (!outlineInfo || !outlineInfo.ok) return splitCharFallback(textFrame, keepStyle);

            var boundsList = outlineInfo.boundsList;

            /* 合字などでグリフ数と文字数がずれると途中から対応がずれるため、
               一致しない場合は作り始める前にフォールバックへ回す */
            if (countSplittableChars(textFrame.contents) !== boundsList.length) {
                debugLog("splitCharHighPrecision: glyph count mismatch");
                removeItems([outlineInfo.outlinedRoot]);
                return splitCharFallback(textFrame, keepStyle);
            }

            var targetLayer = textFrame.layer;
            var madeFrames = [];
            var boundsIndex = 0;

            /* 途中で失敗したら作りかけを片付けてフォールバックへ回す */
            function giveUpToFallback() {
                removeItems(madeFrames);
                removeItems([outlineInfo.outlinedRoot]);
                return splitCharFallback(textFrame, keepStyle);
            }

            for (var i = 0; i < charCount; i++) {
                var charItem, content;
                try { charItem = chars[i]; content = charItem.contents; } catch (e) { continue; }
                if (isNonSplittableChar(content)) continue;
                if (boundsIndex >= boundsList.length) return giveUpToFallback();

                var newFrame = null;
                try {
                    newFrame = targetLayer.textFrames.add();
                    newFrame.contents = content;
                } catch (e) { debugLog("splitCharHighPrecision: add frame", e); return giveUpToFallback(); }

                /* 書式と変形の引き継ぎは失敗しても続行する */
                try {
                    if (keepStyle) copyCharacterAttributes(newFrame.textRange, charItem);
                    else copyBaseFontAttributes(newFrame, textFrame);
                    newFrame.matrix = textFrame.matrix;
                    newFrame.left = textFrame.left;
                    newFrame.top = textFrame.top;
                } catch (e) { debugLog("splitCharHighPrecision: copy style", e); }

                try {
                    moveFrameToMatchBounds(newFrame, boundsList[boundsIndex]);
                } catch (e) {
                    debugLog("splitCharHighPrecision: match bounds", e);
                    removeItems([newFrame]);
                    return giveUpToFallback();
                }

                madeFrames.push(newFrame);
                boundsIndex++;
            }

            removeItems([outlineInfo.outlinedRoot, textFrame]);
            return madeFrames;
        }

        /* テキストフレームをアウトライン化し、グリフごとの geometricBounds を読み順で返す */
        function buildOutlineCharBounds(textFrame) {
            var duplicatedFrame = null;
            try { duplicatedFrame = textFrame.duplicate(textFrame.parent, ElementPlacement.PLACEATBEGINNING); } catch (e) {
                try { duplicatedFrame = textFrame.duplicate(textFrame.layer, ElementPlacement.PLACEATBEGINNING); } catch (err) { return { ok: false }; }
            }

            var outlinedGroup = null;
            try { outlinedGroup = duplicatedFrame.createOutline(); } catch (e) { debugLog("buildOutlineCharBounds: createOutline", e); }
            removeItems([duplicatedFrame]);
            if (!outlinedGroup) return { ok: false };

            /* アウトライン結果が単一グループなら、その中身をグリフとして扱う */
            var glyphItems = [];
            try {
                var topLevelItems = outlinedGroup.pageItems;
                var innerItems = (topLevelItems.length === 1 && topLevelItems[0].typename === "GroupItem")
                    ? topLevelItems[0].pageItems : topLevelItems;
                for (var i = 0; i < innerItems.length; i++) glyphItems.push(innerItems[i]);
            } catch (e) { debugLog("buildOutlineCharBounds: collect glyphs", e); }

            sortOutlineItems(glyphItems);
            if (glyphItems.length === 0) {
                removeItems([outlinedGroup]);
                return { ok: false };
            }

            var boundsList = [];
            for (var j = 0; j < glyphItems.length; j++) {
                try { boundsList.push(glyphItems[j].geometricBounds); } catch (e) { }
            }
            return { ok: boundsList.length > 0, outlinedRoot: outlinedGroup, boundsList: boundsList };
        }

        /* アウトライン項目を読み順（上の行から、行内は左から）に並べ替える。items は破壊的に更新する */
        function sortOutlineItems(items) {
            if (!items || items.length <= 1) return;

            var glyphRecords = [];
            for (var i = 0; i < items.length; i++) {
                var bounds;
                try { bounds = items[i].geometricBounds; } catch (e) { continue; }
                if (!bounds || bounds.length !== 4) continue;
                glyphRecords.push({
                    item: items[i],
                    left: bounds[0],
                    centerY: (bounds[1] + bounds[3]) / 2,
                    height: Math.abs(bounds[1] - bounds[3]),
                    order: i
                });
            }
            if (glyphRecords.length <= 1) return;

            var rowThreshold = estimateCharRowThreshold(glyphRecords);

            glyphRecords.sort(function (a, b) {
                var dy = b.centerY - a.centerY;
                if (Math.abs(dy) > 0.001) return (dy < 0) ? -1 : 1;
                var dx = a.left - b.left;
                if (Math.abs(dx) > 0.001) return (dx < 0) ? -1 : 1;
                return a.order - b.order;
            });

            /* Y中心が近いものを同じ行にまとめ、行の代表Yは平均で更新する */
            var rows = [];
            for (var j = 0; j < glyphRecords.length; j++) {
                var record = glyphRecords[j];
                var placed = false;
                for (var k = 0; k < rows.length; k++) {
                    if (Math.abs(record.centerY - rows[k].centerY) > rowThreshold) continue;
                    rows[k].items.push(record);
                    rows[k].centerY = (rows[k].centerY * (rows[k].items.length - 1) + record.centerY) / rows[k].items.length;
                    placed = true;
                    break;
                }
                if (!placed) rows.push({ centerY: record.centerY, items: [record] });
            }

            rows.sort(function (a, b) { return b.centerY - a.centerY; });

            var sortedItems = [];
            for (var rowIndex = 0; rowIndex < rows.length; rowIndex++) {
                rows[rowIndex].items.sort(function (a, b) {
                    var dx = a.left - b.left;
                    if (Math.abs(dx) > 0.5) return (dx < 0) ? -1 : 1;
                    return a.order - b.order;
                });
                for (var glyphIndex = 0; glyphIndex < rows[rowIndex].items.length; glyphIndex++) {
                    sortedItems.push(rows[rowIndex].items[glyphIndex].item);
                }
            }

            /* バウンディング取得に失敗した要素は sortedItems に含まれないため、
               上書きではなく作り直して末尾に古い要素（重複）が残らないようにする */
            items.length = 0;
            for (var m = 0; m < sortedItems.length; m++) items.push(sortedItems[m]);
        }

        /* 行判定のしきい値をグリフ高さの中央値から推定する */
        function estimateCharRowThreshold(glyphRecords) {
            var heights = [];
            for (var i = 0; i < glyphRecords.length; i++) {
                if (glyphRecords[i].height > 0) heights.push(glyphRecords[i].height);
            }
            if (heights.length === 0) return 8;

            heights.sort(function (a, b) { return a - b; });
            var medianHeight = heights[Math.floor(heights.length / 2)] || heights[0];
            var rowThreshold = medianHeight * 0.6;
            return (rowThreshold < 2) ? 2 : rowThreshold;
        }

        /* 1文字分の文字属性を新しいテキスト範囲へコピーする */
        function copyCharacterAttributes(dstRange, srcChar) {
            var srcAttrs, dstAttrs;
            try {
                srcAttrs = srcChar.characterAttributes;
                dstAttrs = dstRange.characterAttributes;
            } catch (e) { debugLog("copyCharacterAttributes: read attributes", e); return; }

            var copiedProps = ["textFont", "size", "horizontalScale", "verticalScale",
                "tracking", "baselineShift", "rotation", "autoLeading", "kerningMethod"];
            for (var i = 0; i < copiedProps.length; i++) copyAttr(dstAttrs, srcAttrs, copiedProps[i]);

            /* 色と行送りは「無色」「自動」のときにコピーしない */
            try { if (srcAttrs.fillColor && srcAttrs.fillColor.typename !== "NoColor") dstAttrs.fillColor = srcAttrs.fillColor; } catch (e) { }
            try {
                if (srcAttrs.strokeColor && srcAttrs.strokeColor.typename !== "NoColor") {
                    dstAttrs.strokeColor = srcAttrs.strokeColor;
                    dstAttrs.strokeWeight = srcAttrs.strokeWeight;
                }
            } catch (e) { }
            try { if (!srcAttrs.autoLeading) dstAttrs.leading = srcAttrs.leading; } catch (e) { }
        }

        /* 書式を無視して分割する場合でも、フォントと文字サイズは元フレームから引き継ぐ
           （新規テキストフレームの既定書式に落ちると、元の見た目と大きさが変わってしまう）*/
        function copyBaseFontAttributes(dstFrame, srcFrame) {
            var srcAttrs, dstAttrs;
            try {
                srcAttrs = srcFrame.textRange.characterAttributes;
                dstAttrs = dstFrame.textRange.characterAttributes;
            } catch (e) { debugLog("copyBaseFontAttributes: read attributes", e); return; }

            copyAttr(dstAttrs, srcAttrs, "textFont");
            copyAttr(dstAttrs, srcAttrs, "size");
        }

        /* アウトライン化して求めた実寸バウンディングボックスの中心へフレームを移動する */
        function moveFrameToMatchBounds(newFrame, targetBounds) {
            if (!newFrame || !targetBounds || targetBounds.length !== 4) return;

            var duplicatedFrame = null;
            try { duplicatedFrame = newFrame.duplicate(newFrame.parent, ElementPlacement.PLACEATBEGINNING); } catch (e) {
                try { duplicatedFrame = newFrame.duplicate(newFrame.layer, ElementPlacement.PLACEATBEGINNING); } catch (err) { return; }
            }

            var outlinedGroup = null;
            try { outlinedGroup = duplicatedFrame.createOutline(); } catch (e) { debugLog("moveFrameToMatchBounds: createOutline", e); }
            removeItems([duplicatedFrame]);
            if (!outlinedGroup) return;

            var currentBounds = null;
            try { currentBounds = outlinedGroup.geometricBounds; } catch (e) { }
            removeItems([outlinedGroup]);
            if (!currentBounds || currentBounds.length !== 4) return;

            var dx = (targetBounds[0] + targetBounds[2]) / 2 - (currentBounds[0] + currentBounds[2]) / 2;
            var dy = (targetBounds[1] + targetBounds[3]) / 2 - (currentBounds[1] + currentBounds[3]) / 2;

            try { newFrame.left += dx; newFrame.top += dy; } catch (e) {
                try { newFrame.translate(dx, dy); } catch (err) { }
            }
        }

        /* 各文字の左端X方向オフセットを先頭から積算して配列で返す（フォールバック用）。
           文字ごとに先頭から測り直すと文字数の2乗に比例して遅くなるため、1回の走査で全件求める */
        function measureCharOffsetsX(textFrame, targetLayer) {
            var measuredProps = ["textFont", "size", "horizontalScale", "verticalScale", "tracking"];
            var chars = textFrame.textRange.characters;
            var offsets = [];
            var offsetX = 0;

            for (var i = 0; i < chars.length; i++) {
                offsets.push(offsetX);

                var currentChar = chars[i];
                if (isNonSplittableChar(currentChar.contents)) continue;

                var measureFrame = null;
                try {
                    measureFrame = targetLayer.textFrames.add();
                    measureFrame.contents = currentChar.contents;
                    var measureAttrs = measureFrame.textRange.characterAttributes;
                    var srcAttrs = currentChar.characterAttributes;
                    for (var j = 0; j < measuredProps.length; j++) copyAttr(measureAttrs, srcAttrs, measuredProps[j]);
                    offsetX += measureFrame.width;
                } catch (e) { debugLog("measureCharOffsetsX: measure char", e); }
                removeItems([measureFrame]);
            }
            return offsets;
        }

        /* フォールバック処理（アウトラインを使わず、文字幅の積算で位置を再構成）*/
        function splitCharFallback(textFrame, keepStyle) {
            if (!textFrame || textFrame.typename !== "TextFrame") return [];

            var charCount, targetLayer;
            try {
                charCount = textFrame.textRange.characters.length;
                targetLayer = textFrame.layer;
            } catch (e) { debugLog("splitCharFallback: read frame", e); return []; }
            if (!charCount) return [];

            /* 回転しているフレームでも並びが崩れないよう、回転角に沿ってオフセットを掛ける */
            var angleRad = 0;
            try {
                var matrix = textFrame.matrix;
                angleRad = Math.atan2(matrix.mValueB, matrix.mValueA);
            } catch (e) { debugLog("splitCharFallback: matrix", e); }

            var offsetsX = measureCharOffsetsX(textFrame, targetLayer);
            var madeFrames = [];
            for (var i = charCount - 1; i >= 0; i--) {
                try {
                    var charItem = textFrame.textRange.characters[i];
                    var content = charItem.contents;
                    if (isNonSplittableChar(content)) continue;

                    var newFrame = targetLayer.textFrames.add();
                    newFrame.contents = content;
                    if (keepStyle) copyCharacterAttributes(newFrame.textRange, charItem);
                    else copyBaseFontAttributes(newFrame, textFrame);
                    try { newFrame.matrix = textFrame.matrix; } catch (e) { debugLog("splitCharFallback: matrix", e); }

                    var offsetX = offsetsX[i] || 0;
                    newFrame.left = textFrame.left + offsetX * Math.cos(angleRad);
                    newFrame.top = textFrame.top - offsetX * Math.sin(angleRad);

                    madeFrames.push(newFrame);
                } catch (e) { debugLog("splitCharFallback: main loop", e); }
            }

            removeItems([textFrame]);
            return madeFrames;
        }

        /* =========================================
         * 連結（縦・横）
         *
         * いずれも見た目ベースの近似連結で、複雑な書式差・回転・厳密な段落属性までは保持しない。
         * - 縦連結：上から下、同じ高さでは左から右の順に、各行を \r でつないだ1つのテキストへ再構成
         * - 横連結（行維持）：同じ行のテキストを左から右へ連結し、行は別フレームのまま残す
         * - 横連結（行統合）：行ごとに連結したうえで、行間ルール（英文ハイフン除去／語間スペース／
         *   句点でのみ改行）に従って1つのテキストへまとめる
         * ========================================= */

        /* Y位置でフレームを行ごとにグループ化する（同じ行と見なすY座標差は LINE_Y_THRESHOLD）*/
        function groupFramesIntoRows(frames) {
            return groupByLineY(sortByY(frames), LINE_Y_THRESHOLD);
        }

        /* 行内のフレームをX順に連結した文字列と、その並びを返す */
        function concatRowText(rowFrames) {
            var sortedFrames = sortByX(rowFrames);
            var rowText = "";
            for (var i = 0; i < sortedFrames.length; i++) rowText += stripTrailingBreaks(sortedFrames[i].contents);
            return { sorted: sortedFrames, text: rowText };
        }

        /* 横連結（行維持）：同じ行を左から右へ連結し、行ごとに別テキストフレームとして残す（グループ化しない）*/
        function concatHorizontalOnly(objects) {
            var textFrames = getTextFrames(objects);
            if (textFrames.length < 2) return textFrames;

            var rows = groupFramesIntoRows(textFrames);
            var resultFrames = [];

            for (var i = 0; i < rows.length; i++) {
                /* 1つしかない行はそのまま残す（内容に触れない）*/
                if (rows[i].length === 1) {
                    resultFrames.push(rows[i][0]);
                    continue;
                }

                var row = concatRowText(rows[i]);
                row.sorted[0].contents = row.text;
                resultFrames.push(row.sorted[0]);
                removeItems(row.sorted.slice(1));
            }

            return resultFrames;
        }

        /* 縦連結：各フレームを行単位へ分解し、位置順に並べ直して1つのテキストへ再構成する */
        function concatVertical(objects) {
            var sourceFrames = getTextFrames(objects);
            if (sourceFrames.length < 2) return sourceFrames;

            sourceFrames = sortByPosition(sourceFrames);

            /* 各テキストフレームを行単位に分解し、元の行送りで仮のY位置を与える */
            var lineFrames = [];
            for (var i = 0; i < sourceFrames.length; i++) {
                var sourceFrame = sourceFrames[i];
                var lines = splitParagraphLines(sourceFrame.contents);
                var baseX = sourceFrame.position[0];
                var baseY = sourceFrame.position[1];
                var baseLeading = getParagraphMetrics(sourceFrame.textRange, sourceFrame).leading;

                for (var j = 0; j < lines.length; j++) {
                    var lineText = stripTrailingBreaks(lines[j]);
                    if (lineText === "") continue;

                    var lineFrame = sourceFrame.duplicate();
                    lineFrame.contents = lineText;
                    lineFrame.position = [baseX, baseY - (j * baseLeading)];
                    lineFrames.push(lineFrame);
                }
            }
            if (lineFrames.length === 0) return [];

            /* 仮配置後に位置で並べ直して連結順を決める */
            lineFrames = sortByPosition(lineFrames);

            var mergedLines = [];
            for (var k = 0; k < lineFrames.length; k++) {
                var mergedLineText = stripTrailingBreaks(lineFrames[k].contents);
                if (mergedLineText !== "") mergedLines.push(mergedLineText);
            }
            if (mergedLines.length === 0) {
                removeItems(lineFrames);
                return [];
            }

            /* 最上段のフレームをベースに、残りは削除 */
            var baseFrame = lineFrames[0];
            baseFrame.contents = mergedLines.join("\r");
            removeItems(lineFrames.slice(1));

            var leftovers = [];
            for (var m = 0; m < sourceFrames.length; m++) {
                if (sourceFrames[m] !== baseFrame) leftovers.push(sourceFrames[m]);
            }
            removeItems(leftovers);

            return [baseFrame];
        }

        /* 塗り・線なしの矩形を作る（エリア内文字の枠用）*/
        function makeFramelessRect(bounds) {
            var rect = app.activeDocument.pathItems.rectangle(
                bounds[1], bounds[0], bounds[2] - bounds[0], bounds[1] - bounds[3]
            );
            rect.stroked = false;
            rect.filled = false;
            return rect;
        }

        /* Justification.LEFT は直接代入すると無視されるため、一時 resize（200%→50%＝実質等倍）で
           段落属性をリフレッシュしてから左揃えにする */
        function applyLeftJustification(frame) {
            if (!frame) return;
            try {
                frame.resize(200, 200);
                frame.resize(50, 50);
                frame.textRange.justification = Justification.LEFT;
            } catch (e) { debugLog("applyLeftJustification", e); }
        }

        /* 1行のみの横連結（area＝エリア内文字を新規作成 / それ以外＝先頭フレームへ集約）*/
        function concatHorizontalSingleLine(rowFrames, textMode) {
            var row = concatRowText(rowFrames);
            var sortedFrames = row.sorted;
            var baseAttrs = sortedFrames[0].textRange.characterAttributes;
            var resultFrame;

            if (textMode === "area") {
                resultFrame = createConcatOutputText("area", row.text, getUnionBounds(sortedFrames),
                    baseAttrs.textFont, baseAttrs.size, true);
            } else {
                sortedFrames[0].contents = row.text;
                resultFrame = sortedFrames[0];
                applyLeftJustification(resultFrame);
            }

            var leftovers = [];
            for (var i = 0; i < sortedFrames.length; i++) {
                if (sortedFrames[i] !== resultFrame) leftovers.push(sortedFrames[i]);
            }
            removeItems(leftovers);

            return [resultFrame];
        }

        /* 連結済みの各行を、英文ハイフン除去／語間スペース／句点改行のルールで1つの文字列へ */
        function buildJoinedParagraphText(mergedFrames) {
            var joinedText = "";
            for (var i = 0; i < mergedFrames.length; i++) {
                var content = stripTrailingBreaks(mergedFrames[i].contents);
                joinedText += content;
                if (i >= mergedFrames.length - 1) continue;

                var nextContent = stripTrailingBreaks(mergedFrames[i + 1].contents);
                if (/[A-Za-z0-9)]-$/.test(content) && /^[A-Za-z0-9(]/.test(nextContent)) {
                    /* 英単語がハイフンで分断 → ハイフン除去して結合 */
                    joinedText = joinedText.replace(/-$/, "");
                } else if (/[A-Za-z0-9)]$/.test(content) && /^[A-Za-z0-9(]/.test(nextContent)) {
                    /* 行末・次行頭がともに英単語 → 語間スペースを補う */
                    joinedText += " ";
                }
                /* 句点等で終わる場合のみ改行を残す */
                if (shouldInsertParagraphBreakBetweenLines(content)) joinedText += "\r";
            }
            return joinedText;
        }

        /* 連結結果テキストを point/area で出力する（font/size/kinsoku/justification を設定）。
           forceLeft が真なら、エリア内文字でも均等配置ではなく左揃えにする */
        function createConcatOutputText(textMode, joinedText, bounds, baseFont, baseFontSize, forceLeft) {
            var isPointText = (textMode === "point");
            var outputFrame = isPointText
                ? app.activeDocument.textFrames.pointText([bounds[0], bounds[1]])
                : app.activeDocument.textFrames.areaText(makeFramelessRect(bounds));

            outputFrame.contents = joinedText;
            outputFrame.textRange.characterAttributes.textFont = baseFont;
            outputFrame.textRange.characterAttributes.size = baseFontSize;
            if (outputFrame.paragraphs.length > 0) outputFrame.paragraphs[0].paragraphAttributes.kinsoku = "Soft";

            if (isPointText || forceLeft) {
                applyLeftJustification(outputFrame);
            } else {
                outputFrame.textRange.justification = Justification.FULLJUSTIFYLASTLINELEFT;
            }
            return outputFrame;
        }

        /* 横連結（行統合）：行ごとに連結したうえで、1つのテキストへまとめる。
           textMode が未指定または "mixed" のときは選択から自動判定し、混在時はエリア内文字を優先する */
        function concatHorizontal(objects, textMode) {
            var textFrames = getTextFrames(objects);
            if (textFrames.length < 2) return textFrames;

            if (!textMode || textMode === "mixed") {
                textMode = detectTextFrameType(textFrames);
                if (textMode === "mixed") textMode = "area";
            }

            /* 強制改行を削除してから行グループ化する */
            removeForcedLineBreaks(textFrames);
            var rows = groupFramesIntoRows(textFrames);
            if (rows.length === 1) return concatHorizontalSingleLine(rows[0], textMode);

            /* 行ごとにX順で連結して中間フレームを作る */
            var mergedFrames = [];
            for (var i = 0; i < rows.length; i++) {
                var row = concatRowText(rows[i]);
                var mergedFrame = row.sorted[0].duplicate();
                mergedFrame.contents = row.text;
                mergedFrame.position = row.sorted[0].position;
                mergedFrames.push(mergedFrame);
                removeItems(row.sorted);
            }

            var baseAttrs = mergedFrames[0].textRange.characterAttributes;
            var baseFont = baseAttrs.textFont;
            var baseFontSize = baseAttrs.size;
            var outputFrame = createConcatOutputText(textMode, buildJoinedParagraphText(mergedFrames),
                getUnionBounds(mergedFrames), baseFont, baseFontSize, false);

            /* 行送りは連結前の行間から復元する */
            if (mergedFrames.length >= 2) {
                var leading = Math.abs(mergedFrames[0].position[1] - mergedFrames[1].position[1]);
                if (leading < baseFontSize) leading = baseFontSize * MIN_LEADING_RATIO;
                outputFrame.textRange.characterAttributes.autoLeading = false;
                outputFrame.textRange.characterAttributes.leading = leading;
            }

            removeItems(mergedFrames);
            app.redraw();
            return [outputFrame];
        }

        /* =========================================
         * メインエンジン委譲（BridgeTalk）
         *
         * パレットは常駐エンジン（#targetengine）で動くが、その app は
         * パレット表示中に DOM 接続を失い "there is no document" を投げる。
         * そこで DOM を触る全処理は、生きた DOM を持つメインエンジン
         * （bridge.target = BridgeTalk.appSpecifier）へ BridgeTalk で都度委譲する。
         *
         * 上で定義済みの処理関数群を toString() で連結して本文に同梱し、
         * 末尾の __dispatch をメインエンジンで実行する。結果は
         * "OK:<state>" / "LINES:<encoded>" / "ERR:<msg>" の文字列で返す。
         * ========================================= */

        /* メインエンジンへ送る処理関数（上で定義済みのものを再利用）*/
        var __LIB_FUNCS = [
            debugLog, normalizeParagraphBreaks, splitParagraphLines, trimLineSpaces, isBlankLine,
            stripTrailingBreaks, isLatinLetterOrDigit, isAsciiTextOnly, isSentenceEndingJP, isSentenceEndingEN,
            shouldInsertParagraphBreakBetweenLines, getCharCodeSafe, isParagraphBreak, isForcedBreak, isAnyBreak,
            isTabChar, findLastVisibleIndex, isNonSplittableChar, countSplittableChars,
            getTextFrames, countTextFrameTypes, detectTextFrameType, countBreakTypes, transformContents,
            transformContentsKeepingFormat, rewriteFrameKeepingFormat, matchSubsequence, removeUnkeptCharacters, insertAddedText, replaceDifferingPart,
            hasMultipleLines, hasSpacesOrTabs, computeSelectionState, encodeSelectionState,
            mutateMatchingChars, removeForcedLineBreaks, removeItems, sortedCopy, sortByPosition, sortByY, sortByX,
            groupByLineY, getUnionBounds, groupTextFrames, applySplitGrouping,
            removeLineBreaks, removeAllBreaks, joinBreaksToOneLine, flattenToOneLine, removeEmptyLines, removeTabs, tabsToSpaces,
            trimSpaces, collapseSpaces, removeLinePrefix, toHalfWidthAlnumText, toFullWidthKanaText,
            toHiraganaText, toKatakanaText, toHalfWidthKanaText,
            toHalfWidthDigitText, toFullWidthDigitText, toSingleDigitFullWidthText, toKanjiNumeralText, toArabicNumeralText, toKanjiPositionalText, getTextConverter,
            fullToHalfAlnum, halfToFullKana, removeBulletMarkers, removeNumberMarkers,
            clearListFormatting, getCharStyleProps, getParagraphStyleProps,
            captureTextStyles, restoreTextStyles, snapshotAttributes, restoreAttributes,
            snapshotTabStops, restoreTabStops,
            reverseOrder, removeDuplicateLines, sortByCharCode, sortByLength, removeCjkLatinSpaces,
            addLineBreakPerChar, addLineBreakAtCount, convertForcedLineBreaks, convertToForcedBreaks,
            addLineBreakAtPunctuation, keepRepeatedChars, splitFramesByParagraph, getParagraphMetrics,
            collectTabOffsetsByParagraph, splitByTab, splitByLineBreak,
            fitsInOneLine, getLineAnchorRatio, getBoxExtent, setBoxExtent, fitAreaBoxToLine,
            collectVisualLines, splitByVisualLine,
            trimTrailingBreaks, getTailAxis, splitFrameKeepStyle, splitByLineBreakKeepStyle,
            splitByCharKeepStyle, splitByCharIgnoreStyle, splitByChar, stripStyleKeepFirstFont, splitCharHighPrecision,
            splitByWord, splitEachFrame, collectWordRanges, unionBoundsRange, splitWordHighPrecision,
            isAreaTextSafely, rebuildAsAreaText, convertTextFramesToAreaText, threadAreaTextFrames,
            buildOutlineCharBounds, sortOutlineItems, estimateCharRowThreshold, copyCharacterAttributes,
            copyBaseFontAttributes, moveFrameToMatchBounds, measureCharOffsetsX, splitCharFallback,
            groupFramesIntoRows, concatRowText, concatHorizontalOnly, concatVertical, concatHorizontal,
            makeFramelessRect, applyLeftJustification, concatHorizontalSingleLine, buildJoinedParagraphText,
            createConcatOutputText,
            toWordCap, toSentenceCase, toTitleCase,
            runStructureAction, runContentAction, runAction,
            runQueryAction, finalizeSelection,
            safeSet, copyAttr, applyResetStyle
        ];

        /* 処理関数がそのまま参照する定数（パレット側の値をメインエンジンへも渡す）*/
        var __WORKER_CONSTANTS = [
            ["DEFAULT_BREAK_CHARS", DEFAULT_BREAK_CHARS],
            ["DEFAULT_BREAK_COUNT", DEFAULT_BREAK_COUNT],
            ["LINE_Y_THRESHOLD", LINE_Y_THRESHOLD],
            ["AUTO_LEADING_RATIO", AUTO_LEADING_RATIO],
            ["MIN_LEADING_RATIO", MIN_LEADING_RATIO],
            ["DEFAULT_FONT_SIZE_PT", DEFAULT_FONT_SIZE_PT],
            ["BOX_FIT_STEPS", BOX_FIT_STEPS],
            ["BOX_FIT_TOLERANCE", BOX_FIT_TOLERANCE]
        ];

        /**
         * 定数を var 宣言の並びへ変換する（文字列はエスケープを避けて decodeURIComponent で復元）
         * @returns {string} "var NAME=...;" を並べたソース文字列
         */
        function buildConstSource() {
            var parts = [];
            for (var i = 0; i < __WORKER_CONSTANTS.length; i++) {
                var constName = __WORKER_CONSTANTS[i][0];
                var constValue = __WORKER_CONSTANTS[i][1];
                var literal = (typeof constValue === "number")
                    ? String(constValue)
                    : 'decodeURIComponent("' + encodeURIComponent(String(constValue)) + '")';
                parts.push("var " + constName + "=" + literal + ";");
            }
            return parts.join("\n");
        }

        /* Function.toString() の出力から関数本体だけを切り出す。
           ExtendScript は改行を CR で返し、前後のコメント断片（閉じていない \*\/ を含む）を
           混入させることがあるため、LF へ正規化したうえで先頭の function 行から
           閉じ括弧だけの行までを取り出す（そのままつなぐと構文エラーになる）*/
        function sliceFunctionSource(func) {
            var lines = String(func).replace(/\r\n/g, "\n").replace(/\r/g, "\n").split("\n");
            var firstIndex = -1;
            var lastIndex = -1;
            for (var i = 0; i < lines.length; i++) {
                if (firstIndex < 0 && /^\s*function\s/.test(lines[i])) firstIndex = i;
                if (/^\s*\}\s*$/.test(lines[i])) lastIndex = i;
            }
            if (firstIndex < 0) return String(func);
            if (lastIndex < firstIndex) {
                /* 1行で書かれた関数は、その行だけを取り出す */
                return /\}\s*$/.test(lines[firstIndex]) ? lines[firstIndex] : lines.slice(firstIndex).join("\n");
            }
            return lines.slice(firstIndex, lastIndex + 1).join("\n");
        }

        /* 定数と関数配列を1つのソース文字列にまとめる */
        function buildLibSource(funcs) {
            var sourceParts = [buildConstSource()];
            for (var i = 0; i < funcs.length; i++) sourceParts.push(sliceFunctionSource(funcs[i]));
            return sourceParts.join("\n");
        }

        var __LIB_SRC_CACHE = null;

        /* 全処理関数のソース（初回のみ組み立ててキャッシュ）*/
        function getLibSource() {
            if (__LIB_SRC_CACHE === null) __LIB_SRC_CACHE = buildLibSource(__LIB_FUNCS);
            return __LIB_SRC_CACHE;
        }

        /*
         * メインエンジンで実行されるディスパッチャ。
         * ここで参照する処理関数（getTextFrames 等）は getLibSource() で
         * 先に定義される。この関数自体はパレット側では呼ばず、toString() で
         * 本文に埋め込む用途のみ。
         */
        /* フレーム構成を変える処理（分割・連結・1行化）。該当しなければ null を返す */
        function runStructureAction(actionName, targets, params) {
            switch (actionName) {
                case "flatten": {
                    var flattened = flattenToOneLine(targets);
                    var flattenTargets = (flattened && flattened.length) ? flattened : targets;
                    trimSpaces(flattenTargets);
                    removeCjkLatinSpaces(flattenTargets);
                    collapseSpaces(flattenTargets);
                    return flattenTargets;
                }
                /* Option+［指定文字で改行］：すべて1行にしてから指定文字で改行 */
                case "flattenPunctuation": {
                    var flatTargets = runStructureAction("flatten", targets, params);
                    addLineBreakAtPunctuation(flatTargets, params.chars, params.beforeChars);
                    return flatTargets;
                }
                /* Option+［指定文字数で改行］：すべて1行にしてから指定文字数で改行 */
                case "flattenBreakAtCount": {
                    var flatCountTargets = runStructureAction("flatten", targets, params);
                    addLineBreakAtCount(flatCountTargets, params.count, params.forced);
                    return flatCountTargets;
                }
                case "splitByLineBreak": return applySplitGrouping(splitByLineBreak(targets), params.group);
                case "splitByLineBreakKeepStyle": return applySplitGrouping(splitByLineBreakKeepStyle(targets), params.group);
                case "splitByVisualLine": return applySplitGrouping(splitByVisualLine(targets), params.group);
                case "splitByTab": return applySplitGrouping(splitByTab(targets), params.group);
                case "splitByCharKeepStyle": return applySplitGrouping(splitByCharKeepStyle(targets, params.mergeAreaText), params.group);
                case "splitByCharIgnoreStyle": return applySplitGrouping(splitByCharIgnoreStyle(targets, params.mergeAreaText), params.group);
                case "splitByWord": return applySplitGrouping(splitByWord(targets, params.mergeAreaText), params.group);
                case "concatVertical": return concatVertical(targets);
                case "concatHorizontalOnly": return concatHorizontalOnly(targets);
                case "concatH": return concatHorizontal(targets, detectTextFrameType(targets));
                case "concatToArea": return concatHorizontal(targets, "area");
            }
            return null;
        }

        /* テキスト内容だけを書き換える処理（対象フレームはそのまま）*/
        function runContentAction(actionName, targets, params) {
            /* ケース・かな・数字の変換は getTextConverter へ委譲する */
            var convertText = getTextConverter(actionName);
            if (convertText) { transformContentsKeepingFormat(targets, convertText); return; }

            switch (actionName) {
                case "removeLineBreaks": if (params.forced) removeAllBreaks(targets); else removeLineBreaks(targets); return;
                case "addLineBreakPerChar": addLineBreakPerChar(targets); return;
                case "punctuation": addLineBreakAtPunctuation(targets, params.chars, params.beforeChars); return;
                case "breakAtCount": addLineBreakAtCount(targets, params.count, params.forced); return;
                case "convertForcedLineBreaks": convertForcedLineBreaks(targets); return;
                case "convertToForcedBreaks": convertToForcedBreaks(targets); return;
                case "removeTabs": removeTabs(targets); return;
                case "tabsToSpaces": tabsToSpaces(targets); return;
                case "trimSpaces": trimSpaces(targets); return;
                case "removeCjkLatinSpaces": removeCjkLatinSpaces(targets); return;
                case "collapseSpaces": collapseSpaces(targets); return;
                /* 先に連続を1つにまとめる（和欧間は前後の文字で判断するので、連続したままだと英単語間のスペースまで消える）*/
                case "cleanupSpaces": trimSpaces(targets); collapseSpaces(targets); removeCjkLatinSpaces(targets); return;
                case "removeAllSpaces": transformContentsKeepingFormat(targets, function (txt) { return txt.replace(/[ 　]/g, ""); }); return;
                case "fullToHalfAlnum": fullToHalfAlnum(targets); return;
                case "halfToFullKana": halfToFullKana(targets); return;
                /* Illustrator標準のリスト書式を先に外してから、本文に打たれた行頭マーカーを除去する */
                case "removeBulletMarkers": clearListFormatting(targets); removeBulletMarkers(targets); return;
                case "removeNumberMarkers": clearListFormatting(targets); removeNumberMarkers(targets); return;
                case "reverseOrder": reverseOrder(targets); return;
                case "removeDuplicateLines": removeDuplicateLines(targets); return;
                case "sortByCharCode": sortByCharCode(targets); return;
                case "sortByLength": sortByLength(targets); return;
                case "removeEmptyLines": removeEmptyLines(targets); return;
                case "spaceAfterPunct": transformContentsKeepingFormat(targets, function (txt) { return txt.replace(/([.,])(?=[^\s\d.,])/g, "$1 "); }); return;
                case "convertSymbol": {
                    /* ES の入れ子三項は左結合に誤評価されるため括弧で右結合を明示 */
                    var fromPattern = (params.from === "underscore") ? /_/g : ((params.from === "hyphen") ? /-/g : /[ 　]/g);
                    var toText = (params.to === "space") ? " " : ((params.to === "hyphen") ? "-" : "_");
                    transformContentsKeepingFormat(targets, function (txt) { return txt.replace(fromPattern, toText); });
                    return;
                }
            }
        }

        /* アクションIDに対応する処理を実行し、処理後の対象フレーム配列を返す */
        function runAction(actionName, targets, params) {
            var restructured = runStructureAction(actionName, targets, params);
            if (restructured) return restructured;
            runContentAction(actionName, targets, params);
            return targets;
        }

        /* 選択の取得・設定のみで完結するアクション。該当しなければ null を返す */
        function runQueryAction(actionId, params, doc, targets) {
            switch (actionId) {
                case "getState":
                    return "OK:" + encodeSelectionState(targets);
                case "getLines":
                    return (targets.length === 1) ? "LINES:" + encodeURIComponent(targets[0].contents) : "LINES:";
                case "getFirstText":
                    return (targets.length >= 1) ? "TEXT:" + encodeURIComponent(targets[0].contents) : "TEXT:";
                case "setLines":
                    if (targets.length === 1) targets[0].contents = params.text;
                    app.redraw();
                    return "OK:" + encodeSelectionState(getTextFrames(doc.selection));
                case "hiddenChar":
                    try { app.executeMenuCommand("showHiddenChar"); } catch (e) { debugLog("showHiddenChar", e); }
                    app.redraw();
                    return "OK:" + encodeSelectionState(targets);
                case "finalizeClose":
                    finalizeSelection(targets, params.turnOffHidden);
                    return "OK:";
            }
            return null;
        }

        /* パレットを閉じるときの後始末：1要素だけのグループを解除し、選択を整えて制御文字表示を戻す */
        function finalizeSelection(targets, turnOffHidden) {
            for (var i = 0; i < targets.length; i++) {
                try {
                    var parentGroup = targets[i].parent;
                    if (!parentGroup || parentGroup.typename !== "GroupItem" || parentGroup.pageItems.length !== 1) continue;
                    targets[i].move(parentGroup.parent, ElementPlacement.PLACEATEND);
                    parentGroup.remove();
                } catch (e) { debugLog("finalizeSelection: ungroup", e); }
            }
            try { if (targets.length > 0) app.activeDocument.selection = targets; } catch (e) { debugLog("finalizeSelection: select", e); }
            if (turnOffHidden) {
                try { app.executeMenuCommand("showHiddenChar"); } catch (e) { debugLog("finalizeSelection: hidden char", e); }
            }
            app.redraw();
        }

        function __dispatch(actionId, params) {
            if (app.documents.length === 0) return "ERR:nodoc";
            var doc;
            try { doc = app.activeDocument; } catch (e) { return "ERR:nodoc"; }

            var targets = getTextFrames(doc.selection);

            var queryResult = runQueryAction(actionId, params, doc, targets);
            if (queryResult !== null) return queryResult;

            /* 通常の処理アクション */
            if (!targets.length) return "OK:" + encodeSelectionState([]);

            var result;
            try {
                result = runAction(actionId, targets, params);
            } catch (err) {
                app.redraw();
                return "ERR:" + (err && err.message ? err.message : String(err));
            }

            var refreshed = getTextFrames((result && result.length) ? result : targets);
            if (refreshed.length > 0) {
                try { doc.selection = refreshed; } catch (e) { debugLog("__dispatch: select result", e); }
            }
            app.redraw();
            return "OK:" + encodeSelectionState(refreshed);
        }

        var __DISPATCH_SRC = "(" + sliceFunctionSource(__dispatch) + ")";

        /**
         * アクションのパラメーターを、そのまま eval できる JS リテラル文字列へ変換する
         * @param {Object} params - forced / turnOffHidden / group / mergeAreaText / count / chars / text / from / to を持つオブジェクト
         * @returns {string} "{ ... }" 形式のソース文字列
         */
        function paramsToSource(params) {
            if (!params) return "{}";

            var parts = [];
            if (params.forced !== undefined) parts.push("forced:" + (params.forced ? "true" : "false"));
            if (params.turnOffHidden !== undefined) parts.push("turnOffHidden:" + (params.turnOffHidden ? "true" : "false"));
            if (params.group !== undefined) parts.push("group:" + (params.group ? "true" : "false"));
            if (params.mergeAreaText !== undefined) parts.push("mergeAreaText:" + (params.mergeAreaText ? "true" : "false"));
            if (params.count !== undefined) parts.push("count:" + parseInt(params.count, 10));
            if (params.chars !== undefined) parts.push('chars:decodeURIComponent("' + encodeURIComponent(params.chars) + '")');
            if (params.beforeChars !== undefined) parts.push('beforeChars:decodeURIComponent("' + encodeURIComponent(params.beforeChars) + '")');
            if (params.text !== undefined) parts.push('text:decodeURIComponent("' + encodeURIComponent(params.text) + '")');
            if (params.from !== undefined) parts.push('from:"' + params.from + '"');
            if (params.to !== undefined) parts.push('to:"' + params.to + '"');
            return "{" + parts.join(",") + "}";
        }

        /**
         * 本文をメインエンジンへ送り、結果マーカーを解析して onDone を呼ぶ。
         * BridgeTalk は本文送信時にバックスラッシュをエスケープする（"\r" がターゲットで "\\r" になる）ため、
         * コード全体を encodeURIComponent で包んで送り（%エンコードに \ は出ない）、
         * ターゲット側で decodeURIComponent + eval して元ソースに復元してから実行する。
         * @param {string} code - メインエンジンで実行するソース
         * @param {Function} onDone - (status, payload) を受け取るコールバック。status は "ok" | "lines" | "text" | "error"
         * @returns {void}
         */
        function sendWorker(code, onDone) {
            var STATUS_BY_MARKER = { OK: "ok", LINES: "lines", TEXT: "text" };

            var bridge = new BridgeTalk();
            bridge.target = BridgeTalk.appSpecifier;
            bridge.body = "eval(decodeURIComponent(\"" + encodeURIComponent(code) + "\"));";
            bridge.onResult = function (bridgeResult) {
                var body = bridgeResult.body || "";
                var separatorIndex = body.indexOf(":");
                var marker = (separatorIndex >= 0) ? body.substring(0, separatorIndex) : body;
                var payload = (separatorIndex >= 0) ? body.substring(separatorIndex + 1) : "";
                onDone(STATUS_BY_MARKER[marker] || "error", payload);
            };
            bridge.onError = function (bridgeResult) {
                onDone("error", (bridgeResult && bridgeResult.body) ? bridgeResult.body : "BridgeTalk error");
            };
            bridge.send();
        }

        /**
         * メインエンジンへアクションを委譲する（非同期）
         * @param {string} actionId - アクションID
         * @param {Object} params - アクションのパラメーター
         * @param {Function} onDone - (status, payload) を受け取るコールバック
         * @returns {void}
         */
        function runWorker(actionId, params, onDone) {
            var code = getLibSource() + "\nvar __r=" + __DISPATCH_SRC + "(\"" + actionId + "\"," + paramsToSource(params) + ");__r;";
            sendWorker(code, onDone);
        }

        /**
         * state 文字列（"total|point|area|para|forced|tab|multiLines|multiFrames|hasSpTab"）をオブジェクトへ変換する
         * @param {string} encodedState - encodeSelectionState() が返した文字列
         * @returns {Object} 選択状態オブジェクト
         */
        function parseState(encodedState) {
            var fields = String(encodedState || "").split("|");
            return {
                total: parseInt(fields[0], 10) || 0,
                point: parseInt(fields[1], 10) || 0,
                area: parseInt(fields[2], 10) || 0,
                para: parseInt(fields[3], 10) || 0,
                forced: parseInt(fields[4], 10) || 0,
                tab: parseInt(fields[5], 10) || 0,
                multiLines: fields[6] === "1",
                multiFrames: fields[7] === "1",
                hasSpTab: fields[8] === "1"
            };
        }

        /**
         * Option(Alt)キーが押されているかを返す
         * @returns {boolean} 押されていれば true
         */
        function isAltPressed() {
            try {
                return !!(ScriptUI.environment.keyboardState && ScriptUI.environment.keyboardState.altKey);
            } catch (e) { debugLog("isAltPressed", e); }
            return false;
        }

        /* =========================================
         * 軽量ステータスポーラー（選択のリアルタイム反映用）
         *
         * 毎回 LIB 全体を送ると重いので、件数集計に必要な関数だけを同梱した
         * 軽量本文をメインエンジンへ送る。選択は変更せず、state 文字列だけを返す。
         * ========================================= */
        var __STATE_FUNCS = [
            debugLog, normalizeParagraphBreaks, splitParagraphLines,
            getCharCodeSafe, isParagraphBreak, isForcedBreak, isTabChar,
            getTextFrames, countTextFrameTypes, countBreakTypes,
            hasMultipleLines, hasSpacesOrTabs, computeSelectionState, encodeSelectionState
        ];
        var __STATE_LIB_CACHE = null;

        /* ステータス集計用の関数ソース（初回のみ組み立ててキャッシュ）*/
        function getStateLibSource() {
            if (__STATE_LIB_CACHE === null) __STATE_LIB_CACHE = buildLibSource(__STATE_FUNCS);
            return __STATE_LIB_CACHE;
        }

        function __stateDispatch() {
            if (app.documents.length === 0) return "ERR:nodoc";
            var doc;
            try { doc = app.activeDocument; } catch (e) { return "ERR:nodoc"; }
            return "OK:" + encodeSelectionState(getTextFrames(doc.selection));
        }
        var __STATE_DISPATCH_SRC = "(" + sliceFunctionSource(__stateDispatch) + ")";

        /**
         * 現在の選択をメインエンジンで集計し、state 文字列を受け取る（選択は変えない）
         * @param {Function} onDone - (status, payload) を受け取るコールバック
         * @returns {void}
         */
        function runStatePoll(onDone) {
            var code = getStateLibSource() + "\nvar __r=" + __STATE_DISPATCH_SRC + "();__r;";
            sendWorker(code, onDone);
        }

        /**
         * パレットを組み立てて表示する
         * @param {Array<TextFrame>} selectedObjects - 起動時に選択されていたテキストフレーム
         * @returns {void}
         */
        function showPalette(selectedObjects) {
            var paletteWindow = new Window("palette", getLabel(LABELS.dialog.title) + " " + SCRIPT_VERSION);
            setupWindow(paletteWindow);

            /**
             * 処理をメインエンジンへ委譲し、結果のステータスで表示を更新する
             * @param {string} actionId - アクションID
             * @param {Object} params - アクションのパラメーター
             * @returns {void}
             */
            function executeAction(actionId, params) {
                executeActionThen(actionId, params, null);
            }

            /**
             * executeAction と同じだが、成功後に after() を呼ぶ（行リスト再読込などの連鎖用）
             * @param {string} actionId - アクションID
             * @param {Object} params - アクションのパラメーター
             * @param {Function} after - 成功後に呼ぶコールバック（不要なら null）
             * @returns {void}
             */
            function executeActionThen(actionId, params, after) {
                runWorker(actionId, params || {}, function (status, payload) {
                    if (status === "error") {
                        showError({ message: payload });
                        return;
                    }
                    applySelectionState(parseState(payload));
                    if (after) after();
                });
            }

            /**
             * ステータスパネルを構築し、件数表示用の statictext をまとめて返す
             * @returns {Object} 件数表示の statictext を持つオブジェクト
             */
            function buildStatusPanel() {
                var textFrameCounts = countTextFrameTypes(selectedObjects);
                var breakCounts = countBreakTypes(selectedObjects);

                var statusPanel = addPanel(paletteWindow, getLabel(LABELS.panel.status), ["left", "top"]);
                statusPanel.margins = STATUS_MARGINS;

                var statusRow = statusPanel.add("group");
                statusRow.orientation = "row";
                statusRow.alignment = ["fill", "top"];
                statusRow.alignChildren = ["left", "center"];
                statusRow.spacing = STATUS_ROW_SPACING;

                var frameCountColumn = addColumnGroup(statusRow);
                frameCountColumn.alignChildren = ["left", "top"];
                var breakCountColumn = addColumnGroup(statusRow);
                breakCountColumn.alignChildren = ["left", "top"];

                /**
                 * 1行 = [ラベル：] [値] を作り、値側の statictext を返す
                 * @param {Group} column - 追加先のカラム
                 * @param {Object} labelNode - LABELS のラベルノード
                 * @param {number} value - 初期表示する件数
                 * @param {number} labelWidth - ラベル幅（省略時は自動）
                 * @returns {StaticText} 値表示用の statictext
                 */
                function addStatusRow(column, labelNode, value, labelWidth) {
                    var statusFieldRow = column.add("group");
                    statusFieldRow.orientation = "row";
                    statusFieldRow.alignChildren = ["left", "center"];

                    var fieldLabel = statusFieldRow.add("statictext", undefined, labelText(labelNode));
                    if (labelWidth) fieldLabel.preferredSize.width = labelWidth;
                    return statusFieldRow.add("statictext", undefined, String(value));
                }

                return {
                    target: addStatusRow(frameCountColumn, LABELS.info.targetCount, textFrameCounts.total),
                    point: addStatusRow(frameCountColumn, LABELS.info.pointCount, textFrameCounts.point),
                    area: addStatusRow(frameCountColumn, LABELS.info.areaCount, textFrameCounts.area),
                    para: addStatusRow(breakCountColumn, LABELS.info.paragraphBreak, breakCounts.paragraph, STATUS_LABEL_WIDTH),
                    forced: addStatusRow(breakCountColumn, LABELS.info.forcedBreak, breakCounts.forced, STATUS_LABEL_WIDTH),
                    tab: addStatusRow(breakCountColumn, LABELS.info.tab, breakCounts.tab, STATUS_LABEL_WIDTH)
                };
            }

            var statusFields = buildStatusPanel();

            /**
             * 選択状態をステータス表示と各ボタンの有効・無効へ反映する
             * @param {Object} state - parseState() が返した選択状態
             * @returns {void}
             */
            function applySelectionState(state) {
                statusFields.target.text = String(state.total);
                statusFields.point.text = String(state.point);
                statusFields.area.text = String(state.area);
                statusFields.para.text = String(state.para);
                statusFields.forced.text = String(state.forced);
                statusFields.tab.text = String(state.tab);

                var hasParagraph = state.para > 0;
                var hasForced = state.forced > 0;
                var hasAnyBreaks = hasParagraph || hasForced;
                var hasTabs = state.tab > 0;

                /* 行操作系：2行以上あるときだけ */
                btnReverseOrder.enabled = state.multiLines;
                btnRemoveDuplicateLines.enabled = state.multiLines;
                btnRemoveEmptyLines.enabled = state.multiLines;
                btnSortByCharCode.enabled = state.multiLines;
                btnSortByLength.enabled = state.multiLines;
                btnSplitByLine.enabled = state.multiLines;
                btnSplitByLineKeepStyle.enabled = state.multiLines;

                /* 見かけの改行：折り返しが起きるエリア内文字のときだけ */
                btnSplitByVisualLine.enabled = state.area > 0;

                /* 改行の削除・変換 */
                btnRemoveLineBreaks.enabled = hasAnyBreaks;
                chkIncludeForcedBreaks.enabled = hasForced;
                btnConvertBreaks.enabled = hasForced;
                btnConvertToForcedBreaks.enabled = hasParagraph;
                btnFlattenToOneLine.enabled = hasAnyBreaks || state.multiFrames;

                /* タブ */
                btnSplitByTab.enabled = hasTabs;
                btnRemoveTabs.enabled = hasTabs;
                btnTabsToSpaces.enabled = hasTabs;

                /* 連結：2つ以上のフレームが必要 */
                btnConcatV.enabled = state.multiFrames;
                btnConcatHOnly.enabled = state.multiFrames;
                btnConcatH.enabled = state.multiFrames;
                btnConcatToArea.enabled = state.multiFrames;

                /* スペース */
                btnTrimSpaces.enabled = state.hasSpTab;
                btnCjkLatinSpaces.enabled = state.hasSpTab;
                btnCollapseSpaces.enabled = state.hasSpTab;
                btnCleanupSpaces.enabled = state.hasSpTab;
                btnRemoveAllSpaces.enabled = state.hasSpTab;
            }

            /* 制御文字の表示状態 */
            var hiddenCharOn = false;
            var hiddenCharLabel = getLabel(LABELS.button.showHiddenChar);

            var tabbedPanel = paletteWindow.add("tabbedpanel");
            tabbedPanel.alignment = ["fill", "top"];
            tabbedPanel.alignChildren = ["fill", "top"];

            /* === タブ1: 基本 === */
            var tabBasic = tabbedPanel.add("tab", undefined, getLabel(LABELS.tab.basic));
            setupPaletteTab(tabBasic, "row", ["center", "top"]);

            /* 左カラム：改行 */
            var breakColumn = addColumnGroup(tabBasic);
            var panelBreakGroup = addPanel(breakColumn, getLabel(LABELS.panel.breakGroup), ["fill", "top"]);

            var flattenButtonRow = panelBreakGroup.add("group");
            flattenButtonRow.alignment = ["fill", "top"];
            flattenButtonRow.alignChildren = ["fill", "center"];
            flattenButtonRow.margins = BUTTON_ROW_MARGINS;

            var btnFlattenToOneLine = flattenButtonRow.add("button", undefined, getLabel(LABELS.button.flattenToOneLine));
            btnFlattenToOneLine.onClick = function () {
                executeAction("flatten");
            };

            /* 改行の削除 */
            var panelRemoveBreak = addPanel(panelBreakGroup, getLabel(LABELS.panel.removeBreak));

            var btnRemoveLineBreaks = panelRemoveBreak.add("button", undefined, getLabel(LABELS.button.removeLineBreaks));
            btnRemoveLineBreaks.helpTip = getLabel(LABELS.tooltip.removeLineBreaks);
            btnRemoveLineBreaks.onClick = function () {
                executeAction("removeLineBreaks", { forced: chkIncludeForcedBreaks.value });
            };

            var chkIncludeForcedBreaks = panelRemoveBreak.add("checkbox", undefined, getLabel(LABELS.checkbox.includeForcedBreaks));

            /* 改行の挿入 */
            var panelInsertBreak = addPanel(panelBreakGroup, getLabel(LABELS.panel.insertBreak));

            var btnAddLineBreaks = panelInsertBreak.add("button", undefined, getLabel(LABELS.button.addLineBreaks));
            btnAddLineBreaks.onClick = function () {
                executeAction("addLineBreakPerChar");
            };

            /* ［1文字ごとに改行］と［指定文字で改行］を分ける線 */
            addDivider(panelInsertBreak);

            var txtBreakChars = panelInsertBreak.add("edittext", undefined, DEFAULT_BREAK_CHARS);
            txtBreakChars.alignment = ["fill", "center"];
            txtBreakChars.helpTip = getLabel(LABELS.tooltip.breakChars);

            var txtBreakBeforeChars = panelInsertBreak.add("edittext", undefined, DEFAULT_BREAK_BEFORE_CHARS);
            txtBreakBeforeChars.alignment = ["fill", "center"];
            txtBreakBeforeChars.helpTip = getLabel(LABELS.tooltip.breakBeforeChars);

            var btnBreakAtChars = panelInsertBreak.add("button", undefined, getLabel(LABELS.button.breakAtChars));
            btnBreakAtChars.helpTip = getLabel(LABELS.tooltip.breakAtChars);
            btnBreakAtChars.onClick = function () {
                executeAction(isAltPressed() ? "flattenPunctuation" : "punctuation", { chars: txtBreakChars.text, beforeChars: txtBreakBeforeChars.text });
            };

            /* ［指定文字で改行］と［指定文字数で改行］を分ける線 */
            addDivider(panelInsertBreak);

            var breakCountRow = panelInsertBreak.add("group");
            breakCountRow.orientation = "row";
            breakCountRow.alignment = ["fill", "center"];
            breakCountRow.alignChildren = ["left", "center"];
            /* ∧∨と入力欄は隙間0で突き合わせる。文字数は1以上の整数 / butt the stepper against the field; a whole number of at least 1 */
            var breakCountInputGroup = breakCountRow.add("group");
            breakCountInputGroup.orientation = "row";
            breakCountInputGroup.alignChildren = ["left", "center"];
            breakCountInputGroup.spacing = 0;
            breakCountInputGroup.margins = 0;
            var breakCountStepper = addStepper(breakCountInputGroup, function () { return txtBreakCount; }, { integer: true, min: 1 });
            var txtBreakCount = breakCountInputGroup.add("edittext", undefined, DEFAULT_BREAK_COUNT);
            txtBreakCount.characters = 3;
            bindSteppedArrowKeys(txtBreakCount, breakCountStepper);
            var chkForcedBreakAtCount = breakCountRow.add("checkbox", undefined, getLabel(LABELS.checkbox.forcedBreak));

            var btnBreakAtCount = panelInsertBreak.add("button", undefined, getLabel(LABELS.button.breakAtCount));
            btnBreakAtCount.helpTip = getLabel(LABELS.tooltip.breakAtCount);
            btnBreakAtCount.onClick = function () {
                executeAction(isAltPressed() ? "flattenBreakAtCount" : "breakAtCount", { count: txtBreakCount.text, forced: chkForcedBreakAtCount.value });
            };

            /* 改行の切り換え */
            var panelConvertBreak = addPanel(panelBreakGroup, getLabel(LABELS.panel.convertBreak));

            var btnConvertBreaks = panelConvertBreak.add("button", undefined, getLabel(LABELS.button.convertBreaks));
            btnConvertBreaks.onClick = function () {
                executeAction("convertForcedLineBreaks");
            };

            var btnConvertToForcedBreaks = panelConvertBreak.add("button", undefined, getLabel(LABELS.button.convertToForcedBreaks));
            btnConvertToForcedBreaks.onClick = function () {
                executeAction("convertToForcedBreaks");
            };

            /* 右カラム：分割・連結 */
            var splitConcatColumn = addColumnGroup(tabBasic);
            var panelSplitGroup = addPanel(splitConcatColumn, getLabel(LABELS.panel.splitGroup), ["fill", "top"]);

            /* 改行・タブで分割 */
            var panelSplitByBreak = addPanel(panelSplitGroup, getLabel(LABELS.panel.splitByBreak));

            var btnSplitByLine = panelSplitByBreak.add("button", undefined, getLabel(LABELS.button.splitByLine));
            btnSplitByLine.helpTip = getSplitTooltip(LABELS.tooltip.splitByLine);
            btnSplitByLine.onClick = function () {
                executeAction("splitByLineBreak", { group: isAltPressed() });
            };

            var btnSplitByLineKeepStyle = panelSplitByBreak.add("button", undefined, getLabel(LABELS.button.splitByLineKeepStyle));
            btnSplitByLineKeepStyle.helpTip = getSplitTooltip(LABELS.tooltip.splitByLineKeepStyle);
            btnSplitByLineKeepStyle.onClick = function () {
                executeAction("splitByLineBreakKeepStyle", { group: isAltPressed() });
            };

            var btnSplitByVisualLine = panelSplitByBreak.add("button", undefined, getLabel(LABELS.button.splitByVisualLine));
            btnSplitByVisualLine.helpTip = getSplitTooltip(LABELS.tooltip.splitByVisualLine);
            btnSplitByVisualLine.onClick = function () {
                executeAction("splitByVisualLine", { group: isAltPressed() });
            };

            var btnSplitByTab = panelSplitByBreak.add("button", undefined, getLabel(LABELS.button.splitByTab));
            btnSplitByTab.helpTip = getSplitTooltip(LABELS.tooltip.splitByTab);
            btnSplitByTab.onClick = function () {
                executeAction("splitByTab", { group: isAltPressed() });
            };

            /* 1文字ずつ・単語ごとに分割 */
            var panelSplitByChar = addPanel(panelSplitGroup, getLabel(LABELS.panel.splitByChar));

            var btnSplitKeepStyle = panelSplitByChar.add("button", undefined, getLabel(LABELS.button.splitKeepStyle));
            btnSplitKeepStyle.helpTip = getSplitTooltip(LABELS.tooltip.splitKeepStyle);
            btnSplitKeepStyle.onClick = function () {
                executeAction("splitByCharKeepStyle", { group: isAltPressed(), mergeAreaText: chkMergeAreaText.value });
            };

            var btnSplitIgnoreStyle = panelSplitByChar.add("button", undefined, getLabel(LABELS.button.splitIgnoreStyle));
            btnSplitIgnoreStyle.helpTip = getSplitTooltip(LABELS.tooltip.splitIgnoreStyle);
            btnSplitIgnoreStyle.onClick = function () {
                executeAction("splitByCharIgnoreStyle", { group: isAltPressed(), mergeAreaText: chkMergeAreaText.value });
            };

            var btnSplitByWord = panelSplitByChar.add("button", undefined, getLabel(LABELS.button.splitByWord));
            btnSplitByWord.helpTip = getSplitTooltip(LABELS.tooltip.splitByWord);
            btnSplitByWord.onClick = function () {
                executeAction("splitByWord", { group: isAltPressed(), mergeAreaText: chkMergeAreaText.value });
            };

            var chkMergeAreaText = panelSplitByChar.add("checkbox", undefined, getLabel(LABELS.checkbox.mergeAreaText));
            chkMergeAreaText.helpTip = getLabel(LABELS.tooltip.mergeAreaText);

            /* 連結 */
            var panelConcat = addPanel(splitConcatColumn, getLabel(LABELS.panel.concat), ["center", "center"]);

            var concatButtonColumn = panelConcat.add("group");
            concatButtonColumn.margins = BUTTON_ROW_MARGINS;
            concatButtonColumn.orientation = "column";
            concatButtonColumn.alignment = ["fill", "top"];
            concatButtonColumn.alignChildren = ["fill", "center"];

            var btnConcatV = concatButtonColumn.add("button", undefined, getLabel(LABELS.button.concatV));
            btnConcatV.helpTip = getLabel(LABELS.tooltip.concatV);
            btnConcatV.onClick = function () {
                executeAction("concatVertical");
            };

            var btnConcatHOnly = concatButtonColumn.add("button", undefined, getLabel(LABELS.button.concatHOnly));
            btnConcatHOnly.helpTip = getLabel(LABELS.tooltip.concatHOnly);
            btnConcatHOnly.onClick = function () {
                executeAction("concatHorizontalOnly");
            };

            var btnConcatH = concatButtonColumn.add("button", undefined, getLabel(LABELS.button.concatH));
            btnConcatH.helpTip = getLabel(LABELS.tooltip.concatH);
            btnConcatH.onClick = function () {
                executeAction("concatH");
            };

            var btnConcatToArea = concatButtonColumn.add("button", undefined, getLabel(LABELS.button.concatToArea));
            btnConcatToArea.helpTip = getLabel(LABELS.tooltip.concatToArea);
            btnConcatToArea.onClick = function () {
                executeAction("concatToArea");
            };

            /* === タブ2: 行の編集 === */
            var tabLineArrange = tabbedPanel.add("tab", undefined, getLabel(LABELS.tab.lineArrange));
            setupPaletteTab(tabLineArrange, "row");

            /* 左カラム：行リスト */
            var lineListColumn = addColumnGroup(tabLineArrange);

            var lineListRow = lineListColumn.add("group");
            lineListRow.orientation = "row";
            lineListRow.alignChildren = ["fill", "fill"];
            lineListRow.spacing = 10;

            var lineListBox = lineListRow.add("listbox", undefined, [], { multiselect: false });
            lineListBox.preferredSize = LINE_LIST_SIZE;
            lineListBox.graphics.font = ScriptUI.newFont("dialog", "REGULAR", LINE_LIST_FONT_SIZE);

            /* リストボックスが保持する行データ */
            var lineArrangeLines = [];

            /**
             * リストの内容をテキストフレームへ書き戻す
             * @returns {void}
             */
            function applyLinesToTextFrame() {
                executeAction("setLines", { text: lineArrangeLines.join("\r") });
            }

            /**
             * リストボックスを再構築する
             * @param {number} selectIndex - 再構築後に選択する行番号
             * @param {boolean} skipApply - 真ならテキストフレームへの書き戻しを行わない
             * @returns {void}
             */
            function refreshLineList(selectIndex, skipApply) {
                lineListBox.removeAll();
                for (var i = 0; i < lineArrangeLines.length; i++) {
                    lineListBox.add("item", lineArrangeLines[i]);
                }
                if (lineArrangeLines.length > 0) {
                    if (selectIndex < 0) selectIndex = 0;
                    if (selectIndex >= lineArrangeLines.length) selectIndex = lineArrangeLines.length - 1;
                    lineListBox.selection = selectIndex;
                }
                updateLineListButtons();
                if (!skipApply) applyLinesToTextFrame();
            }

            /**
             * 選択中テキストフレームの内容を読み込んでリストへ反映する
             * @returns {void}
             */
            function loadLinesToList() {
                runWorker("getLines", {}, function (status, payload) {
                    lineArrangeLines = [];
                    if (status === "lines" && payload) {
                        lineArrangeLines = normalizeParagraphBreaks(decodeURIComponent(payload)).split("\r");
                    }
                    refreshLineList(0, true);
                });
            }

            /**
             * 行リストの操作ボタンの有効・無効を選択状態に合わせる
             * @returns {void}
             */
            function updateLineListButtons() {
                var hasSelection = lineListBox.selection !== null;
                btnLineUp.enabled = hasSelection && lineListBox.selection.index > 0;
                btnLineDown.enabled = hasSelection && lineListBox.selection.index < lineArrangeLines.length - 1;
                btnLineEdit.enabled = hasSelection;
                btnLineDelete.enabled = hasSelection;
            }

            /**
             * 選択行をダイアログで編集する
             * @returns {void}
             */
            function editSelectedLine() {
                if (!lineListBox.selection) return;
                var selectedIndex = lineListBox.selection.index;
                var editedText = prompt(getLabel(LABELS.prompt.editLine), lineArrangeLines[selectedIndex]);
                if (editedText === null) return;
                lineArrangeLines[selectedIndex] = editedText;
                refreshLineList(selectedIndex);
            }

            /**
             * 選択行を上下いずれかへ1行ぶん移動する
             * @param {number} offset - -1 なら上へ、1 なら下へ
             * @returns {void}
             */
            function moveSelectedLine(offset) {
                if (!lineListBox.selection) return;
                var selectedIndex = lineListBox.selection.index;
                var movedIndex = selectedIndex + offset;
                if (movedIndex < 0 || movedIndex >= lineArrangeLines.length) return;

                var movedLine = lineArrangeLines[selectedIndex];
                lineArrangeLines[selectedIndex] = lineArrangeLines[movedIndex];
                lineArrangeLines[movedIndex] = movedLine;
                refreshLineList(movedIndex);
            }

            lineListBox.onDoubleClick = editSelectedLine;
            lineListBox.onChange = updateLineListButtons;

            /* 右カラム：行への一括操作 */
            var lineActionColumn = addColumnGroup(tabLineArrange);

            var panelLineEdit = addPanel(lineActionColumn, getLabel(LABELS.panel.lineEdit));

            var btnLineUp = panelLineEdit.add("button", undefined, getLabel(LABELS.button.lineUp));
            btnLineUp.onClick = function () {
                moveSelectedLine(-1);
            };

            var btnLineDown = panelLineEdit.add("button", undefined, getLabel(LABELS.button.lineDown));
            btnLineDown.onClick = function () {
                moveSelectedLine(1);
            };

            var btnLineAdd = panelLineEdit.add("button", undefined, getLabel(LABELS.button.lineAdd));
            btnLineAdd.onClick = function () {
                var addedText = prompt(getLabel(LABELS.prompt.addLine), "");
                if (addedText === null) return;
                lineArrangeLines.push(addedText);
                refreshLineList(lineArrangeLines.length - 1);
            };

            var btnLineEdit = panelLineEdit.add("button", undefined, getLabel(LABELS.button.lineEdit));
            btnLineEdit.onClick = editSelectedLine;

            var btnLineDelete = panelLineEdit.add("button", undefined, getLabel(LABELS.button.lineDelete));
            btnLineDelete.onClick = function () {
                if (!lineListBox.selection) return;
                var selectedIndex = lineListBox.selection.index;
                if (!confirm(getLabel(LABELS.confirm.deleteLine), true)) return;
                lineArrangeLines.splice(selectedIndex, 1);
                refreshLineList(selectedIndex);
            };

            var panelSort = addPanel(lineActionColumn, getLabel(LABELS.panel.sort));

            var btnSortByCharCode = panelSort.add("button", undefined, getLabel(LABELS.button.sortByCharCode));
            btnSortByCharCode.onClick = function () {
                executeActionThen("sortByCharCode", {}, loadLinesToList);
            };

            var btnSortByLength = panelSort.add("button", undefined, getLabel(LABELS.button.sortByLength));
            btnSortByLength.onClick = function () {
                executeActionThen("sortByLength", {}, loadLinesToList);
            };

            var btnReverseOrder = panelSort.add("button", undefined, getLabel(LABELS.button.reverseOrder));
            btnReverseOrder.onClick = function () {
                executeActionThen("reverseOrder", {}, loadLinesToList);
            };

            var panelLineDelete = addPanel(lineActionColumn, getLabel(LABELS.panel.lineDelete));

            var btnRemoveDuplicateLines = panelLineDelete.add("button", undefined, getLabel(LABELS.button.removeDuplicateLines));
            btnRemoveDuplicateLines.onClick = function () {
                executeActionThen("removeDuplicateLines", {}, loadLinesToList);
            };

            var btnRemoveEmptyLines = panelLineDelete.add("button", undefined, getLabel(LABELS.button.removeEmptyLines));
            btnRemoveEmptyLines.onClick = function () {
                executeActionThen("removeEmptyLines", {}, loadLinesToList);
            };

            /* === タブ3: 整形 === */
            var tabCleanup = tabbedPanel.add("tab", undefined, getLabel(LABELS.tab.cleanup));
            setupPaletteTab(tabCleanup, "row");

            /* 左カラム：タブ・スペース */
            var spaceCleanupColumn = addColumnGroup(tabCleanup);

            var panelTabChar = addPanel(spaceCleanupColumn, getLabel(LABELS.panel.tab));

            var btnRemoveTabs = panelTabChar.add("button", undefined, getLabel(LABELS.button.removeTabs));
            btnRemoveTabs.onClick = function () {
                executeAction("removeTabs");
            };

            var btnTabsToSpaces = panelTabChar.add("button", undefined, getLabel(LABELS.button.tabsToSpaces));
            btnTabsToSpaces.onClick = function () {
                executeAction("tabsToSpaces");
            };

            var panelRemoveSpace = addPanel(spaceCleanupColumn, getLabel(LABELS.panel.space));

            var btnTrimSpaces = panelRemoveSpace.add("button", undefined, getLabel(LABELS.button.trimSpaces));
            btnTrimSpaces.helpTip = getLabel(LABELS.tooltip.trimSpaces);
            btnTrimSpaces.onClick = function () {
                executeAction("trimSpaces");
            };

            var btnCjkLatinSpaces = panelRemoveSpace.add("button", undefined, getLabel(LABELS.button.cjkLatinSpaces));
            btnCjkLatinSpaces.helpTip = getLabel(LABELS.tooltip.cjkLatinSpaces);
            btnCjkLatinSpaces.onClick = function () {
                executeAction("removeCjkLatinSpaces");
            };

            var btnCollapseSpaces = panelRemoveSpace.add("button", undefined, getLabel(LABELS.button.collapseSpaces));
            btnCollapseSpaces.helpTip = getLabel(LABELS.tooltip.collapseSpaces);
            btnCollapseSpaces.onClick = function () {
                executeAction("collapseSpaces");
            };

            var btnCleanupSpaces = panelRemoveSpace.add("button", undefined, getLabel(LABELS.button.cleanupSpaces));
            btnCleanupSpaces.helpTip = getLabel(LABELS.tooltip.cleanupSpaces);
            btnCleanupSpaces.onClick = function () {
                executeAction("cleanupSpaces");
            };

            var btnRemoveAllSpaces = panelRemoveSpace.add("button", undefined, getLabel(LABELS.button.removeAllSpaces));
            btnRemoveAllSpaces.helpTip = getLabel(LABELS.tooltip.removeAllSpaces);
            btnRemoveAllSpaces.onClick = function () {
                executeAction("removeAllSpaces");
            };

            var panelAddSpace = addPanel(spaceCleanupColumn, getLabel(LABELS.panel.addSpace));

            var btnSpaceAfterPunct = panelAddSpace.add("button", undefined, getLabel(LABELS.button.spaceAfterPunct));
            btnSpaceAfterPunct.helpTip = getLabel(LABELS.tooltip.spaceAfterPunct);
            btnSpaceAfterPunct.onClick = function () {
                executeAction("spaceAfterPunct");
            };

            /* 右カラム：変換・リスト */
            var convertListColumn = addColumnGroup(tabCleanup);

            /* スペースや記号の変換：変換前／変換後をラジオで選び、［変換］で置換する */
            var panelSymbolConvert = addPanel(convertListColumn, getLabel(LABELS.panel.symbolConvert), ["fill", "top"]);

            var symbolConvertColumn = panelSymbolConvert.add("group");
            symbolConvertColumn.orientation = "column";
            symbolConvertColumn.alignment = ["fill", "top"];
            symbolConvertColumn.alignChildren = ["fill", "top"];
            symbolConvertColumn.spacing = TAB_SPACING;

            var panelSymbolBefore = addPanel(symbolConvertColumn, getLabel(LABELS.panel.symbolBefore), ["left", "top"]);
            var rbBeforeSpace = panelSymbolBefore.add("radiobutton", undefined, getLabel(LABELS.radio.space));
            var rbBeforeUnderscore = panelSymbolBefore.add("radiobutton", undefined, getLabel(LABELS.radio.underscore));
            var rbBeforeHyphen = panelSymbolBefore.add("radiobutton", undefined, getLabel(LABELS.radio.hyphen));
            rbBeforeSpace.value = true;

            var panelSymbolAfter = addPanel(symbolConvertColumn, getLabel(LABELS.panel.symbolAfter), ["left", "top"]);
            var rbAfterSpace = panelSymbolAfter.add("radiobutton", undefined, getLabel(LABELS.radio.space));
            var rbAfterUnderscore = panelSymbolAfter.add("radiobutton", undefined, getLabel(LABELS.radio.underscore));
            var rbAfterHyphen = panelSymbolAfter.add("radiobutton", undefined, getLabel(LABELS.radio.hyphen));
            rbAfterUnderscore.value = true;

            /**
             * 変換前に選ばれている記号種別を返す
             * @returns {string} "space" | "underscore" | "hyphen"
             */
            function getBeforeSymbol() {
                if (rbBeforeUnderscore.value) return "underscore";
                if (rbBeforeHyphen.value) return "hyphen";
                return "space";
            }

            /**
             * 変換後に選ばれている記号種別を返す
             * @returns {string} "space" | "underscore" | "hyphen"
             */
            function getAfterSymbol() {
                if (rbAfterSpace.value) return "space";
                if (rbAfterHyphen.value) return "hyphen";
                return "underscore";
            }

            var btnConvertSymbol = panelSymbolConvert.add("button", undefined, getLabel(LABELS.button.convertSymbol));
            btnConvertSymbol.alignment = ["center", "top"];
            btnConvertSymbol.onClick = function () {
                executeAction("convertSymbol", { from: getBeforeSymbol(), to: getAfterSymbol() });
            };

            /**
             * 変換前と変換後が同じ記号なら［変換］をディムにする
             * @returns {void}
             */
            function updateConvertSymbolState() {
                btnConvertSymbol.enabled = (getBeforeSymbol() !== getAfterSymbol());
            }

            var symbolRadios = [rbBeforeSpace, rbBeforeUnderscore, rbBeforeHyphen, rbAfterSpace, rbAfterUnderscore, rbAfterHyphen];
            for (var radioIndex = 0; radioIndex < symbolRadios.length; radioIndex++) {
                symbolRadios[radioIndex].onClick = updateConvertSymbolState;
            }
            updateConvertSymbolState();

            /* 文字変換 */
            var panelConvert = addPanel(convertListColumn, getLabel(LABELS.panel.convert), ["center", "center"]);

            var btnFullToHalfAlnum = panelConvert.add("button", undefined, getLabel(LABELS.button.fullToHalfAlnum));
            btnFullToHalfAlnum.onClick = function () {
                executeAction("fullToHalfAlnum");
            };

            var btnHalfToFullKana = panelConvert.add("button", undefined, getLabel(LABELS.button.halfToFullKana));
            btnHalfToFullKana.onClick = function () {
                executeAction("halfToFullKana");
            };

            /* リストの除去 */
            var panelRemoveList = addPanel(convertListColumn, getLabel(LABELS.panel.list));
            panelRemoveList.orientation = "row";

            var btnBulletList = panelRemoveList.add("button", undefined, getLabel(LABELS.button.bulletList));
            btnBulletList.helpTip = getLabel(LABELS.tooltip.bulletList);
            btnBulletList.onClick = function () {
                executeAction("removeBulletMarkers");
            };

            var btnNumberList = panelRemoveList.add("button", undefined, getLabel(LABELS.button.numberList));
            btnNumberList.helpTip = getLabel(LABELS.tooltip.numberList);
            btnNumberList.onClick = function () {
                executeAction("removeNumberMarkers");
            };

            /* === タブ4: 変換 === */
            var tabConvert = tabbedPanel.add("tab", undefined, getLabel(LABELS.tab.convert));
            setupPaletteTab(tabConvert, "column");

            var panelLetterCase = addPanel(tabConvert, getLabel(LABELS.panel.letterCase), ["fill", "top"]);

            /* プレビュー行の一覧（{ field: statictext, convert: 変換関数 }）*/
            var previewRows = [];

            /**
             * 1行 = [変換ボタン] [変換結果プレビュー] を追加する
             * @param {Panel} parentPanel - 追加先のパネル
             * @param {Object} labelNode - ボタンのラベルノード
             * @param {string} actionId - 実行するアクションID
             * @returns {void}
             */
            function addConvertRow(parentPanel, labelNode, actionId) {
                var convertRow = parentPanel.add("group");
                convertRow.orientation = "row";
                convertRow.alignment = ["fill", "center"];
                convertRow.alignChildren = ["left", "center"];

                var convertButton = convertRow.add("button", undefined, getLabel(labelNode));
                convertButton.preferredSize = CONVERT_BUTTON_SIZE;
                convertButton.onClick = function () {
                    executeActionThen(actionId, {}, refreshConvertPreview);
                };

                var previewText = convertRow.add("statictext", undefined, "", { justify: "left" });
                previewText.preferredSize = CONVERT_PREVIEW_SIZE;
                previewRows.push({ field: previewText, convert: getTextConverter(actionId) });
            }

            addConvertRow(panelLetterCase, LABELS.button.caseUpper, "caseUpper");
            addConvertRow(panelLetterCase, LABELS.button.caseLower, "caseLower");
            addConvertRow(panelLetterCase, LABELS.button.caseWord, "caseWord");
            addConvertRow(panelLetterCase, LABELS.button.caseSentence, "caseSentence");
            addConvertRow(panelLetterCase, LABELS.button.caseTitle, "caseTitle");

            /* かな変換：カタカナ・ひらがな・半角カナの相互変換 */
            var panelKanaConvert = addPanel(tabConvert, getLabel(LABELS.panel.kanaConvert), ["fill", "top"]);

            addConvertRow(panelKanaConvert, LABELS.button.toHiragana, "toHiragana");
            addConvertRow(panelKanaConvert, LABELS.button.toKatakana, "toKatakana");
            addConvertRow(panelKanaConvert, LABELS.button.toHalfKana, "toHalfKana");

            /* 英数字：数字の全角・半角・漢数字の変換 */
            var panelDigitConvert = addPanel(tabConvert, getLabel(LABELS.panel.digitConvert), ["fill", "top"]);

            addConvertRow(panelDigitConvert, LABELS.button.toHalfDigit, "toHalfDigit");
            addConvertRow(panelDigitConvert, LABELS.button.toFullDigit, "toFullDigit");
            addConvertRow(panelDigitConvert, LABELS.button.singleDigitFull, "singleDigitFull");
            addConvertRow(panelDigitConvert, LABELS.button.toKanjiNumeral, "toKanjiNumeral");
            addConvertRow(panelDigitConvert, LABELS.button.toKanjiPositional, "toKanjiPositional");

            /**
             * プレビュー表示用にテキストを1行へ詰めて短く整える
             * @param {string} text - 元テキスト
             * @returns {string} 整形後のテキスト
             */
            function normalizePreviewSample(text) {
                if (text == null) return "";
                var sample = String(text).replace(/[\r\n]+/g, " ").replace(/[ 　\t]+/g, " ").replace(/^\s+|\s+$/g, "");
                if (sample.length > PREVIEW_MAX_CHARS) sample = sample.substring(0, PREVIEW_MAX_CHARS) + "...";
                return sample;
            }

            /* プレビュー更新の多重実行ガード */
            var convertPreviewRefreshing = false;

            /**
             * メインエンジンから先頭テキストを取得し、各行のプレビューを更新する
             * @returns {void}
             */
            function refreshConvertPreview() {
                if (convertPreviewRefreshing) return;
                convertPreviewRefreshing = true;

                runWorker("getFirstText", {}, function (status, payload) {
                    convertPreviewRefreshing = false;
                    var sample = normalizePreviewSample((status === "text" && payload) ? decodeURIComponent(payload) : "");
                    for (var i = 0; i < previewRows.length; i++) {
                        previewRows[i].field.text = normalizePreviewSample(previewRows[i].convert(sample));
                    }
                });
            }

            applySelectionState(computeSelectionState(selectedObjects));
            loadLinesToList();
            refreshConvertPreview();

            /* === 選択のリアルタイム反映 ===
             * Illustrator 30.x には app.scheduleTask / setTimeout 等のタイマー API が無いため、
             * キャンバスにフォーカスがある間の連続ポーリングはできない。代わりに
             * 「ユーザーがパレットへ操作しに来た瞬間」（onActivate＝フォーカス復帰、mouseover）に
             * メインエンジンの選択を取り直してステータスへ反映する。
             * mouseover はパレット上でマウスを動かすたびに何度も発生するため、
             * 多重実行ガード（statusRefreshing）に加えて STATUS_POLL_INTERVAL_MS で間引く。*/
            var statusRefreshing = false;
            var lastFocusRefreshTime = 0;

            /**
             * メインエンジンの選択を取り直してステータス表示へ反映する
             * @returns {void}
             */
            function refreshStatusFromSelection() {
                if (statusRefreshing) return;
                statusRefreshing = true;

                runStatePoll(function (status, payload) {
                    statusRefreshing = false;
                    if (status !== "ok") return;
                    applySelectionState(parseState(payload));
                });
            }

            /**
             * パレットがフォーカスを得たときの更新処理
             * @param {boolean} force - 真なら間引きを無視して必ず取り直す
             * @returns {void}
             */
            function onPaletteFocus(force) {
                var now = (new Date()).getTime();
                if (!force && (now - lastFocusRefreshTime) < STATUS_POLL_INTERVAL_MS) return;
                lastFocusRefreshTime = now;

                refreshStatusFromSelection();
                /* 変換タブ表示中は選択変化に合わせてプレビューも更新 */
                if (tabbedPanel.selection === tabConvert) refreshConvertPreview();
            }

            paletteWindow.onActivate = function () { onPaletteFocus(true); };
            try {
                paletteWindow.addEventListener("mouseover", function () { onPaletteFocus(false); });
            } catch (e) { debugLog("addEventListener: mouseover", e); }

            tabbedPanel.onChange = function () {
                if (tabbedPanel.selection === tabLineArrange) {
                    loadLinesToList();
                } else if (tabbedPanel.selection === tabConvert) {
                    refreshConvertPreview();
                }
            };

            /**
             * パレットを閉じる（1要素だけのグループ解除・選択整理・制御文字OFF はメインエンジンで実行）
             * @returns {void}
             */
            function closePalette() {
                runWorker("finalizeClose", { turnOffHidden: hiddenCharOn }, function () {
                    paletteWindow.close();
                });
            }

            /* フッター：制御文字の表示切り換え */
            var footerRow = paletteWindow.add("group");
            footerRow.orientation = "row";
            footerRow.alignment = ["fill", "bottom"];
            footerRow.alignChildren = ["left", "center"];
            footerRow.margins = FOOTER_MARGINS;

            var btnShowHiddenChar = footerRow.add("button", undefined, hiddenCharLabel);

            /**
             * 制御文字ボタンの文字色を状態に合わせる（ラベルは固定）
             * @returns {void}
             */
            function updateHiddenCharButton() {
                try {
                    var buttonGraphics = btnShowHiddenChar.graphics;
                    var textColor = hiddenCharOn ? [0.0, 0.5, 0.8] : [0.0, 0.0, 0.0];
                    buttonGraphics.foregroundColor = buttonGraphics.newPen(buttonGraphics.PenType.SOLID_COLOR, textColor, 1);
                } catch (e) { debugLog("updateHiddenCharButton: set color", e); }
            }

            btnShowHiddenChar.onClick = function () {
                runWorker("hiddenChar", {}, function (status, payload) {
                    if (status === "error") {
                        showError({ message: payload });
                        return;
                    }
                    hiddenCharOn = !hiddenCharOn;
                    updateHiddenCharButton();
                    applySelectionState(parseState(payload));
                });
            };

            /* パレットがアクティブなとき Esc で閉じる */
            paletteWindow.addEventListener("keydown", function (keyEvent) {
                if (keyEvent.keyName === "Escape") closePalette();
            });

            /* パレットが GC で破棄されないよう参照を保持 */
            $.global.__TextBreakSplitMergePalette = paletteWindow;
            paletteWindow.onClose = function () {
                $.global.__TextBreakSplitMergePalette = null;
            };

            paletteWindow.show();
        }

        try {
            showPalette(selectedObjects);
        } catch (err) {
            showError(err);
        }
    })();

})();
