#targetengine "SwwwitchPalettes"
#target illustrator
app.preferences.setBooleanPreference('ShowExternalJSXWarning', false);

/*
SCRIPTMETA-BEGIN
Script-ID=com.swwwitch.illustrator.UnifiedTypePalette
Name=統合文字組みパネル
Author=Masahiro Takano (@swwwitch)
Target-App=Illustrator
Version=1.5.0
Release-Date=2026-03-24
Description-BEGIN
文字組みに関する設定（フォント、フォントサイズ、自動カーニング、字間調整、文字揃え、行揃え、行送り、文字組みアキ量設定、禁則など）を1枚の常駐パレットにまとめました。
ラジオや入力を操作した時点で、選択中のテキストへ即時適用します。

Gathers the typography settings — font, size, auto-kerning, letter spacing, character alignment, justification, leading, mojikumi and kinsoku — into a single persistent palette.
Every radio button and field applies to the current selection the moment you touch it.
Description-END
SCRIPTMETA-END
*/

/*

### 概要

文字組みに関する設定（フォント、フォントサイズ、自動カーニング、字間調整、文字揃え、行揃え、行送り、文字組みアキ量設定、禁則など）を1枚の常駐パレットにまとめました。
ラジオや入力を操作した時点で、選択中のテキストへ即時適用します。

詳細は README を参照してください。
https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/UnifiedTypePalette.md

note記事も参照してください。
https://note.com/dtp_tranist/n/n4e2b79cf2891

### Overview

Gathers the typography settings — font, size, auto-kerning, letter spacing, character alignment, justification, leading, mojikumi and kinsoku — into a single persistent palette.
Every radio button and field applies to the current selection the moment you touch it.

See the README for details.
https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/UnifiedTypePalette.md

*/

// =========================================
// 基本情報 / Basic info
// =========================================
var SCRIPT_NAME     = "UnifiedTypePalette";           /* スクリプト名 / script name */
var SCRIPT_VERSION  = "v1.5.0";                       /* バージョン / version */
var SCRIPT_AUTHOR   = "Masahiro Takano (@swwwitch)";  /* 作者 / author */
var SCRIPT_RELEASED = "2026-03-24";                   /* 最初のリリース日 / first release date */
var SCRIPT_UPDATED  = "2026-10-16";                   /* 更新日 / last updated */

var SCRIPT_DESCRIPTION_JA = "統合文字組みパネル"; /* README の見出し / README title (Japanese) */

var SCRIPT_README_JA   = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/UnifiedTypePalette.md"; /* README（日本語） */
var SCRIPT_README_EN   = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/UnifiedTypePalette.md"; /* README (English) */
var SCRIPT_ARTICLE_URL = "https://note.com/dtp_tranist/n/n4e2b79cf2891"; /* 紹介記事 / article URL */
var SCRIPT_SOURCE_URL  = "https://github.com/swwwitch/illustrator-scripts/blob/master/jsx/text/UnifiedTypePalette.jsx"; /* 最新版のソース / latest source */

// Released under the MIT license
// http://opensource.org/licenses/mit-license.php

/**
 * @discussion https://note.com/yukifurushima/n/n9f2078dc156f
 */

(function () {

    // =========================================
    // ローカライズ / Localization
    // =========================================
    // ローカライズ（再利用パーツ） / Localization (reusable)

    /**
     * UI の言語を返す（"ja" で始まるロケールは日本語、それ以外は英語）
     * @returns {string} "ja" または "en"
     */
    function getCurrentLang() {
        return (String($.locale || "").indexOf("ja") === 0) ? "ja" : "en";
    }

    var uiLang = getCurrentLang();

    /**
     * LABELS から今の UI 言語の文言を取り出す。
     * @param {string|Object} labelRef - "dialog.title" のようなパス、または { ja, en }
     * @param {Object|Array} [placeholderValues] - { name: 値 } なら {name} を、[値, …] なら %1, %2 … を差し込む
     * @returns {string} 文言。パスが見つからなければパスの文字列、{ ja, en } が無ければ空文字
     */
    function getLabel(labelRef, placeholderValues) {
        var labelEntry = labelRef;
        if (typeof labelRef === "string") {
            var labelPathKeys = labelRef.split(".");
            labelEntry = LABELS;
            for (var i = 0; i < labelPathKeys.length && labelEntry != null; i++) {
                labelEntry = labelEntry[labelPathKeys[i]];
            }
        }
        var labelString;
        if (typeof labelEntry === "string") labelString = labelEntry;
        else if (labelEntry != null && labelEntry[uiLang] != null) labelString = labelEntry[uiLang];
        else if (labelEntry != null && labelEntry.en != null) labelString = labelEntry.en;
        else return (typeof labelRef === "string") ? labelRef : "";
        return fillLabelPlaceholders(String(labelString), placeholderValues);
    }

    /**
     * 項目名の文言の末尾にコロンを付ける（日本語は半角スペース＋半角コロン「 :」、英語は「:」。Illustrator の線パネルなどの項目名に合わせる）
     * @param {string|Object} labelRef - getLabel と同じ
     * @param {Object|Array} [placeholderValues] - getLabel と同じ
     * @returns {string} コロン付きの文言
     */
    function labelText(labelRef, placeholderValues) {
        return getLabel(labelRef, placeholderValues) + (uiLang === "ja" ? " :" : ":");
    }

    /**
     * 「項目名 : 値」の1行を返す（日本語は「件数 : 5」、英語は「Count: 5」。どちらもコロンのあとに空白を入れる）
     * @param {string|Object} labelRef - getLabel と同じ
     * @param {string|number} value - コロンのあとに続ける値
     * @returns {string} 項目名と値をつないだ文字列
     */
    function labelValueText(labelRef, value) {
        return labelText(labelRef) + " " + value;
    }

    /**
     * 文言の {name} や %1 に値を差し込む
     * @param {string} labelString - 文言
     * @param {Object|Array} [placeholderValues] - { name: 値 } または [値, …]
     * @returns {string} 差し込んだ文言
     */
    function fillLabelPlaceholders(labelString, placeholderValues) {
        if (placeholderValues == null) return labelString;
        if (placeholderValues instanceof Array) {
            /* 大きい番号から置き換え、%1 が %10 の一部を置き換えないようにする / Replace from the highest index so %1 does not eat into %10 */
            for (var i = placeholderValues.length; i >= 1; i--) {
                labelString = labelString.split("%" + i).join(String(placeholderValues[i - 1]));
            }
            return labelString;
        }
        for (var placeholderKey in placeholderValues) {
            if (!placeholderValues.hasOwnProperty(placeholderKey)) continue;
            labelString = labelString.split("{" + placeholderKey + "}").join(String(placeholderValues[placeholderKey]));
        }
        return labelString;
    }

    // ローカライズ（再利用パーツ）ここまで / End of the reusable localization

    /* ラベル定義 / Label definitions */
    var LABELS = {
        dialog: {
            title: { ja: "統合文字組みパネル", en: "Unified Type Panel" }
        },
        tab: {
            fonts: { ja: "定番", en: "Favorites" },
            type: { ja: "文字組み", en: "Type" },
            fontSize: { ja: "サイズ", en: "Size" },
            usedFonts: { ja: "使用フォント", en: "Used Fonts" },
            style: { ja: "スタイル", en: "Style" }
        },
        field: {
            docFonts: { ja: "ドキュメントフォント", en: "Document Fonts" },
            presets: { ja: "プリセット", en: "Presets" },
            fontSizePanel: { ja: "フォントサイズ", en: "Font Size" },
            fontSize: { ja: "サイズ", en: "Size" },
            scale: { ja: "比率", en: "Scale" },
            apparent: { ja: "実質", en: "Effective" },
            autoKern: { ja: "自動カーニング", en: "Auto Kerning" },
            tsume: { ja: "文字ツメ", en: "Tsume" },
            tracking: { ja: "トラッキング", en: "Tracking" },
            proportionalMetrics: { ja: "プロポーショナルメトリクス", en: "Proportional Metrics" },
            spacingAdjust: { ja: "字間調整", en: "Letter Spacing" },
            align: { ja: "文字揃え", en: "Char Alignment" },
            justify: { ja: "行揃え", en: "Justification" },
            role: { ja: "種別", en: "Type" },
            leading: { ja: "行送り", en: "Leading" },
            sizeAndLeading: { ja: "フォントサイズと行送り", en: "Font Size & Leading" },
            leadingType: { ja: "行送りの基準", en: "Leading basis" },
            mojikumi: { ja: "文字組みアキ量設定", en: "Mojikumi" },
            kinsoku: { ja: "禁則", en: "Kinsoku" },
            jpComposition: { ja: "日本語組版", en: "Japanese Typography" },
            filter: { ja: "フィルター", en: "Filter" },
            typeScale: { ja: "タイプスケール", en: "Type Scale" },
            typeScaleBase: { ja: "基準", en: "Base" },
            typeScaleRatio: { ja: "倍率", en: "Ratio" },
            typeScaleStep: { ja: "#", en: "#" }
        },
        policy: {
            wabun: { ja: "和文", en: "Japanese" },
            latin: { ja: "欧文", en: "Latin" },
            mixed: { ja: "和欧混在", en: "Mixed" }
        },
        // 使用フォント一覧（DocumentFontListSelectorPalette 由来）/ Used-fonts list labels
        usedFonts: {
            autoLeading: { ja: "自動", en: "Auto" },
            view: {
                fontOnly: { ja: "フォントのみ", en: "Font only" },
                detailed: { ja: "詳細", en: "Details" }
            },
            column: {
                count: { ja: "使用数", en: "Count" },
                font: { ja: "フォント", en: "Font" },
                size: { ja: "サイズ", en: "Size" },
                leading: { ja: "行送り", en: "Leading" },
                kern: { ja: "自動カーニング", en: "Auto Kerning" },
                tsume: { ja: "文字ツメ", en: "Tsume" },
                tracking: { ja: "トラッキング", en: "Tracking" },
                propMetrics: { ja: "プロポーショナル", en: "Prop. Metrics" }
            },
            control: {
                applyOnClick: { ja: "クリックで適用", en: "Apply on click" },
                currentArtboardOnly: { ja: "現在のアートボードに限定", en: "Current artboard only" },
                includeHidden: { ja: "非表示のテキストを含む", en: "Include hidden text" },
                includeLocked: { ja: "ロックされたテキストを含む", en: "Include locked text" }
            },
            button: {
                refresh: { ja: "リストを更新", en: "Refresh list" },
                selectMatching: { ja: "選択したフォントを選択", en: "Select matching text" }
            },
            status: {
                needSelection: { ja: "適用先のテキストを選択してください。", en: "Select the text to apply to." },
                needCondition: { ja: "一覧から条件を選択してください。", en: "Select a condition from the list." },
                noMatch: { ja: "一致するテキストが見つかりませんでした。", en: "No matching text was found." }
            }
        },
        kinsoku: {
            none: { ja: "なし", en: "None" },
            hard: { ja: "強い禁則", en: "Strict" },
            soft: { ja: "弱い禁則", en: "Loose" },
            softV2: { ja: "弱い禁則 v2", en: "Loose v2" }
        },
        align: {
            roman: { ja: "欧文ベースライン", en: "Roman Baseline" },
            top: { ja: "仮想ボディの上/右", en: "Embox Top/Right" },
            center: { ja: "中央", en: "Embox Centre" },
            bottom: { ja: "仮想ボディの下/左", en: "Embox Bottom/Left" },
            icfTop: { ja: "平均字面の上/右", en: "ICF Box Top/Right" },
            icfBottom: { ja: "平均字面の下/左", en: "ICF Box Bottom/Left" }
        },
        leading: {
            typeTop: { ja: "仮想ボディの上", en: "Top-to-top (virtual body)" },
            typeBaseline: { ja: "欧文ベースライン", en: "Baseline-to-baseline" }
        },
        mojikumi: {
            none: { ja: "なし", en: "None" },
            lineEndFullHalf: { ja: "行末約物全角/半角", en: "Line-end punct full/half" },
            punctHalf: { ja: "約物半角", en: "Half-width punctuation" },
            lineEndHalf: { ja: "行末約物半角", en: "Line-end punct half" },
            lineEndFull: { ja: "行末約物全角", en: "Line-end punct full" },
            punctFull: { ja: "約物全角", en: "Full-width punctuation" },
            tight: { ja: "ツメ組み", en: "Tight" },
            solid: { ja: "ベタ組み", en: "Solid" }
        },
        role: {
            body: { ja: "本文", en: "Body" },
            heading: { ja: "見出し", en: "Heading" }
        },
        autoKern: {
            mono: { ja: "和文等幅", en: "Metrics - Roman Only" },
            zero: { ja: "0", en: "0" },
            metrics: { ja: "メトリクス", en: "Metrics" },
            optical: { ja: "オプティカル", en: "Optical" }
        },
        justify: {
            left: { ja: "左揃え", en: "Left" },
            center: { ja: "中央揃え", en: "Center" },
            right: { ja: "右揃え", en: "Right" },
            justifyLeft: { ja: "均等配置（最終行左）", en: "Justify (last left)" },
            justifyCenter: { ja: "均等配置（最終行中央）", en: "Justify (last center)" },
            justifyRight: { ja: "均等配置（最終行右）", en: "Justify (last right)" },
            justifyAll: { ja: "両端揃え", en: "Justify all" }
        },
        button: {
            addPreset: { ja: "追加", en: "Add" },
            overwritePreset: { ja: "上書き", en: "Overwrite" },
            deletePreset: { ja: "削除", en: "Delete" },
            exportPreset: { ja: "書き出し", en: "Export" },
            reset: { ja: "リセット", en: "Reset" },
            reload: { ja: "再読み込み", en: "Reload" },
            hiddenChar: { ja: "制御文字", en: "Hidden Chars" },
            toApparent: { ja: "見かけ←→実サイズ", en: "Apparent ←→ Actual" }
        },
        tip: {
            docFonts: { ja: "書類で使用中のフォント一覧。選ぶと選択テキストに適用します。", en: "Fonts used in the document. Click one to apply it to the selection." },
            presets: { ja: "登録した文字組みプリセット（フォント＋カーニング・ツメ・トラッキング）。選ぶと一括適用します。", en: "Saved type presets (font + kerning / Tsume / tracking). Click one to apply them together." },
            addPreset: { ja: "現在の選択の設定をプリセットとして保存します（同じフォントは上書き）。", en: "Save the current selection's settings as a preset (same font overwrites)." },
            overwritePreset: { ja: "リストで選択中のプリセットを、現在の選択の設定で上書きします。", en: "Overwrite the preset selected in the list with the current selection's settings." },
            deletePreset: { ja: "リストで選択中のプリセットを削除します。", en: "Delete the preset selected in the list." },
            exportPreset: { ja: "登録済みのプリセットを JSON ファイルに書き出します。", en: "Export the saved presets to a JSON file." },
            fontSize: { ja: "選択テキストのフォントサイズ。", en: "Font size of the selection." },
            scale: { ja: "水平比率・垂直比率を同じ値でまとめて設定します。", en: "Sets the horizontal and vertical scale together to the same value." },
            apparent: { ja: "フォントサイズ×比率で計算した、実質的なサイズです。", en: "The effective size, computed as font size × scale." },
            autoKern: { ja: "自動カーニング方式（和文等幅／0／メトリクス／オプティカル）。", en: "Auto-kerning method (Japanese equal width / 0 / Metrics / Optical)." },
            tsume: { ja: "文字ツメ（0〜100%）。隣接する文字の食い込み量。", en: "Tsume (0–100%): how much adjacent characters tighten." },
            tracking: { ja: "字間（1/1000em）をまとめて調整します（-100〜500）。", en: "Adjusts overall letter spacing in 1/1000 em (-100 to 500)." },
            align: { ja: "文字の縦方向の揃え基準。「その他」で残りの基準をポップアップから選びます。", en: "Vertical alignment basis. Use “Other” to pick the rest from the popup." },
            justify: { ja: "段落の行揃え。テキストの見た目の位置を保ったまま変更します。", en: "Paragraph justification, applied while keeping the text's visual position." },
            role: { ja: "本文＝和文等幅／行送り150%／均等配置（最終行左）、見出し＝メトリクス／行送り115%／左揃え をまとめて適用。", en: "Body = Japanese equal width / 150% leading / justify (last left); Heading = Metrics / 115% leading / left." },
            leading: { ja: "行送り。115%／150%／その他（%で直接入力）／自動。", en: "Leading: 115% / 150% / Other (enter a %) / Auto." },
            leadingEffective: { ja: "実質の行送り（フォントサイズ×行送り%）。ここに値を入れると % を逆算して設定します。", en: "The effective leading (font size × leading %). Enter a value here to set the leading by back-calculating the %." },
            leadingType: { ja: "行送りを測る基準位置（仮想ボディの上／欧文ベースライン）。", en: "The reference position for measuring leading (virtual body top / Roman baseline)." },
            mojikumi: { ja: "段落の文字組みアキ量設定（約物の詰め方など）をまとめて適用します。", en: "Applies a mojikumi spacing set (punctuation spacing, etc.) to the paragraphs." },
            kinsoku: { ja: "段落の禁則処理（強い禁則／弱い禁則など）をまとめて適用します。", en: "Applies a kinsoku (line-break) set to the paragraphs." },
            reset: { ja: "標準値に戻します（フォントサイズ12pt・比率100%・ツメ0・トラッキング0・自動カーニング和文等幅・欧文ベースライン・左揃え・行送り115%・文字組みツメ組み・禁則弱い禁則v2）。", en: "Reset to defaults (12pt / 100% scale / 0 Tsume / 0 tracking / Metrics - Roman Only kerning / Roman baseline / left / 115% leading / Tight mojikumi / Loose v2 kinsoku)." },
            reload: { ja: "選択中のテキストの現在値を読み取り直して UI に反映します。", en: "Re-read the current values from the selection and reflect them in the UI." },
            hiddenChar: { ja: "制御文字（改行・スペースなど）の表示／非表示を切り替えます。", en: "Toggle the display of hidden characters (returns, spaces, etc.)." },
            toApparent: { ja: "サイズ×比率を実フォントサイズに焼き込んで比率100%に、もう一度押すと元のサイズ・比率へ戻します（相互変換）。", en: "Bakes size × scale into the actual font size at 100%; press again to restore the original size and scale (round-trip)." },
            typeScale: { ja: "基準サイズと倍率からタイプスケールを生成します。行をクリックすると選択テキストに適用します。", en: "Generate a type scale from a base size and ratio. Click a row to apply it to the selection." },
            typeScaleBase: { ja: "タイプスケールの基準となるフォントサイズ。", en: "The base font size for the type scale." },
            typeScaleRatio: { ja: "各段の比率（音程比）。基準サイズにこの比率を掛け合わせて各サイズを生成します。", en: "The step ratio (musical interval). Each size is the base multiplied by this ratio." }
        },
        tooltip: {
            stepUp: {
                ja: "値を増やす（shift＋クリックで10の倍数へ、option＋クリックで0.1ずつ）",
                en: "Increase (Shift-click to snap to 10s, Option-click by 0.1)"
            },
            stepDown: {
                ja: "値を減らす（shift＋クリックで10の倍数へ、option＋クリックで0.1ずつ）",
                en: "Decrease (Shift-click to snap to 10s, Option-click by 0.1)"
            },
            stepUpInteger: { ja: "値を増やす（shift＋クリックで10の倍数へ）", en: "Increase (Shift-click to snap to 10s)" },
            stepDownInteger: { ja: "値を減らす（shift＋クリックで10の倍数へ）", en: "Decrease (Shift-click to snap to 10s)" }
        },
        msg: {
            applyError: { ja: "適用に失敗しました", en: "Apply failed" }
        }
    };

    // =========================================
    // メインエンジンで実行する DOM 処理 / DOM helpers run on the main engine
    //
    // 以下の関数群は toString() で連結し、BridgeTalk 本文に同梱して
    // メインエンジン（生きた DOM を持つ）で eval される。常駐エンジン側
    // からは直接呼ばず、本文への埋め込み用途のみ。
    // These are concatenated via toString() and embedded in the BridgeTalk
    // body, then eval'd on the main engine (which has a live DOM). They are
    // not called from the palette engine; they exist only to be embedded.
    // =========================================

    /* 型名を安全に取得（host オブジェクトは typename を優先、JS オブジェクトは constructor.name）
       Safely resolve a type name: typename for host objects, constructor.name for JS objects */
    function getTypeName(obj) {
        if (obj === null || obj === undefined) return "";
        if (obj.typename) return obj.typename;
        try {
            return obj.constructor ? obj.constructor.name : "";
        } catch (e) {
            return "";
        }
    }

    /* 例外を短いメッセージ文字列へ（dispatch の "ERR:" 応答用）/ Reduce an exception to a short message string (for dispatch "ERR:" replies) */
    function errMessage(e) {
        return (e && e.message) ? e.message : String(e);
    }

    /* 1 アイテムからテキスト範囲を収集（グループは中を再帰）/ Collect text ranges from one item (descend into groups) */
    function collectTextRangesFromItem(item, selectedRanges) {
        if (!item) return;
        var itemType = getTypeName(item);
        if (itemType === "TextFrame") {
            selectedRanges.push(item.textRange);
        } else if (itemType === "TextRange") {
            selectedRanges.push(item);
        } else if (itemType === "GroupItem" && item.pageItems) {
            for (var i = 0; i < item.pageItems.length; i++) collectTextRangesFromItem(item.pageItems[i], selectedRanges);
        }
    }

    /* 選択中のテキスト範囲を取得 / Get selected text ranges from current document */
    function getSelectedTextRanges() {
        var activeDoc = app.activeDocument;
        var currentSelection = activeDoc.selection;
        var selectedRanges = [];
        if (!currentSelection) return selectedRanges;
        /* テキスト編集モードでは selection が配列でなく TextRange になる / In text-edit mode the selection is a TextRange, not an array */
        if (getTypeName(currentSelection) === "TextRange") {
            selectedRanges.push(currentSelection);
            return selectedRanges;
        }
        if (currentSelection.length === 0) return selectedRanges;
        for (var i = 0; i < currentSelection.length; i++) {
            collectTextRangesFromItem(currentSelection[i], selectedRanges);
        }
        return selectedRanges;
    }

    /* 選択が触れている段落を「段落全体の範囲」で取得（文字属性を段落単位で適用するため）
       Get the full paragraphs the selection touches (so a char-attr can be applied per paragraph).
       range.paragraphs は重なった段落を返し、各段落オブジェクトは段落全体を指す（選択で切られない）
       range.paragraphs returns the overlapping paragraphs; each paragraph spans the whole paragraph (not clipped) */
    function getSelectedParagraphRanges() {
        var ranges = getSelectedTextRanges();
        var paragraphRanges = [];
        for (var i = 0; i < ranges.length; i++) {
            try {
                var paragraphs = ranges[i].paragraphs;
                for (var j = 0; j < paragraphs.length; j++) paragraphRanges.push(paragraphs[j]);
            } catch (e) { }
        }
        return paragraphRanges;
    }

    /* 方式 ID を AutoKernType の列挙値へ変換 / Resolve a method id to an AutoKernType enum value
       和文等幅は欧文のみメトリクス＝和文は等幅（METRICSROMANONLY）
       Japanese equal width = metrics for Roman only (METRICSROMANONLY) */
    function resolveAutoKernType(methodId) {
        if (methodId === "mono") return AutoKernType.METRICSROMANONLY;
        if (methodId === "metrics") return AutoKernType.AUTO;
        if (methodId === "optical") return AutoKernType.OPTICAL;
        return AutoKernType.NOAUTOKERN;
    }

    /* 選択範囲にカーニング方式を適用 / Apply a kerning method to the given ranges
       メトリクスのときのみプロポーショナルメトリクスをON、それ以外はOFF
       Proportional metrics ON only for Metrics, OFF otherwise */
    function applyKerningToRanges(ranges, kerningMethod) {
        var useProportionalMetrics = (kerningMethod === AutoKernType.AUTO);
        for (var i = 0; i < ranges.length; i++) {
            try {
                ranges[i].characterAttributes.kerningMethod = kerningMethod;
                ranges[i].characterAttributes.proportionalMetrics = useProportionalMetrics;
            } catch (e) {
                // 適用できない範囲はスキップ / Skip ranges that can't take these attributes
            }
        }
    }

    /* カーニング方式だけを適用（プロポーショナル連動なし）。combo は独立したプロポーショナル値を持つため専用
       Apply only the kerning method (no proportional coupling); used by the combo, which carries its own proportional value */
    function applyKerningMethodToRanges(ranges, kerningMethod) {
        for (var i = 0; i < ranges.length; i++) {
            try {
                ranges[i].characterAttributes.kerningMethod = kerningMethod;
            } catch (e) {
                // 適用できない範囲はスキップ / Skip ranges that can't take this attribute
            }
        }
    }

    /* 選択範囲に文字ツメを適用 / Apply Tsume to the given ranges
       0〜100 の百分率（30 = 30%）/ Percentage from 0 to 100 (30 = 30%) */
    function applyTsumeToRanges(ranges, tsumePercent) {
        for (var i = 0; i < ranges.length; i++) {
            try {
                ranges[i].characterAttributes.Tsume = tsumePercent;
            } catch (e) {
                // 適用できない範囲はスキップ / Skip ranges that can't take this attribute
            }
        }
    }

    /* 選択範囲のアキ（前／後）を自動に戻す / Reset the aki (before/after) on the given ranges to auto
       akiLeft / akiRight に -1 を入れると「自動」/ Assigning -1 to akiLeft / akiRight means "auto" */
    function clearAkiOnRanges(ranges) {
        for (var i = 0; i < ranges.length; i++) {
            try {
                ranges[i].characterAttributes.akiLeft = -1;
                ranges[i].characterAttributes.akiRight = -1;
            } catch (e) {
                // 適用できない範囲はスキップ / Skip ranges that can't take these attributes
            }
        }
    }

    /* 選択範囲にフォントを適用 / Apply a font (by PostScript name) to the given ranges */
    function applyFontToRanges(ranges, psName) {
        var font = null;
        try { font = app.textFonts.getByName(psName); } catch (e) { return; }
        if (!font) return;
        for (var i = 0; i < ranges.length; i++) {
            try { ranges[i].characterAttributes.textFont = font; } catch (e2) { }
        }
    }

    /* 文字揃え ID を StyleRunAlignmentType へ変換 / Resolve an alignment id to StyleRunAlignmentType */
    function resolveAlignment(alignId) {
        if (alignId === "top") return StyleRunAlignmentType.top;
        if (alignId === "center") return StyleRunAlignmentType.center;
        if (alignId === "bottom") return StyleRunAlignmentType.bottom;
        if (alignId === "icftop") return StyleRunAlignmentType.icfTop;
        if (alignId === "icfbottom") return StyleRunAlignmentType.icfBottom;
        return StyleRunAlignmentType.ROMANBASELINE;
    }

    /* StyleRunAlignmentType を ID 文字列へ / Convert a StyleRunAlignmentType value to an id string */
    function alignmentToId(value) {
        var valueText = String(value);
        if (valueText === String(StyleRunAlignmentType.top)) return "top";
        if (valueText === String(StyleRunAlignmentType.center)) return "center";
        if (valueText === String(StyleRunAlignmentType.bottom)) return "bottom";
        if (valueText === String(StyleRunAlignmentType.icfTop)) return "icftop";
        if (valueText === String(StyleRunAlignmentType.icfBottom)) return "icfbottom";
        if (valueText === String(StyleRunAlignmentType.ROMANBASELINE)) return "roman";
        return "";
    }

    /* 自動カーニング method を ID 文字列へ / Convert a kerning method (AutoKernType) to an id string */
    function kernMethodToId(value) {
        var valueText = String(value);
        if (valueText === String(AutoKernType.AUTO)) return "metrics";
        if (valueText === String(AutoKernType.OPTICAL)) return "optical";
        if (valueText === String(AutoKernType.METRICSROMANONLY)) return "mono";
        if (valueText === String(AutoKernType.NOAUTOKERN)) return "zero";
        return "";
    }

    /* 行揃え（Justification）を ID 文字列へ / Convert a paragraph justification to an id string */
    function justificationToId(value) {
        var valueText = String(value);
        if (valueText === String(Justification.LEFT)) return "left";
        if (valueText === String(Justification.CENTER)) return "center";
        if (valueText === String(Justification.RIGHT)) return "right";
        if (valueText === String(Justification.FULLJUSTIFYLASTLINELEFT)) return "justifyLeft";
        if (valueText === String(Justification.FULLJUSTIFYLASTLINECENTER)) return "justifyCenter";
        if (valueText === String(Justification.FULLJUSTIFYLASTLINERIGHT)) return "justifyRight";
        if (valueText === String(Justification.FULLJUSTIFY)) return "justifyAll";
        return "";
    }

    /* ID 文字列を行揃え（Justification）へ / Resolve an id string to a Justification value */
    function resolveJustification(justifyId) {
        if (justifyId === "center") return Justification.CENTER;
        if (justifyId === "right") return Justification.RIGHT;
        if (justifyId === "justifyLeft") return Justification.FULLJUSTIFYLASTLINELEFT;
        if (justifyId === "justifyCenter") return Justification.FULLJUSTIFYLASTLINECENTER;
        if (justifyId === "justifyRight") return Justification.FULLJUSTIFYLASTLINERIGHT;
        if (justifyId === "justifyAll") return Justification.FULLJUSTIFY;
        return Justification.LEFT;
    }

    /* テキスト範囲っぽい型か / Is this a text-range-like type */
    function isTextRangeLikeType(typeName) {
        return typeName === "TextRange" || typeName === "InsertionPoint" || typeName === "Character" ||
            typeName === "Word" || typeName === "Line" || typeName === "Paragraph";
    }

    /* 親をたどって TextFrame を返す / Walk up parents to the enclosing TextFrame */
    function findParentTextFrame(item) {
        var current = item;
        for (var i = 0; i < 20; i++) {
            if (!current) return null;
            if (getTypeName(current) === "TextFrame") return current;
            try { current = current.parent; } catch (e) { return null; }
        }
        return null;
    }

    /* TextFrame の重複判定キー / A dedup key for a TextFrame
       uuid があれば一意。無い環境では「位置＋bounds＋文字数＋先頭文字列」で近似するが、
       これらが完全一致する別フレームが重なっていると同一視され、片方がスキップされうる（レアケース）
       uuid is unique when available; otherwise we approximate with position + bounds + length +
       a content prefix. Two distinct frames sharing all of these (fully overlapping) could still
       collide and cause one to be skipped (rare) */
    function getTextFrameKey(frame) {
        try { if (frame.uuid) return frame.uuid; } catch (e) { }
        var bounds = frame.visibleBounds;
        var contents = "";
        try { contents = String(frame.contents); } catch (eContents) { }
        var contentKey = contents.length + ":" + contents.substring(0, 16);
        return frame.typename + ":" + frame.position[0] + ":" + frame.position[1] + ":" + bounds.join(":") + ":" + contentKey;
    }

    /* 選択から行揃え対象（フレーム＋範囲）を収集 / Collect justification targets (frame + range) from a selection */
    function collectJustifyTargets(selection) {
        var targets = [];
        var seenFrameKeys = {};
        var itemList = (selection && selection.typename) ? [selection] : (selection || []);
        for (var i = 0; i < itemList.length; i++) collectJustifyTargetsFromItem(itemList[i], targets, seenFrameKeys);
        return targets;
    }

    /* 1 アイテムから対象を収集（グループは中を走査）/ Collect targets from one item (descend into groups) */
    function collectJustifyTargetsFromItem(item, targets, seenFrameKeys) {
        if (!item) return;
        var typeName = getTypeName(item);
        if (typeName === "TextFrame") { addJustifyTarget(item, item.textRange, targets, seenFrameKeys); return; }
        if (isTextRangeLikeType(typeName)) {
            var frame = findParentTextFrame(item);
            if (frame) addJustifyTarget(frame, item, targets, seenFrameKeys);
            return;
        }
        if (typeName === "GroupItem" && item.pageItems) {
            for (var i = 0; i < item.pageItems.length; i++) collectJustifyTargetsFromItem(item.pageItems[i], targets, seenFrameKeys);
        }
    }

    /* 対象を重複なく追加 / Add a target, skipping duplicate frames */
    function addJustifyTarget(frame, range, targets, seenFrameKeys) {
        if (!frame || !range || getTypeName(frame) !== "TextFrame") return;
        var frameKey = getTextFrameKey(frame);
        if (seenFrameKeys[frameKey]) return;
        seenFrameKeys[frameKey] = true;
        targets.push({ frame: frame, range: range });
    }

    /* 範囲内の全段落に行揃えを適用 / Apply justification to every paragraph in the range */
    function applyJustificationToParagraphs(range, justifyValue) {
        try {
            if (range.paragraphs && range.paragraphs.length) {
                for (var i = 0; i < range.paragraphs.length; i++) {
                    range.paragraphs[i].paragraphAttributes.justification = justifyValue;
                }
            }
        } catch (e) { }
        try { range.paragraphAttributes.justification = justifyValue; } catch (e2) { }
        try {
            if (range.parent && getTypeName(range.parent) === "TextFrame") {
                range.parent.textRange.paragraphAttributes.justification = justifyValue;
            }
        } catch (e3) { }
    }

    /* 左揃えはスクリプトから無視されることがあるため、一時リサイズで段落属性を
       リフレッシュさせてから元に戻す（位置補正は呼び出し側で実施）
       Illustrator can ignore Justification.LEFT from scripts; a temporary resize
       forces the attributes to refresh, then the frame is restored (caller fixes position)

       ⚠️ 副作用リスクあり: resize(200,200)→resize(50,50) は強引な回避策で、
          既に変形（回転・シアー等）済みのテキストやエリアテキストでは、matrix/position
          の復元が完全でなく形状やパスがわずかに崩れる可能性がある。Justification.LEFT
          の既知バグ（RIGHT/CENTER は効くが LEFT は無視される）専用のフォールバック。
       ⚠️ Side-effect risk: the resize(200,200)→resize(50,50) dance is a brute-force
          workaround. On already-transformed (rotated/sheared) text or area text, the
          matrix/position restore may be imperfect and slightly distort the shape/path.
          Used only as a fallback for the known Justification.LEFT bug (RIGHT/CENTER work). */
    function forceLeftJustification(target) {
        var frame = target.frame;
        var pos = [frame.position[0], frame.position[1]];
        var matrix = null;
        try { matrix = frame.matrix; } catch (e0) { }
        try { frame.resize(200, 200); } catch (e1) { }
        applyJustificationToParagraphs(target.range, Justification.LEFT);
        try { if (frame.story && frame.story.textRange) frame.story.textRange.justification = Justification.LEFT; } catch (e2) { }
        try { if (frame.textRange) frame.textRange.justification = Justification.LEFT; } catch (e3) { }
        try { frame.resize(50, 50); } catch (e4) { }
        try { frame.position = pos; } catch (e5) { }
        try { if (matrix) frame.matrix = matrix; } catch (e6) { }
        applyJustificationToParagraphs(target.range, Justification.LEFT);
    }

    /* 行揃えを適用しつつ、フレームの見た目位置（visibleBounds 左上）を維持
       Apply justification while preserving the frame's visual position (top-left of visibleBounds) */
    function justifyKeepingPosition(target, justifyValue, justifyId) {
        var frame = target.frame;
        var before = frame.visibleBounds;
        if (justifyId === "left") {
            forceLeftJustification(target);
        } else {
            applyJustificationToParagraphs(target.range, justifyValue);
        }
        var after = frame.visibleBounds;
        var dx = before[0] - after[0];
        var dy = before[1] - after[1];
        if (Math.abs(dx) > 0.001 || Math.abs(dy) > 0.001) frame.translate(dx, dy);
    }

    /* TextFrame / TextRange から characterAttributes を取得（それ以外は null）/ Get characterAttributes from a TextFrame / TextRange */
    function getAlignmentCharAttrs(item) {
        if (item.typename === "TextFrame") return item.textRange.characterAttributes;
        if (item.typename === "TextRange") return item.characterAttributes;
        return null;
    }

    /* グループを潜って最初のテキストの characterAttributes を返す / Descend into groups for the first text's characterAttributes */
    function getFirstAlignmentCharAttrs(item) {
        if (item.typename === "GroupItem") {
            for (var j = 0; j < item.pageItems.length; j++) {
                var found = getFirstAlignmentCharAttrs(item.pageItems[j]);
                if (found !== null) return found;
            }
            return null;
        }
        return getAlignmentCharAttrs(item);
    }

    /* テキストへ再帰的に文字揃えを設定（グループは中を走査）/ Recursively set alignment on text (descends into groups) */
    function applyStyleRunAlignment(item, alignmentValue) {
        if (item.typename === "GroupItem") {
            var applied = 0;
            for (var j = 0; j < item.pageItems.length; j++) applied += applyStyleRunAlignment(item.pageItems[j], alignmentValue);
            return applied;
        }
        var attrs = getAlignmentCharAttrs(item);
        if (attrs === null) return 0;
        attrs.alignment = alignmentValue;
        return 1;
    }

    /* 選択範囲にトラッキングを適用 / Apply tracking to the given ranges（1/1000 em 単位）*/
    function applyTrackingToRanges(ranges, trackingValue) {
        for (var i = 0; i < ranges.length; i++) {
            try {
                ranges[i].characterAttributes.tracking = trackingValue;
            } catch (e) {
                // 適用できない範囲はスキップ / Skip ranges that can't take this attribute
            }
        }
    }

    /* 選択範囲にプロポーショナルメトリクスを適用（段落単位で使うため独立関数化）
       Apply proportional metrics to the given ranges (its own function so it can be applied per paragraph) */
    function applyProportionalToRanges(ranges, useProportional) {
        var on = useProportional ? true : false;
        for (var i = 0; i < ranges.length; i++) {
            try {
                ranges[i].characterAttributes.proportionalMetrics = on;
            } catch (e) {
                // 適用できない範囲はスキップ / Skip ranges that can't take this attribute
            }
        }
    }

    /* 行頭で参照する文字数 / Number of leading characters to sample per line */
    var LINE_FONT_SIZE_SAMPLE_COUNT = 5;

    /* 組み込みの文字組みアキ量設定の数（mojikumiSet のインデックス7以降はカスタム）/ Built-in mojikumi sets (index 7 and later are custom) */
    var MOJIKUMI_BUILTIN_COUNT = 7;

    /* 行から先頭数文字のフォントサイズを採取 / Sample font sizes from the first few characters of a line */
    function getLineSampleFontSizes(line, sampleCount) {
        var fontSizes = [];
        if (!line || !line.characters || line.characters.length === 0) return fontSizes;
        var maxCount = Math.min(line.characters.length, sampleCount);
        for (var i = 0; i < maxCount; i++) {
            try {
                var size = line.characters[i].characterAttributes.size;
                if (!isNaN(size)) fontSizes.push(size);
            } catch (e) { }
        }
        return fontSizes;
    }

    /* 最頻値を返す（同数なら大きい方）/ Return the most frequent value (ties favor the larger) */
    function getMostFrequentNumber(values) {
        if (!values || values.length === 0) return NaN;
        var counts = {};
        var bestValue = values[0];
        var bestCount = 0;
        for (var i = 0; i < values.length; i++) {
            var valueKey = String(values[i]);
            if (!counts[valueKey]) counts[valueKey] = { value: values[i], count: 0 };
            counts[valueKey].count++;
            if (counts[valueKey].count > bestCount) {
                bestCount = counts[valueKey].count;
                bestValue = counts[valueKey].value;
            } else if (counts[valueKey].count === bestCount && counts[valueKey].value > bestValue) {
                bestValue = counts[valueKey].value;
            }
        }
        return bestValue;
    }

    /* 行の基準フォントサイズ（先頭数文字の最頻値）/ Base font size of a line (mode of the first few chars) */
    function getBaseFontSizeFromLine(line) {
        var fontSizes = getLineSampleFontSizes(line, LINE_FONT_SIZE_SAMPLE_COUNT);
        if (!fontSizes || fontSizes.length === 0) return NaN;
        return getMostFrequentNumber(fontSizes);
    }

    /* 処理可能なテキストフレームか判定し、該当すれば返す / Return the item if it is a processable TextFrame */
    function getProcessableTextFrame(item) {
        if (!item || item.typename !== "TextFrame") return null;
        if (!item.contents) return null;
        if (!item.lines || item.lines.length === 0) return null;
        return item;
    }

    /* 選択から重複なしの処理対象テキストフレームを収集 / Collect unique processable text frames from the selection */
    function collectLeadingFrames(selectionItems) {
        var frames = [];
        var seenFrameKeys = {};
        var itemList = (selectionItems && selectionItems.typename) ? [selectionItems] : (selectionItems || []);
        for (var i = 0; i < itemList.length; i++) collectLeadingFramesFromItem(itemList[i], frames, seenFrameKeys);
        return frames;
    }

    /* 1 アイテムからフレームを収集（グループは中を走査、テキスト編集モードの範囲は親フレームへ）
       Collect frames from one item (descend into groups; resolve text-edit ranges to their parent frame) */
    function collectLeadingFramesFromItem(item, frames, seenFrameKeys) {
        if (!item) return;
        var typeName = getTypeName(item);
        if (typeName === "TextFrame") { addLeadingFrame(item, frames, seenFrameKeys); return; }
        if (isTextRangeLikeType(typeName)) { addLeadingFrame(findParentTextFrame(item), frames, seenFrameKeys); return; }
        if (typeName === "GroupItem" && item.pageItems) {
            for (var i = 0; i < item.pageItems.length; i++) collectLeadingFramesFromItem(item.pageItems[i], frames, seenFrameKeys);
        }
    }

    /* 処理可能なフレームを重複なく追加 / Add a processable frame, skipping duplicates */
    function addLeadingFrame(frame, frames, seenFrameKeys) {
        var textFrame = getProcessableTextFrame(frame);
        if (!textFrame) return;
        var frameKey = getTextFrameKey(textFrame);
        if (seenFrameKeys[frameKey]) return;
        seenFrameKeys[frameKey] = true;
        frames.push(textFrame);
    }

    /* 行送りの基準 ID を AutoLeadingType へ変換 / Resolve a leading-basis id to AutoLeadingType */
    function resolveLeadingType(typeId) {
        if (typeId === "baseline") return AutoLeadingType.BOTTOMTOBOTTOM;
        return AutoLeadingType.TOPTOTOP;
    }

    /* AutoLeadingType を ID 文字列へ / Convert an AutoLeadingType value to an id string */
    function leadingTypeToId(typeValue) {
        if (typeValue === AutoLeadingType.BOTTOMTOBOTTOM) return "baseline";
        if (typeValue === AutoLeadingType.TOPTOTOP) return "top";
        return "";
    }

    /* 段落に自動行送りを設定：自動行送り量（%）を段落属性に、各文字を autoLeading=true に
       Set auto-leading on paragraphs: the amount (%) on the paragraph attribute, autoLeading=true on the characters
       これにより Illustrator 上は常に「自動」表示となり、行送りはフォントサイズに追従する
       So Illustrator always shows "Auto" and the leading follows the font size */
    function applyAutoLeadingToParagraphs(paragraphRanges, percent) {
        for (var i = 0; i < paragraphRanges.length; i++) {
            try {
                paragraphRanges[i].paragraphAttributes.autoLeadingAmount = percent;
                paragraphRanges[i].characterAttributes.autoLeading = true;
            } catch (e) {
                // 適用できない範囲はスキップ / Skip ranges that can't take these attributes
            }
        }
    }

    /* 行送りの基準（leadingType）だけを設定し、行送り値は変更しない
       Set only the leading basis (leadingType); leaves the leading values untouched */
    function applyLeadingBasisToFrames(frames, leadingType) {
        for (var i = 0; i < frames.length; i++) {
            try { frames[i].textRange.leadingType = leadingType; } catch (e) { }
        }
    }

    /* 段落にハイフネーションを適用（段落属性）/ Apply hyphenation to the given paragraph ranges (a paragraph attribute) */
    function applyHyphenationToRanges(ranges, useHyphenation) {
        var on = useHyphenation ? true : false;
        for (var i = 0; i < ranges.length; i++) {
            try { ranges[i].paragraphAttributes.hyphenation = on; } catch (e) { }
        }
    }

    /* テキストフレーム内の全段落に文字組みアキ量設定を適用 / Apply a mojikumi set to every paragraph in a text frame */
    function applyMojikumiToTextFrame(textFrame, mojikumiValue) {
        var paragraphs = textFrame.paragraphs;
        for (var paragraphIndex = 0; paragraphIndex < paragraphs.length; paragraphIndex++) {
            try { paragraphs[paragraphIndex].paragraphAttributes.mojikumi = mojikumiValue; } catch (e) { }
        }
    }

    /* 種類で振り分け（TextFrame は直接、GroupItem は再帰）/ Dispatch by type (TextFrame directly, GroupItem recursively) */
    function applyMojikumiToItem(item, mojikumiValue) {
        var typeName = getTypeName(item);
        if (typeName === "TextFrame") {
            applyMojikumiToTextFrame(item, mojikumiValue);
        } else if (typeName === "GroupItem" && item.pageItems) {
            for (var i = 0; i < item.pageItems.length; i++) applyMojikumiToItem(item.pageItems[i], mojikumiValue);
        } else if (isTextRangeLikeType(typeName)) {
            var frame = findParentTextFrame(item);
            if (frame) applyMojikumiToTextFrame(frame, mojikumiValue);
        }
    }

    /* 選択全体に文字組みアキ量設定を適用 / Apply a mojikumi set to the whole selection
       mojikumiIndex === -1 は「なし」/ -1 means "None" */
    function applyMojikumiToSelection(selection, mojikumiIndex) {
        var mojikumiValue = (mojikumiIndex === -1) ? "なし" : app.activeDocument.mojikumiSet[mojikumiIndex];
        var itemList = (selection && selection.typename) ? [selection] : (selection || []);
        for (var i = 0; i < itemList.length; i++) applyMojikumiToItem(itemList[i], mojikumiValue);
    }

    /* mojikumiSet の要素（文字列）からインデックスを引く（見つからなければ -2＝不明）
       要素は文字列で、組み込みは内部 ID（BetaGumi など）、カスタムは名前そのもの。.name は undefined
       Look up a mojikumiSet index by its element string (-2 = unknown); built-ins are internal IDs, custom sets are their names */
    function matchMojikumiName(name) {
        try {
            var mojikumiSets = app.activeDocument.mojikumiSet;
            for (var i = 0; i < mojikumiSets.length; i++) {
                if (String(mojikumiSets[i]) === name) return i;
            }
        } catch (e) { }
        return -2;
    }

    /* カスタムの文字組みアキ量設定の名前（mojikumiSet のインデックス7以降）を改行区切りで返す
       Names of the custom mojikumi sets (mojikumiSet index 7 and later), joined by line feeds */
    function readCustomMojikumiNames() {
        var names = [];
        try {
            var mojikumiSets = app.activeDocument.mojikumiSet;
            for (var i = MOJIKUMI_BUILTIN_COUNT; i < mojikumiSets.length; i++) names.push(String(mojikumiSets[i]));
        } catch (e) { }
        return names.join("\n");
    }

    /* 段落の文字組みアキ量設定を ID へ変換 / Resolve a paragraph's mojikumi to an id
       戻り値: 0以上=mojikumiSet のインデックス / -1=なし / -2=読み取り不可・不明（UI を変更しない）
       getter は環境により MojikumiSet オブジェクト／名前文字列のどちらも返しうるため両対応
       Returns: >=0 mojikumiSet index / -1 = none / -2 = unreadable or unknown (leave UI untouched) */
    function mojikumiToId(paragraph) {
        var mojikumiAttr;
        try { mojikumiAttr = paragraph.paragraphAttributes.mojikumi; } catch (e) { return -2; }
        if (mojikumiAttr === undefined || mojikumiAttr === null) return -1;
        if (typeof mojikumiAttr === "string") {
            return (mojikumiAttr === "" || mojikumiAttr === "なし") ? -1 : matchMojikumiName(mojikumiAttr);
        }
        var mojikumiName;
        try { mojikumiName = (mojikumiAttr.name !== undefined && mojikumiAttr.name !== null) ? mojikumiAttr.name : ""; } catch (e2) { return -2; }
        if (mojikumiName === "") return -2;
        if (mojikumiName === "なし") return -1;
        return matchMojikumiName(mojikumiName);
    }

    /* テキストフレームに禁則を適用（「なし」= "None" は scripting では設定不可で例外になる）
       Apply kinsoku to a text frame ("None" can't be set via scripting and throws) */
    function applyKinsokuToTextFrame(textFrame, kinsokuName) {
        try {
            textFrame.textRange.paragraphAttributes.kinsoku = kinsokuName;
        } catch (e) {
            /* 「なし」は scripting から設定できない（アクション再生が必要）/ "None" can't be set via scripting */
        }
    }

    /* 種類で振り分け（TextFrame は直接、GroupItem は再帰、テキスト範囲は親フレームへ）
       Dispatch by type (TextFrame directly, GroupItem recursively, text ranges to their parent frame) */
    function applyKinsokuToItem(item, kinsokuName) {
        var typeName = getTypeName(item);
        if (typeName === "TextFrame") {
            applyKinsokuToTextFrame(item, kinsokuName);
        } else if (typeName === "GroupItem" && item.pageItems) {
            for (var i = 0; i < item.pageItems.length; i++) applyKinsokuToItem(item.pageItems[i], kinsokuName);
        } else if (isTextRangeLikeType(typeName)) {
            var frame = findParentTextFrame(item);
            if (frame) applyKinsokuToTextFrame(frame, kinsokuName);
        }
    }

    /* 選択全体に禁則を適用 / Apply kinsoku to the whole selection */
    function applyKinsokuToSelection(selection, kinsokuName) {
        var itemList = (selection && selection.typename) ? [selection] : (selection || []);
        for (var i = 0; i < itemList.length; i++) applyKinsokuToItem(itemList[i], kinsokuName);
    }

    /* 段落の禁則を id 文字列へ / Resolve a paragraph's kinsoku to an id string
       禁則「なし」の段落は getter が例外（Error 9563）を投げるため "None" を返す
       A no-kinsoku paragraph throws on read (Error 9563), so return "None" */
    function kinsokuToId(paragraph) {
        try {
            var kinsokuValue = paragraph.paragraphAttributes.kinsoku;
            if (kinsokuValue === undefined || kinsokuValue === null || kinsokuValue === "") return "None";
            return String(kinsokuValue);
        } catch (e) {
            return "None";
        }
    }

    /* 選択へ文字揃え（縦方向の揃え）を適用 / Apply character alignment to the selection */
    function applyAlignmentToSelection(selection, alignValue) {
        if (getTypeName(selection) === "TextRange") { selection.characterAttributes.alignment = alignValue; return 1; }
        var count = 0;
        if (selection && selection.length) {
            for (var i = 0; i < selection.length; i++) count += applyStyleRunAlignment(selection[i], alignValue);
        }
        return count;
    }

    /* 選択の行送り状態を読み取り、初期表示用にエンコード / Read the selection's leading state for initial reflection
       戻り値: count|isAuto|leadingPt|baseFontSizePt|autoAmount|leadingTypeId|
               paragraphCount|alignmentId|fontFamily(enc)|fontStyle(enc)|fontSizePt|kernId|justifyId|hScale|mojikumiId|kinsokuId|
               customMojikumiNames(enc)

       注意: 値系（フォント・サイズ・行送り・カーニング・揃え・禁則など）は「最初のフレームの
       先頭文字／先頭段落」だけを代表値として読む簡略化。複数フレームを選択したり、1フレーム内で
       設定が混在している場合、UI 表示は先頭の値になり実態とズレる（count だけは全体数を返す）。
       Note: the value fields (font, size, leading, kerning, alignment, kinsoku, ...) are read only
       from the FIRST frame's first character/paragraph as a representative. With a multi-frame
       selection or mixed settings within a frame, the UI shows the first value and may not reflect
       the whole selection (only `count` reports the total). */
    function readLeadingState(frames) {
        var count = frames.length;
        var isAuto = 0, leadingPt = NaN, baseFontSizePt = NaN, autoAmount = 175;
        var leadingTypeId = "", paragraphCount = 0, alignmentId = "";
        var fontFamily = "", fontStyle = "", fontSizePt = NaN, kernId = "", justifyId = "", hScale = NaN, mojikumiId = -1, kinsokuId = "None";
        for (var i = 0; i < frames.length; i++) {
            try {
                var lines = frames[i].lines;
                if (lines && lines.length > 0 && lines[0].characters.length > 0) {
                    var firstChar = lines[0].characters[0];
                    isAuto = firstChar.characterAttributes.autoLeading ? 1 : 0;
                    leadingPt = firstChar.characterAttributes.leading;
                    baseFontSizePt = getBaseFontSizeFromLine(lines[0]);
                    alignmentId = alignmentToId(firstChar.characterAttributes.alignment);
                    fontSizePt = firstChar.characterAttributes.size;
                    hScale = firstChar.characterAttributes.horizontalScale;
                    kernId = kernMethodToId(firstChar.characterAttributes.kerningMethod);
                    try {
                        var font = firstChar.characterAttributes.textFont;
                        if (font) { fontFamily = font.family; fontStyle = font.style; }
                    } catch (eFont) { }
                    var paragraphs = frames[i].paragraphs;
                    if (paragraphs && paragraphs.length > 0) {
                        autoAmount = paragraphs[0].paragraphAttributes.autoLeadingAmount;
                        justifyId = justificationToId(paragraphs[0].paragraphAttributes.justification);
                        mojikumiId = mojikumiToId(paragraphs[0]);
                        kinsokuId = kinsokuToId(paragraphs[0]);
                    }
                    leadingTypeId = leadingTypeToId(frames[i].textRange.leadingType);
                    break;
                }
            } catch (e) { }
        }
        for (var k = 0; k < frames.length; k++) {
            try { paragraphCount += frames[k].paragraphs.length; } catch (e2) { }
        }
        return [count, isAuto, leadingPt, baseFontSizePt, autoAmount, leadingTypeId,
            paragraphCount, alignmentId, encodeURIComponent(fontFamily), encodeURIComponent(fontStyle),
            fontSizePt, kernId, justifyId, hScale, mojikumiId, kinsokuId, encodeURIComponent(readCustomMojikumiNames())].join("|");
    }

    // =========================================
    // メインエンジン委譲 / Main-engine delegation (BridgeTalk)
    // =========================================

    // =========================================
    // 使用フォント一覧（DocumentFontListSelectorPalette 由来）/ Used-fonts list (ported from DocumentFontListSelectorPalette)
    // これらもメインエンジンへ委譲する DOM 処理 / DOM helpers also delegated to the main engine
    // =========================================

    /* 小数2桁までで末尾ゼロを落とす / Round to 2 decimals and trim trailing zeros */
    function formatNumber(numericValue) {
        if (numericValue === null || numericValue === undefined || isNaN(numericValue)) return "?";
        var roundedValue = Math.round(numericValue * 100) / 100;
        return String(roundedValue);
    }

    /* フォントの表示名（ファミリー＋スタイル）/ Display name of a font (family + style) */
    function getFontDisplayName(textFont) {
        if (!textFont) return "(no font)";
        var fontFamily = textFont.family || textFont.name || "";
        var fontStyle = textFont.style || "";
        return fontFamily + (fontStyle ? " " + fontStyle : "");
    }

    /* 1文字の属性から組み合わせオブジェクトを作る（読めなければ null）/ Build a combination object from one character (null if unreadable) */
    function readComboFromCharacter(character) {
        try {
            var charAttributes = character.characterAttributes;
            var textFont = charAttributes.textFont;
            if (!textFont) return null;
            return {
                psName: textFont.name,
                displayName: getFontDisplayName(textFont),
                size: charAttributes.size,
                leading: charAttributes.leading,
                autoLeading: charAttributes.autoLeading ? true : false,
                tsume: charAttributes.Tsume,
                tracking: charAttributes.tracking,
                kernId: kernMethodToId(charAttributes.kerningMethod),
                proportionalMetrics: charAttributes.proportionalMetrics ? true : false
            };
        } catch (e) {
            return null;
        }
    }

    /* 組み合わせの重複排除キー / Dedupe key for a combination */
    function comboKey(combo) {
        return [
            combo.psName,
            formatNumber(combo.size),
            combo.autoLeading ? "auto" : formatNumber(combo.leading),
            String(Math.round(combo.tsume)),
            String(Math.round(combo.tracking)),
            combo.kernId,
            combo.proportionalMetrics ? "p1" : "p0"
        ].join("|");
    }

    /* 現在のアートボードの矩形を取得（取れなければ null）/ Get the active artboard rect ([L,T,R,B]); null if unavailable */
    function getActiveArtboardRect(documentRef) {
        try {
            var activeIndex = documentRef.artboards.getActiveArtboardIndex();
            return documentRef.artboards[activeIndex].artboardRect;
        } catch (e) {
            return null;
        }
    }

    /* テキストフレームがアートボード矩形と重なるか / Whether a text frame overlaps the artboard rect */
    function frameOverlapsArtboard(textFrame, artboardRect) {
        if (!artboardRect) return true;
        var bounds;
        try { bounds = textFrame.geometricBounds; } catch (e) { return false; }
        var frameLeft = bounds[0], frameTop = bounds[1], frameRight = bounds[2], frameBottom = bounds[3];
        var artLeft = artboardRect[0], artTop = artboardRect[1], artRight = artboardRect[2], artBottom = artboardRect[3];
        if (frameRight < artLeft || frameLeft > artRight) return false;
        if (frameBottom > artTop || frameTop < artBottom) return false;
        return true;
    }

    /* アイテムが表示されているか（自身と親グループの hidden、所属レイヤーの visible を遡って確認）/ Whether an item is visible */
    function isItemVisible(pageItem) {
        var node = pageItem;
        try {
            while (node) {
                var nodeType = node.typename;
                if (nodeType === "Document") break;
                if (nodeType === "Layer") {
                    if (!node.visible) return false;
                } else {
                    if (node.hidden) return false;
                }
                node = node.parent;
            }
        } catch (e) { }
        return true;
    }

    /* アイテムがロックされていないか（自身と親グループの locked、所属レイヤーの locked を遡って確認）/ Whether an item is unlocked */
    function isItemUnlocked(pageItem) {
        var node = pageItem;
        try {
            while (node) {
                var nodeType = node.typename;
                if (nodeType === "Document") break;
                if (node.locked) return false;
                node = node.parent;
            }
        } catch (e) { }
        return true;
    }

    /* ドキュメントを走査し、組み合わせを TAB 区切り行（LF 連結）で返す / Scan the document; return combos as TAB-joined rows (LF-joined)
       1行 = psName \t displayName \t size \t leading \t autoLeading(0/1) \t tsume \t tracking \t kernId \t proportionalMetrics(0/1) \t count */
    function collectDocumentCombosRaw(documentRef, currentArtboardOnly, includeHidden, includeLocked) {
        var comboOrder = [], comboData = {}, comboRows = [];
        var TAB = String.fromCharCode(9), LF = String.fromCharCode(10);
        var artboardRect = currentArtboardOnly ? getActiveArtboardRect(documentRef) : null;
        var textFrames = documentRef.textFrames;
        for (var f = 0; f < textFrames.length; f++) {
            if (!includeHidden && !isItemVisible(textFrames[f])) continue;
            if (!includeLocked && !isItemUnlocked(textFrames[f])) continue;
            if (artboardRect && !frameOverlapsArtboard(textFrames[f], artboardRect)) continue;
            var characters;
            try { characters = textFrames[f].characters; } catch (eFrame) { continue; }
            var seenInFrame = {};
            for (var c = 0; c < characters.length; c++) {
                var combo = readComboFromCharacter(characters[c]);
                if (!combo) continue;
                var dedupeKey = comboKey(combo);
                if (!comboData[dedupeKey]) {
                    comboData[dedupeKey] = { combo: combo, count: 0 };
                    comboOrder.push(dedupeKey);
                }
                /* 同じフレーム内で同じ組み合わせを複数回使っても使用数は1だけ増やす / Count each frame once per combo */
                if (!seenInFrame[dedupeKey]) {
                    seenInFrame[dedupeKey] = true;
                    comboData[dedupeKey].count++;
                }
            }
        }
        for (var i = 0; i < comboOrder.length; i++) {
            var entry = comboData[comboOrder[i]];
            var entryCombo = entry.combo;
            comboRows.push([
                entryCombo.psName, entryCombo.displayName, String(entryCombo.size), String(entryCombo.leading),
                entryCombo.autoLeading ? "1" : "0", String(entryCombo.tsume), String(entryCombo.tracking), entryCombo.kernId,
                entryCombo.proportionalMetrics ? "1" : "0", String(entry.count)
            ].join(TAB));
        }
        return comboRows.join(LF);
    }

    /* 選択範囲に組み合わせを適用 / Apply a combination to the given ranges. 戻り値: 適用できた範囲数 / Returns applied count */
    function applyComboToRanges(selectedRanges, combo) {
        var textFont = null;
        try { textFont = app.textFonts.getByName(combo.psName); } catch (eGet) { textFont = null; }
        var appliedCount = 0;
        for (var i = 0; i < selectedRanges.length; i++) {
            /* ラン単位の属性のみ（フォント・サイズ・行送り・トラッキング）。文字ツメ・カーニング・プロポーショナルは段落単位で applyCombo 側
               Run-scoped attrs only (font/size/leading/tracking). Tsume, kerning, proportional apply per paragraph in applyCombo */
            try {
                var charAttributes = selectedRanges[i].characterAttributes;
                if (textFont) charAttributes.textFont = textFont;
                if (!isNaN(combo.size)) charAttributes.size = combo.size;
                if (combo.autoLeading) {
                    charAttributes.autoLeading = true;
                } else if (!isNaN(combo.leading)) {
                    charAttributes.autoLeading = false;
                    charAttributes.leading = combo.leading;
                }
                if (!isNaN(combo.tracking)) charAttributes.tracking = combo.tracking;
                appliedCount++;
            } catch (eApplyRange) { }
        }
        return appliedCount;
    }

    /* 組み合わせ（または matchFontOnly ならフォントのみ）に一致する文字を含むテキストフレームを選択 / Select frames whose characters match the combo (or the font only when matchFontOnly). 戻り値: 選択したフレーム数 */
    function selectFramesMatchingCombo(documentRef, combo, currentArtboardOnly, includeHidden, includeLocked) {
        var matchFontOnly = combo.matchFontOnly ? true : false;
        var targetKey = matchFontOnly ? combo.psName : comboKey(combo);
        var artboardRect = currentArtboardOnly ? getActiveArtboardRect(documentRef) : null;
        var textFrames = documentRef.textFrames;
        var matchedFrames = [];
        for (var f = 0; f < textFrames.length; f++) {
            if (!includeHidden && !isItemVisible(textFrames[f])) continue;
            if (!includeLocked && !isItemUnlocked(textFrames[f])) continue;
            if (artboardRect && !frameOverlapsArtboard(textFrames[f], artboardRect)) continue;
            var characters;
            try { characters = textFrames[f].characters; } catch (eFrame) { continue; }
            for (var c = 0; c < characters.length; c++) {
                var charCombo = readComboFromCharacter(characters[c]);
                if (charCombo && (matchFontOnly ? charCombo.psName : comboKey(charCombo)) === targetKey) { matchedFrames.push(textFrames[f]); break; }
            }
        }
        /* 一致0件のときは現在の選択を保持 / Keep the current selection when nothing matched */
        if (matchedFrames.length === 0) return 0;
        /* 配列を直接代入すれば既存選択を一括置換 / Assigning the array replaces the current selection */
        documentRef.selection = matchedFrames;
        return matchedFrames.length;
    }

    /* メインエンジンへ送る処理関数（上で定義済みのものを再利用）
       Functions shipped to the main engine (reuse of the helpers above) */
    var WORKER_FUNCS = [
        getTypeName, errMessage, runRangeAction, collectTextRangesFromItem, getSelectedTextRanges, getSelectedParagraphRanges, resolveAutoKernType, applyKerningToRanges, applyKerningMethodToRanges, applyTsumeToRanges,
        applyTrackingToRanges, applyProportionalToRanges, clearAkiOnRanges, applyFontToRanges,
        kernMethodToId, justificationToId, resolveJustification,
        isTextRangeLikeType, findParentTextFrame, getTextFrameKey, collectJustifyTargets,
        collectJustifyTargetsFromItem, addJustifyTarget, applyJustificationToParagraphs,
        forceLeftJustification, justifyKeepingPosition,
        resolveAlignment, alignmentToId, getAlignmentCharAttrs, getFirstAlignmentCharAttrs, applyStyleRunAlignment,
        getLineSampleFontSizes, getMostFrequentNumber, getBaseFontSizeFromLine,
        getProcessableTextFrame, collectLeadingFrames, collectLeadingFramesFromItem, addLeadingFrame,
        resolveLeadingType, leadingTypeToId,
        applyLeadingBasisToFrames, applyAutoLeadingToParagraphs, applyHyphenationToRanges, applyAlignmentToSelection,
        applyMojikumiToTextFrame, applyMojikumiToItem, applyMojikumiToSelection, matchMojikumiName, readCustomMojikumiNames, mojikumiToId,
        applyKinsokuToTextFrame, applyKinsokuToItem, applyKinsokuToSelection, kinsokuToId,
        readLeadingState,
        formatNumber, getFontDisplayName, readComboFromCharacter, comboKey,
        getActiveArtboardRect, frameOverlapsArtboard, isItemVisible, isItemUnlocked,
        collectDocumentCombosRaw, applyComboToRanges, selectFramesMatchingCombo
    ];

    /* 関数配列を toString() で連結してソース文字列にする / Join the function array into a source string
       関数本体のみ送られるため、参照する定数はここで先頭に定義しておく
       Only function bodies are shipped, so constants they reference are declared up front */
    function buildWorkerLibSource() {
        var src = "var LINE_FONT_SIZE_SAMPLE_COUNT=" + LINE_FONT_SIZE_SAMPLE_COUNT + ";\n";
        src += "var MOJIKUMI_BUILTIN_COUNT=" + MOJIKUMI_BUILTIN_COUNT + ";\n";
        for (var i = 0; i < WORKER_FUNCS.length; i++) src += WORKER_FUNCS[i].toString() + "\n";
        return src;
    }
    var workerLibCache = null;
    function getWorkerLibSource() {
        if (workerLibCache === null) workerLibCache = buildWorkerLibSource();
        return workerLibCache;
    }

    /* 選択範囲へ作用する定型アクションの共通処理（空チェック→try→redraw→件数返却）
       Shared shape for range-acting actions: empty-check, try, redraw, return the count */
    function runRangeAction(ranges, applyFn) {
        if (ranges.length === 0) return "OK:0";
        try { applyFn(); } catch (e) { return "ERR:" + errMessage(e); }
        app.redraw();
        return "OK:" + ranges.length;
    }

    /* メインエンジンで実行されるディスパッチャ / Dispatcher executed on the main engine
       count: 対象数 / getState: 選択状態 / apply: カーニング / applyTsume: 文字ツメ / applyLeading: 行送り
       結果は "OK:<payload>" または "ERR:<msg>" の文字列で返す */
    function dispatch(action, params) {
        if (app.documents.length === 0) return "ERR:nodoc";
        try { app.activeDocument; } catch (e) { return "ERR:nodoc"; }

        var ranges = getSelectedTextRanges();
        if (action === "count") {
            return "OK:" + ranges.length;
        }
        if (action === "getState") {
            return "OK:" + readLeadingState(collectLeadingFrames(app.activeDocument.selection));
        }
        if (action === "toggleHiddenChar") {
            app.executeMenuCommand("showHiddenChar");
            return "OK:1";
        }
        if (action === "getCurrentFont") {
            if (ranges.length === 0) return "OK:";
            try {
                var charAttrs = ranges[0].characterAttributes;
                var currentFont = charAttrs.textFont;
                if (!currentFont || !currentFont.name) return "OK:";
                var currentKernId = kernMethodToId(charAttrs.kerningMethod);
                var currentTsume = Math.round(charAttrs.Tsume);
                var currentTracking = Math.round(charAttrs.tracking);
                return "OK:" + encodeURIComponent([currentFont.name, currentKernId, currentTsume, currentTracking].join("|"));
            } catch (errCur) {
                return "ERR:" + errMessage(errCur);
            }
        }
        if (action === "applyFont") return runRangeAction(ranges, function () { applyFontToRanges(ranges, params.psName); });
        if (action === "applyFontPreset") return runRangeAction(ranges, function () {
            applyFontToRanges(ranges, params.psName);
            if (params.kern) applyKerningToRanges(ranges, resolveAutoKernType(params.kern));
            if (params.tsume !== undefined && params.tsume !== null) applyTsumeToRanges(ranges, params.tsume);
            if (params.tracking !== undefined && params.tracking !== null) applyTrackingToRanges(ranges, params.tracking);
        });
        if (action === "resolveFontNames") {
            var names = params.psList ? params.psList.split(String.fromCharCode(10)) : [];
            var TAB = String.fromCharCode(9), LF = String.fromCharCode(10), resolved = [];
            for (var nameIndex = 0; nameIndex < names.length; nameIndex++) {
                var displayName = names[nameIndex];
                try {
                    var resolvedFont = app.textFonts.getByName(names[nameIndex]);
                    if (resolvedFont) displayName = resolvedFont.family + (resolvedFont.style ? " " + resolvedFont.style : "");
                } catch (eRes) { }
                resolved.push(names[nameIndex] + TAB + displayName);
            }
            return "OK:" + encodeURIComponent(resolved.join(LF));
        }
        // 自動カーニング・文字ツメは段落単位（選択が触れた段落全体へ）/ Auto-kerning & Tsume apply per paragraph
        if (action === "apply") { var kernParas = getSelectedParagraphRanges(); return runRangeAction(kernParas, function () { applyKerningToRanges(kernParas, resolveAutoKernType(params.method)); }); }
        if (action === "applyTsume") { var tsumeParas = getSelectedParagraphRanges(); return runRangeAction(tsumeParas, function () { applyTsumeToRanges(tsumeParas, params.value); }); }
        // トラッキングはラン（選択）単位のまま / Tracking stays per selection (run)
        if (action === "applyTracking") return runRangeAction(ranges, function () { applyTrackingToRanges(ranges, params.tracking); });
        if (action === "applyJustification") {
            var justifyTargets = collectJustifyTargets(app.activeDocument.selection);
            if (justifyTargets.length === 0) return "OK:0";
            var justifyValue = resolveJustification(params.justify);
            try {
                for (var targetIndex = 0; targetIndex < justifyTargets.length; targetIndex++) {
                    justifyKeepingPosition(justifyTargets[targetIndex], justifyValue, params.justify);
                }
            } catch (errJustify) {
                return "ERR:" + errMessage(errJustify);
            }
            app.redraw();
            return "OK:" + justifyTargets.length;
        }
        if (action === "applyFontSize") return runRangeAction(ranges, function () {
            for (var rangeIndex = 0; rangeIndex < ranges.length; rangeIndex++) ranges[rangeIndex].characterAttributes.size = params.sizePt;
        });
        // タイプスケール用：選択が触れた段落全体にフォントサイズを適用 / Type scale: apply the size to every touched paragraph in full
        if (action === "applyFontSizePara") { var sizeParas = getSelectedParagraphRanges(); return runRangeAction(sizeParas, function () {
            for (var paraIndex = 0; paraIndex < sizeParas.length; paraIndex++) sizeParas[paraIndex].characterAttributes.size = params.sizePt;
        }); }
        if (action === "applyScale") return runRangeAction(ranges, function () {
            for (var rangeIndex = 0; rangeIndex < ranges.length; rangeIndex++) {
                ranges[rangeIndex].characterAttributes.horizontalScale = params.scale;
                ranges[rangeIndex].characterAttributes.verticalScale = params.scale;
            }
        });
        // サイズと比率を1回でまとめて適用（実サイズ↔見かけトグル用。undo を1エントリに保つ）
        // Apply size and scale together in one pass (for the Actual↔Apparent toggle; keeps undo to one entry)
        if (action === "applyFontSizeAndScale") return runRangeAction(ranges, function () {
            for (var rangeIndex = 0; rangeIndex < ranges.length; rangeIndex++) {
                ranges[rangeIndex].characterAttributes.size = params.sizePt;
                ranges[rangeIndex].characterAttributes.horizontalScale = params.scale;
                ranges[rangeIndex].characterAttributes.verticalScale = params.scale;
            }
        });
        if (action === "applyAlign") {
            var alignSel = app.activeDocument.selection;
            var alignValue = resolveAlignment(params.align);
            var alignCount = 0;
            try {
                if (getTypeName(alignSel) === "TextRange") {
                    alignSel.characterAttributes.alignment = alignValue;
                    alignCount = 1;
                } else if (alignSel && alignSel.length) {
                    for (var itemIndex = 0; itemIndex < alignSel.length; itemIndex++) {
                        alignCount += applyStyleRunAlignment(alignSel[itemIndex], alignValue);
                    }
                }
            } catch (errAlign) {
                return "ERR:" + errMessage(errAlign);
            }
            app.redraw();
            return "OK:" + alignCount;
        }
        if (action === "applyLeading") {
            var leadingFrames = collectLeadingFrames(app.activeDocument.selection);
            if (leadingFrames.length === 0) return "OK:" + readLeadingState(leadingFrames);
            try {
                // 自動行送り量（%）を段落ごとに設定し、常に自動行送りに / Set the auto-leading amount (%) per paragraph; always auto-leading
                applyAutoLeadingToParagraphs(getSelectedParagraphRanges(), params.percent);
                // 行送りの基準（leadingType）はフレーム単位で設定 / The leading basis is set per frame
                if (params.leadingType !== undefined) applyLeadingBasisToFrames(leadingFrames, resolveLeadingType(params.leadingType));
            } catch (errLeading) {
                return "ERR:" + errMessage(errLeading);
            }
            app.redraw();
            return "OK:" + readLeadingState(leadingFrames);
        }
        if (action === "applyProfile") {
            var profSel = app.activeDocument.selection;
            var profParas = getSelectedParagraphRanges(); // 自動カーニング・文字ツメは段落単位 / Kerning & Tsume per paragraph
            try {
                if (params.kern !== undefined) applyKerningToRanges(profParas, resolveAutoKernType(params.kern));
                if (params.tsume !== undefined) applyTsumeToRanges(profParas, params.tsume);
                if (params.tracking !== undefined) applyTrackingToRanges(ranges, params.tracking);
                if (params.sizePt !== undefined) { for (var sizeRangeIndex = 0; sizeRangeIndex < ranges.length; sizeRangeIndex++) ranges[sizeRangeIndex].characterAttributes.size = params.sizePt; }
                if (params.scale !== undefined) {
                    for (var scaleRangeIndex = 0; scaleRangeIndex < ranges.length; scaleRangeIndex++) {
                        ranges[scaleRangeIndex].characterAttributes.horizontalScale = params.scale;
                        ranges[scaleRangeIndex].characterAttributes.verticalScale = params.scale;
                    }
                }
                if (params.align !== undefined) applyAlignmentToSelection(profSel, resolveAlignment(params.align));
                if (params.justify !== undefined) {
                    var profTargets = collectJustifyTargets(profSel);
                    var profJustify = resolveJustification(params.justify);
                    for (var targetIndex = 0; targetIndex < profTargets.length; targetIndex++) {
                        justifyKeepingPosition(profTargets[targetIndex], profJustify, params.justify);
                    }
                }
                if (params.leadingPercent !== undefined) {
                    // 自動行送り量（%）を段落ごとに設定し、基準もあわせて設定 / Set the auto-leading amount (%) per paragraph, plus the basis
                    applyAutoLeadingToParagraphs(getSelectedParagraphRanges(), params.leadingPercent);
                    if (params.leadingType !== undefined) applyLeadingBasisToFrames(collectLeadingFrames(profSel), resolveLeadingType(params.leadingType));
                }
                if (params.mojikumiIndex !== undefined) applyMojikumiToSelection(profSel, params.mojikumiIndex);
                if (params.kinsoku !== undefined) applyKinsokuToSelection(profSel, params.kinsoku);
                if (params.clearAki) clearAkiOnRanges(ranges);
            } catch (errProfile) {
                return "ERR:" + errMessage(errProfile);
            }
            app.redraw();
            return "OK:" + ranges.length;
        }
        if (action === "applyMojikumi") {
            try {
                applyMojikumiToSelection(app.activeDocument.selection, params.mojikumiIndex);
            } catch (errMojikumi) {
                return "ERR:" + errMessage(errMojikumi);
            }
            app.redraw();
            return "OK:1";
        }
        if (action === "applyKinsoku") {
            try {
                applyKinsokuToSelection(app.activeDocument.selection, params.kinsoku);
            } catch (errKinsoku) {
                return "ERR:" + errMessage(errKinsoku);
            }
            app.redraw();
            return "OK:1";
        }
        if (action === "applyPolicy") {
            var policySel = app.activeDocument.selection;
            var policyFrames = collectLeadingFrames(policySel);
            try {
                if (params.align !== undefined) applyAlignmentToSelection(policySel, resolveAlignment(params.align));
                if (params.justify !== undefined) {
                    var policyTargets = collectJustifyTargets(policySel);
                    var policyJustify = resolveJustification(params.justify);
                    for (var policyTargetIndex = 0; policyTargetIndex < policyTargets.length; policyTargetIndex++) {
                        justifyKeepingPosition(policyTargets[policyTargetIndex], policyJustify, params.justify);
                    }
                }
                if (params.leadingType !== undefined) applyLeadingBasisToFrames(policyFrames, resolveLeadingType(params.leadingType));
                // 自動行送り量（%）は段落ごとに設定 / The auto-leading amount (%) is set per paragraph
                if (params.leadingPercent !== undefined) applyAutoLeadingToParagraphs(getSelectedParagraphRanges(), params.leadingPercent);
                // ハイフネーションは段落属性（触れた段落全体へ）/ Hyphenation is a paragraph attribute (whole touched paragraphs)
                if (params.hyphenation !== undefined) applyHyphenationToRanges(getSelectedParagraphRanges(), params.hyphenation);
                if (params.mojikumiIndex !== undefined) applyMojikumiToSelection(policySel, params.mojikumiIndex);
                if (params.kinsoku !== undefined) applyKinsokuToSelection(policySel, params.kinsoku);
            } catch (errPolicy) {
                return "ERR:" + errMessage(errPolicy);
            }
            app.redraw();
            return "OK:" + policyFrames.length;
        }
        if (action === "getCombos") {
            return "OK:" + encodeURIComponent(collectDocumentCombosRaw(app.activeDocument, params && params.currentArtboardOnly, params && params.includeHidden, params && params.includeLocked));
        }
        if (action === "applyCombo") {
            if (ranges.length === 0) return "OK:nosel";
            var appliedComboCount = 0;
            try {
                appliedComboCount = applyComboToRanges(ranges, params);
                // 文字ツメ・カーニング・プロポーショナルは段落単位（applyKerningMethodToRanges は proportional 非連動）
                // Tsume, kerning method, proportional apply per paragraph (kerning method only, no proportional coupling)
                var comboParas = getSelectedParagraphRanges();
                applyTsumeToRanges(comboParas, params.tsume);
                applyKerningMethodToRanges(comboParas, resolveAutoKernType(params.kernId));
                applyProportionalToRanges(comboParas, params.proportionalMetrics);
            } catch (errCombo) {
                return "ERR:" + errMessage(errCombo);
            }
            app.redraw();
            return "OK:" + appliedComboCount;
        }
        if (action === "selectMatching") {
            var matchedCount = selectFramesMatchingCombo(app.activeDocument, params, params && params.currentArtboardOnly, params && params.includeHidden, params && params.includeLocked);
            app.redraw();
            return "OK:" + matchedCount;
        }
        return "OK:0";
    }
    var DISPATCH_SRC = "(" + dispatch.toString() + ")";

    /* パラメータを安全な JS リテラル文字列へ / Serialize params to a safe JS literal */
    function paramsToSource(params) {
        if (!params) return "{}";
        var parts = [];
        if (params.method !== undefined) parts.push('method:decodeURIComponent("' + encodeURIComponent(params.method) + '")');
        if (params.value !== undefined) parts.push("value:" + parseInt(params.value, 10));
        if (params.tracking !== undefined) parts.push("tracking:" + parseInt(params.tracking, 10));
        if (params.sizePt !== undefined) parts.push("sizePt:" + params.sizePt);
        if (params.scale !== undefined) parts.push("scale:" + params.scale);
        if (params.align !== undefined) parts.push('align:decodeURIComponent("' + encodeURIComponent(params.align) + '")');
        if (params.justify !== undefined) parts.push('justify:decodeURIComponent("' + encodeURIComponent(params.justify) + '")');
        if (params.psName !== undefined) parts.push('psName:decodeURIComponent("' + encodeURIComponent(params.psName) + '")');
        if (params.psList !== undefined) parts.push('psList:decodeURIComponent("' + encodeURIComponent(params.psList) + '")');
        if (params.kern !== undefined) parts.push('kern:decodeURIComponent("' + encodeURIComponent(params.kern) + '")');
        if (params.tsume !== undefined) parts.push("tsume:" + parseInt(params.tsume, 10));
        // 行送り：自動行送り量（%）／プロファイル用の行送り%（いずれも数値）/ Leading: auto-leading amount (%) and the profile leading % (both numeric)
        if (params.percent !== undefined) parts.push("percent:" + params.percent);
        if (params.leadingPercent !== undefined) parts.push("leadingPercent:" + params.leadingPercent);
        if (params.leadingType !== undefined) parts.push('leadingType:"' + params.leadingType + '"');
        if (params.hyphenation !== undefined) parts.push("hyphenation:" + (params.hyphenation ? "true" : "false"));
        if (params.mojikumiIndex !== undefined) parts.push("mojikumiIndex:" + parseInt(params.mojikumiIndex, 10));
        if (params.kinsoku !== undefined) parts.push('kinsoku:decodeURIComponent("' + encodeURIComponent(params.kinsoku) + '")');
        if (params.clearAki !== undefined) parts.push("clearAki:" + (params.clearAki ? "true" : "false"));
        // 使用フォント一覧（combo 適用・走査）用フィールド / Fields for the used-fonts list (combo apply / scan)
        if (params.size !== undefined) parts.push("size:" + (isNaN(params.size) ? "NaN" : params.size));
        if (params.leading !== undefined) parts.push("leading:" + (isNaN(params.leading) ? "NaN" : params.leading));
        if (params.autoLeading !== undefined) parts.push("autoLeading:" + (params.autoLeading ? "true" : "false"));
        if (params.kernId !== undefined) parts.push('kernId:decodeURIComponent("' + encodeURIComponent(params.kernId) + '")');
        if (params.proportionalMetrics !== undefined) parts.push("proportionalMetrics:" + (params.proportionalMetrics ? "true" : "false"));
        if (params.currentArtboardOnly !== undefined) parts.push("currentArtboardOnly:" + (params.currentArtboardOnly ? "true" : "false"));
        if (params.includeHidden !== undefined) parts.push("includeHidden:" + (params.includeHidden ? "true" : "false"));
        if (params.includeLocked !== undefined) parts.push("includeLocked:" + (params.includeLocked ? "true" : "false"));
        if (params.matchFontOnly !== undefined) parts.push("matchFontOnly:" + (params.matchFontOnly ? "true" : "false"));
        return "{" + parts.join(",") + "}";
    }

    /*
     * 本文をメインエンジンへ送り、結果マーカーを解析して onDone(status, payload) を呼ぶ。
     * BridgeTalk は本文送信時にバックスラッシュをエスケープするため（"\r" → ターゲットで "\\r"）、
     * コード全体を encodeURIComponent で包んで送り（%エンコードに \ は出ない）、
     * ターゲットで decodeURIComponent + eval して元ソースに復元してから実行する。
     * Send the body to the main engine and parse the result marker.
     */
    function sendWorker(code, onDone) {
        var bridge = new BridgeTalk();
        bridge.target = BridgeTalk.appSpecifier;
        bridge.body = "eval(decodeURIComponent(\"" + encodeURIComponent(code) + "\"));";
        bridge.onResult = function (response) {
            var payload = response.body || "";
            var colonIndex = payload.indexOf(":");
            var marker = colonIndex >= 0 ? payload.substring(0, colonIndex) : payload;
            var rest = colonIndex >= 0 ? payload.substring(colonIndex + 1) : "";
            if (marker === "OK") onDone("ok", rest);
            else onDone("error", rest);
        };
        bridge.onError = function (response) { onDone("error", response && response.body ? response.body : "BridgeTalk error"); };
        bridge.send();
    }

    /* メインエンジンへアクションを委譲（非同期）/ Delegate an action to the main engine (async) */
    function runWorker(actionId, params, onDone) {
        var code = getWorkerLibSource() + "\nvar __r=" + DISPATCH_SRC + "(\"" + actionId + "\"," + paramsToSource(params) + ");__r;";
        sendWorker(code, onDone);
    }

    // =========================================
    // 使用フォント一覧：ラベル・解析（パレット側）/ Used-fonts list: labels & parsing (palette side)
    // =========================================

    /* カーニング method id を表示ラベルへ / Kerning method id to a display label */
    function usedFontKernLabel(kernMethodId) {
        var labelEntry = LABELS.autoKern[kernMethodId];
        return labelEntry ? getLabel(labelEntry) : "—";
    }

    /* 各列のセル文字列を組み立て / Build the per-column cell strings
       [使用数, フォント, サイズ, 行送り, 自動カーニング, 文字ツメ, トラッキング, プロポーショナル] */
    function comboCells(combo) {
        var countText = isNaN(combo.count) ? "?" : String(combo.count);
        var sizeText = formatNumber(combo.size) + "pt";
        var leadingText = combo.autoLeading
            ? getLabel(LABELS.usedFonts.autoLeading)
            : formatNumber(combo.leading) + "pt";
        var tsumeText = String(Math.round(combo.tsume));
        var trackingText = isNaN(combo.tracking) ? "?" : String(Math.round(combo.tracking));
        var propMetricsText = combo.proportionalMetrics ? "ON" : "OFF";
        return [countText, combo.displayName, sizeText, leadingText, usedFontKernLabel(combo.kernId), tsumeText, trackingText, propMetricsText];
    }

    /* 委譲結果（デコード済み）を組み合わせ配列に復元し、表示順に並べる / Parse the worker payload into combos and sort them */
    function parseCombosPayload(rawPayload) {
        var combos = [];
        if (!rawPayload) return combos;
        var TAB = String.fromCharCode(9), LF = String.fromCharCode(10);
        var comboRows = rawPayload.split(LF);
        for (var i = 0; i < comboRows.length; i++) {
            var fields = comboRows[i].split(TAB);
            if (fields.length < 10) continue;
            var combo = {
                psName: fields[0],
                displayName: fields[1],
                size: parseFloat(fields[2]),
                leading: parseFloat(fields[3]),
                autoLeading: fields[4] === "1",
                tsume: parseFloat(fields[5]),
                tracking: parseFloat(fields[6]),
                kernId: fields[7],
                proportionalMetrics: fields[8] === "1",
                count: parseInt(fields[9], 10)
            };
            combo.cells = comboCells(combo);
            combos.push(combo);
        }
        // フォント名→サイズ→行送り→自動カーニング→ツメ→トラッキング→プロポーショナル の順 / Sort by font, size, leading, kerning, Tsume, tracking, prop-metrics
        combos.sort(function (a, b) {
            if (a.displayName !== b.displayName) return a.displayName < b.displayName ? -1 : 1;
            if ((a.size || 0) !== (b.size || 0)) return (a.size || 0) - (b.size || 0);
            if ((a.leading || 0) !== (b.leading || 0)) return (a.leading || 0) - (b.leading || 0);
            if (a.kernId !== b.kernId) return a.kernId < b.kernId ? -1 : 1;
            if ((a.tsume || 0) !== (b.tsume || 0)) return (a.tsume || 0) - (b.tsume || 0);
            if ((a.tracking || 0) !== (b.tracking || 0)) return (a.tracking || 0) - (b.tracking || 0);
            if (a.proportionalMetrics !== b.proportionalMetrics) return a.proportionalMetrics ? 1 : -1;
            return 0;
        });
        return combos;
    }

    /* 組み合わせを適用パラメータへ / Convert a combo to apply params */
    function comboToParams(combo) {
        return {
            psName: combo.psName,
            size: combo.size,
            leading: combo.leading,
            autoLeading: combo.autoLeading,
            tsume: combo.tsume,
            tracking: combo.tracking,
            kernId: combo.kernId,
            proportionalMetrics: combo.proportionalMetrics
        };
    }

    /* 組み合わせ一覧をフォント単位に畳む（フォントのみ表示用。psName で重複排除、表示名で整列）
       Collapse the combos to unique fonts (for the font-only view; dedup by psName, sorted by display name) */
    function combosToFonts(combos) {
        var seen = {}, fonts = [];
        for (var i = 0; i < combos.length; i++) {
            var combo = combos[i];
            if (seen[combo.psName]) continue;
            seen[combo.psName] = true;
            fonts.push({ psName: combo.psName, displayName: combo.displayName });
        }
        fonts.sort(function (a, b) { return a.displayName < b.displayName ? -1 : (a.displayName > b.displayName ? 1 : 0); });
        return fonts;
    }

    // =========================================
    // UI構築 / Build UI
    // =========================================

    // =========================================
    // 行送り用の単位・選択肢ヘルパー / Leading: units and choices (palette side)
    // =========================================

    // UIレイアウト（再利用パーツ） / UI layout (reusable)

    /* ウィンドウ・パネルの余白と間隔 / Window & panel margins and spacing */
    var WINDOW_MARGINS = 16;                 /* ウィンドウ外周の余白 / window margin */
    var WINDOW_SPACING = 12;                 /* ウィンドウ内の要素間隔 / window spacing */
    var PANEL_MARGINS  = [16, 20, 16, 12];   /* パネル余白 [左,上,右,下] / panel margins */
    var PANEL_SPACING  = 12;                 /* パネル内の要素間隔 / panel spacing */
    var COLUMN_SPACING = 12;                 /* 2カラムの間隔 / gap between columns */
    var TAB_MARGINS    = [15, 20, 5, 10];    /* タブ余白 [左,上,右,下] / tab margins */

    /**
     * ウィンドウの共通設定
     * @param {Window} targetWindow - 対象のウィンドウ
     * @param {number} [spacing] - 要素間隔（省略時は WINDOW_SPACING）
     * @returns {void}
     */
    function setupWindow(targetWindow, spacing) {
        targetWindow.orientation = "column";
        targetWindow.alignChildren = "fill";
        targetWindow.margins = WINDOW_MARGINS;
        targetWindow.spacing = (typeof spacing === "number") ? spacing : WINDOW_SPACING;
    }

    /**
     * パネルの共通設定（子は幅いっぱい。ボタンは alignment = "left" で広げない）
     * @param {Panel} targetPanel - 対象のパネル
     * @param {number} [spacing] - 要素間隔（省略時は PANEL_SPACING）
     * @returns {void}
     */
    function setupPanel(targetPanel, spacing) {
        targetPanel.orientation = "column";
        targetPanel.alignChildren = ["fill", "top"];
        targetPanel.alignment = "fill";
        targetPanel.margins = PANEL_MARGINS;
        targetPanel.spacing = (typeof spacing === "number") ? spacing : PANEL_SPACING;
    }

    /**
     * タブの共通設定
     * @param {Tab} targetTab - 対象のタブ
     * @param {number} [spacing] - 要素間隔（省略時は変えない）
     * @returns {void}
     */
    function setupTab(targetTab, spacing) {
        targetTab.orientation = "column";
        targetTab.alignChildren = "fill";
        targetTab.margins = TAB_MARGINS;
        if (typeof spacing === "number") targetTab.spacing = spacing;
    }

    /**
     * 横並びの行グループの共通設定（ボタン列など）。
     * alignment と alignChildren を対で指定し、中のボタンが横に伸びたり天地がずれたりしないようにする
     * @param {Group} rowGroup - 対象のグループ
     * @param {string|string[]} [rowAlignment] - 横方向の alignment（省略時は "left"）。配列ならそのまま使う
     * @param {number} [spacing] - 要素間隔（省略時は PANEL_SPACING）
     * @returns {void}
     */
    function setupRow(rowGroup, rowAlignment, spacing) {
        rowGroup.orientation = "row";
        rowGroup.alignment = (rowAlignment instanceof Array) ? rowAlignment : [rowAlignment || "left", "center"];
        rowGroup.alignChildren = ["left", "center"];
        rowGroup.spacing = (typeof spacing === "number") ? spacing : PANEL_SPACING;
    }

    /**
     * ボタンの高さを指定した px だけ詰める（レイアウトが決まったあとに呼ぶ）
     * @param {Button} targetButton - 対象のボタン
     * @param {number} trimPixels - 詰める量（px）
     * @returns {void}
     */
    function trimButtonHeight(targetButton, trimPixels) {
        /* レイアウト前は size が無い / size is not set until the layout runs */
        if (!targetButton.size) return;
        targetButton.size = [targetButton.size.width, targetButton.size.height - trimPixels];
    }

    // UIレイアウト（再利用パーツ）ここまで / End of the reusable UI layout

    var GROUP_SPACING = 8; /* グループ内の要素間隔 / spacing inside groups */

    /* グループの共通設定（row/column で整列を切り替え）/ Apply shared group layout */
    function setupGroup(group, orientation, spacing) {
        var groupOrientation = orientation || "column";
        group.orientation = groupOrientation;
        group.alignChildren = (groupOrientation === "row") ? ["left", "center"] : ["left", "top"];
        group.alignment = "fill";
        group.spacing = (typeof spacing === "number") ? spacing : GROUP_SPACING;
    }

    /* タブを1枚追加して共通の体裁（setupTab）を適用 / Add one tab with the shared layout (setupTab) */
    function addTab(mainTabs, labelEntry) {
        var tab = mainTabs.add("tab", undefined, getLabel(labelEntry));
        setupTab(tab);
        return tab;
    }

    /* 少し低くするボタンの共通の高さ / Shared height for the "slightly shorter" buttons */
    var COMPACT_BUTTON_HEIGHT = 20;

    /* ボタンの高さを指定 px 詰める（レイアウト確定後に1回だけ呼ぶ）/ Trim a button's height by the given px (call once, after layout) */

    /* ボタンを共通の高さ（COMPACT_BUTTON_HEIGHT）に揃える / Fit a button to the shared compact height */
    function fitButtonHeight(button) {
        if (!button) return;
        try { trimButtonHeight(button, button.size.height - COMPACT_BUTTON_HEIGHT); } catch (e) {}
    }

    /* 高さを詰めるボタンをまとめて共通高さに揃える（表示＝レイアウト確定後に呼ぶ）
       Fit every height-trimmed button to the shared compact height (call after show, once layout is final) */
    function fitAllButtonHeights(ui) {
        var buttons = [
            ui.refreshCombosButton, ui.selectMatchingButton,
            ui.exportPresetButton, ui.addPresetButton, ui.overwritePresetButton, ui.deletePresetButton,
            ui.apparentToggleButton
        ];
        for (var i = 0; i < buttons.length; i++) fitButtonHeight(buttons[i]);
    }

    // =========================================
    // 単位 / Units
    // =========================================

    /* 単位コードに対応する表示ラベルと、1単位あたりのポイント数
       Unit code -> display label and points per unit */
    var UNITS = [
        { label: "in",    pointsPerUnit: 72 },                /* 0 */
        { label: "mm",    pointsPerUnit: 72 / 25.4 },         /* 1 */
        { label: "pt",    pointsPerUnit: 1 },                 /* 2 */
        { label: "pica",  pointsPerUnit: 12 },                /* 3 */
        { label: "cm",    pointsPerUnit: 72 / 2.54 },         /* 4 */
        { label: "Q",     pointsPerUnit: 72 / 25.4 * 0.25 },  /* 5 */
        { label: "px",    pointsPerUnit: 1 },                 /* 6 */
        { label: "ft/in", pointsPerUnit: 72 * 12 },           /* 7 */
        { label: "m",     pointsPerUnit: 72 / 25.4 * 1000 },  /* 8 */
        { label: "yd",    pointsPerUnit: 72 * 36 },           /* 9 */
        { label: "ft",    pointsPerUnit: 72 * 12 }            /* 10 */
    ];

    /* 単位コード5を「歯（H）」と表示する環境設定キー。文字サイズ（text/units）だけ「級（Q）」
       Preference keys that show unit code 5 as H; only the type size (text/units) shows Q */
    var HA_UNIT_PREF_KEYS = { "rulerType": true, "strokeUnits": true, "text/asianunits": true };

    /**
     * 環境設定キーの単位を返す
     * @param {string} [prefKey] - "rulerType"（既定）/ "strokeUnits" / "text/units" / "text/asianunits"
     * @returns {{code: number, label: string, pointsPerUnit: number}} 単位の情報
     */
    function getUnitInfo(prefKey) {
        var unitKey = prefKey || "rulerType";
        var unitCode = app.preferences.getIntegerPreference(unitKey);
        /* 未知のコードは pt に寄せる / unknown codes fall back to points */
        var unit = UNITS[unitCode] || UNITS[2];
        /* 級（Q）と歯（H）は同じ長さだが、文字サイズは「Q」、距離は「H」と呼び分ける */
        var label = (unitCode === 5 && HA_UNIT_PREF_KEYS[unitKey]) ? "H" : unit.label;
        return { code: unitCode, label: label, pointsPerUnit: unit.pointsPerUnit };
    }

    /**
     * 単位の値を pt に換算する
     * @param {number} value - 単位の値
     * @param {{pointsPerUnit: number}} unit - getUnitInfo() の戻り値か UNITS[i]
     * @returns {number} pt の値
     */
    function unitToPt(value, unit) {
        return value * unit.pointsPerUnit;
    }

    /**
     * pt の値を単位の値に換算する
     * @param {number} ptValue - pt の値
     * @param {{pointsPerUnit: number}} unit - getUnitInfo() の戻り値か UNITS[i]
     * @returns {number} 単位の値
     */
    function ptToUnit(ptValue, unit) {
        return ptValue / unit.pointsPerUnit;
    }

    /* 行送りの単位ラベル（Q/H 環境では行送りは「H」）/ Leading unit label (leading uses "H" when the unit is Q/H) */
    function getLeadingUnitLabel(unitCode) {
        if (unitCode === 5) return "H";
        return (UNITS[unitCode] || UNITS[2]).label;
    }

    /* タイプスケールの倍率（音程比）/ Type-scale ratios (musical intervals) */
    var TYPE_SCALE_RATIOS = [
        { label: "Minor Second 1.067", value: 1.067 },
        { label: "Major Second 1.125", value: 1.125 },
        { label: "Minor Third 1.2", value: 1.2 },
        { label: "Major Third 1.25", value: 1.25 },
        { label: "Golden Ratio: ½ 1.309", value: 1.309 },
        { label: "Perfect Fourth 1.333", value: 1.333 },
        { label: "Augmented Fourth 1.414", value: 1.414 },
        { label: "Golden Ratio 1.618", value: 1.618 }
    ];
    var TYPE_SCALE_DEFAULT_RATIO_INDEX = 3; // Major Third 1.25

    /* 基準サイズと倍率からタイプスケール（7段）を生成 / Generate a 7-step type scale from a base size and ratio
       index 2 が基準サイズ（基準を段番号 0、最上段を -2 とする）/ index 2 is the base (step 0; top row is -2) */
    function generateTypeScaleSizes(baseSize, ratio) {
        var sizes = [];
        var down = baseSize;
        for (var i = 0; i < 2; i++) down /= ratio;
        for (var j = 0; j < 7; j++) {
            sizes.push(Math.round(down * 10) / 10);
            down *= ratio;
        }
        return sizes;
    }

    /* 文字組みアキ量設定の選択肢（index は mojikumiSet のインデックス、-1=なし）
       Mojikumi choices (index is the mojikumiSet index; -1 = None) */
    var MOJIKUMI_CHOICES = [
        { index: -1, label: getLabel(LABELS.mojikumi.none) },
        { index: 0, label: getLabel(LABELS.mojikumi.lineEndFullHalf) },
        { index: 1, label: getLabel(LABELS.mojikumi.punctHalf) },
        { index: 2, label: getLabel(LABELS.mojikumi.lineEndHalf) },
        { index: 3, label: getLabel(LABELS.mojikumi.lineEndFull) },
        { index: 4, label: getLabel(LABELS.mojikumi.punctFull) },
        { index: 5, label: getLabel(LABELS.mojikumi.tight) },
        { index: 6, label: getLabel(LABELS.mojikumi.solid) }
    ];

    /* 禁則の選択肢（id は paragraphAttributes.kinsoku に渡す値）
       Kinsoku choices (id is the value passed to paragraphAttributes.kinsoku) */
    var KINSOKU_CHOICES = [
        { id: "None", label: getLabel(LABELS.kinsoku.none) },
        { id: "Hard", label: getLabel(LABELS.kinsoku.hard) },
        { id: "Soft", label: getLabel(LABELS.kinsoku.soft) },
        { id: "Soft_v2", label: getLabel(LABELS.kinsoku.softV2) }
    ];

    /* 行送りの基準の選択肢 / Leading-basis choices */
    function getLeadingTypeChoices() {
        return [
            { id: "top", label: getLabel(LABELS.leading.typeTop) },
            { id: "baseline", label: getLabel(LABELS.leading.typeBaseline) }
        ];
    }

    /* 自動カーニングの選択肢を生成 / Build the auto-kerning option list */
    function createAutoKernOptions() {
        return [
            { id: "mono", label: LABELS.autoKern.mono },
            { id: "zero", label: LABELS.autoKern.zero },
            { id: "metrics", label: LABELS.autoKern.metrics },
            { id: "optical", label: LABELS.autoKern.optical }
        ];
    }

    /* プリセット（PostScript 名 ＋ 文字組み設定）。選択時にまとめて適用する
       Presets (PostScript name + type-composition settings); all are applied together on selection
       kern: 自動カーニング method id（"metrics" 等）/ tsume: 文字ツメ%（0〜100）/ tracking: トラッキング（-500〜500）*/
    var DEFAULT_PRESETS = [
        { psName: "HiraginoSans-W3", kern: "metrics", tsume: 0, tracking: 0 }
    ];

    // =========================================
    // プリセットの保存・読み込み（JSON）/ Preset persistence (JSON)
    // ExtendScript には JSON が無いため、保存は手動シリアライズ、
    // 読み込みは自前ファイルなので eval で復元する（ES3 安全）。
    // ExtendScript has no JSON, so we serialize by hand and restore our own
    // file via eval (ES3-safe).
    // =========================================

    /* プリセット保存先の File / The File where presets are stored */
    function getPresetFile() {
        return File(Folder.userData.fsName + "/UnifiedTypePanel_presets.json");
    }

    /* 文字列を JSON 文字列リテラルへ / Quote a string as a JSON string literal */
    function jsonQuote(str) {
        var escaped = String(str);
        escaped = escaped.replace(/\\/g, "\\\\").replace(/"/g, '\\"');
        escaped = escaped.replace(/\r/g, "\\r").replace(/\n/g, "\\n").replace(/\t/g, "\\t");
        return '"' + escaped + '"';
    }

    /* プリセット配列を JSON テキストへ / Serialize the preset array to JSON text */
    function presetsToJsonText(presets) {
        var jsonLines = [];
        for (var i = 0; i < presets.length; i++) {
            var preset = presets[i];
            var fields = [];
            fields.push('"psName":' + jsonQuote(preset.psName));
            if (preset.kern !== undefined && preset.kern !== null) fields.push('"kern":' + jsonQuote(preset.kern));
            if (preset.tsume !== undefined && preset.tsume !== null) fields.push('"tsume":' + parseInt(preset.tsume, 10));
            if (preset.tracking !== undefined && preset.tracking !== null) fields.push('"tracking":' + parseInt(preset.tracking, 10));
            jsonLines.push("  {" + fields.join(", ") + "}");
        }
        return "[\n" + jsonLines.join(",\n") + "\n]\n";
    }

    /* プリセットをファイルへ保存 / Save presets to the file */
    function savePresets(presets) {
        var file = getPresetFile();
        try {
            file.encoding = "UTF-8";
            if (file.open("w")) {
                file.write(presetsToJsonText(presets));
                file.close();
                return true;
            }
        } catch (e) { }
        return false;
    }

    /* パース結果がプリセット配列として妥当か / Whether a parsed value is a valid preset array
       各要素が psName（文字列）を持つ配列であることを要求 / Requires an array whose items each have a string psName */
    function isValidPresetArray(parsed) {
        if (!parsed || typeof parsed.length !== "number" || parsed.length === 0) return false;
        for (var i = 0; i < parsed.length; i++) {
            var entry = parsed[i];
            if (!entry || typeof entry.psName !== "string" || entry.psName === "") return false;
        }
        return true;
    }

    /* 壊れた設定ファイルを .bak に退避（上書きせず原因調査できるように）
       Move a corrupt preset file aside to .bak (don't overwrite, so it can be inspected) */
    function backupCorruptPresetFile(file) {
        try {
            var backup = new File(file.fsName + ".bak");
            if (backup.exists) backup.remove();
            file.copy(backup);
        } catch (eBackup) { }
    }

    /* プリセットをファイルから読み込み（無ければ既定）/ Load presets (fall back to defaults)
       復旧方針を明示: (1) 読み込み失敗 → 既定 / (2) 空ファイル → 既定 /
       (3) パース失敗・内容不正 → 破損ファイルを .bak に退避してから既定へ復帰
       Recovery is explicit: (1) read error → defaults / (2) empty file → defaults /
       (3) parse failure or invalid shape → move the file to .bak, then defaults */
    function loadPresets() {
        var file = getPresetFile();
        if (!file.exists) return DEFAULT_PRESETS;

        /* 読み込み / Read */
        var fileText = "";
        try {
            file.encoding = "UTF-8";
            if (!file.open("r")) return DEFAULT_PRESETS;
            fileText = file.read();
            file.close();
        } catch (eRead) {
            try { file.close(); } catch (eClose) { }
            return DEFAULT_PRESETS;
        }

        /* 空ファイルは既定へ（破損扱いにしない）/ Empty file → defaults (not treated as corrupt) */
        if (!fileText || fileText.replace(/^\s+|\s+$/g, "") === "") return DEFAULT_PRESETS;

        /* パース（自前ファイルなので eval を許容）/ Parse (eval is acceptable for our own file) */
        var parsed = null;
        try {
            parsed = eval("(" + fileText + ")");
        } catch (eParse) {
            parsed = null;
        }

        /* パース失敗・内容不正は破損として .bak 退避のうえ既定へ / Parse failure or invalid shape → back up and use defaults */
        if (!isValidPresetArray(parsed)) {
            backupCorruptPresetFile(file);
            return DEFAULT_PRESETS;
        }
        return parsed;
    }

    // =========================================
    // パレット位置の保存・復元 / Palette position persistence
    // 閉じた位置（移動のたびの最新位置）を userData に保存し、次回起動時に同じ位置で開く。
    // モニタ構成が変わっても画面外に復元しないよう、保存値は $.screens の範囲で検証する。
    // Store the last position under userData and reopen there next time; validate against
    // $.screens so a changed monitor layout never restores the palette off-screen.
    // =========================================

    /**
     * パレット位置の保存先ファイルを返す
     * @returns {File} 位置保存用の JSON ファイル
     */
    function getPaletteLocationFile() {
        return File(Folder.userData.fsName + "/UnifiedTypePanel_location.json");
    }

    /**
     * 指定した座標がいずれかのモニタ内に収まるか判定する
     * @param {number} x - パレット左端の座標
     * @param {number} y - パレット上端の座標
     * @returns {boolean} いずれかの画面内に収まるなら true
     */
    function isLocationOnScreen(x, y) {
        var screens;
        try { screens = $.screens; } catch (eScreens) { return true; } /* 取得できない環境では検証しない / Skip validation when unavailable */
        if (!screens || !screens.length) return true;
        var margin = 40; /* タイトルバーを掴める余白 / Keep the title bar reachable */
        for (var i = 0; i < screens.length; i++) {
            var screen = screens[i];
            if (x >= screen.left - margin && x <= screen.right - margin &&
                y >= screen.top && y <= screen.bottom - margin) return true;
        }
        return false;
    }

    /**
     * パレットの現在位置をファイルへ保存する
     * @param {Window} win - 対象のパレット
     * @returns {boolean} 保存できたら true
     */
    function savePaletteLocation(win) {
        var x, y;
        try {
            x = win.location[0];
            y = win.location[1];
        } catch (eLocation) { return false; }
        if (typeof x !== "number" || typeof y !== "number" || !isFinite(x) || !isFinite(y)) return false;

        var file = getPaletteLocationFile();
        try {
            file.encoding = "UTF-8";
            if (file.open("w")) {
                file.write('{"x":' + Math.round(x) + ', "y":' + Math.round(y) + '}\n');
                file.close();
                return true;
            }
        } catch (eWrite) {
            try { file.close(); } catch (eClose) { }
        }
        return false;
    }

    /**
     * 保存済みのパレット位置を読み込む（未保存・不正・画面外は null）
     * @returns {Array<number>|null} [x, y]。使えない場合は null
     */
    function loadPaletteLocation() {
        var file = getPaletteLocationFile();
        if (!file.exists) return null;

        /* 読み込み / Read */
        var fileText = "";
        try {
            file.encoding = "UTF-8";
            if (!file.open("r")) return null;
            fileText = file.read();
            file.close();
        } catch (eRead) {
            try { file.close(); } catch (eClose) { }
            return null;
        }
        if (!fileText || fileText.replace(/^\s+|\s+$/g, "") === "") return null;

        /* パース（自前ファイルなので eval を許容）/ Parse (eval is acceptable for our own file) */
        var parsed = null;
        try {
            parsed = eval("(" + fileText + ")");
        } catch (eParse) {
            parsed = null;
        }
        if (!parsed || typeof parsed.x !== "number" || typeof parsed.y !== "number") return null;
        if (!isFinite(parsed.x) || !isFinite(parsed.y)) return null;

        /* モニタ構成が変わっていたら既定位置に任せる / Fall back to the default spot if the layout changed */
        if (!isLocationOnScreen(parsed.x, parsed.y)) return null;
        return [parsed.x, parsed.y];
    }

    /**
     * 保存済み位置をパレットへ適用する（保存が無ければ何もしない）
     * @param {Window} win - 対象のパレット
     * @returns {void}
     */
    function applySavedPaletteLocation(win) {
        var savedLocation = loadPaletteLocation();
        if (!savedLocation) return;
        try {
            win.location = savedLocation;
        } catch (eApply) { }
    }

    /* プリセット配列でリストボックスを再構築（表示名は後で和文名に差し替え）
       Rebuild a listbox from a preset array (display names resolved to Japanese later) */
    /* プリセットをフォントのみ／詳細の両 listbox へ流し込む / Fill both preset listboxes (font-only + detailed)
       詳細列: フォント / 自動カーニング / 文字ツメ / プロポーショナル(kern連動) / トラッキング
       Detailed columns: font / auto-kerning / Tsume / proportional (follows kern) / tracking */
    function fillPresetLists(fontOnlyLb, detailedLb, presets) {
        fontOnlyLb.removeAll();
        detailedLb.removeAll();
        for (var i = 0; i < presets.length; i++) {
            var preset = presets[i];
            // フォントのみ（単一列）/ Font-only (single column)
            var foItem = fontOnlyLb.add("item", preset.psName);
            foItem.psName = preset.psName;
            if (preset.kern !== undefined) foItem.kern = preset.kern;
            if (preset.tsume !== undefined) foItem.tsume = preset.tsume;
            if (preset.tracking !== undefined) foItem.tracking = preset.tracking;
            // 詳細（フォント＋4列）/ Detailed (font + 4 columns)
            var dItem = detailedLb.add("item", preset.psName);
            dItem.subItems[0].text = usedFontKernLabel(preset.kern);
            dItem.subItems[1].text = (preset.tsume !== undefined && preset.tsume !== null) ? String(preset.tsume) : "";
            dItem.subItems[2].text = (preset.kern === "metrics") ? "ON" : "OFF"; // プロポーショナルは kern 連動 / Proportional follows the kerning method
            dItem.subItems[3].text = (preset.tracking !== undefined && preset.tracking !== null) ? String(preset.tracking) : "";
            dItem.psName = preset.psName;
            if (preset.kern !== undefined) dItem.kern = preset.kern;
            if (preset.tsume !== undefined) dItem.tsume = preset.tsume;
            if (preset.tracking !== undefined) dItem.tracking = preset.tracking;
        }
    }

    /* 文字揃えの選択肢を生成 / Build the character-alignment option list */
    function createAlignOptions() {
        return [
            { id: "roman", label: LABELS.align.roman },
            { id: "top", label: LABELS.align.top },
            { id: "center", label: LABELS.align.center },
            { id: "bottom", label: LABELS.align.bottom },
            { id: "icftop", label: LABELS.align.icfTop },
            { id: "icfbottom", label: LABELS.align.icfBottom }
        ];
    }

    /* 行揃えの選択肢を生成 / Build the paragraph-justification option list */
    function createJustifyOptions() {
        return [
            { id: "left", label: LABELS.justify.left, icon: "left" },
            { id: "center", label: LABELS.justify.center, icon: "center" },
            { id: "right", label: LABELS.justify.right, icon: "right" },
            { id: "justifyLeft", label: LABELS.justify.justifyLeft, icon: "justifyLeft" },
            { id: "justifyAll", label: LABELS.justify.justifyAll, icon: "justifyAll" }
        ];
    }

    // UI の明暗（再利用パーツ） / UI theme (reusable)

    /**
     * UI がダークテーマかどうかを判定する（Illustrator は uiBrightness、InDesign は uiBrightnessPreference）
     * @returns {boolean} ダークなら true。取得できない環境では false（明るいUI扱い）
     */
    function isDarkUI() {
        try {
            if (app.preferences && app.preferences.getRealPreference) {
                return app.preferences.getRealPreference("uiBrightness") <= 0.5; /* Illustrator */
            }
            return app.generalPreferences.uiBrightnessPreference <= 0.5; /* InDesign */
        } catch (e) {
            return false;
        }
    }

    // UI の明暗（再利用パーツ）ここまで / End of the reusable UI theme

    // ステップボタン（再利用パーツ） / Stepper buttons (reusable)

    // -----------------------------------------
    // ステップボタンの寸法・増減量 / Stepper metrics and steps
    // -----------------------------------------
    var STEPPER_BUTTON_WIDTH   = 20;  /* ∧∨ボタンの幅 / button width */
    var STEPPER_BUTTON_HEIGHT  = 11;  /* ∧∨ボタン1つの高さ（2つ重ねた全体の高さは22） / button height (22 for the pair) */
    var STEPPER_CORNER_RADIUS  = 2;   /* 枠の角丸の半径（ScriptUIは円弧を描けないため短い線分で近似） / corner radius, approximated with segments */
    var STEPPER_FIELD_SPACING  = 3;   /* 項目名と∧∨の間隔 / spacing between the label and the stepper */
    var STEPPER_SIDE_MARGIN    = 3;   /* ∧∨の左に足す余白（右は入力欄に突き合わせる） / extra space left of the stepper */
    var STEPPER_SHIFT_MULTIPLE = 10;  /* shift＋クリックでそろえる倍数 / Shift-click snaps to multiples of this */
    var STEPPER_OPTION_STEP    = 0.1; /* option＋クリックの増減量 / Option-click step */

    /* 単位の換算は UnitValue に任せる（in / ft / yd / mm / cm / m / pt / pc / px ほか、単数形・複数形も可）。
       UnitValue に無い単位だけ、ここで UnitValue の単位に読み替える（値は「1単位＝何 unit か」）。
       「p」は「1p6」（1パイカ6ポイント）の形にも使う
       Units UnitValue lacks, mapped onto UnitValue units (how many of `unit` make one) */
    var STEPPER_UNIT_ALIASES = {
        "q": { unit: "mm", amount: 0.25 }, /* 級 / Q */
        "h": { unit: "mm", amount: 0.25 }, /* 歯 / H */
        "p": { unit: "pc", amount: 1 }     /* パイカ / pica */
    };

    // -----------------------------------------
    // ステップボタンの配色 / Stepper colors
    // -----------------------------------------
    var STEPPER_UI_DARK           = isDarkUI();
    /* UIの明るさは4段階あり、段階ごとに背景色が違う。どの段階でも背景に対する差で見せるよう、黒・白の半透明を重ねる。
       ダーク側は Illustrator 標準のスピナー（［グリッドに分割］）で実測、明るい側は最も明るい段階（背景 約0.94）から逆算
       UI brightness has four levels with different backgrounds, so colors are translucent overlays that follow the
       dialog background. Dark values are measured from Illustrator's own spinner; light values derived for the lightest level */
    var STEPPER_FILL_COLOR        = STEPPER_UI_DARK ? [0, 0, 0, 0.10]  : [1, 1, 1, 0.50];  /* 地 / background */
    var STEPPER_FRAME_COLOR       = STEPPER_UI_DARK ? [1, 1, 1, 0.07]  : [0, 0, 0, 0.10];  /* 枠線 / frame */
    var STEPPER_PRESSED_COLOR     = STEPPER_UI_DARK ? [1, 1, 1, 0.12]  : [0, 0, 0, 0.13];  /* 押下中 / pressed */
    var STEPPER_CHEVRON_COLOR     = STEPPER_UI_DARK ? [1, 1, 1, 1]     : [0, 0, 0, 0.70];  /* 山形の線 / chevron */
    var STEPPER_DIM_FILL_COLOR    = STEPPER_UI_DARK ? [1, 1, 1, 0.035] : [1, 1, 1, 0.30];  /* 無効時の地 / background when disabled */
    var STEPPER_DIM_FRAME_COLOR   = STEPPER_UI_DARK ? [1, 1, 1, 0.035] : [0, 0, 0, 0.05];  /* 無効時の枠線（ダークは地と同じで見せない） / frame when disabled */
    var STEPPER_DIM_CHEVRON_COLOR = STEPPER_UI_DARK ? [1, 1, 1, 0.20]  : [0, 0, 0, 0.25];  /* 無効時の山形 / chevron when disabled */

    // -----------------------------------------
    // 数値欄を作る（外から呼ぶ関数） / Public API
    // -----------------------------------------
    /**
     * 「項目名・∧∨・入力欄」をひと組にした数値欄を追加する。
     * ↑↓キーでも∧∨と同じように増減する。直接入力した値も、フォーカスが外れたときに
     * 整数化・下限・上限・単位（「20 mm」の形）へそろえ、数値でなければ直前の値に戻す。
     * 四則演算（+ - * / と括弧）を入れると、確定時に計算した値にする。欄と違う単位で入れた値は欄の単位へ換算する（mm の欄に「1 in」→「25.4 mm」）
     * @param {Group|Panel} parent - 追加先
     * @param {Object} fieldOptions - label（コロン込みの項目名）/ labelWidth / text / characters /
     *     step / min / max / integer（true で整数のみ）/ unit / onStep
     * @returns {EditText} 入力欄（項目名は .fieldLabel、∧∨は .stepperGroup で参照できる）
     */
    function addSteppedField(parent, fieldOptions) {
        var fieldRowGroup = parent.add("group");
        fieldRowGroup.orientation = "row";
        fieldRowGroup.alignChildren = ["left", "center"];
        fieldRowGroup.spacing = STEPPER_FIELD_SPACING;

        var fieldLabel = fieldRowGroup.add("statictext", undefined, fieldOptions.label || "");
        if (fieldOptions.labelWidth) {
            fieldLabel.preferredSize.width = fieldOptions.labelWidth;
            fieldLabel.justify = "right";
        }

        /* ∧∨と入力欄は隙間0で突き合わせる / butt the stepper against the field */
        var stepperInputGroup = fieldRowGroup.add("group");
        stepperInputGroup.orientation = "row";
        stepperInputGroup.alignChildren = ["left", "center"];
        stepperInputGroup.spacing = 0;
        stepperInputGroup.margins = 0;

        var numberInput;
        var stepperGroup = addStepper(stepperInputGroup, function () { return numberInput; }, fieldOptions);
        numberInput = stepperInputGroup.add("edittext", undefined, fieldOptions.text || "");
        numberInput.characters = fieldOptions.characters || 6;
        numberInput.fieldLabel = fieldLabel;
        numberInput.stepperGroup = stepperGroup;

        /* ↑↓キーも∧∨と同じ処理で増減する（増減量・下限・上限・単位・修飾キーをそろえる） / arrow keys share the stepper's logic */
        bindSteppedArrowKeys(numberInput, stepperGroup);

        /* 項目名のクリックで入力欄にフォーカスを移す / clicking the label focuses the field */
        fieldLabel.addEventListener("click", function () { focusNumberInput(numberInput); });

        /* 直接入力をそろえる。計算式は計算し、数値でなければ直前の値に戻す / normalize typed values; evaluate arithmetic, revert non-numbers */
        numberInput.lastValidText = numberInput.text;
        numberInput.onChange = function () {
            var value = evaluateArithmetic(numberInput.text, fieldOptions.unit);
            if (isNaN(value)) {
                numberInput.text = numberInput.lastValidText;
                return;
            }
            writeSteppedValue(numberInput, value, fieldOptions);
        };
        return numberInput;
    }

    /**
     * 数値欄の有効／無効を、項目名・∧∨ごとまとめて切り替える
     * @param {EditText} numberInput - addSteppedField() で作った入力欄
     * @param {boolean} isEnabled - 有効にするなら true
     * @returns {void}
     */
    function setSteppedFieldEnabled(numberInput, isEnabled) {
        numberInput.enabled = isEnabled;
        numberInput.fieldLabel.enabled = isEnabled;
        numberInput.stepperGroup.enabled = isEnabled;
        /* ∧∨は自作描画なので、描き直してディム表示を切り替える / redraw the custom-drawn buttons to update the dimming */
        for (var i = 0; i < numberInput.stepperGroup.children.length; i++) {
            redrawStepperGroup(numberInput.stepperGroup.children[i]);
        }
    }

    /**
     * 入力欄の値を増減する∧∨ボタンを、隙間なく縦に積んで追加する
     * @param {Group|Panel} parent - 追加先
     * @param {Function} getNumberInput - 対象の入力欄を返す関数（入力欄を∧∨より後に作れるよう、クリック時に引く）
     * @param {Object} stepOptions - step（増減量）/ min / max / integer / unit（例 " mm"）/ onStep(numberInput)
     * @returns {Group} ∧∨をまとめた group（.stepBy(direction) で同じ増減を呼べる）
     */
    function addStepper(parent, getNumberInput, stepOptions) {
        var stepperGroup = parent.add("group");
        stepperGroup.orientation = "column";
        stepperGroup.spacing = 0; /* 2つのボタンをつなげて1つの枠に見せる / join the buttons into one frame */
        stepperGroup.margins = [STEPPER_SIDE_MARGIN, 0, 0, 0]; /* 右は入力欄に突き合わせる / butt against the field on the right */
        stepperGroup.alignment = ["left", "center"];

        /**
         * 入力欄の値を増減する（shift を押しながらなら STEPPER_SHIFT_MULTIPLE の倍数へ、option なら STEPPER_OPTION_STEP ずつ。下限・上限で止める）
         * @param {number} direction - 増やすなら 1、減らすなら -1
         * @returns {void}
         */
        function stepBy(direction) {
            var numberInput = getNumberInput();
            if (!isStepperEnabledInTree(numberInput)) return; /* 入力欄か親が無効の間は動かさない */
            var value = evaluateArithmetic(numberInput.text, stepOptions.unit); /* 確定前の計算式も計算してから増減 / evaluate an uncommitted expression first */
            if (isNaN(value)) value = parseFloat(numberInput.text); /* 計算できなければ従来どおり先頭の数値 / fall back to the leading number */
            if (isNaN(value)) value = 0;
            writeSteppedValue(numberInput, computeSteppedValue(value, direction, stepOptions), stepOptions);
            if (stepOptions.onStep) stepOptions.onStep(numberInput);
        }

        /**
         * ∧∨を離したときに入力欄へフォーカスを移す（mousedown で移しても、離したときに外れる）
         * @param {Group} chevronButton - makeStepperChevronButton() で作ったボタン
         * @returns {Group} 渡したボタン
         */
        function focusInputOnRelease(chevronButton) {
            chevronButton.addEventListener("mouseup", function () {
                var numberInput = getNumberInput();
                if (isStepperEnabledInTree(numberInput)) focusNumberInput(numberInput);
            });
            return chevronButton;
        }

        /* 整数の欄では option＋クリックの0.1刻みが効かないので、説明から外す / integer fields have no 0.1 step */
        var upTooltip = stepOptions.integer ? LABELS.tooltip.stepUpInteger : LABELS.tooltip.stepUp;
        var downTooltip = stepOptions.integer ? LABELS.tooltip.stepDownInteger : LABELS.tooltip.stepDown;
        focusInputOnRelease(makeStepperChevronButton(stepperGroup, "up", function () { stepBy(1); })).helpTip = getLabel(upTooltip);
        focusInputOnRelease(makeStepperChevronButton(stepperGroup, "down", function () { stepBy(-1); })).helpTip = getLabel(downTooltip);
        stepperGroup.stepBy = stepBy; /* ↑↓キーからも同じ処理で増減できるよう公開 / shared with the arrow keys */
        stepperGroup.stepOptions = stepOptions; /* 確定時の計算で欄の単位を引けるよう公開 / lets the commit-time evaluation find the unit */
        return stepperGroup;
    }

    /**
     * 入力欄の↑↓キーを、∧∨と同じ処理で増減させる。ほかのキーは素通し。
     * あわせて、確定時に計算式・単位付きの値を計算して書き戻す（各スクリプトの onChange より先に呼ばれるので、onChange は計算後の値を読む）
     * @param {EditText} numberInput - 対象の入力欄
     * @param {Group} stepperGroup - addStepper() で作った∧∨
     * @returns {void}
     */
    function bindSteppedArrowKeys(numberInput, stepperGroup) {
        numberInput.addEventListener("keydown", function (event) {
            if (event.keyName !== "Up" && event.keyName !== "Down") return;
            stepperGroup.stepBy(event.keyName === "Up" ? 1 : -1);
            event.preventDefault(); /* カーソル移動を止める / keep the caret from moving */
        });
        numberInput.addEventListener("change", function () {
            var fieldUnit = stepperGroup.stepOptions ? stepperGroup.stepOptions.unit : undefined;
            var value = evaluateArithmetic(numberInput.text, fieldUnit);
            if (isNaN(value)) return; /* 計算できなければ各スクリプトの処理に任せる / leave it to the script's own handler */
            /* 式か、換算で値が変わったときだけ書き戻す（ただの数値は書式を崩さない） / rewrite only expressions and converted values */
            var hasOperator = /[*\/()\u00D7\u00F7\uFF0A\uFF0F\uFF08\uFF09]|[\d.\uFF10-\uFF19][^\d.\uFF10-\uFF19]*[+\-\u2212\uFF0B\uFF0D]/.test(numberInput.text);
            if (!hasOperator && value === parseFloat(numberInput.text)) return;
            numberInput.text = formatStepperNumber(value) + (fieldUnit || "");
        });
    }

    // -----------------------------------------
    // 値の計算 / Value helpers
    // -----------------------------------------
    /**
     * 押された修飾キーに応じて、1回分増減した値を返す
     * （shift なら STEPPER_SHIFT_MULTIPLE の倍数へ、option なら STEPPER_OPTION_STEP ずつ、それ以外は step の倍数へ（1.5→2、1.5→1）。
     * 整数の欄では option を無視して step の倍数へ）
     * @param {number} value - 元の値
     * @param {number} direction - 増やすなら 1、減らすなら -1
     * @param {Object} stepOptions - step（通常の増減量。省略時は 1）/ integer
     * @returns {number} 増減した値（下限・上限は未適用）
     */
    function computeSteppedValue(value, direction, stepOptions) {
        var keyState = ScriptUI.environment.keyboardState;
        if (keyState.shiftKey) return snapStepperToNextMultiple(value, STEPPER_SHIFT_MULTIPLE, direction);
        if (keyState.altKey && !stepOptions.integer) return value + direction * STEPPER_OPTION_STEP;
        return snapStepperToNextMultiple(value, stepOptions.step || 1, direction);
    }

    /**
     * 値を、指定した方向にある次の倍数へ移す（230→240、232→240、下げるときは 232→230、230→220）
     * @param {number} value - 元の値
     * @param {number} multiple - 倍数の単位（例 10）
     * @param {number} direction - 上げるなら 1、下げるなら -1
     * @returns {number} 移した値
     */
    function snapStepperToNextMultiple(value, multiple, direction) {
        /* 0.29 / 0.01 = 28.999… のような浮動小数の誤差で同じ値に戻らないよう、商を丸めてから切り捨て・切り上げる
           round the quotient first so float error (0.29 / 0.01 = 28.999…) does not step back to the same value */
        var quotient = Math.round(value / multiple * 1e6) / 1e6;
        if (direction > 0) return Math.round((Math.floor(quotient) + 1) * multiple * 1e6) / 1e6;
        return Math.round((Math.ceil(quotient) - 1) * multiple * 1e6) / 1e6;
    }

    /**
     * 値を下限・上限の範囲に収める
     * @param {number} value - 数値
     * @param {Object} rangeOptions - min / max（どちらも省略可）
     * @returns {number} 範囲に収めた値
     */
    function clampSteppedValue(value, rangeOptions) {
        if (rangeOptions.min !== undefined && value < rangeOptions.min) return rangeOptions.min;
        if (rangeOptions.max !== undefined && value > rangeOptions.max) return rangeOptions.max;
        return value;
    }

    /**
     * 入力欄の文字列を四則演算（+ - * / と括弧）として計算する。eval は使わない。
     * 数値の後ろの単位は UnitValue で欄の単位へ換算する（mm の欄に「1in」→ 25.4、「1p6」は1パイカ6ポイント）。単位のない数値は欄の単位とみなす。
     * 全角の数字・記号と × ÷ は半角に直す
     * @param {string} text - 入力欄の文字列
     * @param {string} [fieldUnit] - 欄の単位（例 " mm"。前後の空白は無視）
     * @returns {number} 欄の単位での計算結果（式として読めない・換算できない単位・0で割ったときは NaN）
     */
    function evaluateArithmetic(text, fieldUnit) {
        var source = String(text)
            .replace(/[！-～]/g, function (ch) { return String.fromCharCode(ch.charCodeAt(0) - 0xFEE0); })
            .replace(/×/g, "*")
            .replace(/÷/g, "/")
            .replace(/[−–—]/g, "-")
            .replace(/\s/g, "");
        if (source === "") return NaN;
        var fieldUnitKey = String(fieldUnit || "").replace(/^\s+|\s+$/g, "").toLowerCase();
        var fieldUnitValue = createStepperUnitValue(1, fieldUnitKey); /* 欄の単位の1単位（換算できない欄は null） / one field unit */
        var position = 0;

        /**
         * 加減算の並び（項 ± 項 …）を読む
         * @returns {number} 値（読めなければ NaN）
         */
        function readSum() {
            var total = readProduct();
            while (position < source.length && (source.charAt(position) === "+" || source.charAt(position) === "-")) {
                var operator = source.charAt(position++);
                var operand = readProduct();
                total = (operator === "+") ? total + operand : total - operand;
            }
            return total;
        }

        /**
         * 乗除算の並び（因子 × 因子 …）を読む
         * @returns {number} 値（読めなければ NaN）
         */
        function readProduct() {
            var total = readFactor();
            while (position < source.length && (source.charAt(position) === "*" || source.charAt(position) === "/")) {
                var operator = source.charAt(position++);
                var operand = readFactor();
                if (operator === "/" && operand === 0) return NaN;
                total = (operator === "*") ? total * operand : total / operand;
            }
            return total;
        }

        /**
         * 符号付きの数値（単位付きなら欄の単位へ換算）か、括弧で囲んだ式を読む
         * @returns {number} 値（読めなければ NaN）
         */
        function readFactor() {
            var ch = source.charAt(position);
            if (ch === "+" || ch === "-") {
                position++;
                var signedValue = readFactor();
                return (ch === "-") ? -signedValue : signedValue;
            }
            if (ch === "(") {
                position++;
                var innerValue = readSum();
                if (source.charAt(position) !== ")") return NaN;
                position++;
                return innerValue;
            }
            var numberMatch = /^(\d+\.?\d*|\.\d+)/.exec(source.substring(position));
            if (!numberMatch) return NaN;
            position += numberMatch[0].length;
            return readUnitSuffix(parseFloat(numberMatch[0]));
        }

        /**
         * 数値の直後の単位を読み、欄の単位へ換算する
         * @param {number} value - 単位の前の数値
         * @returns {number} 欄の単位での値（換算できない単位なら NaN）
         */
        function readUnitSuffix(value) {
            var unitMatch = /^([A-Za-z]+|%|°)/.exec(source.substring(position));
            if (!unitMatch) return value; /* 単位なしは欄の単位 / no unit means the field's unit */
            position += unitMatch[0].length;
            var unitKey = unitMatch[0].toLowerCase();
            if (unitKey === fieldUnitKey) return value;
            var typedValue = createStepperUnitValue(value, unitKey);
            if (!typedValue || !fieldUnitValue) return NaN; /* 知らない単位・単位のない欄 / unknown unit or unitless field */
            var points = typedValue.as("pt");
            /* 「1p6」＝1パイカ6ポイント / pica-point notation */
            if (unitKey === "p") {
                var pointMatch = /^(\d+\.?\d*|\.\d+)/.exec(source.substring(position));
                if (pointMatch) {
                    position += pointMatch[0].length;
                    points += parseFloat(pointMatch[0]);
                }
            }
            return points / fieldUnitValue.as("pt");
        }

        var result = readSum();
        if (position !== source.length || !isFinite(result)) return NaN; /* 読み残しがあれば式として不正 / leftovers mean a malformed expression */
        return result;
    }

    /**
     * 数値と単位から UnitValue を作る。Q・H・p は STEPPER_UNIT_ALIASES で UnitValue の単位に読み替える。
     * %（percent）は基準の長さが無いと換算できないので扱わない
     * @param {number} value - 数値
     * @param {string} unitKey - 単位（小文字。例 "mm"、"inches"、"q"）
     * @returns {UnitValue|null} UnitValue（UnitValue が知らない単位・空・% なら null）
     */
    function createStepperUnitValue(value, unitKey) {
        if (unitKey === "" || unitKey === "%") return null;
        var alias = STEPPER_UNIT_ALIASES[unitKey];
        var unitValue = alias ? new UnitValue(value * alias.amount, alias.unit) : new UnitValue(value, unitKey);
        if (unitValue.type === "?" || unitValue.type === "%") return null; /* 知らない単位は例外にならず "?" になる。"percent" も除く / unknown units become "?" */
        return unitValue;
    }

    /**
     * 値を整数化・下限・上限でそろえ、単位を付けて入力欄に書き込む（直前の正しい値としても控える）
     * @param {EditText} numberInput - 書き込む入力欄
     * @param {number} value - 数値
     * @param {Object} valueOptions - integer / min / max / unit（どれも省略可）
     * @returns {void}
     */
    function writeSteppedValue(numberInput, value, valueOptions) {
        numberInput.text = formatSteppedValue(value, valueOptions);
        numberInput.lastValidText = numberInput.text;
    }

    /**
     * 値を整数化・下限・上限でそろえ、丸めて単位を付けた表示用の文字列にする。
     * 整数化してから下限で止めるので、「整数・下限1」の欄に 0.4 が入っても 1 になる
     * @param {number} value - 数値
     * @param {Object} valueOptions - integer / min / max / unit（どれも省略可）
     * @returns {string} 入力欄に入れる文字列（例 "20 mm"）
     */
    function formatSteppedValue(value, valueOptions) {
        if (valueOptions.integer) value = Math.round(value);
        return formatStepperNumber(clampSteppedValue(value, valueOptions)) + (valueOptions.unit || "");
    }

    /**
     * 小数第2位で丸めた数値を文字列で返す
     * @param {number} value - 数値
     * @returns {string} 表示用の数値文字列
     */
    function formatStepperNumber(value) {
        return String(Math.round(value * 100) / 100);
    }

    // -----------------------------------------
    // ∧∨ボタンの描画 / Drawing
    // -----------------------------------------
    /**
     * 山形（∧／∨）の極小ボタンを作成する。
     * 上下2つを隙間なく積んで1つの枠に見えるよう、枠線は外側の辺だけ描き（上ボタンは上側、下ボタンは下側）、
     * 継ぎ目に線は引かない
     * @param {Group|Panel} parent - 追加先
     * @param {string} direction - "up" または "down"
     * @param {Function} onClickFn - クリック時の処理
     * @returns {Group} ボタンとして使う group
     */
    function makeStepperChevronButton(parent, direction, onClickFn) {
        var buttonWidth = STEPPER_BUTTON_WIDTH;
        var buttonHeight = STEPPER_BUTTON_HEIGHT;
        var isUp = (direction === "up");
        var chevronBox = parent.add("group");
        chevronBox.margins = 0;
        chevronBox.spacing = 0;
        chevronBox.preferredSize = [buttonWidth, buttonHeight];
        chevronBox.minimumSize = [buttonWidth, buttonHeight];
        chevronBox.maximumSize = [buttonWidth, buttonHeight];
        chevronBox.isPressed = false;
        chevronBox.isStepperButton = true; /* redrawSteppersIn() の目印 / marker for redrawSteppersIn() */

        chevronBox.onDraw = function () {
            var boxGraphics = chevronBox.graphics;
            /* 自作描画は自動でディムにならないため、無効なら薄い色で描く。親の無効化は子の enabled に出ないので親も見る
               Custom drawing is not dimmed automatically; the parent's state does not reach the child's enabled */
            var isDimmed = !isStepperEnabledInTree(chevronBox);

            /* 枠線の内側の地（押下中は押下色） / background inside the frame, pressed color while pressed */
            var fillColor = isDimmed ? STEPPER_DIM_FILL_COLOR : (chevronBox.isPressed ? STEPPER_PRESSED_COLOR : STEPPER_FILL_COLOR);
            boxGraphics.newPath();
            boxGraphics.rectPath(1, isUp ? 1 : 0, buttonWidth - 2, buttonHeight - 1);
            boxGraphics.fillPath(boxGraphics.newBrush(boxGraphics.BrushType.SOLID_COLOR, fillColor));

            drawStepperFrame(boxGraphics, buttonWidth, buttonHeight, isUp, isDimmed ? STEPPER_DIM_FRAME_COLOR : STEPPER_FRAME_COLOR);
            drawStepperChevron(boxGraphics, buttonWidth, buttonHeight, isUp, isDimmed ? STEPPER_DIM_CHEVRON_COLOR : STEPPER_CHEVRON_COLOR);
        };

        /**
         * 押下状態を変えて描き直す
         * @param {boolean} isPressed - 押下中なら true
         * @returns {void}
         */
        function repaint(isPressed) {
            if (chevronBox.isPressed === isPressed) return;
            chevronBox.isPressed = isPressed;
            redrawStepperGroup(chevronBox);
        }
        chevronBox.addEventListener("mousedown", function () {
            if (!isStepperEnabledInTree(chevronBox)) return;
            repaint(true);
            if (onClickFn) onClickFn();
        });
        chevronBox.addEventListener("mouseup", function () { repaint(false); });
        /* 押したまま外へ出たときも押下色を残さない / reset when the pointer leaves while pressed */
        chevronBox.addEventListener("mouseout", function () { repaint(false); });
        return chevronBox;
    }

    /**
     * 外側の辺だけの枠を描く（角は丸める）。継ぎ目側は開けておき、上下2つで1つの枠に見せる。
     * ScriptUI は円弧を描けないため、角丸は短い線分で近似する
     * @param {ScriptUIGraphics} boxGraphics - 描画先
     * @param {number} boxWidth - ボタンの幅
     * @param {number} boxHeight - ボタンの高さ
     * @param {boolean} isUp - 上のボタンなら true（上側に枠を描く）
     * @param {number[]} frameColor - [r, g, b, a]
     * @returns {void}
     */
    function drawStepperFrame(boxGraphics, boxWidth, boxHeight, isUp, frameColor) {
        var frameLeft = 0.5;
        var frameRight = boxWidth - 0.5;
        var outerY = isUp ? 0.5 : boxHeight - 0.5;
        var seamY = isUp ? boxHeight : 0;
        var towardSeam = isUp ? 1 : -1; /* 外側の辺から継ぎ目へ向かう向き / direction from the outer edge to the seam */
        var radius = STEPPER_CORNER_RADIUS;
        var arcSteps = 4; /* 角丸1つを何本の線分で近似するか / segments per corner */
        var angle, k;

        boxGraphics.newPath();
        boxGraphics.moveTo(frameLeft, seamY);
        /* 左の角丸 / left corner */
        for (k = 0; k <= arcSteps; k++) {
            angle = (Math.PI / 2) * k / arcSteps;
            boxGraphics.lineTo(frameLeft + radius - radius * Math.cos(angle), outerY + towardSeam * (radius - radius * Math.sin(angle)));
        }
        /* 右の角丸 / right corner */
        for (k = 0; k <= arcSteps; k++) {
            angle = (Math.PI / 2) * k / arcSteps;
            boxGraphics.lineTo(frameRight - radius + radius * Math.sin(angle), outerY + towardSeam * (radius - radius * Math.cos(angle)));
        }
        boxGraphics.lineTo(frameRight, seamY);
        boxGraphics.strokePath(boxGraphics.newPen(boxGraphics.PenType.SOLID_COLOR, frameColor, 1));
    }

    /**
     * 山形（∧／∨）を描く。文字グリフの▲▼は上下で大きさやベースラインが揃わないため、線で描く
     * @param {ScriptUIGraphics} boxGraphics - 描画先
     * @param {number} boxWidth - ボタンの幅
     * @param {number} boxHeight - ボタンの高さ
     * @param {boolean} isUp - ∧なら true、∨なら false
     * @param {number[]} chevronColor - [r, g, b, a]
     * @returns {void}
     */
    function drawStepperChevron(boxGraphics, boxWidth, boxHeight, isUp, chevronColor) {
        var centerX = boxWidth / 2;
        var centerY = isUp ? boxHeight / 2 + 0.5 : boxHeight / 2 - 0.5; /* 継ぎ目から少し離す / nudged away from the seam */
        var halfWidth = 3.6; /* 山形の半幅（高さ1.8に対して開き約127°） / half width of the chevron */
        var tipOffsetY = isUp ? -1.8 : 1.8; /* 頂点の中心からのずれ（上向きは上、下向きは下） */
        boxGraphics.newPath();
        boxGraphics.moveTo(centerX - halfWidth, centerY - tipOffsetY);
        boxGraphics.lineTo(centerX, centerY + tipOffsetY);
        boxGraphics.lineTo(centerX + halfWidth, centerY - tipOffsetY);
        boxGraphics.strokePath(boxGraphics.newPen(boxGraphics.PenType.SOLID_COLOR, chevronColor, 1.2));
    }

    /**
     * 入力欄にフォーカスを移す
     * @param {EditText} numberInput - 対象の入力欄
     * @returns {void}
     */
    function focusNumberInput(numberInput) {
        numberInput.active = false; /* 一度外さないとフォーカスが移らないことがある / reset first or focus may not move */
        numberInput.active = true;
    }

    /**
     * コントロールと、その親をたどってすべて有効かを返す（親の無効化は子の enabled に出ない）
     * @param {Object} control - 対象のコントロール
     * @returns {boolean} すべて有効なら true
     */
    function isStepperEnabledInTree(control) {
        for (var node = control; node; node = node.parent) {
            if (!node.enabled) return false;
        }
        return true;
    }

    /**
     * コンテナ以下にある∧∨ボタンをすべて描き直す。行やパネルの enabled を切り替えたあとに呼ぶ
     * @param {Object} container - 行・グループ・パネルなど
     * @returns {void}
     */
    function redrawSteppersIn(container) {
        if (!container.children) return;
        for (var i = 0; i < container.children.length; i++) {
            var child = container.children[i];
            if (child.isStepperButton) redrawStepperGroup(child);
            else redrawSteppersIn(child);
        }
    }

    /**
     * group の onDraw を呼び直す。group には notify() が無いため、隠して再表示して描き直させる
     * @param {Group} targetGroup - 描き直す group
     * @returns {void}
     */
    function redrawStepperGroup(targetGroup) {
        targetGroup.hide();
        targetGroup.show();
    }

    // ステップボタン（再利用パーツ）ここまで / End of the reusable stepper

    /**
     * 入力欄の直前にある項目名のクリックで、入力欄にフォーカスを移す（addSteppedField() の項目名と同じ挙動。無効の間は移さない）。
     * 単位や「→」に付けないよう、行の先頭にあるか末尾がコロンの statictext だけを項目名とみなす
     * @param {Group} stepperFieldGroup - ∧∨と入力欄をまとめた group（追加した直後で、親の末尾にある）
     * @param {EditText} numberInput - 入力欄
     * @returns {void}
     */
    function focusInputOnPrecedingLabel(stepperFieldGroup, numberInput) {
        var siblings = stepperFieldGroup.parent.children;
        if (siblings.length < 2) return;
        var labelIndex = siblings.length - 2;
        var fieldLabel = siblings[labelIndex];
        if (fieldLabel.type !== "statictext") return;
        if (labelIndex > 0 && !/[:：]\s*$/.test(fieldLabel.text)) return;
        fieldLabel.addEventListener("click", function () {
            if (isStepperEnabledInTree(numberInput)) focusNumberInput(numberInput);
        });
    }

    /**
     * 行に、左に∧∨を付けた数値欄を追加する（↑↓キーも∧∨と同じ処理で増減する）。
     * 増減後の処理は、あとから input.stepOptions.onStep に入れる
     * @param {Group} parentRow - 追加先の行
     * @param {string} initialText - 初期値（単位なし。空なら空のまま）
     * @param {Object} stepOptions - min / max / integer / unit（addStepper() を参照。unit は欄の中に添える単位）
     * @returns {EditText} 追加した入力欄（設定は .stepOptions で参照できる）
     */
    function addStepperInput(parentRow, initialText, stepOptions) {
        /* ∧∨と入力欄は隙間0で突き合わせる / butt the stepper against the field */
        var stepperFieldGroup = parentRow.add("group");
        stepperFieldGroup.orientation = "row";
        stepperFieldGroup.alignChildren = ["left", "center"];
        stepperFieldGroup.spacing = 0;
        stepperFieldGroup.margins = 0;
        var numberInput;
        var stepperGroup = addStepper(stepperFieldGroup, function () { return numberInput; }, stepOptions);
        numberInput = stepperFieldGroup.add("edittext", undefined, "");
        numberInput.stepOptions = stepOptions;
        setFieldValue(numberInput, initialText);
        bindSteppedArrowKeys(numberInput, stepperGroup);
        if (stepOptions.unit) {
            /* 数値だけで確定したら単位を書き足す（onChange より先に呼ばれる）/ append the unit to a bare number on commit (runs before onChange) */
            numberInput.addEventListener("change", function () { appendUnitToPlainNumber(numberInput, stepOptions.unit); });
        }
        focusInputOnPrecedingLabel(stepperFieldGroup, numberInput);
        return numberInput;
    }

    /**
     * 数値欄に、欄の単位を付けて値を書き込む（空文字なら空にする）
     * @param {EditText} numberInput - addStepperInput() で作った入力欄
     * @param {string|number} valueText - 書き込む値（単位なし）
     * @returns {void}
     */
    function setFieldValue(numberInput, valueText) {
        var text = String(valueText);
        numberInput.text = (text === "") ? "" : text + (numberInput.stepOptions.unit || "");
    }

    /**
     * 単位の付いていない数値だけの入力に、欄の単位を書き足す
     * @param {EditText} numberInput - 対象の入力欄
     * @param {string} unitSuffix - 欄の単位（例 " pt"、"%"）
     * @returns {void}
     */
    function appendUnitToPlainNumber(numberInput, unitSuffix) {
        var trimmedText = numberInput.text.replace(/^\s+|\s+$/g, "");
        if (/^[-+]?(\d+\.?\d*|\.\d+)$/.test(trimmedText)) numberInput.text = trimmedText + unitSuffix;
    }

    // =========================================
    // 行揃えアイコンの描画（Keep_TextPosition.jsx 由来）/ Justification icon drawing (ported from Keep_TextPosition.jsx)
    // ライト／ダーク対応は ArtboardNavigatorPalette.jsx の方式 / Light/dark handling follows ArtboardNavigatorPalette.jsx
    // =========================================

    /* 環境設定のUI明るさが明るい側か / Whether the UI brightness preference is on the light side
       uiBrightness は 0（最暗）〜1（最明）。0.5（やや暗め）は暗い側に含めるため 0.5 超で判定 */
    function isLightUI() {
        try {
            return app.preferences.getRealPreference("uiBrightness") > 0.5;
        } catch (e) {
            return false;
        }
    }

    /* テーマ＋アクティブ状態に応じたボタン配色 / Button colors per theme and active state */
    function getJustifyColors(isLight, isActive) {
        if (isLight) {
            return {
                bg: isActive ? [0.40, 0.40, 0.40, 1] : [1, 1, 1, 1],
                border: isActive ? [0.30, 0.30, 0.30, 1] : [0.62, 0.62, 0.62, 1],
                line: isActive ? [1, 1, 1, 1] : [0.25, 0.25, 0.25, 1]
            };
        }
        return {
            bg: isActive ? [0.92, 0.92, 0.92, 1] : [0.30, 0.30, 0.30, 1],
            border: null,
            line: isActive ? [0.16, 0.16, 0.16, 1] : [0.82, 0.82, 0.82, 1]
        };
    }

    /* 行ごとの線幅（アイコン種別ごと）/ Per-line widths for an icon type */
    function getJustifyLineWidths(iconType, longWidth, shortWidth) {
        if (iconType === "justifyAll") return [longWidth, longWidth, longWidth, longWidth];
        if (iconType === "justifyLeft" || iconType === "justifyCenter" || iconType === "justifyRight") {
            return [longWidth, longWidth, longWidth, shortWidth];
        }
        return [longWidth, shortWidth, longWidth, shortWidth];
    }

    /* 行の開始 X（アイコン種別ごとに左／中央／右）/ Line start X per icon type (left/center/right) */
    function getJustifyLineX(iconType, buttonWidth, lineWidth) {
        var margin = 5;
        if (iconType === "right" || iconType === "justifyRight") return buttonWidth - margin - lineWidth;
        if (iconType === "center" || iconType === "justifyCenter") return Math.round((buttonWidth - lineWidth) / 2);
        return margin;
    }

    /* アイコンの罫線を描く / Draw the icon's lines */
    function drawJustifyIconLines(graphics, iconType, buttonWidth, buttonHeight, lineColor) {
        var pen = graphics.newPen(graphics.PenType.SOLID_COLOR, lineColor, 1.2);
        var rowYs = [7, 11, 15, 19];
        var lineWidths = getJustifyLineWidths(iconType, 15, 10);
        for (var i = 0; i < rowYs.length; i++) {
            var lineWidth = lineWidths[i];
            var lineStartX = getJustifyLineX(iconType, buttonWidth, lineWidth);
            graphics.newPath();
            graphics.moveTo(lineStartX, rowYs[i]);
            graphics.lineTo(lineStartX + lineWidth, rowYs[i]);
            graphics.strokePath(pen);
        }
    }

    /* ボタン背景＋アイコンを描く（テーマ＋アクティブ対応）/ Draw the button background + icon (theme + active aware) */
    function drawJustifyIcon(button, isActive, isLight) {
        var graphics = button.graphics;
        var buttonWidth = button.size[0];
        var buttonHeight = button.size[1];
        var colors = getJustifyColors(isLight, isActive);
        try {
            graphics.rectPath(0, 0, buttonWidth, buttonHeight);
            graphics.fillPath(graphics.newBrush(graphics.BrushType.SOLID_COLOR, colors.bg));
            if (colors.border) {
                graphics.rectPath(0, 0, buttonWidth, buttonHeight);
                graphics.strokePath(graphics.newPen(graphics.PenType.SOLID_COLOR, colors.border, 1));
            }
        } catch (e1) {
            try { graphics.drawOSControl(); } catch (e2) { }
        }
        drawJustifyIconLines(graphics, button.iconType, buttonWidth, buttonHeight, colors.line);
    }

    /* 使用フォントタブの中身を構築して参照を返す（DocumentFontListSelectorPalette 由来）
       Build the used-fonts tab contents and return refs (ported from DocumentFontListSelectorPalette) */
    function buildUsedFontsTab(usedFontsTab) {
        var usedFontColumnTitles = [
            getLabel(LABELS.usedFonts.column.count),
            getLabel(LABELS.usedFonts.column.font),
            getLabel(LABELS.usedFonts.column.size),
            getLabel(LABELS.usedFonts.column.leading),
            getLabel(LABELS.usedFonts.column.kern),
            getLabel(LABELS.usedFonts.column.tsume),
            getLabel(LABELS.usedFonts.column.tracking),
            getLabel(LABELS.usedFonts.column.propMetrics)
        ];
        var usedFontColumnWidths = [30, 88, 34, 40, 48, 36, 36, 38]; // 合計350px（パレット幅を抑えるため圧縮）/ Sums to 350px (compressed to keep the palette narrow)

        // 表示モード：フォントのみ／詳細（ドキュメントフォント一覧を兼ねる）/ View mode: font-only / detailed (also serves as the document-font list)
        var viewModeRow = usedFontsTab.add("group");
        viewModeRow.orientation = "row";
        viewModeRow.alignment = ["left", "top"];
        viewModeRow.spacing = 12;
        viewModeRow.margins = [0, 0, 0, 6];
        var fontOnlyRadio = viewModeRow.add("radiobutton", undefined, getLabel(LABELS.usedFonts.view.fontOnly));
        var detailedRadio = viewModeRow.add("radiobutton", undefined, getLabel(LABELS.usedFonts.view.detailed));
        fontOnlyRadio.value = true; // 既定はフォントのみ（フォント適用を手早く）/ Default: font-only (quick font apply)

        // 走査オプションのチェックボックスは「フィルター」パネルとしてタブ最下部に配置（下記）
        // The scan-option checkboxes live in a titled "Filter" panel at the bottom of the tab (see below)

        // 両方の listbox を最初に生成し、orientation="stack" で同じ位置に重ねる。
        // stack のグループ高さは「子の最大値」なので2つ並べても高さは伸びない。
        // かつ表示前生成なので onChange が確実に発火する（表示後に動的生成した listbox は
        // クリック（onChange）が効かない環境があるため、この方式にする）。
        // Both listboxes are created up front and stacked (orientation="stack") in the same cell.
        // A stack group's height is the MAX of its children, so two don't add up — the panel stays compact.
        // Being created before show, their onChange fires reliably (dynamically-created listboxes may not).
        var usedFontListHost = usedFontsTab.add("group");
        usedFontListHost.orientation = "stack";
        usedFontListHost.alignChildren = ["fill", "fill"];
        usedFontListHost.alignment = ["fill", "top"];

        // フォントのみ表示：単一列のフォント名リスト / Font-only view: single-column font list
        var fontOnlyListBox = usedFontListHost.add("listbox", undefined, [], { multiselect: false });
        fontOnlyListBox.preferredSize = [300, 230];

        // 詳細表示：8列の組み合わせリスト / Detailed view: the 8-column combination list
        var comboListBox = usedFontListHost.add("listbox", undefined, [], {
            multiselect: false,
            numberOfColumns: usedFontColumnTitles.length,
            showHeaders: true,
            columnTitles: usedFontColumnTitles,
            columnWidths: usedFontColumnWidths
        });
        comboListBox.preferredSize = [300, 230];

        // 既定はフォントのみ（詳細は隠す）/ Default: font-only (hide the detailed list)
        comboListBox.visible = false;

        // ボタンエリア：右＝更新・条件一致選択（クリック適用は常時ON・UIなし）
        // Button area: right = refresh, select matching (apply-on-click always ON, no UI)
        var usedFontButtonRow = usedFontsTab.add("group");
        usedFontButtonRow.orientation = "row";
        usedFontButtonRow.alignment = ["fill", "top"];
        usedFontButtonRow.margins = [0, 10, 0, 10]; // リストとボタンの間隔 / Gap above the buttons

        var refreshCombosButton = usedFontButtonRow.add("button", undefined, getLabel(LABELS.usedFonts.button.refresh));
        refreshCombosButton.alignment = ["right", "center"];
        var selectMatchingButton = usedFontButtonRow.add("button", undefined, getLabel(LABELS.usedFonts.button.selectMatching));
        selectMatchingButton.alignment = ["right", "center"];
        // 高さは表示後に trimButtonHeight でまとめて詰める / Heights are trimmed together after show via trimButtonHeight

        // フィルター：走査オプションのチェックボックスをまとめてタブ最下部に配置
        // Filter: scan-option checkboxes grouped in a titled panel at the bottom of the tab
        var filterPanel = usedFontsTab.add("panel", undefined, getLabel(LABELS.field.filter));
        setupPanel(filterPanel, 4);
        filterPanel.alignChildren = ["left", "top"];
        filterPanel.alignment = ["fill", "top"];
        filterPanel.margins = [10, 12, 10, 8];

        // 走査オプションのチェックボックス（key で参照を引けるよう object に格納）/ Scan-option checkboxes (kept in an object, addressable by key)
        var checkboxSpecs = [
            { key: "includeLockedCheckbox", label: LABELS.usedFonts.control.includeLocked, initial: true },
            { key: "includeHiddenCheckbox", label: LABELS.usedFonts.control.includeHidden, initial: true },
            { key: "currentArtboardCheckbox", label: LABELS.usedFonts.control.currentArtboardOnly, initial: false }
        ];
        var scanCheckboxes = {};
        for (var cbIndex = 0; cbIndex < checkboxSpecs.length; cbIndex++) {
            var cbSpec = checkboxSpecs[cbIndex];
            var scanCheckbox = filterPanel.add("checkbox", undefined, getLabel(cbSpec.label));
            scanCheckbox.value = cbSpec.initial;
            scanCheckboxes[cbSpec.key] = scanCheckbox;
        }

        return {
            comboListBox: comboListBox,
            fontOnlyListBox: fontOnlyListBox,
            fontOnlyRadio: fontOnlyRadio,
            detailedRadio: detailedRadio,
            includeLockedCheckbox: scanCheckboxes.includeLockedCheckbox,
            includeHiddenCheckbox: scanCheckboxes.includeHiddenCheckbox,
            currentArtboardCheckbox: scanCheckboxes.currentArtboardCheckbox,
            refreshCombosButton: refreshCombosButton,
            selectMatchingButton: selectMatchingButton
        };
    }

    /* 左カラム（ドキュメントフォント／プリセット）を構築して参照を返す
       Build the left column (document fonts / presets) and return refs */
    function buildFontsTab(fontsTab) {
        var fontsColumn = fontsTab.add("group");
        fontsColumn.orientation = "column";
        fontsColumn.alignChildren = ["fill", "top"];
        fontsColumn.spacing = 8;

        // ドキュメントフォント一覧は「使用フォント」タブが兼ねる。プリセットはパネル枠なしで直接配置
        // The document-font list lives in the "Used fonts" tab; presets sit directly with no panel frame

        // 表示モード：フォントのみ／詳細 / View mode: font-only / detailed
        var presetViewRow = fontsColumn.add("group");
        presetViewRow.orientation = "row";
        presetViewRow.alignment = ["left", "top"];
        presetViewRow.spacing = 12;
        var presetFontOnlyRadio = presetViewRow.add("radiobutton", undefined, getLabel(LABELS.usedFonts.view.fontOnly));
        var presetDetailedRadio = presetViewRow.add("radiobutton", undefined, getLabel(LABELS.usedFonts.view.detailed));
        presetFontOnlyRadio.value = true; // 既定はフォントのみ / Default: font-only

        // 2つの listbox を stack で重ねる（フォントのみ＝単一列／詳細＝5列）。高さは最大値なので伸びない
        // Two stacked listboxes (font-only = single column / detailed = 5 columns); stack height = max, so no growth
        var presetListHost = fontsColumn.add("group");
        presetListHost.orientation = "stack";
        presetListHost.alignChildren = ["fill", "fill"];
        presetListHost.alignment = ["fill", "top"];

        // フォントのみ：単一列 / Font-only: single column
        var presetFontOnlyListBox = presetListHost.add("listbox", undefined, [], { multiselect: false });
        presetFontOnlyListBox.preferredSize = [300, 350];
        presetFontOnlyListBox.helpTip = getLabel(LABELS.tip.presets);

        // 詳細：フォント／自動カーニング／文字ツメ／プロポーショナル／トラッキング
        // Detailed: font / auto-kerning / Tsume / proportional / tracking
        var presetDetailedListBox = presetListHost.add("listbox", undefined, [], {
            multiselect: false,
            numberOfColumns: 5,
            showHeaders: true,
            columnTitles: [
                getLabel(LABELS.usedFonts.column.font),
                getLabel(LABELS.usedFonts.column.kern),
                getLabel(LABELS.usedFonts.column.tsume),
                getLabel(LABELS.usedFonts.column.propMetrics),
                getLabel(LABELS.usedFonts.column.tracking)
            ],
            columnWidths: [128, 66, 44, 46, 44]
        });
        presetDetailedListBox.preferredSize = [300, 350];
        presetDetailedListBox.helpTip = getLabel(LABELS.tip.presets);
        presetDetailedListBox.visible = false; // 既定はフォントのみ / Default: font-only

        fillPresetLists(presetFontOnlyListBox, presetDetailedListBox, loadPresets());

        // プリセット操作ボタンを3カラムに（左＝書き出し／中央＝スペーサー／右＝削除・上書き・追加）
        // Preset action buttons in 3 columns (left = export / center = fill spacer / right = delete, overwrite, add)
        var presetButtonRow = fontsColumn.add("group");
        presetButtonRow.orientation = "row";
        presetButtonRow.alignment = ["fill", "top"]; // 幅いっぱいにして左右に振り分ける / Stretch to full width to split left/right
        presetButtonRow.margins = [0, 5, 0, 0]; // ボタン行の上に余白 / Extra top margin above the button row

        // 左：書き出し / Left: export
        var exportPresetButton = presetButtonRow.add("button", undefined, getLabel(LABELS.button.exportPreset));
        exportPresetButton.alignment = ["left", "center"];
        exportPresetButton.helpTip = getLabel(LABELS.tip.exportPreset);

        // 中央：スペーサー（余白を吸って左右に振り分ける）/ Center: spacer (absorbs slack to split left/right)
        var presetButtonSpacer = presetButtonRow.add("statictext", undefined, "");
        presetButtonSpacer.alignment = ["fill", "center"];

        // 右：削除・上書き・追加 / Right: delete, overwrite, add
        var deletePresetButton = presetButtonRow.add("button", undefined, getLabel(LABELS.button.deletePreset));
        deletePresetButton.alignment = ["right", "center"];
        deletePresetButton.helpTip = getLabel(LABELS.tip.deletePreset);

        var overwritePresetButton = presetButtonRow.add("button", undefined, getLabel(LABELS.button.overwritePreset));
        overwritePresetButton.alignment = ["right", "center"];
        overwritePresetButton.helpTip = getLabel(LABELS.tip.overwritePreset);

        var addPresetButton = presetButtonRow.add("button", undefined, getLabel(LABELS.button.addPreset));
        addPresetButton.alignment = ["right", "center"];
        addPresetButton.helpTip = getLabel(LABELS.tip.addPreset);

        // 高さは表示後に trimButtonHeight でまとめて詰める / Heights are trimmed together after show via trimButtonHeight

        return {
            presetFontOnlyListBox: presetFontOnlyListBox,
            presetDetailedListBox: presetDetailedListBox,
            presetFontOnlyRadio: presetFontOnlyRadio,
            presetDetailedRadio: presetDetailedRadio,
            exportPresetButton: exportPresetButton,
            deletePresetButton: deletePresetButton,
            overwritePresetButton: overwritePresetButton,
            addPresetButton: addPresetButton
        };
    }

    /* 最上部の方針（和文／欧文／和欧混在）＋種別（本文／見出し）を構築して参照を返す
       Build the top panels (Policy + Type) and return refs */
    function buildTopPanels(palette) {
        var topRow = palette.add("group");
        topRow.orientation = "row";
        topRow.alignment = "fill";
        topRow.alignChildren = ["fill", "fill"]; // パネルを左右いっぱいに / Panels fill the full width
        topRow.spacing = 8;

        // 方針：和文／欧文／和欧混在（横並び）。文字揃えと行送りの基準をまとめて適用（タイトルなしパネル）
        // Policy: Japanese / Western / Mixed (row). Applies char-alignment + leading-basis together (untitled panel)
        var policyPanel = topRow.add("panel", undefined, "");
        setupPanel(policyPanel, 6);
        policyPanel.margins.top = 7;
        policyPanel.margins.bottom = 5; // 上下のみ指定、左右は setupPanel 既定 / Top/bottom only, left/right stay default
        policyPanel.alignment = ["fill", "fill"]; // 左右いっぱいに / Fill the full width
        policyPanel.alignChildren = ["center", "center"];
        var policyRow = policyPanel.add("group");
        policyRow.orientation = "row";
        policyRow.spacing = 12;
        policyRow.alignment = ["center", "center"];
        var POLICY_PRESETS = [
            // justify・bodyLeadingPercent・bodyMojikumiIndex は本文（種別＝本文）のとき、headingJustify・headingMojikumiIndex は見出しのときに適用
            // justify / bodyLeadingPercent / bodyMojikumiIndex apply for the Body role; headingJustify / headingMojikumiIndex for the Heading role
            { id: "wabun", label: LABELS.policy.wabun, align: "center", leadingType: "top", hyphenation: false, justify: "justifyLeft", headingJustify: "left", bodyLeadingPercent: 150, bodyMojikumiIndex: 6, headingMojikumiIndex: 5, kinsoku: "Soft_v2" },     // 和文：中央 ＋ 仮想ボディの上 ＋ ハイフネーションOFF ＋ 両端揃え（最終行左／見出しは左）＋ 本文は行送り150% ＋ ベタ組み（見出しはツメ組み）＋ 弱い禁則v2
            { id: "latin", label: LABELS.policy.latin, align: "roman", leadingType: "baseline", hyphenation: true, justify: "left", headingJustify: "left", bodyLeadingPercent: 120, bodyMojikumiIndex: -1, headingMojikumiIndex: -1, kinsoku: "None" },  // 欧文：欧文ベースライン ＋ 欧文ベースライン ＋ ハイフネーションON ＋ 左揃え ＋ 本文は行送り120% ＋ 文字組み・禁則なし
            { id: "mixed", label: LABELS.policy.mixed, align: "roman", leadingType: "top", hyphenation: true, justify: "justifyLeft", headingJustify: "left", bodyLeadingPercent: 150, bodyMojikumiIndex: 6, headingMojikumiIndex: 5, kinsoku: "Soft_v2" }        // 和欧混在：欧文ベースライン ＋ 仮想ボディの上 ＋ ハイフネーションON ＋ 両端揃え（最終行左／見出しは左）＋ 本文は行送り150% ＋ ベタ組み（見出しはツメ組み）＋ 弱い禁則v2
        ];
        var policyRadios = [];
        for (var policyIndex = 0; policyIndex < POLICY_PRESETS.length; policyIndex++) {
            var policyRadio = policyRow.add("radiobutton", undefined, getLabel(POLICY_PRESETS[policyIndex].label));
            policyRadio.policyPreset = POLICY_PRESETS[policyIndex];
            policyRadios.push(policyRadio);
        }

        // 種別（本文／見出し）：タイトルなしパネル / Type (Body / Heading): untitled panel
        var rolePanel = topRow.add("panel", undefined, "");
        setupPanel(rolePanel, 6);
        rolePanel.margins.top = 7;
        rolePanel.margins.bottom = 5; // 上下のみ指定、左右は setupPanel 既定 / Top/bottom only, left/right stay default
        rolePanel.alignment = ["fill", "fill"]; // 左右いっぱいに / Fill the full width
        rolePanel.alignChildren = ["center", "center"];
        var roleRow = rolePanel.add("group");
        roleRow.orientation = "row";
        roleRow.spacing = 16;
        roleRow.alignment = ["center", "center"]; // 上下左右中央 / Centered
        var roleBodyRadio = roleRow.add("radiobutton", undefined, getLabel(LABELS.role.body));
        var roleHeadingRadio = roleRow.add("radiobutton", undefined, getLabel(LABELS.role.heading));
        rolePanel.helpTip = getLabel(LABELS.tip.role);
        roleBodyRadio.helpTip = rolePanel.helpTip;
        roleHeadingRadio.helpTip = rolePanel.helpTip;

        return {
            roleBodyRadio: roleBodyRadio,
            roleHeadingRadio: roleHeadingRadio,
            policyRadios: policyRadios
        };
    }

    /* フッター（制御文字トグル／再読み込み／リセット）を構築して参照を返す
       Build the footer (hidden-chars toggle / reload / reset) and return refs */
    function buildFooter(palette) {
        // フッター（左=制御文字／中央=スペーサー／右=リセット・再読み込み）/ Footer: hidden-chars, spacer, reset, reload
        var footerGroup = palette.add("group");
        footerGroup.orientation = "row";
        footerGroup.alignment = "fill";
        var hiddenCharButton = footerGroup.add("button", undefined, getLabel(LABELS.button.hiddenChar));
        hiddenCharButton.alignment = ["left", "center"];
        hiddenCharButton.helpTip = getLabel(LABELS.tip.hiddenChar);
        var footerSpacer = footerGroup.add("statictext", undefined, "");
        footerSpacer.alignment = ["fill", "center"];
        var resetButton = footerGroup.add("button", undefined, getLabel(LABELS.button.reset));
        resetButton.alignment = ["right", "center"];
        resetButton.helpTip = getLabel(LABELS.tip.reset);
        var reloadButton = footerGroup.add("button", undefined, getLabel(LABELS.button.reload));
        reloadButton.alignment = ["right", "center"];
        reloadButton.helpTip = getLabel(LABELS.tip.reload);

        return {
            hiddenCharButton: hiddenCharButton,
            reloadButton: reloadButton,
            resetButton: resetButton
        };
    }

    /* 中央カラム（フォントサイズ／自動カーニング／字間調整／行揃え）を構築して参照を返す
       Build the center column (font size / auto kerning / letter spacing / justification) and return refs */
    function buildCharacterColumn(typeColumnsRow, textUnit, autoKernOptions, justifyOptions) {
        var characterColumn = typeColumnsRow.add("group");
        characterColumn.orientation = "column";
        characterColumn.alignChildren = ["fill", "top"];
        characterColumn.spacing = 8;

        // フォントサイズ（サイズ）は行送りパネルへ移動 / Font size (size) has moved to the leading panel

        var autoKernPanel = characterColumn.add("panel", undefined, getLabel(LABELS.field.autoKern));
        setupPanel(autoKernPanel, 6); // spacing は行送りのラジオと同じ / Same row spacing as the leading radios
        autoKernPanel.alignChildren = ["left", "top"];
        autoKernPanel.helpTip = getLabel(LABELS.tip.autoKern);

        var kernRadios = [];
        for (var i = 0; i < autoKernOptions.length; i++) {
            var kernRadio = autoKernPanel.add("radiobutton", undefined, getLabel(autoKernOptions[i].label));
            kernRadio.value = false;
            kernRadio.index = i;
            kernRadios.push(kernRadio);
        }

        // 字間調整（文字ツメ・トラッキング）：各行「ラベル：［入力］」＋スライダー
        // Letter spacing (Tsume / Tracking): each row "label: [input]" then a slider
        var spacingPanel = characterColumn.add("panel", undefined, getLabel(LABELS.field.spacingAdjust));
        setupPanel(spacingPanel, 6);

        // 一番上：プロポーショナルメトリクス / Top: Proportional metrics checkbox
        var proportionalMetricsCheck = spacingPanel.add("checkbox", undefined, getLabel(LABELS.field.proportionalMetrics));
        proportionalMetricsCheck.value = false;

        var tsumeRow = spacingPanel.add("group");
        setupGroup(tsumeRow, "row");
        tsumeRow.add("statictext", undefined, labelText(LABELS.field.tsume));
        var tsumeInput = addStepperInput(tsumeRow, "0", { min: 0, max: 100, integer: true, unit: "%" });
        tsumeInput.characters = 4;
        tsumeInput.helpTip = getLabel(LABELS.tip.tsume);
        var tsumeSlider = spacingPanel.add("slider", undefined, 0, 0, 100);

        // 文字ツメとトラッキングの間に少し余白 / A little gap between Tsume and Tracking
        var spacingGap = spacingPanel.add("group");
        spacingGap.preferredSize.height = 1;

        var trackingRow = spacingPanel.add("group");
        setupGroup(trackingRow, "row");
        trackingRow.add("statictext", undefined, labelText(LABELS.field.tracking));
        var trackingInput = addStepperInput(trackingRow, "0", { min: -100, max: 500, integer: true });
        trackingInput.characters = 3;
        trackingInput.helpTip = getLabel(LABELS.tip.tracking);
        var trackingSlider = spacingPanel.add("slider", undefined, 0, -100, 500);

        // 文字揃え（縦方向）：行揃えと位置を入れ替えて中央カラムの末尾に配置
        // Char alignment (vertical): swapped with justification, placed at the end of the center column
        var alignPanel = characterColumn.add("panel", undefined, getLabel(LABELS.field.align));
        setupPanel(alignPanel, 6);
        alignPanel.alignChildren = ["left", "top"];
        alignPanel.helpTip = getLabel(LABELS.tip.align);

        // 3つのラジオ：欧文ベースライン／中央／その他（その他は残りをポップアップで指定）
        // Three radios: Roman baseline / Center / Other (Other picks the rest from a popup)
        // ラジオは alignId で排他制御（親が異なるため selectAlignRadio で手動切替）
        var alignRadios = [];
        var alignRomanRadio = alignPanel.add("radiobutton", undefined, getLabel(LABELS.align.roman));
        alignRomanRadio.alignId = "roman";
        alignRadios.push(alignRomanRadio);
        var alignCenterRadio = alignPanel.add("radiobutton", undefined, getLabel(LABELS.align.center));
        alignCenterRadio.alignId = "center";
        alignRadios.push(alignCenterRadio);

        // 「その他」ラジオの右にポップアップ / Popup to the right of the "Other" radio
        var alignOtherRow = alignPanel.add("group");
        alignOtherRow.orientation = "row";
        alignOtherRow.alignChildren = ["left", "center"];
        alignOtherRow.spacing = 6;
        var alignOtherRadio = alignOtherRow.add("radiobutton", undefined, ""); // ラベルなし（右のポップアップで内容を示す）/ No label (the popup shows the choice)
        alignOtherRadio.alignId = "other";
        alignRadios.push(alignOtherRadio);
        var alignOtherOptions = [
            { id: "top", label: LABELS.align.top },
            { id: "bottom", label: LABELS.align.bottom },
            { id: "icftop", label: LABELS.align.icfTop },
            { id: "icfbottom", label: LABELS.align.icfBottom }
        ];
        var alignOtherDropdown = alignOtherRow.add("dropdownlist", undefined, []);
        for (var optionIndex = 0; optionIndex < alignOtherOptions.length; optionIndex++) {
            alignOtherDropdown.add("item", getLabel(alignOtherOptions[optionIndex].label));
        }
        alignOtherDropdown.selection = 0;
        alignOtherDropdown.preferredSize.width = 124; // 少し狭く / A bit narrower
        alignRomanRadio.value = true;

        return {
            kernRadios: kernRadios,
            proportionalMetricsCheck: proportionalMetricsCheck,
            tsumeInput: tsumeInput,
            tsumeSlider: tsumeSlider,
            trackingInput: trackingInput,
            trackingSlider: trackingSlider,
            alignRadios: alignRadios,
            alignRomanRadio: alignRomanRadio,
            alignCenterRadio: alignCenterRadio,
            alignOtherRadio: alignOtherRadio,
            alignOtherDropdown: alignOtherDropdown,
            alignOtherOptions: alignOtherOptions
        };
    }

    /* 右カラム（文字揃え／行送り／行送りの基準／禁則／文字組みアキ量）を構築して参照を返す
       Build the right column (char alignment / leading / basis / kinsoku / mojikumi) and return refs */
    function buildParagraphColumn(typeColumnsRow, leadingBasisChoices, justifyOptions) {
        var paragraphColumn = typeColumnsRow.add("group");
        paragraphColumn.orientation = "column";
        paragraphColumn.alignChildren = ["fill", "top"];
        paragraphColumn.spacing = 8;

        // 行送り：常に自動行送り。サイズ・実質（pt）・行送り（%）の3入力を1パネルに。右カラムの先頭に配置
        // Leading: always auto. Size, effective (pt), and leading (%) in one panel, at the top of the right column
        var leadingPanel = paragraphColumn.add("panel", undefined, getLabel(LABELS.field.sizeAndLeading));
        setupPanel(leadingPanel, 6);
        leadingPanel.alignChildren = "left";
        leadingPanel.helpTip = getLabel(LABELS.tip.leading);

        var leadColon = uiLang === "ja" ? " : " : ": ";
        var leadTextUnit = getUnitInfo("text/units");

        // フォントサイズ（フォントサイズパネルから移動）/ Font size (moved from the font-size panel)
        var leadSizeRow = leadingPanel.add("group");
        leadSizeRow.orientation = "row";
        leadSizeRow.alignChildren = ["left", "center"];
        var leadSizeLabel = leadSizeRow.add("statictext", undefined, getLabel(LABELS.field.fontSize) + leadColon);
        var fontSizeInput = addStepperInput(leadSizeRow, "", { min: 0, unit: " " + leadTextUnit.label });
        fontSizeInput.characters = 5;
        leadSizeLabel.helpTip = getLabel(LABELS.tip.fontSize); fontSizeInput.helpTip = leadSizeLabel.helpTip;

        // 実質（フォントサイズ×行送り% の結果。ここに入力すると % を逆算）/ Effective leading (size × %); entering a value back-calculates the %
        var leadEffectiveRow = leadingPanel.add("group");
        leadEffectiveRow.orientation = "row";
        leadEffectiveRow.alignChildren = ["left", "center"];
        var leadEffectiveLabel = leadEffectiveRow.add("statictext", undefined, getLabel(LABELS.field.leading) + leadColon);
        // 実質は行送りなので Q/H 環境では単位「H」/ Effective is a leading value, so use "H" when the unit is Q/H
        var leadingEffectiveInput = addStepperInput(leadEffectiveRow, "", { min: 0, unit: " " + getLeadingUnitLabel(leadTextUnit.code) });
        leadingEffectiveInput.characters = 5;
        leadEffectiveLabel.helpTip = getLabel(LABELS.tip.leadingEffective); leadingEffectiveInput.helpTip = leadEffectiveLabel.helpTip;

        // 行送り（自動行送り量 %）/ Leading (auto-leading amount %)
        var leadPercentRow = leadingPanel.add("group");
        leadPercentRow.orientation = "row";
        leadPercentRow.alignChildren = ["left", "center"];
        var leadPercentLabel = leadPercentRow.add("statictext", undefined, getLabel(LABELS.field.leading) + leadColon);
        var leadingPercentInput = addStepperInput(leadPercentRow, "", { min: 0, unit: "%" });
        leadingPercentInput.characters = 4;
        leadPercentLabel.helpTip = getLabel(LABELS.tip.leading); leadingPercentInput.helpTip = leadPercentLabel.helpTip;

        // ラベル幅を揃える / Unify label widths
        var leadLabelWidth = 65;
        leadSizeLabel.preferredSize.width = leadLabelWidth;
        leadEffectiveLabel.preferredSize.width = leadLabelWidth;
        leadPercentLabel.preferredSize.width = leadLabelWidth;

        // 行送りの基準：独立したタイトル付きパネル（行送りパネルの外）/ Leading basis: its own titled panel (outside the leading panel)
        var leadingBasisPanel = paragraphColumn.add("panel", undefined, getLabel(LABELS.field.leadingType));
        setupPanel(leadingBasisPanel, 6);
        leadingBasisPanel.alignChildren = "left";
        leadingBasisPanel.helpTip = getLabel(LABELS.tip.leadingType);
        var leadingBasisRadios = [];
        for (var basisIndex = 0; basisIndex < leadingBasisChoices.length; basisIndex++) {
            var leadingBasisRadio = leadingBasisPanel.add("radiobutton", undefined, leadingBasisChoices[basisIndex].label);
            leadingBasisRadio.index = basisIndex;
            leadingBasisRadios.push(leadingBasisRadio);
        }
        leadingBasisRadios[0].value = true;

        // 行揃え：行送り・基準の下に配置 / Justification: placed below leading and its basis
        var justifyPanel = paragraphColumn.add("panel", undefined, getLabel(LABELS.field.justify));
        setupPanel(justifyPanel, 5);
        justifyPanel.orientation = "row";
        justifyPanel.alignChildren = ["center", "center"]; // ボタン列を左右中央に / Center the button row horizontally
        justifyPanel.helpTip = getLabel(LABELS.tip.justify);

        // アクティブな行揃え id と UI 明暗を共有（onDraw のクロージャから参照）/ Shared active id + theme (read by onDraw closures)
        var justifyState = { activeId: "", isLight: isLightUI() };
        var justifyButtons = [];
        for (var buttonIndex = 0; buttonIndex < justifyOptions.length; buttonIndex++) {
            var justifyOption = justifyOptions[buttonIndex];
            var justifyButton = justifyPanel.add("button", undefined, "");
            justifyButton.helpTip = getLabel(justifyOption.label);
            justifyButton.preferredSize = [26, 26];
            justifyButton.minimumSize = [26, 26];
            justifyButton.maximumSize = [26, 26];
            justifyButton.justifyId = justifyOption.id;
            justifyButton.iconType = justifyOption.icon;
            justifyButton.onDraw = function () { drawJustifyIcon(this, this.justifyId === justifyState.activeId, justifyState.isLight); };
            justifyButtons.push(justifyButton);
        }

        // 日本語組版：禁則＋文字組みアキ量設定を1枚にまとめ、各見出しはラベルとして表示
        // Japanese typography: Kinsoku + Mojikumi in one panel; each sub-heading is shown as a label
        var jpPanel = paragraphColumn.add("panel", undefined, getLabel(LABELS.field.jpComposition));
        setupPanel(jpPanel, 5);
        jpPanel.alignChildren = "fill";

        // 禁則（ラベル＋ポップアップ）/ Kinsoku (label + popup)
        var kinsokuHeading = jpPanel.add("statictext", undefined, labelText(LABELS.field.kinsoku));
        kinsokuHeading.helpTip = getLabel(LABELS.tip.kinsoku);
        var kinsokuItems = [];
        for (var kinsokuChoiceIndex = 0; kinsokuChoiceIndex < KINSOKU_CHOICES.length; kinsokuChoiceIndex++) kinsokuItems.push(KINSOKU_CHOICES[kinsokuChoiceIndex].label);
        var kinsokuDropdown = jpPanel.add("dropdownlist", undefined, kinsokuItems);
        kinsokuDropdown.selection = 0;
        kinsokuDropdown.helpTip = kinsokuHeading.helpTip;
        kinsokuDropdown.alignment = "left"; // fill を無効化して幅を指定 / Override fill so the explicit width applies
        kinsokuDropdown.preferredSize.width = 150;

        // 禁則と文字組みの間の余白 / Gap between the two groups
        var jpGap = jpPanel.add("group");
        jpGap.preferredSize.height = 4;

        // 文字組みアキ量設定（ラベル＋ポップアップ）/ Mojikumi spacing set (label + popup)
        var mojikumiHeading = jpPanel.add("statictext", undefined, labelText(LABELS.field.mojikumi));
        mojikumiHeading.helpTip = getLabel(LABELS.tip.mojikumi);
        var mojikumiItems = [];
        for (var mojikumiChoiceIndex = 0; mojikumiChoiceIndex < MOJIKUMI_CHOICES.length; mojikumiChoiceIndex++) mojikumiItems.push(MOJIKUMI_CHOICES[mojikumiChoiceIndex].label);
        var mojikumiDropdown = jpPanel.add("dropdownlist", undefined, mojikumiItems);
        mojikumiDropdown.selection = 0;
        mojikumiDropdown.helpTip = mojikumiHeading.helpTip;
        mojikumiDropdown.alignment = "left"; // fill を無効化して幅を指定 / Override fill so the explicit width applies
        mojikumiDropdown.preferredSize.width = 150;

        return {
            justifyButtons: justifyButtons,
            justifyState: justifyState,
            fontSizeInput: fontSizeInput,
            leadingEffectiveInput: leadingEffectiveInput,
            leadingPercentInput: leadingPercentInput,
            leadingBasisRadios: leadingBasisRadios,
            kinsokuDropdown: kinsokuDropdown,
            mojikumiDropdown: mojikumiDropdown
        };
    }

    /* 「フォントサイズ」タブ：サイズ・比率・実質をまとめた独立パネル（中央カラムから複製）
       "Font Size" tab: a standalone panel with size / scale / effective (duplicated from the center column) */
    function buildFontSizeTab(fontSizeTab, textUnit) {
        // サイズタブを左右2カラムに（左：フォントサイズ／右：タイプスケール）
        // Two columns for the Size tab (left: font size, right: type scale)
        var columnsRow = fontSizeTab.add("group");
        columnsRow.orientation = "row";
        columnsRow.alignChildren = ["fill", "top"];
        columnsRow.spacing = 12;

        // ---- 左カラム：フォントサイズ / Left column: font size ----
        var fontSizeColumn = columnsRow.add("group");
        fontSizeColumn.orientation = "column";
        fontSizeColumn.alignChildren = ["fill", "top"];
        fontSizeColumn.spacing = 8;

        var fontSizePanel = fontSizeColumn.add("panel", undefined, getLabel(LABELS.field.fontSizePanel));
        setupPanel(fontSizePanel, 6);
        fontSizePanel.alignChildren = ["left", "top"];
        fontSizePanel.alignment = ["left", "top"]; // タブ幅いっぱいに広げず、内容幅に合わせる / Size to content instead of filling the tab width

        var sizeColon = uiLang === "ja" ? " : " : ": ";

        var fsSizeRow = fontSizePanel.add("group");
        fsSizeRow.orientation = "row";
        fsSizeRow.alignChildren = ["left", "center"];
        var fsSizeLabel = fsSizeRow.add("statictext", undefined, getLabel(LABELS.field.fontSize) + sizeColon);
        var fontSizeInput = addStepperInput(fsSizeRow, "", { min: 0, unit: " " + textUnit.label });
        fontSizeInput.characters = 5;

        var fsScaleRow = fontSizePanel.add("group");
        fsScaleRow.orientation = "row";
        fsScaleRow.alignChildren = ["left", "center"];
        var fsScaleLabel = fsScaleRow.add("statictext", undefined, getLabel(LABELS.field.scale) + sizeColon);
        var scaleInput = addStepperInput(fsScaleRow, "100", { min: 0, unit: "%" });
        scaleInput.characters = 5;

        var fsApparentRow = fontSizePanel.add("group");
        fsApparentRow.orientation = "row";
        fsApparentRow.alignChildren = ["left", "center"];
        fsApparentRow.margins = [0, 5, 0, 0]; // 「実質」行の上に余白 / Extra top margin above the "Effective" row
        var fsApparentLabel = fsApparentRow.add("statictext", undefined, getLabel(LABELS.field.apparent) + sizeColon);
        var apparentValueLabel = fsApparentRow.add("statictext", undefined, "--");
        apparentValueLabel.characters = 5;
        var fsApparentUnit = fsApparentRow.add("statictext", undefined, textUnit.label);

        fsSizeLabel.helpTip = getLabel(LABELS.tip.fontSize); fontSizeInput.helpTip = fsSizeLabel.helpTip;
        fsScaleLabel.helpTip = getLabel(LABELS.tip.scale); scaleInput.helpTip = fsScaleLabel.helpTip;
        fsApparentLabel.helpTip = getLabel(LABELS.tip.apparent); apparentValueLabel.helpTip = fsApparentLabel.helpTip;

        // ラベル幅を揃える / Unify label widths
        var fsLabelWidth = 55;
        fsSizeLabel.preferredSize.width = fsLabelWidth;
        fsScaleLabel.preferredSize.width = fsLabelWidth;
        fsApparentLabel.preferredSize.width = fsLabelWidth;

        // ボタン上に 5px のマージン / A 5px margin above the button
        var apparentButtonGap = fontSizePanel.add("group");
        apparentButtonGap.preferredSize.height = 5;

        // 実サイズ↔見かけ：サイズ×比率を実サイズへ焼き込み比率100%に／もう一度で復元
        // Actual ↔ Apparent: bake size × scale into the actual size at 100%; press again to restore
        var apparentToggleButton = fontSizePanel.add("button", undefined, getLabel(LABELS.button.toApparent));
        apparentToggleButton.helpTip = getLabel(LABELS.tip.toApparent);
        apparentToggleButton.alignment = "right";
        apparentToggleButton.preferredSize.width = 150;
        // 高さは trimButtonHeight でレイアウト確定後に詰める / Height is trimmed after layout via trimButtonHeight

        // ---- 右カラム：タイプスケール（TypeScaler 由来）/ Right column: type scale (from TypeScaler) ----
        var typeScaleColumn = columnsRow.add("group");
        typeScaleColumn.orientation = "column";
        typeScaleColumn.alignChildren = ["fill", "top"];
        typeScaleColumn.spacing = 8;

        var typeScalePanel = typeScaleColumn.add("panel", undefined, getLabel(LABELS.field.typeScale));
        setupPanel(typeScalePanel, 6);
        typeScalePanel.alignChildren = ["left", "top"];
        typeScalePanel.helpTip = getLabel(LABELS.tip.typeScale);

        // 基準サイズ入力 / Base size input
        var tsBaseRow = typeScalePanel.add("group");
        tsBaseRow.orientation = "row";
        tsBaseRow.alignChildren = ["left", "center"];
        var tsBaseLabel = tsBaseRow.add("statictext", undefined, getLabel(LABELS.field.typeScaleBase) + sizeColon);
        var typeScaleBaseInput = addStepperInput(tsBaseRow, "", { min: 0, unit: " " + textUnit.label });
        typeScaleBaseInput.characters = 5;
        tsBaseLabel.helpTip = getLabel(LABELS.tip.typeScaleBase); typeScaleBaseInput.helpTip = tsBaseLabel.helpTip;

        // 倍率ポップアップ / Ratio popup
        var ratioLabels = [];
        for (var ri = 0; ri < TYPE_SCALE_RATIOS.length; ri++) ratioLabels.push(TYPE_SCALE_RATIOS[ri].label);
        var typeScaleRatioPopup = typeScalePanel.add("dropdownlist", undefined, ratioLabels);
        typeScaleRatioPopup.selection = TYPE_SCALE_DEFAULT_RATIO_INDEX;
        typeScaleRatioPopup.helpTip = getLabel(LABELS.tip.typeScaleRatio);
        typeScaleRatioPopup.preferredSize.width = 180;

        // サイズ一覧（段番号＋サイズの2カラム）/ Size list (step number + size, 2 columns)
        var typeScaleList = typeScalePanel.add("listbox", undefined, [], {
            multiselect: false,
            numberOfColumns: 2,
            showHeaders: true,
            columnTitles: [getLabel(LABELS.field.typeScaleStep), getLabel(LABELS.field.fontSize)],
            columnWidths: [40, 130]
        });
        typeScaleList.preferredSize = [180, 160];

        // 基準・倍率からサイズ一覧を再生成 / Rebuild the size list from base + ratio
        function rebuildTypeScaleList() {
            typeScaleList.removeAll();
            var baseSize = parseFloat(typeScaleBaseInput.text);
            if (isNaN(baseSize) || baseSize <= 0) return;
            var ratio = TYPE_SCALE_RATIOS[typeScaleRatioPopup.selection ? typeScaleRatioPopup.selection.index : TYPE_SCALE_DEFAULT_RATIO_INDEX].value;
            var sizes = generateTypeScaleSizes(baseSize, ratio);
            for (var j = 0; j < sizes.length; j++) {
                var item = typeScaleList.add("item", String(j - 2)); // index 2 が基準（段番号 0）/ index 2 is the base (step 0)
                item.subItems[0].text = sizes[j] + " " + textUnit.label;
            }
        }
        typeScaleBaseInput.onChanging = rebuildTypeScaleList;
        typeScaleRatioPopup.onChange = rebuildTypeScaleList;
        typeScaleBaseInput.stepOptions.onStep = rebuildTypeScaleList;

        return {
            fontSizeInput: fontSizeInput,
            scaleInput: scaleInput,
            apparentValueLabel: apparentValueLabel,
            fsApparentLabel: fsApparentLabel,
            fsApparentUnit: fsApparentUnit,
            apparentToggleButton: apparentToggleButton,
            typeScaleBaseInput: typeScaleBaseInput,
            typeScaleRatioPopup: typeScaleRatioPopup,
            typeScaleList: typeScaleList,
            rebuildTypeScaleList: rebuildTypeScaleList
        };
    }

    /* パレットを組み立てて参照を返す（イベント未接続）/ Build the palette and return references (events not wired yet) */
    function createPaletteUI(autoKernOptions, alignOptions, justifyOptions) {
        var palette = new Window("palette", getLabel(LABELS.dialog.title) + " " + SCRIPT_VERSION);
        setupWindow(palette);

        var textUnit = getUnitInfo("text/units");
        var leadingBasisChoices = getLeadingTypeChoices();

        // ===== 上部：種別（タイトルなし）＋方針を左右に並べて構築 / Top: Type + Policy panels side by side =====
        var topPanelsUI = buildTopPanels(palette);

        // ===== レイアウト：タブ1（ドキュメントフォント）／タブ2（カーニング・ツメ・文字揃え・行送りなど）
        //       Layout: tab 1 (document fonts) / tab 2 (kerning, tsume, alignment, leading, ...) =====
        var mainTabs = palette.add("tabbedpanel");
        mainTabs.alignChildren = ["fill", "top"];

        // タブ1：文字組み・タブ2：フォントサイズ・タブ3：フォント／プリセット・タブ4：使用フォント（生成順＝表示順）
        // Tab 1: type settings, Tab 2: font size, Tab 3: fonts/presets, Tab 4: used fonts (creation order = strip order)
        var typeTab = addTab(mainTabs, LABELS.tab.type);
        var fontSizeTab = addTab(mainTabs, LABELS.tab.fontSize);
        var fontsTab = addTab(mainTabs, LABELS.tab.fonts);
        var usedFontsTab = addTab(mainTabs, LABELS.tab.usedFonts);
        var styleTab = null; // 仮に OFF（addTab(mainTabs, LABELS.tab.style) で有効化）/ Temporarily OFF

        // フォントサイズタブの中身を構築 / Build the font-size tab contents
        var fontSizeTabUI = buildFontSizeTab(fontSizeTab, textUnit);

        // 使用フォントタブの中身を構築 / Build the used-fonts tab contents
        var usedFontsUI = buildUsedFontsTab(usedFontsTab);

        var typeColumnsRow = typeTab.add("group");
        typeColumnsRow.orientation = "row";
        typeColumnsRow.alignChildren = ["fill", "top"];
        typeColumnsRow.spacing = 12;

        mainTabs.selection = typeTab; // 起動時は文字組みタブを開く / Open the Type tab on launch

        // ---- 左カラム：ドキュメントフォント／プリセットを構築 / Left column: document fonts + presets ----
        var fontsTabUI = buildFontsTab(fontsTab);

        // ---- 中央カラム：フォントサイズ（サイズのみ）・自動カーニング・文字ツメ・文字揃えを構築 / Center column ----
        var characterColumnUI = buildCharacterColumn(typeColumnsRow, textUnit, autoKernOptions, justifyOptions);

        // ---- 右カラム：行揃え・行送り・行送りの基準・禁則・文字組みアキ量設定を構築 / Right column ----
        var paragraphColumnUI = buildParagraphColumn(typeColumnsRow, leadingBasisChoices, justifyOptions);

        // フッターを構築 / Build the footer
        var footerUI = buildFooter(palette);

        return {
            palette: palette,
            mainTabs: mainTabs,
            typeTab: typeTab,
            usedFontsTab: usedFontsTab,
            styleTab: styleTab,
            comboListBox: usedFontsUI.comboListBox,
            fontOnlyListBox: usedFontsUI.fontOnlyListBox,
            fontOnlyRadio: usedFontsUI.fontOnlyRadio,
            detailedRadio: usedFontsUI.detailedRadio,
            includeLockedCheckbox: usedFontsUI.includeLockedCheckbox,
            includeHiddenCheckbox: usedFontsUI.includeHiddenCheckbox,
            currentArtboardCheckbox: usedFontsUI.currentArtboardCheckbox,
            refreshCombosButton: usedFontsUI.refreshCombosButton,
            selectMatchingButton: usedFontsUI.selectMatchingButton,
            presetFontOnlyListBox: fontsTabUI.presetFontOnlyListBox,
            presetDetailedListBox: fontsTabUI.presetDetailedListBox,
            presetFontOnlyRadio: fontsTabUI.presetFontOnlyRadio,
            presetDetailedRadio: fontsTabUI.presetDetailedRadio,
            exportPresetButton: fontsTabUI.exportPresetButton,
            addPresetButton: fontsTabUI.addPresetButton,
            overwritePresetButton: fontsTabUI.overwritePresetButton,
            deletePresetButton: fontsTabUI.deletePresetButton,
            // 文字組みタブのサイズ欄と「フォントサイズ」タブのサイズ欄を同期して扱う / Both size fields (Type tab + Font Size tab) are kept in sync
            fontSizeInputs: [paragraphColumnUI.fontSizeInput, fontSizeTabUI.fontSizeInput],
            scaleInput: fontSizeTabUI.scaleInput,
            apparentValueLabel: fontSizeTabUI.apparentValueLabel,
            fsApparentLabel: fontSizeTabUI.fsApparentLabel,
            fsApparentUnit: fontSizeTabUI.fsApparentUnit,
            apparentToggleButton: fontSizeTabUI.apparentToggleButton,
            // タイプスケール（サイズタブ右カラム）/ Type scale (right column of the Size tab)
            typeScaleBaseInput: fontSizeTabUI.typeScaleBaseInput,
            typeScaleRatioPopup: fontSizeTabUI.typeScaleRatioPopup,
            typeScaleList: fontSizeTabUI.typeScaleList,
            rebuildTypeScaleList: fontSizeTabUI.rebuildTypeScaleList,
            roleBodyRadio: topPanelsUI.roleBodyRadio,
            roleHeadingRadio: topPanelsUI.roleHeadingRadio,
            policyRadios: topPanelsUI.policyRadios,
            alignRadios: characterColumnUI.alignRadios,
            alignRomanRadio: characterColumnUI.alignRomanRadio,
            alignCenterRadio: characterColumnUI.alignCenterRadio,
            alignOtherRadio: characterColumnUI.alignOtherRadio,
            alignOtherDropdown: characterColumnUI.alignOtherDropdown,
            alignOtherOptions: characterColumnUI.alignOtherOptions,
            justifyButtons: paragraphColumnUI.justifyButtons,
            justifyState: paragraphColumnUI.justifyState,
            alignOptions: alignOptions,
            justifyOptions: justifyOptions,
            kernRadios: characterColumnUI.kernRadios,
            proportionalMetricsCheck: characterColumnUI.proportionalMetricsCheck,
            tsumeSlider: characterColumnUI.tsumeSlider,
            tsumeInput: characterColumnUI.tsumeInput,
            trackingSlider: characterColumnUI.trackingSlider,
            trackingInput: characterColumnUI.trackingInput,
            resetButton: footerUI.resetButton,
            reloadButton: footerUI.reloadButton,
            hiddenCharButton: footerUI.hiddenCharButton,
            textUnit: textUnit,
            leadingBasisChoices: leadingBasisChoices,
            leadingEffectiveInput: paragraphColumnUI.leadingEffectiveInput,
            leadingPercentInput: paragraphColumnUI.leadingPercentInput,
            leadingBasisRadios: paragraphColumnUI.leadingBasisRadios,
            mojikumiDropdown: paragraphColumnUI.mojikumiDropdown,
            mojikumiChoices: MOJIKUMI_CHOICES.slice(0), /* カスタムのセットを後ろに足すので複製 / Copied because custom sets are appended */
            kinsokuDropdown: paragraphColumnUI.kinsokuDropdown,
            kinsokuChoices: KINSOKU_CHOICES
        };
    }

    /* ラジオ配列の排他選択（別コンテナのため手動）/ Exclusive selection across radios in separate containers */
    function selectExclusiveRadio(radios, index) {
        for (var i = 0; i < radios.length; i++) radios[i].value = (i === index);
    }

    /* 現在選択中のラジオ index を返す（未選択は -1）/ Index of the currently selected radio (-1 if none) */
    function selectedRadioIndex(radios) {
        for (var i = 0; i < radios.length; i++) if (radios[i].value) return i;
        return -1;
    }

    /* "count|isAuto|leadingPt|basePt|autoAmount|leadingTypeId|paraCount|alignmentId|
        fontFamily|fontStyle|fontSizePt|kernId|justifyId|hScale|mojikumiId|kinsokuId|customMojikumiNames" を分解
       Parse the encoded leading state string */
    function parseLeadingState(rest) {
        var fields = String(rest || "").split("|");
        function toNumber(text) { var parsed = parseFloat(text); return isNaN(parsed) ? NaN : parsed; }
        return {
            count: parseInt(fields[0], 10) || 0,
            isAuto: fields[1] === "1",
            leadingPt: toNumber(fields[2]),
            baseFontSizePt: toNumber(fields[3]),
            autoAmount: toNumber(fields[4]),
            leadingTypeId: fields[5] || "",
            paragraphCount: parseInt(fields[6], 10) || 0,
            alignmentId: fields[7] || "",
            fontFamily: decodeURIComponent(fields[8] || ""),
            fontStyle: decodeURIComponent(fields[9] || ""),
            fontSizePt: toNumber(fields[10]),
            kernId: fields[11] || "",
            justifyId: fields[12] || "",
            hScale: toNumber(fields[13]),
            mojikumiId: isNaN(parseInt(fields[14], 10)) ? -2 : parseInt(fields[14], 10),
            kinsokuId: fields[15] || "None",
            customMojikumiNames: fields[16] ? decodeURIComponent(fields[16]).split("\n") : []
        };
    }

    /* パレットにイベントを接続 / Wire palette events */
    function bindPaletteEvents(ui, autoKernOptions, alignOptions, justifyOptions) {
        // BridgeTalk は非同期なので、連打による委譲の重複を抑止 / Guard against overlapping async delegations
        var workerBusy = false;
        var textUnit = ui.textUnit;
        var suppressUiEvents = false; // 反映中のドロップダウン onChange を抑止 / Suppress dropdown onChange while reflecting state

        /* 重要処理の失敗をダイアログで通知（握りつぶさず、どのアクションで何が起きたか見えるように）
           Surface an important-op failure via an alert (don't swallow it; show which action failed and why) */
        function showWorkerError(actionId, payload) {
            var detail = payload ? (": " + String(payload)) : "";
            try { alert("⚠ " + getLabel(LABELS.msg.applyError) + " [" + actionId + "]" + detail); } catch (e) { }
        }

        // 委譲する共通処理（連打抑止）/ Delegate an apply action (guarded against overlap)
        function runApply(actionId, params, onDone) {
            if (workerBusy) return;
            workerBusy = true;
            runWorker(actionId, params, function (status, payload) {
                workerBusy = false;
                // BridgeTalk エラーや dispatch の "ERR:<msg>" はここで可視化 / BridgeTalk errors and dispatch "ERR:<msg>" become visible here
                if (status === "error") showWorkerError(actionId, payload);
                if (onDone) onDone(status, payload);
            });
        }

        // ---- プリセット / Presets（フォント＋カーニング・ツメ・トラッキングをまとめて適用）----
        // どちらのビューでクリックしても「プリセット一括適用」。表示モードは列の見せ方だけ
        // Clicking in either view applies the whole preset; the mode only changes how columns are shown
        function applyPresetFromItem(selectedPreset) {
            if (!selectedPreset || !selectedPreset.psName) return;
            var params = { psName: selectedPreset.psName };
            if (selectedPreset.kern) {
                params.kern = selectedPreset.kern;
                // カーニングのラジオも UI に反映 / Reflect the kerning radio on the UI too
                for (var kernIndex = 0; kernIndex < autoKernOptions.length; kernIndex++) {
                    if (autoKernOptions[kernIndex].id === selectedPreset.kern) { selectExclusiveRadio(ui.kernRadios, kernIndex); break; }
                }
            }
            if (selectedPreset.tsume !== undefined && selectedPreset.tsume !== null) {
                params.tsume = selectedPreset.tsume;
                // ツメは UI にも反映 / Reflect Tsume on the slider too
                ui.tsumeSlider.value = selectedPreset.tsume;
                setFieldValue(ui.tsumeInput, selectedPreset.tsume);
            }
            if (selectedPreset.tracking !== undefined && selectedPreset.tracking !== null) {
                params.tracking = selectedPreset.tracking;
                // トラッキングも UI に反映 / Reflect tracking on the slider too
                ui.trackingSlider.value = selectedPreset.tracking;
                ui.trackingInput.text = String(selectedPreset.tracking);
            }
            runApply("applyFontPreset", params);
        }
        ui.presetFontOnlyListBox.onChange = function () { applyPresetFromItem(this.selection); };
        ui.presetDetailedListBox.onChange = function () { applyPresetFromItem(this.selection); };

        // 現在アクティブなプリセット listbox（追加・上書き・削除の選択元）/ The active preset listbox (source for add/overwrite/delete)
        function activePresetList() { return ui.presetDetailedRadio.value ? ui.presetDetailedListBox : ui.presetFontOnlyListBox; }

        // 表示モード切替（stack なので visible 切替のみ）/ Switch view mode (stack: toggle visibility only)
        function applyPresetView() {
            var fontOnly = ui.presetFontOnlyRadio.value;
            ui.presetFontOnlyListBox.visible = fontOnly;
            ui.presetDetailedListBox.visible = !fontOnly;
        }
        ui.presetFontOnlyRadio.onClick = function () { applyPresetView(); };
        ui.presetDetailedRadio.onClick = function () { applyPresetView(); };
        applyPresetView(); // 初期表示（既定＝フォントのみ）/ Initial view (default = font-only)

        // 現在の選択の設定をプリセットオブジェクトへ変換 / Build a preset object from the current selection's settings
        function buildPresetFromSelection(callback) {
            runWorker("getCurrentFont", null, function (status, payload) {
                if (status !== "ok" || !payload) { callback(null); return; }
                var fontParts = decodeURIComponent(payload).split("|");
                callback({
                    psName: fontParts[0],
                    kern: fontParts[1] || undefined,
                    tsume: fontParts[2] !== "" ? parseInt(fontParts[2], 10) : undefined,
                    tracking: fontParts[3] !== "" ? parseInt(fontParts[3], 10) : undefined
                });
            });
        }

        // プリセット保存後にリストと表示名を更新 / Persist, then refresh the list and labels
        function commitPresets(presets) {
            savePresets(presets);
            fillPresetLists(ui.presetFontOnlyListBox, ui.presetDetailedListBox, presets);
            presetLabelsResolved = false; // 追加・更新直後も表示名を再解決する / Re-resolve labels after add/update
            refreshPresetLabels();
        }

        // ---- プリセットに追加（現在の選択の設定を保存）/ Add the current selection's settings as a preset ----
        ui.addPresetButton.onClick = function () {
            buildPresetFromSelection(function (newPreset) {
                if (!newPreset) return;
                var presets = loadPresets();
                // 同じ PostScript 名があれば設定を上書き / Overwrite settings if the font is already present
                var replaced = false;
                for (var presetIndex = 0; presetIndex < presets.length; presetIndex++) {
                    if (presets[presetIndex].psName === newPreset.psName) { presets[presetIndex] = newPreset; replaced = true; break; }
                }
                if (!replaced) presets.push(newPreset);
                commitPresets(presets);
            });
        };

        // ---- プリセットを上書き（リストで選択中の項目を現在の選択の設定で更新）/ Overwrite the selected list item with the current selection's settings ----
        ui.overwritePresetButton.onClick = function () {
            var index = activePresetList().selection ? activePresetList().selection.index : -1;
            if (index < 0) return; // 未選択なら何もしない / Do nothing if nothing is selected
            buildPresetFromSelection(function (newPreset) {
                if (!newPreset) return;
                var presets = loadPresets();
                if (index >= presets.length) return;
                presets[index] = newPreset;
                commitPresets(presets);
            });
        };

        // ---- プリセットを書き出し（登録済みプリセットを JSON ファイルへ）/ Export presets to a JSON file ----
        ui.exportPresetButton.onClick = function () {
            var presets = loadPresets();
            var defaultFile = File(Folder.desktop.fsName + "/UnifiedTypePanel_presets.json");
            var saveFile = defaultFile.saveDlg(getLabel(LABELS.tip.exportPreset), "JSON:*.json");
            if (!saveFile) return; // キャンセル / Cancelled
            try {
                saveFile.encoding = "UTF-8";
                if (saveFile.open("w")) {
                    saveFile.write(presetsToJsonText(presets));
                    saveFile.close();
                }
            } catch (e) {
                try { saveFile.close(); } catch (eClose) { }
                alert(getLabel(LABELS.msg.applyError) + "\n" + e);
            }
        };

        // ---- プリセットを削除（リストで選択中の項目を削除）/ Delete the selected list item ----
        ui.deletePresetButton.onClick = function () {
            var index = activePresetList().selection ? activePresetList().selection.index : -1;
            if (index < 0) return; // 未選択なら何もしない / Do nothing if nothing is selected
            var presets = loadPresets();
            if (index >= presets.length) return;
            presets.splice(index, 1);
            commitPresets(presets);
        };

        // ---- 文字揃え（欧文ベースライン／中央／その他＋ポップアップ）/ Character alignment (Roman / Center / Other + popup) ----
        // ラジオは親が異なるため手動で排他制御 / Radios have different parents, so toggle them manually
        function selectAlignRadio(alignId) {
            var targetAlignId = (alignId === "roman" || alignId === "center") ? alignId : "other";
            for (var i = 0; i < ui.alignRadios.length; i++) {
                ui.alignRadios[i].value = (ui.alignRadios[i].alignId === targetAlignId);
            }
        }
        function applyAlignOther() {
            if (suppressUiEvents) return;
            var selectedOption = ui.alignOtherDropdown.selection;
            if (!selectedOption) return;
            selectAlignRadio("other");
            runApply("applyAlign", { align: ui.alignOtherOptions[selectedOption.index].id });
        }
        ui.alignRomanRadio.onClick = function () { selectAlignRadio("roman"); runApply("applyAlign", { align: "roman" }); };
        ui.alignCenterRadio.onClick = function () { selectAlignRadio("center"); runApply("applyAlign", { align: "center" }); };
        ui.alignOtherRadio.onClick = applyAlignOther;
        ui.alignOtherDropdown.onChange = applyAlignOther;

        // ---- 行揃え（グラフィカルボタン）/ Paragraph justification (graphical buttons) ----
        // アクティブ表示を切り替えて再描画 / Switch the active button and redraw
        function setActiveJustify(justifyId) {
            ui.justifyState.activeId = justifyId || "";
            for (var i = 0; i < ui.justifyButtons.length; i++) {
                try { ui.justifyButtons[i].notify("onDraw"); } catch (e) { }
            }
            try { ui.palette.update(); } catch (e2) { }
        }
        for (var buttonIndex = 0; buttonIndex < ui.justifyButtons.length; buttonIndex++) {
            ui.justifyButtons[buttonIndex].onClick = function () {
                setActiveJustify(this.justifyId);
                runApply("applyJustification", { justify: this.justifyId });
            };
        }

        // ---- 種別（本文／見出し）とリセット / Type roles (Body / Heading) and Reset ----
        // id 一致するラジオを選択 / Select the radio whose option id matches
        function selectRadioById(radios, options, targetId) {
            for (var i = 0; i < options.length; i++) {
                if (options[i].id === targetId) { selectExclusiveRadio(radios, i); return; }
            }
        }
        function reflectTsume(value) {
            ui.tsumeSlider.value = value;
            setFieldValue(ui.tsumeInput, value);
        }
        function reflectTracking(value) {
            ui.trackingSlider.value = value;
            ui.trackingInput.text = String(value);
        }
        // 文字組みアキ量設定ポップアップを mojikumiSet インデックスで選択 / Select the mojikumi popup by mojikumiSet index
        function reflectMojikumiByIndex(mojikumiIndex) {
            for (var i = 0; i < ui.mojikumiChoices.length; i++) {
                if (ui.mojikumiChoices[i].index === mojikumiIndex) { ui.mojikumiDropdown.selection = i; return; }
            }
        }
        // 禁則ポップアップを id（"None"/"Hard"/"Soft"/"Soft_v2"）で選択 / Select the kinsoku popup by id
        function reflectKinsokuById(kinsokuId) {
            for (var i = 0; i < ui.kinsokuChoices.length; i++) {
                if (ui.kinsokuChoices[i].id === kinsokuId) {
                    suppressUiEvents = true;
                    ui.kinsokuDropdown.selection = i;
                    suppressUiEvents = false;
                    return;
                }
            }
        }

        /* 現在選択中の方針プリセットを返す（未選択なら null）/ Return the selected policy preset (null if none) */
        function currentPolicyPreset() {
            for (var i = 0; i < ui.policyRadios.length; i++) {
                if (ui.policyRadios[i].value) return ui.policyRadios[i].policyPreset;
            }
            return null;
        }

        /* 種別プロファイルの文字組み・禁則を、選択中の方針の指定で上書きする
           （欧文＝いずれも「なし」、和文／和欧混在＝弱い禁則v2 ＋ 本文ベタ組み・見出しツメ組み）
           Override the role profile's mojikumi/kinsoku with the selected policy's values
           @param {object} profileParams - applyProfile へ渡すパラメータ / The params passed to applyProfile
           @param {boolean} isHeadingRole - 見出しプロファイルなら true / true for the Heading profile
           @returns {object} 上書き後のパラメータ（同一オブジェクト）/ The same object, after the override */
        function applyPolicyOverrides(profileParams, isHeadingRole) {
            var preset = currentPolicyPreset();
            if (!preset) return profileParams;
            var presetMojikumiIndex = isHeadingRole ? preset.headingMojikumiIndex : preset.bodyMojikumiIndex;
            if (presetMojikumiIndex !== undefined) profileParams.mojikumiIndex = presetMojikumiIndex;
            if (preset.kinsoku !== undefined) profileParams.kinsoku = preset.kinsoku;
            return profileParams;
        }

        // 本文：和文等幅／行送り 150%／均等配置（最終行左）／文字組みベタ組み / Body preset (mojikumi: Solid)
        ui.roleBodyRadio.onClick = function () {
            ui.mainTabs.selection = ui.typeTab; // 文字組みタブへ切り替え / Switch to the Type tab
            var bodyParams = applyPolicyOverrides({ kern: "mono", leadingPercent: 150, justify: "justifyLeft", mojikumiIndex: 6, kinsoku: "Soft_v2" }, false);
            runApply("applyProfile", bodyParams);
            selectRadioById(ui.kernRadios, autoKernOptions, "mono");
            reflectLeadingPercent(150);
            setActiveJustify("justifyLeft");
            reflectMojikumiByIndex(bodyParams.mojikumiIndex);
            reflectKinsokuById(bodyParams.kinsoku);
        };

        // 見出し：メトリクス／行送り 115%／左揃え／文字組みツメ組み／弱い禁則 v2 / Heading preset (mojikumi: Tight, kinsoku: Soft_v2)
        ui.roleHeadingRadio.onClick = function () {
            ui.mainTabs.selection = ui.typeTab; // 文字組みタブへ切り替え / Switch to the Type tab
            var headingParams = applyPolicyOverrides({ kern: "metrics", leadingPercent: 115, justify: "left", mojikumiIndex: 5, kinsoku: "Soft_v2" }, true);
            runApply("applyProfile", headingParams);
            selectRadioById(ui.kernRadios, autoKernOptions, "metrics");
            reflectLeadingPercent(115);
            setActiveJustify("left");
            reflectMojikumiByIndex(headingParams.mojikumiIndex);
            reflectKinsokuById(headingParams.kinsoku);
        };

        // 方針：文字揃え＋行送りの基準をまとめて適用し、対応するラジオも反映
        // Policy: apply char-alignment + leading-basis together and reflect the corresponding radios
        for (var policyRadioIndex = 0; policyRadioIndex < ui.policyRadios.length; policyRadioIndex++) {
            (function (index) {
                ui.policyRadios[index].onClick = function () {
                    ui.mainTabs.selection = ui.typeTab; // 文字組みタブへ切り替え / Switch to the Type tab
                    var preset = ui.policyRadios[index].policyPreset;
                    selectExclusiveRadio(ui.policyRadios, index);
                    // 種別が見出しなら headingJustify（左揃え）を優先 / Heading role prefers headingJustify (left)
                    var isHeadingRole = ui.roleHeadingRadio.value;
                    var policyJustifyId = (isHeadingRole && preset.headingJustify !== undefined) ? preset.headingJustify : preset.justify;
                    // 行送り % は本文のときだけ方針ごとの値に合わせる（見出しは見出しプロファイルの 115% のまま）
                    // The leading % follows the policy only for the Body role (Heading keeps its profile's 115%)
                    var policyLeadingPercent = isHeadingRole ? undefined : preset.bodyLeadingPercent;
                    // 文字組みアキ量設定は種別ごと（見出し＝ツメ組み／本文＝ベタ組み、欧文はいずれも「なし」）
                    // The mojikumi set depends on the role (Heading = tight, Body = solid; Latin = "None" for both)
                    var policyMojikumiIndex = isHeadingRole ? preset.headingMojikumiIndex : preset.bodyMojikumiIndex;
                    runApply("applyPolicy", { align: preset.align, leadingType: preset.leadingType, hyphenation: preset.hyphenation, justify: policyJustifyId, leadingPercent: policyLeadingPercent, mojikumiIndex: policyMojikumiIndex, kinsoku: preset.kinsoku });
                    selectAlignRadio(preset.align);
                    selectRadioById(ui.leadingBasisRadios, ui.leadingBasisChoices, preset.leadingType);
                    if (policyJustifyId !== undefined) setActiveJustify(policyJustifyId);
                    if (policyLeadingPercent !== undefined) reflectLeadingPercent(policyLeadingPercent);
                    if (policyMojikumiIndex !== undefined) reflectMojikumiByIndex(policyMojikumiIndex);
                    if (preset.kinsoku !== undefined) reflectKinsokuById(preset.kinsoku);
                };
            })(policyRadioIndex);
        }

        // 制御文字の表示／非表示 / Toggle hidden characters
        ui.hiddenCharButton.onClick = function () {
            runApply("toggleHiddenChar", null);
        };

        // リセット：すべて既定値へ / Reset everything to defaults
        ui.resetButton.onClick = function () {
            runApply("applyProfile", {
                kern: "mono", tsume: 0, tracking: 0, align: "roman", justify: "left",
                leadingPercent: 115, leadingType: "top",
                sizePt: 12, scale: 100, mojikumiIndex: 5, kinsoku: "Soft_v2", clearAki: true
            });
            selectRadioById(ui.kernRadios, autoKernOptions, "mono");
            syncProportionalMetricsCheck("mono"); // 和文等幅ではプロポーショナルは OFF / Proportional is OFF for Japanese equal width
            reflectTsume(0);
            reflectTracking(0);
            selectAlignRadio("roman");
            setActiveJustify("left");
            reflectLeadingPercent(115);
            selectRadioById(ui.leadingBasisRadios, ui.leadingBasisChoices, "top");
            // 文字組みアキ量設定を「ツメ組み」（mojikumiSet の index 5）へ / Mojikumi to Tight (index 5)
            suppressUiEvents = true;
            for (var mojikumiChoiceIndex = 0; mojikumiChoiceIndex < ui.mojikumiChoices.length; mojikumiChoiceIndex++) {
                if (ui.mojikumiChoices[mojikumiChoiceIndex].index === 5) { ui.mojikumiDropdown.selection = mojikumiChoiceIndex; break; }
            }
            // 禁則を「弱い禁則 v2」（Soft_v2）へ / Kinsoku to Loose v2 (Soft_v2)
            for (var kinsokuChoiceIndex = 0; kinsokuChoiceIndex < ui.kinsokuChoices.length; kinsokuChoiceIndex++) {
                if (ui.kinsokuChoices[kinsokuChoiceIndex].id === "Soft_v2") { ui.kinsokuDropdown.selection = kinsokuChoiceIndex; break; }
            }
            suppressUiEvents = false;
            // 文字サイズ 12pt・比率 100% / Font size 12pt, scale 100%
            syncFontSizeText(String(Math.round(ptToUnit(12, textUnit) * 10) / 10), null);
            setFieldValue(ui.scaleInput, "100");
            updateApparentDisplay();
            updateReferenceApparent();
            updateLeadingEffective(); // サイズ確定後に実質行送りを更新 / Refresh the effective leading after the size is set
            ui.roleBodyRadio.value = false;
            ui.roleHeadingRadio.value = false;
            for (var policyResetIndex = 0; policyResetIndex < ui.policyRadios.length; policyResetIndex++) ui.policyRadios[policyResetIndex].value = false;
        };

        // 自動カーニングに合わせてプロポーショナルメトリクスのチェックを更新（メトリクスのみ ON）
        // Sync the proportional-metrics checkbox with the kerning choice (ON only for Metrics)
        function syncProportionalMetricsCheck(methodId) {
            if (ui.proportionalMetricsCheck) ui.proportionalMetricsCheck.value = (methodId === "metrics");
        }

        // ---- カーニング・文字ツメ / Kerning and Tsume ----
        for (var i = 0; i < ui.kernRadios.length; i++) {
            ui.kernRadios[i].onClick = function () {
                syncProportionalMetricsCheck(autoKernOptions[this.index].id);
                runApply("apply", { method: autoKernOptions[this.index].id });
            };
        }
        // 文字ツメスライダー（Shift 併用で 10% 刻み）/ Tsume slider (Shift snaps to 10% steps)
        function tsumeSnap(value) {
            var isShiftPressed = false;
            try { isShiftPressed = ScriptUI.environment.keyboardState.shiftKey; } catch (e) { }
            return isShiftPressed ? Math.round(value / 10) * 10 : Math.round(value);
        }
        ui.tsumeSlider.onChanging = function () {
            var snappedValue = tsumeSnap(this.value);
            this.value = snappedValue;
            setFieldValue(ui.tsumeInput, snappedValue);
        };
        ui.tsumeSlider.onChange = function () {
            var snappedValue = tsumeSnap(this.value);
            this.value = snappedValue;
            setFieldValue(ui.tsumeInput, snappedValue);
            runApply("applyTsume", { value: snappedValue });
        };
        // 文字ツメ入力欄：0〜100 にクランプしてスライダーへ反映 / Tsume input: clamp 0-100 and sync the slider
        function applyTsumeFromInput() {
            var clampedValue = Math.round(parseFloat(ui.tsumeInput.text));
            if (isNaN(clampedValue)) return;
            if (clampedValue < 0) clampedValue = 0; else if (clampedValue > 100) clampedValue = 100;
            setFieldValue(ui.tsumeInput, clampedValue);
            ui.tsumeSlider.value = clampedValue;
            runApply("applyTsume", { value: clampedValue });
        }
        ui.tsumeInput.onChange = applyTsumeFromInput;
        ui.tsumeInput.stepOptions.onStep = applyTsumeFromInput; /* スライダーも追従 / keeps the slider in sync */

        // トラッキングスライダー（-100〜500、Shift 併用で 10 単位）/ Tracking slider (-100 to 500, Shift snaps to 10 steps)
        function trackingSnap(value) {
            var isShiftPressed = false;
            try { isShiftPressed = ScriptUI.environment.keyboardState.shiftKey; } catch (e) { }
            return isShiftPressed ? Math.round(value / 10) * 10 : Math.round(value);
        }
        ui.trackingSlider.onChanging = function () {
            var snappedValue = trackingSnap(this.value);
            this.value = snappedValue;
            ui.trackingInput.text = String(snappedValue);
        };
        ui.trackingSlider.onChange = function () {
            var snappedValue = trackingSnap(this.value);
            this.value = snappedValue;
            ui.trackingInput.text = String(snappedValue);
            runApply("applyTracking", { tracking: snappedValue });
        };
        // トラッキング入力欄：-100〜500 にクランプしてスライダーへ反映 / Tracking input: clamp -100..500 and sync the slider
        function applyTrackingFromInput() {
            var clampedValue = Math.round(parseFloat(ui.trackingInput.text));
            if (isNaN(clampedValue)) return;
            if (clampedValue < -100) clampedValue = -100; else if (clampedValue > 500) clampedValue = 500;
            ui.trackingInput.text = String(clampedValue);
            ui.trackingSlider.value = clampedValue;
            runApply("applyTracking", { tracking: clampedValue });
        }
        ui.trackingInput.onChange = applyTrackingFromInput;
        ui.trackingInput.stepOptions.onStep = applyTrackingFromInput; /* スライダーも追従 / keeps the slider in sync */

        // ---- フォントサイズ（文字サイズ・比率・見かけ）/ Font size (size, scale, apparent) ----
        // 文字組みタブと「フォントサイズ」タブの2つのサイズ欄を同期させる / Keep the two size fields (Type tab + Font Size tab) in sync
        function calcApparentSize(size, scale) { return Math.round(size * scale) / 100; }
        /* 全サイズ欄へ値を反映（except は編集中の欄を除外してキャレット移動を防ぐ）/ Push a value to every size field (except the one being edited, to avoid caret jumps) */
        function syncFontSizeText(text, except) {
            for (var i = 0; i < ui.fontSizeInputs.length; i++) {
                if (ui.fontSizeInputs[i] !== except) setFieldValue(ui.fontSizeInputs[i], text);
            }
        }
        function updateApparentDisplay() {
            var size = parseFloat(ui.fontSizeInputs[0].text);
            var scale = parseFloat(ui.scaleInput.text);
            if (isNaN(size) || isNaN(scale)) {
                ui.apparentValueLabel.text = "--";
            } else {
                ui.apparentValueLabel.text = String(Math.round(calcApparentSize(size, scale) * 10) / 10);
            }
            // 比率100%のときは見かけ＝実サイズなので淡色表示 / Dim when scale is 100 (apparent == actual)
            var isDimmed = (scale === 100);
            ui.fsApparentLabel.enabled = !isDimmed;
            ui.apparentValueLabel.enabled = !isDimmed;
            ui.fsApparentUnit.enabled = !isDimmed;
        }
        // サイズ変更では基準見かけサイズ（referenceApparent）を更新しない＝ボタンで元の見かけへ戻せるように保持
        // A size edit does NOT update the reference apparent size, so the button can restore the previous look
        function applyFontSizeFromInput(sourceInput) {
            var inputValue = parseFloat(sourceInput.text);
            syncFontSizeText(isNaN(inputValue) ? "" : String(inputValue), sourceInput);
            // 行送りは自動行送りなのでサイズ変更に自動追従する（行送りの再適用は不要）
            // Leading is auto-leading and follows the size automatically (no need to reapply leading)
            if (!isNaN(inputValue)) runApply("applyFontSize", { sizePt: unitToPt(inputValue, textUnit) });
            updateApparentDisplay();
            updateLeadingEffective(); // サイズ変更で実質行送りの表示も更新 / Refresh the effective-leading display on size change
        }
        // 比率の変更は「見た目を変える」操作なので基準見かけサイズを更新 / A scale edit changes the look, so refresh the reference
        function applyScaleFromInput() {
            var inputValue = parseFloat(ui.scaleInput.text);
            if (!isNaN(inputValue)) runApply("applyScale", { scale: inputValue });
            updateApparentDisplay();
            updateReferenceApparent();
        }
        for (var fontSizeInputIndex = 0; fontSizeInputIndex < ui.fontSizeInputs.length; fontSizeInputIndex++) {
            (function (sizeInput) {
                sizeInput.onChange = function () { applyFontSizeFromInput(sizeInput); };
                sizeInput.onChanging = function () {
                    var typedSize = parseFloat(sizeInput.text);
                    syncFontSizeText(isNaN(typedSize) ? "" : String(typedSize), sizeInput);
                    updateApparentDisplay();
                    updateLeadingEffective();
                };
                sizeInput.stepOptions.onStep = function () { applyFontSizeFromInput(sizeInput); };
            })(ui.fontSizeInputs[fontSizeInputIndex]);
        }
        ui.scaleInput.onChange = applyScaleFromInput;
        ui.scaleInput.onChanging = function () { updateApparentDisplay(); };
        ui.scaleInput.stepOptions.onStep = applyScaleFromInput;

        // ---- タイプスケール（サイズタブ右カラム）/ Type scale (right column of the Size tab) ----
        // 一覧の行をクリックしたら、そのサイズを選択テキストへ適用しサイズ欄にも反映
        // Click a row to apply that size to the selection and reflect it in the size fields
        ui.typeScaleList.onChange = function () {
            var selectedItem = ui.typeScaleList.selection;
            if (!selectedItem) return;
            var sizeValue = parseFloat(selectedItem.subItems[0].text);
            if (isNaN(sizeValue) || sizeValue <= 0) return;
            syncFontSizeText(String(sizeValue), null);
            updateApparentDisplay();
            updateReferenceApparent(); // 選んだサイズを新しい見た目の基準に / The picked size becomes the new visual reference
            updateLeadingEffective(); // サイズ変更で実質行送りの表示も更新 / Refresh the effective-leading display on size change
            // タイプスケールは段落全体にサイズを適用（行送りは自動行送りなので自動追従）
            // Type scale applies the size to the whole paragraph (leading is auto and follows automatically)
            runApply("applyFontSizePara", { sizePt: unitToPt(sizeValue, textUnit) });
        };
        // 基準サイズ欄が空なら現在のフォントサイズ（なければ既定値）で初期化 / Seed the base field from the current font size (fallback to default)
        if (ui.typeScaleBaseInput.text === "") {
            var seedBase = parseFloat(ui.fontSizeInputs[0].text);
            setFieldValue(ui.typeScaleBaseInput, (!isNaN(seedBase) && seedBase > 0) ? String(seedBase) : String(Math.round(ptToUnit(12, textUnit) * 10) / 10));
            ui.rebuildTypeScaleList();
        }

        // 見かけ←→実サイズ（相互変換）：見た目の大きさ（実質サイズ＝サイズ×比率）を保ったまま、
        //   ・比率≠100%：現在の見かけを実サイズへ焼き込み、比率100%に（見かけ→実サイズ）
        //   ・比率＝100%：サイズ変更後、変更前の見かけサイズを基準に比率を計算して合わせる（実サイズ→見かけ）
        // referenceApparent に「保つべき見かけサイズ（表示単位）」を保持。サイズ変更では更新しないので元の見た目へ戻せる
        // Apparent ←→ Actual: keep the visual size (size × scale) constant.
        //   - scale != 100: bake the current apparent into the actual size, scale → 100% (apparent → actual)
        //   - scale == 100: after a size change, compute the scale that restores the pre-change apparent (actual → apparent)
        // referenceApparent holds the apparent size to preserve (display units); size edits don't touch it, so the look can be restored.
        var referenceApparent = NaN;
        function updateReferenceApparent() {
            var size = parseFloat(ui.fontSizeInputs[0].text);
            var scale = parseFloat(ui.scaleInput.text);
            referenceApparent = (isNaN(size) || isNaN(scale)) ? NaN : calcApparentSize(size, scale);
        }
        ui.apparentToggleButton.onClick = function () {
            var size = parseFloat(ui.fontSizeInputs[0].text);
            var scale = parseFloat(ui.scaleInput.text);
            if (isNaN(size) || isNaN(scale)) return;
            var EPS = 0.05;
            if (Math.abs(scale - 100) > EPS) {
                // 見かけ→実サイズ：現在の見かけ（サイズ×比率）を実サイズへ焼き込み、比率を100%に
                // Apparent → Actual: bake the current apparent into the actual size, scale → 100%
                var bakedSize = calcApparentSize(size, scale);
                syncFontSizeText(String(bakedSize), null);
                setFieldValue(ui.scaleInput, "100");
                runApply("applyFontSizeAndScale", { sizePt: unitToPt(bakedSize, textUnit), scale: 100 });
            } else {
                // 実サイズ→見かけ：サイズ変更後、変更前の見かけサイズを基準に比率を計算して合わせる
                // Actual → Apparent: after a size change, compute the scale that restores the previous apparent size
                if (isNaN(referenceApparent) || Math.abs(referenceApparent - size) < EPS) return; // 変更なし＝何もしない / no change → no-op
                var newScale = Math.round((referenceApparent / size) * 100 * 10) / 10;
                setFieldValue(ui.scaleInput, newScale);
                runApply("applyFontSizeAndScale", { sizePt: unitToPt(size, textUnit), scale: newScale });
            }
            updateReferenceApparent(); // 変換後の見かけを新しい基準に / The post-conversion apparent becomes the new reference
            updateApparentDisplay();
        };

        // ---- 行送り / Leading ----

        /* 現在の行送り（自動行送り量 %）を取得 / Read the current leading (auto-leading amount %) */
        function currentLeadingPercent() {
            return parseFloat(ui.leadingPercentInput.text);
        }

        /* 実質行送り（フォントサイズ×%）の表示を更新 / Update the effective-leading display (font size × %) */
        function updateLeadingEffective() {
            var size = parseFloat(ui.fontSizeInputs[0].text);
            var percent = currentLeadingPercent();
            if (isNaN(size) || isNaN(percent)) { setFieldValue(ui.leadingEffectiveInput, ""); return; }
            setFieldValue(ui.leadingEffectiveInput, Math.round(size * percent / 100 * 10) / 10);
        }

        /* 行送り（%）欄へ値を反映し、実質表示も更新 / Set the leading (%) field and refresh the effective display */
        function reflectLeadingPercent(percent) {
            setFieldValue(ui.leadingPercentInput, isNaN(percent) ? "" : Math.round(percent * 10) / 10);
            updateLeadingEffective();
        }

        /* UI の現在状態から行送りパラメータ（自動行送り量%＋基準）を組み立てる（% が空なら null）
           Build leading params (auto-leading % + basis) from the current UI (null if the % is empty) */
        function currentLeadingParams() {
            var percent = currentLeadingPercent();
            if (isNaN(percent)) return null;
            var basisIndex = selectedRadioIndex(ui.leadingBasisRadios);
            if (basisIndex < 0) basisIndex = 0;
            return {
                percent: percent,
                leadingType: ui.leadingBasisChoices[basisIndex].id
            };
        }

        function applyLeading() {
            var params = currentLeadingParams();
            if (!params) return;
            if (workerBusy) return;
            workerBusy = true;
            runWorker("applyLeading", params, function (status, payload) {
                workerBusy = false;
            });
        }

        // 行送り（%）入力：実質表示を更新して適用 / Leading (%) input: refresh the effective display and apply
        function applyLeadingFromPercent() {
            updateLeadingEffective();
            applyLeading();
        }
        ui.leadingPercentInput.onChange = applyLeadingFromPercent;
        ui.leadingPercentInput.onChanging = function () { updateLeadingEffective(); };
        ui.leadingPercentInput.stepOptions.onStep = applyLeadingFromPercent;

        // 実質（pt）入力：フォントサイズから % を逆算して適用 / Effective (pt) input: back-calculate the % from the font size and apply
        function applyLeadingFromEffective() {
            var effective = parseFloat(ui.leadingEffectiveInput.text);
            var size = parseFloat(ui.fontSizeInputs[0].text);
            if (isNaN(effective) || isNaN(size) || size <= 0) return;
            var percent = Math.round((effective / size) * 100 * 10) / 10;
            setFieldValue(ui.leadingPercentInput, percent);
            applyLeading();
        }
        ui.leadingEffectiveInput.onChange = applyLeadingFromEffective;
        ui.leadingEffectiveInput.stepOptions.onStep = applyLeadingFromEffective;

        for (var basisRadioIndex = 0; basisRadioIndex < ui.leadingBasisRadios.length; basisRadioIndex++) {
            (function (index) {
                ui.leadingBasisRadios[index].onClick = function () {
                    selectExclusiveRadio(ui.leadingBasisRadios, index);
                    applyLeading();
                };
            })(basisRadioIndex);
        }

        // 文字組みアキ量設定（ポップアップ）/ Mojikumi spacing set (popup)
        ui.mojikumiDropdown.onChange = function () {
            if (suppressUiEvents || !this.selection) return;
            runApply("applyMojikumi", { mojikumiIndex: ui.mojikumiChoices[this.selection.index].index });
        };

        // 禁則（ポップアップ）/ Kinsoku (popup)
        ui.kinsokuDropdown.onChange = function () {
            if (suppressUiEvents || !this.selection) return;
            runApply("applyKinsoku", { kinsoku: ui.kinsokuChoices[this.selection.index].id });
        };

        /* ドキュメントのカスタムの文字組みアキ量設定を、組み込みのあとに並べ直す（変わったときだけ）
           Re-list the document's custom mojikumi sets after the built-ins (only when they changed) */
        var customMojikumiKey = "";
        function syncCustomMojikumiChoices(customNames) {
            var nextKey = customNames.join("\n");
            if (nextKey === customMojikumiKey) return;
            customMojikumiKey = nextKey;
            var builtinCount = MOJIKUMI_CHOICES.length;
            var selectedIndex = ui.mojikumiDropdown.selection ? ui.mojikumiDropdown.selection.index : 0;
            suppressUiEvents = true;
            while (ui.mojikumiDropdown.items.length > builtinCount) ui.mojikumiDropdown.remove(ui.mojikumiDropdown.items.length - 1);
            ui.mojikumiChoices.length = builtinCount;
            for (var i = 0; i < customNames.length; i++) {
                ui.mojikumiChoices.push({ index: MOJIKUMI_BUILTIN_COUNT + i, label: customNames[i] });
                ui.mojikumiDropdown.add("item", customNames[i]);
            }
            /* 選んでいたカスタムが消えたら先頭に戻す / Fall back to the first item when the selected custom set is gone */
            ui.mojikumiDropdown.selection = (selectedIndex < ui.mojikumiDropdown.items.length) ? selectedIndex : 0;
            suppressUiEvents = false;
        }

        /* 選択状態を読み取って UI に反映 / Read the selection state and reflect it into the UI */
        function refreshState() {
            runWorker("getState", null, function (status, payload) {
                if (status !== "ok") return;
                var state = parseLeadingState(payload);
                syncCustomMojikumiChoices(state.customMojikumiNames);
                if (state.count <= 0) return;
                // フォントサイズ・比率・見かけ / Font size, scale, apparent
                syncFontSizeText(isNaN(state.fontSizePt) ? "" : String(Math.round(ptToUnit(state.fontSizePt, textUnit) * 10) / 10), null);
                setFieldValue(ui.scaleInput, isNaN(state.hScale) ? "100" : Math.round(state.hScale * 10) / 10);
                updateApparentDisplay();
                updateReferenceApparent(); // 選択を読み直したら現在の見かけを基準にする / Reloading the selection sets the current apparent as the reference
                // 行送り%：自動行送り量（%）を % 欄に反映（実質欄は現在値で上書きするので計算表示は使わない）
                // Leading %: reflect the auto-leading amount (%) into the % field（the effective field is overwritten by the actual value below）
                setFieldValue(ui.leadingPercentInput, isNaN(state.autoAmount) ? "" : Math.round(state.autoAmount * 10) / 10);
                // 行送り：選択の現在値（絶対値 pt）をそのまま表示（サイズ×% の計算値ではない）
                // Leading: show the selection's actual current value (absolute pt), not the size × % computation
                setFieldValue(ui.leadingEffectiveInput, isNaN(state.leadingPt) ? "" : Math.round(ptToUnit(state.leadingPt, textUnit) * 10) / 10);
                // 行送りの基準 / Leading basis
                var basisIndex = 0;
                for (var choiceIndex = 0; choiceIndex < ui.leadingBasisChoices.length; choiceIndex++) {
                    if (ui.leadingBasisChoices[choiceIndex].id === state.leadingTypeId) { basisIndex = choiceIndex; break; }
                }
                selectExclusiveRadio(ui.leadingBasisRadios, basisIndex);
                // 文字組みアキ量設定（-2＝読み取り不可・不明のときは現在の選択を維持）/ Mojikumi (leave the current selection when -2 = unreadable/unknown)
                if (state.mojikumiId !== -2) {
                    var mojikumiSelectionIndex = 0;
                    for (var mojikumiChoiceIndex = 0; mojikumiChoiceIndex < ui.mojikumiChoices.length; mojikumiChoiceIndex++) {
                        if (ui.mojikumiChoices[mojikumiChoiceIndex].index === state.mojikumiId) { mojikumiSelectionIndex = mojikumiChoiceIndex; break; }
                    }
                    suppressUiEvents = true;
                    ui.mojikumiDropdown.selection = mojikumiSelectionIndex;
                    suppressUiEvents = false;
                }
                // 禁則 / Kinsoku
                var kinsokuSelectionIndex = 0;
                for (var kinsokuChoiceIndex = 0; kinsokuChoiceIndex < ui.kinsokuChoices.length; kinsokuChoiceIndex++) {
                    if (ui.kinsokuChoices[kinsokuChoiceIndex].id === state.kinsokuId) { kinsokuSelectionIndex = kinsokuChoiceIndex; break; }
                }
                suppressUiEvents = true;
                ui.kinsokuDropdown.selection = kinsokuSelectionIndex;
                suppressUiEvents = false;
                // 文字揃え / Character alignment
                if (state.alignmentId) {
                    selectAlignRadio(state.alignmentId);
                    // その他系は対応するポップアップ項目も選択 / For "Other" ids, also select the popup item
                    if (state.alignmentId !== "roman" && state.alignmentId !== "center") {
                        for (var optionIndex = 0; optionIndex < ui.alignOtherOptions.length; optionIndex++) {
                            if (ui.alignOtherOptions[optionIndex].id === state.alignmentId) {
                                suppressUiEvents = true;
                                ui.alignOtherDropdown.selection = optionIndex;
                                suppressUiEvents = false;
                                break;
                            }
                        }
                    }
                }
                // 行揃え / Paragraph justification
                setActiveJustify(state.justifyId || "");
            });
        }

        /* プリセットの表示名を和文フォント名に差し替え（1回だけ、両ビュー）/ Replace preset labels with Japanese font names (once, both views) */
        var presetLabelsResolved = false;
        function refreshPresetLabels() {
            if (presetLabelsResolved) return;
            var foItems = ui.presetFontOnlyListBox.items, dItems = ui.presetDetailedListBox.items;
            var psList = "";
            for (var i = 0; i < foItems.length; i++) {
                psList += (i ? String.fromCharCode(10) : "") + foItems[i].psName;
            }
            runWorker("resolveFontNames", { psList: psList }, function (status, payload) {
                if (status !== "ok") return;
                var resolvedData = decodeURIComponent(payload);
                if (resolvedData === "") return;
                var rows = resolvedData.split(String.fromCharCode(10));
                for (var rowIndex = 0; rowIndex < rows.length && rowIndex < foItems.length; rowIndex++) {
                    var tabIndex = rows[rowIndex].indexOf(String.fromCharCode(9));
                    if (tabIndex >= 0) {
                        var displayName = rows[rowIndex].substring(tabIndex + 1);
                        foItems[rowIndex].text = displayName;           // フォントのみ / font-only
                        if (dItems[rowIndex]) dItems[rowIndex].text = displayName; // 詳細のフォント列 / detailed font column
                    }
                }
                presetLabelsResolved = true;
            });
        }

        // パレット表示・フォーカス復帰のたびに選択状況とフォント一覧を反映 / Reflect the selection and font lists on show and on regaining focus
        // UI 明暗を再取得して行揃えボタンを描き直す / Re-read the UI theme and repaint the justify buttons
        function refreshJustifyTheme() {
            ui.justifyState.isLight = isLightUI();
            setActiveJustify(ui.justifyState.activeId);
        }
        // ---- 使用フォント一覧（フォントのみ／詳細を stack で重ねた2つの listbox で切替）/ Used-fonts list (two stacked listboxes toggled by visibility) ----
        var currentCombos = [];
        var currentFonts = [];
        var comboApplyInProgress = false;

        /* フォントのみ表示か / Whether the font-only view is active */
        function isFontOnlyView() { return ui.fontOnlyRadio.value; }

        // 詳細：クリックで組み合わせを一括適用 / Detailed: a click applies the whole combination
        ui.comboListBox.onChange = function () {
            if (!ui.comboListBox.selection) return;
            if (comboApplyInProgress) return;
            var combo = currentCombos[ui.comboListBox.selection.comboIndex];
            if (!combo) return;
            comboApplyInProgress = true;
            runWorker("applyCombo", comboToParams(combo), function (status, payload) {
                comboApplyInProgress = false;
                // 選択が無いときだけ警告 / Warn only when nothing was selected
                if (status === "ok" && payload === "nosel") alert(getLabel(LABELS.usedFonts.status.needSelection));
            });
        };

        // フォントのみ：クリックでフォントだけ適用（旧ドキュメントフォントと同じ）/ Font-only: a click applies just the font
        ui.fontOnlyListBox.onChange = function () {
            if (!ui.fontOnlyListBox.selection || !ui.fontOnlyListBox.selection.psName) return;
            if (comboApplyInProgress) return;
            comboApplyInProgress = true;
            runWorker("applyFont", { psName: ui.fontOnlyListBox.selection.psName }, function (status, payload) {
                comboApplyInProgress = false;
            });
        };

        /* 表示モードに応じて listbox を出し分け（stack なので visible 切替のみ）/ Show one listbox per mode (stack: just toggle visibility) */
        function applyUsedFontView() {
            var fontOnly = isFontOnlyView();
            ui.fontOnlyListBox.visible = fontOnly;
            ui.comboListBox.visible = !fontOnly;
        }

        /* 走査してデータ更新→両ビュー（詳細・フォントのみ）に反映 / Scan, cache, and repopulate both views */
        function refreshCombos() {
            runWorker("getCombos", { currentArtboardOnly: ui.currentArtboardCheckbox.value, includeHidden: ui.includeHiddenCheckbox.value, includeLocked: ui.includeLockedCheckbox.value }, function (status, payload) {
                currentCombos = (status === "ok") ? parseCombosPayload(decodeURIComponent(payload)) : [];
                currentFonts = combosToFonts(currentCombos);
                // 詳細（8列）/ Detailed (8 columns)
                ui.comboListBox.removeAll();
                for (var i = 0; i < currentCombos.length; i++) {
                    var cells = currentCombos[i].cells;
                    var listItem = ui.comboListBox.add("item", cells[0]);
                    for (var col = 1; col < cells.length; col++) listItem.subItems[col - 1].text = cells[col];
                    listItem.comboIndex = i;
                }
                // フォントのみ（単一列）/ Font-only (single column)
                ui.fontOnlyListBox.removeAll();
                for (var f = 0; f < currentFonts.length; f++) {
                    var fontItem = ui.fontOnlyListBox.add("item", currentFonts[f].displayName);
                    fontItem.psName = currentFonts[f].psName;
                }
            });
        }

        // 表示モード切替 / Switch view mode
        ui.fontOnlyRadio.onClick = function () { applyUsedFontView(); };
        ui.detailedRadio.onClick = function () { applyUsedFontView(); };

        // 選択中の条件に一致するテキストを選択（詳細＝組み合わせ一致／フォントのみ＝フォント一致）
        // Select matching text (detailed = full combo / font-only = same font)
        ui.selectMatchingButton.onClick = function () {
            var matchingParams;
            if (isFontOnlyView()) {
                if (!ui.fontOnlyListBox.selection || !ui.fontOnlyListBox.selection.psName) { alert(getLabel(LABELS.usedFonts.status.needCondition)); return; }
                matchingParams = { psName: ui.fontOnlyListBox.selection.psName, matchFontOnly: true };
            } else {
                if (!ui.comboListBox.selection) { alert(getLabel(LABELS.usedFonts.status.needCondition)); return; }
                var combo = currentCombos[ui.comboListBox.selection.comboIndex];
                if (!combo) return;
                matchingParams = comboToParams(combo);
            }
            matchingParams.currentArtboardOnly = ui.currentArtboardCheckbox.value;
            matchingParams.includeHidden = ui.includeHiddenCheckbox.value;
            matchingParams.includeLocked = ui.includeLockedCheckbox.value;
            runWorker("selectMatching", matchingParams, function (status, payload) {
                if (status === "ok" && payload === "0") alert(getLabel(LABELS.usedFonts.status.noMatch));
            });
        };

        ui.refreshCombosButton.onClick = function () { refreshCombos(); };
        ui.currentArtboardCheckbox.onClick = function () { refreshCombos(); };
        ui.includeHiddenCheckbox.onClick = function () { refreshCombos(); };
        ui.includeLockedCheckbox.onClick = function () { refreshCombos(); };

        // 初期表示モードを反映（既定＝フォントのみ）/ Apply the initial view (default = font-only)
        applyUsedFontView();

        // 使用フォントタブに切り替えたら一覧を再走査（重い走査を必要時のみ）/ Rescan when switching to the used-fonts tab (scan only when needed)
        ui.mainTabs.onChange = function () {
            if (ui.mainTabs.selection === ui.usedFontsTab) refreshCombos();
        };

        ui.palette.onShow = function () { refreshJustifyTheme(); refreshState(); refreshPresetLabels(); if (ui.mainTabs.selection === ui.usedFontsTab) refreshCombos(); };
        ui.palette.onActivate = function () { refreshJustifyTheme(); refreshState(); refreshPresetLabels(); };

        // 再読み込み：選択中のテキストの現在値を読み直して UI に反映 / Reload: re-read the selection's current values into the UI
        ui.reloadButton.onClick = function () { refreshState(); refreshPresetLabels(); };

        // Esc でパレットを閉じる / Close the palette on Esc
        ui.palette.addEventListener("keydown", function (event) {
            if (event.keyName === "Escape") ui.palette.close();
        });

        return { refreshState: refreshState };
    }

    // =========================================
    // メイン処理 / Main
    // =========================================
    function main() {
        // 二重起動ガード：既存パレットがあれば前面化して終了 / Single-instance guard: reuse the existing palette if any
        if ($.global.__UnifiedTypePanel && $.global.__UnifiedTypePanel.window) {
            try {
                var existingPalette = $.global.__UnifiedTypePanel.window;
                existingPalette.show();
                existingPalette.active = true;
                return;
            } catch (existingError) {
                // 参照が死んでいたら作り直す / Stale reference — fall through and rebuild
                $.global.__UnifiedTypePanel = null;
            }
        }

        var autoKernOptions = createAutoKernOptions();
        var alignOptions = createAlignOptions();
        var justifyOptions = createJustifyOptions();
        var ui = createPaletteUI(autoKernOptions, alignOptions, justifyOptions);
        var controller = bindPaletteEvents(ui, autoKernOptions, alignOptions, justifyOptions);

        // 常駐エンジンにパレット参照を保持 / Keep the palette reference on the persistent engine
        $.global.__UnifiedTypePanel = { window: ui.palette };

        // 移動のたびに位置を控える（閉じた位置がそのまま次回の初期位置になる）
        // Track the position on every move, so wherever it was closed becomes next launch's spot
        ui.palette.onMove = function () { savePaletteLocation(ui.palette); };

        // 閉じられたら位置を保存して参照をクリア / Save the position and clear the reference on close
        ui.palette.addEventListener("close", function () {
            savePaletteLocation(ui.palette);
            $.global.__UnifiedTypePanel = null;
        });

        // 前回の位置を復元（保存が無ければ既定位置のまま）/ Restore the last position (default spot when none)
        applySavedPaletteLocation(ui.palette);

        ui.palette.show();

        // show 後にレイアウトが確定するため、位置をもう一度当て直す / Re-apply after show, when layout is final
        applySavedPaletteLocation(ui.palette);

        // 表示（レイアウト確定）後にボタン高さをまとめて共通高さへ / Fit button heights after show (layout is final)
        fitAllButtonHeights(ui);
    }

    main();

})();
