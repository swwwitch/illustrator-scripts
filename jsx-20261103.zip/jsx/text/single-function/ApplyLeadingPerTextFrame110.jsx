#target illustrator
app.preferences.setBooleanPreference('ShowExternalJSXWarning', false);

/*
SCRIPTMETA-BEGIN
Script-ID=com.swwwitch.illustrator.ApplyLeadingPerTextFrame110
Name=行頭の文字サイズを基準に行送りを再計算（110%）
Author=Masahiro Takano (@swwwitch)
Target-App=Illustrator
Version=1.0.2
Description-BEGIN
選択された各テキストフレームの各行について、行頭数文字のフォントサイズを基準に行送りを再計算して適用します。
行送りは110%に固定されます。

Recalculates the leading of each line in the selected text frames from the font size of the first few characters, and applies it.
The leading is fixed at 110%.
Description-END
SCRIPTMETA-END
*/

/*

### 概要

選択された各テキストフレームの各行について、行頭数文字のフォントサイズを基準に行送りを再計算して適用します。
行送りは110%に固定されます。

詳細は README を参照してください。
https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/ApplyLeadingPerTextFrame110.md

### Overview

Recalculates the leading of each line in the selected text frames from the font size of the first few characters, and applies it.
The leading is fixed at 110%.

See the README for details.
https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/ApplyLeadingPerTextFrame110.md

*/

// =========================================
// 基本情報 / Basic info
// =========================================
var SCRIPT_NAME     = "ApplyLeadingPerTextFrame110";  /* スクリプト名 / script name */
var SCRIPT_VERSION  = "v1.0.2";                       /* バージョン / version */
var SCRIPT_AUTHOR   = "Masahiro Takano (@swwwitch)";  /* 作者 / author */
var SCRIPT_RELEASED = "";                             /* 最初のリリース日 / first release date */
var SCRIPT_UPDATED  = "2026-10-04";                   /* 更新日 / last updated */

var SCRIPT_DESCRIPTION_JA = "行頭の文字サイズを基準に行送りを再計算（110%）"; /* README の見出し / README title (Japanese) */

var SCRIPT_README_JA  = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/ApplyLeadingPerTextFrame110.md"; /* README（日本語） */
var SCRIPT_README_EN  = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/ApplyLeadingPerTextFrame110.md"; /* README (English) */
var SCRIPT_SOURCE_URL = "https://github.com/swwwitch/illustrator-scripts/blob/master/jsx/text/single-function/ApplyLeadingPerTextFrame110.jsx"; /* 最新版のソース / latest source */

// Released under the MIT license
// http://opensource.org/licenses/mit-license.php

(function () {

    var DEFAULT_LEADING_RATIO = 1.1; // fallback

    var fileName = File($.fileName).name;
    var match = fileName.match(/(\d+)\.jsx$/);

    if (match) {
        var num = Number(match[1]);
        if (!isNaN(num) && num > 0) {
            DEFAULT_LEADING_RATIO = num / 100;
        }
    }
    var LINE_FONT_SIZE_SAMPLE_COUNT = 5; // 行頭で参照する文字数 / Number of leading characters to sample per line

    // ローカライズ（再利用パーツ） / Localization (reusable)

    /**
     * UI の言語を返す（"ja" で始まるロケールは日本語、それ以外は英語）
     * @returns {string} "ja" または "en"
     */
    function getCurrentLang() {
        return (String($.locale || "").indexOf("ja") === 0) ? "ja" : "en";
    }

    var uiLang = getCurrentLang();

    /**
     * LABELS から今の UI 言語の文言を取り出す。
     * @param {string|Object} labelRef - "dialog.title" のようなパス、または { ja, en }
     * @param {Object|Array} [placeholderValues] - { name: 値 } なら {name} を、[値, …] なら %1, %2 … を差し込む
     * @returns {string} 文言。パスが見つからなければパスの文字列、{ ja, en } が無ければ空文字
     */
    function getLabel(labelRef, placeholderValues) {
        var labelEntry = labelRef;
        if (typeof labelRef === "string") {
            var labelPathKeys = labelRef.split(".");
            labelEntry = LABELS;
            for (var i = 0; i < labelPathKeys.length && labelEntry != null; i++) {
                labelEntry = labelEntry[labelPathKeys[i]];
            }
        }
        var labelString;
        if (typeof labelEntry === "string") labelString = labelEntry;
        else if (labelEntry != null && labelEntry[uiLang] != null) labelString = labelEntry[uiLang];
        else if (labelEntry != null && labelEntry.en != null) labelString = labelEntry.en;
        else return (typeof labelRef === "string") ? labelRef : "";
        return fillLabelPlaceholders(String(labelString), placeholderValues);
    }

    /**
     * 項目名の文言の末尾にコロンを付ける（日本語は半角スペース＋半角コロン「 :」、英語は「:」。Illustrator の線パネルなどの項目名に合わせる）
     * @param {string|Object} labelRef - getLabel と同じ
     * @param {Object|Array} [placeholderValues] - getLabel と同じ
     * @returns {string} コロン付きの文言
     */
    function labelText(labelRef, placeholderValues) {
        return getLabel(labelRef, placeholderValues) + (uiLang === "ja" ? " :" : ":");
    }

    /**
     * 「項目名 : 値」の1行を返す（日本語は「件数 : 5」、英語は「Count: 5」。どちらもコロンのあとに空白を入れる）
     * @param {string|Object} labelRef - getLabel と同じ
     * @param {string|number} value - コロンのあとに続ける値
     * @returns {string} 項目名と値をつないだ文字列
     */
    function labelValueText(labelRef, value) {
        return labelText(labelRef) + " " + value;
    }

    /**
     * 文言の {name} や %1 に値を差し込む
     * @param {string} labelString - 文言
     * @param {Object|Array} [placeholderValues] - { name: 値 } または [値, …]
     * @returns {string} 差し込んだ文言
     */
    function fillLabelPlaceholders(labelString, placeholderValues) {
        if (placeholderValues == null) return labelString;
        if (placeholderValues instanceof Array) {
            /* 大きい番号から置き換え、%1 が %10 の一部を置き換えないようにする / Replace from the highest index so %1 does not eat into %10 */
            for (var i = placeholderValues.length; i >= 1; i--) {
                labelString = labelString.split("%" + i).join(String(placeholderValues[i - 1]));
            }
            return labelString;
        }
        for (var placeholderKey in placeholderValues) {
            if (!placeholderValues.hasOwnProperty(placeholderKey)) continue;
            labelString = labelString.split("{" + placeholderKey + "}").join(String(placeholderValues[placeholderKey]));
        }
        return labelString;
    }

    // ローカライズ（再利用パーツ）ここまで / End of the reusable localization

    var LABELS = {
        alertOpenDocument: {
            ja: "ドキュメントを開いてから実行してください。",
            en: "Please open a document before running this script."
        },
        alertSelectTextObject: {
            ja: "テキストオブジェクトを選択してください。",
            en: "Please select a text object."
        },
        alertLeadingApplyError: {
            ja: "行送りの設定中にエラーが発生しました。",
            en: "An error occurred while applying leading."
        },
        alertNoProcessableLine: {
            ja: "処理可能な行が見つかりませんでした。",
            en: "No processable lines were found."
        },
        alertNoProcessableTextFrame: {
            ja: "処理可能なテキストフレームが選択されていません。",
            en: "No processable text frames are selected."
        }
    };

    applyLeadingPerTextFrame(DEFAULT_LEADING_RATIO);

    function ensureTextFrameSelection() {
        // テキストの一部（TextRange）が選択されている場合、親の TextFrame を選択し直す
        if (app.documents.length > 0 && app.selection && app.selection.typename === "TextRange") {
            var story = app.selection.story;
            if (story && story.textFrames.length === 1) {
                var parentTextFrame = story.textFrames[0];
                app.executeMenuCommand("deselectall");
                app.selection = [parentTextFrame];
                try {
                    app.selectTool("Adobe Select Tool");
                } catch (e) { }
            }
        }
    }

    function getLineSampleFontSizes(line, sampleCount) {
        var fontSizes = [];
        if (!line || !line.characters || line.characters.length === 0) {
            return fontSizes;
        }

        var maxCount = Math.min(line.characters.length, sampleCount);
        for (var i = 0; i < maxCount; i++) {
            try {
                var size = line.characters[i].characterAttributes.size;
                if (!isNaN(size)) {
                    fontSizes.push(size);
                }
            } catch (e) { }
        }

        return fontSizes;
    }

    function getMostFrequentNumber(values) {
        if (!values || values.length === 0) {
            return NaN;
        }

        var counts = {};
        var bestValue = values[0];
        var bestCount = 0;

        for (var i = 0; i < values.length; i++) {
            var key = String(values[i]);
            if (!counts[key]) {
                counts[key] = { value: values[i], count: 0 };
            }
            counts[key].count++;

            if (counts[key].count > bestCount) {
                bestCount = counts[key].count;
                bestValue = counts[key].value;
            } else if (counts[key].count === bestCount && counts[key].value > bestValue) {
                bestValue = counts[key].value;
            }
        }

        return bestValue;
    }

    function getBaseFontSizeFromLine(line) {
        var fontSizes = getLineSampleFontSizes(line, LINE_FONT_SIZE_SAMPLE_COUNT);
        if (!fontSizes || fontSizes.length === 0) {
            return NaN;
        }

        return getMostFrequentNumber(fontSizes);
    }

    function getProcessableTextFrameInfo(item) {
        if (!item || item.typename !== "TextFrame") {
            return null;
        }

        if (!item.contents) {
            return null;
        }

        if (!item.lines || item.lines.length === 0) {
            return null;
        }

        return {
            textFrame: item
        };
    }

    function applyLeadingPerTextFrame(leadingRatio) {
        ensureTextFrameSelection();
        var doc;
        try {
            doc = app.activeDocument;
        } catch (e) {
            alert(getLabel("alertOpenDocument"));
            return;
        }

        var selectedItems = doc.selection;

        if (!selectedItems || selectedItems.length === 0) {
            alert(getLabel("alertSelectTextObject"));
            return;
        }

        var hasValidTextFrame = false;
        var hasProcessableLine = false;
        var hasShownLeadingError = false;

        for (var i = 0; i < selectedItems.length; i++) {
            var textFrameInfo = getProcessableTextFrameInfo(selectedItems[i]);
            if (!textFrameInfo) {
                continue;
            }

            var textFrame = textFrameInfo.textFrame;
            hasValidTextFrame = true;

            try {
                // 各テキストフレーム内の各行ごとに、自動行送りをONにして自動行送りの値（％）を変更する（行送り値そのものやフォントなど他の属性は触らない）
                var autoLeadingPercent = leadingRatio * 100;
                var lines = textFrame.lines;
                for (var j = 0; j < lines.length; j++) {
                    var line = lines[j];
                    var baseFontSizeFromLine = getBaseFontSizeFromLine(line);
                    if (isNaN(baseFontSizeFromLine)) {
                        continue;
                    }

                    hasProcessableLine = true;
                    line.characterAttributes.autoLeading = true;
                    line.paragraphAttributes.autoLeadingAmount = autoLeadingPercent;
                }

            } catch (e) {
                if (!hasShownLeadingError) {
                    alert(getLabel("alertLeadingApplyError") + "\r" + e.message);
                    hasShownLeadingError = true;
                }
            }
        }

        if (!hasValidTextFrame) {
            alert(getLabel("alertNoProcessableTextFrame"));
            return;
        }

        if (!hasProcessableLine) {
            alert(getLabel("alertNoProcessableLine"));
            return;
        }

        redraw();
    }
})();
