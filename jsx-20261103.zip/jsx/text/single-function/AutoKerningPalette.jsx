#targetengine "SwwwitchPalettes"
#target illustrator
app.preferences.setBooleanPreference('ShowExternalJSXWarning', false);

/*
SCRIPTMETA-BEGIN
Script-ID=com.swwwitch.illustrator.AutoKerningPalette
Name=カーニング設定パレット
Author=Masahiro Takano (@swwwitch)
Target-App=Illustrator
Version=1.1.7
Release-Date=2026-06-22
Description-BEGIN
自動カーニング（和文等幅／0／メトリクス／オプティカル）とプロポーショナルメトリクスだけをまとめた常駐パレットです。
ラジオやチェックボックスを操作した時点で、選択中のテキストへ即時適用します。

A persistent palette holding just the auto-kerning methods — Metrics (Roman Only), 0, Metrics, Optical — and proportional metrics.
Every radio button and checkbox applies to the current text selection the moment you touch it.
Description-END
SCRIPTMETA-END
*/

/*

### 概要

自動カーニング（和文等幅／0／メトリクス／オプティカル）とプロポーショナルメトリクスだけをまとめた常駐パレットです。
ラジオやチェックボックスを操作した時点で、選択中のテキストへ即時適用します。

詳細は README を参照してください。
https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/AutoKerningPalette.md

note記事も参照してください。
https://note.com/dtp_tranist/n/ne7a198a4f527

### Overview

A persistent palette holding just the auto-kerning methods — Metrics (Roman Only), 0, Metrics, Optical — and proportional metrics.
Every radio button and checkbox applies to the current text selection the moment you touch it.

See the README for details.
https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/AutoKerningPalette.md

*/

// =========================================
// 基本情報 / Basic info
// =========================================
var SCRIPT_NAME     = "AutoKerningPalette";           /* スクリプト名 / script name */
var SCRIPT_VERSION  = "v1.1.7";                       /* バージョン / version */
var SCRIPT_AUTHOR   = "Masahiro Takano (@swwwitch)";  /* 作者 / author */
var SCRIPT_RELEASED = "2026-06-22";                   /* 最初のリリース日 / first release date */
var SCRIPT_UPDATED  = "2026-10-10";                   /* 更新日 / last updated */

var SCRIPT_DESCRIPTION_JA = "カーニング設定パレット"; /* README の見出し / README title (Japanese) */

var SCRIPT_README_JA   = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/AutoKerningPalette.md"; /* README（日本語） */
var SCRIPT_README_EN   = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/AutoKerningPalette.md"; /* README (English) */
var SCRIPT_ARTICLE_URL = "https://note.com/dtp_tranist/n/ne7a198a4f527"; /* 紹介記事 / article URL */
var SCRIPT_SOURCE_URL  = "https://github.com/swwwitch/illustrator-scripts/blob/master/jsx/text/single-function/AutoKerningPalette.jsx"; /* 最新版のソース / latest source */

// Released under the MIT license
// http://opensource.org/licenses/mit-license.php

(function () {

    // =========================================
    // ローカライズ / Localization
    // =========================================

    // ローカライズ（再利用パーツ） / Localization (reusable)

    /**
     * UI の言語を返す（"ja" で始まるロケールは日本語、それ以外は英語）
     * @returns {string} "ja" または "en"
     */
    function getCurrentLang() {
        return (String($.locale || "").indexOf("ja") === 0) ? "ja" : "en";
    }

    var uiLang = getCurrentLang();

    /**
     * LABELS から今の UI 言語の文言を取り出す。
     * @param {string|Object} labelRef - "dialog.title" のようなパス、または { ja, en }
     * @param {Object|Array} [placeholderValues] - { name: 値 } なら {name} を、[値, …] なら %1, %2 … を差し込む
     * @returns {string} 文言。パスが見つからなければパスの文字列、{ ja, en } が無ければ空文字
     */
    function getLabel(labelRef, placeholderValues) {
        var labelEntry = labelRef;
        if (typeof labelRef === "string") {
            var labelPathKeys = labelRef.split(".");
            labelEntry = LABELS;
            for (var i = 0; i < labelPathKeys.length && labelEntry != null; i++) {
                labelEntry = labelEntry[labelPathKeys[i]];
            }
        }
        var labelString;
        if (typeof labelEntry === "string") labelString = labelEntry;
        else if (labelEntry != null && labelEntry[uiLang] != null) labelString = labelEntry[uiLang];
        else if (labelEntry != null && labelEntry.en != null) labelString = labelEntry.en;
        else return (typeof labelRef === "string") ? labelRef : "";
        return fillLabelPlaceholders(String(labelString), placeholderValues);
    }

    /**
     * 項目名の文言の末尾にコロンを付ける（日本語は半角スペース＋半角コロン「 :」、英語は「:」。Illustrator の線パネルなどの項目名に合わせる）
     * @param {string|Object} labelRef - getLabel と同じ
     * @param {Object|Array} [placeholderValues] - getLabel と同じ
     * @returns {string} コロン付きの文言
     */
    function labelText(labelRef, placeholderValues) {
        return getLabel(labelRef, placeholderValues) + (uiLang === "ja" ? " :" : ":");
    }

    /**
     * 「項目名 : 値」の1行を返す（日本語は「件数 : 5」、英語は「Count: 5」。どちらもコロンのあとに空白を入れる）
     * @param {string|Object} labelRef - getLabel と同じ
     * @param {string|number} value - コロンのあとに続ける値
     * @returns {string} 項目名と値をつないだ文字列
     */
    function labelValueText(labelRef, value) {
        return labelText(labelRef) + " " + value;
    }

    /**
     * 文言の {name} や %1 に値を差し込む
     * @param {string} labelString - 文言
     * @param {Object|Array} [placeholderValues] - { name: 値 } または [値, …]
     * @returns {string} 差し込んだ文言
     */
    function fillLabelPlaceholders(labelString, placeholderValues) {
        if (placeholderValues == null) return labelString;
        if (placeholderValues instanceof Array) {
            /* 大きい番号から置き換え、%1 が %10 の一部を置き換えないようにする / Replace from the highest index so %1 does not eat into %10 */
            for (var i = placeholderValues.length; i >= 1; i--) {
                labelString = labelString.split("%" + i).join(String(placeholderValues[i - 1]));
            }
            return labelString;
        }
        for (var placeholderKey in placeholderValues) {
            if (!placeholderValues.hasOwnProperty(placeholderKey)) continue;
            labelString = labelString.split("{" + placeholderKey + "}").join(String(placeholderValues[placeholderKey]));
        }
        return labelString;
    }

    // ローカライズ（再利用パーツ）ここまで / End of the reusable localization

    var LABELS = {
        title: { ja: "カーニング設定", en: "Kerning Settings" },
        autoKern: { ja: "自動カーニング", en: "Auto Kerning" },
        proportionalMetrics: { ja: "プロポーショナルメトリクス", en: "Proportional Metrics" },
        tipAutoKern: { ja: "自動カーニング方式（和文等幅／0／メトリクス／オプティカル）。選択が触れた段落全体に適用します。", en: "Auto-kerning method (Japanese equal width / 0 / Metrics / Optical), applied to every paragraph the selection touches." },
        tipProportional: { ja: "プロポーショナルメトリクスの ON／OFF。メトリクスを選ぶと自動で ON になります。", en: "Turns proportional metrics on or off. Choosing Metrics turns it on automatically." },
        applyError: { ja: "適用に失敗しました", en: "Apply failed" }
    };

    /* 並び順がラジオの並び順 / Array order = radio order */
    var AUTO_KERN_OPTIONS = [
        { id: "mono", ja: "和文等幅", en: "Metrics - Roman Only" },
        { id: "zero", ja: "0", en: "0" },
        { id: "metrics", ja: "メトリクス", en: "Metrics" },
        { id: "optical", ja: "オプティカル", en: "Optical" }
    ];

    // =========================================
    // メインエンジンで実行する DOM 処理 / DOM helpers run on the main engine
    //
    // toString() で連結して BridgeTalk 本文に同梱し、メインエンジンで eval される。
    // 注意: ここの関数には JSDoc を付けない（toString() の結果が壊れる）。
    // Shipped via toString(); never attach JSDoc — it corrupts the output.
    // =========================================

    /* グループは中を再帰 / Descend into groups */
    function collectTextRangesFromItem(item, selectedRanges) {
        if (!item) return;
        if (item.typename === "TextFrame") {
            selectedRanges.push(item.textRange);
        } else if (item.typename === "TextRange") {
            selectedRanges.push(item);
        } else if (item.typename === "GroupItem" && item.pageItems) {
            for (var i = 0; i < item.pageItems.length; i++) {
                collectTextRangesFromItem(item.pageItems[i], selectedRanges);
            }
        }
    }

    /* 選択が触れた段落を段落全体の範囲で取得 / Get the full paragraphs the selection touches */
    function getSelectedParagraphRanges() {
        var currentSelection = app.activeDocument.selection;
        var ranges = [];
        if (!currentSelection) return ranges;
        /* テキスト編集モードでは selection が TextRange / A text-edit selection is a TextRange */
        if (currentSelection.typename === "TextRange") {
            ranges.push(currentSelection);
        } else {
            for (var i = 0; i < currentSelection.length; i++) {
                collectTextRangesFromItem(currentSelection[i], ranges);
            }
        }
        var paragraphRanges = [];
        for (var j = 0; j < ranges.length; j++) {
            try {
                var paragraphs = ranges[j].paragraphs;
                for (var k = 0; k < paragraphs.length; k++) paragraphRanges.push(paragraphs[k]);
            } catch (e) { }
        }
        return paragraphRanges;
    }

    /* 和文等幅＝欧文のみメトリクス / Japanese equal width = metrics for Roman only */
    function resolveAutoKernType(methodId) {
        if (methodId === "mono") return AutoKernType.METRICSROMANONLY;
        if (methodId === "metrics") return AutoKernType.AUTO;
        if (methodId === "optical") return AutoKernType.OPTICAL;
        return AutoKernType.NOAUTOKERN;
    }

    function kernMethodToId(value) {
        var valueText = String(value);
        if (valueText === String(AutoKernType.AUTO)) return "metrics";
        if (valueText === String(AutoKernType.OPTICAL)) return "optical";
        if (valueText === String(AutoKernType.METRICSROMANONLY)) return "mono";
        if (valueText === String(AutoKernType.NOAUTOKERN)) return "zero";
        return "";
    }

    /* 戻り値は "OK:<payload>" / "ERR:<msg>"。getState の payload は kernId|proportionalMetrics
       Returns "OK:<payload>" / "ERR:<msg>"; getState's payload is kernId|proportionalMetrics */
    function dispatch(action, params) {
        if (app.documents.length === 0) return "ERR:nodoc";
        try { app.activeDocument; } catch (e) { return "ERR:nodoc"; }

        /* いずれも段落単位で適用 / Everything applies per paragraph */
        var ranges = getSelectedParagraphRanges();

        if (action === "getState") {
            /* 最初に読めた段落の先頭文字を代表値にする / The first readable paragraph's first character represents the selection */
            for (var i = 0; i < ranges.length; i++) {
                try {
                    var readAttributes = ranges[i].characters[0].characterAttributes;
                    return "OK:" + kernMethodToId(readAttributes.kerningMethod) + "|" + (readAttributes.proportionalMetrics ? 1 : 0);
                } catch (eRead) { }
            }
            return "OK:";
        }

        if (ranges.length === 0) return "OK:0";
        /* メトリクスのときだけプロポーショナルを ON / Proportional ON only for Metrics */
        var kerningMethod = (action === "apply") ? resolveAutoKernType(params.method) : null;
        var useProportional = (action === "apply") ? (kerningMethod === AutoKernType.AUTO) : params.proportionalMetrics;
        for (var j = 0; j < ranges.length; j++) {
            try {
                var charAttributes = ranges[j].characterAttributes;
                /* 方式を先に確定させてから上書き / Set the method first, then override */
                if (kerningMethod !== null) charAttributes.kerningMethod = kerningMethod;
                charAttributes.proportionalMetrics = useProportional ? true : false;
            } catch (eApply) { }
        }
        app.redraw();
        return "OK:" + ranges.length;
    }

    // =========================================
    // メインエンジン委譲 / Main-engine delegation (BridgeTalk)
    // =========================================

    var WORKER_FUNCS = [collectTextRangesFromItem, getSelectedParagraphRanges, resolveAutoKernType, kernMethodToId, dispatch];
    var WORKER_LIB_SRC = "";
    for (var workerFuncIndex = 0; workerFuncIndex < WORKER_FUNCS.length; workerFuncIndex++) {
        WORKER_LIB_SRC += WORKER_FUNCS[workerFuncIndex].toString() + "\n";
    }

    /* 非同期なので連打による委譲の重複を抑止 / Guard against overlapping async delegations */
    var workerBusy = false;

    /* BridgeTalk は本文のバックスラッシュをエスケープするため、コード全体を
       encodeURIComponent で包んで送り、ターゲットで復元する
       BridgeTalk escapes backslashes, so the code is sent percent-encoded and restored there */
    function runWorker(actionId, params, onDone) {
        if (workerBusy) return;
        workerBusy = true;

        /* method は自前の ID なのでエスケープ不要 / method is our own ASCII id */
        var parts = [];
        if (params && params.method !== undefined) parts.push('method:"' + params.method + '"');
        if (params && params.proportionalMetrics !== undefined) parts.push("proportionalMetrics:" + (params.proportionalMetrics ? "true" : "false"));
        var code = WORKER_LIB_SRC + '\nvar __r=dispatch("' + actionId + '",{' + parts.join(",") + "});__r;";

        var bridge = new BridgeTalk();
        bridge.target = BridgeTalk.appSpecifier;
        bridge.body = "eval(decodeURIComponent(\"" + encodeURIComponent(code) + "\"));";
        bridge.onResult = function (response) {
            workerBusy = false;
            var payload = response.body || "";
            var colonIndex = payload.indexOf(":");
            if (payload.substring(0, colonIndex) === "OK") { onDone(payload.substring(colonIndex + 1)); return; }
            /* ドキュメントなしは異常ではないので黙って無視 / No document is a normal state, not a failure */
            if (payload === "ERR:nodoc") return;
            /* 失敗は握りつぶさず可視化 / Surface failures instead of swallowing them */
            alert("⚠ " + getLabel(LABELS.applyError) + " [" + actionId + "]: " + payload);
        };
        bridge.onError = function (response) {
            workerBusy = false;
            alert("⚠ " + getLabel(LABELS.applyError) + " [" + actionId + "]: " + (response && response.body ? response.body : "BridgeTalk error"));
        };
        bridge.send();
    }

    // =========================================
    // パレット位置の保存・復元 / Palette position persistence
    // 移動のたびの位置を userData に "x,y" で保存し、次回起動時に同じ位置で開く。
    // =========================================

    function getPaletteLocationFile() {
        return File(Folder.userData.fsName + "/AutoKerningPanel_location.txt");
    }

    /* モニタ構成が変わっても画面外に復元しないための検証 / Never restore off-screen after a layout change */
    function isLocationOnScreen(x, y) {
        var screens;
        try { screens = $.screens; } catch (e) { return true; }
        if (!screens || !screens.length) return true;
        var margin = 40; /* タイトルバーを掴める余白 / Keep the title bar reachable */
        for (var i = 0; i < screens.length; i++) {
            var screen = screens[i];
            if (x >= screen.left - margin && x <= screen.right - margin &&
                y >= screen.top && y <= screen.bottom - margin) return true;
        }
        return false;
    }

    function savePaletteLocation(win) {
        var file = getPaletteLocationFile();
        file.encoding = "UTF-8";
        if (!file.open("w")) return;
        file.write(Math.round(win.location[0]) + "," + Math.round(win.location[1]));
        file.close();
    }

    function applySavedPaletteLocation(win) {
        var file = getPaletteLocationFile();
        if (!file.exists) return;
        file.encoding = "UTF-8";
        if (!file.open("r")) return;
        var fields = file.read().split(",");
        file.close();
        var x = parseInt(fields[0], 10), y = parseInt(fields[1], 10);
        if (isNaN(x) || isNaN(y) || !isLocationOnScreen(x, y)) return;
        win.location = [x, y];
    }

    // =========================================
    // UI構築 / Build UI
    // =========================================

    // UIレイアウト（再利用パーツ） / UI layout (reusable)

    /* ウィンドウ・パネルの余白と間隔 / Window & panel margins and spacing */
    var WINDOW_MARGINS = 16;                 /* ウィンドウ外周の余白 / window margin */
    var WINDOW_SPACING = 12;                 /* ウィンドウ内の要素間隔 / window spacing */
    var PANEL_MARGINS  = [16, 20, 16, 12];   /* パネル余白 [左,上,右,下] / panel margins */
    var PANEL_SPACING  = 12;                 /* パネル内の要素間隔 / panel spacing */
    var COLUMN_SPACING = 12;                 /* 2カラムの間隔 / gap between columns */
    var TAB_MARGINS    = [15, 20, 5, 10];    /* タブ余白 [左,上,右,下] / tab margins */

    /**
     * ウィンドウの共通設定
     * @param {Window} targetWindow - 対象のウィンドウ
     * @param {number} [spacing] - 要素間隔（省略時は WINDOW_SPACING）
     * @returns {void}
     */
    function setupWindow(targetWindow, spacing) {
        targetWindow.orientation = "column";
        targetWindow.alignChildren = "fill";
        targetWindow.margins = WINDOW_MARGINS;
        targetWindow.spacing = (typeof spacing === "number") ? spacing : WINDOW_SPACING;
    }

    /**
     * パネルの共通設定（子は幅いっぱい。ボタンは alignment = "left" で広げない）
     * @param {Panel} targetPanel - 対象のパネル
     * @param {number} [spacing] - 要素間隔（省略時は PANEL_SPACING）
     * @returns {void}
     */
    function setupPanel(targetPanel, spacing) {
        targetPanel.orientation = "column";
        targetPanel.alignChildren = ["fill", "top"];
        targetPanel.alignment = "fill";
        targetPanel.margins = PANEL_MARGINS;
        targetPanel.spacing = (typeof spacing === "number") ? spacing : PANEL_SPACING;
    }

    /**
     * タブの共通設定
     * @param {Tab} targetTab - 対象のタブ
     * @param {number} [spacing] - 要素間隔（省略時は変えない）
     * @returns {void}
     */
    function setupTab(targetTab, spacing) {
        targetTab.orientation = "column";
        targetTab.alignChildren = "fill";
        targetTab.margins = TAB_MARGINS;
        if (typeof spacing === "number") targetTab.spacing = spacing;
    }

    /**
     * 横並びの行グループの共通設定（ボタン列など）。
     * alignment と alignChildren を対で指定し、中のボタンが横に伸びたり天地がずれたりしないようにする
     * @param {Group} rowGroup - 対象のグループ
     * @param {string|string[]} [rowAlignment] - 横方向の alignment（省略時は "left"）。配列ならそのまま使う
     * @param {number} [spacing] - 要素間隔（省略時は PANEL_SPACING）
     * @returns {void}
     */
    function setupRow(rowGroup, rowAlignment, spacing) {
        rowGroup.orientation = "row";
        rowGroup.alignment = (rowAlignment instanceof Array) ? rowAlignment : [rowAlignment || "left", "center"];
        rowGroup.alignChildren = ["left", "center"];
        rowGroup.spacing = (typeof spacing === "number") ? spacing : PANEL_SPACING;
    }

    /**
     * ボタンの高さを指定した px だけ詰める（レイアウトが決まったあとに呼ぶ）
     * @param {Button} targetButton - 対象のボタン
     * @param {number} trimPixels - 詰める量（px）
     * @returns {void}
     */
    function trimButtonHeight(targetButton, trimPixels) {
        /* レイアウト前は size が無い / size is not set until the layout runs */
        if (!targetButton.size) return;
        targetButton.size = [targetButton.size.width, targetButton.size.height - trimPixels];
    }

    // UIレイアウト（再利用パーツ）ここまで / End of the reusable UI layout

    function createPalette() {
        var palette = new Window("palette", getLabel(LABELS.title) + " " + SCRIPT_VERSION);
        setupWindow(palette);

        var autoKernPanel = palette.add("panel", undefined, getLabel(LABELS.autoKern));
        setupPanel(autoKernPanel, 6);
        autoKernPanel.helpTip = getLabel(LABELS.tipAutoKern);

        var proportionalCheck = palette.add("checkbox", undefined, getLabel(LABELS.proportionalMetrics));
        proportionalCheck.value = false;
        proportionalCheck.alignment = "left";
        proportionalCheck.helpTip = getLabel(LABELS.tipProportional);

        var kernRadios = [];
        for (var i = 0; i < AUTO_KERN_OPTIONS.length; i++) {
            var kernRadio = autoKernPanel.add("radiobutton", undefined, getLabel(AUTO_KERN_OPTIONS[i]));
            kernRadio.value = false;
            kernRadio.index = i;
            /* 表示も適用と同じ連動にする / Keep the checkbox in step with what is applied */
            kernRadio.onClick = function () {
                var methodId = AUTO_KERN_OPTIONS[this.index].id;
                proportionalCheck.value = (methodId === "metrics");
                runWorker("apply", { method: methodId }, function () { });
            };
            kernRadios.push(kernRadio);
        }

        /* カーニング方式は変えずに単独で適用 / Applied on its own, leaving the kerning method alone */
        proportionalCheck.onClick = function () {
            runWorker("applyProportional", { proportionalMetrics: this.value }, function () { });
        };

        function refreshState() {
            runWorker("getState", null, function (payload) {
                var fields = payload.split("|");
                if (!fields[0]) return; /* 読み取れなければ現在の表示を維持 / Keep the display when nothing could be read */
                for (var i = 0; i < kernRadios.length; i++) kernRadios[i].value = (AUTO_KERN_OPTIONS[i].id === fields[0]);
                proportionalCheck.value = (fields[1] === "1");
            });
        }

        /* 表示・フォーカス復帰のたびに選択状況を反映 / Reflect the selection on show and on regaining focus */
        palette.onShow = refreshState;
        palette.onActivate = refreshState;

        palette.addEventListener("keydown", function (event) {
            if (event.keyName === "Escape") palette.close();
        });

        return palette;
    }

    // =========================================
    // メイン処理 / Main
    // =========================================

    function main() {
        /* 二重起動ガード：既存パレットがあれば前面化 / Single-instance guard */
        if ($.global.__AutoKerningPanel && $.global.__AutoKerningPanel.window) {
            try {
                var existingPalette = $.global.__AutoKerningPanel.window;
                existingPalette.show();
                existingPalette.active = true;
                return;
            } catch (existingError) {
                /* 参照が死んでいたら作り直す / Stale reference, rebuild */
                $.global.__AutoKerningPanel = null;
            }
        }

        var palette = createPalette();
        $.global.__AutoKerningPanel = { window: palette };

        /* 閉じた位置がそのまま次回の初期位置になる / Wherever it was closed becomes next launch's spot */
        palette.onMove = function () { savePaletteLocation(palette); };
        palette.addEventListener("close", function () {
            savePaletteLocation(palette);
            $.global.__AutoKerningPanel = null;
        });

        applySavedPaletteLocation(palette);
        palette.show();
        /* show 後にレイアウトが確定するため当て直す / Re-apply once the layout is final */
        applySavedPaletteLocation(palette);
    }

    main();

})();
