#target illustrator
#targetengine "SelectTextEngine"
app.preferences.setBooleanPreference('ShowExternalJSXWarning', false);

/*
SCRIPTMETA-BEGIN
Script-ID=com.swwwitch.illustrator.SelectText
Name=テキストを一覧表示してクリップボードにコピー
Author=Masahiro Takano (@swwwitch)
Target-App=Illustrator
Version=1.0.8
Release-Date=2026-03-31
Description-BEGIN
現在のアートボードにかかっているテキスト、またはドキュメント全体のテキストを一覧表示し、まとめてクリップボードにコピーします。

Lists the text on the current artboard, or in the whole document, and copies it all to the clipboard.
Description-END
SCRIPTMETA-END
*/

/*

### 概要

現在のアートボードにかかっているテキスト、またはドキュメント全体のテキストを一覧表示し、まとめてクリップボードにコピーします。

詳細は README を参照してください。
https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/SelectText.md

### Overview

Lists the text on the current artboard, or in the whole document, and copies it all to the clipboard.

See the README for details.
https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/SelectText.md

*/

// =========================================
// 基本情報 / Basic info
// =========================================
var SCRIPT_NAME     = "SelectText";                   /* スクリプト名 / script name */
var SCRIPT_VERSION  = "v1.0.8";                       /* バージョン / version */
var SCRIPT_AUTHOR   = "Masahiro Takano (@swwwitch)";  /* 作者 / author */
var SCRIPT_RELEASED = "2026-03-31";                   /* 最初のリリース日 / first release date */
var SCRIPT_UPDATED  = "2026-10-04";                   /* 更新日 / last updated */

var SCRIPT_DESCRIPTION_JA = "テキストを一覧表示してクリップボードにコピー"; /* README の見出し / README title (Japanese) */

var SCRIPT_README_JA  = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/SelectText.md"; /* README（日本語） */
var SCRIPT_README_EN  = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/SelectText.md"; /* README (English) */
var SCRIPT_SOURCE_URL = "https://github.com/swwwitch/illustrator-scripts/blob/master/jsx/text/single-function/SelectText.jsx"; /* 最新版のソース / latest source */

// Released under the MIT license
// http://opensource.org/licenses/mit-license.php

(function () {

    // ローカライズ（再利用パーツ） / Localization (reusable)

    /**
     * UI の言語を返す（"ja" で始まるロケールは日本語、それ以外は英語）
     * @returns {string} "ja" または "en"
     */
    function getCurrentLang() {
        return (String($.locale || "").indexOf("ja") === 0) ? "ja" : "en";
    }

    var uiLang = getCurrentLang();

    /**
     * LABELS から今の UI 言語の文言を取り出す。
     * @param {string|Object} labelRef - "dialog.title" のようなパス、または { ja, en }
     * @param {Object|Array} [placeholderValues] - { name: 値 } なら {name} を、[値, …] なら %1, %2 … を差し込む
     * @returns {string} 文言。パスが見つからなければパスの文字列、{ ja, en } が無ければ空文字
     */
    function getLabel(labelRef, placeholderValues) {
        var labelEntry = labelRef;
        if (typeof labelRef === "string") {
            var labelPathKeys = labelRef.split(".");
            labelEntry = LABELS;
            for (var i = 0; i < labelPathKeys.length && labelEntry != null; i++) {
                labelEntry = labelEntry[labelPathKeys[i]];
            }
        }
        var labelString;
        if (typeof labelEntry === "string") labelString = labelEntry;
        else if (labelEntry != null && labelEntry[uiLang] != null) labelString = labelEntry[uiLang];
        else if (labelEntry != null && labelEntry.en != null) labelString = labelEntry.en;
        else return (typeof labelRef === "string") ? labelRef : "";
        return fillLabelPlaceholders(String(labelString), placeholderValues);
    }

    /**
     * 項目名の文言の末尾にコロンを付ける（日本語は半角スペース＋半角コロン「 :」、英語は「:」。Illustrator の線パネルなどの項目名に合わせる）
     * @param {string|Object} labelRef - getLabel と同じ
     * @param {Object|Array} [placeholderValues] - getLabel と同じ
     * @returns {string} コロン付きの文言
     */
    function labelText(labelRef, placeholderValues) {
        return getLabel(labelRef, placeholderValues) + (uiLang === "ja" ? " :" : ":");
    }

    /**
     * 「項目名 : 値」の1行を返す（日本語は「件数 : 5」、英語は「Count: 5」。どちらもコロンのあとに空白を入れる）
     * @param {string|Object} labelRef - getLabel と同じ
     * @param {string|number} value - コロンのあとに続ける値
     * @returns {string} 項目名と値をつないだ文字列
     */
    function labelValueText(labelRef, value) {
        return labelText(labelRef) + " " + value;
    }

    /**
     * 文言の {name} や %1 に値を差し込む
     * @param {string} labelString - 文言
     * @param {Object|Array} [placeholderValues] - { name: 値 } または [値, …]
     * @returns {string} 差し込んだ文言
     */
    function fillLabelPlaceholders(labelString, placeholderValues) {
        if (placeholderValues == null) return labelString;
        if (placeholderValues instanceof Array) {
            /* 大きい番号から置き換え、%1 が %10 の一部を置き換えないようにする / Replace from the highest index so %1 does not eat into %10 */
            for (var i = placeholderValues.length; i >= 1; i--) {
                labelString = labelString.split("%" + i).join(String(placeholderValues[i - 1]));
            }
            return labelString;
        }
        for (var placeholderKey in placeholderValues) {
            if (!placeholderValues.hasOwnProperty(placeholderKey)) continue;
            labelString = labelString.split("{" + placeholderKey + "}").join(String(placeholderValues[placeholderKey]));
        }
        return labelString;
    }

    // ローカライズ（再利用パーツ）ここまで / End of the reusable localization

    var LABELS = {
        dialogTitle: {
            ja: "テキスト一覧",
            en: "Text"
        },
        scopeArtboard: {
            ja: "現在のアートボードにかかるもの",
            en: "Artboard"
        },
        scopeAll: {
            ja: "ドキュメント全体",
            en: "Document"
        },
        dedupeGroup: {
            ja: "オプション",
            en: "Options"
        },
        dedupeText: {
            ja: "同じテキストをまとめる",
            en: "Merge duplicates"
        },
        ignoreOutside: {
            ja: "アートボード外を無視",
            en: "Ignore outside artboards"
        },
        tipScopeArtboard: {
            ja: "現在のアートボードに重なるテキストだけを集めます。",
            en: "Collects only the text that overlaps the current artboard."
        },
        tipScopeAll: {
            ja: "ドキュメント内のすべてのテキストを集めます。",
            en: "Collects every text object in the document."
        },
        tipDedupe: {
            ja: "同じ内容のテキストを1行にまとめます。",
            en: "Merges identical text into a single line."
        },
        tipIgnoreOutside: {
            ja: "アートボードの外に置かれたテキストを対象から外します。",
            en: "Leaves out text placed outside the artboards."
        },
        tipTextList: {
            ja: "集めたテキストの一覧です。ここで選択した行のオブジェクトがアートボード上でも選択されます。",
            en: "The collected text. Selecting a line here also selects the matching object on the artboard."
        },
        copyAll: {
            ja: "一覧をコピー",
            en: "Copy"
        },
        close: {
            ja: "閉じる",
            en: "Close"
        },
        noDocument: {
            ja: "ドキュメントが開かれていません。",
            en: "No document is open."
        },
        noTextToCopy: {
            ja: "コピーできるテキストがありません。",
            en: "Nothing to copy."
        },
        copyDone: {
            ja: "コピーしました。",
            en: "Copied."
        },
        copyError: {
            ja: "コピー中にエラーが発生しました。",
            en: "Copy failed."
        },
        tempLayerPrefix: {
            ja: "__TextList_CopyTemp__",
            en: "__TextList_CopyTemp__"
        }
    };

    // =========================================
    // レイアウト / Layout
    // =========================================
    // UIレイアウト（再利用パーツ） / UI layout (reusable)

    /* ウィンドウ・パネルの余白と間隔 / Window & panel margins and spacing */
    var WINDOW_MARGINS = 16;                 /* ウィンドウ外周の余白 / window margin */
    var WINDOW_SPACING = 12;                 /* ウィンドウ内の要素間隔 / window spacing */
    var PANEL_MARGINS  = [16, 20, 16, 12];   /* パネル余白 [左,上,右,下] / panel margins */
    var PANEL_SPACING  = 12;                 /* パネル内の要素間隔 / panel spacing */
    var COLUMN_SPACING = 12;                 /* 2カラムの間隔 / gap between columns */
    var TAB_MARGINS    = [15, 20, 5, 10];    /* タブ余白 [左,上,右,下] / tab margins */

    /**
     * ウィンドウの共通設定
     * @param {Window} targetWindow - 対象のウィンドウ
     * @param {number} [spacing] - 要素間隔（省略時は WINDOW_SPACING）
     * @returns {void}
     */
    function setupWindow(targetWindow, spacing) {
        targetWindow.orientation = "column";
        targetWindow.alignChildren = "fill";
        targetWindow.margins = WINDOW_MARGINS;
        targetWindow.spacing = (typeof spacing === "number") ? spacing : WINDOW_SPACING;
    }

    /**
     * パネルの共通設定（子は幅いっぱい。ボタンは alignment = "left" で広げない）
     * @param {Panel} targetPanel - 対象のパネル
     * @param {number} [spacing] - 要素間隔（省略時は PANEL_SPACING）
     * @returns {void}
     */
    function setupPanel(targetPanel, spacing) {
        targetPanel.orientation = "column";
        targetPanel.alignChildren = ["fill", "top"];
        targetPanel.alignment = "fill";
        targetPanel.margins = PANEL_MARGINS;
        targetPanel.spacing = (typeof spacing === "number") ? spacing : PANEL_SPACING;
    }

    /**
     * タブの共通設定
     * @param {Tab} targetTab - 対象のタブ
     * @param {number} [spacing] - 要素間隔（省略時は変えない）
     * @returns {void}
     */
    function setupTab(targetTab, spacing) {
        targetTab.orientation = "column";
        targetTab.alignChildren = "fill";
        targetTab.margins = TAB_MARGINS;
        if (typeof spacing === "number") targetTab.spacing = spacing;
    }

    /**
     * 横並びの行グループの共通設定（ボタン列など）。
     * alignment と alignChildren を対で指定し、中のボタンが横に伸びたり天地がずれたりしないようにする
     * @param {Group} rowGroup - 対象のグループ
     * @param {string|string[]} [rowAlignment] - 横方向の alignment（省略時は "left"）。配列ならそのまま使う
     * @param {number} [spacing] - 要素間隔（省略時は PANEL_SPACING）
     * @returns {void}
     */
    function setupRow(rowGroup, rowAlignment, spacing) {
        rowGroup.orientation = "row";
        rowGroup.alignment = (rowAlignment instanceof Array) ? rowAlignment : [rowAlignment || "left", "center"];
        rowGroup.alignChildren = ["left", "center"];
        rowGroup.spacing = (typeof spacing === "number") ? spacing : PANEL_SPACING;
    }

    /**
     * ボタンの高さを指定した px だけ詰める（レイアウトが決まったあとに呼ぶ）
     * @param {Button} targetButton - 対象のボタン
     * @param {number} trimPixels - 詰める量（px）
     * @returns {void}
     */
    function trimButtonHeight(targetButton, trimPixels) {
        /* レイアウト前は size が無い / size is not set until the layout runs */
        if (!targetButton.size) return;
        targetButton.size = [targetButton.size.width, targetButton.size.height - trimPixels];
    }

    // UIレイアウト（再利用パーツ）ここまで / End of the reusable UI layout

    // ダイアログの位置と不透明度（再利用パーツ） / Dialog position and opacity (reusable)

    var DIALOG_OPACITY = 0.98;       /* ダイアログの不透明度 / dialog opacity */
    var DIALOG_AVOID_MARGIN = 60;    /* 選択範囲の推定位置の両側に取る余裕（px）/ margin on each side of the estimated selection (px) */
    var DIALOG_AVOID_MAX_ITEMS = 100; /* 選択範囲を測るオブジェクトの上限 / max items measured for the selection bounds */

    /**
     * ダイアログの不透明度を設定し、前回閉じた位置で開いて、動かした位置を記録するようにする。
     * 開く位置が選択中のオブジェクトに重なりそうなときは、左右の反対側へずらす（Illustrator のみ）。
     * 既存の onShow / onMove / onClose は先に呼んでから、位置の復元・記録を行う。
     * @param {Window} dialog - 対象のダイアログ
     * @param {string} storageKey - 位置を覚えるキー（ふつうは SCRIPT_NAME）
     * @returns {void}
     */
    function prepareDialogWindow(dialog, storageKey) {
        /* 同じダイアログを開き直すときは、選択範囲を測り直すだけにする（ハンドラーを重ねない）
           When the same dialog is shown again, only re-measure the selection (don't stack handlers) */
        if (dialog.dialogWindowState) {
            dialog.dialogWindowState.selectionSpan = getSelectionViewSpan();
            dialog.dialogWindowState.avoidedLocation = null;
            return;
        }
        var locationKey = "__" + storageKey + "_DialogLocation";
        var previousOnShow = dialog.onShow;
        var previousOnMove = dialog.onMove;
        var previousOnClose = dialog.onClose;
        var windowState = {
            selectionSpan: getSelectionViewSpan(), /* 選択範囲は show() の前に測る / measured before show() */
            screenWidth: null,                     /* 最初に開いたときに推定する / estimated on the first show */
            avoidedLocation: null                  /* 避けるためにずらした位置（記録しない）/ location set to avoid the selection (not remembered) */
        };
        dialog.dialogWindowState = windowState;

        dialog.opacity = DIALOG_OPACITY;

        /* 今の位置を記録する / Remember the current location */
        function rememberDialogLocation() {
            var currentLocation = [dialog.location[0], dialog.location[1]];
            var avoidedLocation = windowState.avoidedLocation;
            if (avoidedLocation && currentLocation[0] === avoidedLocation[0] && currentLocation[1] === avoidedLocation[1]) return;
            $.global[locationKey] = currentLocation;
        }

        dialog.onShow = function () {
            /* 最初に開くときの既定の位置は画面の横中央なので、画面の幅を逆算できる。2回目からは前回の位置なので使い回す
               On the first show the default location is centered horizontally, which gives the screen width; reuse it afterwards */
            if (windowState.screenWidth === null) windowState.screenWidth = dialog.location[0] * 2 + dialog.bounds.width;
            if (previousOnShow) previousOnShow.apply(this, arguments);
            /* $.screens は実際の画面の大きさと合わない（Mac で 1280×524 など）ので、画面内かは判定しない
               $.screens does not match the real display (e.g. 1280x524 on a Mac), so no on-screen check */
            var savedLocation = $.global[locationKey];
            if (savedLocation) dialog.location = [savedLocation[0], savedLocation[1]];
            if (windowState.selectionSpan) {
                var avoidLeft = findDialogLeftAvoidingSelection(dialog.location[0], dialog.bounds.width, windowState.screenWidth, windowState.selectionSpan);
                if (avoidLeft !== null) {
                    dialog.location = [avoidLeft, dialog.location[1]];
                    /* 代入後の値で比べる（丸められることがある）/ Compare with the value after assignment, which may be rounded */
                    windowState.avoidedLocation = [dialog.location[0], dialog.location[1]];
                }
            }
        };
        dialog.onMove = function () {
            if (previousOnMove) previousOnMove.apply(this, arguments);
            rememberDialogLocation();
        };
        dialog.onClose = function () {
            rememberDialogLocation();
            /* false を返すと閉じるのを取りやめるので、戻り値は元の onClose のものを返す
               Returning false cancels the close, so pass the original onClose result through */
            if (previousOnClose) return previousOnClose.apply(this, arguments);
        };
    }

    /**
     * 選択中のオブジェクトが、ドキュメントの表示域の左端から画面上で何 px の範囲にあるかを返す。
     * @returns {{left: number, right: number, viewWidth: number}|null} 選択が無い・測れないときは null
     */
    function getSelectionViewSpan() {
        try {
            if (app.name !== "Adobe Illustrator" || !app.documents.length) return null;
            var targetDoc = app.activeDocument;
            var selectedItems = targetDoc.selection;
            /* 文字ツールで文字を選択しているときは TextRange が返り、[0] が無い / Selecting characters with the Type tool returns a TextRange, which has no [0] */
            if (!selectedItems || selectedItems.typename === "TextRange" || !selectedItems.length || !selectedItems[0].visibleBounds) return null;
            var itemCount = Math.min(selectedItems.length, DIALOG_AVOID_MAX_ITEMS);
            var spanLeft = Infinity;
            var spanRight = -Infinity;
            for (var i = 0; i < itemCount; i++) {
                var itemBounds = selectedItems[i].visibleBounds;
                if (itemBounds[0] < spanLeft) spanLeft = itemBounds[0];
                if (itemBounds[2] > spanRight) spanRight = itemBounds[2];
            }
            var activeView = targetDoc.activeView; /* 複数ウィンドウで開いていても今のウィンドウ / the current window even with multiple windows */
            var viewBounds = activeView.bounds;
            var zoom = activeView.zoom;
            var viewWidth = (viewBounds[2] - viewBounds[0]) * zoom;
            /* 表示域の外にはみ出した部分は数えない / Ignore the part outside the view */
            var left = Math.max(0, (spanLeft - viewBounds[0]) * zoom);
            var right = Math.min(viewWidth, (spanRight - viewBounds[0]) * zoom);
            if (right <= left) return null;
            return { left: left, right: right, viewWidth: viewWidth };
        } catch (e) {
            /* テキスト編集中など測れないときは避けない / Do not avoid when it cannot be measured, e.g. while editing text */
            return null;
        }
    }

    /**
     * ダイアログが選択範囲に重なるなら、重ならない左端の位置を返す。
     * 表示域は画面の横中央にあるとみなし、ずれは DIALOG_AVOID_MARGIN で吸収する。
     * @param {number} dialogLeft - 今のダイアログの左端
     * @param {number} dialogWidth - ダイアログの幅
     * @param {number} screenWidth - 画面の幅
     * @param {{left: number, right: number, viewWidth: number}} selectionSpan - getSelectionViewSpan() の結果
     * @returns {number|null} ずらした左端。重ならない・どちらにも収まらないときは null
     */
    function findDialogLeftAvoidingSelection(dialogLeft, dialogWidth, screenWidth, selectionSpan) {
        var viewLeft = (screenWidth - selectionSpan.viewWidth) / 2;
        var avoidLeft = viewLeft + selectionSpan.left - DIALOG_AVOID_MARGIN;
        var avoidRight = viewLeft + selectionSpan.right + DIALOG_AVOID_MARGIN;
        if (dialogLeft + dialogWidth <= avoidLeft || dialogLeft >= avoidRight) return null;

        var leftSideLeft = avoidLeft - dialogWidth;   /* 選択範囲の左に置くとき / placed left of the selection */
        var rightSideLeft = avoidRight;               /* 選択範囲の右に置くとき / placed right of the selection */
        var fitsLeft = leftSideLeft >= 0;
        var fitsRight = rightSideLeft + dialogWidth <= screenWidth;
        /* 選択範囲が画面の右寄りなら左へ、左寄りなら右へ逃がす / Move away from the side the selection leans to */
        var preferLeft = (avoidLeft + avoidRight) / 2 > screenWidth / 2;
        if (preferLeft && fitsLeft) return leftSideLeft;
        if (fitsRight) return rightSideLeft;
        if (fitsLeft) return leftSideLeft;
        return null;
    }

    // ダイアログの位置と不透明度（再利用パーツ）ここまで / End of the reusable dialog position and opacity

    // ボタン行（再利用パーツ） / Button row (reusable)

    var BUTTON_ROW_TOP_MARGIN = 5; /* ボタン行の上の余白 / top margin of the button row */
    var BUTTON_ROW_BOTTOM_MARGIN = 14; /* ボタン行の下の余白。ダイアログの下余白と合わせて約30px（Illustrator 標準のダイアログに合わせる） / bottom margin; with the dialog margin about 30px, like Illustrator's own dialogs */
    var BUTTON_ROW_SPACING = 10;   /* ボタンどうしの間隔 / spacing between buttons */
    var BUTTON_ROW_CENTER_MAX_WIDTH = 240; /* 右のボタンだけの行を中央に置く、ダイアログの内側の最大幅（px、左右の余白を除く）。広いダイアログは右揃え / max inner dialog width (px, margins excluded) that centers a right-only row; wider dialogs keep it right-aligned */

    /**
     * ダイアログ下部のボタン行を作る。
     * 通常は「左のグループ・伸びるスペーサー・右のグループ」、centered なら行そのものを左右中央に置く
     * @param {Window|Group|Panel} parent - 行を足す先（ふつうはダイアログ）
     * @param {Object} [rowOptions] - { centered: true } で左右中央に並べる
     * @returns {{rowGroup: Group, leftGroup: Group|null, rightGroup: Group|null}} 行と左右のグループ（centered のときは左右が null）
     */
    function addButtonRow(parent, rowOptions) {
        var isCentered = !!(rowOptions && rowOptions.centered);
        var btnRowGroup = parent.add("group");
        btnRowGroup.orientation = "row";
        btnRowGroup.margins = [0, BUTTON_ROW_TOP_MARGIN, 0, BUTTON_ROW_BOTTOM_MARGIN];
        btnRowGroup.spacing = BUTTON_ROW_SPACING;

        if (isCentered) {
            btnRowGroup.alignment = ["center", "bottom"];
            btnRowGroup.alignChildren = ["center", "center"];
            return { rowGroup: btnRowGroup, leftGroup: null, rightGroup: null };
        }

        btnRowGroup.alignment = ["fill", "bottom"];

        var btnLeftGroup = btnRowGroup.add("group");
        btnLeftGroup.alignChildren = ["left", "center"];
        btnLeftGroup.spacing = BUTTON_ROW_SPACING;

        /* 余りの幅を吸って、右のグループを右端に寄せる / Absorbs the extra width so the right group sits at the right edge */
        var spacer = btnRowGroup.add("group");
        spacer.alignment = ["fill", "fill"];
        spacer.minimumSize.width = 0;

        var btnRightGroup = btnRowGroup.add("group");
        btnRightGroup.alignChildren = ["right", "center"];
        btnRightGroup.spacing = BUTTON_ROW_SPACING;

        return { rowGroup: btnRowGroup, leftGroup: btnLeftGroup, rightGroup: btnRightGroup };
    }

    /**
     * 左のグループにボタンが無い（右のボタンだけの）行を、ダイアログの幅に合わせて揃える。
     * 内側の幅（左右の余白を除く）が BUTTON_ROW_CENTER_MAX_WIDTH 以下なら左右中央、それより広ければ右揃えのまま。
     * 幅はレイアウトが決まるまで分からないので、ダイアログを表示した時点（show イベント）で判定する。
     * ボタンをすべて足したあと、show() の前に呼ぶ。centered で作った行や、左にボタンがある行はそのまま
     * @param {{rowGroup: Group, leftGroup: Group|null, rightGroup: Group|null}} buttonRow - addButtonRow() の戻り値
     * @returns {void}
     */
    function alignRightOnlyButtonRow(buttonRow) {
        if (!buttonRow.leftGroup || buttonRow.leftGroup.children.length > 0) return;
        var dialogWindow = buttonRow.rowGroup.window;
        dialogWindow.addEventListener("show", function () {
            if (!buttonRow.leftGroup) return;
            var btnRowGroup = buttonRow.rowGroup;
            /* 行の幅＝ダイアログの内側の幅（左右の余白を除く）/ The row spans the dialog's inner width (margins excluded) */
            if (!btnRowGroup.size || btnRowGroup.size.width > BUTTON_ROW_CENTER_MAX_WIDTH) return;
            /* 左のグループとスペーサーを外し、右のグループだけを中央に置く / Drop the left group and the spacer so only the right group remains, centered */
            btnRowGroup.remove(buttonRow.leftGroup);
            btnRowGroup.remove(btnRowGroup.children[0]); /* 左のグループを外すと先頭はスペーサー / the spacer is first once the left group is gone */
            btnRowGroup.alignment = ["center", "bottom"];
            btnRowGroup.alignChildren = ["center", "center"];
            buttonRow.leftGroup = null;
            dialogWindow.layout.layout(true);
        });
    }

    // ボタン行（再利用パーツ）ここまで / End of the reusable button row

    main();

    function main() {
        if (app.documents.length === 0) {
            alert(getLabel("noDocument"));
            return;
        }

        var doc = app.activeDocument;

        // アートボード内にあるか判定する関数
        function isOnArtboard(item, abRect) {
            var gb = item.geometricBounds;
            return !(gb[2] < abRect[0] || gb[0] > abRect[2] || gb[1] < abRect[3] || gb[3] > abRect[1]);
        }

        function isOnAnyArtboard(item, artboardRects) {
            for (var i = 0; i < artboardRects.length; i++) {
                if (isOnArtboard(item, artboardRects[i])) {
                    return true;
                }
            }
            return false;
        }

        function getAllArtboardRects() {
            var rects = [];
            for (var i = 0; i < doc.artboards.length; i++) {
                rects.push(doc.artboards[i].artboardRect);
            }
            return rects;
        }

        function getTextFrameContents(textFrame) {
            // 強制改行を含めて1つのテキストとして扱う
            var text = textFrame.contents;
            // 改行コードを統一（\r → \n）
            text = text.replace(/\r/g, "\n");
            return text;
        }

        function normalizeLineBreaks(text) {
            return text.replace(/\r\n?/g, "\n");
        }

        function normalizeForDuplicateCheck(text) {
            var normalized = normalizeLineBreaks(text);
            normalized = normalized.replace(/\u3000/g, " ");
            normalized = normalized.replace(/[ \t\f\v]+/g, " ");
            normalized = normalized.replace(/ *\n */g, "\n");
            normalized = normalized.replace(/^\s+|\s+$/g, "");
            return normalized;
        }

        function isEmptyText(text) {
            return normalizeForDuplicateCheck(text) === "";
        }

        function createTempCopyLayer() {
            var prefix = getLabel("tempLayerPrefix");
            var layer = doc.layers.add();
            layer.name = prefix + new Date().getTime() + "_" + Math.floor(Math.random() * 100000);
            layer.visible = true;
            layer.locked = false;
            return layer;
        }

        function collectTextFrames(textFrames, abRect, ignoreOutside, artboardRects) {
            var entries = [];
            for (var i = 0; i < textFrames.length; i++) {
                var textFrame = textFrames[i];
                var shouldInclude = false;

                if (abRect) {
                    shouldInclude = isOnArtboard(textFrame, abRect);
                } else if (ignoreOutside) {
                    shouldInclude = isOnAnyArtboard(textFrame, artboardRects || getAllArtboardRects());
                } else {
                    shouldInclude = true;
                }

                if (shouldInclude) {
                    var text = getTextFrameContents(textFrame);
                    if (!isEmptyText(text)) {
                        entries.push(text);
                    }
                }
            }
            return entries;
        }

        function dedupeEntries(entries) {
            var result = [];
            var seen = {};
            for (var i = 0; i < entries.length; i++) {
                var key = normalizeForDuplicateCheck(entries[i]);
                if (!Object.prototype.hasOwnProperty.call(seen, key)) {
                    seen[key] = true;
                    result.push(entries[i]);
                }
            }
            return result;
        }

        function joinEntries(entries) {
            return entries.length ? entries.join("\n") + "\n" : "";
        }

        function gatherText(useAll, dedupe, ignoreOutside) {
            var entries;
            var allArtboardRects = getAllArtboardRects();
            if (useAll) {
                entries = collectTextFrames(doc.textFrames, null, ignoreOutside, allArtboardRects);
            } else {
                var abIndex = doc.artboards.getActiveArtboardIndex();
                var abRect = doc.artboards[abIndex].artboardRect;
                entries = collectTextFrames(doc.textFrames, abRect, false, allArtboardRects);
            }

            if (dedupe) {
                entries = dedupeEntries(entries);
            }
            return joinEntries(entries);
        }

        function refreshText(editBox, useAll, dedupe, ignoreOutside) {
            editBox.text = gatherText(useAll, dedupe, ignoreOutside);
        }

        function copyAllText(text) {
            if (isEmptyText(text)) {
                alert(getLabel("noTextToCopy"));
                return;
            }

            var prevSelection = [];
            var i;
            for (i = 0; i < doc.selection.length; i++) {
                prevSelection.push(doc.selection[i]);
            }

            var tempLayer = null;
            var tempFrame = null;
            try {
                tempLayer = createTempCopyLayer();
                tempFrame = tempLayer.textFrames.add();
                tempFrame.contents = text;
                doc.selection = null;
                tempFrame.selected = true;
                app.executeMenuCommand("copy");
                alert(getLabel("copyDone"));
            } catch (e) {
                alert(getLabel("copyError") + "\n" + e);
            } finally {
                try {
                    if (tempLayer) {
                        tempLayer.remove();
                    } else if (tempFrame) {
                        tempFrame.remove();
                    }
                } catch (e) { }

                try {
                    doc.selection = null;
                    for (i = 0; i < prevSelection.length; i++) {
                        try {
                            prevSelection[i].selected = true;
                        } catch (e) { }
                    }
                } catch (e) { }
            }
        }

        function bindDialogEvents(ui) {
            ui.rbArtboard.onClick = handleScopeChange;
            ui.rbAll.onClick = handleScopeChange;
            ui.chkDedupe.onClick = handleScopeChange;
            ui.copyBtn.onClick = handleCopy;

            reflectEnabledUI();

            function reflectEnabledUI() {
                ui.chkIgnoreOutside.enabled = ui.rbAll.value;
            }

            function handleScopeChange() {
                reflectEnabledUI();
                refreshText(ui.editBox, ui.rbAll.value, ui.chkDedupe.value, ui.chkIgnoreOutside.value);
            }

            function handleCopy() {
                copyAllText(ui.editBox.text);
            }
        }

        var ui = buildDialogUI();
        bindDialogEvents(ui);
        refreshText(ui.editBox, false, ui.chkDedupe.value, ui.chkIgnoreOutside.value);
        prepareDialogWindow(ui.dlg, SCRIPT_NAME);
        ui.dlg.show();

        function buildDialogUI() {
            var dialog = new Window("dialog", getLabel("dialogTitle") + " " + SCRIPT_VERSION);
            setupWindow(dialog);

            var grpScopeWrap = dialog.add("group");
            grpScopeWrap.orientation = "row";
            grpScopeWrap.alignment = ["center", "top"];
            grpScopeWrap.alignChildren = ["center", "center"];

            var grpScope = grpScopeWrap.add("group");
            grpScope.orientation = "row";
            grpScope.alignChildren = ["left", "center"];
            grpScope.alignment = ["center", "center"];

            var rbArtboard = grpScope.add("radiobutton", undefined, getLabel("scopeArtboard"));
            rbArtboard.helpTip = getLabel("tipScopeArtboard");
            var rbAll = grpScope.add("radiobutton", undefined, getLabel("scopeAll"));
            rbAll.helpTip = getLabel("tipScopeAll");
            rbArtboard.value = true;

            var pnlDedupe = dialog.add("panel", undefined, getLabel("dedupeGroup"));
            setupPanel(pnlDedupe, 6);
            var chkDedupe = pnlDedupe.add("checkbox", undefined, getLabel("dedupeText"));
            chkDedupe.helpTip = getLabel("tipDedupe");
            chkDedupe.value = true;

            var chkIgnoreOutside = pnlDedupe.add("checkbox", undefined, getLabel("ignoreOutside"));
            chkIgnoreOutside.helpTip = getLabel("tipIgnoreOutside");
            chkIgnoreOutside.value = false;

            var editBox = dialog.add("edittext", [0, 0, 400, 300], "", { multiline: true, scrolling: true });
            editBox.helpTip = getLabel("tipTextList");
            editBox.active = true;

            var buttonRow = addButtonRow(dialog);
            var btnCopy = buttonRow.leftGroup.add("button", undefined, getLabel("copyAll"));
            var btnClose = buttonRow.rightGroup.add("button", undefined, getLabel("close"), { name: "cancel" });

            return {
                dlg: dialog,
                rbArtboard: rbArtboard,
                rbAll: rbAll,
                chkDedupe: chkDedupe,
                chkIgnoreOutside: chkIgnoreOutside,
                editBox: editBox,
                copyBtn: btnCopy,
                closeBtn: btnClose
            };
        }
    }

})();
