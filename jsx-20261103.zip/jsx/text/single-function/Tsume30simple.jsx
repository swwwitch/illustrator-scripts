#target illustrator
app.preferences.setBooleanPreference('ShowExternalJSXWarning', false);

/*
SCRIPTMETA-BEGIN
Script-ID=com.swwwitch.illustrator.Tsume30simple
Name=文字ツメを30%に設定
Author=Masahiro Takano (@swwwitch)
Target-App=Illustrator
Version=1.0.1
Description-BEGIN
選択したテキストの文字ツメを30%に設定します。

Sets the tsume of the selected text to 30%.
Description-END
SCRIPTMETA-END
*/

/*

### 概要

選択したテキストの文字ツメを30%に設定します。

詳細は README を参照してください。
https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/Tsume30simple.md

### Overview

Sets the tsume of the selected text to 30%.

See the README for details.
https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/Tsume30simple.md

*/

// =========================================
// 基本情報 / Basic info
// =========================================
var SCRIPT_NAME     = "Tsume30simple";                /* スクリプト名 / script name */
var SCRIPT_VERSION  = "v1.0.1";                       /* バージョン / version */
var SCRIPT_AUTHOR   = "Masahiro Takano (@swwwitch)";  /* 作者 / author */
var SCRIPT_RELEASED = "";                             /* 最初のリリース日 / first release date */
var SCRIPT_UPDATED  = "2026-09-19";                   /* 更新日 / last updated */

var SCRIPT_DESCRIPTION_JA = "文字ツメを30%に設定"; /* README の見出し / README title (Japanese) */

var SCRIPT_README_JA  = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-ja/Tsume30simple.md"; /* README（日本語） */
var SCRIPT_README_EN  = "https://github.com/swwwitch/illustrator-scripts/blob/master/readme-en/Tsume30simple.md"; /* README (English) */
var SCRIPT_SOURCE_URL = "https://github.com/swwwitch/illustrator-scripts/blob/master/jsx/text/single-function/Tsume30simple.jsx"; /* 最新版のソース / latest source */

// Released under the MIT license
// http://opensource.org/licenses/mit-license.php

(function () {

    // =========================================
    // ユーザー設定 / User Settings
    // =========================================
    var TSUME_PERCENT = 30; /* 文字ツメ（%）/ tsume (%) */

    // =========================================
    // メイン処理 / Main
    // =========================================
    if (app.documents.length === 0) return;
    var currentSelection = app.activeDocument.selection;
    if (!currentSelection) return;

    /* テキスト編集モードでは selection が TextRange 単体になる / In text-edit mode the selection is a single TextRange */
    var targetItems = (currentSelection.typename === "TextRange") ? [currentSelection] : currentSelection;

    for (var i = 0; i < targetItems.length; i++) {
        var targetRange = targetItems[i].textRange || targetItems[i];
        /* テキスト以外のオブジェクトは characterAttributes が無いので飛ばす / Non-text items have no characterAttributes */
        try {
            targetRange.characterAttributes.Tsume = TSUME_PERCENT;
        } catch (e) {}
    }
})();
